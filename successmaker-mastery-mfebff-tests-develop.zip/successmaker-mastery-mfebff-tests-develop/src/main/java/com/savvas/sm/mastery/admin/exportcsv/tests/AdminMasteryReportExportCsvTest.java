package com.savvas.sm.mastery.admin.exportcsv.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants.Graphql.MasteryExportCSVConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.ui.mastery.pages.ExportPopupComponent;
import com.savvas.sm.ui.mastery.pages.MasteryFiltersComponent;
import com.savvas.sm.ui.mastery.pages.MasteryMfePage;
import com.savvas.sm.ui.mastery.pages.MasteryReportOutputPage;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.AdminReportCsv;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.ExportCsvConstants;
import com.savvas.sm.utils.sme187.report.exportutils.ExportCsvUtils;
import com.savvas.sm.utils.sql.helper.SqlHelperMastery;
import com.savvas.sm.utils.sql.helper.StandardVersionTable.StandardVersionMastery;

import io.restassured.response.Response;

public class AdminMasteryReportExportCsvTest extends BaseTest {

    private String browser;
    private String districtAdminUsername;
    private String districtAdminUserId;
    private List<String> teacherUsernames;
    private String districtId;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String schoolName;
    private String orgId;
    private String masteryAdminSingleMfeUrl;
    Map<String, String> headers = new HashMap<>();
    private String mathStandardId;
    private String mathStandardName;
    private String readingStandardId;
    private String readingStandardName;
    private static String mathDefaultExportRequestId;
    private static String readingDefaultExportRequestId;
    private static String mathCustomExportRequestId;
    private static String readingCustomExportRequestId;

    //UI response Variable
    String mathSkillDefaultExportedCSVFromUI;
    List<Map<String, String>> mathSkillDefaultExportedCSVSplitted;
    String mathStandardDefaultExportedCSVFromUI;
    List<Map<String, String>> mathStandardDefaultExportedCSVSplitted;
    String readingSkillDefaultExportedCSVFromUI;
    List<Map<String, String>> readingSkillDefaultExportedCSVSplitted;
    String readingStandardDefaultExportedCSVFromUI;
    List<Map<String, String>> readingStandardDefaultExportedCSVSplitted;

    //API response variable
    List<Map<String, String>> mathSplittedAPIData;
    List<Map<String, String>> readingSplittedAPIData;

    @BeforeClass ( alwaysRun = true )
    public void init() throws Exception {
        masteryAdminSingleMfeUrl = configProperty.getProperty( "MasteryAdminSingleMfe" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        //To fetch the admin details from Report data
        try {
            districtAdminUsername = ReportDataCollection.districtAdmin;
            districtAdminUserId = SMUtils.getKeyValueFromResponse( ReportDataCollection.districtAdminDetails, Constants.USERID );
            districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        } catch ( Exception e ) {
            Log.message( "Getting issue while fetch the admin details from Report data" );
        }
        schoolName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = ReportDataCollection.orgId;

        try {
            //To fetch the teacher Details from Report Data
            teacherUsernames = new ArrayList<>( ReportDataCollection.teacherDetails.keySet() );
        } catch ( Exception e ) {
            Log.message( "Getting issue while fetch the teacher details from Report data" );
        }

        //To get the Standard details for Math from DB
        List<StandardVersionMastery> listStandardVersionDB = SqlHelperMastery.getStandards( "MATH" );
        mathStandardId = listStandardVersionDB.get( 0 ).getStandardsId();
        mathStandardName = listStandardVersionDB.get( 0 ).getStandardsName();

        //To get the Standard details for Reading from DB
        listStandardVersionDB = SqlHelperMastery.getStandards( "READING" );
        readingStandardId = listStandardVersionDB.get( 0 ).getStandardsId();
        readingStandardName = listStandardVersionDB.get( 0 ).getStandardsName();

        try {
            WebDriver driver = WebDriverFactory.get( browser );
            mathSkillDefaultExportedCSVFromUI = getCSVDataFromUI( driver, schoolName, "Math", "", false, null );
            if ( Objects.isNull( mathSkillDefaultExportedCSVFromUI ) ) {
                throw new NullPointerException();
            }
        } catch ( Exception e ) {
            WebDriver driver = WebDriverFactory.get( browser );
            mathSkillDefaultExportedCSVFromUI = getCSVDataFromUI( driver, schoolName, "Math", "", false, null );
        }
        mathSkillDefaultExportedCSVSplitted = ExportCsvUtils.splitCSVData( mathSkillDefaultExportedCSVFromUI );

        try {
            WebDriver driver = WebDriverFactory.get( browser );
            readingSkillDefaultExportedCSVFromUI = getCSVDataFromUI( driver, schoolName, "Reading", "", false, null );
            if ( Objects.isNull( mathSkillDefaultExportedCSVFromUI ) ) {
                throw new NullPointerException();
            }
        } catch ( Exception e ) {
            WebDriver driver = WebDriverFactory.get( browser );
            readingSkillDefaultExportedCSVFromUI = getCSVDataFromUI( driver, schoolName, "Reading", "", false, null );
        }
        readingSkillDefaultExportedCSVSplitted = ExportCsvUtils.splitCSVData( readingSkillDefaultExportedCSVFromUI );

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.USERID_SM_HEADER, districtAdminUserId );
        headers.put( Constants.ORGID_SM_HEADER, districtId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( districtAdminUsername, password ) );

        Response mathExportcsvResponseFromAPI = new AdminReportCsv().postMasteryExportCSVAPI( headers, orgId, ExportCsvConstants.DEFAULT, mathDefaultExportRequestId, "", 1, null );
        mathSplittedAPIData = ExportCsvUtils.splitCSVData( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( mathExportcsvResponseFromAPI.getBody().asString(), "signedUrl" ) ) );

        Response readingExportcsvResponseFromAPI = new AdminReportCsv().postMasteryExportCSVAPI( headers, orgId, ExportCsvConstants.DEFAULT, readingDefaultExportRequestId, "", 2, null );
        readingSplittedAPIData = ExportCsvUtils.splitCSVData( getCSVFileFromSignedUrl( SMUtils.getKeyValueFromResponse( readingExportcsvResponseFromAPI.getBody().asString(), "signedUrl" ) ) );

    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv", "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify the fields available in the Export Report CSV popup" )
    public void tcAdminMasteryExportCsv001() throws Exception {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcAdminMasteryExportCsv001 - (Admin - Mastery - Export Default columns) Verify the fields available in the Export Report CSV popup" + browser + "]</b></i></small>" );

        try {
            //Login as a district admin in Mastery MFE
            LoginWrapper.loginToMasteryMfe( driver, masteryAdminSingleMfeUrl, districtAdminUsername, password );
            MasteryMfePage masteryMfePage = new MasteryMfePage( driver ).get();

            MasteryFiltersComponent masteryFilterComponent = masteryMfePage.getMasteryFilterComponent();

            //To select the organization
            masteryFilterComponent.selectOrganization( schoolName );

            //To select the subject
            masteryFilterComponent.selectSubject( "Math" );

            //To Click the apply filter button
            masteryFilterComponent.applyFilter();

            //To click the run report button
            MasteryReportOutputPage masteryReportOutput = masteryFilterComponent.clickRunReport();

            ExportPopupComponent exportPopup = masteryReportOutput.clickExportCSVButton();

            SMUtils.logDescriptionTC( "tc001 - (Admin - Mastery - Export Default columns) Verify the fields available in the Export Report CSV popup" );
            Log.assertThat( exportPopup.getExportTypeLabels().containsAll( Arrays.asList( MasteryExportCSVConstants.EXPORT_DEFAULT, MasteryExportCSVConstants.CUSTOMIZE_EXPORT ) ),
                    "Both Default and custom export labels are present in Export Report CSV popup", " Default and custom export labels are not displaying in Export Report CSV popup. Expected - "
                            + Arrays.asList( MasteryExportCSVConstants.EXPORT_DEFAULT, MasteryExportCSVConstants.CUSTOMIZE_EXPORT ) + ". Actual -" + exportPopup.getExportTypeLabels() );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc002 - (Admin - Mastery - Export Default columns) Verify the fields available in \"Export selected columns\" option" );
            //To select the custom export radio button
            exportPopup.clickCustomizeExportRadioButton();
            List<String> availableColumns = exportPopup.getAllAvailableColumns();
            Log.assertThat( availableColumns.containsAll( MasteryExportCSVConstants.CUSTOM_FILTERS ), "All the custom filters are displaying properly",
                    "All the custom filters are not displaying properly. Expected -" + MasteryExportCSVConstants.CUSTOM_FILTERS + ".Actual - " + availableColumns );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify the csv headers (column name) in downloaded CSV file, for Export Default columns - Math Subject and skill/standard SuccessMaker Mastery Skills - Math" )
    public void tcAdminMasteryExportCsv002() throws Exception {
        Log.testCaseInfo( "tcAdminMasteryExportCsv002 - (Admin - Mastery - Export    Default columns) Verify the fields available in the Export Report CSV popup" + browser + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc003 - (Admin - Mastery - Export Default columns) Verify the csv headers (column name) in downloaded CSV file, for Export Default columns - Math Subject and skill/standard SuccessMaker Mastery Skills - Math" );
            List<String> headersFromExportedCSV = ExportCsvUtils.getCSVHeadersFromResponse( mathSkillDefaultExportedCSVFromUI );
            Log.assertThat( headersFromExportedCSV.containsAll( MasteryExportCSVConstants.DEFAULT_HEADERS ), "All column headers are fetched properly for Math Assignments",
                    "All column headers are not fetched properly for Math Assignments.Expected - " + MasteryExportCSVConstants.DEFAULT_HEADERS + ".Actual - " + headersFromExportedCSV );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify the csv headers (column name) in downloaded CSV file, for Export Default columns - Math Subject and skill/standard - aimswebPlus" )
    public void tcAdminMasteryExportCsv003() throws Exception {
        Log.testCaseInfo( "tcAdminMasteryExportCsv003 - (Admin - Mastery - Export Default columns) Verify the csv headers (column name) in downloaded CSV file, for Export Default columns - Math Subject and skill/standard - aimswebPlus" + browser
                + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc004 - (Admin - Mastery - Export Default columns) Verify the csv headers (column name) in downloaded CSV file, for Export Default columns - Math Subject and skill/standard - aimswebPlus" );

            WebDriver driver = WebDriverFactory.get( browser );
            try {
                mathStandardDefaultExportedCSVFromUI = getCSVDataFromUI( driver, schoolName, "Math", mathStandardName, false, null );
                if ( Objects.isNull( mathStandardDefaultExportedCSVFromUI ) ) {
                    throw new NullPointerException();
                }
            } catch ( Exception e ) {
                driver = WebDriverFactory.get( browser );
                mathStandardDefaultExportedCSVFromUI = getCSVDataFromUI( driver, schoolName, "Math", mathStandardName, false, null );
            }
            mathStandardDefaultExportedCSVSplitted = ExportCsvUtils.splitCSVData( mathStandardDefaultExportedCSVFromUI );

            List<String> headersFromExportedCSV = ExportCsvUtils.getCSVHeadersFromResponse( mathStandardDefaultExportedCSVFromUI );
            Log.assertThat( headersFromExportedCSV.containsAll( MasteryExportCSVConstants.DEFAULT_HEADERS ), "All column headers are fetched properly for Math -Standard",
                    "All column headers are not fetched properly for Math - Standard.Expected - " + MasteryExportCSVConstants.DEFAULT_HEADERS + ".Actual - " + headersFromExportedCSV );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify the csv headers (column name) in downloaded CSV file, for Export Default columns - Reading Subject and skill/standard SuccessMaker Mastery Skills - Math" )
    public void tcAdminMasteryExportCsv004() throws Exception {
        Log.testCaseInfo(
                "tcAdminMasteryExportCsv004 - (Admin - Mastery - Export Default columns) Verify the csv headers (column name) in downloaded CSV file, for Export Default columns - Reading Subject and skill/standard SuccessMaker Mastery Skills - Math"
                        + browser + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc005 -  (Admin - Mastery - Export Default columns) Verify the csv headers (column name) in downloaded CSV file, for Export Default columns - Reading Subject and skill/standard SuccessMaker Mastery Skills - Math" );
            List<String> headersFromExportedCSV = ExportCsvUtils.getCSVHeadersFromResponse( readingSkillDefaultExportedCSVFromUI );
            Log.assertThat( headersFromExportedCSV.containsAll( MasteryExportCSVConstants.DEFAULT_HEADERS ), "All column headers are fetched properly for Reading -Skill",
                    "All column headers are not fetched properly for Reading - Skill.Expected - " + MasteryExportCSVConstants.DEFAULT_HEADERS + ".Actual - " + headersFromExportedCSV );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify the csv headers (column name) in downloaded CSV file, for Export Default columns - Reading Subject and skill/standard - any one standard" )
    public void tcAdminMasteryExportCsv005() throws Exception {
        Log.testCaseInfo( "tcAdminMasteryExportCsv005 - (Admin - Mastery - Export Default columns) Verify the csv headers (column name) in downloaded CSV file, for Export Default columns - Reading Subject and skill/standard - any one standard" + browser
                + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc006 -  (Admin - Mastery - Export Default columns) Verify the csv headers (column name) in downloaded CSV file, for Export Default columns - Reading Subject and skill/standard - any one standard" );

            WebDriver driver = WebDriverFactory.get( browser );
            try {
                readingStandardDefaultExportedCSVFromUI = getCSVDataFromUI( driver, schoolName, "Reading", readingStandardName, false, null );
                if ( Objects.isNull( mathStandardDefaultExportedCSVFromUI ) ) {
                    throw new NullPointerException();
                }
            } catch ( Exception e ) {
                driver = WebDriverFactory.get( browser );
                readingStandardDefaultExportedCSVFromUI = getCSVDataFromUI( driver, schoolName, "Reading", readingStandardName, false, null );
            }
            readingStandardDefaultExportedCSVSplitted = ExportCsvUtils.splitCSVData( readingStandardDefaultExportedCSVFromUI );

            List<String> headersFromExportedCSV = ExportCsvUtils.getCSVHeadersFromResponse( readingStandardDefaultExportedCSVFromUI );
            Log.assertThat( headersFromExportedCSV.containsAll( MasteryExportCSVConstants.DEFAULT_HEADERS ), "All column headers are fetched properly for Reading -Standard",
                    "All column headers are not fetched properly for Reading - Standard.Expected - " + MasteryExportCSVConstants.DEFAULT_HEADERS + ".Actual - " + headersFromExportedCSV );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Default math assignment who has cleared the IP.\r\n" + "" )
    public void tcAdminMasteryExportCsv006() throws Exception {
        Log.testCaseInfo( "tcAdminMasteryExportCsv006 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Default math assignment who has cleared the IP." + browser + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc007 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Default math assignment who has cleared the IP.\\r\\n" );

            //To get the IP Cleared Student ID
            Optional<String> studentId = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map(
                    entry -> entry.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( entry.get( student ), "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ).findFirst().orElse( null ) ).filter(
                            studentID -> Objects.nonNull( studentID ) ).findFirst();

            //To get the student details
            String studentDetail = new RBSUtils().getUser( studentId.get() );
            String studentName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "lastName" );

            //To get the course name
            Optional<String> courseName = ReportDataCollection.defaultMathAssignmentDetails.values().stream().filter( entry -> Objects.nonNull( entry.get( studentId.get() ) ) ).map(
                    entry -> SMUtils.getKeyValueFromResponse( entry.get( studentId.get() ), "courseDetail,name" ) ).findFirst();

            //To get the exported data for respective student
            List<Map<String, String>> exportedDataFromUI = mathSkillDefaultExportedCSVSplitted.stream().filter(
                    entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect( Collectors.toList() );

            exportedDataFromUI.stream().forEach( entry -> entry.remove( "\"Report Run\"" ) );

            List<Map<String, String>> exportedDataFromAPI = mathSplittedAPIData.stream().filter( entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect(
                    Collectors.toList() );

            //Comparing both API and UI data
            Log.assertThat( exportedDataFromAPI.stream().allMatch( dataFromAPI -> exportedDataFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "All the student's mastery details are present in downloaded csv File for math assignments who has cleared the IP",
                    "Student's mastery details are not fetching properly for math assignments in downloaded csv File who has cleared the IP. Expected -" + exportedDataFromAPI.toString() + ".Actual -" + exportedDataFromUI.toString() );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Default math assignment who has not cleared the IP.\r\n" + "" + "" )
    public void tcAdminMasteryExportCsv007() throws Exception {
        Log.testCaseInfo( "tcAdminMasteryExportCsv007 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Default math assignment who has not cleared the IP." + browser + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc008 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Default math assignment who has not cleared the IP." );

            //To get the IP Not Cleared Student ID
            Optional<String> studentId = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map(
                    entry -> entry.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( entry.get( student ), "ipStatus" ).equalsIgnoreCase( "PENDING" ) ).findFirst().orElse( null ) ).filter(
                            studentID -> Objects.nonNull( studentID ) ).findFirst();

            //To get the student details
            String studentDetail = new RBSUtils().getUser( studentId.get() );
            String studentName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "lastName" );

            //To get the course name
            Optional<String> courseName = ReportDataCollection.defaultMathAssignmentDetails.values().stream().filter( entry -> Objects.nonNull( entry.get( studentId.get() ) ) ).map(
                    entry -> SMUtils.getKeyValueFromResponse( entry.get( studentId.get() ), "courseDetail,name" ) ).findFirst();

            //To get the exported data for respective student
            List<Map<String, String>> exportedDataFromUI = mathSkillDefaultExportedCSVSplitted.stream().filter(
                    entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect( Collectors.toList() );

            exportedDataFromUI.stream().forEach( entry -> entry.remove( "\"Report Run\"" ) );

            List<Map<String, String>> exportedDataFromAPI = mathSplittedAPIData.stream().filter( entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect(
                    Collectors.toList() );

            //Comparing both API and UI data
            Log.assertThat( exportedDataFromAPI.stream().allMatch( dataFromAPI -> exportedDataFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "student's mastery details are present in downloaded csv File for math assignments who has not cleared the IP",
                    "Student's mastery details are not fetching properly for math assignments in downloaded csv File who has not cleared the IP. Expected -" + exportedDataFromAPI.toString() + ".Actual -" + exportedDataFromUI.toString() );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Default reading assignment who has cleared the IP" )
    public void tcAdminMasteryExportCsv008() throws Exception {
        Log.testCaseInfo( "tcAdminMasteryExportCsv008 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Default reading assignment who has cleared the IP." + browser + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc009 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Default reading assignment who has cleared the IP" );

            //To get the IP Cleared Student ID
            Optional<String> studentId = ReportDataCollection.defaultReadingAssignmentDetails.values().stream().map(
                    entry -> entry.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( entry.get( student ), "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ).findFirst().orElse( null ) ).filter(
                            studentID -> Objects.nonNull( studentID ) ).findFirst();

            //To get the student details
            String studentDetail = new RBSUtils().getUser( studentId.get() );
            String studentName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "lastName" );

            //To get the course name
            Optional<String> courseName = ReportDataCollection.defaultReadingAssignmentDetails.values().stream().filter( entry -> Objects.nonNull( entry.get( studentId.get() ) ) ).map(
                    entry -> SMUtils.getKeyValueFromResponse( entry.get( studentId.get() ), "courseDetail,name" ) ).findFirst();

            //To get the exported data for respective student
            List<Map<String, String>> exportedDataFromUI = readingSkillDefaultExportedCSVSplitted.stream().filter(
                    entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect( Collectors.toList() );

            exportedDataFromUI.stream().forEach( entry -> entry.remove( "\"Report Run\"" ) );

            List<Map<String, String>> exportedDataFromAPI = readingSplittedAPIData.stream().filter( entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect(
                    Collectors.toList() );

            //Comparing both API and UI data
            Log.assertThat( exportedDataFromAPI.stream().allMatch( dataFromAPI -> exportedDataFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "student's mastery details are present in downloaded csv File for reading assignments who has cleared the IP",
                    "Student's mastery details are not fetching properly for reading assignments in downloaded csv File who has cleared the IP. Expected -" + exportedDataFromAPI.toString() + ".Actual -" + exportedDataFromUI.toString() );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Default Reading assignment who has not cleared the IP" )
    public void tcAdminMasteryExportCsv009() throws Exception {
        Log.testCaseInfo( "tcAdminMasteryExportCsv009 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Default Reading assignment who has not cleared the IP." + browser + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc010 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Default Reading assignment who has not cleared the IP." );

            //To get the IP Cleared Student ID
            Optional<String> studentId = ReportDataCollection.defaultReadingAssignmentDetails.values().stream().map(
                    entry -> entry.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( entry.get( student ), "ipStatus" ).equalsIgnoreCase( "PENDING" ) ).findFirst().orElse( null ) ).filter(
                            studentID -> Objects.nonNull( studentID ) ).findFirst();

            //To get the student details
            String studentDetail = new RBSUtils().getUser( studentId.get() );
            String studentName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "lastName" );

            //To get the course name
            Optional<String> courseName = ReportDataCollection.defaultReadingAssignmentDetails.values().stream().filter( entry -> Objects.nonNull( entry.get( studentId.get() ) ) ).map(
                    entry -> SMUtils.getKeyValueFromResponse( entry.get( studentId.get() ), "courseDetail,name" ) ).findFirst();

            //To get the exported data for respective student
            List<Map<String, String>> exportedDataFromUI = readingSkillDefaultExportedCSVSplitted.stream().filter(
                    entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect( Collectors.toList() );

            exportedDataFromUI.stream().forEach( entry -> entry.remove( "\"Report Run\"" ) );

            List<Map<String, String>> exportedDataFromAPI = readingSplittedAPIData.stream().filter( entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect(
                    Collectors.toList() );

            //Comparing both API and UI data
            Log.assertThat( exportedDataFromAPI.stream().allMatch( dataFromAPI -> exportedDataFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "student's mastery details are present in downloaded csv File for reading assignments who has not cleared the IP",
                    "Student's mastery details are not fetching properly for reading assignments in downloaded csv File who has not cleared the IP. Expected -" + exportedDataFromAPI.toString() + ".Actual -" + exportedDataFromUI.toString() );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for math Custom Setting IP On assignment who has cleared the IP." )
    public void tcAdminMasteryExportCsv010() throws Exception {
        Log.testCaseInfo( "tcAdminMasteryExportCsv010 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for math Custom Setting IP On assignment who has cleared the IP." + browser + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc011 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for math Custom Setting IP On assignment who has cleared the IP." );

            //To get the IP Cleared Student ID
            Optional<String> studentId = ReportDataCollection.mathSettingIPMONAssignmentDetails.values().stream().map(
                    entry -> entry.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( entry.get( student ), "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ).findFirst().orElse( null ) ).filter(
                            studentID -> Objects.nonNull( studentID ) ).findFirst();

            //To get the student details
            String studentDetail = new RBSUtils().getUser( studentId.get() );
            String studentName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "lastName" );

            //To get the course name
            Optional<String> courseName = ReportDataCollection.mathSettingIPMONAssignmentDetails.values().stream().filter( entry -> Objects.nonNull( entry.get( studentId.get() ) ) ).map(
                    entry -> SMUtils.getKeyValueFromResponse( entry.get( studentId.get() ), "courseDetail,name" ) ).findFirst();

            //To get the exported data for respective student
            List<Map<String, String>> exportedDataFromUI = mathSkillDefaultExportedCSVSplitted.stream().filter(
                    entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect( Collectors.toList() );

            exportedDataFromUI.stream().forEach( entry -> entry.remove( "\"Report Run\"" ) );

            List<Map<String, String>> exportedDataFromAPI = mathSplittedAPIData.stream().filter( entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect(
                    Collectors.toList() );

            //Comparing both API and UI data
            Log.assertThat( exportedDataFromAPI.stream().allMatch( dataFromAPI -> exportedDataFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "student's mastery details are present in downloaded csv File for Math- Custom settings IPM on assignments who has cleared the IP",
                    "Student's mastery details are not fetching properly for Math- Custom settings IPM on assignments in downloaded csv File who has cleared the IP. Expected -" + exportedDataFromAPI.toString() + ".Actual -"
                            + exportedDataFromUI.toString() );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for math Custom Setting IP On assignment who has not cleared the IP.\r\n" + "" )
    public void tcAdminMasteryExportCsv011() throws Exception {
        Log.testCaseInfo( "tcAdminMasteryExportCsv011 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for math Custom Setting IP On assignment who has not cleared the IP." + browser + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc012 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for math Custom Setting IP On assignment who has not cleared the IP." );

            //To get the IP Cleared Student ID
            Optional<String> studentId = ReportDataCollection.mathSettingIPMONAssignmentDetails.values().stream().map(
                    entry -> entry.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( entry.get( student ), "ipStatus" ).equalsIgnoreCase( "PENDING" ) ).findFirst().orElse( null ) ).filter(
                            studentID -> Objects.nonNull( studentID ) ).findFirst();

            //To get the student details
            String studentDetail = new RBSUtils().getUser( studentId.get() );
            String studentName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "lastName" );

            //To get the course name
            Optional<String> courseName = ReportDataCollection.mathSettingIPMONAssignmentDetails.values().stream().filter( entry -> Objects.nonNull( entry.get( studentId.get() ) ) ).map(
                    entry -> SMUtils.getKeyValueFromResponse( entry.get( studentId.get() ), "courseDetail,name" ) ).findFirst();

            //To get the exported data for respective student
            List<Map<String, String>> exportedDataFromUI = mathSkillDefaultExportedCSVSplitted.stream().filter(
                    entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect( Collectors.toList() );

            exportedDataFromUI.stream().forEach( entry -> entry.remove( "\"Report Run\"" ) );

            List<Map<String, String>> exportedDataFromAPI = mathSplittedAPIData.stream().filter( entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect(
                    Collectors.toList() );

            //Comparing both API and UI data
            Log.assertThat( exportedDataFromAPI.stream().allMatch( dataFromAPI -> exportedDataFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "All the student's mastery details are present in downloaded csv File for Math- Custom settings IPM on assignments who has not cleared the IP",
                    "Student's mastery details are not fetching properly for Math- Custom settings IPM on assignments in downloaded csv File who has not cleared the IP. Expected -" + exportedDataFromAPI.toString() + ".Actual -"
                            + exportedDataFromUI.toString() );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Reading- Custom Setting IP On assignment who has cleared the IP." )
    public void tcAdminMasteryExportCsv012() throws Exception {
        Log.testCaseInfo( "tcAdminMasteryExportCsv012 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Reading- Custom Setting IP On assignment who has cleared the IP." + browser + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc013 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Reading- Custom Setting IP On assignment who has cleared the IP." );

            //To get the IP Cleared Student ID
            Optional<String> studentId = ReportDataCollection.readingSettingIPMONAssignmentDetails.values().stream().map(
                    entry -> entry.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( entry.get( student ), "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ).findFirst().orElse( null ) ).filter(
                            studentID -> Objects.nonNull( studentID ) ).findFirst();

            //To get the student details
            String studentDetail = new RBSUtils().getUser( studentId.get() );
            String studentName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "lastName" );

            //To get the course name
            Optional<String> courseName = ReportDataCollection.readingSettingIPMONAssignmentDetails.values().stream().filter( entry -> Objects.nonNull( entry.get( studentId.get() ) ) ).map(
                    entry -> SMUtils.getKeyValueFromResponse( entry.get( studentId.get() ), "courseDetail,name" ) ).findFirst();

            //To get the exported data for respective student
            List<Map<String, String>> exportedDataFromUI = readingSkillDefaultExportedCSVSplitted.stream().filter(
                    entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect( Collectors.toList() );

            exportedDataFromUI.stream().forEach( entry -> entry.remove( "\"Report Run\"" ) );

            List<Map<String, String>> exportedDataFromAPI = readingSplittedAPIData.stream().filter( entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect(
                    Collectors.toList() );

            //Comparing both API and UI data
            Log.assertThat( exportedDataFromAPI.stream().allMatch( dataFromAPI -> exportedDataFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "student's mastery details are present in downloaded csv File for Reading- Custom settings IPM on assignments who has cleared the IP",
                    "Student's mastery details are not fetching properly for Reading- Custom settings IPM on assignments in downloaded csv File who has  cleared the IP. Expected -" + exportedDataFromAPI.toString() + ".Actual -"
                            + exportedDataFromUI.toString() );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Reading- Custom Setting IP On assignment who has not cleared the IP." )
    public void tcAdminMasteryExportCsv013() throws Exception {
        Log.testCaseInfo( "tcAdminMasteryExportCsv013 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Reading- Custom Setting IP On assignment who has not cleared the IP." + browser + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc014 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Reading- Custom Setting IP On assignment who has not cleared the IP." );

            //To get the IP Cleared Student ID
            Optional<String> studentId = ReportDataCollection.readingSettingIPMONAssignmentDetails.values().stream().map(
                    entry -> entry.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( entry.get( student ), "ipStatus" ).equalsIgnoreCase( "PENDING" ) ).findFirst().orElse( null ) ).filter(
                            studentID -> Objects.nonNull( studentID ) ).findFirst();

            //To get the student details
            String studentDetail = new RBSUtils().getUser( studentId.get() );
            String studentName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "lastName" );

            //To get the course name
            Optional<String> courseName = ReportDataCollection.readingSettingIPMONAssignmentDetails.values().stream().filter( entry -> Objects.nonNull( entry.get( studentId.get() ) ) ).map(
                    entry -> SMUtils.getKeyValueFromResponse( entry.get( studentId.get() ), "courseDetail,name" ) ).findFirst();

            //To get the exported data for respective student
            List<Map<String, String>> exportedDataFromUI = readingSkillDefaultExportedCSVSplitted.stream().filter(
                    entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect( Collectors.toList() );

            exportedDataFromUI.stream().forEach( entry -> entry.remove( "\"Report Run\"" ) );

            List<Map<String, String>> exportedDataFromAPI = readingSplittedAPIData.stream().filter( entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect(
                    Collectors.toList() );

            //Comparing both API and UI data
            Log.assertThat( exportedDataFromAPI.stream().allMatch( dataFromAPI -> exportedDataFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "All the student's mastery details are present in downloaded csv File for Reading- Custom settings IPM on assignments who has not cleared the IP",
                    "Student's mastery details are not fetching properly for Reading- Custom settings IPM on assignments in downloaded csv File who has not cleared the IP. Expected -" + exportedDataFromAPI.toString() + ".Actual -"
                            + exportedDataFromUI.toString() );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Math - Custom Setting IP Off assignment." )
    public void tcAdminMasteryExportCsv014() throws Exception {
        Log.testCaseInfo( "tcAdminMasteryExportCsv014 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Math - Custom Setting IP Off assignment." + browser + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc015 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Math - Custom Setting IP Off assignment." );

            //To get the IP Cleared Student ID
            Optional<String> studentId = ReportDataCollection.mathSettingIPMOFFAssignmentDetails.values().stream().map(
                    entry -> entry.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( entry.get( student ), "ipStatus" ).equalsIgnoreCase( "INACTIVE" ) ).findFirst().orElse( null ) ).filter(
                            studentID -> Objects.nonNull( studentID ) ).findFirst();

            //To get the student details
            String studentDetail = new RBSUtils().getUser( studentId.get() );
            String studentName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "lastName" );

            //To get the course name
            Optional<String> courseName = ReportDataCollection.mathSettingIPMOFFAssignmentDetails.values().stream().filter( entry -> Objects.nonNull( entry.get( studentId.get() ) ) ).map(
                    entry -> SMUtils.getKeyValueFromResponse( entry.get( studentId.get() ), "courseDetail,name" ) ).findFirst();

            //To get the exported data for respective student
            List<Map<String, String>> exportedDataFromUI = mathSkillDefaultExportedCSVSplitted.stream().filter(
                    entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect( Collectors.toList() );

            exportedDataFromUI.stream().forEach( entry -> entry.remove( "\"Report Run\"" ) );

            List<Map<String, String>> exportedDataFromAPI = mathSplittedAPIData.stream().filter( entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect(
                    Collectors.toList() );

            //Comparing both API and UI data
            Log.assertThat( exportedDataFromAPI.stream().allMatch( dataFromAPI -> exportedDataFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "student's mastery details are present in downloaded csv File for Math- Custom settings IPM off assignments",
                    "Student's mastery details are not fetching properly for Math- Custom settings IPM offmathSettingIPMOFFAssignmentDetails. Expected -" + exportedDataFromAPI.toString() + ".Actual -" + exportedDataFromUI.toString() );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Reading - Custom Setting IP Off assignment." )
    public void tcAdminMasteryExportCsv015() throws Exception {
        Log.testCaseInfo( "tcAdminMasteryExportCsv015 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Reading - Custom Setting IP Off assignment." + browser + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc016 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Reading - Custom Setting IP Off assignment." );

            //To get the IP Cleared Student ID
            Optional<String> studentId = ReportDataCollection.readingSettingIPMOFFAssignmentDetails.values().stream().map(
                    entry -> entry.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( entry.get( student ), "ipStatus" ).equalsIgnoreCase( "INACTIVE" ) ).findFirst().orElse( null ) ).filter(
                            studentID -> Objects.nonNull( studentID ) ).findFirst();

            //To get the student details
            String studentDetail = new RBSUtils().getUser( studentId.get() );
            String studentName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "lastName" );

            //To get the course name
            Optional<String> courseName = ReportDataCollection.readingSettingIPMOFFAssignmentDetails.values().stream().filter( entry -> Objects.nonNull( entry.get( studentId.get() ) ) ).map(
                    entry -> SMUtils.getKeyValueFromResponse( entry.get( studentId.get() ), "courseDetail,name" ) ).findFirst();

            //To get the exported data for respective student
            List<Map<String, String>> exportedDataFromUI = readingSkillDefaultExportedCSVSplitted.stream().filter(
                    entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect( Collectors.toList() );

            exportedDataFromUI.stream().forEach( entry -> entry.remove( "\"Report Run\"" ) );

            List<Map<String, String>> exportedDataFromAPI = readingSplittedAPIData.stream().filter( entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect(
                    Collectors.toList() );

            //Comparing both API and UI data
            Log.assertThat( exportedDataFromAPI.stream().allMatch( dataFromAPI -> exportedDataFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "student's mastery details are present in downloaded csv File for Reading- Custom settings IPM off assignments",
                    "Student's mastery details are not fetching properly for Reading- Custom settings IPM Reading- Custom settings IPM off assignments. Expected -" + exportedDataFromAPI.toString() + ".Actual -" + exportedDataFromUI.toString() );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Math - Custom by skill assignment." )
    public void tcAdminMasteryExportCsv016() throws Exception {
        Log.testCaseInfo( "tcAdminMasteryExportCsv016 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Math - Custom by skill assignment." + browser + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc017 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Math - Custom by skill assignment." );

            //To get the IP Cleared Student ID
            Optional<String> studentId = ReportDataCollection.mathSkillAssignmentDetails.values().stream().map(
                    entry -> entry.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( entry.get( student ), "ipStatus" ).equalsIgnoreCase( "INACTIVE" ) ).findFirst().orElse( null ) ).filter(
                            studentID -> Objects.nonNull( studentID ) ).findFirst();

            //To get the student details
            String studentDetail = new RBSUtils().getUser( studentId.get() );
            String studentName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "lastName" );

            //To get the course name
            Optional<String> courseName = ReportDataCollection.mathSkillAssignmentDetails.values().stream().filter( entry -> Objects.nonNull( entry.get( studentId.get() ) ) ).map(
                    entry -> SMUtils.getKeyValueFromResponse( entry.get( studentId.get() ), "courseDetail,name" ) ).findFirst();

            //To get the exported data for respective student
            List<Map<String, String>> exportedDataFromUI = mathSkillDefaultExportedCSVSplitted.stream().filter(
                    entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect( Collectors.toList() );

            exportedDataFromUI.stream().forEach( entry -> entry.remove( "\"Report Run\"" ) );

            List<Map<String, String>> exportedDataFromAPI = mathSplittedAPIData.stream().filter( entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect(
                    Collectors.toList() );

            //Comparing both API and UI data
            Log.assertThat( exportedDataFromAPI.stream().allMatch( dataFromAPI -> exportedDataFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "student's mastery details are present in downloaded csv File for Math- Custom skill assignments",
                    "Student's mastery details are not fetching properly for Math- Custom skill assignments. Expected -" + exportedDataFromAPI.toString() + ".Actual -" + exportedDataFromUI.toString() );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for reading Custom by skill assignment" )
    public void tcAdminMasteryExportCsv017() throws Exception {
        Log.testCaseInfo( "tcAdminMasteryExportCsv017 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for reading Custom by skill assignment" + browser + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc018 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for reading Custom by skill assignment" );

            //To get the IP Cleared Student ID
            Optional<String> studentId = ReportDataCollection.readingSkillAssignmentDetails.values().stream().map(
                    entry -> entry.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( entry.get( student ), "ipStatus" ).equalsIgnoreCase( "INACTIVE" ) ).findFirst().orElse( null ) ).filter(
                            studentID -> Objects.nonNull( studentID ) ).findFirst();

            //To get the student details
            String studentDetail = new RBSUtils().getUser( studentId.get() );
            String studentName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "lastName" );

            //To get the course name
            Optional<String> courseName = ReportDataCollection.readingSkillAssignmentDetails.values().stream().filter( entry -> Objects.nonNull( entry.get( studentId.get() ) ) ).map(
                    entry -> SMUtils.getKeyValueFromResponse( entry.get( studentId.get() ), "courseDetail,name" ) ).findFirst();

            //To get the exported data for respective student
            List<Map<String, String>> exportedDataFromUI = readingSkillDefaultExportedCSVSplitted.stream().filter(
                    entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect( Collectors.toList() );

            exportedDataFromUI.stream().forEach( entry -> entry.remove( "\"Report Run\"" ) );

            List<Map<String, String>> exportedDataFromAPI = readingSplittedAPIData.stream().filter( entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect(
                    Collectors.toList() );

            //Comparing both API and UI data
            Log.assertThat( exportedDataFromAPI.stream().allMatch( dataFromAPI -> exportedDataFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "student's mastery details are present in downloaded csv File for Reading- Custom skill assignments",
                    "Student's mastery details are not fetching properly for Reading- Custom skill assignments. Expected -" + exportedDataFromAPI.toString() + ".Actual -" + exportedDataFromUI.toString() );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Math - Custom by standard assignment." )
    public void tcAdminMasteryExportCsv018() throws Exception {
        Log.testCaseInfo( "tcAdminMasteryExportCsv018 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Math - Custom by standard assignment." + browser + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc019 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Math - Custom by standard assignment." );

            //To get the IP Cleared Student ID
            Optional<String> studentId = ReportDataCollection.mathStandardAssignmentDetails.values().stream().map(
                    entry -> entry.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( entry.get( student ), "ipStatus" ).equalsIgnoreCase( "INACTIVE" ) ).findFirst().orElse( null ) ).filter(
                            studentID -> Objects.nonNull( studentID ) ).findFirst();

            //To get the student details
            String studentDetail = new RBSUtils().getUser( studentId.get() );
            String studentName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "lastName" );

            //To get the course name
            Optional<String> courseName = ReportDataCollection.mathStandardAssignmentDetails.values().stream().filter( entry -> Objects.nonNull( entry.get( studentId.get() ) ) ).map(
                    entry -> SMUtils.getKeyValueFromResponse( entry.get( studentId.get() ), "courseDetail,name" ) ).findFirst();

            //To get the exported data for respective student
            List<Map<String, String>> exportedDataFromUI = mathSkillDefaultExportedCSVSplitted.stream().filter(
                    entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect( Collectors.toList() );

            exportedDataFromUI.stream().forEach( entry -> entry.remove( "\"Report Run\"" ) );

            List<Map<String, String>> exportedDataFromAPI = mathSplittedAPIData.stream().filter( entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect(
                    Collectors.toList() );

            //Comparing both API and UI data
            Log.assertThat( exportedDataFromAPI.stream().allMatch( dataFromAPI -> exportedDataFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "student's mastery details are present in downloaded csv File for Math- Custom standard assignments",
                    "Student's mastery details are not fetching properly for Math- Custom standard assignments. Expected -" + exportedDataFromAPI.toString() + ".Actual -" + exportedDataFromUI.toString() );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Reading - Custom by standard assignment" )
    public void tcAdminMasteryExportCsv019() throws Exception {
        Log.testCaseInfo( "tcAdminMasteryExportCsv019 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Reading - Custom by standard assignment" + browser + "]</b></i></small>" );

        try {
            SMUtils.logDescriptionTC( "tc020 - (Admin - Mastery - Export Default columns) Verify all the fields in the downloaded CSV file for Reading - Custom by standard assignment" );

            //To get the IP Cleared Student ID
            Optional<String> studentId = ReportDataCollection.readingStandardAssignmentDetails.values().stream().map(
                    entry -> entry.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( entry.get( student ), "ipStatus" ).equalsIgnoreCase( "INACTIVE" ) ).findFirst().orElse( null ) ).filter(
                            studentID -> Objects.nonNull( studentID ) ).findFirst();

            //To get the student details
            String studentDetail = new RBSUtils().getUser( studentId.get() );
            String studentName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "lastName" );

            //To get the course name
            Optional<String> courseName = ReportDataCollection.readingStandardAssignmentDetails.values().stream().filter( entry -> Objects.nonNull( entry.get( studentId.get() ) ) ).map(
                    entry -> SMUtils.getKeyValueFromResponse( entry.get( studentId.get() ), "courseDetail,name" ) ).findFirst();

            //To get the exported data for respective student
            List<Map<String, String>> exportedDataFromUI = readingSkillDefaultExportedCSVSplitted.stream().filter(
                    entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect( Collectors.toList() );

            exportedDataFromUI.stream().forEach( entry -> entry.remove( "\"Report Run\"" ) );

            List<Map<String, String>> exportedDataFromAPI = readingSplittedAPIData.stream().filter( entry -> entry.get( "\"Student Name\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"Course Name\"" ).equalsIgnoreCase( courseName.get() ) ).collect(
                    Collectors.toList() );

            //Comparing both API and UI data
            Log.assertThat( exportedDataFromAPI.stream().allMatch( dataFromAPI -> exportedDataFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "student's mastery details are present in downloaded csv File for Reading- Custom standard assignments",
                    "Student's mastery details are not fetching properly for Reading- Custom standard assignments. Expected -" + exportedDataFromAPI.toString() + ".Actual -" + exportedDataFromUI.toString() );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export selected columns) Verify the downloaded CSV file headers (column name) , for Export Selected columns - Math Subject and skill/standard SuccessMaker Mastery Skills - Math" )
    public void tcAdminMasteryExportCsv020() throws Exception {

        Log.testCaseInfo( "tcAdminMasteryExportCsv020 - (Admin - Mastery - Export selected columns) Verify the downloaded CSV file headers (column name) , for Export Selected columns - Math Subject and skill/standard SuccessMaker Mastery Skills - Math"
                + browser + "]</b></i></small>" );

        try {

            SMUtils.logDescriptionTC( "tc021 - (Admin - Mastery - Export selected columns) Verify the downloaded CSV file headers (column name) , for Export Selected columns - Math Subject and skill/standard SuccessMaker Mastery Skills - Math" );
            WebDriver driver = WebDriverFactory.get( browser );

            String customExportedCsv = getCSVDataFromUI( driver, schoolName, "Math", "", true, MasteryExportCSVConstants.CUSTOM_FILTERS );

            List<String> headersFromExportedCSV = ExportCsvUtils.getCSVHeadersFromResponse( customExportedCsv );
            Log.assertThat( headersFromExportedCSV.containsAll( MasteryExportCSVConstants.CUSTOM_HEADERS ), "All column headers are fetched properly for Math -Skill Custom Export",
                    "All column headers are not fetched properly for Math - Skill.Expected - " + MasteryExportCSVConstants.CUSTOM_HEADERS + ".Actual - " + headersFromExportedCSV );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc022 - (Admin - Mastery - Export selected columns) Verify the downloaded CSV file if we pass the all column names in selected columns" );
            SMUtils.logDescriptionTC( "tc023 - (Admin - Mastery - Export selected columns) Verify the Assigned course level,Current course level and IP level the fields in the downloaded CSV file for math assignment" );

            //To get the csv data from api response
            Response mathCustomExportcsvResponseFromAPI = new AdminReportCsv().postMasteryExportCSVAPI( headers, orgId, ExportCsvConstants.CUSTOM, mathCustomExportRequestId, "", 1, MasteryExportCSVConstants.CUSTOM_SELECTED_FILTERS );
            List<Map<String, String>> mathCustomSplittedAPIData = ExportCsvUtils.splitCSVData( mathCustomExportcsvResponseFromAPI.getBody().asString() );

            //To get the IP Cleared Student ID
            Optional<String> studentId = ReportDataCollection.defaultMathAssignmentDetails.values().stream().map(
                    entry -> entry.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( entry.get( student ), "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ).findFirst().orElse( null ) ).filter(
                            studentID -> Objects.nonNull( studentID ) ).findFirst();

            //To get the student details
            String studentDetail = new RBSUtils().getUser( studentId.get() );
            String studentName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "lastName" );

            //To get the course name
            Optional<String> courseName = ReportDataCollection.defaultMathAssignmentDetails.values().stream().filter( entry -> Objects.nonNull( entry.get( studentId.get() ) ) ).map(
                    entry -> SMUtils.getKeyValueFromResponse( entry.get( studentId.get() ), "courseDetail,name" ) ).findFirst();

            //To get the exported data for respective student
            List<Map<String, String>> exportedCSvFromUI = ExportCsvUtils.splitCSVData( customExportedCsv );
            List<Map<String, String>> exportedDataFromUI = exportedCSvFromUI.stream().filter( entry -> entry.get( "\"studentName\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"courseName\"" ).equalsIgnoreCase( courseName.get() ) ).collect(
                    Collectors.toList() );

            exportedDataFromUI.stream().forEach( entry -> entry.remove( "\"reportRun\"" ) );

            List<Map<String, String>> exportedDataFromAPI = mathCustomSplittedAPIData.stream().filter( entry -> entry.get( "\"studentName\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"courseName\"" ).equalsIgnoreCase( courseName.get() ) ).collect(
                    Collectors.toList() );

            //Comparing both API and UI data
            Log.assertThat( exportedDataFromAPI.stream().allMatch( dataFromAPI -> exportedDataFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "All the student's mastery details are present in downloaded csv File for math assignments (Custom Export)",
                    "Student's mastery details are not fetching properly for math assignments(Custom Export). Expected -" + exportedDataFromAPI.toString() + ".Actual -" + exportedDataFromUI.toString() );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export selected columns) Verify the downloaded CSV file headers (column name) , for Export Selected columns - Math Subject and skill/standard - aimswebPlus" )
    public void tcAdminMasteryExportCsv021() throws Exception {

        Log.testCaseInfo( "tcAdminMasteryExportCsv021 - (Admin - Mastery - Export selected columns) Verify the downloaded CSV file headers (column name) , for Export Selected columns - Math Subject and skill/standard SuccessMaker Mastery Skills - Math"
                + browser + "]</b></i></small>" );

        try {

            SMUtils.logDescriptionTC( "tc024 - (Admin - Mastery - Export selected columns) Verify the downloaded CSV file headers (column name) , for Export Selected columns - Math Subject and skill/standard - aimswebPlus" );
            WebDriver driver = WebDriverFactory.get( browser );

            String customExportedCsv = getCSVDataFromUI( driver, schoolName, "Math", mathStandardName, true, MasteryExportCSVConstants.CUSTOM_FILTERS );

            List<String> headersFromExportedCSV = ExportCsvUtils.getCSVHeadersFromResponse( customExportedCsv );
            Log.assertThat( headersFromExportedCSV.containsAll( MasteryExportCSVConstants.CUSTOM_HEADERS ), "All column headers are fetched properly for Math -Standard Custom Export",
                    "All column headers are not fetched properly for Math - Standard.Expected - " + MasteryExportCSVConstants.CUSTOM_HEADERS + ".Actual - " + headersFromExportedCSV );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export Selected columns) Verify the downloaded CSV file headers (column name) , for Export Selected columns - Reading Subject and skill/standard SuccessMaker Mastery Skills - reading" )
    public void tcAdminMasteryExportCsv022() throws Exception {

        Log.testCaseInfo(
                "tcAdminMasteryExportCsv022 - (Admin - Mastery - Export Selected columns) Verify the downloaded CSV file headers (column name) , for Export Selected columns - Reading Subject and skill/standard SuccessMaker Mastery Skills - reading"
                        + browser + "]</b></i></small>" );

        try {

            SMUtils.logDescriptionTC( "tc025 - (Admin - Mastery - Export Selected columns) Verify the downloaded CSV file headers (column name) , for Export Selected columns - Reading Subject and skill/standard SuccessMaker Mastery Skills - reading" );
            WebDriver driver = WebDriverFactory.get( browser );

            String customExportedCsv = getCSVDataFromUI( driver, schoolName, "Reading", "", true, MasteryExportCSVConstants.CUSTOM_FILTERS );

            List<String> headersFromExportedCSV = ExportCsvUtils.getCSVHeadersFromResponse( customExportedCsv );
            Log.assertThat( headersFromExportedCSV.containsAll( MasteryExportCSVConstants.CUSTOM_HEADERS ), "All column headers are fetched properly for reading -skill Custom Export",
                    "All column headers are not fetched properly for Reading - Skill Custom Export.Expected - " + MasteryExportCSVConstants.CUSTOM_HEADERS + ".Actual - " + headersFromExportedCSV );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "tc026 - (Admin - Mastery - Export selected columns) Verify Assigned course level,Current course level and IP level the fields in the downloaded CSV file for reading assignment" );

            //To get the csv data from api response
            Response readingCustomExportcsvResponseFromAPI = new AdminReportCsv().postMasteryExportCSVAPI( headers, orgId, ExportCsvConstants.CUSTOM, readingCustomExportRequestId, "", 2, MasteryExportCSVConstants.CUSTOM_SELECTED_FILTERS );
            List<Map<String, String>> readingCustomSplittedAPIData = ExportCsvUtils.splitCSVData( readingCustomExportcsvResponseFromAPI.getBody().asString() );

            //To get the IP Cleared Student ID
            Optional<String> studentId = ReportDataCollection.defaultReadingAssignmentDetails.values().stream().map(
                    entry -> entry.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( entry.get( student ), "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ).findFirst().orElse( null ) ).filter(
                            studentID -> Objects.nonNull( studentID ) ).findFirst();

            //To get the student details
            String studentDetail = new RBSUtils().getUser( studentId.get() );
            String studentName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "lastName" );

            //To get the course name
            Optional<String> courseName = ReportDataCollection.defaultReadingAssignmentDetails.values().stream().filter( entry -> Objects.nonNull( entry.get( studentId.get() ) ) ).map(
                    entry -> SMUtils.getKeyValueFromResponse( entry.get( studentId.get() ), "courseDetail,name" ) ).findFirst();

            //To get the exported data for respective student
            List<Map<String, String>> exportedCSvFromUI = ExportCsvUtils.splitCSVData( customExportedCsv );
            List<Map<String, String>> exportedDataFromUI = exportedCSvFromUI.stream().filter( entry -> entry.get( "\"studentName\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"courseName\"" ).equalsIgnoreCase( courseName.get() ) ).collect(
                    Collectors.toList() );

            exportedDataFromUI.stream().forEach( entry -> entry.remove( "\"reportRun\"" ) );

            List<Map<String, String>> exportedDataFromAPI = readingCustomSplittedAPIData.stream().filter(
                    entry -> entry.get( "\"studentName\"" ).equalsIgnoreCase( studentName ) && entry.get( "\"courseName\"" ).equalsIgnoreCase( courseName.get() ) ).collect( Collectors.toList() );

            //Comparing both API and UI data
            Log.assertThat( exportedDataFromAPI.stream().allMatch( dataFromAPI -> exportedDataFromUI.stream().anyMatch( dataFromUI -> SMUtils.compareTwoHashMap( dataFromUI, dataFromAPI ) ) ),
                    "All the student's mastery details are present in downloaded csv File for reading assignments (Custom Export)",
                    "Student's mastery details are not fetching properly for reading assignments(Custom Export). Expected -" + exportedDataFromAPI.toString() + ".Actual -" + exportedDataFromUI.toString() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export selected columns) Verify the downloaded CSV file headers (column name) , for Export Selected columns - Reading Subject and skill/standard - any one standard" )
    public void tcAdminMasteryExportCsv023() throws Exception {

        Log.testCaseInfo( "tcAdminMasteryExportCsv023 - (Admin - Mastery - Export selected columns) Verify the downloaded CSV file headers (column name) , for Export Selected columns - Reading Subject and skill/standard - any one standard" + browser
                + "]</b></i></small>" );

        try {

            SMUtils.logDescriptionTC( "tc027 - (Admin - Mastery - Export selected columns) Verify the downloaded CSV file headers (column name) , for Export Selected columns - Reading Subject and skill/standard - any one standard" );
            WebDriver driver = WebDriverFactory.get( browser );

            String customExportedCsv = getCSVDataFromUI( driver, schoolName, "Reading", "", true, MasteryExportCSVConstants.CUSTOM_FILTERS );

            List<String> headersFromExportedCSV = ExportCsvUtils.getCSVHeadersFromResponse( customExportedCsv );
            Log.assertThat( headersFromExportedCSV.containsAll( MasteryExportCSVConstants.CUSTOM_HEADERS ), "All column headers are fetched properly for reading - standard Custom Export",
                    "All column headers are not fetched properly for Reading - standard Custom Export.Expected - " + MasteryExportCSVConstants.CUSTOM_HEADERS + ".Actual - " + headersFromExportedCSV );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export selected columns) Verify the downloaded CSV file if we pass the single column name(assignedCourseLevel) in selected columns" )
    public void tcAdminMasteryExportCsv028() throws Exception {

        Log.testCaseInfo( "tcAdminMasteryExportCsv024 - (Admin - Mastery - Export selected columns) Verify the downloaded CSV file if we pass the single column name(assignedCourseLevel) in selected columns" + browser + "]</b></i></small>" );

        try {

            SMUtils.logDescriptionTC( "tc028 - (Admin - Mastery - Export selected columns) Verify the downloaded CSV file if we pass the single column name(assignedCourseLevel) in selected columns" );
            WebDriver driver = WebDriverFactory.get( browser );

            String customExportedCsv = getCSVDataFromUI( driver, schoolName, "Reading", "", true, Arrays.asList( MasteryExportCSVConstants.CUSTOM_FILTERS.get( 1 ) ) );

            List<String> headersFromExportedCSV = ExportCsvUtils.getCSVHeadersFromResponse( customExportedCsv );
            Log.assertThat( headersFromExportedCSV.containsAll( Arrays.asList( MasteryExportCSVConstants.CUSTOM_HEADERS.get( 1 ) ) ), "column headers are fetched properly while pass the single selected filter",
                    "column headers are not fetched properly while pass the single selected filter.Expected - " + MasteryExportCSVConstants.CUSTOM_HEADERS.get( 1 ) + ".Actual - " + headersFromExportedCSV );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( enabled = true, groups = { "SMK-66121", "SMK-69618", "Mastery - Export csv",
            "smoke_test_case" }, description = "(Admin - Mastery - Export selected columns) Verify the downloaded CSV file if we pass the multiple column names in selected columns" )
    public void tcAdminMasteryExportCsv029() throws Exception {

        Log.testCaseInfo( "tcAdminMasteryExportCsv025 - (Admin - Mastery - Export selected columns) Verify the downloaded CSV file if we pass the multiple column names in selected columns" + browser + "]</b></i></small>" );

        try {

            SMUtils.logDescriptionTC( "tc029 - (Admin - Mastery - Export selected columns) Verify the downloaded CSV file if we pass the multiple column names in selected columns" );
            WebDriver driver = WebDriverFactory.get( browser );

            List<String> selectedFilters = Arrays.asList( MasteryExportCSVConstants.CUSTOM_FILTERS.get( 1 ), MasteryExportCSVConstants.CUSTOM_FILTERS.get( 2 ), MasteryExportCSVConstants.CUSTOM_FILTERS.get( 3 ) );
            List<String> expectedHeaders = Arrays.asList( MasteryExportCSVConstants.CUSTOM_HEADERS.get( 1 ), MasteryExportCSVConstants.CUSTOM_HEADERS.get( 2 ), MasteryExportCSVConstants.CUSTOM_HEADERS.get( 3 ) );

            String customExportedCsv = getCSVDataFromUI( driver, schoolName, "Reading", "", true, selectedFilters );

            List<String> headersFromExportedCSV = ExportCsvUtils.getCSVHeadersFromResponse( customExportedCsv );
            Log.assertThat( headersFromExportedCSV.containsAll( expectedHeaders ), "column headers are fetched properly while pass the multiple selected filter",
                    "column headers are not fetched properly while pass the multiple selected filter.Expected - " + expectedHeaders + ".Actual - " + headersFromExportedCSV );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    /**
     * To get the Exported CSV from UI
     * 
     * @param driver
     * @param organizationName
     * @param subject
     * @param strandardName
     * @param isCustom
     * @param selectedFilter
     * @return
     * @throws Exception
     */
    private String getCSVDataFromUI( WebDriver driver, String organizationName, String subject, String strandardName, boolean isCustom, List<String> selectedFilter ) throws Exception {

        String csvDataFromBS = null;
        try {
            //Login as a district admin in Mastery MFE
            LoginWrapper.loginToMasteryMfe( driver, masteryAdminSingleMfeUrl, districtAdminUsername, password );
            MasteryMfePage masteryMfePage = new MasteryMfePage( driver ).get();

            MasteryFiltersComponent masteryFilterComponent = masteryMfePage.getMasteryFilterComponent();

            //To select the organization
            masteryFilterComponent.selectOrganization( organizationName );

            //To select the subject
            masteryFilterComponent.selectSubject( subject );
            if ( !strandardName.isBlank() ) {
                masteryFilterComponent.selectSkillStandards( strandardName );
            }

            //To Click the apply filter button
            masteryFilterComponent.applyFilter();

            //To click the run report button
            MasteryReportOutputPage masteryReportOutput = masteryFilterComponent.clickRunReport();

            if ( isCustom ) {
                if ( subject.equalsIgnoreCase( Constants.MATH ) ) {
                    mathCustomExportRequestId = driver.getCurrentUrl().split( "=" )[1];
                } else {
                    readingCustomExportRequestId = driver.getCurrentUrl().split( "=" )[1];
                }
            } else {
                if ( subject.equalsIgnoreCase( Constants.MATH ) ) {
                    mathDefaultExportRequestId = driver.getCurrentUrl().split( "=" )[1];
                } else {
                    readingDefaultExportRequestId = driver.getCurrentUrl().split( "=" )[1];
                }
            }

            //To click the csv icon 
            ExportPopupComponent exportPopup = masteryReportOutput.clickExportCSVButton();

            if ( isCustom ) {
                //To click the custom ecport radio button
                exportPopup.clickCustomizeExportRadioButton();

                //To select the filters
                exportPopup.selectAvailableColumns( selectedFilter );

                exportPopup.clickChevronRightButton();
            }

            //To click the ok button
            exportPopup.clickOkButton();

            //to get the downloaded file
            csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            driver.quit();
        }

        if ( Objects.isNull( csvDataFromBS ) ) {
            Log.message( "Getting issue while download the file!!!!" );
        }
        return csvDataFromBS;

    }

    /**
     * To Launch the signedURl anf get the CSv file
     * 
     * @param signedUrl
     * @return
     */
    public String getCSVFileFromSignedUrl( String signedUrl ) {
        //To get the CSV File
        String csvDataFromBS = null;
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        try {
            driver.get( signedUrl );
            csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

        } catch ( Exception e ) {
            Log.message( "Getting Exception while download the csv file!!!!!" );
        } finally {
            driver.quit();
        }
        return csvDataFromBS;
    }
}
