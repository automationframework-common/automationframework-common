package com.savvas.sm.ui.tests.mastery;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.google.common.collect.Ordering;
import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.ui.mastery.pages.DevToolsUtils;
import com.savvas.sm.ui.mastery.pages.MasteryFiltersComponent;
import com.savvas.sm.ui.mastery.pages.MasteryMfePage;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sql.helper.SqlHelperMastery;
import com.savvas.sm.utils.sql.helper.StandardVersionTable;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MasteryMfeFiltersTest extends BaseTest {
	private String masteryTeacherMfe;
	private String browser;
	private String configGraphQL ="https://sm-mastery-bff-srv-stack-dev.smdemo.info/graphql";//endpoint

	@BeforeClass(alwaysRun = true)
	public void initTest(ITestContext context) {
		masteryTeacherMfe = configProperty.getProperty("MasteryTeacherMfe");
		browser = configProperty.getProperty("BrowserPlatformToRun");
	}

	@Test(priority = 1, groups = { "SMK-51600", "mastery_mfe", "P1", "UI", "mock" })
	public void tcMasteryMfeGroups(ITestContext context) throws Exception {

		DevTools tools = null;
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo("Mastery Groups dropdown Test" + "<small><b><i>[" + browser + "]</b></i></small>");
		try {

			// TC_1
			SMUtils.logDescriptionTC("1. Verify whether group names are sorted in alphebetical order");
			// login to Mastery mfe as Teacher
			LoginWrapper.loginToMasteryMfe(driver, masteryTeacherMfe, MasteryDataSetup.teacherUserName, "testing123$");
			MasteryMfePage masteryMfePage = new MasteryMfePage(driver).get();
			MasteryFiltersComponent masteryFilterComponent = masteryMfePage.getMasteryFilterComponent();
			
			if (DevToolsUtils.isMock(context)){
	            String json = DevToolsUtils.readJsonResponse("TeacherFilterGroupsAndStudents.json");
	            tools = RequestMockUtils.setResponse(driver, configGraphQL, "GroupsAndStudents", "post", json);
	            tools.createSessionIfThereIsNotOne();
	            Log.message(tools.getCdpSession().toString());
	            driver.navigate().refresh();
	            masteryFilterComponent.waitForFilterButtonPresent();
	            SMUtils.nap(5);
				}

			
			// expand groups dropdown
			masteryFilterComponent.setDropDownMS(Constants.MasteryUI.GROUPS);
			masteryFilterComponent.expandDropDownMS();

			// verify group names are sorted in order
			List<String> groupNamesInDisplayedOrder = masteryFilterComponent.getGroupsList(20);
			Log.softAssertThat(Ordering.<String>natural().isOrdered(groupNamesInDisplayedOrder),
					"Group names are sorted", "Group names are not sorted");

			// TC_2
			SMUtils.logDescriptionTC("2. Verify whether student names are sorted in alphebetical order");

			// expand students dropdown
			masteryFilterComponent.setDropDownMS(Constants.MasteryUI.STUDENTS);
			masteryFilterComponent.expandDropDownMS();

			// verify group names are sorted in order
			List<String> studentNamesInDisplayedOrder = masteryFilterComponent.getStudentsList(20);
			Log.softAssertThat(Ordering.<String>natural().isOrdered(studentNamesInDisplayedOrder),
					"Student names are sorted", "Student names are not sorted");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			if (tools != null) {
				   RequestMockUtils.closeMock(tools);
				}
			driver.quit();
		}
	}

	@Test(priority = 2, groups = { "SMK-51602", "mastery_mfe", "P1", "UI" })
	public void tcMasteryMfeStandards() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo("Mastery Groups dropdown Test" + "<small><b><i>[" + browser + "]</b></i></small>");
		try {

			// login to Mastery mfe as Teacher
			LoginWrapper.loginToMasteryMfe(driver, masteryTeacherMfe, MasteryDataSetup.teacherUserName, "testing123$");
			MasteryMfePage masteryMfePage = new MasteryMfePage(driver).get();
			MasteryFiltersComponent masteryFilterComponent = masteryMfePage.getMasteryFilterComponent();

			// TC_1
			SMUtils.logDescriptionTC("1. Verify the Math-skills/standards dropdown values are equal with DB values");
			masteryFilterComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);
			/// Get Skills/Standards name from DB data - Math
			List<StandardVersionTable.StandardVersionMastery> listStandardVersionDBMath = SqlHelperMastery
					.getStandards(Constants.MasteryUI.SUBJECT_MATH);
			List<String> skillStandardsAvailableDBMath = new ArrayList<String>();
			skillStandardsAvailableDBMath.add(Constants.MasteryUI.SKILL_MATH);
			for (StandardVersionTable.StandardVersionMastery standardVersionMastery : listStandardVersionDBMath) {
				skillStandardsAvailableDBMath.add(standardVersionMastery.getStandardsName());
			}
			skillStandardsAvailableDBMath = skillStandardsAvailableDBMath.stream().map(String::toLowerCase)
					.collect(Collectors.toList());

			Log.assertThat(
					masteryFilterComponent.getAllSkillStandardsDropDownValues().stream().map(String::toLowerCase)
					.collect(Collectors.toList())
					.containsAll(skillStandardsAvailableDBMath.stream().map(String::toLowerCase)
							.collect(Collectors.toList())),
					"All skills are present in Skills/Standards dropdown",
					"All skills are not present in Skills/Standards dropdown");

			// TC_2
			SMUtils.logDescriptionTC("1. Verify the Reading-skills/standards dropdown values are equal with DB values");
			// select Reading as subject
			masteryFilterComponent.selectSubject(Constants.MasteryUI.SUBJECT_READING);
			/// Get Skills/Standards name from DB data - Math
			List<StandardVersionTable.StandardVersionMastery> listStandardVersionDBReading = SqlHelperMastery
					.getStandards(Constants.MasteryUI.SUBJECT_READING);
			List<String> skillStandardsAvailableDBReading = new ArrayList<String>();
			skillStandardsAvailableDBReading.add(Constants.MasteryUI.SKILL_READING);
			for (StandardVersionTable.StandardVersionMastery standardVersionMastery : listStandardVersionDBReading) {
				skillStandardsAvailableDBReading.add(standardVersionMastery.getStandardsName());
			}
			int skillStandardsAvailableDBReadingCount = skillStandardsAvailableDBReading.size();
			int standards = masteryFilterComponent.getAllSkillStandardsDropDownValues().size();
			Log.assertThat(
					standards == skillStandardsAvailableDBReadingCount,
					"All skills are present in Skills/Standards dropdown",
					"All skills are not present in Skills/Standards dropdown");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(priority = 3, groups = { "SMK-51601", "mastery_mfe", "P1", "UI", "mock" })
	public void tcMasteryMfeAssignment(ITestContext context) throws Exception {

		DevTools tools = null;
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo("Mastery Assignment dropdown Test" + "<small><b><i>[" + browser + "]</b></i></small>");
		try {

			// TC_1
			SMUtils.logDescriptionTC(
					"1. Verify the teacher is able to view assignments in the Assignments dropdown(Mastery Page)");
			// login to Mastery mfe as Teacher
			LoginWrapper.loginToMasteryMfe(driver, masteryTeacherMfe, MasteryDataSetup.teacherUserName, "testing123$");
			MasteryMfePage masteryMfePage = new MasteryMfePage(driver).get();
			SMUtils.waitForPageLoad(driver);
			if (DevToolsUtils.isMock(context)) {
            String json = DevToolsUtils.readJsonResponse("TeacherFilterAssignments.json");
            tools = RequestMockUtils.setResponse(driver, configGraphQL, "Assignments", "post", json);
            tools.createSessionIfThereIsNotOne();
            Log.message(tools.getCdpSession().toString());
			}
			MasteryFiltersComponent masteryFilterComponent = masteryMfePage.getMasteryFilterComponent();
			masteryFilterComponent.resetFilter();
			SMUtils.nap(5);
			
			
			// Selecting the dropdown and Assert
			Log.assertThat(masteryFilterComponent.isAssignmentDropdownPresent(),
					"Teacher is able to view the Assignment Drop Down",
					"Teacher is not able to view the Assignment Drop Down");

			SMUtils.logDescriptionTC(
					"2. Verify the teacher is able to select a assignment in the Assignments dropdown(Mastery Page)");
			if (!DevToolsUtils.isMock(context)){
				masteryFilterComponent.resetFilter();
			}
			
			// Selecting the Single Student
			masteryFilterComponent.waitForFilterButtonPresent();
			masteryFilterComponent.setDropDownMS(Constants.MasteryUI.ASSIGNMENTS);
			masteryFilterComponent.selectAssignments(1);
			String selectedAssignmentCount = masteryFilterComponent.getAssignmentListSelectedCount(20).toString();
			Log.assertThat(selectedAssignmentCount.equalsIgnoreCase("1"),
					" The Teacher is able to select the single assignment from the drop down",
					" Teacher is not able to select the single select assignment from the drop down");

			SMUtils.logDescriptionTC(
					"4. Verify the teacher is able to select all assignments by clicking SELECT ALL checkbox in the Assignments dropdown(Mastery Page)");

			if (DevToolsUtils.isMock(context)){
				masteryFilterComponent.selectAssignments(1);		
			}else {
			masteryFilterComponent.resetFilter();
			// Selecting the Select All DropDown
			masteryFilterComponent.waitForFilterButtonPresent();
			masteryFilterComponent.setDropDownMS(Constants.MasteryUI.ASSIGNMENTS);
			}
			masteryFilterComponent.unCheckSelectAllDropdownMS();
			masteryFilterComponent.setDropDownMS(Constants.MasteryUI.ASSIGNMENTS);
			masteryFilterComponent.checkSelectAllDropdownMS();
			masteryFilterComponent.setDropDownMS(Constants.MasteryUI.ASSIGNMENTS);
			Log.assertThat(masteryFilterComponent.getPopulatedNameforAssignmentDropDownMS().startsWith("All Assignments"),
					"The teacher is able to select all assignments by clicking SELECT ALL checkbox in the assginment dropdown",
					"The teacher is unable to select all assignments by clicking SELECT ALL checkbox in the students dropdown");

			SMUtils.logDescriptionTC(
					"5. Verify the All Assignments are selected as default in the Assignments dropdown(Mastery Page)");
			if (!DevToolsUtils.isMock(context)){
			masteryFilterComponent.resetFilter();
			masteryFilterComponent.waitForFilterButtonPresent();
			masteryFilterComponent.setDropDownMS(Constants.MasteryUI.ASSIGNMENTS);
			}
			String selectedAssignmentValueForDefault = masteryFilterComponent.getDropDownMSSelectedValue();

			// Assert the All Assignments are Selected as Default
			Log.assertThat(selectedAssignmentValueForDefault.startsWith("All Assignments"),
					"All assignments are selected as default in the assignments dropdown",
					"All assignments are not selected as default in the assignments dropdown");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			if (tools != null) {
				   RequestMockUtils.closeMock(tools);
				}
			driver.quit();
		}

	}

	@Test(priority = 4, groups = { "SMK-51601", "mastery_mfe", "P1", "UI", "mock" })
	public void tcMasteryMfeAssignment001(ITestContext context) throws Exception {

		DevTools tools = null;
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo("Mastery Assignment dropdown Test" + "<small><b><i>[" + browser + "]</b></i></small>");
		try {

			SMUtils.logDescriptionTC(
					"3. Verify the teacher is able to select multiple assignments in the Assignments dropdown(Mastery Page)");
			LoginWrapper.loginToMasteryMfe(driver, masteryTeacherMfe, MasteryDataSetup.teacherUserName, "testing123$");
			MasteryMfePage masteryMfePage = new MasteryMfePage(driver).get();
			SMUtils.waitForPageLoad(driver);
			MasteryFiltersComponent masteryFilterComponent = masteryMfePage.getMasteryFilterComponent();
			masteryFilterComponent.resetFilter();
			
			if (DevToolsUtils.isMock(context)) {
            String json = DevToolsUtils.readJsonResponse("TeacherFilterAssignments.json");
            tools = RequestMockUtils.setResponse(driver, configGraphQL, "Assignments", "post", json);
            tools.createSessionIfThereIsNotOne();
            Log.message(tools.getCdpSession().toString());
			}
            
			// Getting the Values From the Assignment DropDown
            masteryFilterComponent.resetFilter();
            SMUtils.nap(5);
			masteryFilterComponent.waitForFilterButtonPresent();
			masteryFilterComponent.setDropDownMS(Constants.MasteryUI.ASSIGNMENTS);
			Integer totalAvailableAssignments = masteryFilterComponent.selectAssignments(20);


			Integer getSelectedCount = masteryFilterComponent.getAssignmentListSelectedCount(20);

			// Assertment for the Multiple Select
			Log.assertThat(getSelectedCount.equals(totalAvailableAssignments), " Teacher is able to do the multiple Select ",
					"Teacher is not able to do the multiple select");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			if (tools != null) {
				   RequestMockUtils.closeMock(tools);
				}
			driver.quit();
		}
	}	
}