package com.savvas.sm.ui.mastery.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.SMUtils;

public class MasteryMfePage extends LoadableComponent<MasteryMfePage> {
    private final WebDriver driver;
    boolean isPageLoaded;

    MasteryFiltersComponent masteryFilterComponent;
    MasterySummaryComponent masterySummaryComponent;

    @FindBy ( css = ".header-title" )
    WebElement lblMasteryHeading;

    @FindBy ( css = "h2.filter-header" )
    WebElement lblStep1Heading;

    @FindBy ( css = "mastery-step-two-filters h2" )
    WebElement lblStep2Heading;

    @FindBy ( css = ".contextual-help-icon.hydrated" )
    WebElement masteryHelpIcon;

    @FindBy ( css = "div.run-reports-button cel-button" )
    WebElement masteryRunReportBtnRoot;

    String runReportPrimaryBtn = ".primary_button";

    @FindBy ( css = "cel-error-block.hydrated" )
    WebElement masteryUnAuthorized;

    /**
     *
     * Constructor class for MasteryMfe page and initializing the driver for
     * page factory objects.
     *
     * @param driver
     *
     */
    public MasteryMfePage( WebDriver driver ) {
        this.driver = driver;
        // Have Topbar here and init
        PageFactory.initElements( driver, this );
        masteryFilterComponent = new MasteryFiltersComponent( driver );
    }

    /***
     * return the masteryFilterComponent Object
     *
     * @return
     */
    public MasteryFiltersComponent getMasteryFilterComponent() {
        if ( masteryFilterComponent == null )
            masteryFilterComponent = new MasteryFiltersComponent( driver );
        return masteryFilterComponent;
    }

    @Override
    protected void isLoaded() {
        if ( !isPageLoaded ) {
            Assert.fail();
        }

        if ( SMUtils.fluentWaitForElement( driver, lblMasteryHeading ) ) {
            Log.message( "SM Mastery Mfe page loaded successfully.", driver );
        } else {
            Log.fail( "SM Mastery Mfe page did not load." );
        }
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, lblMasteryHeading );
    }

    /***
     * returns the Heading
     *
     * @return
     */
    public String getMasteryHeading() {
        return lblMasteryHeading.getText();
    }

    /**
     * returns the students and groups filter heading
     *
     * @return
     */
    public String getMasteryStep1Heading() {
        return lblStep1Heading.getText();
    }

    /**
     * returns the unauthorized message in the mastery mFE page
     * 
     * @return
     */
    public String getUnauthorizedMessage() {
        return masteryUnAuthorized.getText();
    }

    /**
     * returns the refine search heading
     *
     * @return
     */
    public String getMasteryStep2Heading() {
        return lblStep2Heading.getText();
    }

    /**
     * Returns the displayed status of Step2 Heading
     * 
     * @return
     */
    public boolean isMasteryStep2HeadingDisplayed() {
        boolean returnParam = false;
        try {
            lblStep2Heading.isDisplayed();
            returnParam = true;
        } catch ( Exception e ) {
            returnParam = false;
        }

        return returnParam;
    }

    /**
     * returns the displayed state of help icon
     * 
     * @return
     */
    public boolean isHelpIconDisplayed() {
        return masteryHelpIcon.isDisplayed();
    }

    /**
     * Verifies the help page loads in a new tab
     * 
     * @param driver
     * @return
     */
    public boolean isHelpPageOpensInNewTab( WebDriver driver ) {
        boolean returnParam = false;
        String parent=driver.getWindowHandle();
        masteryHelpIcon.click();
        SMUtils.nap( 0.2 );
        returnParam = driver.getWindowHandles().size() == 2;

        driver.switchTo().window(parent);
        //SMUtils.switchWindow( driver );
        return returnParam;
    }
}
