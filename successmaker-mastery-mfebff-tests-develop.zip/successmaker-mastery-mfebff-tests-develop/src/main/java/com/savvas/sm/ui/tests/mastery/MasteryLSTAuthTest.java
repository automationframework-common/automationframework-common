package com.savvas.sm.ui.tests.mastery;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.ui.mastery.pages.MasteryMfePage;
import com.savvas.sm.ui.pages.login.EBPlusAndAutoSignInPage;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;

/**
 * This class is used to test whether teacher, single&multiple school customer
 * admin can able to login to mastery mFE without SSO
 * 
 * @author madhan.nagarathinam
 *
 */
public class MasteryLSTAuthTest extends BaseTest {

	private String smUrl;
	private String catUrl;
	private String masteryTeacherMfe;
	private String masterySingleSchoolCustomerAdminMfe;
	private String masteryMultiSchoolCustomerAdminMfe;
	private String browser;

	@BeforeClass
	public void initTest(ITestContext context) {
		smUrl = configProperty.getProperty("SMAppUrl");
		catUrl = configProperty.getProperty("EBAppUrl");
		browser = configProperty.getProperty(ConfigConstants.BROWSER_PLATFORM_TO_RUN );
		masteryTeacherMfe = configProperty.getProperty("MasteryTeacherMfe");
		masterySingleSchoolCustomerAdminMfe = configProperty.getProperty("MasteryAdminSingleMfe");
		masteryMultiSchoolCustomerAdminMfe = configProperty.getProperty("MasteryAdminMultiMfe");
	}

	@Test(priority = 1, groups = { "SMK-51585", "mastery_mfe", "P1", "UI", "Integrate mastery MFE with lst-auth" })
	public void tcMasteryLSTAuthTest01(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get( browser );
		Log.testCaseInfo(
				"TC:01 Verify the user is able to login to teacher's mastery mfe without sso when teacher's session is maintained in the other tab"
						+ "<small><b><i>[" + browser + "]</b></i></small>");

		try {

			new LoginWrapper();
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, "basic", null,
					MasteryDataSetup.teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD);
			SMUtils.openNewTabAndSwitchToNewSMApp(driver, masteryTeacherMfe);
			Log.assertThat(new MasteryMfePage(driver).isMasteryStep2HeadingDisplayed(),
					"Mastery Teacher MFE Page is loaded successfully without SSO",
					"Mastery Teacher MFE Page is not getting loaded successfully!");
//			driver.quit();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(priority = 1, groups = { "SMK-51585", "mastery_mfe", "P1", "UI", "Integrate mastery MFE with lst-auth" })
	public void tcMasteryLSTAuthTest02(ITestContext context) throws Exception {

		// Get driver
		WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo(
				"TC:02 Verify the user is able to login as customer admin mastery mfe without sso when single school customer admin's session is maintained in the other tab "
						+ "<small><b><i>[" + browser + "]</b></i></small>");
		try {

			new LoginWrapper();
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, "basic", null,
					MasteryDataSetup.schoolAdminUserName, RBSDataSetupConstants.DEFAULT_PASSWORD);
			SMUtils.nap(3);
			SMUtils.openNewTabAndSwitchToNewSMApp(driver, masterySingleSchoolCustomerAdminMfe);
			Log.assertThat(
					new MasteryMfePage(driver).getMasteryHeading().equals(MasteryConstants.Labels.MASTERY_HEADING),
					"Mastery Single School Admin MFE Page is loaded successfully without SSO",
					"Mastery Single School Admin MFE Page is not getting loaded successfully!");
			driver.quit();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(priority = 1, groups = { "SMK-51585", "mastery_mfe", "P1", "UI", "Integrate mastery MFE with lst-auth" })
	public void tcMasteryLSTAuthTest03(ITestContext context) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get( browser );
		Log.testCaseInfo(
				"TC:03 Verify the user is able to login to customer admin mutli-school mastery mfe without sso when mutliple school customer admin's session is maintained in the other tab "
						+ "<small><b><i>[" + browser + "]</b></i></small>");
		try {
			new LoginWrapper();
			LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, "basic", null,
					MasteryDataSetup.multiSchoolAdminUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
			SMUtils.nap(3);
			SMUtils.openNewTabAndSwitchToNewSMApp(driver, masteryMultiSchoolCustomerAdminMfe);
			Log.assertThat(new MasteryMfePage(driver).getMasteryHeading().equals(MasteryConstants.Labels.MASTERY_HEADING),
					"Mastery Multi School Admin MFE Page is loaded successfully without SSO",
					"Mastery Multi School Admin MFE Page is not getting loaded successfully!");
			driver.quit();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(priority = 1, groups = { "SMK-51585", "mastery_mfe", "P1", "UI", "Integrate mastery MFE with lst-auth" })
	public void tcMasteryLSTAuthTest04(ITestContext context) throws Exception {

		// Get driver
		WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo(
				"TC:04 Verify the user is able to see the unauthorized message without sso when student's session is maintained in the other tab "
						+ "<small><b><i>[" + browser + "]</b></i></small>");
		try {
			new LoginWrapper();
			LoginWrapper.loginToSuccessMakerAsStudent(driver, smUrl, "basic", null,
					MasteryDataSetup.studentUserName1, RBSDataSetupConstants.DEFAULT_PASSWORD);
			SMUtils.openNewTabAndSwitchToNewSMApp(driver, masteryMultiSchoolCustomerAdminMfe);
			Log.assertThat(
					new MasteryMfePage(driver).getUnauthorizedMessage().equals(
							"Sorry! You are not authorized to access this reporting information, including Mastery."),
					"The unauthorized message is getting displayed when student session is getting maintained in the another tab",
					"The unauthorized message is not getting displayed when student session is getting maintained in the another tab!");
			driver.quit();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(priority = 2, groups = { "SMK-51585", "mastery_mfe", "P2", "UI", "Integrate mastery MFE with lst-auth" })
	public void tcMasteryLSTAuthTest05(ITestContext context) throws Exception {

		// Get driver
		WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo("TC:05, TC:06, TC:07 Verify EBSignInPage is getting displayed when no session is maintained"
				+ "<small><b><i>[" + browser + "]</b></i></small>");
		try {
			// TC:05
			SMUtils.logDescriptionTC(
					"TC:05 Verify the user is not able to login to teacher's mastery mfe without sso when teacher's session is not maintained in the other tab ");
			driver.get(masteryTeacherMfe);
			Log.assertThat(new EBPlusAndAutoSignInPage(driver).isSignInContainerDisplayed(),
					"EBSignInPage is getting displayed", "EBSignInPage is not getting displayed");
			driver.quit();
			Log.testCaseResult();

			// TC:06
			SMUtils.logDescriptionTC(
					"TC;06 Verify the user is not able to login to customer admin mastery mfe without sso when single school customer admin's session is not maintained in the other tab ");
			driver = WebDriverFactory.get(browser);
			driver.get(masterySingleSchoolCustomerAdminMfe);
			Log.assertThat(new EBPlusAndAutoSignInPage(driver).isSignInContainerDisplayed(),
					"EBSignInPage is getting displayed", "EBSignInPage is not getting displayed");
			driver.quit();
			Log.testCaseResult();

			// TC:07
			SMUtils.logDescriptionTC(
					"Verify the user is not able to login to customer admin mutli-school mastery mfe without sso when mutliple school customer admin's session is not maintained in the other tab ");
			driver = WebDriverFactory.get(browser);
			driver.get(masteryMultiSchoolCustomerAdminMfe);
			Log.assertThat(new EBPlusAndAutoSignInPage(driver).isSignInContainerDisplayed(),
					"EBSignInPage is getting displayed", "EBSignInPage is not getting displayed");
			driver.quit();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

}
