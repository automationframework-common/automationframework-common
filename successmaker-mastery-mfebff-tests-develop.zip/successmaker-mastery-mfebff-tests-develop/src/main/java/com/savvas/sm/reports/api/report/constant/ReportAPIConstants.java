package com.savvas.sm.reports.api.report.constant;

public interface ReportAPIConstants {

    String GRAPH_QL_ENDPOINT = "/graphql";
    String GRAPG_QL_BASE_URL = "https://sm-reports-bff-srv-stack-stage.smdemo.info";

    String GRAPH_QL_MASTERY_URL = "https://successmaker-mastery-bff-dev.smdemo.info";
    String GRAPH_QL_AFG_URL = "https://sm-reports-bff-srv-stack-stage.smdemo.info";
    String GRAPH_QL_SRV_URL = "https://sm-reports-bff-srv-stack-stage.smdemo.info";

    String ORGANIZATION_ID = "organizationId";
    String TEACHER_ID = "teacherId";

    String districtId = "district-id";
    String ID = "id";
    String WEEKS = "weeks";
    String GRADE_ID = "gradeId";
    String IS_GROUP_SELECTED = "isGroupSelected";
    boolean IS_GROUP_SELECTED_VALUE = false;
    String RBS = "rbs";
    boolean RBSFLAG = false;
    String COURSE_ID = "1";
    String SUBJECT = "subject";
    String PS = "ps";
    String PBS = "pbs";
    String AOD = "aod";
    String LIMIT = "limit";
    float LIMITS = 100;
    String VALID_LIMIT = "10";
    String INVALID_LIMIT_ZERO = "0";
    String OFFSET = "offset";
    float OFFSETS = 0;
    String VALID_OFFSET = "0";
    String STUDENT_IDS = "studentIds";
    String ISP_QUERY = "ISP_QUERY";
    String LS_QUERY = "LS_QUERY";
    String CP_QUERY = "CP_QUERY";
    String PSR_QUERY = "PSR_QUERY";
    String Mastery_QUERY = "Mastery_QUERY";
    String LOAD_QUERY = "LOAD_QUERY";
    String REPORT_OPTION_QUERY = "REPORT_OPTION_QUERY";
    String ORG_ID = "orgId";
    String USER_ID = "userId";
    String ORG_IDs = "org-id";
    String USER_IDs = "user-id";
    String REQUEST_ID = "requestId";
    String REPORT_TYPE = "reportType";
    String FILTER_NAME = "filterName";
    String USER_TYPE = "userType";
    String REPORT_PARAMETERS = "reportParameters";
    String PERSON_REPORT = "personReport";
    String BACKWARD_SLASH = "\\";
    String DOUBLE_QUOTATION = "\"";
    String BACK_SLASH = "\\\"";

    String TST_ORG_ID = "\\\"8a7200f77de565ac017e248148670654\\\"";
    String TST_TEACHER_ID = "\\\"ffffffff61d41c916e4125002f230e8b\\\"";
    String INVALID_TEACHER_ID = "aaaaaaaaaaaaaaaaaaaaaaa";
    String TST_STUDENT_IDS = "[\\\"ffffffff6268243afeaf2e071c086848\\\"\\n" + "    \\\"ffffffff6273e85049e87c2f26b0092e\\\"\\n" + "    \\\"ffffffff6273e81c49e87c2f26b0092d\\\"\\n" + "    \\\"ffffffff6273e81c49e87c2f26b0092d\\\"\\n"
            + "    \\\"ffffffff6273e85049e87c2f26b0092e\\\"\\n" + "    \\\"ffffffff61d41c646e4125002f23052e\\\"\\n" + "    \\\"ffffffff62671639feaf2e071c086489\\\"]";
    String TST_USERNAME = "zenvo_tc01";
    String TST_REQUEST_ID = "\\\"14a3f022-2e0a-445a-bcdf-c982bb0f5fbb\\\"";
    String TST_REPORT_TYPE = "\\\"LS\\\"";
    String TEACHER = "\\\"teacher\\\"";

    String INVALID = "INVALID";
    String NO_RESPONSE_CODE = "No Response Code";
    String CODE = "code";
    String ERROR = "errors,extensions";
    String STATUS = "response,status";
    String TNS_USESRNAME = "tns:UserName";

    String GROUP_IDS = "\\[\"a5a6ca7beff240bba0b4ca6ec51501f7\"]\\";
    String GROUP_ID_VALUE = "[\\\"a5a6ca7beff240bba0b4ca6ec51501f7\\\"]";
    String ASSIGNMENT_IDS = "\\[\"578\"]\\";
    String ORDERBY_ID = "orderBy";
    String ORDERBY_IDS = "\\[\"PERSON_ID\"]\\";

    String INVALID_GROUP_IDS = "\\\"1111112a5a6ca7beff240bba0b4ca6ec51501f7\\\"";
    String INVALID_SUBJECT_ID = "1234";
    String VALID_SUBJECT_ID = "2";
    float VALID_MATH_SUBJECT_ID = 1;
    float INVALID_SUBJECT_IDs = 1234;
    String LASTSESSION = "lastSession";
    String ASSIGNMENT_ID = "assignmentIds";
    String GROUP_ID = "groupIds";
    String START_DATE = "startDate";
    String END_DATE = "endDate";
    String PASSWORD = "testing123$";
    String INVALID_ORG_ID = "\\\"{org}\\\"";
    String NON_EXISTING_ORG_ID = "\\\"8a72010c7f16531f017f2099da12\\\"";
    int INTERGER_USERNAME = 123;
    String NON_EXISTING_REQUEST_ID = "\\\"14a3f022-2e0a-445a-bcdf\\\"";

    String FILTER_PARAMS = "filterParams";

    String CP_REPORT_ADMIN_FILTER = "{\\n" + "      subject: \\\"Reading\\\"\\n" + "      courseList: []\\n" + "      additionalGrouping: 2\\n" + "      filterBySchool: [\\n" + "        \\\"8a7200f77de565ac017e2485554d0684\\\"\\n"
            + "        \\\"8a7200f77de565ac017e248488fc0658\\\"\\n" + "      ]\\n" + "      filterByDemographics: {\\n" + "        disabilityStatus: [],\\n" + "        englishLanguageProficiency: [],\\n" + "        gender: [],\\n"
            + "        migrantStatus: [],\\n" + "        raceEthnicity: [],\\n" + "        socioeconomicStatus: [],\\n" + "        specialServices: []\\n" + "      }\\n" + "      startDate: \\\"2022-03-29\\\",\\n" + "      endDate: \\\"2022-04-30\\\"\\n"
            + "    }";

    public interface CourseList {
        // CourseType and ID
        String DEFAULT_MATH = "1";
        String DEFAULT_READING = "2";
        String FOCUS_MATH_1 = "3";
        String FOCUS_MATH_2 = "4";
        String FOCUS_MATH_3 = "5";
        String FOCUS_READING_1 = "11";
        public static String TEACHER_ID = "teacherID";
        public static String INVALID_TEACHER_ID = "invalidTeacherID";
        public static String ORG_ID = "orgID";
        public static String STUDENT_RUMBA_IDS = "studentRumbaIds";
        public static String STUDENT_RUMBA_GRADE_IDS = "studentRumbaIds_Grades";
        public static String STATUS = "status";
        public static String GROUP_ID = "groupID";
        public static String TEACHER_ID_ENDPOINT = "teacherIDEndPoint";
        public static String ASSIGNMENT_IDS = "assignementIds";
        public static String COURSE_IDS = "courseIds";
        public static String STUDENT_ID = "studnetID";
        public static String SCHOOL_ADMIN_ID = "schoolAdminId";
        public static String LAST_SESSION = "lastSession";
    }

    public interface TeacherAFG {

        String STAGE_URL = "https://nightly-next-basic.smdemo.info/teacher-reports/report/aodreport";

        String TEACHER_AFG_API_PAYLOAD = "{\r\n" + "    \"students\": [%s],\r\n" + "    \"weeks\": {weeks},\r\n" + "    \"subject\": {subject},\r\n" + "    \"orderBy\" : \"{orderBy}\",\r\n" + "    \"assignmentIds\" : [{assignmentId}]\r\n" + "    \r\n"
                + "}";

        String subject = "{subject}";
        String weeks = "{weeks}";
        String limit = "{limit}";
        String orderBy = "{orderBy}";
        String assignmentId = "{assignmentId}";

    }

    String BOTH = "Both";

    String TST_USERNAME_AFG = "teacher_d11";

    String CP_AR_ADMIN_FILTER = "{\\n" + "      subject: \\\"Reading\\\"\\n" + "      courseList: []\\n" + "      additionalGrouping: 2\\n" + "      filterBySchool: [\\n" + "        \\\"8a72063a81a61c300181c9bafe210092\\\"\\n"
            + "        \\\"8a72063a81a61c300181c9bafe210092\\\"\\n" + "      ]\\n" + "      filterByDemographics: {\\n" + "        disabilityStatus: [],\\n" + "        englishLanguageProficiency: [],\\n" + "        gender: [],\\n"
            + "        migrantStatus: [],\\n" + "        ethnicity: [],\\n" + "        socioeconomicStatus: [],\\n" + "        specialServices: []\\n" + "      }\\n" + "}";
    String TARGET_DATE = "targetDate";
    String PS_QUERY = "PS_QUERY";
    String GRADE = "grade";

    String NO_DATA_FOUND_MESSAGE = "Report details not found";

    public interface ReportAPIConstantsforAFG {
        String REQ_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getAFGAdminReportData(\\n    filterParams: {subject: \\\"%s\\\", courseList: [], additionalGrouping: 1, datesAtRisk: 1024, filterBySchool: [\\\"%s\\\"], filterByTeacher: [{teacherId}], filterByGroup: [], filterByGrade: [], filterByDemographics: {disabilityStatus: [], englishLanguageProficiency: [], gender: [], migrantStatus: [], race: [], ethnicity: [], socioeconomicStatus: [], specialServices: []}}\\n    userId: \\\"%s\\\"\\n    organizationId: \\\"%s\\\"\\n  ) {\\n    reportRun\\n    orgRows {\\n      organizationName\\n      teacherTitle\\n      teacherFirstName\\n      teacherLastName\\n      teacherName\\n      teacherUsername\\n      grade\\n      gradeDisplayOrder\\n      groupName\\n      groupID\\n      assignmentTitle\\n      assignmentID\\n      strandSkillRows {\\n        strandName\\n        strandLevel\\n        catalogNum\\n        objectiveID\\n        loDescription\\n        lessonNumber\\n        lessonTitle\\n        studentRows {\\n          username\\n          studentName\\n          studentFirstName\\n          studentLastName\\n          studentId\\n          personID\\n          failedDate\\n          masteryStatus\\n        }\\n      }\\n    }\\n  }\\n}\\n\"}";
        public static String SCHOOL_ID_VALUE = "{schoolId}";
        public static String USER_ID_VALUE = "{userId}";
        public static String DISTRICT_ID_VALUE = "{districtId}";
        public static String TEACHER_ID_VALUE = "{teacherId}";
        public static String GROUP = "{groupId}";
        public static String GRADE = "{grade}";
        public static String ASSIGNMENTID = "{assignmentId}";
        public static String DISABILITY = "{disabilityStatus}";
        public static String ENGLISH_PROFIENCIENCY = "{language}";
        public static String GENDER = "{gender}";
        public static String MIGRANT_STATUS = "{migrantStatus}";
        public static String RACE = "{race}";
        public static String ETHNICITY = "{ethnicity}";
        public static String SOCIO_ECONOMIC = "{socioStatus}";
        public static String SPECIAL_SERVICES = "{specialServices}";
    }

    public interface SPReport {
        String STUDENT_ID = "studentId";
        String LANGUAGE = "language";
        String SUBJECT = "subject";
        String COURSE_LST = "courseList";
        String INC_PERF_SUM = "includePerformanceSummary";
        String INC_PERF_BY_STRAND = "includePerformanceByStrand";
        String INC_AOD = "includeAreasOfDifficulty";
        String INC_HIST_DATA = "includeRecentHistoryData";
        String FILTER_SCHOOL = "filterBySchool";
        String SP_QUERY = "SP_QUERY";
    }

    public interface PSRConstants {
        public static String PRS_REPORT_REQUEST = "psReportRequestValue";
        public static String PSA_REPORT_REQUEST = "psaReportRequestValue";
        public static String SUBJECT = "subject";
        public static String COURSE_LIST = "courseList";
        public static String TARGET_DATE = "targetDate";
        public static String TARGET_LEVEL_ARRAY = "targetLevelArray";
        public static String ADDITIONAL_GROUPING = "additionalGrouping";
        public static String FILTER_BY_SCHOOL = "filterBySchool";
        public static String FILTER_BY_TEACHER = "filterByTeacher";
        public static String FILTER_BY_GRADE = "filterByGrade";
        public static String FILTER_BY_GROUP = "filterByGroup";
        public static String DEMOGRAPHICS_INPUT = "demographicsInput";
        public static String DISABILLITY_STATUS = "disabilityStatus";
        public static String ENGLISH_LANGUGAGE_PROFICIENCY = "englishLanguageProficiency";
        public static String GENDER = "gender";
        public static String MIGRANT_STATUS = "migrantStatus";
        public static String RACE = "race";
        public static String ETHINICITY = "ethnicity";
        public static String SOCIO_ECONOMIC_STATUS = "socioeconomicStatus";
        public static String SPECIAL_SERVICES = "specialServices";
        public static Object TEACHER_ROWS = "teacherRows";
        public static String TEACHER_NAME = "teacherName";

        String STUDENTS_ROW = "studentRows";
        String ASSIGNMENT_TITLE = "assignmentTitle";
        String REPORT_RUN = "reportRun";
        String STUDENT_USERNAME = "studentUsername";
        String STUDENT_NAME = "studentName";
        String PERSON_ID = "person_id";
        String IPM_STATUS_ID = "ipmStatusId";

        String PERFOMANCE_DATA = "performanceData";
        String PERFORMANCE_MEAN = "mean";
        String PSA_PERFOMANCE_DATA = "psaPerformanceData";
        String CURRENT_COURSE_LEVEL = "currentCourseLevel";
        String CURRENT_COURSE_LEVEL_MEAN = "currentCourseLevelMean";
        String IP_LEVEL = "ipLevel";
        String IP_LEVEL_MEAN = "ipLevelMean";
        String TIME_SINCE_IP = "timeSinceIp";
        String TIME_SINCE_IP_MEAN = "timeSinceIPMean";
        String SKILL_PERCENT_MASTERED = "skillsPercentMastered";
        String PERCENT_STD_WITH_AP = "percentStudentsWithAP";
        String PSA_PRESCRIPTION = "psaPrescription";
        String AVG_ADDTL_MIN_DAY_TO_TARGET = "averageAddlMinDayToTarget";

        String CURRENT_RATE = "currentRate";
        String SESSION_LENGTH = "sessionLength";
        String AVERAGE_MIN_DAY = "averageMinDay";
        String CURRENT_LEARNING_RATE = "currentLearningRate";

        String CURRENT_FORECAST = "currentForecast";
        String TIME = "time";
        String LEVEL = "level";

        String CURRENT_FORECAST_TIME = "currentForecastTime";

        String PRESCRIPTION = "prescription";
        String ADDL_SESSION_TO_TARGET = "addlSessionsToTarget";
        String ADDL_TIME_TO_TARGET = "addlTimeToTarget";
        String ADDL_MIN_DAY_TO_TARGET = "addlMinDayToTarget";

        String MEAN = "mean";
        String STANDARD_DEVIATION = "standardDeviation";
        String TARGET_LEVEL = "targetLevel";
        String TARGET_DATE1 = "targetDate";
        String DAYS_TO_TARGET = "daysToTarget";
        String ORGANIZATION_NAME = "organizationName";
        String TEACHER_ID = "teacherID";
        String GRADE = "grade";
        String PSA_POPULATION = "psaPopulation";
        String PSA_TEACHER_MEAN = "psaTeacherMean";
        String PSA_STUDENTS_INCLUDED = "studentsIncluded";
        String PSA_STUDENTS_NOT_INCLUDED = "studentsNotIncluded";
        String PSA_CURRENT_FORECAST = "psaCurrentForecast";
        String PERCENT_STD_ACHIEVE_TARGET_LEVEL = "percentStudentsToAchieveTargetLevel";
        String PROJECTED_END_LEVEL_MEAN = "projectedEndLevelMean";

        int GROUP_BY_GRADE = 0;
        int GROUP_BY_GRADE_THEN_GROUP = 4;

        String SUBJECT_TYPE_MATH = "math";
        String SUBJECT_TYPE_READING = "reading";

    }
    
    interface MasteryExportAPIPDFConstants {
        public static String GROUPS_ID = "{groupid}";
        public static String STUDENT_IDD = "{studentid}";
        public static String ASSIGNMNET_ID = "{assignmentids}";
        public static String ORGS_ID = "{orgIds}";
        public static String USERSID = "{userids}";
    	public static String RUN_REPORT_TIME_VALUE = "2023-01-13 10.05 AM";
        public static String RBSS = "rbs";
        public static String CLIENT_ID = "GTrd4wvsJKWf6JkV0gbxHmgm3lQz20E7";
        public static String GRANT_TYPE = "client_credentials";
    	public static String FILTER="{fliter}";
        public static String CAST_GC = "castgc".trim().toString();
        public static String REQUEST_ID_REPORT = "requestId".trim().toString();
        public static String REPORT_TYP = "reportType".trim().toString();
        public static String PDF_LINKREPORT_TYP = "returnPdfLinks";
        public static String PDF_CURRENT_PAGE = "currentPage";
        public static String RUN_REPORT_TIME = "runReportTime".trim().toString();
    	String FILTER_NAMES = "{filterName}";
        String REQUEST_ID = "requestId";
        //Using 'Last Session' payload to generate request id
        public static String MASTERYREPORT_PARAMETER_PAYLOAD = "\r\n"
                +"{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  saveReportOption(\\n    userType: \\\"Teacher\\\"\\n    reportParameters: \\\"{\\\\\\\"groups\\\\\\\":[\\\\\\\"groupid\\\\\\\"],\\\\\\\"students\\\\\\\":[\\\\\\\"{studentid}\\\\\\\"],\\\\\\\"groupsOrStudents\\\\\\\":\\\\\\\"students\\\\\\\",\\\\\\\"subject\\\\\\\":\\\\\\\"1\\\\\\\",\\\\\\\"assignments\\\\\\\":[\\\\\\\"{assignmentids}\\\\\\\"],\\\\\\\"display\\\\\\\":\\\\\\\"STUDENT_NAME\\\\\\\",\\\\\\\"maskStudentDisplay\\\\\\\":null,\\\\\\\"isGroupsAllOrSingle\\\\\\\":\\\\\\\"ALL\\\\\\\",\\\\\\\"isStudentsAllOrSingle\\\\\\\":\\\\\\\"\\\\\\\",\\\\\\\"additionalGrouping\\\\\\\":\\\\\\\"NONE\\\\\\\",\\\\\\\"sort\\\\\\\":\\\\\\\"STUDENT\\\\\\\"}\\\"\\n    filterName: \\\"{filterName}\\\"\\n    personReport: true\\n    userId: \\\"{userids}\\\"\\n    reportType: \\\"lastSession\\\"\\n    orgId: \\\"{orgIds}\\\"\\n  ) {\\n    requestId\\n  }\\n}\\n\"}";
    }
   

}