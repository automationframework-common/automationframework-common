package com.savvas.sm.ui.tests.mastery;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.ui.mastery.pages.DevToolsUtils;
import com.savvas.sm.ui.mastery.pages.MasteryFiltersComponent;
import com.savvas.sm.ui.mastery.pages.MasteryMfePage;
import com.savvas.sm.ui.mastery.pages.MasterySummaryComponent;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

public class AdminMasteryMfeHierarchyViewTest extends BaseTest{

	private String masteryMfeUrl;

	private String browser;
	List<WebElement> masteredProgressBars;

	RBSUtils rbsUtils;
	private static String usernameSuffixTest;

	private static String smUrl;
	public static String orgId;
	public static Map<String, String> teacherDetails = new HashMap<>();
	public static Map<String, String> teacherGroupDetails = new HashMap<>();

	public static String districtAdmin;
	public static String schoolAdmin;
	public static String multiSchoolAdmin;
	public static String subDistrictAdmin;

	public static String districtAdminDetails;
	public static String schoolAdminDetails;
	public static String multiSchoolAdminDetails;
	public static String subDistrictAdminDetails;

	private String configGraphQL ="https://sm-mastery-bff-srv-stack-dev.smdemo.info/graphql";//endpoint

	@BeforeClass (alwaysRun = true)
	public void initTest(ITestContext context) {
		browser = configProperty.getProperty("BrowserPlatformToRun");
		smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
		rbsUtils = new RBSUtils();
		orgId = rbsUtils.getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

		String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
		String usernameSuffix = envUrl.split( "\\." )[0];
		usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );

		districtAdmin = String.format( RBSDataSetupConstants.DISTRICT_ADMIN_USERNAME, usernameSuffixTest );
		schoolAdmin = String.format( RBSDataSetupConstants.SCHOOL_ADMIN_USERNAME, usernameSuffixTest );
		multiSchoolAdmin = String.format( RBSDataSetupConstants.MULTI_SCHOOL_ADMIN_USERNAME, usernameSuffixTest );
		subDistrictAdmin = String.format( RBSDataSetupConstants.SUBDISTRICT_ADMIN_USERNAME, usernameSuffixTest );

		districtAdminDetails = rbsUtils.getUser( rbsUtils.getUserIDByUserName( districtAdmin ) );
		schoolAdminDetails = rbsUtils.getUser( rbsUtils.getUserIDByUserName( schoolAdmin ) );
		multiSchoolAdminDetails = rbsUtils.getUser( rbsUtils.getUserIDByUserName( multiSchoolAdmin ) );
		subDistrictAdminDetails = rbsUtils.getUser( rbsUtils.getUserIDByUserName( subDistrictAdmin ) );

	}

	@Test(priority = 1, dataProvider = "masterySummaryValidation", groups = { "SMK-51603", "mastery", "P1",
			"masterySummary", "mock" })
	public void tcMasteryMfeHierarchy001(String loginAs, String loginUrl, String loginUserName, ITestContext context) throws Exception {
		// Get driver
		DevTools tools = null;
		DevTools devTool = null;
		DevTools devTool1 = null;
		DevTools devTool2 = null;
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo(loginAs + " Mastery Hierarchy View Test" + "<small><b><i>[" + browser + "]</b></i></small>");
		masteryMfeUrl = configProperty.getProperty(loginUrl);
		try {
			// login to Mastery mfe as Teacher

			LoginWrapper.loginToMasteryMfe(driver, masteryMfeUrl, loginUserName, RBSDataSetupConstants.DEFAULT_PASSWORD);
			MasteryMfePage masteryMfePage = new MasteryMfePage(driver).get();
			MasteryFiltersComponent masteryFilterComponent = masteryMfePage.getMasteryFilterComponent();
			if (DevToolsUtils.isMock(context)){
				String json = DevToolsUtils.readJsonResponse("TeacherFilterSkillsAndStandardsMath.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "SkillsAndStandards", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
			}
			masteryFilterComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);
			masteryFilterComponent.selectSkillStandards(Constants.MasteryUI.SKILL_MATH);

			if ( DevToolsUtils.isMock( context ) ) {
				//mocking
				String responseJson = DevToolsUtils.readJsonResponse( "masteryMathSummary.json" );
				devTool = DevToolsUtils.setResponse( driver, configGraphQL, "post", 200, responseJson );
				devTool.createSessionIfThereIsNotOne();
				Log.message(devTool.getCdpSession().toString());
			}
			MasterySummaryComponent masterySummaryComponent = masteryFilterComponent.applyFilter();

			SMUtils.nap(10);
			SMUtils.logDescriptionTC(
					"TC:11: Verify LO Number & hotlink to preview in LO viewer is displayed for SuccessMaker Mastery Skills - Math");
			Log.assertThat(!masterySummaryComponent.getLinkOfLeafNodeLO().isEmpty(),
					"LO Number & hotlink to preview is displayed for SuccessMaker Mastery Skills - Math",
					"LO Number & hotlink to preview is not getting displayed for SuccessMaker Mastery Skills - Math");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:13: Verify the detailed mastery status link is available next to the progress bar");
			Log.assertThat(!masterySummaryComponent.getProgressBarLink(Constants.MasteryUI.MASTERED).isEmpty(),
					"The detailed Mastery status link is available next to the progress bar",
					"The detailed Mastery status link is not available next to the progress bar!");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:17: Verify the first-level Strand can be expanded and collapsed for Subject -Math and Default Math Skill");
			SMUtils.logDescriptionTC(
					"TC:18: Verify the progress bar gets collapsed when collapsing first-level Strand for Subject -Math and Default Math Skill");
			masterySummaryComponent.clickFirstLevelStrandName();
			Log.assertThat(!masterySummaryComponent.isLOviewLinkPresenet(),
					"After Clicking collapse btn on First level strandName, the progress bar is collapsed",
					"After Clicking collapse btn on First level strandName, the progress bar is not getting collapsed!");
			masterySummaryComponent.clickFirstLevelStrandName();
			Log.assertThat(masterySummaryComponent.isLOviewLinkPresenet(),
					"After Clicking Expand btn on First level strandName, the progress bar gets displayed",
					"After Clicking collapse btn on First level strandName, the progress bar is not getting displayed!");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:19: Verify the second-level Strand can be expanded and collapsed for Subject -Math and Default Math Skill");
			SMUtils.logDescriptionTC(
					"TC:20: Verify the progress bar gets collapsed when collapsing second-level Strand for Subject -Math and Default Math Skill");
			masterySummaryComponent.clickSecondLevelStrandName();
			Log.assertThat(!masterySummaryComponent.isLOviewLinkPresenet(),
					"After Clicking collapse btn on second level strandName, the progress bar is collapsed",
					"After Clicking collapse btn on second level strandName, the progress bar is not getting collapsed!");
			masterySummaryComponent.clickSecondLevelStrandName();
			Log.assertThat(masterySummaryComponent.isLOviewLinkPresenet(),
					"After Clicking Expand btn on second level strandName, the progress bar gets displayed",
					"After Clicking collapse btn on second level strandName, the progress bar is not getting displayed!");
			Log.testCaseResult();

			if (DevToolsUtils.isMock(context)){
				String json = DevToolsUtils.readJsonResponse("TeacherFilterSkillsAndStandardsReading.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "SkillsAndStandards", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
				SMUtils.nap(5);
			}

			masteryFilterComponent.expandToggle();
			masteryFilterComponent.selectSubject(Constants.MasteryUI.SUBJECT_READING);
			if (DevToolsUtils.isMock(context)){
				String json = DevToolsUtils.readJsonResponse("TeacherFilterSkillsAndStandardsReading.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "SkillsAndStandards", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
			}
			masteryFilterComponent.selectSubject(Constants.MasteryUI.SUBJECT_READING);
			if ( DevToolsUtils.isMock( context ) ) {
				String responseJson1 = DevToolsUtils.readJsonResponse( "masteryReadingSummary.json" );
				devTool1 = DevToolsUtils.setResponse( driver, configGraphQL, "post", 200, responseJson1 );
				devTool1.createSessionIfThereIsNotOne();
				Log.message(devTool1.getCdpSession().toString());
			}
			masteryFilterComponent.applyFilter();

			SMUtils.logDescriptionTC(
					"TC:21: Verify the first-level Strand can be expanded and collapsed for Subject -Reading");
			SMUtils.logDescriptionTC(
					"TC:22: Verify the progress bar gets collapsed when collapsing first-level Strand for Subject -Reading");
			masterySummaryComponent.clickFirstLevelStrandName();
			Log.assertThat(!masterySummaryComponent.isLOviewLinkPresenet(),
					"After Clicking collapse btn on First level strandName, the progress bar is collapsed",
					"After Clicking collapse btn on First level strandName, the progress bar is not getting collapsed!");
			masterySummaryComponent.clickFirstLevelStrandName();
			Log.assertThat(masterySummaryComponent.isLOviewLinkPresenet(),
					"After Clicking Expand btn on First level strandName, the progress bar gets displayed",
					"After Clicking collapse btn on First level strandName, the progress bar is not getting displayed!");

			Log.testCaseResult();

			masteryFilterComponent.expandToggle();
			if (DevToolsUtils.isMock(context)){
				String json = DevToolsUtils.readJsonResponse("TeacherFilterSkillsAndStandardsMath.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "SkillsAndStandards", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
			}
			masteryFilterComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);

			if ( DevToolsUtils.isMock( context ) ) {
				String responseJson2 = DevToolsUtils.readJsonResponse( "masteryReadingSummary.json" );
				devTool2 = DevToolsUtils.setResponse( driver, configGraphQL, "post", 200, responseJson2 );
				devTool2.createSessionIfThereIsNotOne();
				Log.message(devTool2.getCdpSession().toString());
			}
			masteryFilterComponent.applyFilter();

			SMUtils.logDescriptionTC(
					"TC:23:On clicking 'Apply Filters' button on Mastery Page, verify teacher is able to see the 'Mastered', 'At Risk', 'Not Mastered', and 'Unassessed' breakdown per skills progress bar");
			Log.assertThat(masterySummaryComponent.isSkillDetailsPresentInProgressBarToolTip(),
					"Teacher is able to see skill in tool tip as Mastered', 'At Risk', 'Not Mastered', and 'Unassessed' ",
					"Teacher is able to see skill in tool tip as Mastered', 'At Risk', 'Not Mastered', and 'Unassessed'");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:24:On Mouse hovering on Progress bar, Verify tooltip message is displaying ");
			Log.assertThat(masterySummaryComponent.isSkillDetailsPresentInProgressBarToolTip(),
					"On Mouse hovering on Progress bar-Tool-tip is present",
					"On Mouse hovering on Progress bar-Tool-tip is present");
			Log.testCaseResult();


			SMUtils.logDescriptionTC("TC:34:Verify the 'Assessed Objectives' title is displayed");
			Log.assertThat(masterySummaryComponent.getAssessedObjectivesHeader(browser).isDisplayed(),
					"'Assessed Objectives' title is displayed", "'Assessed Objectives' title is not displayed");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			if (tools != null) {
				RequestMockUtils.closeMock(tools);
			}
			if (null != devTool){
				DevToolsUtils.closeMock(devTool);
			}
			if (null != devTool1){
				DevToolsUtils.closeMock(devTool1);
			}
			if (null != devTool2){
				DevToolsUtils.closeMock(devTool2);
			}
			driver.quit();
		}
	}

	@Test(priority = 1, dataProvider = "masterySummaryValidation", groups = { "SMK-51603", "mastery",
			"masterySummary", "mock" })
	public void tcMasteryMfeHierarchy002(String loginAs, String loginUrl, String loginUserName, ITestContext context) throws Exception {
		// Get driver
		DevTools tools = null;
		DevTools devTool = null;
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo(loginAs + " Mastery Hierarchy View Test" + "<small><b><i>[" + browser + "]</b></i></small>");
		masteryMfeUrl = configProperty.getProperty(loginUrl);
		try {
			// login to Mastery mfe as Teacher
			LoginWrapper.loginToMasteryMfe(driver, masteryMfeUrl, loginUserName, "testing123$");
			MasteryMfePage masteryMfePage = new MasteryMfePage(driver).get();
			MasteryFiltersComponent masteryFilterComponent = masteryMfePage.getMasteryFilterComponent();
			if (DevToolsUtils.isMock(context)){
				String json = DevToolsUtils.readJsonResponse("TeacherFilterSkillsAndStandardsMath.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "SkillsAndStandards", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
			}
			masteryFilterComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);
			masteryFilterComponent.selectSkillStandards(Constants.MasteryUI.SKILL_MATH);
			if ( DevToolsUtils.isMock( context ) ) {
				//mocking
				String responseJson = DevToolsUtils.readJsonResponse( "masteryMathSummary.json" );
				devTool = DevToolsUtils.setResponse( driver, configGraphQL, "post", 200, responseJson );
				devTool.createSessionIfThereIsNotOne();
				Log.message(devTool.getCdpSession().toString());

			}
			MasterySummaryComponent masterySummaryComponent = masteryFilterComponent.applyFilter();

			SMUtils.logDescriptionTC(
					"TC:12: Teacher is able to see the LO as a blue link, when Math subject is chosen with skills");
			Log.assertThat(masterySummaryComponent.verifyLOColor(browser),
					"Teacher is able to see the LO as a blue link",
					"Teacher is not able to see the LO as a blue link, when Math subject is chosen with skills");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:25:Verify the progress bar, 'Mastered' status is indicated by Green color");
			Log.assertThat(
					masterySummaryComponent.getStatusColor(browser)
					.contains(Constants.MasteryUI.MASTERED_COLOR_CODE.toLowerCase()),
					"Mastered status is indicated by Green color in the progress bar ",
					"Mastered status is not indicated by Green color in the progress bar ");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:26:Verify the progress bar, 'At Risk ' status is indicated by Yellow color");
			Log.assertThat(
					masterySummaryComponent.getStatusColor(browser)
					.contains(Constants.MasteryUI.ATRISK_COLOR_CODE.toLowerCase()),
					"At Risk status is indicated by Yellow color in the progress bar ",
					"At Risk status is not indicated by Yellow color in the progress bar ");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:27:Verify the progress bar, 'Not Mastered' status is indicated by Yellow color");
			Log.assertThat(
					masterySummaryComponent.getStatusColor(browser)
					.contains(Constants.MasteryUI.NOTMASTERED_COLOR_CODE.toLowerCase()),
					"Not Mastered status is indicated by Red color in the progress bar ",
					"Not Mastered status is not indicated by Red color in the progress bar ");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:28:Verify the progress bar, 'Un Assessed' status is indicated by Grey color");
			Log.assertThat(
					masterySummaryComponent.getStatusColor(browser)
					.contains(Constants.MasteryUI.UNASSESSED_COLOR_CODE.toLowerCase()),
					"Unassessed status is indicated by grey color in the progress bar ",
					"Unassessed status is not indicated by grey color in the progress bar ");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:33: Verify horizontal line displaying below 'Assessed Objectives' title\n");
			Log.assertThat(masterySummaryComponent.getAssessedObjectivesLine(browser).isDisplayed(),
					"Horizontal line displaying below 'Assessed Objectives' title",
					"Horizontal line is not displaying below 'Assessed Objectives' title");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			if (tools != null) {
				RequestMockUtils.closeMock(tools);
			}
			if (null != devTool) {
				DevToolsUtils.closeMock( devTool );
			}
			driver.quit();
		}
	}

	@Test(priority = 1, dataProvider = "masterySummaryValidation", groups = { "SMK-51603", "mastery", "P1",
			"masterySummary", "mock" })
	public void tcMasteryMfeHierarchySmoke(String loginAs, String loginUrl, String loginUserName, ITestContext context) throws Exception {
		DevTools tools = null;
		DevTools devTool = null;
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo(loginAs + " Mastery Hierarchy View Test" + "<small><b><i>[" + browser + "]</b></i></small>");
		masteryMfeUrl = configProperty.getProperty(loginUrl);
		try {
			// login to Mastery mfe as Teacher
			LoginWrapper.loginToMasteryMfe(driver, masteryMfeUrl, loginUserName, "testing123$");
			MasteryMfePage masteryMfePage = new MasteryMfePage(driver).get();
			MasteryFiltersComponent masteryFilterComponent = masteryMfePage.getMasteryFilterComponent();
			if (DevToolsUtils.isMock(context)){
				String json = DevToolsUtils.readJsonResponse("TeacherFilterSkillsAndStandardsMath.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "SkillsAndStandards", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
			}
			masteryFilterComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);
			masteryFilterComponent.selectSkillStandards(Constants.MasteryUI.SKILL_MATH);
			if ( DevToolsUtils.isMock( context ) ) {
				String responseJson = DevToolsUtils.readJsonResponse( "masteryMathSummary.json" );
				devTool = DevToolsUtils.setResponse( driver, configGraphQL, "post", 200, responseJson );
				devTool.createSessionIfThereIsNotOne();
				Log.message(devTool.getCdpSession().toString());
			}
			MasterySummaryComponent masterySummaryComponent = masteryFilterComponent.applyFilter();

			SMUtils.logDescriptionTC(
					"TC:01: Verify the selected values from Mastery filters are shown in the Filters section-Collapsed view ");
			SMUtils.logDescriptionTC(
					"TC:02: Verify the Mastery Filter section collapses after clicking on Apply Filter button");
			Log.assertThat(!masteryFilterComponent.isFilterExpanded(),
					"Mastery Filter section collapses after clicking on Apply filter button",
					"Mastery Filter section is not collapsed after clicking on Apply filter button!");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:03: Verify the Mastery Data are getting loaded and collapse the Filters on clicking Apply Filter button");
			SMUtils.logDescriptionTC(
					"TC:04: Verify the Mastery Data are getting loaded on clicking Apply Filter button for valid selection of Mastery Filters");
			Log.assertThat(masterySummaryComponent.verifyGradeIsDisplayed(),
					"Mastery Data are getting loaded on clicking Apply Filter button for valid selection of Mastery Filters",
					"Mastery Data is not getting loaded on clicking Apply Filter button for valid selection of Mastery Filters!");
			Log.testCaseResult();
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:05: Verify the Collapsed Filter section can be expanded");
			Log.assertThat(masteryFilterComponent.isFilterExpandable(), "The collapse Filter can be expandable",
					"The collapse Filter is not getting expandable!");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:06 Verify user is able to expand collapsed Filters and change options to load a new mastery view");
			Log.assertThat(masteryFilterComponent.isFilterExpanded(), "The collpased filter gets expanded",
					"The collpased filter is not getting expanded!");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:07: Verify the Reset button functionality");
			masteryFilterComponent.resetFilter();
			masteryFilterComponent.waitForFilterButtonPresent();
			Log.assertThat(
					masteryFilterComponent.getSkillStandardDropDownSelectedValue()
					.contains(Constants.MasteryUI.SKILL_MATH),
					"After clicking the reset, the dropdown values got resetted ",
					"After clicking the reset button, the values are not getting resetted!");
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:08- Verify Math is selected as default in the Subjects dropdown");
			masteryFilterComponent.resetFilter();
			String defaultSubject = masteryFilterComponent.getSelectedValueFromSubjectDropDown();
			Log.assertThat(Constants.MasteryUI.SUBJECT_MATH.equals(defaultSubject),
					"Math is selected as default in the Subjects dropdown",
					"Math is not selected as default in the Subjects dropdown");

			SMUtils.logDescriptionTC(
					"TC:09 - Verify the SuccessMaker Mastery Skills- Math are selected default in the Skills/Standards dropdown when Math is chosen as subject");
			masteryFilterComponent.resetFilter();
			String selectedSkillStandards = masteryFilterComponent.getSelectedValueFromSkillStandardsDropDown();
			Log.assertThat(Constants.MasteryUI.SKILL_MATH.equals(selectedSkillStandards),
					"The SuccessMaker Mastery Skills- Math are selected as default in the Skills/Standards dropdown(Mastery Page) when Math is chosen as subject",
					"The SuccessMaker Mastery Skills- Math are not selected as default in the Skills/Standards dropdown(Mastery Page) when Math is chosen as subject");

			SMUtils.logDescriptionTC("TC:10: Verify the applied filters can be modified");
			masteryFilterComponent.selectSubject(Constants.MasteryUI.SUBJECT_READING);
			if (DevToolsUtils.isMock(context)){
				String json = DevToolsUtils.readJsonResponse("TeacherFilterSkillsAndStandardsMath.json");
				tools = RequestMockUtils.setResponse(driver, configGraphQL, "SkillsAndStandards", "post", json);
				tools.createSessionIfThereIsNotOne();
				Log.message(tools.getCdpSession().toString());
			}
			masteryFilterComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);
			masteryFilterComponent.applyFilter();
			Log.assertThat(masterySummaryComponent.verifyGradeIsDisplayed(), "The applied filters are modified",
					"The applied filter are not modified!");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:14: Verify the number of students got assessed and progress bar is displaying for each skill/standard");
			SMUtils.logDescriptionTC(
					"TC:15: Verify the number of students got assessed is displaying for each skill/standard");
			Log.assertThat(
					masterySummaryComponent.getStudentAssessmentOfLeafNodeLO().stream()
					.allMatch(studentCount -> !studentCount.isEmpty()),
					"The number of students mastery status is displaying for each skill/standard",
					"The number of students mastery status is not getting displayed for each skill/standard");
			Log.testCaseResult();
			Log.testCaseResult();

			SMUtils.logDescriptionTC("TC:16: Verify the progress bar is displayed for the skill/standards avaialble");
			List<WebElement> masteredProgressBars = masterySummaryComponent
					.getProgressBarLink(Constants.MasteryUI.MASTERED);
			Log.assertThat(!masteredProgressBars.isEmpty(),
					"Progress bar is getting displayed for the skills/standards available",
					"Progress bar is not getting displayed for the skills/standards available!");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:29:Verify the progress bar, total number of students 'Mastered'/Not Mastered/At Risk with respect to that skill is displaying inside Green/Yellow/red colour.");
			Log.assertThat(
					masterySummaryComponent.getStudentAssessmentOfLeafNodeLO()
					.containsAll(masterySummaryComponent.getStudentAssessmentCount()),
					"Total number of student assessment is didplayed in progress bar",
					"Total number of student assessment is not didplayed in progress bar");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			if (tools != null) {
				RequestMockUtils.closeMock(tools);
			}
			if (null != devTool) {
				DevToolsUtils.closeMock( devTool );
			}
			driver.quit();
		}
	}

	@DataProvider(name = "masterySummaryValidation")
	public Object[][] masterySummaryValidation() {

		Object[][] inputData = {
				{ "singleadminlogin", "MasteryAdminSingleMfe", schoolAdmin },
				{ "multiadminlogin", "MasteryAdminMultiMfe", multiSchoolAdmin } 
		};
		return inputData;
	}

}
