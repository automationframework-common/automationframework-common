package com.savvas.sm.ui.tests.mastery;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.ui.constants.ReportsUIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.ui.mastery.pages.*;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * This class is used to test the Mastery Admin Run Report Output Screen
 */
public class MasteryAdminRunReportTest extends EnvProperties {
    private String masteryMFE;
    private String browser;
    private String username;
    private String password;
    private String masteryBFF;
    private String masterBFF;
    private String reportMFE;

    @BeforeClass ( alwaysRun = true )
    public void beforeTest() {
        username = MasteryDataSetup.districtAdminUserName;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        masteryMFE = configProperty.getProperty( "MasteryAdminSingleMfe" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        masteryBFF = "https://sm-reports-bff-srv-stack-dev.smdemo.info/graphql";
        reportMFE = configProperty.getProperty( "MasteryAdminReportMfe" ) + UUID.randomUUID();
    }

    @Test ( description = "Verify the Mastery Output Run Report Page", groups = { "SMK-67073",  "Mastery", "MasteryAdminRunReport", "mock" }, priority = 1 )
    public void tcMasteryRunReport001( ITestContext context ) throws Exception {

        WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcMasteryRunReport1: Verify the user can able to Navigate to Mastery Run Report page<small><b><i>[" + browser + "]</b></i></small>" );

        DevTools devTool = null;
        try {

            MasteryReportOutputPage masteryReport;

            if ( DevToolsUtils.isMock( context ) ) {
                //mocking
                Map<String, String> responses = new HashMap();
                String getReportOptionResponseJson = DevToolsUtils.readJsonResponse( "GetReportOptionResponseMasteryAdmin.json" );
                String masteryRunReportJson = DevToolsUtils.readJsonResponse( "masteryAdminRunReport.json" );
                responses.put( "GetReportOptionResponse", getReportOptionResponseJson );
                responses.put( "GetAdminMasteryReportData", masteryRunReportJson );

                List<String> requestPayloadMatchers = Arrays.asList( "GetReportOptionResponse", "GetAdminMasteryReportData" );
                devTool = DevToolsUtils.setResponse( driver, masteryBFF, requestPayloadMatchers, "post", responses );
                devTool.createSessionIfThereIsNotOne();
                Log.message( devTool.getCdpSession().toString() );
                
                LoginWrapper.loginToMasteryMfe(driver, reportMFE, username, password);
                masteryReport = new MasteryReportOutputPage(driver);

            }else{
                LoginWrapper.loginToMasteryMfe(driver, masteryMFE, username, password);
                MasteryMfePage masteryMfePage = new MasteryMfePage(driver).get();
                MasteryFiltersComponent masteryFilterComponent = masteryMfePage.getMasteryFilterComponent();
                masteryFilterComponent.selectOrganization( "Flex_RegressionBasic" );
                masteryFilterComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);
                masteryFilterComponent.selectSkillStandards(Constants.MasteryUI.SKILL_MATH);
                MasterySummaryComponent masterySummaryComponent= new MasterySummaryComponent(driver);
                masteryReport = new MasteryReportOutputPage(driver);

                SMUtils.logDescriptionTC( "Tc:01 Verify the Organization dropdown is present" );
                Log.assertThat( masteryFilterComponent.isOrganizationDropdownPresent(), "Organization dropdown is present", "Organization dropdown is not present" );
                Log.testCaseResult();
                masteryFilterComponent.selectOrganization( "Flex_RegressionBasic" );

                SMUtils.logDescriptionTC( "Tc:02 Verify the Subject dropdown is present" );
                Log.assertThat( masteryFilterComponent.isSubjectDropdownPresent(), "Subject dropdown is present", "Subject dropdown is not present" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "Tc:03 Verify Default Value of Subject Dropdown" );
                Log.assertThat( masteryFilterComponent.getSubjectDropDownSelectedValue().equals( Constants.MasteryUI.SUBJECT_MATH ), "Default value of subject dropdown is Math", "Default value of Subject dropdown is not Math" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "Tc:04 Verify Value of Subject Dropdown" );
                Log.assertThat( masteryFilterComponent.getAllSubjectDropDownValues().size() > 0, "Value of Subject dropdown : " + masteryFilterComponent.getAllSubjectDropDownValues().toString(), "Subject Value is not present" );
                Log.testCaseResult();
                masteryFilterComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );

                SMUtils.logDescriptionTC( "Tc:05 Verify the Assignment dropdown is present" );
                Log.assertThat( masteryFilterComponent.isSubjectDropdownPresent(), "Assignment dropdown is present", "Assignment dropdown is not present" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "Tc:06 Verify the Assignment dropdown is present" );
                Log.assertThat( masteryFilterComponent.getAllSkillStandardsDropDownValues().size() > 0, "Assignment dropdown have value", "Assignment dropdown is null" );
                Log.testCaseResult();
                masteryFilterComponent.selectSkillStandards( Constants.MasteryUI.SKILL_MATH );


                SMUtils.logDescriptionTC( "Tc:07 Verify the Mastery Run Report button is disabled by default" );
                Log.assertThat( masterySummaryComponent.isRunReportBtnDisabled(), "The Mastery Run Report button is disabled by default", "The Mastery Run Report button is not disabled by default" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "Tc:08 Verify the Reset Filter button is present" );
                Log.assertThat( masteryFilterComponent.isresetBtnPresent(), "Reset Button is present", "Reset Button is not present" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "Tc:09 Verify the Mastery Run Report button is enabled after clicking on Run Report button" );
                masterySummaryComponent = masteryFilterComponent.applyFilter();
                Log.assertThat( !masterySummaryComponent.isRunReportBtnDisabled(), "The Mastery Run Report button is enabled after clicking on Run Report button", "The Mastery Run Report button is not enabled after clicking on Run Report button" );
                Log.testCaseResult();

                SMUtils.nap( 10 );
                SMUtils.logDescriptionTC( "TC:10: Verify LO Number & hotlink to preview in LO viewer is displayed for SuccessMaker Mastery Skills - Math" );
                Log.assertThat( !masterySummaryComponent.getLinkOfLeafNodeLO().isEmpty(), "LO Number & hotlink to preview is displayed for SuccessMaker Mastery Skills - Math",
                        "LO Number & hotlink to preview is not getting displayed for SuccessMaker Mastery Skills - Math" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "TC:11: Verify the detailed mastery status link is available next to the progress bar" );
                Log.assertThat( !masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED ).isEmpty(), "The detailed Mastery status link is available next to the progress bar",
                        "The detailed Mastery status link is not available next to the progress bar!" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "TC:12: Verify the first-level Strand can be expanded and collapsed for Subject -Math and Default Math Skill" );
                SMUtils.logDescriptionTC( "TC:13: Verify the progress bar gets collapsed when collapsing first-level Strand for Subject -Math and Default Math Skill" );
                masterySummaryComponent.clickFirstLevelStrandName();
                Log.assertThat( !masterySummaryComponent.isLOviewLinkPresenet(), "After Clicking collapse btn on First level strandName, the progress bar is collapsed",
                        "After Clicking collapse btn on First level strandName, the progress bar is not getting collapsed!" );
                masterySummaryComponent.clickFirstLevelStrandName();
                Log.assertThat( masterySummaryComponent.isLOviewLinkPresenet(), "After Clicking Expand btn on First level strandName, the progress bar gets displayed",
                        "After Clicking collapse btn on First level strandName, the progress bar is not getting displayed!" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "TC:14: Verify the second-level Strand can be expanded and collapsed for Subject -Math and Default Math Skill" );
                SMUtils.logDescriptionTC( "TC:15: Verify the progress bar gets collapsed when collapsing second-level Strand for Subject -Math and Default Math Skill" );
                masterySummaryComponent.clickSecondLevelStrandName();
                Log.assertThat( !masterySummaryComponent.isLOviewLinkPresenet(), "After Clicking collapse btn on second level strandName, the progress bar is collapsed",
                        "After Clicking collapse btn on second level strandName, the progress bar is not getting collapsed!" );
                masterySummaryComponent.clickSecondLevelStrandName();
                Log.assertThat( masterySummaryComponent.isLOviewLinkPresenet(), "After Clicking Expand btn on second level strandName, the progress bar gets displayed",
                        "After Clicking collapse btn on second level strandName, the progress bar is not getting displayed!" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "Tc:16 Verify the Grade is displayed" );
                Log.assertThat( masterySummaryComponent.verifyGradeIsDisplayed(), "The applied filters are modified", "The applied filter are not modified!" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "TC:17: Verify the number of students got assessed and progress bar is displaying for each skill/standard" );
                SMUtils.logDescriptionTC( "TC:18: Verify the number of students got assessed is displaying for each skill/standard" );
                Log.assertThat( masterySummaryComponent.getStudentAssessmentOfLeafNodeLO().stream().allMatch( studentCount -> !studentCount.isEmpty() ), "The number of students mastery status is displaying for each skill/standard",
                        "The number of students mastery status is not getting displayed for each skill/standard" );
                Log.testCaseResult();
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "TC:19: Verify the progress bar is displayed for the skill/standards avaialble" );
                List<WebElement> masteredProgressBars = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );
                Log.assertThat( !masteredProgressBars.isEmpty(), "Progress bar is getting displayed for the skills/standards available", "Progress bar is not getting displayed for the skills/standards available!" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "TC:20:Verify the progress bar, total number of students 'Mastered'/Not Mastered/At Risk with respect to that skill is displaying inside Green/Yellow/red colour." );
                Log.assertThat( masterySummaryComponent.getStudentAssessmentOfLeafNodeLO().containsAll( masterySummaryComponent.getStudentAssessmentCount() ), "Total number of student assessment is didplayed in progress bar",
                        "Total number of student assessment is not didplayed in progress bar" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "TC:21:On clicking 'Apply Filters' button on Mastery Page, verify admin is able to see the 'Mastered', 'At Risk', 'Not Mastered', and 'Unassessed' breakdown per skills progress bar" );
                Log.assertThat( masterySummaryComponent.isSkillDetailsPresentInProgressBarToolTip(), "admin is able to see skill in tool tip as Mastered', 'At Risk', 'Not Mastered', and 'Unassessed' ",
                        "admin is able to see skill in tool tip as Mastered', 'At Risk', 'Not Mastered', and 'Unassessed'" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "TC:22:On Mouse hovering on Progress bar, Verify tooltip message is displaying " );
                Log.assertThat( masterySummaryComponent.isSkillDetailsPresentInProgressBarToolTip(), "On Mouse hovering on Progress bar-Tool-tip is present", "On Mouse hovering on Progress bar-Tool-tip is present" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "TC:23:Verify the 'Assessed Objectives' title is displayed" );
                Log.assertThat( masterySummaryComponent.getAssessedObjectivesHeader( browser ).isDisplayed(), "'Assessed Objectives' title is displayed", "'Assessed Objectives' title is not displayed" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "TC:24: admin is able to see the LO as a blue link, when Math subject is chosen with skills" );
                Log.assertThat( masterySummaryComponent.verifyLOColor( browser ), "admin is able to see the LO as a blue link", "admin is not able to see the LO as a blue link, when Math subject is chosen with skills" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "TC:25:Verify the progress bar, 'Mastered' status is indicated by Green color" );
                Log.assertThat( masterySummaryComponent.getStatusColor( browser ).contains( Constants.MasteryUI.MASTERED_COLOR_CODE.toLowerCase() ), "Mastered status is indicated by Green color in the progress bar ",
                        "Mastered status is not indicated by Green color in the progress bar " );
                Log.testCaseResult();


                SMUtils.logDescriptionTC( "TC:26: Verify horizontal line displaying below 'Assessed Objectives' title\n" );
                Log.assertThat( masterySummaryComponent.getAssessedObjectivesLine( browser ).isDisplayed(), "Horizontal line displaying below 'Assessed Objectives' title", "Horizontal line is not displaying below 'Assessed Objectives' title" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "Tc:27 Verify the Mastery Report opened in a new tab after clicking on Run Report button" );
                SMUtils.logDescriptionTC( "Tc:28 Verify the Mastery report is loaded in a new tab when user is clicked on Run Report button" );
                masterySummaryComponent.clickMasteryRunReportBtn();
            }



            Log.assertThat( masteryReport.isMasteryReportPageLoaded(), "Mastery Report Page is loaded Successfully", "Mastery Report Page is not loaded Successfully!!" );
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:29 Verify the header of the  Mastery Run Report contains Mastery in bold letters in the top left of the page");
            Log.assertThat(masteryReport.getMasteryHeader().equals(ReportsUIConstants.MASTERY_HEADER), "The mastery header is displayed in bold letters", "The mastery header is not displayed in bold letters");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:30 Verify the Student Name  is present in the Mastery Run Report");
            Log.assertThat(!masteryReport.getStudentName().isEmpty(), "The student name is displayed", "The student name is not displayed");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:31 Verify the Grade Level is present in the Mastery Run Report");
            Log.assertThat(!masteryReport.getGradeName().isEmpty(), "The grade is displayed", "The grade is not displayed");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:32 Verify the Assignments name is present in the Mastery Run Report");
            Log.assertThat(!masteryReport.getAssignmentName().isEmpty(), "The grade is displayed", "The grade is not displayed");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:33 Verify the Date and time is getting displayed in the Mastery Run Report under Report Run ");
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yy");
            String reportDate = dateFormat.format(new Date());
            Log.assertThat(masteryReport.getReportRunTime().contains(reportDate), "The today date " + reportDate + " is displayed as expected", "The today date " + reportDate + " is not displayed as expected");
            Log.assertThat(masteryReport.getReportRunTime().contains("AM") || masteryReport.getReportRunTime().contains("PM"), "The time is " + masteryReport.getReportRunTime() + "displayed as expected", "The time is " + masteryReport.getReportRunTime() + "not displayed as expected");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:34 Verify the Assigned Course Level, Current Course Level, IP Level, Time Spent, Total Sessions(Minimum of 1 Assessments), Average Session Time, Skill/Standard, Mastery Status, # of Skills Completed/Judged, # of Attempts column fields are available in Mastery Run Report page");
            Log.assertThat(masteryReport.getAssignmentsDetailsKey().containsAll(ReportsUIConstants.MASTERYREPORT_ASSIGNMENTDETAILS_LABELS), "The Assignment Details Key are getting displayed as Expected", "The Assignment Details Key are getting displayed as Expected!");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:35 Verify user is able to view the next students mastery data by clicking Next  button");
            String asgnNamebfrr = masteryReport.getAssignmentName();
            masteryReport.clickPaginationNextBtn();
            String asgnNameaftt = masteryReport.getAssignmentName();
            Log.assertThat(!asgnNamebfrr.equals(asgnNameaftt), "The next students mastery data is displaying by clicking Next button", "The next students mastery data is not displaying by clicking next button");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:36 Verify user is able to view the previous students mastery data by clicking Back button");
            String asgnNamebfr = masteryReport.getAssignmentName();
            masteryReport.clickPaginationBackBtn();
            String asgnNameaft = masteryReport.getAssignmentName();
            Log.assertThat(!asgnNamebfr.equals(asgnNameaft), "The previous students mastery data is displaying by clicking Back button", "The previous students mastery data is not displaying by clicking Back button");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:37 Verify user is able to go to respective students page by entering respective page number in the box provided neato \"Go to\" text & click on enter on the keyboard if we have multiple pages in the report generated");
            String assignmentNamebfr = masteryReport.getAssignmentName();
            masteryReport.setPaginationInput(ReportsUIConstants.VALID_PAGINATION_THREE);
            String assignmentNameAft = masteryReport.getAssignmentName();
            Log.assertThat(!assignmentNamebfr.equals(assignmentNameAft), "The student able to go to respective students page by entering respective page number", "The student not able to go to respective students page by entering respective page number");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:38 Verify the message \" Invalid\" is displayed   in Run Report while giving page number out of the bound  in the box provied near to \"Go to\" text ");
            masteryReport.setPaginationInput(ReportsUIConstants.INVALID_PAGINATION_INPUT);
            Log.assertThat(masteryReport.getPaginationError().equals(ReportsUIConstants.INVALID_PAGINATION_ERRMSG), "The pagination error message is displayed while giving page number out of the bound", "The pagination error message is not displayed while giving page number out of the bound");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:39 Verify the Legends displayed in the report page");
            Log.assertThat(masteryReport.getLegendHeading().equals(ReportsUIConstants.LEGEND_HEADER), "The legend header is available in reports output page", "The lengend header is not available in reports output page");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:40 Verify the Legends labels displayed in the report page");
            Log.assertThat(masteryReport.getLegendLabel().equals(ReportsUIConstants.MASTERYREPORT_LEGEND_LABELS), "The legend label is showing as expected", "The legend label is not showing as expected");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:41 Verify the Legends values displayed in the report page");
            Log.assertThat(masteryReport.getLegengLabelValuey().equals(ReportsUIConstants.MASTERYREPORT_LEGEND_LABELS_VALUES), "The legend label values are showing as expected", "The legend label values are not showing as expected");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:42 Verify the all Students Mastery Data Headers ");
            Log.assertThat(masteryReport.verifyMasteryHeaderTitles(), "The MasteryDetails Header titles are displayed as expected", "The MasteryDetails Header titles are not displayed as expected!");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:43 Verify the Mastery Skills/Standards values are getting diaplayed in the Mastery Skills/Standard Column");
            Log.message("The mastery Skills/Standard column present count is " + masteryReport.getMasteryStatusColumn().size());
            Log.assertThat(!masteryReport.getSkillOrStandardColumn().isEmpty(), "Mastery Skills/Standards values are getting displayed in the Mastery skills/standard column", "Mastery Skills/Standards values are not getting displayed in the Mastery skills/standard column!");

            SMUtils.logDescriptionTC("Tc:44 Verify the # of Skills Completed/Judged	values are present under # of Skills Completed/Judged column ");
            Log.message("The # of Skills Completed/Judged column value count is " + masteryReport.getSkillsCompletedColumn().size());
            Log.assertThat(masteryReport.getSkillsCompletedColumn().size() > 0, "The # of Skills Completed/Judged	values are present under # of Skills Completed/Judged column", "The # of Skills Completed/Judged values are not present under # of Skills Completed/Judged column!");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:45 Verify the Attempts column values are getting displayed under Attempts column");
            Log.message("The Attempts column value count is " + masteryReport.getNoofAttemptsColumn().size());
            Log.assertThat(masteryReport.getNoofAttemptsColumn().size() > 0, "The Attempts column values are getting displayed under Attempts column", "The Attempts column values are not getting displayed under Attempts column!");
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            if ( null != devTool ) {
                DevToolsUtils.closeMock( devTool );
            }
            Log.endTestCase();
            driver.quit();
        }

    }


    @Test ( description = "Verify the Mastery Output Run Report Page - Reading", groups = { "SMK-67073",  "Mastery", "MasteryAdminRunReport", "mock" }, priority = 1 )
    public void tcMasteryRunReport002( ITestContext context ) throws Exception {

        WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcMasteryRunReport2: Verify the user can able to Navigate to Mastery Run Report page<small><b><i>[" + browser + "]</b></i></small>" );

        DevTools devTool = null;
        try {

            MasteryReportOutputPage masteryReport;

            if ( DevToolsUtils.isMock( context ) ) {
                //mocking
                Map<String, String> responses = new HashMap();
                String getReportOptionResponseJson = DevToolsUtils.readJsonResponse( "GetReportOptionResponseMasteryAdminReading.json" );
                String masteryRunReportJson = DevToolsUtils.readJsonResponse( "masteryAdminRunReportReading.json" );
                String exportCSV = DevToolsUtils.readJsonResponse( "GetExportCSVFieldsAdminMastery.json" );
                responses.put( "GetReportOptionResponse", getReportOptionResponseJson );
                responses.put( "GetAdminMasteryReportData", masteryRunReportJson );
                responses.put( "GetExportCSVFields", exportCSV );

                List<String> requestPayloadMatchers = Arrays.asList( "GetReportOptionResponse", "GetAdminMasteryReportData", "GetExportCSVFields" );
                devTool = DevToolsUtils.setResponse( driver, masteryBFF, requestPayloadMatchers, "post", responses );
                devTool.createSessionIfThereIsNotOne();
                Log.message( devTool.getCdpSession().toString() );

                LoginWrapper.loginToMasteryMfe(driver, reportMFE, username, password);
                masteryReport = new MasteryReportOutputPage(driver);

            }else{
                LoginWrapper.loginToMasteryMfe(driver, masteryMFE, username, password);
                MasteryMfePage masteryMfePage = new MasteryMfePage(driver).get();
                MasteryFiltersComponent masteryFilterComponent = masteryMfePage.getMasteryFilterComponent();
                masteryFilterComponent.selectOrganization( "Flex_RegressionBasic" );
                masteryFilterComponent.selectSubject(Constants.MasteryUI.SUBJECT_READING);
                masteryFilterComponent.selectSkillStandards(Constants.MasteryUI.SKILL_READING);
                MasterySummaryComponent masterySummaryComponent= new MasterySummaryComponent(driver);
                masteryReport = new MasteryReportOutputPage(driver);

                SMUtils.logDescriptionTC( "Tc:01 Verify the Organization dropdown is present" );
                Log.assertThat( masteryFilterComponent.isOrganizationDropdownPresent(), "Organization dropdown is present", "Organization dropdown is not present" );
                Log.testCaseResult();
                masteryFilterComponent.selectOrganization( "Flex_RegressionBasic" );

                SMUtils.logDescriptionTC( "Tc:02 Verify the Subject dropdown is present" );
                Log.assertThat( masteryFilterComponent.isSubjectDropdownPresent(), "Subject dropdown is present", "Subject dropdown is not present" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "Tc:03 Verify Default Value of Subject Dropdown" );
                Log.assertThat( masteryFilterComponent.getSubjectDropDownSelectedValue().equals( Constants.MasteryUI.SUBJECT_MATH ), "Default value of subject dropdown is Math", "Default value of Subject dropdown is not Math" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "Tc:04 Verify Value of Subject Dropdown" );
                Log.assertThat( masteryFilterComponent.getAllSubjectDropDownValues().size() > 0, "Value of Subject dropdown : " + masteryFilterComponent.getAllSubjectDropDownValues().toString(), "Subject Value is not present" );
                Log.testCaseResult();
                masteryFilterComponent.selectSubject( Constants.MasteryUI.SUBJECT_READING );

                SMUtils.logDescriptionTC( "Tc:05 Verify the Assignment dropdown is present" );
                Log.assertThat( masteryFilterComponent.isSubjectDropdownPresent(), "Assignment dropdown is present", "Assignment dropdown is not present" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "Tc:06 Verify the Assignment dropdown is present" );
                Log.assertThat( masteryFilterComponent.getAllSkillStandardsDropDownValues().size() > 0, "Assignment dropdown have value", "Assignment dropdown is null" );
                Log.testCaseResult();
                masteryFilterComponent.selectSkillStandards( Constants.MasteryUI.SKILL_READING );


                SMUtils.logDescriptionTC( "Tc:07 Verify the Mastery Run Report button is disabled by default" );
                Log.assertThat( masterySummaryComponent.isRunReportBtnDisabled(), "The Mastery Run Report button is disabled by default", "The Mastery Run Report button is not disabled by default" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "Tc:08 Verify the Reset Filter button is present" );
                Log.assertThat( masteryFilterComponent.isresetBtnPresent(), "Reset Button is present", "Reset Button is not present" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "Tc:09 Verify the Mastery Run Report button is enabled after clicking on Run Report button" );
                masterySummaryComponent = masteryFilterComponent.applyFilter();
                Log.assertThat( !masterySummaryComponent.isRunReportBtnDisabled(), "The Mastery Run Report button is enabled after clicking on Run Report button", "The Mastery Run Report button is not enabled after clicking on Run Report button" );
                Log.testCaseResult();


                SMUtils.logDescriptionTC( "TC:10: Verify the detailed mastery status link is available next to the progress bar" );
                Log.assertThat( !masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED ).isEmpty(), "The detailed Mastery status link is available next to the progress bar",
                        "The detailed Mastery status link is not available next to the progress bar!" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "TC:11: Verify the first-level Strand can be expanded and collapsed for Subject -Math and Default Math Skill" );
                SMUtils.logDescriptionTC( "TC:12: Verify the progress bar gets collapsed when collapsing first-level Strand for Subject -Math and Default Math Skill" );
                masterySummaryComponent.clickFirstLevelStrandName();
                Log.assertThat( !masterySummaryComponent.isLOviewLinkPresenet(), "After Clicking collapse btn on First level strandName, the progress bar is collapsed",
                        "After Clicking collapse btn on First level strandName, the progress bar is not getting collapsed!" );
                masterySummaryComponent.clickFirstLevelStrandName();
                Log.assertThat( masterySummaryComponent.isLOviewLinkPresenet(), "After Clicking Expand btn on First level strandName, the progress bar gets displayed",
                        "After Clicking collapse btn on First level strandName, the progress bar is not getting displayed!" );
                Log.testCaseResult();

                SMUtils.logDescriptionTC( "Tc:13 Verify the Mastery Report opened in a new tab after clicking on Run Report button" );
                SMUtils.logDescriptionTC( "Tc:14 Verify the Mastery report is loaded in a new tab when user is clicked on Run Report button" );
                masterySummaryComponent.clickMasteryRunReportBtn();
            }



            Log.assertThat( masteryReport.isMasteryReportPageLoaded(), "Mastery Report Page is loaded Successfully", "Mastery Report Page is not loaded Successfully!!" );
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:15 Verify the header of the  Mastery Run Report contains Mastery in bold letters in the top left of the page");
            Log.assertThat(masteryReport.getMasteryHeader().equals(ReportsUIConstants.MASTERY_HEADER), "The mastery header is displayed in bold letters", "The mastery header is not displayed in bold letters");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:16 Verify the Student Name  is present in the Mastery Run Report");
            Log.assertThat(!masteryReport.getStudentName().isEmpty(), "The student name is displayed", "The student name is not displayed");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:17 Verify the Grade Level is present in the Mastery Run Report");
            Log.assertThat(!masteryReport.getGradeName().isEmpty(), "The grade is displayed", "The grade is not displayed");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:18 Verify the Assignments name is present in the Mastery Run Report");
            Log.assertThat(!masteryReport.getAssignmentName().isEmpty(), "The grade is displayed", "The grade is not displayed");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:19 Verify the Date and time is getting displayed in the Mastery Run Report under Report Run ");
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yy");
            String reportDate = dateFormat.format(new Date());
            Log.assertThat(masteryReport.getReportRunTime().contains(reportDate), "The today date " + reportDate + " is displayed as expected", "The today date " + reportDate + " is not displayed as expected");
            Log.assertThat(masteryReport.getReportRunTime().contains("AM") || masteryReport.getReportRunTime().contains("PM"), "The time is " + masteryReport.getReportRunTime() + "displayed as expected", "The time is " + masteryReport.getReportRunTime() + "not displayed as expected");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:20 Verify the Assigned Course Level, Current Course Level, IP Level, Time Spent, Total Sessions(Minimum of 1 Assessments), Average Session Time, Skill/Standard, Mastery Status, # of Skills Completed/Judged, # of Attempts column fields are available in Mastery Run Report page");
            Log.assertThat(masteryReport.getAssignmentsDetailsKey().containsAll(ReportsUIConstants.MASTERYREPORT_ASSIGNMENTDETAILS_LABELS), "The Assignment Details Key are getting displayed as Expected", "The Assignment Details Key are getting displayed as Expected!");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:21 Verify user is able to view the next students mastery data by clicking Next  button");
            String asgnNamebfrr = masteryReport.getStudentName();
            masteryReport.clickPaginationNextBtn();
            String asgnNameaftt = masteryReport.getStudentName();
            Log.assertThat(!asgnNamebfrr.equals(asgnNameaftt), "The next students mastery data is displaying by clicking Next button", "The next students mastery data is not displaying by clicking next button");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:22 Verify user is able to view the previous students mastery data by clicking Back button");
            String asgnNamebfr = masteryReport.getStudentName();
            masteryReport.clickPaginationBackBtn();
            String asgnNameaft = masteryReport.getStudentName();
            Log.assertThat(!asgnNamebfr.equals(asgnNameaft), "The previous students mastery data is displaying by clicking Back button", "The previous students mastery data is not displaying by clicking Back button");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:23 Verify user is able to go to respective students page by entering respective page number in the box provided neato \"Go to\" text & click on enter on the keyboard if we have multiple pages in the report generated");
            String assignmentNamebfr = masteryReport.getStudentName();
            masteryReport.setPaginationInput(ReportsUIConstants.VALID_PAGINATION_THREE);
            String assignmentNameAft = masteryReport.getStudentName();
            Log.assertThat(!assignmentNamebfr.equals(assignmentNameAft), "The student able to go to respective students page by entering respective page number", "The student not able to go to respective students page by entering respective page number");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:24 Verify the message \" Invalid\" is displayed   in Run Report while giving page number out of the bound  in the box provied near to \"Go to\" text ");
            masteryReport.setPaginationInput(ReportsUIConstants.INVALID_PAGINATION_INPUT);
            Log.assertThat(masteryReport.getPaginationError().equals(ReportsUIConstants.INVALID_PAGINATION_ERRMSG), "The pagination error message is displayed while giving page number out of the bound", "The pagination error message is not displayed while giving page number out of the bound");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:25 Verify the Legends displayed in the report page");
            Log.assertThat(masteryReport.getLegendHeading().equals(ReportsUIConstants.LEGEND_HEADER), "The legend header is available in reports output page", "The lengend header is not available in reports output page");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:26 Verify the Legends labels displayed in the report page");
            Log.assertThat(masteryReport.getLegendLabel().equals(ReportsUIConstants.MASTERYREPORT_LEGEND_LABELS), "The legend label is showing as expected", "The legend label is not showing as expected");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:27 Verify the Legends values displayed in the report page");
            Log.assertThat(masteryReport.getLegengLabelValuey().equals(ReportsUIConstants.MASTERYREPORT_LEGEND_LABELS_VALUES), "The legend label values are showing as expected", "The legend label values are not showing as expected");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:28 Verify the all Students Mastery Data Headers ");
            Log.assertThat(masteryReport.verifyMasteryHeaderTitles(), "The MasteryDetails Header titles are displayed as expected", "The MasteryDetails Header titles are not displayed as expected!");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:29 Verify the Mastery Skills/Standards values are getting diaplayed in the Mastery Skills/Standard Column");
            Log.message("The mastery Skills/Standard column present count is " + masteryReport.getMasteryStatusColumn().size());
            Log.assertThat(!masteryReport.getSkillOrStandardColumn().isEmpty(), "Mastery Skills/Standards values are getting displayed in the Mastery skills/standard column", "Mastery Skills/Standards values are not getting displayed in the Mastery skills/standard column!");

            SMUtils.logDescriptionTC("Tc:30 Verify the # of Skills Completed/Judged	values are present under # of Skills Completed/Judged column ");
            Log.message("The # of Skills Completed/Judged column value count is " + masteryReport.getSkillsCompletedColumn().size());
            Log.assertThat(masteryReport.getSkillsCompletedColumn().size() > 0, "The # of Skills Completed/Judged	values are present under # of Skills Completed/Judged column", "The # of Skills Completed/Judged values are not present under # of Skills Completed/Judged column!");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:31 Verify the Attempts column values are getting displayed under Attempts column");
            Log.message("The Attempts column value count is " + masteryReport.getNoofAttemptsColumn().size());
            Log.assertThat(masteryReport.getNoofAttemptsColumn().size() > 0, "The Attempts column values are getting displayed under Attempts column", "The Attempts column values are not getting displayed under Attempts column!");
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            if ( null != devTool ) {
                DevToolsUtils.closeMock( devTool );
            }
            Log.endTestCase();
            driver.quit();
        }

    }

}
