package com.savvas.sm.ui.mastery.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.Keys;
import java.util.Map;
import java.util.Objects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants.Graphql.MasteryReportOutput;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import com.savvas.sm.common.utils.ui.constants.ReportsUIConstants;

public class MasteryReportOutputPage extends LoadableComponent<MasteryReportOutputPage> {

	WebDriver driver;
	boolean isPageLoaded;
	public static List<Object> pageFactoryKey = new ArrayList<Object>();
	public static List<String> pageFactoryValue = new ArrayList<String>();
	public ElementLayer elementLayer;

	@IFindBy ( how = How.CSS, using = "report-viewer-header  h2", AI = false )
	private WebElement reportHeader;

	@FindBy ( css = "export-data-modal cel-modal.export-data-modal" )
	WebElement btnExportCSVGrantRoot;

	@FindBy(css="report-viewer-header h2.header")
	WebElement masteryHeader;

	@IFindBy ( how = How.CSS, using = "div.export-data-wrapper cel-radio-button-group", AI = false )
    WebElement allPages;
    
    @IFindBy ( how = How.CSS, using = "cel-modal-window[class='hydrated']", AI = false )
    WebElement crossCancel;
    
    @IFindBy ( how = How.CSS, using = "cel-modal-window.hydrated", AI = false )
    WebElement successMessegeText;
    
    @IFindBy ( how = How.XPATH, using = "//span[text()='Report viewer']", AI = false )
    public WebElement txtReportViewer;
    
    @FindBy ( css = "export-pdf-modal cel-modal.export-pdf-modal" )
    WebElement exportPDFs;
    
    @FindBy ( css = "export-data-modal cel-modal.export-data-modal" )
    WebElement exportCSV;
    //Child elements
    private String btnExportCSVRoot = "cel-button";
    private String btnExportCSV = "button";
    public static String childPDF = "cel-button";
    public static String gChildPDF = "cel-icon";
    public static String gGrandChildPDF = "svg";
    public static String pdftext = "span";
    public static String pdfPopUpText = "h1.header";
    public static String gChildAllPage = "cel-radio-button:nth-child(1)";
    public static String gChildCurrentPage = "cel-radio-button:nth-child(2)";
    public static String childAllPages = "label";
    public static String gchildCancel = "cel-button.cancel-button";
    public static String childCancel = "button span";
    public static String gchildOK = "cel-button.ok-button";
    public static String childButton = "button";
    public static String grandChildCrossIcon = "cel-icon-button.close-button";
    public static String gChildCrossIcon = "button.icon-button cel-icon";
    public static String ChildCrossIcon = "div.icon-inner svg.cel-icon";
    public static String childText = "div.context span";
    public static String gChildClose = "div.button-container cel-button";
    public static String pdfPopUpTextSuccess = "h2.header";
    public static String pdfChild = ".close-button.focusable-element.first-interactive.last-interactive.hydrated";

	@FindBy(css="h2.assignment-name.ml-3")
	WebElement studentName;

	@FindBy(css="h2.assignment-grade.ml-3")
	WebElement gradeValue;

	@FindBy(css="h2.assignment-group.ml-3")
	WebElement assignmentName;

	@FindBy(css="section.report-sub-header dl.detail-row dd")
	WebElement rptRunTime;

	@FindBy(css="h2.detail-row.ml-3")
	WebElement reportRunDetails;

	@FindBy(css="div.col-3.mastery-right-border dl dt")
	List<WebElement> assignmentDetailsTable ;

	@FindBy(css="div.col-3.mastery-right-border dl dd")
	List<WebElement> assignmentDetailsTableValue ;

	@FindBy(css="span.list-head")
	WebElement legend;

	@FindBy(css="dl.detail-row.legends dt")
	List<WebElement> legendTableKey ;

	@FindBy(css="dl.detail-row.legends dd")
	List<WebElement> legendTableValue ;

	@FindBy ( css = "tr.header > th:nth-child(1)" )
	WebElement skillorstandardtitle; 

	@FindBy ( css = "tr.header > th:nth-child(2)" )
	WebElement masterystatustitle; 

	@FindBy ( css = "tr.header > th:nth-child(3)" )
	WebElement skillscompletedtitle; 

	@FindBy ( css = "tr.header > th:nth-child(4)" )
	WebElement noofattemptstitle; 

	@FindBy(css="tr.header > th")
	List<WebElement> masteryDetailsHeader;

	@FindBy ( css = "tr td:nth-of-type(1)" )
	List<WebElement> skillsorstandardcolumn;

	@FindBy ( css = "tr td:nth-of-type(2)" )
	List<WebElement> masterystatuscolumn;

	@FindBy ( css = "tr td:nth-of-type(3)" )
	List<WebElement> skillscompletedcolumn;

	@FindBy ( css = "tr td:nth-of-type(4)" )
	List<WebElement> noofattemptscolumn;

	@FindBy ( css = "div.report-header span.error-message")
	WebElement paginationerrmsg; 

	@FindBy ( css = "div.report-header div.text-field-container input")
	WebElement paginationinput;

	@FindBy(css = "cel-button.back-btn")
	WebElement paginationBackBtn;

	@FindBy(css = "cel-button.next-btn")
	WebElement paginationNextBtn;

	@IFindBy ( how = How.CSS, using = "cel-modal.export-pdf-modal", AI = false )
	WebElement exportPDF;

	@IFindBy ( how = How.CSS, using = "div.export-data-wrapper p", AI = false )
	WebElement pageText;

	@Override
	protected void load() {
		isPageLoaded = true;
		SMUtils.waitForPageLoad( driver );
	}

	@Override
	protected void isLoaded() throws Error {
		if ( !isPageLoaded ) {
			Assert.fail();
		}
		if ( isPageLoaded && SMUtils.waitForElement( driver, this.reportHeader, 30 ) ) {
			if ( this.reportHeader.getText().trim().equalsIgnoreCase( MasteryReportOutput.REPORT_HEADER ) ) {
				Log.message( "Mastery Report output page - Loaded Properly." );
			} else {
				Log.fail( "Mastery Report output page did not Loaded Properly. Site might be down.", driver );
			}
		} else {
			Log.fail( "Mastery Report output page did not Loaded Properly. Site might be down.", driver );
		}
		elementLayer = new ElementLayer( driver );
	}

	public MasteryReportOutputPage() {}

	/**
	 * 
	 * @param driver
	 */
	public MasteryReportOutputPage( WebDriver driver ) {
		this.driver = driver;
		ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
		PageFactory.initElements( finder, this );
		elementLayer = new ElementLayer( driver );
	}

	/**
	 * To click the Export csv button
	 * 
	 * @return
	 */
	public ExportPopupComponent clickExportCSVButton() {
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 30 );
		} catch ( InterruptedException e2 ) {
			Log.message( "Issue in Spinner loading" );
		}
		SMUtils.waitForElement( driver, btnExportCSVGrantRoot, 30 );
		SMUtils.click( driver, SMUtils.getWebElementDirect( driver, btnExportCSVGrantRoot, btnExportCSVRoot, btnExportCSV ) );
		ExportPopupComponent exportPopupComponent = null;
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 50 );
			SMUtils.waitForElement( driver, btnExportCSVGrantRoot, 30 );
			SMUtils.click( driver, SMUtils.getWebElementDirect( driver, btnExportCSVGrantRoot, btnExportCSVRoot, btnExportCSV ) );
			exportPopupComponent = new ExportPopupComponent( driver ).get();
		} catch ( Exception e ) {
			try {
				Log.message( "Getting issue while clicking the csv button...Retrying!!!" + e );
				SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, btnExportCSVGrantRoot, btnExportCSVRoot, btnExportCSV ) );
				exportPopupComponent = new ExportPopupComponent( driver ).get();
			} catch ( Exception e1 ) {
				Log.fail( "Getting issue while clicking the csv button..." + e1 );
			}
		}
		return exportPopupComponent;
	}


	/**
	 * Verify 'Report Viewers' page
	 */
	public void verifyReportPage( WebDriver driver ) {
		List<String> windowHandles = new ArrayList<String>( driver.getWindowHandles() ); // switch window to report
		driver.switchTo().window( windowHandles.get( windowHandles.size() - 1 ) );
		boolean isDisplayedReportViewerText = SMUtils.waitForElement( driver, txtReportViewer );
		Log.softAssertThat( isDisplayedReportViewerText, "Navigate to 'Report Viewer' page Successfully ", "Failed to navigate 'Report Viewer' page" );
	}


	/**
	 * Verifing the Mastery Report page
	 */
	public boolean isMasteryReportPageLoaded() {
		SMUtils.waitForElement(driver, masteryHeader);
		boolean flag = false;
		if(SMUtils.isElementPresent(masteryHeader)) {
			flag= true;
			Log.message("Mastery Report OutputPage is loaded Successfully!!");
		}
		return flag;
	}

	/**
	 * To verify the  mastery report table titles
	 * 
	 * @return
	 */
	public boolean verifyMasteryHeaderTitles() {
		boolean flag=true;
		Log.message( "Verifying mastery header titles" );
		if ( skillorstandardtitle.getText().trim().equals(ReportsUIConstants.SKILLORSTANDARD_TITLE) ) {
			Log.pass( "The skillorstandardtitle text matches!" );
		} else {
			Log.fail( "The skillorstandardtitle text is not matching" );
		}

		if ( masterystatustitle.getText().trim().equals(ReportsUIConstants.MASTERYSTATUS_TITLE) ) {
			Log.pass( "The masterystatustitle text matches!" );
		} else {
			Log.fail( "The masterystatustitle text is not matching" );
		}
		Log.message(skillscompletedtitle.getText().trim());
		if ( skillscompletedtitle.getText().trim().equals(ReportsUIConstants.SKILLSCOMPLETED_TITLE) ) {
			Log.pass( "The skills completed title text matches!" );
		} else {
			Log.fail( "The skills completed title text is not matching" );
		}

		if ( noofattemptstitle.getText().trim().equals(ReportsUIConstants.NOOFATTEMPTS_TITLE) ) {
			Log.pass( "The no of attempts title text matches!" );
		} else {
			Log.fail( "The no of attempts title text is not matching" );
		}            

		return flag;
	}    

	public List<String> getSkillOrStandardColumn() {
		Log.message( "Getting Mastery Report getSkillOrStandard Column " );
		SMUtils.waitForElement( driver,skillorstandardtitle  );
		return skillsorstandardcolumn.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );

	}

	public List<String> getMasteryStatusColumn() {
		Log.message( "Getting Mastery Report getMasteryStatus Column" );
		SMUtils.waitForElement( driver,masterystatustitle  );
		return masterystatuscolumn.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );

	}

	public List<String> getSkillsCompletedColumn() {
		Log.message( "Getting Mastery Report getskillscompleted column " );
		SMUtils.waitForElement( driver,skillscompletedtitle  );
		return skillscompletedcolumn.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );

	}

	public String getLegendHeading() {
		SMUtils.waitForElement( driver, legend );
		return legend.getText();
	}

	public List<String> getAssignmentsDetailsKey() {
		Log.message( "Getting Keys are displayed " );
		return assignmentDetailsTable.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );

	}

	public String getMasteryHeader() {
		SMUtils.waitForElement( driver, masteryHeader );
		return masteryHeader.getText();
	}

	public String getStudentName() {
		SMUtils.waitForElement( driver, studentName );
		return studentName.getText();
	}

	public String getGradeName() {
		SMUtils.waitForElement( driver, gradeValue );
		return gradeValue.getText();
	}

	public String getAssignmentName() {
		SMUtils.waitForElement( driver, assignmentName );
		return assignmentName.getText();

	}

	public String getReportRunTime() {
		SMUtils.waitForElement( driver, rptRunTime );
		return rptRunTime.getText();

	}

	public void clickPaginationBackBtn() {
		SMUtils.waitForElement(driver, paginationBackBtn);
		SMUtils.click(driver, paginationBackBtn);
		SMUtils.nap(2);
	}

	public void clickPaginationNextBtn() {
		SMUtils.waitForElement(driver, paginationNextBtn);
		SMUtils.click(driver, paginationNextBtn);
		SMUtils.nap(2);
	}

	public List<String> getLegendLabel() {
		List<String> legendKey = new ArrayList<>();
		SMUtils.waitForElement( driver, legend );
		for ( WebElement legKey : legendTableKey ) {
			legendKey.add( legKey.getText().trim() );
		}
		return legendKey;
	}

	public List<String> getLegengLabelValuey() {
		List<String> legendLabValues = new ArrayList<>();
		SMUtils.waitForElement( driver, legend );
		for ( WebElement legValue : legendTableValue ) {
			legendLabValues.add( legValue.getText().trim() );
		}
		return legendLabValues;
	}

	public String getPaginationError() {
		SMUtils.waitForElement( driver, paginationerrmsg );
		return paginationerrmsg.getText();
	}

	public void setPaginationInput(String pagNo) {
		SMUtils.waitForElement(driver, paginationinput);
		paginationinput.clear();
		paginationinput.sendKeys(pagNo);
		paginationinput.sendKeys(Keys.ENTER);
		SMUtils.nap(2);
	}

	public List<String> getNoofAttemptsColumn() {
		Log.message( "Getting Mastery Report getNoofAttempts Column" );
		SMUtils.waitForElement( driver,noofattemptstitle  );
		return noofattemptscolumn.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );
	}

	/**
	 * Click on PDF
	 */
	public void clickOnPDF() {

		SMUtils.waitForElement( driver, exportPDF );
		WebElement childElement = SMUtils.getWebElement( driver, exportPDF, childPDF );
		WebElement gchildElement = SMUtils.getWebElement( driver, childElement, gChildPDF );
		WebElement actualElement = SMUtils.getWebElement( driver, gchildElement, gGrandChildPDF );
		Log.message( "Click on PDF icon" );
		SMUtils.click( driver, actualElement );

	}

	/**
	 * Validate PDF icon
	 * 
	 * @return
	 */
	public Boolean validatePDFIcon() {
		SMUtils.waitForElement( driver, exportPDF );
		WebElement childElement = SMUtils.getWebElement( driver, exportPDF, childPDF );
		WebElement gchildElement = SMUtils.getWebElement( driver, childElement, gChildPDF );
		WebElement actualElement = SMUtils.getWebElement( driver, gchildElement, gGrandChildPDF );
		Log.message( "Verifying pDF icon displaying" );
		return actualElement.isDisplayed();
	}

	/**
	 * Get PDF text
	 * 
	 * @return
	 */
	public String getPDFText() {

		SMUtils.waitForElement( driver, exportPDF );
		WebElement childElement = SMUtils.getWebElement( driver, exportPDF, childPDF );
		WebElement actualElement = SMUtils.getWebElement( driver, childElement, pdftext );
		Log.message( "Getting text for PDF" );
		return actualElement.getText().trim();
	}

	/**
	 * Get Text Export PDF Pop up Text
	 * 
	 * @return
	 */
	public String validateExportPDFPopUPText() {

		SMUtils.waitForElement( driver, exportPDF );
		WebElement actualElement = SMUtils.getWebElement( driver, exportPDF, pdfPopUpText );
		Log.message( "Getting text for Export PDF pop Up" );
		return actualElement.getText().trim();
	}

	/**
	 * Get the pages PDF text
	 * 
	 * @return
	 */
	public String validatePageText() {

		SMUtils.waitForElement( driver, pageText );
		Log.message( "Getting text fo Pages on export PDF" );
		return pageText.getText().trim();
	}

	/**
	 * 
	 * @return
	 */
	public String validateAllPageText() {

		SMUtils.waitForElement( driver, allPages );
		WebElement childElement = SMUtils.getWebElement( driver, allPages, gChildAllPage );
		WebElement actualElement = SMUtils.getWebElement( driver, childElement, childAllPages );
		Log.message( "Getting All Pages text" );
		return actualElement.getText().trim();
	}

	/**
	 * 
	 * @return
	 */
	public String validateCurrentPageText() {

		SMUtils.waitForElement( driver, allPages );
		WebElement childElement = SMUtils.getWebElement( driver, allPages, gChildCurrentPage );
		WebElement actualElement = SMUtils.getWebElement( driver, childElement, childAllPages );
		Log.message( "Getting All Pages text" );
		return actualElement.getText().trim();
	}

	/**
	 * 
	 * @return
	 */
	public String validateCancelButton() {
		SMUtils.waitForElement( driver, exportPDF );
		WebElement childElement = SMUtils.getWebElement( driver, exportPDF, gchildCancel );
		WebElement actualElement = SMUtils.getWebElement( driver, childElement, childCancel );
		Log.message( "Getting text for Can cancel button" );
		return actualElement.getText().trim();
	}

	/**
	 * 
	 * @return
	 */
	public String validateOKButton() {
		SMUtils.waitForElement( driver, exportPDF );
		WebElement childElement = SMUtils.getWebElement( driver, exportPDF, gchildOK );
		WebElement actualElement = SMUtils.getWebElement( driver, childElement, childCancel );
		Log.message( "Getting text for Can OK button" );
		return actualElement.getText().trim();
	}

	/**
	 * Clicked on OK Button
	 */
	public void clickOkButton() {
		SMUtils.waitForElement( driver, exportPDF );
		WebElement childElement = SMUtils.getWebElement( driver, exportPDF, gchildOK );
		WebElement actualElement = SMUtils.getWebElement( driver, childElement, childButton );
		Log.message( "Clicking on OK Button" );
		SMUtils.click( driver, actualElement );

	}

	/**
	 * Clicked on Cancel Button
	 */
	public void clickCancelButton() {
		SMUtils.waitForElement( driver, exportPDF );
		WebElement childElement = SMUtils.getWebElement( driver, exportPDF, gchildCancel );
		WebElement actualElement = SMUtils.getWebElement( driver, childElement, childButton );
		Log.message( "Clicking on Cancel Button" );
		SMUtils.click( driver, actualElement );

	}

	/**
	 * Clicked on cross icon
	 */
	public void clickCrossIcon() {
		SMUtils.waitForElement( driver, exportPDF );
		WebElement gchildElement = SMUtils.getWebElement( driver, exportPDF, grandChildCrossIcon );
		WebElement childElement = SMUtils.getWebElement( driver, gchildElement, gChildCrossIcon );
		WebElement actualElement = SMUtils.getWebElement( driver, childElement, ChildCrossIcon );
		Log.message( "Clicking on Cross icon" );
		SMUtils.click( driver, actualElement );

	}

	/**
	 * Clicked on cross icon
	 */
	public void clickCrossButton() {
		SMUtils.waitForElement( driver, exportPDF );
		WebElement parentCross = SMUtils.getWebElement( driver, crossCancel, pdfChild );
		Log.message( "Clicking on Cross icon" );
		SMUtils.click( driver, parentCross );

	}

	/**
	 * Clicked on cross icon
	 */
	public Boolean isCrossButtonDisable() {
		SMUtils.waitForElement( driver, exportPDF );
		WebElement parentCross = SMUtils.getWebElement( driver, crossCancel, pdfChild );
		Log.message( "Corss icon is displaying with disbale mode" );
		return parentCross.isEnabled();

	}

	/**
	 * Clicked on cross icon
	 */
	public Boolean isCrossIconDisplayed() {
		SMUtils.waitForElement( driver, exportPDF );
		WebElement gchildElement = SMUtils.getWebElement( driver, exportPDF, grandChildCrossIcon );
		WebElement childElement = SMUtils.getWebElement( driver, gchildElement, gChildCrossIcon );
		WebElement actualElement = SMUtils.getWebElement( driver, childElement, ChildCrossIcon );
		Log.message( "Corss icon is displaying" );
		return actualElement.isDisplayed();

	}

	/**
	 * Getting text of success Message
	 * 
	 * @return
	 */
	public String getSuccessMessage() {
		SMUtils.waitForElement( driver, successMessegeText );
		WebElement childElement = SMUtils.getWebElement( driver, successMessegeText, childText );
		Log.message( "Getting text of success message" );
		return childElement.getText().trim();
	}

	/**
	 * Close button validation
	 * 
	 * @return
	 */
	public Boolean validateCloseButton() {
		SMUtils.waitForElement( driver, successMessegeText );
		WebElement childElement = SMUtils.getWebElement( driver, successMessegeText, gChildClose );
		WebElement actualElement = SMUtils.getWebElement( driver, childElement, childButton );
		Log.message( "Validate close button displaying" );
		return actualElement.isDisplayed();
	}

	/**
	 * Close button
	 * 
	 * @return
	 */
	public void clickCloseButton() {
		SMUtils.waitForElement( driver, successMessegeText );
		WebElement childElement = SMUtils.getWebElement( driver, successMessegeText, gChildClose );
		WebElement actualElement = SMUtils.getWebElement( driver, childElement, childButton );
		Log.message( "Clicked on close button" );
		SMUtils.click( driver, actualElement );
	}

	/**
	 * Get Text Export PDF Pop up Text after downloading the file
	 * 
	 * @return
	 */
	public String validateExportPDFPopUPTextForSucces() {
		SMUtils.waitForElement( driver, successMessegeText );
		WebElement actualElement = SMUtils.getWebElement( driver, successMessegeText, pdfPopUpTextSuccess );
		Log.message( "Getting text for Export PDF pop Up for sucessfull file" );
		return actualElement.getText().trim();
	}

	/**
	 * Close button validation
	 * 
	 * @return
	 */
	public Boolean verifyCloseButtonEnableOrDisable() {
		SMUtils.waitForElement( driver, successMessegeText );
		WebElement childElement = SMUtils.getWebElement( driver, successMessegeText, gChildClose );
		WebElement actualElement = SMUtils.getWebElement( driver, childElement, childButton );
		Log.message( "Validation close button is disable" );
		return actualElement.isEnabled();

	}

	/**
	 * Clicked on cross icon
	 */
	public Boolean isCrossIconDisable() {
		SMUtils.waitForElement( driver, exportPDF );
		WebElement gchildElement = SMUtils.getWebElement( driver, exportPDF, grandChildCrossIcon );
		WebElement childElement = SMUtils.getWebElement( driver, gchildElement, gChildCrossIcon );
		WebElement actualElement = SMUtils.getWebElement( driver, childElement, ChildCrossIcon );
		Log.message( "Corss icon is displaying with disbale mode" );
		return actualElement.isEnabled();

	}

	/**
	 * To check whether the file is downloaded or not
	 * 
	 * @param driver
	 * @return
	 */
	public  boolean isPDFFileDownloaded( WebDriver driver ) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		int itr = 0;
		do {
			try {
				if ( (boolean) jse.executeScript( "browserstack_executor: {\"action\": \"fileExists\"}" ) ) {
					Log.message( "PDF file is downloaded successfully!!!" );
					SMUtils.nap( 10 );
					return true;
				}
			} catch ( Exception e ) {
				Log.fail( "PDF file is not downloaded..Retrying!!!" );
				SMUtils.nap( 15 );
				itr++;
			}

		} while ( itr < 3 );
		return false;
	}

	/**
	 * To get the downloaded file name
	 * 
	 * @param driver
	 * @return
	 */
	public String getPdfFileNameFromBS( WebDriver driver ) {
		String fileName = null;
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		int itr = 0;
		do {
			try {
				Map<String, String> properties = (Map<String, String>) jse.executeScript( "browserstack_executor: {\"action\": \"getFileProperties\"}" );
				Log.message( properties.toString() );
				fileName = properties.get( "file_name" );
			} catch ( Exception e ) {
				e.getMessage();
				Log.message( "Issue on reading the file. Retrying...." );
				//Waiting for file downloading
				SMUtils.nap( 15 );
			}
			itr++;
		} while ( Objects.isNull( fileName ) && itr < 3 );
		return fileName;
	}

	/**
	 * To get the downloaded file name
	 * 
	 * @param driver
	 * @return
	 */
	public long getPdfFileSizeFromBS( WebDriver driver ) {
		String fileSizeStr = null;
		long fileSize = 0;
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		int itr = 0;
		do {
			try {
				Map<String, Object> properties = (Map<String, Object>) jse.executeScript( "browserstack_executor: {\"action\": \"getFileProperties\"}" );
				Log.message( properties.toString() );
				fileSizeStr = properties.get("size").toString();                
				if (!Objects.isNull(fileSizeStr) && !fileSizeStr.isEmpty())
				{
					fileSize= Long.parseLong(fileSizeStr);
				}

			} catch ( Exception e ) {
				e.getMessage();
				Log.message( "Issue on reading the file. Retrying...." );
				//Waiting for file downloading
				SMUtils.nap( 15 );
			}
			itr++;
		} while ( Objects.isNull( fileSizeStr ) && itr < 3 );
		return fileSize;
	}

	/**
	 * Clicked on current page radio Button
	 */
	public void clickCurrentPageRadioButton() {
		SMUtils.waitForElement( driver, exportPDF );
		WebElement childElement = SMUtils.getWebElement( driver, allPages, gChildCurrentPage );
		WebElement actualElement = SMUtils.getWebElement( driver, childElement, childAllPages );
		Log.message( "Clicking on radio Button" );
		SMUtils.click( driver, actualElement );

	}

    
    /**
     * Get current URL for report viewer page
     * 
     * @return
     */
    public String getReportViewerURL() {

        String URL = driver.getCurrentUrl();
        String actualURL = URL + System.nanoTime();
        Log.message( "Getting URL for report viewr page" );
        return actualURL;
    }

    /**
     * Launching report viewr page again
     */
    public void launchURLWithWrongRequestID() {
        
        SMUtils.nap( 2 );// This wait is required to load report viewr page
        String launchingURL = getReportViewerURL();
        Log.message( "Launching URL again after adding wrong request ID in URL" );
        driver.navigate().to( launchingURL );
        SMUtils.nap( 2 );// This wait is required to load report viewr page

    }

    /**
     * Getting status of PDF button when error message pops up
     * 
     * @return
     */
    public String getPDFButtonDisabled() {

        SMUtils.waitForElement( driver, exportPDFs );
        String attributeValue = exportPDFs.getAttribute("class");
        Log.message( "Getting attribute value for disabled mode PDF" );
        return attributeValue;
    }
    
    /**
     * Getting status of CSV button when error message pops up
     * 
     * @return
     */
    public String getCSVButtonDisabled() {

        SMUtils.waitForElement( driver, exportCSV );
        String attributeValue = exportCSV.getAttribute("class");
        Log.message( "Getting attribute value for disabled mode PDF" );
        return attributeValue;

    }
}

