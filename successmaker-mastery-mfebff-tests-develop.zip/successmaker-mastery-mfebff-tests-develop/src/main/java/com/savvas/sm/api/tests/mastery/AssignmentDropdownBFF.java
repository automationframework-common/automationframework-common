package com.savvas.sm.api.tests.mastery;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.api.pojo.mastery.GetAssignmentsMasteryBff;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.apiconstants.MasteryAPIConstants;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sql.helper.AssignmentTable.AssignmentMastery;

import io.restassured.response.Response;

/**
 * Method for testing the realTime assignments data in the GraphQL call
 * 
 * @author durgaPrasad
 */

public class AssignmentDropdownBFF extends BaseAPITest {

	public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    public static String teacherDetails = null;
    public static String teacherUserName, teacherUserId;
    public static String studentDetails1 = null;
    public static String studentUserName1, studentUserId1;
	String MATH_SUBJECT_ID = "1";
	String READING_SUBJECT_ID = "2";
	String INVALID_SUBJECT_ID = "3";
	String subject_Id;
	String orgId;
	
@BeforeClass
public void before() {
	orgId =  MasteryDataSetup.orgId;
    teacherUserName =  MasteryDataSetup.teacherUserName;
    teacherUserId = MasteryDataSetup.teacherUserId;

    // Fetching Student Details
    studentUserId1 = MasteryDataSetup.studentUserId1; 
    studentUserName1 = MasteryDataSetup.studentUserName1;
    
}

	@Test( dataProvider = "getDataForPostivieScenarios", groups = { "SMK-59840",
			"(Graphql) BFF Assignments api integration - real", "GraphQL", "BFF" }, priority = 1 )
	public void getAssignemntsTest001( String testcaseName, String expected_StatusCode, String testcaseDescription,
			String scenarioType, String expected_subjectId ) throws Exception {

		// headers
		Map<String, String> headers = new HashMap<String, String>();
		headers.put( Constants.AUTHORIZATION,
				Constants.BEARER
						+ new RBSUtils().getAccessToken(teacherUserName,
								MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
		headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.ORG_ID,
				orgId );
		headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.USER_ID,
				teacherUserId );
		headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

		String organizationId = orgId;
		String userId = teacherUserId;

		// For Constructing QueryItems in request PayLoad
		List<String> queryItems = new ArrayList<String>();
		String queryItem = null;

		Log.testCaseInfo( testcaseName + testcaseDescription );
		switch ( scenarioType ) {

		case "ALL_QUERY_ITEMS":
			subject_Id = MATH_SUBJECT_ID;
			queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ASSIGNER_FIRST_NAME );
			queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ASSIGNER_LAST_NAME );
			queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ID );
			queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_NAME );
			queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.SUBJECT_ID );
			queryItem = constructQueryItems( queryItems );
			break;

		case "MULTIPLE_QUERY_ITEMS":
			subject_Id = MATH_SUBJECT_ID;
			queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ASSIGNER_FIRST_NAME );
			queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.SUBJECT_ID );
			queryItem = constructQueryItems( queryItems );
			break;

		case "SINGLE_QUERY_ITEMS":
			subject_Id = MATH_SUBJECT_ID;
			queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.SUBJECT_ID );
			queryItem = constructQueryItems( queryItems );
			break;

		}

		String payload = String.format( MasteryAPIConstants.Mastery_GraphQL_Assignments.REQ_PAYLOAD, organizationId,
				userId, subject_Id, queryItem );
		Log.message("Payload - " + payload);
		Response response = RestAssuredAPIUtil.POSTGraphQl( MasteryConstants.Graphql.skillsandStandards.BASE_URL,
				headers, payload, MasteryConstants.Graphql.skillsandStandards.ENDPOINT );
		Log.message( "Response - " + response.getBody().asString() );
		String body = SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" );
		String assignments = SMUtils.getKeyValueFromResponse( body, "assignments" );
		Object subjectId = new JSONArray(assignments).getJSONObject(0).get("subjectId");

		Log.assertThat(subjectId.equals(expected_subjectId), "The actual subject id "+subjectId+" is same as expected subject id " + expected_subjectId, 
				"The actual subject id "+subjectId+" is not the same as expected subject id " + expected_subjectId);
		
		Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ),
				"The actual status code " + response.getStatusCode() + "is the same as expected status code "
						+ expected_StatusCode,
				"The actual status code " + response.getStatusCode() + "is not the same as expected status code "
						+ expected_StatusCode );

	}

	@Test(dataProvider = "getDataForNegativeScenarios", groups = { "SMK-59840",
			"(Graphql) BFF Assignments api integration - real", "GraphQL", "BFF" }, priority = 1)
	public void getAssignemntsTest002(String testcaseName, String expected_StatusCode, String testcaseDescription,
			String scenarioType) throws Exception {

		// headers
		Map<String, String> headers = new HashMap<String, String>();
		// For Constructing QueryItems in request PayLoad
		List<String> queryItems = new ArrayList<String>();
		String queryItem = null;

		String organizationId = null;
		String userId = null;
		Log.testCaseInfo( testcaseName + testcaseDescription );
		switch ( scenarioType ) {

		case "INVALID_AUTH":
		    headers.put( Constants.AUTHORIZATION,
                     new RBSUtils().getAccessToken( teacherUserName,
                                    MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD + 1 ));
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.ORG_ID,
                    orgId );
            headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.USER_ID,
                    teacherUserId );
            organizationId = MasteryAPIConstants.Mastery_GraphQL_Assignments.INVALID_ORG_ID_VALUE;
            userId = teacherUserId;
            subject_Id = MATH_SUBJECT_ID;
            queryItems.add( MasteryConstants.Graphql.skillsandStandards.ASSIGNMENT_NAME );
            queryItem = constructQueryItems( queryItems );
            break;

		case "INVALID_PAYLOAD":
			headers.put( Constants.AUTHORIZATION,
					Constants.BEARER
							+ new RBSUtils().getAccessToken( teacherUserName,
									MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
			headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.ORG_ID,
					orgId );
			headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.USER_ID,
					teacherUserId );
			headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
			organizationId = orgId;
			userId = teacherUserId;
			subject_Id = READING_SUBJECT_ID;
			queryItems.add( "122" );
			queryItem = constructQueryItems( queryItems );
			break;

		case "STUDENT":
			headers.put( Constants.AUTHORIZATION,
					Constants.BEARER + new RBSUtils().getAccessToken(
					        studentUserName1,
							MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
			headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.ORG_ID,
					orgId );
			headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.USER_ID,
			        studentUserId1 );
			headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
			organizationId = orgId;
			userId = studentUserId1;
			subject_Id = READING_SUBJECT_ID;
			queryItems.add( MasteryConstants.Graphql.skillsandStandards.ASSIGNMENT_NAME );
			queryItem = constructQueryItems( queryItems );
			break;

		case "IRRESPECTIVE_ORG_ID":
			headers.put( Constants.AUTHORIZATION,
					Constants.BEARER + new RBSUtils().getAccessToken(
					        teacherUserName,
							MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
			headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.ORG_ID,
					orgId );
			headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.USER_ID,
					teacherUserId );
			headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
			organizationId = orgId + "1";
			userId = teacherUserId;
			subject_Id = READING_SUBJECT_ID;
			queryItems.add( MasteryConstants.Graphql.skillsandStandards.ASSIGNMENT_NAME );
			queryItem = constructQueryItems( queryItems );
			break;

		case "INVALID_SUBJECT_ID":
			headers.put( Constants.AUTHORIZATION,
					Constants.BEARER
							+ new RBSUtils().getAccessToken(teacherUserName,
									MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
			headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.ORG_ID,
					orgId );
			headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.USER_ID,
					teacherUserId );
			headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
			organizationId = orgId;
			userId = teacherUserId;
			subject_Id = INVALID_SUBJECT_ID;
			queryItems.add( MasteryConstants.Graphql.skillsandStandards.ASSIGNMENT_NAME );
			queryItem = constructQueryItems( queryItems );
			break;

		case "BUSSINESS_VIOLATION":
			headers.put( Constants.AUTHORIZATION,
					Constants.BEARER
							+ new RBSUtils().getAccessToken( teacherUserName,
									MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
			headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
			headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.ORG_ID,
					orgId );
			headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.USER_ID,
					teacherUserId );
			organizationId = MasteryAPIConstants.Mastery_GraphQL_Assignments.INVALID_ORG_ID_VALUE;
			userId = teacherUserId;
			subject_Id = MATH_SUBJECT_ID;
			queryItems.add( MasteryConstants.Graphql.skillsandStandards.ASSIGNMENT_NAME );
			queryItem = constructQueryItems( queryItems );
			break;
		}
		String payload = String.format( MasteryAPIConstants.Mastery_GraphQL_Assignments.REQ_PAYLOAD, organizationId,
				userId, subject_Id, queryItem );
		System.out.println( "*****" + payload );
		Response response = RestAssuredAPIUtil.POSTGraphQl( MasteryConstants.Graphql.skillsandStandards.BASE_URL,
				headers, payload, MasteryConstants.Graphql.skillsandStandards.ENDPOINT );
		Log.message( response.getBody().asString() );
		System.out.println( "********************" + response );
		Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ),
				"The actual status code " + response.getStatusCode() + "is the same as expected status code "
						+ expected_StatusCode,
				"The actual status code " + response.getStatusCode() + "is not the same as expected status code "
						+ expected_StatusCode );

		if ( scenarioType.equalsIgnoreCase( "INVALID_AUTH" )) {
			String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
			String message = getErrorMessage( error, "message" );
			Log.assertThat(message.equalsIgnoreCase( MasteryConstants.Graphql.skillsandStandards.UNAUTHORIZED_MESSAGE ),
					"Getting Unauthorized message for Invalid authorization",
					"The Unauthorized message is not getting displayed for Invalid Authorization!" );
		} else if ( scenarioType.equalsIgnoreCase( "STUDENT" )) {
			String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
			String message = getErrorMessage( error, "message" );
			Log.assertThat( message.equalsIgnoreCase(MasteryConstants.Graphql.skillsandStandards.ACCESS_DENIED ),
					"Getting Access Denied message for Invalid users ",
					"The Access Denied message is not getting displayed for Invalid users" );
		} else if ( scenarioType.contentEquals( "IRRESPECTIVE_ORG_ID" )) {
			String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
			String message = getErrorMessage( error, "message" );
			Log.assertThat( message.equalsIgnoreCase( MasteryConstants.Graphql.skillsandStandards.BAD_REQUEST1 ),
					"Getting Not authenticated message for Irrespective org's",
					"Getting Not authenticated message for  Irrespective org's" );

		} else if ( scenarioType.equalsIgnoreCase( "BUSSINESS_VIOLATION" )) {
			String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
			String message = getErrorMessage( error, "message" );
			Log.assertThat( message.contains( "400: Bad Request" ),
					"Getting Unauthorized message for Invalid authorization",
					"The Unauthorized message is not getting displayed for Invalid Authorization!" );

		}

	}

	// This method is for constructing the query Items for payload
	public String constructQueryItems( List<String> queryItems ) {
		String frameQuery = "{";
		for ( String item : queryItems ) {
			if ( frameQuery.endsWith( "{" ))
				frameQuery = frameQuery + item;
			else
				frameQuery = frameQuery + "," + item;
		}
		frameQuery = frameQuery + "}";
		return frameQuery;
	}

	@DataProvider
	public Object[][] getDataForPostivieScenarios() {
		Object[][] data = { { "SMK-26594 ", "200",
				"Verify the graphql response is obtaining the predictable result for all set of Fields for assignments query",
				"ALL_QUERY_ITEMS", "1" },
				{ "SMK-26595 ", "200",
						"Verify the graphql response is obtaining the predictable result for multiple set of Fields given below",
						"MULTIPLE_QUERY_ITEMS", "1" },
				{ "SMK-26596 ", "200", "Verify 200 status code and valid response when a single set query is given ",
						"SINGLE_QUERY_ITEMS", "1" } };

		return data;
	}

	@DataProvider
	public Object[][] getDataForNegativeScenarios() {
		Object[][] data = { { "SMK-26599", "200",
				"Verify '401: UnAuthorized' message in response when invalid Bearer token is given ", "INVALID_AUTH" },
				{ "SMK-26600", "400", "Verify '400: Bad Request' in response when invalid query has been given",
						"INVALID_PAYLOAD" },
				{ "SMK-26601", "200",
						"Verify 400 status code and response when invalid subject id is given in the query ",
						"INVALID_SUBJECT_ID" },
				{ "SMK-26602", "200",
						"Verify the user is not authorized message on the response when irrespective org is given the headers",
						"IRRESPECTIVE_ORG_ID" },
				{ "SMK-26605", "200",
						"Verify the BusinessRuleViolationException on the response when the headers and query set is not matching with given  query",
						"BUSSINESS_VIOLATION" },
				{ "SMK-26607", "200",
						"Verify the user is not authorized message on the response when studentid is given the headers and query",
						"STUDENT" }, };
		return data;
	}

	/**
	 * This method is used to compare the standards list from API response and
	 * DB-Table entries
	 * 
	 * @param listStandardVersionResponse
	 * @param listStandardVersionDB
	 * @return
	 */
	private boolean compareStandardsFromApiResponseAndDB( List<GetAssignmentsMasteryBff> listAssignmentResponse,
			List<AssignmentMastery> listAssignmentDB ) {
		boolean returnParam = false;
		// sort the values by ascending order pointing - StandardsID
		listAssignmentDB.sort( Comparator
				.comparing( com.savvas.sm.utils.sql.helper.AssignmentTable.AssignmentMastery::getAssignmentId ));
		listAssignmentResponse.sort( Comparator.comparing(GetAssignmentsMasteryBff::getAssignmentId ));

		// add to common list for comparison.
		// Since, comparing two list of different object is not possible
		List<String> commonListDB = new ArrayList<String>();
		List<String> commonListResponse = new ArrayList<String>();

		listAssignmentResponse.stream().forEachOrdered(c -> {
			commonListResponse.add( c.getAssignmentId() );
			commonListResponse.add( c.getAssignmentName() );
		});

		listAssignmentDB.stream().forEachOrdered(c -> {
			commonListDB.add(c.getAssignmentId());
			commonListDB.add(c.getAssignmentName());
		});
		Log.message( commonListDB + "" );
		Log.message( commonListResponse + "" );

		// compare
		returnParam = commonListDB.equals( commonListResponse );

		return returnParam;
	}

	// This method is extracting error message from response

	public String getErrorMessage( String jsonResponse, String message ) {
		String messageValue = "";
		try {
			JSONArray jsonArray = new JSONArray( jsonResponse );
			JSONObject jsonObject1 = jsonArray.getJSONObject(0);
			messageValue = jsonObject1.optString( message );

		} catch (JSONException e) {
			e.printStackTrace();
		}
		return messageValue;
	}

}
