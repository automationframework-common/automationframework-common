package com.savvas.sm.ui.tests.mastery;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.ui.mastery.pages.DevToolsUtils;
import com.savvas.sm.ui.mastery.pages.MasteryDetailsPage;
import com.savvas.sm.ui.mastery.pages.MasteryFiltersComponent;
import com.savvas.sm.ui.mastery.pages.MasteryMfePage;
import com.savvas.sm.ui.mastery.pages.MasteryPage;
import com.savvas.sm.ui.mastery.pages.MasterySummaryComponent;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

public class AdminMasteryMfeLOViewTest extends BaseTest {


	private String masteryMfeUrl;
	private String browser;
	private String Math_Assignment;
	private String masteryBFF;
    private String bffEndpoint;
    private String bff;
    
	RBSUtils rbsUtils;
    private static String usernameSuffixTest;
    
    private static String smUrl;
    public static String orgId;
    public static Map<String, String> adminDetails = new HashMap<>();
    public static Map<String, String> adminGroupDetails = new HashMap<>();

    public static String districtAdmin;
    public static String schoolAdmin;
    public static String multiSchoolAdmin;
    public static String subDistrictAdmin;

    public static String districtAdminDetails;
    public static String schoolAdminDetails;
    public static String multiSchoolAdminDetails;
    public static String subDistrictAdminDetails;

	@BeforeTest( alwaysRun = true )
	public void initTest(ITestContext context) {
		browser = configProperty.getProperty("BrowserPlatformToRun");
		if (  DevToolsUtils.isMock( context ) )  {
		
		    bff = MasteryConstants.Graphql.BASE_URL;
            bffEndpoint = MasteryConstants.Graphql.ENDPOINT;
            masteryBFF = bff + bffEndpoint;
		}   
		smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        rbsUtils = new RBSUtils();
        orgId = rbsUtils.getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );

        districtAdmin = String.format( RBSDataSetupConstants.DISTRICT_ADMIN_USERNAME, usernameSuffixTest );
        schoolAdmin = String.format( RBSDataSetupConstants.SCHOOL_ADMIN_USERNAME, usernameSuffixTest );
        multiSchoolAdmin = String.format( RBSDataSetupConstants.MULTI_SCHOOL_ADMIN_USERNAME, usernameSuffixTest );
        subDistrictAdmin = String.format( RBSDataSetupConstants.SUBDISTRICT_ADMIN_USERNAME, usernameSuffixTest );

        districtAdminDetails = rbsUtils.getUser( rbsUtils.getUserIDByUserName( districtAdmin ) );
        schoolAdminDetails = rbsUtils.getUser( rbsUtils.getUserIDByUserName( schoolAdmin ) );
        multiSchoolAdminDetails = rbsUtils.getUser( rbsUtils.getUserIDByUserName( multiSchoolAdmin ) );
        subDistrictAdminDetails = rbsUtils.getUser( rbsUtils.getUserIDByUserName( subDistrictAdmin ) );
	
	}

	@Test(priority = 1, dataProvider = "masteryLoViewValidation", groups = { "mastery", "P1", "masteryLOview", "mock" } )
	public void tcLOViewTest(String loginAs, String loginUrl, String loginUserName, ITestContext context ) throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo(loginAs + " Mastery LO View Test" + "<small><b><i>[" + browser + "]</b></i></small>");
		masteryMfeUrl = configProperty.getProperty(loginUrl);
        DevTools devTool = null;

		try {

			LoginWrapper.loginToMasteryMfe(driver, masteryMfeUrl, loginUserName, RBSDataSetupConstants.DEFAULT_PASSWORD);
			MasteryMfePage masteryMfePage = new MasteryMfePage(driver);
			MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();
			masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);
			masteryFiltersComponent.selectSkillStandards(Constants.MasteryUI.SKILL_MATH);
			MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();
			MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.clickLOLink();

			if (  DevToolsUtils.isMock( context ) ) {
                //mocking
                String responseJson = DevToolsUtils.readJsonResponse( "MasteryLoView.json" );
                devTool = DevToolsUtils.setResponse( driver, masteryBFF, "post", 200, responseJson );
                devTool.createSessionIfThereIsNotOne();
                Log.message( devTool.getCdpSession().toString() );
            }
			
			SMUtils.logDescriptionTC(
					"TC:02 : Verify the admin can able to see the SCO content belongs to the LO, when Math subject is chosen with skills");
			Log.assertThat(
					masteryDetailsPage.clickLearningObjectLink()
							.equalsIgnoreCase(masteryDetailsPage.learningObjectID.getText()),
					"The admin can able to see the SCO content belongs to the LO, when Math subject is chosen with skills",
					"The admin is not able to see the SCO content belongs to the LO, when Math subject is chosen with skills");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:03 : Verify the admin is not able to see the LO name, when Math subject is chosen with standards");
			masteryDetailsPage.clickChevronIcon();
			masteryFiltersComponent.expandToggle();
			masteryFiltersComponent.selectSkillStandards(Constants.MasteryUI.STANDARD_AIMSWEBPLUS_MATH);
			MasterySummaryComponent masterySummaryComponent1 = masteryFiltersComponent.applyFilter();
			MasteryDetailsPage masteryDetailsPage1 = masterySummaryComponent1.clickLOLink();
			SMUtils.waitForElement(driver, masteryDetailsPage1.learningObjectID);
			Log.assertThat(masteryDetailsPage1.learningObjectID.getText().equals(""),
					"The LO Link is not visible when Math subject is chosen with standards",
					"The LO Link is visible when Math subject is chosen with standards");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:04 : Verify the admin is not able to see the LO name, when Reading subject is chosen");
			masteryDetailsPage.clickChevronIcon();
			masteryFiltersComponent.expandToggle();
			masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_READING);
			MasterySummaryComponent masterySummaryComponent3 = masteryFiltersComponent.applyFilter();
			MasteryDetailsPage masteryDetailsPage3 = masterySummaryComponent3.clickLOLink();
			Log.assertThat(!masteryDetailsPage3.verifyLearningObjectLinkIsDisplayed(),
					"The LO Link is not visible when Reading subject is chosen with skills",
					"The LO Link is visible when Reading subject is chosen with skills");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:05 : Verify the admin is not able to see the LO name, when Reading subject is chosen with skills");
			masteryDetailsPage.clickChevronIcon();
			masteryFiltersComponent.expandToggle();
			masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_READING);
			masteryFiltersComponent.selectSkillStandards(Constants.MasteryUI.STANDARD_ALASKAENGLISH_READING);
			MasterySummaryComponent masterySummaryComponent4 = masteryFiltersComponent.applyFilter();
			MasteryDetailsPage masteryDetailsPage4 = masterySummaryComponent4.clickLOLink();
			Log.assertThat(!masteryDetailsPage4.verifyLearningObjectLinkIsDisplayed(),
					"The LO Link is not visible when Reading subject is chosen with standards",
					"The LO Link is visible when Reading subject is chosen with standards");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:06 : Verify the student name(first name, last name), Mastery Status, Skills Evaluated, Attemps fields in the Mastery details page");
			Log.assertThat(Constants.MasteryUI.masteryTableHeaders.equals(masteryDetailsPage.getStudentTableHeaders()),
					"The 'Student', 'Mastery Status', 'Skills Evaluated', 'Attempts' are available in the mastery header",
					"The 'Student', 'Mastery Status', 'Skills Evaluated', 'Attempts' are not available in the mastery header");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:07: Verify the student name fields are sorted in ascending by default in the Mastery details page");
			masteryDetailsPage.clickBackBtn();
			masteryFiltersComponent.expandToggle();
			masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);
			MasterySummaryComponent masterySummaryComponent11 = masteryFiltersComponent.applyFilter();
			List<WebElement> masteredProgressBars1 = masterySummaryComponent11
					.getProgressBarLink(Constants.MasteryUI.MASTERED);
			MasteryDetailsPage masteryDetailsPage11 = masterySummaryComponent11
					.navigateToLoViewPage(masteredProgressBars1.get(0));
			SMUtils.waitForElement(driver, masteryDetailsPage11.getStatusBadge());
			List<String> studentsName = masteryDetailsPage11.getStudentName("As_copy_Single_LO");
			Log.assertThat(studentsName.equals(SMUtils.sortList(studentsName)),
					"The student name fields are sorted in ascending by default in the Mastery details page",
					"The student name fields are not sorted in ascending by default in the Mastery details page");
			Log.testCaseResult();
			SMUtils.logDescriptionTC(
					"TC:08 : Verify the admin is able to sort the 'student name' field in descending order in the Mastery details page");
			SMUtils.clickJS(driver,
					masteryDetailsPage11.getWebElementForDetailsPageHeaders(Constants.MasteryUI.STUDENT_FIELD));
			SMUtils.waitForElement(driver, masteryDetailsPage11.getStatusBadge());
			List<String> studentDescending = masteryDetailsPage11.getStudentName("As_copy_Single_LO");
			Log.assertThat(studentDescending.equals(SMUtils.sortAndReverseList(studentsName)),
					"The student name fields are sorted in ascending by default in the Mastery details page",
					"The student name fields are not sorted in ascending by default in the Mastery details page");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:09 : Verify the admin is able to sort the 'Attempts field' in ascending order in the Mastery details page");
			SMUtils.clickJS(driver,
					masteryDetailsPage11.getWebElementForDetailsPageHeaders(Constants.MasteryUI.ATTEMPTS_FIELD));
			SMUtils.waitForElement(driver, masteryDetailsPage11.getStatusBadge());
			List<String> attemptsFieldAsc = masteryDetailsPage11.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.ATTEMPTS_FIELD);
			Log.assertThat(attemptsFieldAsc.equals(SMUtils.sortList(attemptsFieldAsc)),
					"The " + Constants.MasteryUI.ATTEMPTS_FIELD
							+ " fields are sorted in ascending in the Mastery details page",
					"The " + Constants.MasteryUI.ATTEMPTS_FIELD
							+ " fields are not sorted in ascending in the Mastery details page");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:10 : Verify the admin is able to navigate back to the Mastery view page when they click on the breadcrumb icon in the top of the Mastery detail page");
			masteryDetailsPage11.clickBackBtn();

			MasteryPage masteryPage1 = new MasteryPage(driver);
			Log.assertThat(masteryPage1.lblMasteryHeading.isDisplayed(),
					"The admin is able to navigate back to the Mastery view page when they click on the breadcrumb icon in the top of the Mastery detail page",
					"The admin is not able to navigate back to the Mastery view page when they click on the breadcrumb icon in the top of the Mastery detail page");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:11 : Verify the admin is able to sort the 'Mastery Status' field in ascending order in the Mastery details page");
			MasteryDetailsPage masteryDetailsPage41 = masterySummaryComponent4.clickLOLink();
			List<String> masteryStsBfrSortingAsc = masteryDetailsPage41.getRowValuesBasedOnTheColumn("Math_Assignment",
					Constants.MasteryUI.MASTERY_STATUS_FIELD);
			SMUtils.clickJS(driver,
					masteryDetailsPage41.getWebElementForDetailsPageHeaders(Constants.MasteryUI.MASTERY_STATUS_FIELD));
			SMUtils.waitForElement(driver, masteryDetailsPage41.getStatusBadge());
			List<String> masteryStatusAsc = masteryDetailsPage41.getRowValuesBasedOnTheColumn("Math_Assignment",
					Constants.MasteryUI.MASTERY_STATUS_FIELD);
			Log.assertThat(masteryStatusAsc.equals(SMUtils.sortList(masteryStsBfrSortingAsc)),
					"The " + Constants.MasteryUI.MASTERY_STATUS_FIELD
							+ " fields are sorted in ascending in the Mastery details page",
					"The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD
							+ " fields are not sorted in ascending in the Mastery details page");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:12 : Verify the admin is able to sort the 'Mastery Status' field in descending order in the Mastery details page");
			List<String> masteryStsBfrSortingDsc = masteryDetailsPage.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.MASTERY_STATUS_FIELD);
			SMUtils.clickJS(driver,
					masteryDetailsPage.getWebElementForDetailsPageHeaders(Constants.MasteryUI.MASTERY_STATUS_FIELD));
			SMUtils.waitForElement(driver, masteryDetailsPage.getStatusBadge());
			List<String> masteryStatusDesc = masteryDetailsPage.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.MASTERY_STATUS_FIELD);
			Log.assertThat(masteryStatusDesc.equals(SMUtils.sortAndReverseList(masteryStsBfrSortingDsc)),
					"The " + Constants.MasteryUI.MASTERY_STATUS_FIELD
							+ " fields are sorted in descending in the Mastery details page",
					"The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD
							+ " fields are not sorted in descending order in the Mastery details page");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:13: Verify the admin is able to sort the 'Skills Evaluated' field in ascending order in the Mastery details page");
			List<String> skillEvalBeforeSortingAsc = masteryDetailsPage.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.SKILLS_EVALUATED_FIELD);
			SMUtils.clickJS(driver,
					masteryDetailsPage.getWebElementForDetailsPageHeaders(Constants.MasteryUI.SKILLS_EVALUATED_FIELD));
			SMUtils.waitForElement(driver, masteryDetailsPage.getStatusBadge());
			List<String> skillsEvaluatedAsc = masteryDetailsPage.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.SKILLS_EVALUATED_FIELD);
			List<Integer> skillsEvaluatedAscExpectedInt = skillsEvaluatedAsc.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			List<Integer> skillsEvaluatedAscInt = skillEvalBeforeSortingAsc.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			Log.assertThat(skillsEvaluatedAscExpectedInt.equals(SMUtils.sortListInteger(skillsEvaluatedAscInt)),
					"The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD
							+ " fields are sorted in ascending in the Mastery details page",
					"The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD
							+ " fields are not sorted in ascending in the Mastery details page");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:14 : Verify the admin is able to sort the 'Skills Evaluated' field in descending order in the Mastery details page");
			List<String> skillEvalBeforeSortingDsc = masteryDetailsPage.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.SKILLS_EVALUATED_FIELD);
			SMUtils.clickJS(driver,
					masteryDetailsPage.getWebElementForDetailsPageHeaders(Constants.MasteryUI.SKILLS_EVALUATED_FIELD));
			SMUtils.waitForElement(driver, masteryDetailsPage.getStatusBadge());
			List<String> skillsEvaluatedDsc = masteryDetailsPage.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.SKILLS_EVALUATED_FIELD);
			List<Integer> skillsEvaluatedDscExpectedInt = skillsEvaluatedDsc.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			List<Integer> skillsEvaluatedDescInt = skillEvalBeforeSortingDsc.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			Log.assertThat(
					skillsEvaluatedDscExpectedInt.equals(SMUtils.sortAndReverseListInteger(skillsEvaluatedDescInt)),
					"The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD
							+ " fields are sorted in descending in the Mastery details page",
					"The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD
							+ " fields are not sorted in descending order in the Mastery details page");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:15 : Verify the admin is able to sort the 'Attempts field' in ascending order in the Mastery details page");
			List<String> attemptsFieldBeforeSortingDsc = masteryDetailsPage
					.getRowValuesBasedOnTheColumn(Math_Assignment, Constants.MasteryUI.ATTEMPTS_FIELD);
			SMUtils.clickJS(driver,
					masteryDetailsPage.getWebElementForDetailsPageHeaders(Constants.MasteryUI.ATTEMPTS_FIELD));
			SMUtils.waitForElement(driver, masteryDetailsPage.getStatusBadge());
			List<String> attemptsFieldAsc1 = masteryDetailsPage.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.ATTEMPTS_FIELD);
			List<Integer> attemptsFieldAscExpectedInt = attemptsFieldAsc1.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			List<Integer> attemptsFieldAscInt = attemptsFieldBeforeSortingDsc.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			Log.assertThat(attemptsFieldAscExpectedInt.equals(SMUtils.sortListInteger(attemptsFieldAscInt)),
					"The " + Constants.MasteryUI.ATTEMPTS_FIELD
							+ " fields are sorted in ascending order in the Mastery details page",
					"The " + Constants.MasteryUI.ATTEMPTS_FIELD
							+ " fields are not sorted in ascending order in the Mastery details page");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:16 : Verify the admin is able to sort the Attempts field in descending order in the Mastery details page");
			List<String> attemptsFieldBeforeSortingAsc = masteryDetailsPage
					.getRowValuesBasedOnTheColumn(Math_Assignment, Constants.MasteryUI.ATTEMPTS_FIELD);
			SMUtils.clickJS(driver,
					masteryDetailsPage.getWebElementForDetailsPageHeaders(Constants.MasteryUI.ATTEMPTS_FIELD));
			SMUtils.waitForElement(driver, masteryDetailsPage.getStatusBadge());
			List<String> attemptsFieldDesc = masteryDetailsPage.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.ATTEMPTS_FIELD);
			List<Integer> attemptsFieldDescExpectedInt = attemptsFieldDesc.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			List<Integer> attemptsFieldDescInt = attemptsFieldBeforeSortingAsc.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			Log.assertThat(attemptsFieldDescExpectedInt.equals(SMUtils.sortAndReverseListInteger(attemptsFieldDescInt)),
					"The " + Constants.MasteryUI.ATTEMPTS_FIELD
							+ " fields are sorted in descending order in the Mastery details page",
					"The " + Constants.MasteryUI.ATTEMPTS_FIELD
							+ " fields are not sorted in descending order in the Mastery details page");
			Log.testCaseResult();
			
		} catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            if ( null != devTool ) {
                DevToolsUtils.closeMock( devTool );
            }
            driver.quit();
        }

    }

		@Test(priority = 1, dataProvider = "masteryLoViewValidation", groups = { "mastery", "P1", "masteryLOview", "mock" } )
		public void tcLOMasteryViewTest(String loginAs, String loginUrl, String loginUserName, ITestContext context) throws Exception {
			// Get driver
			final WebDriver driver = WebDriverFactory.get(browser);
			Log.testCaseInfo(loginAs + " Mastery LO View Test" + "<small><b><i>[" + browser + "]</b></i></small>");
			masteryMfeUrl = configProperty.getProperty(loginUrl);
	        DevTools devTool = null;

			try {
				LoginWrapper.loginToMasteryMfe(driver, masteryMfeUrl, loginUserName, "testing123$");
				MasteryMfePage masteryMfePage = new MasteryMfePage(driver);
				MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();
				masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);
				masteryFiltersComponent.selectSkillStandards(Constants.MasteryUI.SKILL_MATH);
				MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();
				MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.clickLOLink();
				
	            if (  DevToolsUtils.isMock( context ) ) {
	                //mocking
	                String responseJson = DevToolsUtils.readJsonResponse( "MasteryLoView.json" );
	                devTool = DevToolsUtils.setResponse( driver, masteryBFF, "post", 200, responseJson );
	                devTool.createSessionIfThereIsNotOne();
	                Log.message( devTool.getCdpSession().toString() );
	            }

				SMUtils.logDescriptionTC(
						"TC 01 : Verify the admin is able to see the LO as a blue link, when Math subject is chosen with skills");
				Log.assertThat(masteryDetailsPage.getLOColor(browser).contentEquals(Constants.MasteryUI.LO_ID_COLOR_CODE),
						"admin is able to see the LO as a blue link",
						"admin is not able to see the LO as a blue link, when Math subject is chosen with skills");
				Log.testCaseResult();

				SMUtils.logDescriptionTC(
						"TC:17: Verify the Mastery status columnn values in red color for Not Mastered values for both Math/Reading courses skills or standards");
				SMUtils.logDescriptionTC(
						"TC:18: Verify the Mastery status columnn values in yellow color for At Risk values for both Math/Reading courses skills or standards");
				SMUtils.logDescriptionTC(
						"TC:19: Verify the Mastery status columnn values in green color for Mastered values for both Math/Reading courses skills or standards");

				Log.assertThat(masteryDetailsPage.verifyMasteryValueBGColor(browser),
						"All the mastery status values are displayed with respective color background",
						"All the mastery status values are not displayed with respective color background!");

				Log.testCaseResult();

				SMUtils.logDescriptionTC(
						"TC:20: Verify the Mastery status columnn values in Grey color for Not Assessed values for both Math/Reading courses skills or standards");
				Map<String, Map<String, Integer>> student_Status = masteryDetailsPage
						.getCountAndColorInProgressBar(browser);
				Log.assertThat(
						student_Status.get(Constants.MasteryUI.UNASSESSED)
								.containsKey(Constants.MasteryUI.UNASSESSED_COLOR_CODE),
						"The 'Unassessed' value in the Mastery Status columnn is displayed in Grey color",
						"The 'Unassessed' value in the Mastery Status columnn is not displayed as grey color");
				Log.testCaseResult();

			
			} catch ( Exception e ) {
	            Log.exception( e, driver );
	        } finally {
	            Log.endTestCase();
	            if ( null != devTool ) {
	                DevToolsUtils.closeMock( devTool );
	            }
	            driver.quit();
	        }

	    }

	@DataProvider(name = "masteryLoViewValidation")
	public Object[][] masterySummaryValidation() {

		Object[][] inputData = { 
				{ "singleadminlogin", "MasteryAdminSingleMfe", schoolAdmin },
				{ "multiadminlogin", "MasteryAdminMultiMfe", multiSchoolAdmin } 
				};
		return inputData;
	}

}
