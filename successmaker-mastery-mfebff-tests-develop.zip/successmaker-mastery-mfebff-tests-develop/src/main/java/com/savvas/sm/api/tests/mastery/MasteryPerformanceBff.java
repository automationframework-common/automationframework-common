package com.savvas.sm.api.tests.mastery;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.response.Response;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.MasteryAPIConstants;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.rbs.RBSUtils;

/**
 * This class is used to test the mastery performance BFF call for teacher users
 * 
 * @author aravindan.sivanandan
 *
 */
public class MasteryPerformanceBff extends EnvProperties {
    String studentIds;
    String subject_Id;
    int subject_Id_2;
    String assignmentIds;
    String standard_id;
    String limit;   
    String userName;
    String organizationId;


    @Test ( dataProvider = "getDataForPostivieScenarios", groups = { "SMK-51622", "(Automation) (Graphql) Mastery performance data API", "Bff", "GraphQL" }, priority = 1 )
    public void postMasteryPerformanceDetailsTest001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.Mastery_Performance_BFF.TEACHER_USER_NAME, MasteryAPIConstants.Mastery_Performance_BFF.PASSWORD ) );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( MasteryAPIConstants.Mastery_Performance_BFF.ORGANIZATION_ID, MasteryAPIConstants.Mastery_Performance_BFF.ORGANIZATION_ID_VALUE );
        headers.put( MasteryAPIConstants.Mastery_Performance_BFF.USER_ID, MasteryAPIConstants.Mastery_Performance_BFF.TEACHER_ID_VALUE );

        //Mandatory QueryItemList
        subject_Id = MasteryAPIConstants.Mastery_Performance_BFF.MATH_SUBJECT_ID;
        assignmentIds = MasteryAPIConstants.Mastery_Performance_BFF.ASSIGNMENT_ID_VALUE;
        standard_id = MasteryAPIConstants.Mastery_Performance_BFF.STANDARD_ID_VALUE;
        limit=  MasteryAPIConstants.Mastery_Performance_BFF.LIMIT_COUNT;
        

        //For Constructing QueryItems in request PayLoad
        List<String> queryItems = new ArrayList<String>();
        String queryItem = null;

        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {

            case "ALL_QUERY_ITEMS":
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TOP_PERFORMERS );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.MASTERY_PERCENT);
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TITLE + "}" ); 
                ;
              
                
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.LOW_PERFORMERS );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.MASTERY_PERCENT );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TITLE + "}"); 
                
                queryItem = constructQueryItems( queryItems );

                break;

            case "SINGLE_QUERY_ITEMS":
            	queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TOP_PERFORMERS );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.MASTERY_PERCENT );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TITLE + "}" );
                
                queryItem = constructQueryItems( queryItems );
                break;
                
                
            case "MATH_SUBJECT_ID":
            	queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TOP_PERFORMERS );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.MASTERY_PERCENT);
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TITLE + "}"); 
                
               
                queryItem = constructQueryItems( queryItems );
                subject_Id = MasteryAPIConstants.Mastery_Performance_BFF.MATH_SUBJECT_ID;
                break;

            case "READING_SUBJECT_ID":
            	queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TOP_PERFORMERS );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.MASTERY_PERCENT);
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TITLE + "}" );
                
                
                queryItem = constructQueryItems( queryItems );
                subject_Id_2 = Integer.parseInt( MasteryAPIConstants.Mastery_Performance_BFF.READING_SUBJECT_ID );
                break;
              
     
        }
        String payload = String.format( MasteryAPIConstants.Mastery_Performance_BFF.REQ_PAYLOAD_ALL_PARAMS, subject_Id,assignmentIds, standard_id, limit, queryItem );
        Response response = RestAssuredAPIUtil.POSTGraphQl( MasteryConstants.Graphql.skillsandStandards.BASE_URL, headers, payload, MasteryConstants.Graphql.skillsandStandards.ENDPOINT );
        Log.message( response.getBody().asString() );
        if ( scenarioType.equalsIgnoreCase( "ALL_QUERY_ITEMS" ) ) {
            Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                    "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "MasteryPerformanceBff", expected_StatusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );

        } else {
            Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                    "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );

        }

    }

    @Test ( dataProvider = "getDataForNegativeScenarios", groups = { "SMK-51622", "(Automation) (Graphql) Mastery performance data API", "Bff", "GraphQL" }, priority = 2 )
    public void postMasterySummaryDetailsTest002( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        //For Constructing QueryItems in request PayLoad
        List<String> queryItems = new ArrayList<String>();
        String queryItem = null;

        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {

            case "INVALID_ORG_ID":       
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.Mastery_Performance_BFF.TEACHER_USER_NAME, MasteryAPIConstants.Mastery_Performance_BFF.PASSWORD ) );
                headers.put( MasteryAPIConstants.Mastery_Performance_BFF.ORGANIZATION_ID, MasteryAPIConstants.Mastery_Performance_BFF.INVALID_ORG_ID_VALUE );
                headers.put( MasteryAPIConstants.Mastery_Performance_BFF.USER_ID,  MasteryAPIConstants.Mastery_Performance_BFF.TEACHER_ID_VALUE );

                //Mandatory QueryItemList
                subject_Id = MasteryAPIConstants.Mastery_Performance_BFF.MATH_SUBJECT_ID;
                assignmentIds = MasteryAPIConstants.Mastery_Performance_BFF.ASSIGNMENT_ID_VALUE;
                standard_id = MasteryAPIConstants.Mastery_Performance_BFF.STANDARD_ID_VALUE;
                limit=  MasteryAPIConstants.Mastery_Performance_BFF.LIMIT_COUNT;
                
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TOP_PERFORMERS );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TITLE + "}" );
                queryItem = constructQueryItems( queryItems );
                break;

            case "INVALID_USER_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.Mastery_Performance_BFF.TEACHER_USER_NAME, MasteryAPIConstants.Mastery_Performance_BFF.PASSWORD ) );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( MasteryAPIConstants.Mastery_Performance_BFF.ORGANIZATION_ID, MasteryAPIConstants.Mastery_Performance_BFF.ORGANIZATION_ID_VALUE );
                headers.put( MasteryAPIConstants.Mastery_Performance_BFF.USER_ID, MasteryAPIConstants.Mastery_Performance_BFF.INVALID_USER_ID_VALUE );

                //Mandatory QueryItemList
                subject_Id = MasteryAPIConstants.Mastery_Performance_BFF.MATH_SUBJECT_ID;
                assignmentIds = MasteryAPIConstants.Mastery_Performance_BFF.ASSIGNMENT_ID_VALUE;
                standard_id = MasteryAPIConstants.Mastery_Performance_BFF.STANDARD_ID_VALUE;
                limit=  MasteryAPIConstants.Mastery_Performance_BFF.LIMIT_COUNT;
                
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TOP_PERFORMERS );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TITLE + "}");
                queryItem = constructQueryItems( queryItems );

                break;

            case "ACCESS_DENIED":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.Mastery_Performance_BFF.CA_USER_NAME, MasteryAPIConstants.Mastery_Performance_BFF.PASSWORD ) );
                headers.put( MasteryAPIConstants.Mastery_Performance_BFF.ORGANIZATION_ID, MasteryAPIConstants.Mastery_Performance_BFF.ORGANIZATION_ID_VALUE );
                headers.put( MasteryAPIConstants.Mastery_Performance_BFF.USER_ID, MasteryAPIConstants.Mastery_Performance_BFF.TEACHER_ID_VALUE );

                //Mandatory QueryItemList
                subject_Id = MasteryAPIConstants.Mastery_Performance_BFF.MATH_SUBJECT_ID;
                assignmentIds = MasteryAPIConstants.Mastery_Performance_BFF.ASSIGNMENT_ID_VALUE;
                standard_id = MasteryAPIConstants.Mastery_Performance_BFF.STANDARD_ID_VALUE;
                limit=  MasteryAPIConstants.Mastery_Performance_BFF.LIMIT_COUNT;
                
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TOP_PERFORMERS );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TITLE+ "}" );
                queryItem = constructQueryItems( queryItems );
                break;

            case "INVALID_SUBJECT_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.Mastery_Performance_BFF.TEACHER_USER_NAME, MasteryAPIConstants.Mastery_Performance_BFF.PASSWORD ) );
                headers.put( MasteryAPIConstants.Mastery_Performance_BFF.ORGANIZATION_ID, MasteryAPIConstants.Mastery_Performance_BFF.ORGANIZATION_ID_VALUE );
                headers.put( MasteryAPIConstants.Mastery_Performance_BFF.USER_ID,  MasteryAPIConstants.Mastery_Performance_BFF.TEACHER_ID_VALUE );

                //Mandatory QueryItemList
                subject_Id = MasteryAPIConstants.Mastery_Performance_BFF.INVALID_SUBJECT_ID;
                assignmentIds = MasteryAPIConstants.Mastery_Performance_BFF.ASSIGNMENT_ID_VALUE;
                standard_id = MasteryAPIConstants.Mastery_Performance_BFF.STANDARD_ID_VALUE;
                limit=  MasteryAPIConstants.Mastery_Performance_BFF.LIMIT_COUNT;
                
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TOP_PERFORMERS );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TITLE + "}" );
                queryItem = constructQueryItems( queryItems );
                break;

            case "INVALID_PAYLOAD":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.Mastery_Performance_BFF.TEACHER_USER_NAME, MasteryAPIConstants.Mastery_Performance_BFF.PASSWORD ) );
                headers.put( MasteryAPIConstants.Mastery_Performance_BFF.ORGANIZATION_ID, MasteryAPIConstants.Mastery_Performance_BFF.ORGANIZATION_ID_VALUE );
                headers.put( MasteryAPIConstants.Mastery_Performance_BFF.USER_ID,  MasteryAPIConstants.Mastery_Performance_BFF.TEACHER_ID_VALUE );

                //Mandatory QueryItemList
                subject_Id = MasteryAPIConstants.Mastery_Performance_BFF.MATH_SUBJECT_ID;
                assignmentIds = MasteryAPIConstants.Mastery_Performance_BFF.ASSIGNMENT_ID_VALUE;
                standard_id = MasteryAPIConstants.Mastery_Performance_BFF.STANDARD_ID_VALUE;
                limit=  MasteryAPIConstants.Mastery_Performance_BFF.LIMIT_COUNT;
                
                queryItems.add( MasteryAPIConstants.Mastery_Performance_BFF.TOP_PERFORMERS + "{()}" );
                queryItem = constructQueryItems( queryItems );
                break;

        }
        String payload = String.format( MasteryAPIConstants.Mastery_Performance_BFF.REQ_PAYLOAD_ALL_PARAMS, subject_Id,assignmentIds, standard_id, limit, queryItem );
        Response response = RestAssuredAPIUtil.POSTGraphQl( MasteryConstants.Graphql.skillsandStandards.BASE_URL, headers, payload, MasteryConstants.Graphql.skillsandStandards.ENDPOINT );
        String errors = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
        Log.message( response.getBody().asString() );
        Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );
        if ( scenarioType.equalsIgnoreCase( "INVALID_USER_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( MasteryAPIConstants.Mastery_Performance_BFF.NOT_AUTHENTICATED ), "Getting Unauthorized message for Invalid authorization", "The Unauthorized message is not getting displayed for Invalid Authorization!" );
                  
        } else if ( scenarioType.equalsIgnoreCase( "INVALID_SUBJECT_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( MasteryAPIConstants.Mastery_Performance_BFF.INVALID_SUBJECT_ID_MESSAGE ), "Getting Invalid value passed for subjectId error message for invalid subject Id",
                    "Not getting Invalid value passed for subjectId error message for invalid subject Id!" );
        }  else if ( scenarioType.equalsIgnoreCase( "INVALID_PAYLOAD" ) ) {
            String message = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "message" );
            Log.assertThat( message.contains( MasteryAPIConstants.Mastery_Performance_BFF.BAD_REQUEST ), "Getting Bad request error message for invalid payload",
                    "Not getting bad request error message for invalid payload" );
        }
        
    }



    @DataProvider
    public Object[][] getDataForPostivieScenarios() {
        Object[][] data = { { "TC:01  ", "200", "Verify the graphql response is obtaining the predictable result for all set of Fields for Mastery Performance query", "ALL_QUERY_ITEMS" },
                { "TC:02  ", "200", "Verify the graphql response is obtaining the predictable result for single of Fields for Mastery Performance query", "SINGLE_QUERY_ITEMS" },
                { "TC:03  ", "200", "Verify the graphql response is obtaining the predictable result for Math Subject Id for Mastery Performance query", "MATH_SUBJECT_ID" },
                { "TC:04  ", "200", "Verify the graphql response is obtaining the predictable result for Reading Subject Id for Mastery Performance query", "READING_SUBJECT_ID" },

        };
        return data;
    }

    @DataProvider
    public Object[][] getDataForNegativeScenarios() {
        Object[][] data = { { "TC:05", "200", "Verify 403 status code and forbidden when invalid org-id is provided", "INVALID_ORG_ID" }, { "TC:06", "200", "Verify unauthorized message  when invalid user-id is provided", "INVALID_USER_ID" },
                { "TC:07", "200", "Verify access denied message when customer Admin ID is provided", "ACCESS_DENIED" }, { "TC:08", "200", "Verify invalid subject Id message when invalid subject-Id is provided", "INVALID_SUBJECT_ID" },
                { "TC:09", "400", "Verify bad request when invalid request payload is provided", "INVALID_PAYLOAD" },

        };
        return data;
    }

       //This method is for constructing the query Items for payload
    public String constructQueryItems( List<String> queryItems ) {
        String frameQuery = "{";
        for ( String item : queryItems ) {
            if ( frameQuery.endsWith( "{" ) )
                frameQuery = frameQuery + item;
            else
                frameQuery = frameQuery + "," + item;
        }
        frameQuery = frameQuery + "}";
        return frameQuery;
    }

    //This method is extracting error message from response

    public String getErrorMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
            messageValue = jsonObject1.optString( message );

        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }

}
