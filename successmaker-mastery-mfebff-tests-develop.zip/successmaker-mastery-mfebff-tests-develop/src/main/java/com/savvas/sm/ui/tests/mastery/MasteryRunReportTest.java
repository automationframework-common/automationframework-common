package com.savvas.sm.ui.tests.mastery;


import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.ui.constants.ReportsUIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.ui.mastery.pages.DevToolsUtils;
import com.savvas.sm.ui.mastery.pages.MasteryFiltersComponent;
import com.savvas.sm.ui.mastery.pages.MasteryMfePage;
import com.savvas.sm.ui.mastery.pages.MasteryReportOutputPage;
import com.savvas.sm.ui.mastery.pages.MasterySummaryComponent;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * This class is used to test the Mastery Run Report Output Screen
 *
 * @author madhan.nagarathinam
 */
public class MasteryRunReportTest extends EnvProperties {
    private String masteryMFE;
    private String browser;
    private String username;
    private String password;
    private String masteryBFF;
    private String masterBFF;
    private String reportMFE;

    @BeforeClass(alwaysRun = true)
    public void beforeTest() {
        username = MasteryDataSetup.teacherUserName;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        masteryMFE = configProperty.getProperty("MasteryTeacherMfe");
        browser = configProperty.getProperty("BrowserPlatformToRun");
        masteryBFF = "https://sm-reports-bff-srv-stack-dev.smdemo.info/graphql";
        reportMFE = configProperty.getProperty("MasteryReportMfe") + UUID.randomUUID();
    }


    @Test(description = "Verify the Mastery Output Run Report Page", groups = {"SMK-61720", "SMK-60517", "Mastery", "MasteryRunReport", "mock"}, priority = 1)
    public void tcMasteryRunReport001(ITestContext context) throws Exception {

        WebDriver driver = WebDriverFactory.get(browser);

        Log.testCaseInfo("tcMasteryRunReport: Verify the user can able to Navigate to Mastery Run Report page<small><b><i>[" + browser + "]</b></i></small>");

        DevTools devTool = null;
        try {
            
            MasteryReportOutputPage masteryReport;
            if (DevToolsUtils.isMock(context)) {
                //mocking
                Map<String, String> responses = new HashMap();
                String getReportOptionResponseJson = DevToolsUtils.readJsonResponse("GetReportOptionResponse.json");
                String masteryRunReportJson = DevToolsUtils.readJsonResponse("masteryRunReport.json");
                responses.put("GetReportOptionResponse", getReportOptionResponseJson);
                responses.put("GetMasteryReportData", masteryRunReportJson);

                List<String> requestPayloadMatchers = Arrays.asList("GetReportOptionResponse", "GetMasteryReportData");
                devTool = DevToolsUtils.setResponse(driver, masteryBFF, requestPayloadMatchers, "post", responses);
                devTool.createSessionIfThereIsNotOne();
                Log.message(devTool.getCdpSession().toString());
                
                LoginWrapper.loginToMasteryMfe(driver, reportMFE, username, password);
                masteryReport = new MasteryReportOutputPage(driver);
                
            } else {
            	LoginWrapper.loginToMasteryMfe(driver, masteryMFE, username, password);
    			MasteryMfePage masteryMfePage = new MasteryMfePage(driver).get();
    			MasteryFiltersComponent masteryFilterComponent = masteryMfePage.getMasteryFilterComponent();
    			masteryFilterComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);
    			masteryFilterComponent.selectSkillStandards(Constants.MasteryUI.SKILL_MATH);
    			MasterySummaryComponent masterySummaryComponent= new MasterySummaryComponent(driver);
    			masteryReport = new MasteryReportOutputPage(driver);
    			SMUtils.logDescriptionTC("Tc:01 Verify the Mastery Run Report button is disabled by default");
    			Log.assertThat(masterySummaryComponent.isRunReportBtnDisabled(), "The Mastery Run Report button is disabled by default", "The Mastery Run Report button is not disabled by default");
    			Log.testCaseResult();
    			
    			SMUtils.logDescriptionTC("Tc:02 Verify the Mastery Run Report button is enabled after clicking on Run Report button");
    			masterySummaryComponent= masteryFilterComponent.applyFilter();
    			Log.assertThat(!masterySummaryComponent.isRunReportBtnDisabled(), "The Mastery Run Report button is enabled after clicking on Run Report button", "The Mastery Run Report button is not enabled after clicking on Run Report button");
    			Log.testCaseResult();
    			
    			SMUtils.logDescriptionTC("Tc:03 Verify the Mastery Report opened in a new tab after clicking on Run Report button");
    			SMUtils.logDescriptionTC("Tc:04 Verify the Mastery report is loaded in a new tab when user is clicked on Run Report button");
    			masterySummaryComponent.clickMasteryRunReportBtn();
            }

            Log.assertThat(masteryReport.isMasteryReportPageLoaded(), "Mastery Report Page is loaded Successfully", "Mastery Report Page is not loaded Successfully!!");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:05 Verify the header of the  Mastery Run Report contains Mastery in bold letters in the top left of the page");
            Log.assertThat(masteryReport.getMasteryHeader().equals(ReportsUIConstants.MASTERY_HEADER), "The mastery header is displayed in bold letters", "The mastery header is not displayed in bold letters");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:06 Verify the Student Name , Grade Level and the Assignments name is present in the Mastery Run Report");
            Log.assertThat(!masteryReport.getStudentName().isEmpty(), "The student name is displayed", "The student name is not displayed");
            Log.assertThat(!masteryReport.getGradeName().isEmpty(), "The grade is displayed", "The grade is not displayed");
            Log.assertThat(!masteryReport.getAssignmentName().isEmpty(), "The grade is displayed", "The grade is not displayed");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:07 Verify the Date and time is getting displayed in the Mastery Run Report under Report Run ");
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yy");
            String reportDate = dateFormat.format(new Date());
            Log.assertThat(masteryReport.getReportRunTime().contains(reportDate), "The today date " + reportDate + " is displayed as expected", "The today date " + reportDate + " is not displayed as expected");
            Log.assertThat(masteryReport.getReportRunTime().contains("AM") || masteryReport.getReportRunTime().contains("PM"), "The time is " + masteryReport.getReportRunTime() + "displayed as expected", "The time is " + masteryReport.getReportRunTime() + "not displayed as expected");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:08 Verify the Assigned Course Level, Current Course Level, IP Level, Time Spent, Total Sessions(Minimum of 1 Assessments), Average Session Time, Skill/Standard, Mastery Status, # of Skills Completed/Judged, # of Attempts column fields are available in Mastery Run Report page");
            Log.assertThat(masteryReport.getAssignmentsDetailsKey().containsAll(ReportsUIConstants.MASTERYREPORT_ASSIGNMENTDETAILS_LABELS), "The Assignment Details Key are getting displayed as Expected", "The Assignment Details Key are getting displayed as Expected!");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:09 Verify user is able to view the next students mastery data by clicking Next  button");
            String asgnNamebfrr = masteryReport.getAssignmentName();
            masteryReport.clickPaginationNextBtn();
            String asgnNameaftt = masteryReport.getAssignmentName();
            Log.assertThat(!asgnNamebfrr.equals(asgnNameaftt), "The next students mastery data is displaying by clicking Next button", "The next students mastery data is not displaying by clicking next button");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:10 Verify user is able to view the previous students mastery data by clicking Back button");
            String asgnNamebfr = masteryReport.getAssignmentName();
            masteryReport.clickPaginationBackBtn();
            String asgnNameaft = masteryReport.getAssignmentName();
            Log.assertThat(!asgnNamebfr.equals(asgnNameaft), "The previous students mastery data is displaying by clicking Back button", "The previous students mastery data is not displaying by clicking Back button");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:11 Verify user is able to go to respective students page by entering respective page number in the box provided neato \"Go to\" text & click on enter on the keyboard if we have multiple pages in the report generated");
            String assignmentNamebfr = masteryReport.getAssignmentName();
            masteryReport.setPaginationInput(ReportsUIConstants.VALID_PAGINATION_THREE);
            String assignmentNameAft = masteryReport.getAssignmentName();
            Log.assertThat(!assignmentNamebfr.equals(assignmentNameAft), "The student able to go to respective students page by entering respective page number", "The student not able to go to respective students page by entering respective page number");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:12 Verify the message \" Invalid\" is displayed   in Run Report while giving page number out of the bound  in the box provied near to \"Go to\" text ");
            masteryReport.setPaginationInput(ReportsUIConstants.INVALID_PAGINATION_INPUT);
            Log.assertThat(masteryReport.getPaginationError().equals(ReportsUIConstants.INVALID_PAGINATION_ERRMSG), "The pagination error message is displayed while giving page number out of the bound", "The pagination error message is not displayed while giving page number out of the bound");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:13 Verify the Legends displayed in the report page");
            Log.assertThat(masteryReport.getLegendHeading().equals(ReportsUIConstants.LEGEND_HEADER), "The legend header is available in reports output page", "The lengend header is not available in reports output page");
            Log.assertThat(masteryReport.getLegendLabel().equals(ReportsUIConstants.MASTERYREPORT_LEGEND_LABELS), "The legend label is showing as expected", "The legend label is not showing as expected");
            Log.assertThat(masteryReport.getLegengLabelValuey().equals(ReportsUIConstants.MASTERYREPORT_LEGEND_LABELS_VALUES), "The legend label values are showing as expected", "The legend label values are not showing as expected");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:14 Verify the all Students Mastery Data Headers ");
            Log.assertThat(masteryReport.verifyMasteryHeaderTitles(), "The MasteryDetails Header titles are displayed as expected", "The MasteryDetails Header titles are not displayed as expected!");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:15 Verify the Mastery Skills/Standards values are getting diaplayed in the Mastery Skills/Standard Column");
            Log.message("The mastery Skills/Standard column present count is " + masteryReport.getMasteryStatusColumn().size());
            Log.assertThat(!masteryReport.getSkillOrStandardColumn().isEmpty(), "Mastery Skills/Standards values are getting displayed in the Mastery skills/standard column", "Mastery Skills/Standards values are not getting displayed in the Mastery skills/standard column!");

            SMUtils.logDescriptionTC("Tc:16 Verify the Mastery status values are getting displayed in the Mastery Status Column");
            Log.message("The Mastery status colum present count is " + masteryReport.getMasteryStatusColumn().size());
            List<String> ab = masteryReport.getMasteryStatusColumn();
            Log.message(ab + "");
            //Log.assertThat(ReportsUIConstants.MASTERYREPORT_MASTERY_STATUS_VALUES.contains(masteryReport.getMasteryStatusColumn()), "The Mastery Status Values are getting displayed in the Mastery status column", "The Mastery Status column values are not getting displayed under Mastery status column!");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:17 Verify the # of Skills Completed/Judged	values are present under # of Skills Completed/Judged column ");
            Log.message("The # of Skills Completed/Judged column value count is " + masteryReport.getSkillsCompletedColumn().size());
            Log.assertThat(masteryReport.getSkillsCompletedColumn().size() > 0, "The # of Skills Completed/Judged	values are present under # of Skills Completed/Judged column", "The # of Skills Completed/Judged values are not present under # of Skills Completed/Judged column!");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:18 Verify the Attempts column values are getting displayed under Attempts column");
            Log.message("The Attempts column value count is " + masteryReport.getNoofAttemptsColumn().size());
            Log.assertThat(masteryReport.getNoofAttemptsColumn().size() > 0, "The Attempts column values are getting displayed under Attempts column", "The Attempts column values are not getting displayed under Attempts column!");
            Log.testCaseResult();

        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            if (null != devTool) {
                DevToolsUtils.closeMock(devTool);
            }
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test(description = "Verify the Mastery Output Run Report Page", groups = {"SMK-61720", "SMK-60517", "Mastery", "MasteryRunReport", "mock"}, priority = 1)
    public void tcMasteryRunReport002(ITestContext context) throws Exception {

        WebDriver driver = WebDriverFactory.get(browser);

        Log.testCaseInfo("tcMasteryRunReport: Verify the user can able to Navigate to Mastery Run Report page<small><b><i>[" + browser + "]</b></i></small>");

        DevTools devTool = null;
        try {
            
            MasteryReportOutputPage masteryReport;
            if (DevToolsUtils.isMock(context)) {
                //mocking
                Map<String, String> responses = new HashMap();
                String getReportOptionResponseJson = DevToolsUtils.readJsonResponse("GetReportOptionResponse.json");
                String masteryRunReportJson = DevToolsUtils.readJsonResponse("masteryRunReportReading.json");
                responses.put("GetReportOptionResponse", getReportOptionResponseJson);
                responses.put("GetMasteryReportData", masteryRunReportJson);

                List<String> requestPayloadMatchers = Arrays.asList("GetReportOptionResponse", "GetMasteryReportData");
                devTool = DevToolsUtils.setResponse(driver, masteryBFF, requestPayloadMatchers, "post", responses);
                devTool.createSessionIfThereIsNotOne();
                Log.message(devTool.getCdpSession().toString());
                
                LoginWrapper.loginToMasteryMfe(driver, reportMFE, username, password);
                masteryReport = new MasteryReportOutputPage(driver);
                
            } else {
            	LoginWrapper.loginToMasteryMfe(driver, masteryMFE, username, password);
    			MasteryMfePage masteryMfePage = new MasteryMfePage(driver).get();
    			MasteryFiltersComponent masteryFilterComponent = masteryMfePage.getMasteryFilterComponent();
    			masteryFilterComponent.selectSubject(Constants.MasteryUI.SUBJECT_READING);
    			masteryFilterComponent.selectSkillStandards(Constants.MasteryUI.SKILL_READING);
    			MasterySummaryComponent masterySummaryComponent= new MasterySummaryComponent(driver);
    			masteryReport = new MasteryReportOutputPage(driver);
    			SMUtils.logDescriptionTC("Tc:01 Verify the Mastery Run Report button is disabled by default");
    			Log.assertThat(masterySummaryComponent.isRunReportBtnDisabled(), "The Mastery Run Report button is disabled by default", "The Mastery Run Report button is not disabled by default");
    			Log.testCaseResult();
    			
    			SMUtils.logDescriptionTC("Tc:02 Verify the Mastery Run Report button is enabled after clicking on Run Report button");
    			masterySummaryComponent= masteryFilterComponent.applyFilter();
    			Log.assertThat(!masterySummaryComponent.isRunReportBtnDisabled(), "The Mastery Run Report button is enabled after clicking on Run Report button", "The Mastery Run Report button is not enabled after clicking on Run Report button");
    			Log.testCaseResult();
    			
    			SMUtils.logDescriptionTC("Tc:03 Verify the Mastery Report opened in a new tab after clicking on Run Report button");
    			SMUtils.logDescriptionTC("Tc:04 Verify the Mastery report is loaded in a new tab when user is clicked on Run Report button");
    			masterySummaryComponent.clickMasteryRunReportBtn();
            }

            Log.assertThat(masteryReport.isMasteryReportPageLoaded(), "Mastery Report Page is loaded Successfully", "Mastery Report Page is not loaded Successfully!!");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:05 Verify the header of the  Mastery Run Report contains Mastery in bold letters in the top left of the page");
            Log.assertThat(masteryReport.getMasteryHeader().equals(ReportsUIConstants.MASTERY_HEADER), "The mastery header is displayed in bold letters", "The mastery header is not displayed in bold letters");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:06 Verify the Student Name , Grade Level and the Assignments name is present in the Mastery Run Report");
            Log.assertThat(!masteryReport.getStudentName().isEmpty(), "The student name is displayed", "The student name is not displayed");
            Log.assertThat(!masteryReport.getGradeName().isEmpty(), "The grade is displayed", "The grade is not displayed");
            Log.assertThat(!masteryReport.getAssignmentName().isEmpty(), "The grade is displayed", "The grade is not displayed");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:07 Verify the Date and time is getting displayed in the Mastery Run Report under Report Run ");
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yy");
            String reportDate = dateFormat.format(new Date());
            Log.assertThat(masteryReport.getReportRunTime().contains(reportDate), "The today date " + reportDate + " is displayed as expected", "The today date " + reportDate + " is not displayed as expected");
            Log.assertThat(masteryReport.getReportRunTime().contains("AM") || masteryReport.getReportRunTime().contains("PM"), "The time is " + masteryReport.getReportRunTime() + "displayed as expected", "The time is " + masteryReport.getReportRunTime() + "not displayed as expected");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:08 Verify the Assigned Course Level, Current Course Level, IP Level, Time Spent, Total Sessions(Minimum of 1 Assessments), Average Session Time, Skill/Standard, Mastery Status, # of Skills Completed/Judged, # of Attempts column fields are available in Mastery Run Report page");
            Log.assertThat(masteryReport.getAssignmentsDetailsKey().containsAll(ReportsUIConstants.MASTERYREPORT_ASSIGNMENTDETAILS_LABELS), "The Assignment Details Key are getting displayed as Expected", "The Assignment Details Key are getting displayed as Expected!");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:09 Verify user is able to view the next students mastery data by clicking Next  button");
            String asgnNamebfrr = masteryReport.getAssignmentName();
            masteryReport.clickPaginationNextBtn();
            String asgnNameaftt = masteryReport.getAssignmentName();
            Log.assertThat(!asgnNamebfrr.equals(asgnNameaftt), "The next students mastery data is displaying by clicking Next button", "The next students mastery data is not displaying by clicking next button");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:10 Verify user is able to view the previous students mastery data by clicking Back button");
            String asgnNamebfr = masteryReport.getAssignmentName();
            masteryReport.clickPaginationBackBtn();
            String asgnNameaft = masteryReport.getAssignmentName();
            Log.assertThat(!asgnNamebfr.equals(asgnNameaft), "The previous students mastery data is displaying by clicking Back button", "The previous students mastery data is not displaying by clicking Back button");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:11 Verify user is able to go to respective students page by entering respective page number in the box provided neato \"Go to\" text & click on enter on the keyboard if we have multiple pages in the report generated");
            String assignmentNamebfr = masteryReport.getAssignmentName();
            masteryReport.setPaginationInput(ReportsUIConstants.VALID_PAGINATION_THREE);
            String assignmentNameAft = masteryReport.getAssignmentName();
            Log.assertThat(!assignmentNamebfr.equals(assignmentNameAft), "The student able to go to respective students page by entering respective page number", "The student not able to go to respective students page by entering respective page number");
            Log.testCaseResult();


            SMUtils.logDescriptionTC("Tc:12 Verify the message \" Invalid\" is displayed   in Run Report while giving page number out of the bound  in the box provied near to \"Go to\" text ");
            masteryReport.setPaginationInput(ReportsUIConstants.INVALID_PAGINATION_INPUT);
            Log.assertThat(masteryReport.getPaginationError().equals(ReportsUIConstants.INVALID_PAGINATION_ERRMSG), "The pagination error message is displayed while giving page number out of the bound", "The pagination error message is not displayed while giving page number out of the bound");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:13 Verify the Legends displayed in the report page");
            Log.assertThat(masteryReport.getLegendHeading().equals(ReportsUIConstants.LEGEND_HEADER), "The legend header is available in reports output page", "The lengend header is not available in reports output page");
            Log.assertThat(masteryReport.getLegendLabel().equals(ReportsUIConstants.MASTERYREPORT_LEGEND_LABELS), "The legend label is showing as expected", "The legend label is not showing as expected");
            Log.assertThat(masteryReport.getLegengLabelValuey().equals(ReportsUIConstants.MASTERYREPORT_LEGEND_LABELS_VALUES), "The legend label values are showing as expected", "The legend label values are not showing as expected");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:14 Verify the all Students Mastery Data Headers ");
            Log.assertThat(masteryReport.verifyMasteryHeaderTitles(), "The MasteryDetails Header titles are displayed as expected", "The MasteryDetails Header titles are not displayed as expected!");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:15 Verify the Mastery Skills/Standards values are getting diaplayed in the Mastery Skills/Standard Column");
            Log.message("The mastery Skills/Standard column present count is " + masteryReport.getMasteryStatusColumn().size());
            Log.assertThat(!masteryReport.getSkillOrStandardColumn().isEmpty(), "Mastery Skills/Standards values are getting displayed in the Mastery skills/standard column", "Mastery Skills/Standards values are not getting displayed in the Mastery skills/standard column!");

            SMUtils.logDescriptionTC("Tc:16 Verify the Mastery status values are getting displayed in the Mastery Status Column");
            Log.message("The Mastery status colum present count is " + masteryReport.getMasteryStatusColumn().size());
            List<String> ab = masteryReport.getMasteryStatusColumn();
            Log.message(ab + "");
            //Log.assertThat(ReportsUIConstants.MASTERYREPORT_MASTERY_STATUS_VALUES.contains(masteryReport.getMasteryStatusColumn()), "The Mastery Status Values are getting displayed in the Mastery status column", "The Mastery Status column values are not getting displayed under Mastery status column!");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:17 Verify the # of Skills Completed/Judged	values are present under # of Skills Completed/Judged column ");
            Log.message("The # of Skills Completed/Judged column value count is " + masteryReport.getSkillsCompletedColumn().size());
            Log.assertThat(masteryReport.getSkillsCompletedColumn().size() > 0, "The # of Skills Completed/Judged	values are present under # of Skills Completed/Judged column", "The # of Skills Completed/Judged values are not present under # of Skills Completed/Judged column!");
            Log.testCaseResult();

            SMUtils.logDescriptionTC("Tc:18 Verify the Attempts column values are getting displayed under Attempts column");
            Log.message("The Attempts column value count is " + masteryReport.getNoofAttemptsColumn().size());
            Log.assertThat(masteryReport.getNoofAttemptsColumn().size() > 0, "The Attempts column values are getting displayed under Attempts column", "The Attempts column values are not getting displayed under Attempts column!");
            Log.testCaseResult();

        } catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            if (null != devTool) {
                DevToolsUtils.closeMock(devTool);
            }
            Log.endTestCase();
            driver.quit();
        }

    }
}
