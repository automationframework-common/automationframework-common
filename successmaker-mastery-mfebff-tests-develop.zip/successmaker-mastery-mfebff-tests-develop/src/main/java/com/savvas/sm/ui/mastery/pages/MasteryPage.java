package com.savvas.sm.ui.mastery.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.SMUtils;

public class MasteryPage extends LoadableComponent<MasteryPage> {

    private final WebDriver driver;
    boolean isPageLoaded;

    MasteryFiltersComponent masteryFilterComponent;

    // ********* SuccessMaker Mastery Page Elements ***************
    public @FindBy ( css = "div.mastery-container div.zero-state-content h3" ) WebElement zeroStateHeader;

    public @FindBy ( css = "div.mastery-container div.projected p" ) WebElement zeroStateMsg;

    public @FindBy ( css = "div.mastery-container div.zero-state-icon img[alt='zero state']" ) WebElement zeroStateIcon;

    public @FindBy ( css = "mastery .header-title" ) WebElement lblMasteryHeading;

    @FindBy ( css = "h2.filter-header" )
    WebElement lblStep1Heading;

    @FindBy ( css = "mastery-step-two-filters h2" )
    WebElement lblStep2Heading;

    @FindBy ( css = ".contextual-help-icon.hydrated" )
    WebElement cellIcon;

    @FindBy ( css = "#mc-main-content>h1" )
    WebElement masteryFromHelpPage;

    public @FindBy ( css = "div.mastery-footer-button div.run-reports-button cel-button" ) WebElement masteryRunReportBtnRoot;

    /**
     *
     * Constructor class for Mastery page and initializing the driver for page
     * factory objects.
     *
     * @param driver
     *
     */
    public MasteryPage( WebDriver driver ) {
        this.driver = driver;
        // Have Topbar here and init
        PageFactory.initElements( driver, this );
        masteryFilterComponent = new MasteryFiltersComponent( driver );
    }

    // Root Child Elements
    private static String runReportPrimaryBtn = "button.primary_button";

    /**
     * Verify the run report button is enabled or disabled
     *
     * @return boolean
     */
    public boolean isRunBtnEnabled() {
        Log.message( "Verifying Run Report button is Enabled" );
        SMUtils.waitForElement( driver, masteryRunReportBtnRoot, 5 );
        WebElement runReportStatusDbd = SMUtils.getWebElementDirect( driver, masteryRunReportBtnRoot, runReportPrimaryBtn );
        return runReportStatusDbd.isEnabled();
    }

    /***
     * return the masteryFilterComponent Object
     *
     * @return
     */
    public MasteryFiltersComponent getMasteryFilterComponent() {
        return masteryFilterComponent;
    }

    @Override
    protected void isLoaded() {
        if ( !isPageLoaded ) {
            Assert.fail();
        }

        if ( SMUtils.waitForElement( driver, lblMasteryHeading ) ) {
            Log.message( "SM Mastery page loaded successfully.", driver );
        } else {
            Log.fail( "SM Mastery page did not load." );
        }
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, lblMasteryHeading );
    }

    /***
     * returns the Heading
     *
     * @return
     */
    public String getMasteryHeading() {
        return lblMasteryHeading.getText();
    }

    /**
     * returns the students and groups filter heading
     *
     * @return
     */
    public String getMasteryStep1Heading() {
        return lblStep1Heading.getText();
    }

    /**
     * returns the refine search heading
     *
     * @return
     */
    public String getMasteryStep2Heading() {
        return lblStep2Heading.getText();
    }

    /**
     * returns the Cell Icon element
     *
     * @return webelement
     */

    public WebElement getCellIcon() {
        return cellIcon;
    }

    /**
     * returns the Mastery Help Page
     *
     * @return webelement
     */

    public WebElement getMasteryFromHelpPage() {
        return masteryFromHelpPage;
    }
}
