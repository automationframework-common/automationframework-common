package com.savvas.sm.common.utils.ui.constants;

import java.util.Arrays;
import java.util.List;

public interface MasteryConstants {
    interface UserRole {
        public static String TEACHER = "teacher";
        public static String ADMIN_SINGLE = "admin_single";
        public static String ADMIN_MULTI = "admin_multi";
    }

    interface Labels {
        public static String MASTERY_HEADING = "Mastery";
        public static String STUDENT_MASTERY_HEADING = "Student Details - Mastery";
        public static String GROUP_MASTERY_HEADING = "Group Details - Mastery";
    }

    interface Graphql {
        public static String BASE_URL = "https://sm-mastery-bff-srv-stack-stage.smdemo.info";
        public static String ENDPOINT = "/graphql";

        interface Get3SixtyId {
            public static String DESCRIPTION = "description";
            public static String DISPLAYNAME = "displayName";
            public static String ADDRESS1 = "address1";
            public static String ADDRESS2 = "address2";
            public static String CITY = "city";
            public static String STATE = "state";
            public static String ZIPCODE = "zipcode";
            public static String COUNTRY = "country";
            public static String NAME = "name";
            public static String ORGANIZATIONID = "organizationId";
            public static String STATUS = "status";
            public static String ORGANIZATIONTYPE = "organizationType";
            public static String SOURCESYSTEM = "sourceSystem";
            public static String LASTUPDATEDDATE = "lastUpdatedDate";
            public static String CREATEDDATE = "createdDate";
            public static String LASTUPDATEDBY = "lastUpdatedBy";
            public static String CREATEDBY = "createdBy";
            public static String DISPLAYGROUP = "displayGroup";
            public static String ATTRIBUTES = "attributes";
            public static String THREESIXTYID = "threeSixtyId";

            //public static String REQ_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getThreeSixtyId(organizationId: \\\"8a7200f77de565ac017e2484aff10660\\\") {\\n    threeSixtyId\\n    zipcode\\n  }\\n}\\n\"}";
            public static String REQ_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getThreeSixtyId(organizationId: \\\"%s\\\") %s\\n}\\n\"}";
            public static String EXPECTED_3SIXTYID_VALUE = "https://nightly-next-auto.smdemo.info";
            public static String UNAUTHORIZED_MESSAGE = "UNAUTHORIZED";
        }

        interface skillsandStandards {
            public static String ASSIGNMENT_NAME = "assignmentName";
            public static String STANDARDS_NAME = "standardsName";
            public static String STANDARDS_ID = "standardsId";
            public static String BASE_URL = "https://sm-mastery-bff-srv-stack-stage.smdemo.info";
            public static String REPORT_URL = "https://sm-reports-bff-srv-stack-dev.smdemo.info";
            public static String ENDPOINT = "/graphql";
            public static String REQ_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  skillsAndStandards(\\n    orgId: \\\"%s\\\"\\n    userId: \\\"%s\\\"\\n    subjectId: \\\"%s\\\"\\n    isAdminCall: %s\\n  ) %s\\n}\\n\"}";
            public static String UNAUTHORIZED_MESSAGE = "Unauthorized";
            public static String ACCESS_DENIED = "Access denied! You don't have permission for this action!";
            public static String NOT_AUTHENTICATED = "Not authenticated.";
            public static String SYNTAX_ERROR = "Syntax Error";
            public static String INVALID_SUBJECT_ID_ERROR = "Invalid value passed for subjectId";
            public static String INVALID_SUBJECT_ID_ERROR1 = "Invalid value passed for Subject Id";
            public static String BAD_REQUEST = "Bad Request";
            public static String BAD_REQUEST1 = "400: Bad Request";

            public static String NO_ASSIGNMENTS = "teacher has no associated groups";
            public static String ASSIGNMENT_NOT_FOUND = "Assignment Details Not found";

        }

        interface MasteryReportOutput {
            public static String REPORT_HEADER = "Mastery";
        }

        interface MasteryExportPDFConstants {
        	//Export PDF Functionality
            public static String PDF_POP_TEXT = "Export Report PDF";
            public static String ALL_PSGES_TEXT = "All page(s)";
            public static String CURRENT_PAGE_TEXT = "Current page";
            public static String PDF_TEXT = "PDF";
            public static String PAGES_TEXT = "Page(s)";
            public static String OK_EXT = "OK";
            public static String CANCEL_TEXT = "Cancel";
            public static String POP_UP_PDF_FILE = "Exporting PDF File";
            public static String DOWNLOADING_TEXT = "It may take a few minutes for your PDF generation to complete. Please don't close this browser tab or your browser while the download is in progress.";
            public static String SUCCESS_TEXT = "Your report is successfully generated and will now begin downloading. It may take a few minutes for your PDF download to complete. Please don't close this browser tab or your browser while the download is in progress.";
            public static String SUCCESS_TEXT_SECOND = "Exporting a PDF is not recommended on Android or iOS devices.";
            public static String DOWNLOADING_TEXT_SECOND = "Exporting a PDF is not recommended on Android or iOS devices.";
            public static String MASTERY_EXPORT_FILENAME = "Mastery";
            public static String DISABLED_STATUS = "disabled";
        }
        
        interface MasteryExportCSVConstants {
            //Export Functionality
            public static String EXPORT_DATA_HEADER = "Export Report CSV";
            public static String EXPORT_DEFAULT = "Export Default Columns";
            public static String CUSTOMIZE_EXPORT = "Export Selected Columns";
            public static String EXPORTING_CSV_FILE = "Exporting CSV File";
            public static String DELAY_POPUP_TEXT = "Your report is successfully generated and will now begin downloading. It may take a few minutes for your CSV download to complete. Please don't close this browser tab or your browser while the download is in progress.Exporting a CSV is not recommended on Android or iOS devices.";
            public static String DOWNLOAD_ERROR = "Download Error";
            public static String ERROR_POPUP_TEXT = "Sorry, we encountered a problem generating your file. Please try again later.";

            public static List<String> CUSTOM_FILTERS = Arrays.asList( "reportRun", "assignedCourseLevel", "averageSessionTime", "contentBaseTypeName", "courseId", "courseName", "currentCourseLevel", "grade", "ipLevel", "ipmStatusName", "masteryStatus",
                    "noOfAttempts", "noOfSkillsCompleted", "skillStandardName", "studentId", "studentName", "timeSpent", "totalSessions" );

            public static List<String> CUSTOM_HEADERS = Arrays.asList( "\"reportRun\"", "\"assignedCourseLevel\"", "\"averageSessionTime\"", "\"contentBaseTypeName\"", "\"courseId\"", "\"courseName\"", "\"currentCourseLevel\"", "\"grade\"", "\"ipLevel\"",
                    "\"ipmStatusName\"", "\"masteryStatus\"", "\"noOfAttempts\"", "\"noOfSkillsCompleted\"", "\"skillStandardName\"", "\"studentId\"", "\"studentName\"", "\"timeSpent\"", "\"totalSessions\"" );

            public static List<String> DEFAULT_HEADERS = Arrays.asList( "\"Report Run\"", "\"Assigned course level\"", "\"Average Session Time\"", "\"Course Name\"", "\"Current course level\"", "\"Grade Name\"", "\"IP level\"", "\"Mastery Status\"",
                    "\"# of Attempts\"", "\"# of Skills Completed/Judged\"", "\"Skill or Standard\"", "\"Student Name\"", "\"Time Spent\"", "\"Total Sessions\"" );

            public static List<String> CUSTOM_SELECTED_FILTERS = Arrays.asList( "assignedCourseLevel", "AverageSessionTime", "contentBaseTypeName", "courseId", "courseName", "currentCourseLevel", "grade", "ipLevel", "ipmStatusName",
                    "masteryData.masteryStatus", "masteryData.noOfAttempts", "masteryData.noOfSkillsCompleted", "masteryData.skillStandardName", "studentId", "studentName", "timeSpent", "totalSessions" );
        }
    }

}
