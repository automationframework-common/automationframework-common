package com.savvas.sm.ui.mastery.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;

public class MasterySummaryComponent {

	private WebDriver driver;
	WebElement shadowTree = null;

	@FindBy ( className = "grade-name" )
	List<WebElement> grades;

	//IMP: Couldn't use Page Object Factory pattern here as the mastery summary component involves iterating hierarchy

	By byParentLocator = By.xpath( "//parent::recursive-hierarchy" );

	//under grades
	By byStrand = By.className( "strand-name" );

	//under strands
	By byFirstLevelStrandContent = By.cssSelector( ".dark-header>.accordion-wrapper" );

	//under first level strand content
	By byFirstLevelStrandName = By.cssSelector( "button" );

	//under first level strand content
	By bySecondLevelStrandName = By.cssSelector( ".accordion-wrapper>button" );

	//under first/second level strand content
	By byLeafNode = By.className( "leaf-node" );

	//under leaf node
	By byLeafNodeContent = By.cssSelector( ".leaf-node-text" );

	By byLeafNodeLO = By.tagName( "a" );

	//under leaf node
	By byStudentAssessmentCount = By.cssSelector( "mastery-progress-bar .leaf-node-text " );

	//under lead node- get title for tool tip
	By byProgressBarShadowRoot = By.cssSelector( "cel-multi-part-progress-bar" );

	//under byProgressBarShadowRoot
	By byProgressBarSplit = By.cssSelector( ".multi-part-progress-bar>button" );//elements
	String progressBarSplit = ".multi-part-progress-bar>button";

	//under byProgressBarSplit
	By byProgressBarSplitCount = By.className( "multi-part-progress-bar-text" );

	By byProgressBarSplitStatus = By.cssSelector( ".tooltip-wrapper" );
	String progressBarSplitStatus = ".tooltip";

	//under leaf node
	By bySelectLO = By.cssSelector( ".show-details .select-lo" );

	String expandCollapseStatus = "aria-expanded";

	@FindBy ( css = "div.header-title>span" )
	WebElement headerMasteryText;

	//Mastery Assessed Objectives headers
	@FindBy ( css = ".card .d-flex" )
	WebElement assessedObjectivesHeader;

	@FindBy ( css = "div.d-flex .indication" )
	WebElement hierarchyAssessedObjectivesHeader;
	@FindBy ( css = "div.show-content.accordion-data" )
	WebElement accordianData;

	By loLink = By.cssSelector( "div.accordion-wrapper div.accordion-data div.show-details cel-icon.select-lo" );

	//Mastery tool tip 
	@FindBy ( css = "div cel-multi-part-progress-bar[title]" )
	WebElement skillDetailsInProgressBarToolTip;

	@FindBy ( css = "cel-multi-part-progress-bar.hydrated" )
	List<WebElement> listofassessdStudentCount;

	@FindBy ( css = "div.col-sm-8.header-text" )
	List<WebElement> secondLevelStrandName;

	@FindBy ( css = "div.show-details" )
	List<WebElement> loViewLink;

	//mastery sub tab
	@FindBy ( css = "groups-mastery div.zero-state-content" )
	WebElement masteryZeroState;

	@FindBy ( css = ".apply-button" )
	WebElement btnApplyFilterRoot;

	@FindBy ( css = "recursive-hierarchy:nth-child(3) mastery-progress-bar .hydrated" )
	WebElement progressBarRoot;

	@FindBy ( css = ".accordion-wrapper button[aria-expanded=false]" )
	WebElement strandCollapse;

	@FindBy ( css = "a.lo-catalog-link" )
	WebElement loIdLink;

	@FindBy(css = "mastery-card > div.card > hr")
	WebElement divider;

	@FindBy(css="cel-button.cel-button.hydrated")
	WebElement runReportBtnParent;

	public static String btnApplyFilterChild = ".primary_button";

	public static String strand = "div[class='strand-name']";
	public static String firstLevelStrand = "button[class='accordion-header clickable']";
	public static String progressBarStyle = ".multi-part-progress-bar>button.multi-part-button";
	public static String progressBarText = "div.multi-part-progress-bar-text";
	public static String button = "button";

	/******* UI Constants ***********/
	static String collapsed_value = "false";

	/**
	 * 
	 * Constructor class for Mastery Summary Component and initializing the
	 * driver for page factory objects.
	 * 
	 * @param driver
	 * @param url
	 */
	public MasterySummaryComponent( WebDriver driver ) {
		this.driver = driver;
		// Have Topbar here and init
		PageFactory.initElements( driver, this );
		SMUtils.nap( 2 );//will be removed after integrating with mastery page
		SMUtils.waitForElement( driver, accordianData, 10 ); //grades.get( 0 )
	}

	/**
	 * Wait for spinner to complete
	 *
	 * @return
	 */
	public void waitForLoadingSpinnerToDisapper() {
		Log.message( "Proceed to wait for spinner to disappear" );
		WebDriverWait wait = new WebDriverWait( driver,Duration.ofSeconds(60) );
		wait.until( ExpectedConditions.invisibilityOfElementLocated( By.cssSelector( "div.spinner>cel-loading-spinner.hydrated" ) ) );
		//SMUtils.fluentWaitForElement( driver, grades.get( 0 ) ); Commenting this because Reading subject mastery doesn't have grades in summary page
	}

	/**
	 * Gets the content of leaf node
	 * 
	 * @return
	 */
	public List<String> getLeafNodeContent() {
		List<String> contents = new ArrayList<String>();
		driver.findElements( byLeafNode ).stream().forEach( leafNode -> contents.add( SMUtils.getTextOfWebElement( leafNode.findElement( byLeafNodeContent ), driver ) ) );

		return contents;
	}

	/**
	 * Gets the LO Id of leaf node
	 * 
	 * @return
	 */
	public List<String> getIdOfLeafNodeLO() {
		List<String> loIds = new ArrayList<String>();
		driver.findElements( byLeafNode ).stream().forEach( leafNode -> loIds.add( SMUtils.getTextOfWebElement( leafNode.findElement( byLeafNodeLO ), driver ) ) );

		return loIds;
	}

	/**
	 * Gets the LO link of leaf node
	 * 
	 * @return
	 */
	public List<String> getLinkOfLeafNodeLO() {
		List<String> loUrls = new ArrayList<String>();
		driver.findElements( byLeafNode ).stream().forEach( leafNode -> loUrls.add( SMUtils.getAttributeOfWebElement( leafNode.findElement( byLeafNodeLO ), driver, SMUtils.HREF_ATTRIBUTE ) ) );

		return loUrls;
	}

	/**
	 * Gets the Student Assessment of leaf node
	 * 
	 * @return
	 */
	public List<String> getStudentAssessmentOfLeafNodeLO() {
		List<String> studentAssessment = new ArrayList<String>();
		driver.findElements( byLeafNode ).stream().forEach( leafNode -> studentAssessment.add( SMUtils.getTextOfWebElement( leafNode.findElement( byStudentAssessmentCount ), driver ) ) );

		return studentAssessment;
	}

	/**
	 * Gets the Tool tip of progress bar
	 * 
	 * @return
	 */
	public String getTooltipOfProgressBar( WebElement progressBarElement ) {
		SMUtils.nap( 3 );
		//get the tool tip of given progressBar

		String tooltip = SMUtils.getAttributeOfWebElement( progressBarElement, driver, SMUtils.TITLE_ATTRIBUTE );

		WebElement btn_progressBar = SMUtils.getWebElementDirect( driver, progressBarElement, progressBarSplit );

		SMUtils.scrollWebElementToView( driver, progressBarElement, SMUtils.SCROLL_TO_MIDDLE );

		//mouse hover on top of given progressBar
		Actions actions = new Actions( driver );
		actions.moveToElement( btn_progressBar, 0, 30 ).build().perform();

		return tooltip;
	}

	/**
	 * Gets the available progress bar
	 * 
	 * @param masteryStatus
	 * @return
	 */
	public List<WebElement> getAvailableProgressBarShadow() {
		List<WebElement> progressBars = new ArrayList<>();
		driver.findElements( byLeafNode ).stream().forEach( leafNode -> progressBars.add( leafNode.findElement( byProgressBarShadowRoot ) ) );
		return progressBars;
	}

	/**
	 * Get Run Report Button
	 * 
	 */
	public WebElement getRunReportBtn() {
		WebElement RunReportBtn = SMUtils.getWebElementDirect(driver, runReportBtnParent, button);
		System.out.println(RunReportBtn);
		System.out.println(RunReportBtn.getLocation());
		return RunReportBtn;
	}
	
	/**
	 * Validate the Run Report button is disabled by default
	 */
	public boolean isRunReportBtnDisabled() {
		boolean flag = true;
		if(SMUtils.isElementEnabled(getRunReportBtn())) {
			flag= false;
			Log.message("The run report button is enabled by default");
		}
		return flag;
	}

	/**
	 * Click Mastery Run Report
	 */
	public WebDriver clickMasteryRunReportBtn() throws Exception {
		String winHandle = driver.getWindowHandle();
		SMUtils.waitForElement(driver, getRunReportBtn());


		SMUtils.clickJS(driver, getRunReportBtn());

		SMUtils.nap(10);
		
		Set<String> handles = driver.getWindowHandles();
		Log.event( "Number of window handles - " + handles.size() );
		for ( String index : handles ) {
			if ( !index.equals( winHandle ) ) {
				driver.switchTo().window( index );

				break;
			}
		}
		return driver;
		
	}

	/**
	 * Gets the leaf node of given mastery status
	 * 
	 * @param masteryStatus
	 * @return
	 */
	public List<WebElement> getLeafNodeBasedOnMasteryStatus( String masteryStatus ) {
		return driver.findElements( byLeafNode ).stream().filter(
				leafNode -> SMUtils.getAttributeOfWebElement( SMUtils.getWebElementDirect( driver, leafNode.findElement( byProgressBarShadowRoot ), progressBarSplitStatus ), driver, SMUtils.INNERTEXT_ATTRIBUTE ).equals( masteryStatus ) ).collect(
						Collectors.toList() );
	}

	/**
	 * Gets the progress bar link of given mastery status
	 * 
	 * @param masteryStatus
	 * @return
	 */
	public List<WebElement> getProgressBarLink( String masteryStatus ) throws Exception {
		List<WebElement> loBarWithMasteryStatus = new ArrayList<>();
		getLeafNodeBasedOnMasteryStatus( masteryStatus ).stream().forEach( node -> loBarWithMasteryStatus.add( node.findElement( bySelectLO ) ) );
		if ( loBarWithMasteryStatus.isEmpty() ) {
			MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );
			masteryFiltersComponent.expandToggle();
			masteryFiltersComponent.applyFilter();
			getLeafNodeBasedOnMasteryStatus( masteryStatus ).stream().forEach( node -> loBarWithMasteryStatus.add( node.findElement( bySelectLO ) ) );
		}
		return loBarWithMasteryStatus;
	}

	/**
	 * Gets the progress bar link of given mastery status
	 *
	 * @param masteryStatus
	 * @return
	 */
	public MasteryDetailsPage clickLOLink() throws Exception {
		SMUtils.nap(2);
		if ( driver.findElements( loLink ).size() == 0 ) {
			MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );
			masteryFiltersComponent.expandToggle();
			masteryFiltersComponent.applyFilter();
			SMUtils.waitForElement( driver, driver.findElement( loLink ) );
			List<WebElement> links = driver.findElements( loLink );
			WebElement random = links.get( new Random().nextInt( links.size() ) );
			SMUtils.clickJS( driver, random );
			Log.message( "The LO Link clicked successfully" );
		} else {
			List<WebElement> links = driver.findElements( loLink );
			WebElement random = links.get( new Random().nextInt( links.size() ) );
			SMUtils.clickJS( driver, random );
			Log.message( "The LO Link clicked successfully" );
		}
		return new MasteryDetailsPage( driver );
	}

	/**
	 * Navigate to LO View page by clicking given LO link
	 * 
	 * @param loLink
	 */
	public MasteryDetailsPage navigateToLoViewPage( WebElement loLink ) {
		SMUtils.scrollWebElementToView( driver, loLink, SMUtils.SCROLL_TO_MIDDLE );
		SMUtils.click( driver, loLink );

		return new MasteryDetailsPage( driver );
	}

	/**
	 * Gets the assessed Objectives header text
	 * 
	 * @return
	 */
	public boolean getAssessedObjectivesHeaders() {
		return Constants.MasteryUI.ASSESSED_OBJECTIVES_HEADERS.stream().allMatch( objectives -> assessedObjectivesHeader.getText().trim().contains( objectives ) );
	}

	/**
	 * To verify grade is displayed or not
	 * 
	 * @return
	 */
	public boolean verifyGradeIsDisplayed() {
		return ( SMUtils.isElementPresent( grades.get( 0 ) ) ? true : false );
	}

	/**
	 * To verify the headings in mastery tab in assignment details page
	 * 
	 * @return
	 */
	public boolean verifySkillHeadingIsDisplayed() {
		if ( SMUtils.waitForElement( driver, driver.findElement( byLeafNode ) ) ) {
			driver.findElements( byStrand ).stream().forEach( domain -> domain.isDisplayed() );
			driver.findElements( byFirstLevelStrandContent ).stream().forEach( cluster -> cluster.isDisplayed() );
			driver.findElements( byLeafNodeContent ).stream().forEach( domain -> domain.isDisplayed() );
			Log.message( "Skill headings are displayed" );
			return true;
		} else {
			return false;
		}
	}

	/*
	 * To get LO link
	 * 
	 * @return
	 */
	public List<WebElement> getLinkElementOfLeafNodeLO() {
		List<WebElement> loUrls = new ArrayList<>();
		driver.findElements( byLeafNode ).stream().forEach( leafNode -> loUrls.add( leafNode.findElement( byLeafNodeLO ) ) );
		return loUrls;
	}

	/**
	 * To verify the color of LO in mastery tab in assignment details page
	 * 
	 * Return color code
	 */
	public boolean verifyLOColor( String browser ) {
		if ( SMUtils.isElementPresent( driver.findElement( byLeafNodeContent ) ) ) {
			getLinkElementOfLeafNodeLO().stream().forEach( lo -> {
				SMUtils.waitForElement( driver, lo );
				String colorCode = "null";
				String rgbcolor;
				if ( !browser.contains( "Safari" ) ) {
					rgbcolor = lo.getCssValue( "color" );
					String[] hexValue = rgbcolor.replace( "rgba(", "" ).replace( ")", "" ).split( "," );
					hexValue[0] = hexValue[0].trim();
					int hexValue1 = Integer.parseInt( hexValue[0] );
					hexValue[1] = hexValue[1].trim();
					int hexValue2 = Integer.parseInt( hexValue[1] );
					hexValue[2] = hexValue[2].trim();
					int hexValue3 = Integer.parseInt( hexValue[2] );
					colorCode = String.format( "#%02x%02x%02x", hexValue1, hexValue2, hexValue3 );
				} else if ( browser.contains( "Safari" ) ) {
					rgbcolor = lo.getCssValue( "color" );
					String[] hexValue = rgbcolor.replace( "rgb(", "" ).replace( ")", "" ).split( "," );
					hexValue[0] = hexValue[0].trim();
					int hexValue1 = Integer.parseInt( hexValue[0] );
					hexValue[1] = hexValue[1].trim();
					int hexValue2 = Integer.parseInt( hexValue[1] );
					hexValue[2] = hexValue[2].trim();
					int hexValue3 = Integer.parseInt( hexValue[2] );
					colorCode = String.format( "#%02x%02x%02x", hexValue1, hexValue2, hexValue3 );
				}
				colorCode.equalsIgnoreCase( Constants.MasteryUI.LO_COLOR_CODE );
			} );
			Log.message( "LO is displayed as blue in color" );
			return true;
		} else {
			Log.message( "LO is displayed as blue in color" );
			return false;
		}
	}

	/**
	 * To Verify is Mastery Summary age Loaded
	 * 
	 * @return
	 */

	public Boolean isMasterySummaryPageLoaded() {
		Boolean status = false;
		String text = headerMasteryText.getText();
		if ( text.equals( "Mastery" ) ) {
			status = true;
			Log.message( "Mastery Summary Page Loaded" );
		}
		return status;
	}

	/**
	 * Verify tool-tip is present or not
	 * 
	 * @return
	 */
	public Boolean isSkillDetailsPresentInProgressBarToolTip() {
		Boolean status = false;
		SMUtils.waitForElement( driver, skillDetailsInProgressBarToolTip );
		if ( skillDetailsInProgressBarToolTip.isDisplayed() ) {
			status = true;
			Log.message( "Skill Details Present in the Progress Bar Tool Tip" );
		}
		return status;
	}

	/**
	 * Return Of list of assessment student
	 * 
	 * @return
	 */
	public List<String> getStudentAssessmentCount() {
		String student = "";
		List<String> header = new ArrayList<String>();
		for ( WebElement element : listofassessdStudentCount ) {
			student = element.getAttribute( SMUtils.TITLE_ATTRIBUTE );
			int totalStudents = 0;
			String noOfStudentsAssessed = "";
			String[] split = student.split( "," );
			totalStudents = Integer.parseInt( split[0].trim().split( " " )[0] ) + Integer.parseInt( split[1].trim().split( " " )[0] ) + Integer.parseInt( split[2].trim().split( " " )[0] );
			if ( totalStudents > 1 ) {
				noOfStudentsAssessed = totalStudents + " Student Assessments";
			}

			else {
				noOfStudentsAssessed = totalStudents + " Student Assessment";
			}
			header.add( noOfStudentsAssessed );
		}
		return header;
	}

	// Clicking on First Level Strand Name for Math and Reading subjects
	public void clickFirstLevelStrandName() {
		AtomicReference<String> collapsed = new AtomicReference<>();
		List<WebElement> strandName = SMUtils.getChildWebElementsFromParent( driver.findElement( byParentLocator ), strand );
		Log.message( strandName.toString() );

		WebElement parent = driver.findElement( byParentLocator );
		List<WebElement> firstLevelStrandName = SMUtils.getChildWebElementsFromParent( parent, firstLevelStrand );
		SMUtils.clickJS( driver, firstLevelStrandName.get( 0 ) );
		collapsed.set( firstLevelStrandName.get( 0 ).getAttribute( SMUtils.ARIA_PRESSED ) );

		if ( collapsed.get().contentEquals( collapsed_value ) )
			Log.pass( "The First Level Strand is collapsed" );
		else
			Log.pass( "The First Level Strand is Expanded" );
	}

	//Clicking the second strand name for Math skills in the mastery summary page
	public void clickSecondLevelStrandName() {
		SMUtils.scrollWebElementToView( driver, secondLevelStrandName.get( 0 ), SMUtils.SCROLL_TO_MIDDLE );
		Log.message( "Clicking on Second Level StrandName" );
		SMUtils.click( driver, secondLevelStrandName.get( 0 ) );
	}

	// To check, if the LO details page link is available
	public boolean isLOviewLinkPresenet() {
		boolean status = false;
		try {
			if ( SMUtils.isElementPresent( loViewLink.get( 0 ) ) ) {
				if ( loViewLink.get( 0 ).isDisplayed() ) {
					status = true;
				}
			}
		} catch ( Exception e ) {
			e.printStackTrace();
		}
		return status;
	}

	/**
	 * Verify the apply filter button
	 * 
	 * @return
	 */

	public boolean applyFilter() {
		WebElement applyFilter = SMUtils.getWebElementDirect( driver, btnApplyFilterRoot, btnApplyFilterChild );
		SMUtils.waitForElement( driver, applyFilter );
		if ( applyFilter.isEnabled() ) {
			SMUtils.click( driver, applyFilter );
			Log.message( "Clicked apply filter!", driver );
			return true;
		} else {
			Log.message( "Apply filter button is disabled" );
			return false;
		}

	}

	/**
	 * To get the color of status in mastery
	 * 
	 * Return color code
	 */
	public List<String> getStatusColor( String browser ) {

		SMUtils.waitForElement( driver, progressBarRoot );
		List<WebElement> listOfStatus = SMUtils.getWebElementsDirect( driver, progressBarRoot, progressBarStyle );
		List<String> statusCode = new ArrayList<>();

		listOfStatus.stream().forEach( status -> {
			SMUtils.waitForElement( driver, status );
			String colorCode = null;

			if ( !browser.contains( "Safari" ) ) {
				String[] styleRGB = status.getAttribute( "style" ).split( ";" );
				String[] hexValue = styleRGB[0].replace( "background: rgb(", "" ).replace( ")", "" ).split( "," );
				hexValue[0] = hexValue[0].trim();
				int hexValue1 = Integer.parseInt( hexValue[0] );
				hexValue[1] = hexValue[1].trim();
				int hexValue2 = Integer.parseInt( hexValue[1] );
				hexValue[2] = hexValue[2].trim();
				int hexValue3 = Integer.parseInt( hexValue[2] );
				colorCode = String.format( "#%02x%02x%02x", hexValue1, hexValue2, hexValue3 );
				statusCode.add( colorCode );
			} else if ( browser.contains( "Safari" ) ) {
				String[] styleRGB = status.getAttribute( "style" ).split( ";" );
				String[] hexValue = styleRGB[0].replace( "background-color: rgb(", "" ).replace( ")", "" ).split( "," );
				hexValue[0] = hexValue[0].trim();
				int hexValue1 = Integer.parseInt( hexValue[0] );
				hexValue[1] = hexValue[1].trim();
				int hexValue2 = Integer.parseInt( hexValue[1] );
				hexValue[2] = hexValue[2].trim();
				int hexValue3 = Integer.parseInt( hexValue[2] );
				colorCode = String.format( "#%02x%02x%02x", hexValue1, hexValue2, hexValue3 );
				statusCode.add( colorCode );
			}
		} );
		return statusCode;
	}

	/**
	 * To verify strand is collapsed or not
	 * 
	 * @return
	 */
	public boolean isStrandCollapsed() {
		Log.message( "Verifying strand is collapsed or not" );
		SMUtils.waitForElement( driver, accordianData );
		return SMUtils.isElementPresent( strandCollapse );
	}

	/**
	 * To LO id link is present or not
	 * 
	 * @return
	 */
	public boolean verifyLoLinkIsPresent() {
		Log.message( "Verifying LO id link is present or not" );
		SMUtils.waitForElement( driver, accordianData );
		try {
			SMUtils.isElementPresent( loIdLink );
			return true;
		} catch ( Exception e ) {
			Log.message( "LO id link is not present" );
			return false;
		}
	}

	/**
	 * Compares the Background color of leaf node before and after Hover over
	 * the LO
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean isColorChangedOnhoverOverLeafNodeContent() throws Exception {
		List<WebElement> contents = new ArrayList<WebElement>();

		driver.findElements( byLeafNode ).forEach( leafNode -> contents.add( leafNode.findElement( byLeafNodeContent ) ) );
		String beforeHover = SMUtils.getBackgroundColor( contents.stream().findFirst().get() );
		SMUtils.moveToElementJS( driver, contents.stream().findFirst().get() );
		String afterHover = SMUtils.getBackgroundColor( contents.stream().findFirst().get() );

		Log.message( "Color before the element is Hover Overed: " + beforeHover + " && Color after the element is Hover Overed: " + afterHover );

		return ( afterHover.equals( beforeHover ) );
	}

	public WebElement getAssessedObjectivesLine(String browser) {

		return divider;
	}

	public WebElement getAssessedObjectivesHeader(String browser) {
		return assessedObjectivesHeader;
	}

}
