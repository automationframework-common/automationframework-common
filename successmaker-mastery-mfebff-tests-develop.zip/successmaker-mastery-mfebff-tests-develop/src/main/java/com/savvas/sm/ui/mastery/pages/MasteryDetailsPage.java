package com.savvas.sm.ui.mastery.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;

/**
 * This class contains POM for the Mastery LO View page UI.
 * 
 * @author madhan.nagarathinam
 *
 */

public class MasteryDetailsPage {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    private final WebDriver driver;
    WebElement shadowTree = null;
    boolean isPageLoaded;

    //**********Mastery LO View Page Elements***********

    @FindBy ( css = "cel-icon.chevron-left-icon.hydrated" )
    WebElement breadCrumbBtnRoot;

    @FindBy ( css = "div.card" )
    WebElement learningObjectPageView;

    public @FindBy ( css = "div.card-body .lo-details span.card-text a" ) WebElement learningObjectID;

    @FindBy ( css = "div.leaf-node-text" )
    WebElement noOfStudentAssessed;

    @FindBy ( css = "cel-multi-part-progress-bar.hydrated" )
    WebElement progressBarRoot;

    @FindBy ( css = "tbody.table-body" )
    WebElement masteryDetails;

    @FindBy ( css = "div.mastery-student-table button.accordion-header" )
    List<WebElement> masteryAssignmentHeader;

    @FindBy ( css = "div.table-container .table-head tr>th" )
    List<WebElement> masteryHeader;

    @FindBy ( css = "div[slot='headers']" )
    List<WebElement> assignmentName;

    @FindBy ( css = "th.th-text" )
    List<WebElement> listHeaders;

    @FindBy ( css = "div cel-multi-part-progress-bar[title]" )
    WebElement skillDetailsInProgressBarToolTip;

    @FindBy ( css = "div.container-fluid>div.header-row>a>cel-icon.chevron-left-icon" )
    WebElement chevronIcon;

    public @FindBy ( css = "div.container-fluid div.card-body" ) WebElement loPageBody;

    @FindBy ( css = ".row .chevron-left-icon" )
    WebElement backBtnRoot;

    @FindBy ( css = "a.header-back-link cel-icon.chevron-left-icon" )
    WebElement masteryBackBreadCrumbBtnRoot;

    @FindBy ( css = "tr.table-row th span.d-flex" )
    List<WebElement> masteryDetailPageHeader;

    @FindBy ( css = "div.header-title>span" )
    WebElement headerMasteryText;

    @FindBy ( css = "span.card-text" )
    WebElement loDescriptionText;

    @FindBy ( css = "tbody.table-body>tr:first-child table span.col-name" )
    List<WebElement> listOfStudentsInDetailsPage;

    @FindBy ( css = "tbody.table-body>tr:first-child table cel-badge" )
    List<WebElement> getMasteryStatusRoot;

    @FindBy ( css = "tbody.table-body>tr:first-child table span.col-skills" )
    List<WebElement> skillsEvaluatedInDetailsPage;

    @FindBy ( css = "tbody.table-body>tr:first-child table span.col-attempts" )
    List<WebElement> attemptsValuesInDetailsPage;

    @FindBy ( css = "div span.card-text a" )
    WebElement nameOfLOInMasteryDetailsPage;

    @FindBy ( css = ".mobile-glass-panel div#mobile-play-button" )
    WebElement mobilePlayBtnCourseLaunchPage;

    @FindBy ( css = "div#menuButtonContainer" )
    WebElement menuBtnCourseLaunchPage;

    @FindBy ( css = "div.lo-details div span p" )
    WebElement skillDescription;

    @FindBy ( css = "span.card-title" )
    WebElement skillParentName;

    @FindBy ( css = "cel-side-nav-bar div span.side-nav-item" )
    List<WebElement> settingsSideBar;

    @FindBy ( css = "body>iframe#playerFrame" )
    WebElement scoPageFrame;

    @FindBy ( css = "iframe#gadgetPlayer" )
    WebElement scoPagegadgetFrame;

    @FindBy ( css = "div iframe#playerFrame" )
    WebElement finalFrame;

    @FindBy ( css = "div.mastery-student-table .table-head tr>th" )
    List<WebElement> studentTableHeader;

    public @FindBy ( css = "div.show-content.accordion-data cel-badge.hydrated" ) WebElement badgeRoot;

    // Root Child Elements

    private static String btnPrimary = ".primary_button";
    private static String btnSecondary = ".secondary_button";
    private static String backbreadscrumbChild = "img.icon-inner";
    private static String drpDownChild = "div.icon-inner";
    private static String getMasteryStatuschild = "div.badge span";

    //Root child Elements
    private static String studentName = "tr:nth-child(%s) table tr:nth-child(%s) td:nth-child(1)";
    private static String masteryLOViewTabHeader = "div.table-container .table-head tr>th:nth-child(%s)";
    private static String masterLOViewRowValues = "tr:nth-child(%s) table tr:nth-child(%s) td:nth-child(%s)";
    private static String btnExpandCollapseRoot = "tr:nth-child(%s) cel-icon.hydrated[aria-label='subtraction']";
    private static String btnExpandCollapsechild = "img[alt='subtraction']";
    private static String assignment = "tr:nth-child(%s) div[slot='headers']";
    private static String studentNameTable = "tr:nth-child(%s) div[slot='accordion-data']>table";
    private static String studentTable = ".show-content.accordion-data table tr td:nth-child(%s)";
    private static String progressBarStyle = "div.multi-part-progress-bar>button.multi-part-button";
    private static String progressBarValue = "div.multi-part-progress-bar>button.multi-part-button:nth-child(%s) div.multi-part-progress-bar-text";
    private static String innerIcon = ".icon-inner";
    private static String badgeChild = "div.badge span";
    private static String masteryValueChild = "div";
    private static String masteryValueName = "tr:nth-child(1) table tr:nth-child(%s) td:nth-child(2) cel-badge";
    private static String masteryValues = "tr:nth-child(1) div[slot='accordion-data']>table";

    //UI Constants
    private static String smUrl = configProperty.getProperty( "SMAppUrl" );
    private static String minusBtn = smUrl + "/lms/assets/subtraction.svg";
    private static String plusBtn = smUrl + "/lms/assets/addition.svg";
    List<String> HEADERS = new ArrayList<>( Arrays.asList( "Student", "Mastery Status", "Skills Evaluated", "Attempts" ) );

    //**********************************************************************
    public MasteryDetailsPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
        SMUtils.fluentWaitForElement( driver, loPageBody, 5 );
    }

    /**
     * Get the color of LO Name
     * 
     * Return color code
     */
    public String getLOColor( String browser ) {
        SMUtils.waitForElement( driver, learningObjectID );
        String colorCode = "null";
        String rgbcolor;
        if ( !browser.contains( "Safari" ) && SMUtils.isElementPresent( learningObjectID ) ) {
            rgbcolor = learningObjectID.getCssValue( "color" );
            String[] hexValue = rgbcolor.replace( "rgba(", "" ).replace( ")", "" ).split( "," );
            hexValue[0] = hexValue[0].trim();
            int hexValue1 = Integer.parseInt( hexValue[0] );
            hexValue[1] = hexValue[1].trim();
            int hexValue2 = Integer.parseInt( hexValue[1] );
            hexValue[2] = hexValue[2].trim();
            int hexValue3 = Integer.parseInt( hexValue[2] );
            colorCode = String.format( "#%02x%02x%02x", hexValue1, hexValue2, hexValue3 );
        } else if ( browser.contains( "Safari" ) && SMUtils.isElementPresent( learningObjectID ) ) {
            rgbcolor = learningObjectID.getCssValue( "color" );
            String[] hexValue = rgbcolor.replace( "rgb(", "" ).replace( ")", "" ).split( "," );
            hexValue[0] = hexValue[0].trim();
            int hexValue1 = Integer.parseInt( hexValue[0] );
            hexValue[1] = hexValue[1].trim();
            int hexValue2 = Integer.parseInt( hexValue[1] );
            hexValue[2] = hexValue[2].trim();
            int hexValue3 = Integer.parseInt( hexValue[2] );
            colorCode = String.format( "#%02x%02x%02x", hexValue1, hexValue2, hexValue3 );
        } else
            Log.fail( "LO Id is not present in blue color" );

        return colorCode;
    }

    /**
     * To get the Number of students Assessed in UI.
     *
     * @return
     */

    public String getNoOfStudentAssessed() {
        SMUtils.waitForElement( driver, noOfStudentAssessed );
        String noOfStudents = noOfStudentAssessed.getText().trim();
        Log.message( "The students assessed details above progressbar is " + noOfStudentAssessed.getText() );
        return noOfStudents;
    }

    /**
     * To get student count from progressBar
     * 
     * @return no.of students assessed
     */
    public String getStudentCounts() {
        SMUtils.waitForElement( driver, progressBarRoot );
        String val = progressBarRoot.getAttribute( SMUtils.TITLE_ATTRIBUTE ).toString();
        int totalStudents = 0;
        String noOfStudentsAssessed = "";
        String[] split = val.split( "," );
        totalStudents = Integer.parseInt( split[0].trim().split( " " )[0] ) + Integer.parseInt( split[1].trim().split( " " )[0] ) + Integer.parseInt( split[2].trim().split( " " )[0] );
        if ( totalStudents > 1 ) {
            noOfStudentsAssessed = totalStudents + " Student Assessments";
            Log.message( "Total number of student Assessment is " + noOfStudentsAssessed );
        }

        else {
            noOfStudentsAssessed = totalStudents + " Student Assessment";
            Log.message( "Total number of student Assessment is " + noOfStudentsAssessed );
        }
        return noOfStudentsAssessed;
    }

    /**
     * To get student count from progressBar return type as int
     * 
     * @return no.of students assessed
     */
    public int getStudentCountsFromDetailsPage() {
        SMUtils.waitForElement( driver, progressBarRoot );
        String val = progressBarRoot.getAttribute( SMUtils.TITLE_ATTRIBUTE ).toString();
        int totalStudents = 0;
        String[] split = val.split( "," );
        totalStudents = Integer.parseInt( split[0].trim().split( " " )[0] ) + Integer.parseInt( split[1].trim().split( " " )[0] ) + Integer.parseInt( split[2].trim().split( " " )[0] );
        Log.message( "Total number of student Assessment is " + totalStudents );
        return totalStudents;
    }

    /***
     * Verify collapse icon is present for all Assignment
     * 
     * return status
     */
    public boolean isMinusBtnPresentByDefault() {
        boolean status = true;
        try {
            String assignmentNames = masteryDetails.getAttribute( "childElementCount" );
            status = IntStream.range( 0, Integer.parseInt( assignmentNames ) ).allMatch( i -> {
                if ( !( getCollapseExpandIcon( i + 1 ).getAttribute( "src" ).equals( minusBtn ) ) ) {
                    return false;
                } else
                    return true;
            } );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return status;
    }

    /**
     * To get the +/- icon button
     *
     * @param AssignmentCount
     * @return
     */
    private WebElement getCollapseExpandIcon( int assignmentCount ) {
        WebElement collapseExpandButtonRoot = driver.findElement( By.cssSelector( String.format( btnExpandCollapseRoot, assignmentCount ) ) );
        WebElement btnExpandCollapse = SMUtils.getWebElementDirect( driver, collapseExpandButtonRoot, btnExpandCollapsechild );
        return btnExpandCollapse;
    }

    //Clicking collapseButton
    public void clickingMinusButton( String AssignmentName ) {
        try {
            String assignmentNames = masteryDetails.getAttribute( "childElementCount" );
            IntStream.range( 0, Integer.parseInt( assignmentNames ) ).forEach( i -> {
                if ( driver.findElement( By.cssSelector( String.format( MasteryDetailsPage.assignment, i + 1 ) ) ).getText().trim().contains( AssignmentName ) ) {
                    SMUtils.clickJS( driver, getCollapseExpandIcon( i + 1 ) );
                    Log.message( "Minus button is clicked for " + AssignmentName );
                }
            } );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    //Verifying after clicking Minus[-] Btn, Plus[+] is getting displayed
    public boolean isPlusBtnPresent( String AssignmentName ) {
        AtomicReference<Boolean> status = new AtomicReference<Boolean>( false );
        try {
            String assignmentNames = masteryDetails.getAttribute( "childElementCount" );
            IntStream.range( 0, Integer.parseInt( assignmentNames ) ).forEach( i -> {
                if ( driver.findElement( By.cssSelector( String.format( MasteryDetailsPage.assignment, i + 1 ) ) ).getText().trim().contains( AssignmentName ) ) {
                    if ( ( getCollapseExpandIcon( i + 1 ).getAttribute( "src" ).equals( plusBtn ) ) ) {
                        Log.pass( "Plus Btn is getting displayed " );
                        status.set( true );
                    } else {
                        Log.fail( "Plus Btn is not getting displayed!" );
                        status.set( false );
                    }
                }
            } );

        } catch ( Exception e ) {
            e.printStackTrace();
        }

        return status.get();
    }

    //Clicking ExpandButton
    public void clickingPlusButton( String AssignmentName ) {
        try {
            String assignmentNames = masteryDetails.getAttribute( "childElementCount" );
            IntStream.range( 0, Integer.parseInt( assignmentNames ) ).forEach( i -> {
                if ( driver.findElement( By.cssSelector( String.format( MasteryDetailsPage.assignment, i + 1 ) ) ).getText().trim().contains( AssignmentName ) ) {
                    SMUtils.clickJS( driver, getCollapseExpandIcon( i + 1 ) );
                    Log.message( "Plus button is clicked for " + AssignmentName );
                }
            } );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     * Get the list of students in Mastery LO Assignments page.
     *
     * @return
     */
    public List<String> getStudentName( String AssignmentName ) {
        List<String> studentsFromUI = new ArrayList<String>();
        SMUtils.waitForElement( driver, masteryDetails );
        String assignmentNames = masteryDetails.getAttribute( "childElementCount" );
        IntStream.range( 0, Integer.parseInt( assignmentNames ) ).allMatch( assignmentCount -> {
            Log.message( driver.findElement( By.cssSelector( String.format( MasteryDetailsPage.assignment, assignmentCount + 1 ) ) ).getText().trim() );
            if ( driver.findElement( By.cssSelector( String.format( MasteryDetailsPage.assignment, assignmentCount + 1 ) ) ).getText().trim().contains( AssignmentName ) ) {
                String StudentNames = driver.findElement( By.cssSelector( String.format( MasteryDetailsPage.studentNameTable, assignmentCount + 1 ) ) ).getAttribute( "childElementCount" );
                IntStream.range( 0, Integer.parseInt( StudentNames ) ).forEach( studentCount -> {
                    WebElement studentName = driver.findElement( By.cssSelector( String.format( MasteryDetailsPage.studentName, assignmentCount + 1, studentCount + 1 ) ) );
                    if ( studentName.isDisplayed() ) {
                        String studentNameFromUI = SMUtils.getTextOfWebElement( studentName, driver );
                        studentsFromUI.add( studentNameFromUI );
                    }
                    Log.message( "Listed Students -" + studentsFromUI );
                } );
            }
            return true;
        } );

        return studentsFromUI;
    }

    public int getTableHeaderIndex( String columName ) {
        AtomicInteger headerIndex = new AtomicInteger();
        SMUtils.waitForElement( driver, masteryDetails );
        int headerValues = masteryHeader.size();
        IntStream.rangeClosed( 1, headerValues ).allMatch( headerCount -> {
            if ( driver.findElement( By.cssSelector( String.format( MasteryDetailsPage.masteryLOViewTabHeader, headerCount ) ) ).getText().trim().contains( columName.trim() ) ) {
                headerIndex.set( headerCount );
                return true;
            }

            return true;
        } );
        return headerIndex.get();
    }

    //
    /**
     * Get the list of students in Mastery LO Assignments page.
     *
     * @return
     */
    public List<String> getRowValuesBasedOnTheColumn( String AssignmentName, String columName ) {
        List<String> rowValuesFromUI = new ArrayList<String>();
        SMUtils.waitForElement( driver, masteryDetails );
        int columnIndex = getTableHeaderIndex( columName );
        masteryAssignmentHeader.stream().forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( assignmentNameUI -> {
            if ( assignmentNameUI.equalsIgnoreCase( AssignmentName ) ) {
                WebElement parent = element.findElement( By.xpath( "./.." ) );
                List<WebElement> skillNames = parent.findElements( By.cssSelector( String.format( MasteryDetailsPage.studentTable, columnIndex ) ) );
                skillNames.stream().forEach( ele -> {
                    rowValuesFromUI.add( ele.getText().trim() );
                } );
            }
        } ) );

        return rowValuesFromUI;
    }
    //Verifying the student name, mastery status, skills Evaluated and attempts field for all assignments

    public boolean isDetailsDisplayed() {
        SMUtils.waitForElement( driver, masteryDetails );
        String assignmentNames = masteryDetails.getAttribute( "childElementCount" );
        boolean status = true;
        try {
            List<String> header = new ArrayList<String>();
            for ( WebElement element : listHeaders )
                header.add( element.getText().trim() );
            if ( header.equals( HEADERS ) )
                Log.pass( "Mastery Header details is getting displayed successfully" );
            else
                Log.fail( "Mastery Details page Header is not getting displayed!" );
            status = IntStream.range( 0, Integer.parseInt( assignmentNames ) ).allMatch( i -> {
                if ( SMUtils.isElementPresent( driver.findElement( By.cssSelector( String.format( MasteryDetailsPage.studentNameTable, i + 1 ) ) ) ) ) {
                    Log.pass( "All Details -Student names, Mastery Status, Skills Evaluated, Attempts values are getting displayed for each Assignments" );
                    return true;
                } else {
                    Log.fail( "All Details -Student names, Mastery Status, Skills Evaluated, Attempts values are not getting displayed for each Assignments  !" );
                    return false;
                }
            } );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return status;
    }

    /**
     * Get the list of Assignments in Mastery Details page.
     *
     * @return
     */

    public List<String> getAssignmentNameList() {
        SMUtils.waitForElement( driver, skillDetailsInProgressBarToolTip );
        List<String> listOfAssigments = new ArrayList<>();
        for ( WebElement eachAssigment : assignmentName ) {
            String assignment = eachAssigment.getText().trim();
            listOfAssigments.add( assignment );
        }
        Log.message( "Assignment List from the Details Page Fetched Successfully" );
        return listOfAssigments;
    }

    /**
     * To get Text from the Tool Tip of Progress Bar
     * 
     * @return
     */

    public String getProgressBarToolTipText() {
        SMUtils.waitForElement( driver, skillDetailsInProgressBarToolTip );
        String toolTipText = skillDetailsInProgressBarToolTip.getAttribute( "title" );
        Log.message( "Tool Tip text Fetched Successfully" );
        return toolTipText;

    }

    /**
     * Click the learning object link in the LO View page
     *
     * @return sco page title
     */
    public String clickLearningObjectLink() {
        Log.message( "Proceed to click the learning object link" );
        SMUtils.waitForElement( driver, learningObjectID );
        SMUtils.click( driver, learningObjectID );
        String oldWindow = SMUtils.switchWindow( driver );
        String scoPage = driver.getTitle();
        SMUtils.closeOtherWindows( driver, oldWindow );
        driver.switchTo().window( oldWindow );
        return scoPage;
    }

    /**
     * Click the back icon in the LO View page
     *
     * @return MasteryFiltersComponent page
     */
    public MasteryFiltersComponent clickChevronIcon() {
        Log.message( "Proceed to click the back icon link" );
        SMUtils.waitForElement( driver, learningObjectID );
        chevronIcon.click();
        return new MasteryFiltersComponent( driver );
    }

    /**
     * Check Learning Object link is displayed or not in LO view page
     *
     * @return boolean
     */
    public boolean verifyLearningObjectLinkIsDisplayed() {
        Log.message( "Proceed to verify learning object link is displayed" );
        try {
            learningObjectID.isDisplayed();
            return true;
        } catch ( org.openqa.selenium.NoSuchElementException e ) {
            return false;
        }
    }

    /**
     * Get count and color for all status
     *
     * @return count and color for all status
     */
    public Map<String, Map<String, Integer>> getCountAndColorForAllStatus() {
        Log.message( "Proceed to get student count for assessment: " );
        int statusCount = 0;
        int number = 0;
        Map<String, Map<String, Integer>> studentStatus = new HashMap<String, Map<String, Integer>>();
        SMUtils.waitForElement( driver, progressBarRoot, 5 );
        List<WebElement> ele = SMUtils.getWebElementsDirect( driver, progressBarRoot, progressBarStyle );
        Log.message( "The total status available in the progress bar is: " + ele.size() );
        for ( WebElement elem : ele ) {
            String[] style_RGB = elem.getAttribute( "style" ).split( ";" );
            String[] hexValue = style_RGB[0].replace( "background: rgb(", "" ).replace( ")", "" ).split( "," );
            hexValue[0] = hexValue[0].trim();
            int hexValue1 = Integer.parseInt( hexValue[0] );
            hexValue[1] = hexValue[1].trim();
            int hexValue2 = Integer.parseInt( hexValue[1] );
            hexValue[2] = hexValue[2].trim();
            int hexValue3 = Integer.parseInt( hexValue[2] );
            String colorCode = String.format( "#%02x%02x%02x", hexValue1, hexValue2, hexValue3 );
            SMUtils.waitForElement( driver, progressBarRoot, 5 );
            WebElement colourCount = SMUtils.getWebElementDirect( driver, progressBarRoot, String.format( progressBarValue, number + 1 ) );
            number++;
            if ( !colorCode.equalsIgnoreCase( Constants.MasteryUI.UNASSESSED_COLOR_CODE ) )
                statusCount = Integer.parseInt( colourCount.getText() );
            if ( colorCode.equalsIgnoreCase( Constants.MasteryUI.MASTERED_COLOR_CODE ) ) { //RGB (0,138,0)
                int finalStatusCount = statusCount;
                studentStatus.put( Constants.MasteryUI.MASTERED, new HashMap<String, Integer>() {
                    {
                        put( Constants.MasteryUI.MASTERED_COLOR_CODE, finalStatusCount );
                    }
                } );
            } else if ( colorCode.equalsIgnoreCase( Constants.MasteryUI.ATRISK_COLOR_CODE ) ) { //RGB (255,186,74)
                int finalStatusCount1 = statusCount;
                studentStatus.put( Constants.MasteryUI.AT_RISK, new HashMap<String, Integer>() {
                    {
                        put( Constants.MasteryUI.ATRISK_COLOR_CODE, finalStatusCount1 );
                    }
                } );
            } else if ( colorCode.equalsIgnoreCase( Constants.MasteryUI.NOTMASTERED_COLOR_CODE ) ) { //RGB (204,51,63)
                int finalStatusCount2 = statusCount;
                studentStatus.put( Constants.MasteryUI.NOT_MASTERED, new HashMap<String, Integer>() {
                    {
                        put( Constants.MasteryUI.NOTMASTERED_COLOR_CODE, finalStatusCount2 );
                    }
                } );
            } else if ( colorCode.equalsIgnoreCase( Constants.MasteryUI.UNASSESSED_COLOR_CODE ) ) { //RGB (205,207,209)
                studentStatus.put( Constants.MasteryUI.UNASSESSED, new HashMap<String, Integer>() {
                    {
                        put( Constants.MasteryUI.UNASSESSED_COLOR_CODE, 0 );
                    }
                } );
            } else
                Log.message( "Invalid color code detected. Please check." );
        }
        return studentStatus;
    }

    /**
     * Get student table headers
     *
     * @return header names
     */
    public List<String> getStudentTableHeaders() {
        Log.message( "Proceed to get headers for the student mastery table" );
        List<String> headers = new ArrayList<>();
        for ( WebElement ele : studentTableHeader ) {
            headers.add( ele.getText() );
        }
        return headers;
    }

    /**
     * Webelement of status badge
     *
     * @return weblement of status badge
     */
    public WebElement getStatusBadge() {
        SMUtils.waitForElement( driver, badgeRoot );
        WebElement badgeStatus = SMUtils.getWebElementDirect( driver, badgeRoot, badgeChild );
        return badgeStatus;
    }

    /**
     * To click back icon
     */
    public void clickBackBtn() {
        SMUtils.waitForElement( driver, backBtnRoot );
        WebElement element = SMUtils.getWebElementDirect( driver, backBtnRoot, innerIcon );
        SMUtils.click( driver, element );
    }

    /**
     * To Verify is mastery page loaded
     * 
     * @return
     */

    public Boolean isMasteryDetailsPageLoaded() {
        Boolean status = false;
        SMUtils.waitForElement( driver, skillParentName );
        try {
            if ( skillParentName.isDisplayed() ) {
                status = true;
                Log.message( "Mastery Details Page Loaded" );
            }
        } catch ( Exception e ) {
            Log.message( "Not Loaded" );
        }
        return status;
    }

    /**
     * To Click Bread Crumb Icon in Summary Page
     * 
     * 
     */

    public void clickBreadCrumbIcon() {
        WebElement breadCrumbBtn = SMUtils.getWebElementDirect( driver, masteryBackBreadCrumbBtnRoot, backbreadscrumbChild );
        SMUtils.clickJS( driver, breadCrumbBtn );
        Log.message( "Bread Crumb Button Clicked" );
    }

    /**
     * To Verify LO Description Present
     * 
     * @return
     */

    public Boolean verifyLODescriptionPresent() {
        Boolean status = false;
        SMUtils.waitForElement( driver, loDescriptionText, 8 );
        if ( loDescriptionText.isDisplayed() ) {
            status = true;
            Log.message( "LO Description Displayed" );
        }
        return status;
    }

    /**
     * To Verify Skill Description Present
     * 
     * @return
     */

    public Boolean verifySkillDescriptionPresent() {
        Boolean status = false;
        SMUtils.waitForElement( driver, skillDescription, 8 );
        if ( skillDescription.isDisplayed() ) {
            status = true;
            Log.message( "Skill Description Displayed" );
        }
        return status;
    }

    /**
     * To Verify Skill Parent Name Present
     * 
     * @return
     */

    public Boolean verifySkillParentName() {
        Boolean status = false;
        SMUtils.waitForElement( driver, skillParentName );
        if ( skillParentName.isDisplayed() ) {
            status = true;
            Log.message( "Skill Parent Name is  Displayed" );
        }
        return status;
    }

    /**
     * To Verify Skill Details Present In ProgressBar ToolTip
     * 
     * @return
     */

    public Boolean isSkillDetailsPresentInProgressBarToolTip() {
        Boolean status = false;
        SMUtils.waitForElement( driver, skillDetailsInProgressBarToolTip );
        if ( skillDetailsInProgressBarToolTip.isDisplayed() ) {
            status = true;
            Log.message( "Skill Details Present in the Progress Bar Tool Tip" );
        }
        return status;
    }

    /**
     * To Verify is LO Is Clickable And SCOContent Loaded
     * 
     * @return
     * @throws InterruptedException
     */

    public Boolean isNameOfLOIsClickableAndSCOContentLoaded() throws InterruptedException {
        Boolean status = false;
        SMUtils.waitForElement( driver, nameOfLOInMasteryDetailsPage );
        String currentwindow = driver.getWindowHandle();
        SMUtils.clickJS( driver, nameOfLOInMasteryDetailsPage );
        SMUtils.nap( 5 );// Required for safari Browser
        try {
            Set<String> windowHandles = driver.getWindowHandles();
            for ( String string : windowHandles ) {
                driver.switchTo().window( string );
            }
            driver.switchTo().frame( scoPageFrame );
            driver.switchTo().frame( "gadgetPlayer" );
            driver.switchTo().frame( finalFrame );
            SMUtils.waitForElement( driver, mobilePlayBtnCourseLaunchPage, 10 );
            boolean display = mobilePlayBtnCourseLaunchPage.isDisplayed();
            if ( display == true ) {
                Log.message( "LO name is clickable" );
                status = true;
            } else {
                Log.message( "LO Not Clickable" );
            }
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            return status;
        }
    }

    /**
     * To fetch WebElement for Headers in the Mastery Page Details
     * 
     * @return
     */

    public WebElement getWebElementForDetailsPageHeaders( String fieldName ) {
        SMUtils.waitForElement( driver, skillParentName );
        return masteryDetailPageHeader.stream().filter( element -> element.getText().trim().equals( fieldName ) ).findFirst().orElse( null );
    }

    /**
     * To Verify Mastery Details PageHeaderFields
     * 
     * @return
     */

    public Boolean verifyMasteryDetailsPageHeaderFields( String fieldName ) {
        Boolean status = false;
        SMUtils.waitForElement( driver, skillParentName );
        String header = getWebElementForDetailsPageHeaders( fieldName ).getText().trim();
        if ( fieldName.equals( header ) ) {
            Log.message( fieldName + "is present in the Mastery Details Page" );
            status = true;
        }
        return status;
    }

    /**
     * To Get Default Student Order DetailsPage
     * 
     * @return
     */
    public List<String> getDefaultStudentOrderDetailsPage() {
        List<String> defaultSort = new ArrayList<>();
        SMUtils.waitForElement( driver, skillParentName );
        for ( WebElement eachStudent : listOfStudentsInDetailsPage ) {
            defaultSort.add( eachStudent.getText().trim() );
        }
        return defaultSort;
    }

    /**
     * To Verify Student Order sorted in to Descending Order and then Ascending
     * Order
     * 
     * @return
     */

    public Boolean verifyStudentNameSortedToDescAndAsceInDetailsPage( List<String> defaultOrder ) {
        Boolean status = false;
        // Verify descending order
        List<String> descendingOrder = new ArrayList<>();
        SMUtils.clickJS( driver, getWebElementForDetailsPageHeaders( Constants.MasteryUI.STUDENT_FIELD ) );
        for ( WebElement eachStudent : listOfStudentsInDetailsPage ) {
            descendingOrder.add( eachStudent.getText().trim() );
        }
        Collections.reverse( descendingOrder );
        if ( defaultOrder.equals( descendingOrder ) ) {
            Log.message( "The Students Names sorted in to Descending Order" );
            status = true;
        } else {
            Log.fail( "Not Sorted as Expected" );
        }
        // Verify Ascending order
        SMUtils.clickJS( driver, getWebElementForDetailsPageHeaders( Constants.MasteryUI.STUDENT_FIELD ) );
        List<String> ascendingOrder = new ArrayList<>();
        for ( WebElement eachStudent : listOfStudentsInDetailsPage ) {
            ascendingOrder.add( eachStudent.getText().trim() );
        }
        if ( ascendingOrder.equals( defaultOrder ) ) {
            status = true;
            Log.message( "The Student Name Sorted in to Ascending Order" );
        } else {
            status = false;
            Log.message( "Not Sorted in to ascending order as expected" );
        }
        return status;

    }

    /**
     * To Get Ascending Order of Skills Evaluated
     * 
     * @return
     */

    public List<String> getAscendingOrderSkillsEvaluated() {
        List<String> ascendingOrder = new ArrayList<>();
        SMUtils.waitForElement( driver, skillParentName );
        SMUtils.clickJS( driver, getWebElementForDetailsPageHeaders( Constants.MasteryUI.SKILLS_EVALUATED_FIELD ) );
        for ( WebElement eachStudent : skillsEvaluatedInDetailsPage ) {
            ascendingOrder.add( eachStudent.getText().trim() );
        }
        return ascendingOrder;
    }

    /**
     * To Verify Skills Evaluated Field sorted in to Descending Order and then
     * Ascending Order
     * 
     * @return
     */

    public Boolean verifySkillsEvaluatedFieldSortedToDescAndAsceInDetailsPage( List<String> asceOrder ) {
        Boolean status = false;
        // Verify descending order
        List<String> descendingOrder = new ArrayList<>();
        SMUtils.clickJS( driver, getWebElementForDetailsPageHeaders( Constants.MasteryUI.SKILLS_EVALUATED_FIELD ) );
        for ( WebElement eachStudent : skillsEvaluatedInDetailsPage ) {
            descendingOrder.add( eachStudent.getText().trim() );
        }
        Collections.reverse( descendingOrder );
        if ( asceOrder.equals( descendingOrder ) ) {
            Log.message( "Skills Evaluated Field sorted in to Descending Order" );
            status = true;
        } else {
            Log.fail( "Not Sorted as Expected" );
        }
        // Verify Ascending order
        SMUtils.clickJS( driver, getWebElementForDetailsPageHeaders( Constants.MasteryUI.SKILLS_EVALUATED_FIELD ) );
        List<String> ascendingOrder = new ArrayList<>();
        for ( WebElement eachStudent : skillsEvaluatedInDetailsPage ) {
            ascendingOrder.add( eachStudent.getText().trim() );
        }
        if ( ascendingOrder.equals( asceOrder ) ) {
            status = true;
            Log.message( "Skills Evaluated Field Sorted in to Ascending Order" );
        } else {
            status = false;
            Log.message( "Not Sorted in to ascending order as expected" );
        }
        return status;

    }

    /**
     * To Get Ascending Order of Attempts Field
     * 
     * @return
     */

    public List<String> getAscendingOrderAttemptsField() {
        List<String> ascendingOrder = new ArrayList<>();
        SMUtils.waitForElement( driver, skillParentName );
        SMUtils.clickJS( driver, getWebElementForDetailsPageHeaders( Constants.MasteryUI.ATTEMPTS_FIELD ) );
        for ( WebElement eachStudent : attemptsValuesInDetailsPage ) {
            ascendingOrder.add( eachStudent.getText().trim() );
        }
        return ascendingOrder;
    }

    /**
     * To Verify Attempts Field sorted in to Descending Order and then Ascending
     * Order
     * 
     * @return
     */

    public Boolean verifyAttemptsFieldSortedToDescAndAsceInDetailsPage( List<String> asceOrder ) {
        Boolean status = false;
        // Verify descending order
        List<String> descendingOrder = new ArrayList<>();
        SMUtils.clickJS( driver, getWebElementForDetailsPageHeaders( Constants.MasteryUI.ATTEMPTS_FIELD ) );
        for ( WebElement eachStudent : attemptsValuesInDetailsPage ) {
            descendingOrder.add( eachStudent.getText().trim() );
        }
        Collections.reverse( descendingOrder );
        if ( asceOrder.equals( descendingOrder ) ) {
            Log.message( "Attempts Field sorted in to Descending Order" );
            status = true;
        } else {
            Log.fail( "Not Sorted as Expected" );
        }
        // Verify Ascending order
        SMUtils.clickJS( driver, getWebElementForDetailsPageHeaders( Constants.MasteryUI.ATTEMPTS_FIELD ) );
        List<String> ascendingOrder = new ArrayList<>();
        for ( WebElement eachStudent : attemptsValuesInDetailsPage ) {
            ascendingOrder.add( eachStudent.getText().trim() );
        }
        if ( ascendingOrder.equals( asceOrder ) ) {
            status = true;
            Log.message( "Attempts Field Sorted in to Ascending Order" );
        } else {
            status = false;
            Log.message( "Not Sorted in to ascending order as expected" );
        }
        return status;

    }

    /**
     * To Get Ascending Order of Mastery Field
     * 
     * @return
     */

    public List<String> getMasteryFieldAscendOrder() {
        List<String> ascendingOrder = new ArrayList<>();
        SMUtils.waitForElement( driver, skillParentName );
        SMUtils.clickJS( driver, getWebElementForDetailsPageHeaders( Constants.MasteryUI.MASTERY_STATUS_FIELD ) );
        for ( WebElement eachElement : getMasteryStatusRoot ) {
            WebElement webElementDirect = SMUtils.getWebElementDirect( driver, eachElement, getMasteryStatuschild );
            ascendingOrder.add( webElementDirect.getText().trim() );
        }
        return ascendingOrder;
    }

    /**
     * To Verify Mastery Status Field sorted in to Descending Order and then
     * Ascending Order
     * 
     * @return
     */

    public Boolean verifyMasteryStatusFieldSortedToDescAndAsceInDetailsPage( List<String> asceOrder ) {
        Boolean status = false;
        // Verify descending order
        List<String> descendingOrder = new ArrayList<>();
        SMUtils.clickJS( driver, getWebElementForDetailsPageHeaders( Constants.MasteryUI.MASTERY_STATUS_FIELD ) );
        for ( WebElement eachMasteryRoot : getMasteryStatusRoot ) {
            descendingOrder.add( SMUtils.getWebElementDirect( driver, eachMasteryRoot, getMasteryStatuschild ).getText().trim() );
        }
        Collections.reverse( descendingOrder );
        if ( asceOrder.equals( descendingOrder ) ) {
            Log.message( "Mastery Status Field sorted in to Descending Order" );
            status = true;
        } else {
            Log.fail( "Not Sorted as Expected" );
        }
        // Verify Ascending order
        SMUtils.clickJS( driver, getWebElementForDetailsPageHeaders( Constants.MasteryUI.MASTERY_STATUS_FIELD ) );
        List<String> ascendingOrder = new ArrayList<>();
        for ( WebElement eachMasteryRoot : getMasteryStatusRoot ) {
            ascendingOrder.add( SMUtils.getWebElementDirect( driver, eachMasteryRoot, getMasteryStatuschild ).getText().trim() );
        }
        if ( ascendingOrder.equals( asceOrder ) ) {
            status = true;
            Log.message( "Mastery Status Sorted in to Ascending Order" );
        } else {
            status = false;
            Log.message( "Not Sorted in to ascending order as expected" );
        }
        return status;

    }

    /**
     * To get the MasteryValues Element locator
     * 
     * @param AssignmentCount and masteryValueCount
     * @return
     */
    private WebElement getMasteryValueStatus( int masteryCount ) {
        WebElement masteryStatusRoot = driver.findElement( By.cssSelector( String.format( masteryValueName, masteryCount ) ) );
        WebElement masteryStatus = SMUtils.getWebElementDirect( driver, masteryStatusRoot, masteryValueChild );
        return masteryStatus;
    }

    /**
     * Validate mastery Color status code for Mastered, Not Mastered and At Risk
     * status
     * 
     * return status
     */
    public boolean verifyMasteryValueBGColor( String browser ) {
        boolean status = false;
        try {
            String masteryCount = driver.findElement( By.cssSelector( String.format( MasteryDetailsPage.masteryValues ) ) ).getAttribute( "childElementCount" );
            IntStream.range( 0, Integer.parseInt( masteryCount ) ).forEach( i -> {
                if ( driver.findElement( By.cssSelector( String.format( MasteryDetailsPage.masteryValueName, i + 1 ) ) ).getText().trim().equals( "Not Mastered" ) ) {
                    WebElement ele = getMasteryValueStatus( i + 1 );
                    String rgbColor = ele.getCssValue( "background-color" );
                    if ( !browser.contains( "Safari" ) ) {
                        if ( rgbColor.equals( Constants.MasteryUI.NOTMASTERED_RGB_CODE_CHROME ) )
                            Log.pass( "The NOT mastered mastery status has red colour background" );
                        else
                            Log.fail( "The NOT mastered mastery status has not red colour background!" );
                    } else {
                        if ( rgbColor.equals( Constants.MasteryUI.NOTMASTERED_RGB_CODE_SAFARI ) )
                            Log.pass( "The NOT mastered mastery status has red colour background" );
                        else
                            Log.fail( "The NOT mastered mastery status has not red colour background!" );
                    }

                } else if ( driver.findElement( By.cssSelector( String.format( MasteryDetailsPage.masteryValueName, i + 1 ) ) ).getText().trim().equals( "Mastered" ) ) {
                    WebElement ele1 = getMasteryValueStatus( i + 1 );
                    String rgbColor1 = ele1.getCssValue( "background-color" );
                    if ( !browser.contains( "Safari" ) ) {
                        if ( rgbColor1.equals( Constants.MasteryUI.MASTERED_RGB_CODE_CHROME ) )
                            Log.pass( "The Mastered mastery status has Green colour background" );
                        else
                            Log.fail( "The Mastered mastery status has not Green colour background!" );
                    } else {
                        if ( rgbColor1.equals( Constants.MasteryUI.MASTERED_RGB_CODE_SAFARI ) )
                            Log.pass( "The Mastered mastery status has Green colour background" );
                        else
                            Log.fail( "The Mastered mastery status has not Green colour background!" );
                    }
                } else if ( driver.findElement( By.cssSelector( String.format( MasteryDetailsPage.masteryValueName, i + 1 ) ) ).getText().trim().equals( "At Risk" ) ) {
                    WebElement ele2 = getMasteryValueStatus( i + 1 );
                    String rgbColor2 = ele2.getCssValue( "background-color" );
                    if ( !browser.contains( "Safari" ) ) {
                        if ( rgbColor2.equals( Constants.MasteryUI.ATRISK_RGB_CODE_CHROME ) )
                            Log.pass( "The AtRisk mastery status has Yellow colour background" );
                        else
                            Log.fail( "The AtRisk mastery status has not Yellow colour background!" );
                    } else {
                        if ( rgbColor2.equals( Constants.MasteryUI.ATRISK_RGB_CODE_SAFARI ) )
                            Log.pass( "The AtRisk mastery status has Yellow colour background" );
                        else
                            Log.fail( "The AtRisk mastery status has not Yellow colour background!" );
                    }
                }
            } );
            status = true;
        } catch ( Exception e ) {
            e.printStackTrace();
        }

        return status;
    }

    /**
     * Getting the mastered count, not mastered count, atrisk count irrespective
     * of assignments
     * 
     * Parameters MasteryValue
     * 
     * return counts
     */
    public int getStatusCount( String masteryValue ) {
        AtomicReference<Integer> count = new AtomicReference<Integer>();
        List<String> status = new ArrayList<String>();
        try {
            String masteryCount = driver.findElement( By.cssSelector( String.format( MasteryDetailsPage.masteryValues ) ) ).getAttribute( "childElementCount" );
            IntStream.range( 0, Integer.parseInt( masteryCount ) ).forEach( i -> {
                WebElement ele1 = getMasteryValueStatus( i + 1 );
                String a = ele1.getText().toString().trim();
                status.add( a );
            } );
            Log.message( "" + status );
            count.set( Collections.frequency( status, masteryValue ) );

        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return count.get();
    }

    /**
     * Getting students count from Mastered, NotMastered, AtRisk Progress Bar
     * 
     * Parameters MasteryValue
     * 
     * Return count
     */
    public int getStudentsCount( String masteryValue ) {
        int studentsCount = 0;
        try {
            SMUtils.waitForElement( driver, progressBarRoot );
            String val = progressBarRoot.getAttribute( SMUtils.TITLE_ATTRIBUTE ).toString();
            String[] split = val.split( "," );
            if ( masteryValue.equals( Constants.MasteryUI.MASTERED ) )
                studentsCount = Integer.parseInt( split[0].trim().split( " " )[0] );
            else if ( masteryValue.equals( Constants.MasteryUI.NOT_MASTERED ) )
                studentsCount = Integer.parseInt( split[1].trim().split( " " )[0] );
            else if ( masteryValue.equals( Constants.MasteryUI.AT_RISK ) )
                studentsCount = Integer.parseInt( split[2].trim().split( " " )[0] );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return studentsCount;
    }

    /**
     * Get count and color for all status in the progressBar
     *
     * @return count and color for all status
     */
    public Map<String, Map<String, Integer>> getCountAndColorInProgressBar( String browser ) {
        Log.message( "Proceed to get student count for assessment: " );
        int statusCount = 0;
        int number = 0;
        String colorCode;
        Map<String, Map<String, Integer>> studentStatus = new HashMap<String, Map<String, Integer>>();
        SMUtils.waitForElement( driver, progressBarRoot, 5 );
        List<WebElement> ele = SMUtils.getWebElementsDirect( driver, progressBarRoot, progressBarStyle );
        Log.message( "The total status available in the progress bar is: " + ele.size() );
        for ( WebElement elem : ele ) {
            if ( !browser.contains( "Safari" ) ) {
                String[] style_RGB = elem.getAttribute( "style" ).split( ";" );
                String[] hexValue = style_RGB[0].replace( "background: rgb(", "" ).replace( ")", "" ).split( "," );
                hexValue[0] = hexValue[0].trim();
                int hexValue1 = Integer.parseInt( hexValue[0] );
                hexValue[1] = hexValue[1].trim();
                int hexValue2 = Integer.parseInt( hexValue[1] );
                hexValue[2] = hexValue[2].trim();
                int hexValue3 = Integer.parseInt( hexValue[2] );
                colorCode = String.format( "#%02x%02x%02x", hexValue1, hexValue2, hexValue3 );
            } else {
                String[] style_RGB = elem.getAttribute( "style" ).split( ";" );
                String[] hexValue = style_RGB[0].replace( "background-color: rgb(", "" ).replace( ")", "" ).split( "," );
                hexValue[0] = hexValue[0].trim();
                int hexValue1 = Integer.parseInt( hexValue[0] );
                hexValue[1] = hexValue[1].trim();
                int hexValue2 = Integer.parseInt( hexValue[1] );
                hexValue[2] = hexValue[2].trim();
                int hexValue3 = Integer.parseInt( hexValue[2] );
                colorCode = String.format( "#%02x%02x%02x", hexValue1, hexValue2, hexValue3 );
            }
            SMUtils.waitForElement( driver, progressBarRoot, 5 );
            WebElement colourCount = SMUtils.getWebElementDirect( driver, progressBarRoot, String.format( progressBarValue, number + 1 ) );
            number++;
            if ( !colorCode.equalsIgnoreCase( Constants.MasteryUI.UNASSESSED_COLOR_CODE ) )
                statusCount = Integer.parseInt( colourCount.getText() );
            if ( colorCode.equalsIgnoreCase( Constants.MasteryUI.MASTERED_COLOR_CODE ) ) { //RGB (0,138,0)
                int finalStatusCount = statusCount;
                studentStatus.put( Constants.MasteryUI.MASTERED, new HashMap<String, Integer>() {
                    {
                        put( Constants.MasteryUI.MASTERED_COLOR_CODE, finalStatusCount );
                    }
                } );
            } else if ( colorCode.equalsIgnoreCase( Constants.MasteryUI.ATRISK_COLOR_CODE ) ) { //RGB (255,186,74)
                int finalStatusCount1 = statusCount;
                studentStatus.put( Constants.MasteryUI.AT_RISK, new HashMap<String, Integer>() {
                    {
                        put( Constants.MasteryUI.ATRISK_COLOR_CODE, finalStatusCount1 );
                    }
                } );
            } else if ( colorCode.equalsIgnoreCase( Constants.MasteryUI.NOTMASTERED_COLOR_CODE ) ) { //RGB (204,51,63)
                int finalStatusCount2 = statusCount;
                studentStatus.put( Constants.MasteryUI.NOT_MASTERED, new HashMap<String, Integer>() {
                    {
                        put( Constants.MasteryUI.NOTMASTERED_COLOR_CODE, finalStatusCount2 );
                    }
                } );
            } else if ( colorCode.equalsIgnoreCase( Constants.MasteryUI.UNASSESSED_COLOR_CODE ) ) { //RGB (205,207,209)
                studentStatus.put( Constants.MasteryUI.UNASSESSED, new HashMap<String, Integer>() {
                    {
                        put( Constants.MasteryUI.UNASSESSED_COLOR_CODE, 0 );
                    }
                } );
            } else
                Log.message( "Invalid color code detected. Please check." );
        }
        return studentStatus;
    }

    /**
     * Compares the Background color of Students before and after Hover overing
     * the Students Name
     * 
     * @return
     * @throws Exception
     */
    public boolean isColorChangedOnhoverOverStudentName() throws Exception {
        String beforeHover = SMUtils.getBackgroundColor( listOfStudentsInDetailsPage.stream().findFirst().get() );
        SMUtils.moveToElementJS( driver, listOfStudentsInDetailsPage.stream().findFirst().get() );
        String afterHover = SMUtils.getBackgroundColor( listOfStudentsInDetailsPage.stream().findFirst().get() );

        Log.message( "Color before the element is Hover Overed: " + beforeHover + " && Color after the element is Hover Overed: " + afterHover );

        return ( afterHover.equals( beforeHover ) );
    }

}
