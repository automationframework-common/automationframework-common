package com.savvas.sm.ui.tests.mastery;

import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.DevTools;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.chromedevtools.RequestMockUtils;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.ui.mastery.pages.DevToolsUtils;
import com.savvas.sm.ui.mastery.pages.MasteryDetailsPage;
import com.savvas.sm.ui.mastery.pages.MasteryFiltersComponent;
import com.savvas.sm.ui.mastery.pages.MasteryMfePage;
import com.savvas.sm.ui.mastery.pages.MasteryPage;
import com.savvas.sm.ui.mastery.pages.MasterySummaryComponent;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;

public class MasteryMfeLOViewTest extends BaseTest {

    private String masteryMfeUrl;
    private String browser;
    private String Math_Assignment;
    private String masteryBFF;
    private String bffEndpoint;
    private String bff;


    @BeforeTest ( alwaysRun = true )
    public void initTest( ITestContext context ) throws MalformedURLException {
        browser = "Windows_10_Chrome_100";
        if ( context != null && context.getIncludedGroups() != null && Arrays.stream( context.getIncludedGroups() ).anyMatch( group -> group.equals( "mock" ) ) ) {
         bff = MasteryConstants.Graphql.BASE_URL;
         bffEndpoint = MasteryConstants.Graphql.ENDPOINT;
         masteryBFF=bff+bffEndpoint;

        }
    }

    @Test ( priority = 1, dataProvider = "masteryLoViewValidation", groups = { "mastery", "P1", "masteryLOview", "mock" } )
    public void tcLOViewTest( String loginAs, String loginUrl, String loginUserName, ITestContext context ) throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo(loginAs + " Mastery LO View Test" + "<small><b><i>[" + browser + "]</b></i></small>");
		masteryMfeUrl = configProperty.getProperty(loginUrl);
		 DevTools devTool=null;
		try {
			LoginWrapper.loginToMasteryMfe(driver, masteryMfeUrl, loginUserName, "testing123$");
			MasteryMfePage masteryMfePage = new MasteryMfePage(driver);
			MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();
			masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);
			masteryFiltersComponent.selectSkillStandards(Constants.MasteryUI.SKILL_MATH);
			MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();
			MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.clickLOLink();
			 
			if ( context != null && context.getIncludedGroups() != null && Arrays.stream( context.getIncludedGroups() ).anyMatch( group -> group.equals( "mock" ) ) ) {
	                //mocking
	                String responseJson = DevToolsUtils.readJsonResponse( "MasteryLoView.json" );
	                 devTool = DevToolsUtils.setResponse( driver, masteryBFF, "post", 200, responseJson );
	                devTool.createSessionIfThereIsNotOne();
	                Log.message( devTool.getCdpSession().toString() );
			}
			SMUtils.logDescriptionTC(
					"TC:02 : Verify the teacher can able to see the SCO content belongs to the LO, when Math subject is chosen with skills");
			Log.assertThat(
					masteryDetailsPage.clickLearningObjectLink()
							.equalsIgnoreCase(masteryDetailsPage.learningObjectID.getText()),
					"The teacher can able to see the SCO content belongs to the LO, when Math subject is chosen with skills",
					"The teacher is not able to see the SCO content belongs to the LO, when Math subject is chosen with skills");
			Log.testCaseResult();
			
			SMUtils.logDescriptionTC(
					"TC:06 : Verify the student name(first name, last name), Mastery Status, Skills Evaluated, Attemps fields in the Mastery details page");
			Log.assertThat(Constants.MasteryUI.masteryTableHeaders.equals(masteryDetailsPage.getStudentTableHeaders()),
					"The 'Student', 'Mastery Status', 'Skills Evaluated', 'Attempts' are available in the mastery header",
					"The 'Student', 'Mastery Status', 'Skills Evaluated', 'Attempts' are not available in the mastery header");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:07: Verify the student name fields are sorted in ascending by default in the Mastery details page");
			SMUtils.waitForElement(driver, masteryDetailsPage.getStatusBadge());
			List<String> studentsName = masteryDetailsPage.getStudentName("As_copy_Single_LO");
			Log.assertThat(studentsName.equals(SMUtils.sortList(studentsName)),
					"The student name fields are sorted in ascending by default in the Mastery details page",
					"The student name fields are not sorted in ascending by default in the Mastery details page");
			Log.testCaseResult();
			
			SMUtils.logDescriptionTC(
					"TC:08 : Verify the teacher is able to sort the 'student name' field in descending order in the Mastery details page");
			SMUtils.clickJS(driver,
					masteryDetailsPage.getWebElementForDetailsPageHeaders(Constants.MasteryUI.STUDENT_FIELD));
			SMUtils.waitForElement(driver, masteryDetailsPage.getStatusBadge());
			List<String> studentDescending = masteryDetailsPage.getStudentName("As_copy_Single_LO");
			Log.assertThat(studentDescending.equals(SMUtils.sortAndReverseList(studentsName)),
					"The student name fields are sorted in ascending by default in the Mastery details page",
					"The student name fields are not sorted in ascending by default in the Mastery details page");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:09 : Verify the teacher is able to sort the 'Attempts field' in ascending order in the Mastery details page");
			SMUtils.clickJS(driver,
					masteryDetailsPage.getWebElementForDetailsPageHeaders(Constants.MasteryUI.ATTEMPTS_FIELD));
			SMUtils.waitForElement(driver, masteryDetailsPage.getStatusBadge());
			List<String> attemptsFieldAsc = masteryDetailsPage.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.ATTEMPTS_FIELD);
			Log.assertThat(attemptsFieldAsc.equals(SMUtils.sortList(attemptsFieldAsc)),
					"The " + Constants.MasteryUI.ATTEMPTS_FIELD
							+ " fields are sorted in ascending in the Mastery details page",
					"The " + Constants.MasteryUI.ATTEMPTS_FIELD
							+ " fields are not sorted in ascending in the Mastery details page");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:11 : Verify the teacher is able to sort the 'Mastery Status' field in ascending order in the Mastery details page");
			List<String> masteryStsBfrSortingAsc = masteryDetailsPage.getRowValuesBasedOnTheColumn("Math_Assignment",
					Constants.MasteryUI.MASTERY_STATUS_FIELD);
			SMUtils.clickJS(driver,
					masteryDetailsPage.getWebElementForDetailsPageHeaders(Constants.MasteryUI.MASTERY_STATUS_FIELD));
			SMUtils.waitForElement(driver, masteryDetailsPage.getStatusBadge());
			List<String> masteryStatusAsc = masteryDetailsPage.getRowValuesBasedOnTheColumn("Math_Assignment",
					Constants.MasteryUI.MASTERY_STATUS_FIELD);
			Log.assertThat(masteryStatusAsc.equals(SMUtils.sortList(masteryStsBfrSortingAsc)),
					"The " + Constants.MasteryUI.MASTERY_STATUS_FIELD
							+ " fields are sorted in ascending in the Mastery details page",
					"The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD
							+ " fields are not sorted in ascending in the Mastery details page");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:12 : Verify the teacher is able to sort the 'Mastery Status' field in descending order in the Mastery details page");
			List<String> masteryStsBfrSortingDsc = masteryDetailsPage.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.MASTERY_STATUS_FIELD);
			SMUtils.clickJS(driver,
					masteryDetailsPage.getWebElementForDetailsPageHeaders(Constants.MasteryUI.MASTERY_STATUS_FIELD));
			SMUtils.waitForElement(driver, masteryDetailsPage.getStatusBadge());
			List<String> masteryStatusDesc = masteryDetailsPage.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.MASTERY_STATUS_FIELD);
			Log.assertThat(masteryStatusDesc.equals(SMUtils.sortAndReverseList(masteryStsBfrSortingDsc)),
					"The " + Constants.MasteryUI.MASTERY_STATUS_FIELD
							+ " fields are sorted in descending in the Mastery details page",
					"The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD
							+ " fields are not sorted in descending order in the Mastery details page");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:13: Verify the teacher is able to sort the 'Skills Evaluated' field in ascending order in the Mastery details page");
			List<String> skillEvalBeforeSortingAsc = masteryDetailsPage.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.SKILLS_EVALUATED_FIELD);
			SMUtils.clickJS(driver,
					masteryDetailsPage.getWebElementForDetailsPageHeaders(Constants.MasteryUI.SKILLS_EVALUATED_FIELD));
			SMUtils.waitForElement(driver, masteryDetailsPage.getStatusBadge());
			List<String> skillsEvaluatedAsc = masteryDetailsPage.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.SKILLS_EVALUATED_FIELD);
			List<Integer> skillsEvaluatedAscExpectedInt = skillsEvaluatedAsc.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			List<Integer> skillsEvaluatedAscInt = skillEvalBeforeSortingAsc.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			Log.assertThat(skillsEvaluatedAscExpectedInt.equals(SMUtils.sortListInteger(skillsEvaluatedAscInt)),
					"The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD
							+ " fields are sorted in ascending in the Mastery details page",
					"The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD
							+ " fields are not sorted in ascending in the Mastery details page");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:14 : Verify the teacher is able to sort the 'Skills Evaluated' field in descending order in the Mastery details page");
			List<String> skillEvalBeforeSortingDsc = masteryDetailsPage.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.SKILLS_EVALUATED_FIELD);
			SMUtils.clickJS(driver,
					masteryDetailsPage.getWebElementForDetailsPageHeaders(Constants.MasteryUI.SKILLS_EVALUATED_FIELD));
			SMUtils.waitForElement(driver, masteryDetailsPage.getStatusBadge());
			List<String> skillsEvaluatedDsc = masteryDetailsPage.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.SKILLS_EVALUATED_FIELD);
			List<Integer> skillsEvaluatedDscExpectedInt = skillsEvaluatedDsc.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			List<Integer> skillsEvaluatedDescInt = skillEvalBeforeSortingDsc.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			Log.assertThat(
					skillsEvaluatedDscExpectedInt.equals(SMUtils.sortAndReverseListInteger(skillsEvaluatedDescInt)),
					"The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD
							+ " fields are sorted in descending in the Mastery details page",
					"The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD
							+ " fields are not sorted in descending order in the Mastery details page");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:15 : Verify the teacher is able to sort the 'Attempts field' in ascending order in the Mastery details page");
			List<String> attemptsFieldBeforeSortingDsc = masteryDetailsPage
					.getRowValuesBasedOnTheColumn(Math_Assignment, Constants.MasteryUI.ATTEMPTS_FIELD);
			SMUtils.clickJS(driver,
					masteryDetailsPage.getWebElementForDetailsPageHeaders(Constants.MasteryUI.ATTEMPTS_FIELD));
			SMUtils.waitForElement(driver, masteryDetailsPage.getStatusBadge());
			List<String> attemptsFieldAsc1 = masteryDetailsPage.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.ATTEMPTS_FIELD);
			List<Integer> attemptsFieldAscExpectedInt = attemptsFieldAsc1.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			List<Integer> attemptsFieldAscInt = attemptsFieldBeforeSortingDsc.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			Log.assertThat(attemptsFieldAscExpectedInt.equals(SMUtils.sortListInteger(attemptsFieldAscInt)),
					"The " + Constants.MasteryUI.ATTEMPTS_FIELD
							+ " fields are sorted in ascending order in the Mastery details page",
					"The " + Constants.MasteryUI.ATTEMPTS_FIELD
							+ " fields are not sorted in ascending order in the Mastery details page");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"TC:16 : Verify the teacher is able to sort the Attempts field in descending order in the Mastery details page");
			List<String> attemptsFieldBeforeSortingAsc = masteryDetailsPage
					.getRowValuesBasedOnTheColumn(Math_Assignment, Constants.MasteryUI.ATTEMPTS_FIELD);
			SMUtils.clickJS(driver,
					masteryDetailsPage.getWebElementForDetailsPageHeaders(Constants.MasteryUI.ATTEMPTS_FIELD));
			SMUtils.waitForElement(driver, masteryDetailsPage.getStatusBadge());
			List<String> attemptsFieldDesc = masteryDetailsPage.getRowValuesBasedOnTheColumn(Math_Assignment,
					Constants.MasteryUI.ATTEMPTS_FIELD);
			List<Integer> attemptsFieldDescExpectedInt = attemptsFieldDesc.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			List<Integer> attemptsFieldDescInt = attemptsFieldBeforeSortingAsc.stream().map(Integer::valueOf)
					.collect(Collectors.toList());
			Log.assertThat(attemptsFieldDescExpectedInt.equals(SMUtils.sortAndReverseListInteger(attemptsFieldDescInt)),
					"The " + Constants.MasteryUI.ATTEMPTS_FIELD
							+ " fields are sorted in descending order in the Mastery details page",
					"The " + Constants.MasteryUI.ATTEMPTS_FIELD
							+ " fields are not sorted in descending order in the Mastery details page");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
                    "TC:10 : Verify the teacher is able to navigate back to the Mastery view page when they click on the breadcrumb icon in the top of the Mastery detail page");
            masteryDetailsPage.clickBackBtn();

            MasteryPage masteryPage = new MasteryPage(driver);
            Log.assertThat(masteryPage.lblMasteryHeading.isDisplayed(),
                    "The teacher is able to navigate back to the Mastery view page when they click on the breadcrumb icon in the top of the Mastery detail page",
                    "The teacher is not able to navigate back to the Mastery view page when they click on the breadcrumb icon in the top of the Mastery detail page");
            Log.testCaseResult();

			
		} catch (Exception e) {
            Log.exception(e, driver);
        } finally {
            Log.endTestCase();
            if (null != devTool) {
                DevToolsUtils.closeMock( devTool );
            }
            driver.quit();
        }

    }

		@Test(priority = 1, dataProvider = "masteryLoViewValidation",groups = { "mastery", "P1", "masteryLOview", "mock" } )
		public void tcLOMasteryViewTest( String loginAs, String loginUrl, String loginUserName, ITestContext context ) throws Exception {
			// Get driver
			final WebDriver driver = WebDriverFactory.get(browser);
			Log.testCaseInfo(loginAs + " Mastery LO View Test" + "<small><b><i>[" + browser + "]</b></i></small>");
			masteryMfeUrl = configProperty.getProperty(loginUrl);
			DevTools devTool=null;
	        try {
				// login to Mastery mfe as Teacher
				// LoginWrapper.loginToMasteryMfe(driver, masteryMfeUrl, "as_mastery_teacher",
				// "testing123$");
				LoginWrapper.loginToMasteryMfe(driver, masteryMfeUrl, loginUserName, "testing123$");
				MasteryMfePage masteryMfePage = new MasteryMfePage(driver);
				MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();
				masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);
				masteryFiltersComponent.selectSkillStandards(Constants.MasteryUI.SKILL_MATH);
				MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();
				MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.clickLOLink();
				
				if ( context != null && context.getIncludedGroups() != null && Arrays.stream( context.getIncludedGroups() ).anyMatch( group -> group.equals( "mock" ) ) ) {
                    //mocking
                    String responseJson = DevToolsUtils.readJsonResponse( "MasteryLoView.json" );
                     devTool = DevToolsUtils.setResponse( driver, masteryBFF, "post", 200, responseJson );
                    devTool.createSessionIfThereIsNotOne();
                    Log.message( devTool.getCdpSession().toString() );
            }
				SMUtils.logDescriptionTC(
						"TC 01 : Verify the teacher is able to see the LO as a blue link, when Math subject is chosen with skills");
				Log.assertThat(masteryDetailsPage.getLOColor(browser).contentEquals(Constants.MasteryUI.LO_ID_COLOR_CODE),
						"Teacher is able to see the LO as a blue link",
						"Teacher is not able to see the LO as a blue link, when Math subject is chosen with skills");
				Log.testCaseResult();

				SMUtils.logDescriptionTC(
						"TC:17: Verify the Mastery status columnn values in red color for Not Mastered values for both Math/Reading courses skills or standards");
				SMUtils.logDescriptionTC(
						"TC:18: Verify the Mastery status columnn values in yellow color for At Risk values for both Math/Reading courses skills or standards");
				SMUtils.logDescriptionTC(
						"TC:19: Verify the Mastery status columnn values in green color for Mastered values for both Math/Reading courses skills or standards");

				Log.assertThat(masteryDetailsPage.verifyMasteryValueBGColor(browser),
						"All the mastery status values are displayed with respective color background",
						"All the mastery status values are not displayed with respective color background!");

				Log.testCaseResult();
				Log.testCaseResult();
				Log.testCaseResult();

				SMUtils.logDescriptionTC(
						"TC:20: Verify the Mastery status columnn values in Grey color for Not Assessed values for both Math/Reading courses skills or standards");
				Map<String, Map<String, Integer>> student_Status = masteryDetailsPage
						.getCountAndColorInProgressBar(browser);
				Log.assertThat(
						student_Status.get(Constants.MasteryUI.UNASSESSED)
								.containsKey(Constants.MasteryUI.UNASSESSED_COLOR_CODE),
						"The 'Unassessed' value in the Mastery Status columnn is displayed in Grey color",
						"The 'Unassessed' value in the Mastery Status columnn is not displayed as grey color");
				Log.testCaseResult();

				
			} catch (Exception e) {
	            Log.exception(e, driver);
	        } finally {
	            Log.endTestCase();
	            if (null != devTool) {
	                DevToolsUtils.closeMock( devTool );	            }
	            driver.quit();
	        }

	    }
		@Test(priority = 1, dataProvider = "masteryLoViewValidation",groups = { "mastery", "P1", "masteryLOview", "mock" } )
        public void tcLOMasteryViewTest01( String loginAs, String loginUrl, String loginUserName, ITestContext context ) throws Exception {
            // Get driver
            final WebDriver driver = WebDriverFactory.get(browser);
            Log.testCaseInfo(loginAs + " Mastery LO View Test" + "<small><b><i>[" + browser + "]</b></i></small>");
            masteryMfeUrl = configProperty.getProperty(loginUrl);
            DevTools devTool=null;
            try {
                // login to Mastery mfe as Teacher
                // LoginWrapper.loginToMasteryMfe(driver, masteryMfeUrl, "as_mastery_teacher",
                // "testing123$");
                LoginWrapper.loginToMasteryMfe(driver, masteryMfeUrl, loginUserName, "testing123$");
                MasteryMfePage masteryMfePage = new MasteryMfePage(driver);
                MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();
                masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);
                masteryFiltersComponent.selectSkillStandards(Constants.MasteryUI.STANDARD_AIMSWEBPLUS_MATH);
                MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();
                MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.clickLOLink();
                
                if ( context != null && context.getIncludedGroups() != null && Arrays.stream( context.getIncludedGroups() ).anyMatch( group -> group.equals( "mock" ) ) ) {
                    //mocking
                    String responseJson = DevToolsUtils.readJsonResponse( "MasteryLoView.json" );
                     devTool = DevToolsUtils.setResponse( driver, masteryBFF, "post", 200, responseJson );
                    devTool.createSessionIfThereIsNotOne();
                    Log.message( devTool.getCdpSession().toString() );
            }
		
		
		SMUtils.logDescriptionTC(
                "TC:03 : Verify the teacher is not able to see the LO name, when Math subject is chosen with standards");
        SMUtils.waitForElement(driver, masteryDetailsPage.learningObjectID);
        Log.assertThat(masteryDetailsPage.learningObjectID.getText().equals(""),
                "The LO Link is not visible when Math subject is chosen with standards",
                "The LO Link is visible when Math subject is chosen with standards");
        Log.testCaseResult();

        SMUtils.logDescriptionTC(
                "TC:04 : Verify the teacher is not able to see the LO name, when Reading subject is chosen");
        masteryDetailsPage.clickChevronIcon();
        masteryFiltersComponent.expandToggle();
        masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_READING);
        MasterySummaryComponent masterySummaryComponent3 = masteryFiltersComponent.applyFilter();
        MasteryDetailsPage masteryDetailsPage3 = masterySummaryComponent3.clickLOLink();
        Log.assertThat(!masteryDetailsPage3.verifyLearningObjectLinkIsDisplayed(),
                "The LO Link is not visible when Reading subject is chosen with skills",
                "The LO Link is visible when Reading subject is chosen with skills");
        Log.testCaseResult();

        SMUtils.logDescriptionTC(
                "TC:05 : Verify the teacher is not able to see the LO name, when Reading subject is chosen with skills");
        masteryDetailsPage.clickChevronIcon();
        masteryFiltersComponent.expandToggle();
        masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_READING);
        masteryFiltersComponent.selectSkillStandards(Constants.MasteryUI.STANDARD_ALASKAENGLISH_READING);
        MasterySummaryComponent masterySummaryComponent4 = masteryFiltersComponent.applyFilter();
        MasteryDetailsPage masteryDetailsPage4 = masterySummaryComponent4.clickLOLink();
        Log.assertThat(!masteryDetailsPage4.verifyLearningObjectLinkIsDisplayed(),
                "The LO Link is not visible when Reading subject is chosen with standards",
                "The LO Link is visible when Reading subject is chosen with standards");
        Log.testCaseResult();
        
            } catch (Exception e) {
                Log.exception(e, driver);
            } finally {
                Log.endTestCase();
                if (null != devTool) {
                    DevToolsUtils.closeMock( devTool );             }
                driver.quit();
            }

        }

	@DataProvider(name = "masteryLoViewValidation")
	public Object[][] masterySummaryValidation() {

		Object[][] inputData = { { "teacherlogin", "MasteryTeacherMfe", MasteryDataSetup.teacherUserName },
//				{ "singleadminlogin", "MasteryAdminSingleMfe", MasteryDataSetup.schoolAdminUserName },
//				{ "multiadminlogin", "MasteryAdminMultiMfe", MasteryDataSetup.multiSchoolAdminUserName } 
				};
		return inputData;
	}
}
