# successmaker_mastery_mfe_bff_test_automation
SuccessMaker Mastery UI and API Automation Repository. (Epic: SME-187E)

**API Automation Guidelines**

https://docs.google.com/document/d/1VIz_SvL0i53ZNDK_L7ECuO3aiAkZPIlz3Q2ldpVdanY/edit
