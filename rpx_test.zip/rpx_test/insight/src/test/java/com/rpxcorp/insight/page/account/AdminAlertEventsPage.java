package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.module.Facet;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;

import java.util.List;
import java.util.stream.Collectors;

public class AdminAlertEventsPage extends BasePage {

	public AdminAlertEventsPage() {
		this.url = new PageUrl("admin/alert_events");
	}

	@Override
	public boolean at() {
		return title.waitUntilVisible();
	}
	
	public final Element title=$(".admin_alert_events .section-title:contains('Alert Events')");
	public final Element result_events=$("#alert_events_list .result-count");
	public final Element result_title=$("#alert_events_list .title");
	
	public final Facet event_name = $("section.filters:nth-of-type(2)", (Configure<Facet>) facet ->
		{
			facet.showMoreDialog("#facet-search-modal .facet_options li");
			facet.showMoreLink("section.filters:nth-of-type(2) a.more");
			facet.submitBtnInShowMoreDialog("#facet-search-modal a.submit_btn");
			facet.selectedOptionsInShowMoreDialog("#facet-search-modal .selected_facets li");
			facet.unSelectedOptionsInShowMoreDialog("#facet-search-modal .facet_options li");
		}
	);
	
	public final Facet event_type = $("section.filters:nth-of-type(3)", (Configure<Facet>) facet ->
		{
			facet.showMoreDialog("#facet-search-modal .facet_options li");
			facet.showMoreLink("section.filters:nth-of-type(3) a.more");
			facet.submitBtnInShowMoreDialog("#facet-search-modal a.submit_btn");
			facet.selectedOptionsInShowMoreDialog("#facet-search-modal .selected_facets li");
			facet.unSelectedOptionsInShowMoreDialog("#facet-search-modal .facet_options li");
		}
	);

	public List<String> getDistinctCaseEventTypesFromResults() {		
		return result_events.getAllData().stream().distinct().collect(Collectors.toList());
	}
	
	public List<String> getDistinctEventTitlesFromResults() {		
		return result_title.getAllData().stream().distinct().collect(Collectors.toList());
	}
}
