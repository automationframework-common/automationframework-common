package com.rpxcorp.insight.page;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.util.ConfigUtil;

public class InternalAppsPortfolioPage extends Page{

    @Override
    public boolean at() {
        return internalAppLoginTitle.waitUntilTextPresent("Internal Authentication Service");
    }

    public final Element internalAppLoginTitle = $(".app-name");
    public final Element pageTitle =$(".col-md-12 h2");
    public final Element username = $("#email");
    public final Element password = $("#password");
    public final Element loginButton = $("input[name='commit']");
    private String IAUsername = ConfigUtil.config().get("IA_USERNAME").toString();
    private String IAPassword = ConfigUtil.config().get("IA_PASSWORD").toString();

    public void login(){
        username.sendKeys(IAUsername);
        password.sendKeys(IAPassword);
        loginButton.click();
    }
}