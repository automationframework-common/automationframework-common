package com.rpxcorp.insight.page.myrpx;

import com.rpxcorp.insight.module.Radio;
import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;


public class CommunityWebinars extends BasePage {

    public CommunityWebinars() {
        this.url = new PageUrl("community");
    }

    @Override
    public boolean at() {
        webinarTabs.getAllTab().contains("On-Demand Webinars");
        return pageTitle.waitUntilVisible();
    }

    public final Tabs webinarTabs = new Tabs(".webinar.tabs li.tab-title");
    public final Element pageTitle = $("h1:contains('RPX Community Webinars')");
    public final Element videoPlayBtn = $("#past_webinar_list .video_thumbnail span.play-btn");

    public final Element webinarSortBy = $("select#order");
    public final Radio archivedVideos = new Radio("div.campaign_view_switch input");

}
