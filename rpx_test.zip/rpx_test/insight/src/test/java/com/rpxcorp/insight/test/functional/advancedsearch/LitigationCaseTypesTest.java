package com.rpxcorp.insight.test.functional.advancedsearch;

import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.google.gson.JsonObject;
import com.rpxcorp.insight.page.LitigationCaseTypesPage;
import com.rpxcorp.insight.test.functional.BaseFuncTest;
@Authenticate(role = "MEMBER")
public class LitigationCaseTypesTest extends BaseFuncTest {

	LitigationCaseTypesPage litigationCaseTypesPage;

	@BeforeClass
	public void gotoLitCaseTypes() throws Exception {
		JsonObject jsonTestData = getJsonTestData("PatentLitigationSearch.json");
		testData = jsonTestData.getAsJsonObject("PAT_LIT_FORM");
		 to(litigationCaseTypesPage);
	}

	@Test(priority = 1, groups ="P2", description = "Verify page title and headers in litigation type table")
	public void verifyLitigationTypesPageTitleAndTableHeader() throws Exception {
		String[] expHeader = {"Litigation Case Type", "Description"};
		assertEquals(litigationCaseTypesPage.title.getText(), "Litigation Case Types", "Litigation case types page header");
		assertEquals(litigationCaseTypesPage.litTypesTable.getHeaderData(), expHeader, "Header in litigation case type table");
	}

	@Test(priority = 2, groups ="P3", description = "Verify litigation case types in litigation case types table")
	public void verifyLitigationCaseTypeColumnInTable() throws Exception {
		assertEquals(litigationCaseTypesPage.litTypesTable.getColumn("Litigation Case Type"), dataAsList("litCaseTypes"), "Litigation case types in table");
	}

	@Test(priority = 3, groups ="P2",dataProvider = "litTypeData", description = "Verify links from lit case types in litigation case types page")
	public void verifyDescriptionForLitigationCaseTypesInTable(String caseType) throws Exception {
		assertEquals(litigationCaseTypesPage.getCaseTypeDescription(caseType), dataAsString(caseType), "Case type description in Litigation case types table");
	}

	@DataProvider
	public Object[][] litTypeData() {
		return dataAsTestObject("litCaseTypes");
	}
}
