package com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.LoginPage;
import com.rpxcorp.insight.page.detail.AlertsSubscriptionPage;
import com.rpxcorp.insight.page.detail.BaseDetailPage;
import com.rpxcorp.insight.page.detail.LitigationDetailPage;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.HashMap;
public class AlertsLimitTest extends BaseFuncTest {
    AlertsSubscriptionPage alertsSubscriptionPage;
    BaseDetailPage detailPage;
    LitigationDetailPage litigationDetailPage;
    private String[] dataIds;


    /******* TEST METHODS ********/
    @Test(priority = 1, groups = "P3")
    public void createAlertWithinLimit() throws Exception {
        urlData.put("ID",dataIds[0]);
        to(litigationDetailPage,urlData);
        detailPage.createAlertBtn.click();
        at(alertsSubscriptionPage);
        alertsSubscriptionPage.createAlert();
        assertTrue(detailPage.modifyAlertBtn.isDisplayed(),"Modify Alert button is created after creating alert");
    }
    @Test(priority = 2, groups = "P3")
    public void createAlertBeyondLimit() throws Exception {
        urlData.put("ID",dataIds[1]);
        to(litigationDetailPage,urlData);
        detailPage.createAlertBtn.click();
        String message=detailPage.getPopupMessage();
        assertTrue(message.contains("You have subscribed to the maximum number of litigation alerts available through your subscription plan."),
                "Alert limit validation pop up doesn't appear");
    }


    @BeforeClass(alwaysRun = true)
    public void setupTestData() throws Exception {
        // Update alertLimit
        updateAlertLimit(LoginPage.ROLES.PLUS,1);
        dataIds = getDBData("RANDOM_LIT_WITHOUT_ALERT", "2");

        // Enable Features
        //enableFeature("Alerts Overhaul");
        //enableFeature("Limit Alert Subscriptions");
        String userId="alertlimittest.ba6f4fe1@mailosaur.io";
        deleteUser(userId);
        createUser(userId,LoginPage.ROLES.PLUS);      
        to(loginPage);
        login(userId,"Welcome@1",LoginPage.ROLES.PLUS);
    }


    @AfterClass(alwaysRun = true)
    public void resetData() throws Exception {
        updateAlertLimit(LoginPage.ROLES.PLUS,30);
    }

    private int updateAlertLimit(LoginPage.ROLES role, int limit) throws Exception {
        HashMap<String,String> queryParam = new HashMap<>();
        queryParam.put("ROLE",role.toString());
        queryParam.put("LIMIT",Integer.toString(limit));
        return processDB("UPDATE_ALERT_LIMIT",queryParam);
    }
}
