package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.detail.FedCircuitDetailPage;
import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.sql.ResultSet;

@Authenticate(role = "MEMBER")
@Test(groups = {"Lits","FedCircuit"})
public class FedCircuitDetailsTest extends BaseDataTest{

    FedCircuitDetailPage fedCircuitDetailPage;
    ResultSet resultSet,accusedProducts;
    public int count;
    /* TEST CONFIGURATIONS */
    @Factory(dataProvider = "returnData")
    public FedCircuitDetailsTest(String dataDescription, String ptabJudId) {
        this.dataDescription = dataDescription;
        this.dataId = ptabJudId;
    }

    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("FedCircuitDetail");
    }

    @BeforeClass
    public void loadPage() {
        this.urlData.put("ID", dataId);
        this.dataUrl = fedCircuitDetailPage.getDeclaredUrl(urlData);
        to(fedCircuitDetailPage, urlData);
    }

 @Test(description = "Verify Title", priority = 1)
    public void verifyTitle() throws Exception {
        assertEquals(fedCircuitDetailPage.detailPageTitle.getData(),
                sqlProcessor.getSinglResultValue("FedCircuitDetail.TITLE", dataId));
    }

    @Test(description = "Verify header details", priority = 1)
    public void verifyHeaderDetails() throws Exception {
        assertEquals(fedCircuitDetailPage.headerContent.getData(),
                sqlProcessor.getResultData("FedCircuitDetail.HEADER_DETAILS", dataId));
    }

   @Test(description = "Verify stats bar count", priority = 1)
    public void verifyStatsBar() throws Exception {
        assertEquals(fedCircuitDetailPage.statsBarConent.getData(),
                sqlProcessor.getResultData("FedCircuitDetail.STATS_BAR", dataId));
    }

    @Test(description = "Verify overview section details", priority = 1)
    public void verifyOverview() throws Exception {
        assertEquals(fedCircuitDetailPage.overviewConent.getData(),
                sqlProcessor.getResultData("FedCircuitDetail.OVERVIEW_DETAILS", dataId));
    }

    @Test(description = "Verify appellant parties and Counsel Information", priority = 1)
    public void plaintiffParties() throws Exception {
        assertEquals(fedCircuitDetailPage.appellantPartiesContent.getData(),
                sqlProcessor.getResultData("FedCircuitDetail.APPELLANT_PARTIES", dataId));
    }

    @Test(description = "Verify appellee parties and Counsel Information", priority = 1)
    public void defendantParties() throws Exception {
        assertEquals(fedCircuitDetailPage.appelleePartiesContent.getData(),
                sqlProcessor.getResultData("FedCircuitDetail.APPELLEE_PARTIES", dataId));
    }

    @Test(description = "Verify other parties and Counsel Information", priority = 1)
    public void otherParties() throws Exception {
        ResultSet rs = sqlProcessor.getResultData("FedCircuitDetail.OTHER_PARTIES",dataId);
        int rsCount = sqlProcessor.getResultCount(rs);
        if (rsCount > 0) {
            assertEquals(fedCircuitDetailPage.otherPartiesContent.getData(),rs);
        }else {
            assertEquals(rsCount,0);
        }
        }

    @Test(description = "Verify Patents In Suit count", priority = 7)
    public void Patents_In_Suit_Count() throws Exception {
        resultSet = sqlProcessor.getResultData("FedCircuitDetail.PATS_IN_SUIT", dataId);
        assertEquals(fedCircuitDetailPage.patentInSuitHeader.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    @Test(description = "Verify Patents in Suit in Patent Information Section", priority = 8)
    public void Patents_In_Suit() throws Exception {
        assertEquals(fedCircuitDetailPage.PATENT_TABLE.getData(), resultSet);
    }
    @Test(description = "Verify Case Count in Litigation Campaign Section", priority = 11)
    public void Case_Count_in_Litigation_Campaign() throws Exception {
        resultSet = sqlProcessor.getResultData("FedCircuitDetail.CAMPAIGN_REL_LITS_COUNT", dataId);
        assertEquals(fedCircuitDetailPage.caseTabLink.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    @Test(description = "Verify Cases in Litigation Campaign Section", priority = 12)
    public void Litigation_Campaign_Case() throws Exception {
        resultSet = sqlProcessor.getResultData("FedCircuitDetail.CAMPAIGN_REL_LITS", dataId);
        assertEquals(fedCircuitDetailPage.litigation_cases.getData(), resultSet, "date_filed", "case_name",
                "case_number", "termination_date");
    }

    @Test(description = "Verify Patent Count in Litigation Campaign Section", priority = 13)
    public void Patent_Count_in_Litigation_Campaign() throws Exception {
        resultSet = sqlProcessor.getResultData("FedCircuitDetail.CAMPAIGN_REL_PATS", dataId);
        assertEquals(fedCircuitDetailPage.patentsTabLink.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    @Test(description = "Verify Patents in Litigation Campaign Section", priority = 14)
    public void Litigation_Campaign_Patents() throws Exception {
        fedCircuitDetailPage.selectPatentTab();
        assertEquals(fedCircuitDetailPage.patentInLitigationCampaign.getData(), resultSet);
    }

    @Test(description = "Verify Accused Products in Litigation Campaign Section", priority = 15)
    public void Litigation_Campaign_Accused_Products() throws Exception {
        fedCircuitDetailPage.selectAccusedProductTab();
        assertEquals(fedCircuitDetailPage.patent_accused_table.getData(),
                sqlProcessor.getResultData("FedCircuitDetail.CAMPAIGN_ACCUSEDPRODUCTS", dataId));
    }

    @Test(description = "Verify Defendant Count in Litigation Campaign Section", priority = 16)
    public void Defendant_Count_in_Litigation_Campaign() throws Exception {
        resultSet = sqlProcessor.getResultData("FedCircuitDetail.CAMPAIGN_DEFENDANTS", dataId);
        assertEquals(fedCircuitDetailPage.defendantsTabLink.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    @Test(description = "Verify Defendants in Litigation Campaign Section", priority = 17)
    public void Defendants_in_Litigation_Campaign() throws Exception {
        fedCircuitDetailPage.selectDefendantTab();
        assertEquals(fedCircuitDetailPage.defendant_table.getData(), resultSet);
    }

    @Test(description = "Verify Defendants Sub Table in Litigation Campaign Section", priority = 18)
    public void Defendants_SubTable_in_Litigation_Campaign() throws Exception {
        fedCircuitDetailPage.expandAlldefandant();
        assertEquals(fedCircuitDetailPage.defendant_table.getSubtableData(),
                sqlProcessor.getResultData("FedCircuitDetail.CAMPAIGN_DEFENDANTS_SUBTABLE", dataId));
    }

    @Test(description = "Verify Accused Product count", priority = 19)
    public void Accused_Product_Count() throws Exception {
        accusedProducts = sqlProcessor.getResultData("FedCircuitDetail.ACCUSED_PRODUCT_INFO", dataId);
        count=sqlProcessor.getResultCount(accusedProducts);
        if(fedCircuitDetailPage.accused_product_count.isDisplayed()) {
           assertEquals(fedCircuitDetailPage.accused_product_count.getIntData(),count);
       } else {
            assertEquals(0,count);
        }
    }

    @Test(description = "Verify Accused Product Information", priority = 20)
    public void Accused_Product_Information() throws Exception {
        if(fedCircuitDetailPage.accused_product_section.isDisplayed()) {
            assertEquals(fedCircuitDetailPage.accused_product_section.getData(), accusedProducts);
        } else {
            assertEquals(0,count);
        }
    }
}
