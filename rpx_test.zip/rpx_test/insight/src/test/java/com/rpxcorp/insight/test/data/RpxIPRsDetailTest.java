package com.rpxcorp.insight.test.data;

import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.rpxcorp.insight.page.intelligence.RpxIPRsPage;
@Authenticate(role = "MEMBER")
public class RpxIPRsDetailTest extends BaseDataTest {
    RpxIPRsPage rpxIPRpage;

    @BeforeClass
    public void navigateIPRPage() {
        this.dataDescription = "RPX IPR Page";
        this.dataUrl = rpxIPRpage.getDeclaredUrl();
        to(rpxIPRpage);
    }

    @Test(description = "Verify petitions Count", priority = 1)
    public void petitionCount() throws Exception {
        assertEquals(rpxIPRpage.petitionSummaryCount.getData(), sqlProcessor.getResultData("Intelligence.PETITION_COUNT"),
                "count");
    }

    @Test(description = "Verify IPR Table Data", priority = 2)
    public void verifyCampignSort() throws Exception {
        assertEquals(rpxIPRpage.IPR_table.getData(),
                sqlProcessor.getResultData("Intelligence.RPX_IPR_CAMPAIGN_ALL_DATA"), "campaign_name", "case_name",
                "case", "patent", "date_filed");
    }
    
    @Test(description = "Verify stats information", priority = 2)
    public void verifyStatsCount() throws Exception {
        assertEquals(rpxIPRpage.metricsSection.getData(),
                sqlProcessor.getResultData("Intelligence.STATS_INFO"), "campaigns", "petitions_filed",
                "unique_patents_challenged");
    }
}
