package com.rpxcorp.insight.page;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;

public class AnalystPatentDetailsPage extends Page{

	@Override
	public boolean at() {
		patentHeader.waitUntilVisible();
		return totalClaims.waitUntilVisible();
	}

	public final Element patentHeader = $(".header-main span");
    public final Element totalClaims =$("div.headline-boxes div.rpx-flex-row:contains(Claims) .badge.ng-binding");
		}
