package com.rpxcorp.insight.page;

import com.rpxcorp.testcore.element.Element;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

public class LoginPage extends BasePage {

    @Override
    public boolean at() {
        contentLoading.waitUntilInvisible();
        return login_link.waitUntilVisible();
    }

    public final Element user_email_TextBox = $(".email-section #user_email[required='required']");
    public final Element password_TextBox = $(".password-section #user_password[required='required']");
    public final Element login_btn = $("input[value*='Login']:visible()");
    public final Element alertMessage = $(By.id("flash_name"));
    public final String account = "a:contains('Account')";
    public final Element logout_btn = $(By.cssSelector(".medium-12.columns a[data-section='log_out']"));
    public final Element createAccount_Btn = $(".btn-container li.subscribe>a:contains(Plans)");
    public final Element subscribe_Btn_Txt=$("#primary-nav li.subscribe a:contains('Plans')");
    public final Element linkedInBtn = $("a.button.linked-in:contains(Login with LinkedIn)");//.button.linked-in[href*=linkedin]
    public final Element linkedIn_userName_TextBox = $("input#username");//input[id*='session_key'] //By.id("session_key-oauth2SAuthorizeForm")
    public final Element linkedIn_password_TextBox = $("input#password");//input[id*='session_password'] //By.id("session_password-oauth2SAuthorizeForm")
    public final Element linkedIn_LoginBtn = $("button[aria-label='Sign in']"); //input#btn-primary //.grant-access .allow
    public final Element rpx_logo = $("#logo");
    public final Element login_holder = $(".login_holder");
    public final Element errorMsg = $(".login_holder .errors");
    public final Element infoMsg=$("div.panel>p");
    public final Element errorPageLogin = $("#primary-nav #public_login_btn");
    public final Element loginModalErrorSignUp = $(".errors a");
    public final Element forgetPasswordLink = $("div.label-wrap a#forgot_password");
    public final Element staySingnedInCheckBox = $("#user_remember_me");
    public final Element logout_link=$("#primary-nav .dropdown>ul>li>a[href='/users/sign_out']");
    public final Element features_LNK=$(By.xpath("//*[@id='primary-nav']//a[text()='Features']"));
    public final Element tos_Link=$("#primary-footer .nav a[href*='rpxcorp.com']+a[href*='terms-of-service']");
//    private ROLES loggedInUser;

//    public ROLES getLoggedInUser() {
//        return loggedInUser;
//    }

//    public void setLoggedInUser(ROLES loggedInUser) {
//        this.loggedInUser = loggedInUser;
//    }
//UNDERWRITER("5")
    public enum ROLES {
        ADMIN("3"), STAFF("2"), MEMBER("7"), ENTERPRISE("6"), PLUS("43"), BASIC("8"), LINKEDIN, PRIME("10"), EXTERNAL_MEMBER("7"),ELITE("6"), STAFFADMIN("5"),None;

        String dataId;
        private ROLES() {

        }
        private ROLES(String dataId) {
            this.dataId=dataId;
        }
        public String getDataId() {
            return dataId;
        }
    }
    public void login(String username, String password) {
        login(username,password,false);
    }
    public void login(String username, String password,boolean staySignedIn) {
    	expandLoginForm();
    	user_email_TextBox.sendKeys(username);
        password_TextBox.sendKeys(password);
        if(staySignedIn)
            staySingnedInCheckBox.click();
        login_btn.click();
    }
    public void loginWithoutExpanding(String username, String password,boolean staySignedIn) {
        user_email_TextBox.sendKeys(username);
        password_TextBox.sendKeys(password);
        if(staySignedIn)
            staySingnedInCheckBox.click();
        login_btn.click();
    }

    public void loginasLinkedIn(String username, String password) {
        contentLoading.waitUntilInvisible();
        expandLoginForm();
        linkedInBtn.waitUntilVisible();
        linkedInBtn.click();
        linkedIn_userName_TextBox.waitUntilVisible();
        linkedIn_userName_TextBox.sendKeys(username);
        linkedIn_password_TextBox.sendKeys(password);
        linkedIn_LoginBtn.click();
    }

    public String loginAs(ROLES roleName) {
        String username = getConfig(roleName + "_EMAIL");
        if (roleName == ROLES.LINKEDIN) {
            loginasLinkedIn(username,getConfig(roleName + "_PSWD"));
        } else {
            login(username, getConfig(roleName + "_PSWD"));
        }
//        setLoggedInUser(roleName); // Set Logged in user
        return username;
    }

    public boolean waitForAlert() {
    	return alertMessage.waitUntilTextContains("igned in");
    }

    public boolean waitForDashboardPage() {
        return accountsMenu.waitUntilVisible();
    }

    public void logout() {
        waitForDOM();
        if (logOut.isPresent()) {
            System.out.println("Logout...");
//            if( $("#primary-nav a[data-dropdown='account-menu']>span.user-name>div.header-text").isPresent()) { //#primary-nav .dropdown>ul>li>a[href='/user/edit']
//            	$("#primary-nav a[data-dropdown='account-menu']>span.user-name>div.header-text").clickAndHold();
//            }

            //expandAccountMenu();
            //logOut.click();
            ((JavascriptExecutor) (getBrowser().getDriver()))
                    .executeScript("$('#primary-nav ul#account-menu>li>a[href=\"/users/sign_out\"]').click();");  //$('#primary-nav .dropdown>ul>li>a[href="/users/sign_out"]').click();
            at();
            //alertMessage.waitUntilTextPresent("Signed out successfully.");
            login_link.waitUntilVisible();
        }
    }

    public final Element accountMenu = $("#primary-nav ul#account-menu a[href='/user/edit']"); //#primary-nav li.has-dropdown>a[href='/user/edit']
    public final Element logOut = $("#primary-nav ul#account-menu>li>a[href='/users/sign_out']");  //#primary-nav li.has-dropdown>a[href='/user/edit']+div.dropdown>ul>li>a[href='/users/sign_out']

    public void clickOnForgetPasswordLink() {
        forgetPasswordLink.waitUntilVisible();
        forgetPasswordLink.click();
    }
    
    public void expandLoginForm() {
    	if(!user_email_TextBox.isDisplayed() && login_link.isDisplayed()) {
    		login_link.click();
    		user_email_TextBox.waitUntilVisible();    		
    	}
    }

}