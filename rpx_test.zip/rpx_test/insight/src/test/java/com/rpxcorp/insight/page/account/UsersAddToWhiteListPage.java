package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class UsersAddToWhiteListPage extends BasePage {

    public UsersAddToWhiteListPage() {
        this.url = new PageUrl("admin/whitelists/new");
    }

    @Override
    public boolean at() {
        return inputEmailId.waitUntilVisible();
    }

    public final Element inputEmailId = $("#whitelist_email");
    public final Element save_Whitelist_user = $("input[name='save_user_changes']");

    public void addToWhiteList(String mailId) {
        String url = getDriver().getCurrentUrl();
        inputEmailId.sendKeys(mailId);
        save_Whitelist_user.click();
        alertMessage.waitUntilVisible();
        getDriver().navigate().to(url);
        save_Whitelist_user.waitUntilVisible();

    }

    public void addToWhiteList(String[] mailIds) {
        for (int i = 0; i < mailIds.length; i++) {
            addToWhiteList(mailIds[i]);
        }
    }

}
