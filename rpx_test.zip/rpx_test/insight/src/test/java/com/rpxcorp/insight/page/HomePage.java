package com.rpxcorp.insight.page;

import com.rpxcorp.insight.module.*;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class HomePage extends BasePage {

    @Override
    public boolean at() {
        tileLoadIcon.waitUntilNoElementPresent();
        searchBox.waitUntilClickable();
        return accountsMenu.waitUntilVisible();
    }

    //SwitchToNewInsight Model Popup
    public final Element switchToNewInsightPopup = $("#switch_new_insight");
    public final Element switchToNewInsightBtn = $("div#switch_new_insight a.goto_insight.button");


    public final Element personalizationModalDialog = $("#myModal");
    public final Element personalizationAskMeLater = $("#personalization_form a.ask-later");
    public final Element personalizationJobTitle = $("input#user_personalization_attributes_job_title");
    public final Element personalizationJobRole = $("div#s2id_user_personalization_attributes_job_role");
    public final Element interestCompany = $(".available-container li:nth-child(1).available_items");
    public final Element interestMarketSector = $(".available-market-container li:nth-child(1).available_items");
    public final Element personalizationNextButton = $("#myModal #nextBtn");
    public final Element userRoleInput = $("div.select2-search input.select2-input:visible");
    public final Element userRoleAutoList = $("ul#select2-results-1 span.select2-match");


    public void clickAskMeLaterForPersonalisation() {
        if(switchToNewInsightPopup.isPresent()){
            switchToNewInsightBtn.click();
            switchToNewInsightBtn.waitUntilInvisible();
        }else if(personalizationModalDialog.isDisplayed()){
            personalizationAskMeLater.click();
            loading.waitUntilInvisible();
            waitForPageLoad();
            if (switchToNewInsightPopup.isPresent()) {
                switchToNewInsightPopup.waitUntilVisible();
                switchToNewInsightBtn.click();
                switchToNewInsightBtn.waitUntilInvisible();
                waitForRequestInit();
            }
        }        else {
            System.out.println("No popup");
        }
    }

    public final Tabs personalisationaActiveTab = new Tabs("dl.tabs.dashboard-header dd.active");
    public final Tabs personalisationTabs = new Tabs("dl.tabs.dashboard-header dd");//div.personalization_dashboard dl.tabs.dashboard-header dd
    public final Element dashbordTilesTitle = $("#intelligence div.summary_title .valign-center:visible()");
    public final Element portfolioViewAllAcquisitions = $("#intelligence div.show-for-small-tile-only:contains('Portfolio Acquisitions by RPX') ~ div.overflow-for-small-tile div.view-all-link");
    public final Element PortfolioLink = $("#intelligence div.show-for-small-tile-only:contains('Portfolio Acquisitions by RPX') ~ div.overflow-for-small-tile div.columns:nth-child(1) a");
    public final Element portfolioCount = $("#intelligence .row.summary_title:contains(Portfolio Acquisitions by RPX) div.new_matters_count");
    public final Element reportsDropdown = $("select#jurisdiction");
    public final Element newsLink = $("#intelligence div.show-for-small-tile-only:contains('Suggested News Articles') ~ div.tile-content div.row.summary-table-row:not(div.more-link) .text-left");

    public final Element salutation = $("a[class*='edit-dboard-btn']:visible"); //h1.salutation
    public final Element tileLoadIcon = $(".tile-loader-image:visible");
    public final Element AnonymousSearchTypeLink = $("header.anonymous div.search-box-container a#search-v2-menu-anc");
    public final Element anonymousSearchTypes = $("header.anonymous ul#search-v2-menu li");
    public final Element searchSubmit = $(".search-table-main input.search-icon");
    public final Element searchBox = $("#searchq");
    public final Element searchAutoCompleteText = $(".ui-menu-item a");
    public final Element company = $("ul.subsidiaries a");
    public final Element viewAsAccountNotice = $(".viewing_account_notice");
    public final Element viewAsAccountNoticeDefault = $(".viewing_account_notice a");
    public final Element account_menu = $(".show-for-large-up .has-dropdown>a[href='/user/edit']");
    public final Element visual_analytics_menu = $("#primary-nav a[href='/analytics']");
    public final Element my_assertions_panel = new ListPanel(".panel.my-assertions");
    public final Element manage_alerts_link = $(".dashboard-content li.result-count+li>a[href='/alerts']");
    public final Element myLitigations = $("#total-litigation-cases.group");
    public final Element litigationTitle = $("#total-litigation-cases .title");
    public final Table litigationTable = new Table("#total-litigation-cases .table-expand table");
    public final Element recentLitigation = $("#recent-litigation-cases.group.collapsed");
    public final Element recentLitigationTitle = $("#recent-litigation-cases .title");
    public final Element recentLitigationstats = $("#recent-litigation-cases.group .stats");
    public final Element recentLitigationNoCases = $("#recent-litigation-cases.group .info.one-item");
    public final Element litigationViewAsSearch = $(".view-as-search");
    public final Element flashMsg = $("#flash_name");
    public final Element rpx_logo_src = $("img[src*='/assets/rpx_logo']");
    public final Element upgradeMyAccount = $(
            "#primary-nav ul.inline-list li:nth-child(4) > a[href='/payments/options']");
    public final Element subscriptionBanner = $(".homepage_subscribe_banner");
    public final Element subscriptionPanelHeader = $(By.xpath("//div[contains(@class,'homepage_promo_holder')]//h3"));
    public final Element subscriptionButton = $(".homepage_subscribe_banner .button");
    public final Table recentLitigationTable = $("#recent-litigation-cases .table-expand table", (Configure<Table>) table ->
            {
                table.displayedRecords(" tbody tr:not([style='display: none;'])");
                table.viewAllLink("#recent-litigation-cases .view-all.no-border");
                table.uniqueId("td:nth-of-type(2)>a");
            }
    );
    public final Table savedLitigationTable = $("#recent-litigation-cases .table-expand table", (Configure<Table>) table ->
            {
                table.displayedRecords(" tbody tr:not([style='display: none;'])");
                table.viewAllLink("#recent-litigation-cases .view-all.no-border");
                table.uniqueId("td:nth-of-type(2)>a");
            }
    );

    public final StaticContent groupedResultsCount = $("h2.result-title", (Configure<StaticContent>) dataForm -> {

        dataForm.content("campaign_Count", "span:first-child");
        dataForm.content("Lit_Count", "span:nth-of-type(2)");
        dataForm.content("Ptab_Count", "span:nth-of-type(3)");
        dataForm.content("ITC_Count", "span:nth-of-type(4)");
        dataForm.content("FC_Count", "span:nth-of-type(5)");
    });

    public ArrayList<String> getAutoCompleteText() {
        searchAutoCompleteText.waitUntilVisible();
        return searchAutoCompleteText.getAllData();
    }

    //NEW SECTIONS
    public final Element plans_LNK = $("#primary-nav a:contains('Plans')");
    public final Element adv_description_h1 = $(By.xpath("//*[@class='rpx-intro']//h1[text()='The Most Complete Intelligence on Patent Litigation']"));
    public final Element adv_description_h2 = $(By.xpath("//*[@class='rpx-intro']//h2[text()='Powered by the premiere authority in the patent space, only RPX Insight brings machine and human intelligence together to enable faster research, more relevant detail, and smarter decisions.']"));
    public final Element legalInformatics_Section_h1 = $(By.xpath("//*[@class='feature_listing']//h1[text()='Legal Informatics']"));
    public final Element proprietaryInsightsHeader = $(".homepage_features .feature_listing h1:contains('Proprietary Insights')");
    public final Element proprietary_Features = $(".homepage_features .feature_listing.row_list h2.feature_title");
    public final Element coreKnowledge_heading = $(".homepage_features .feature_listing h1:contains('Core Knowledge')");
    public final Element coreKnowledge_features = $(".homepage_features .feature_listing.column_list .feature_container h2.feature_title");
    public final Element subscriber_details = $("div[class='row'] .hr-sect");
    public final Element subsriber_logs = $(".logo img[src*='view.wp.multi.aws.rpxcorp.local/wp-content/uploads/sites']");
    public final Element testmonials_section = $(".testimonials h3.statement");
    public final Element insightByNumbers_title = $(".by_the_number_title .header-section");
    public final Element insightByNumbers_Sections = $(".number_attribute .description");
    public final Element feature_links = $(".feature_container>a");

    //FOOTER
    public final Element privacyPolicyLink = $("#primary-footer .nav a[href*='privacy-policy']");
    public final Element termsOfServiceLink = $("#primary-footer .nav a[href*='terms-of-service']");
    public final Element patentShowingLink = $(By.xpath("//footer[@id='primary-footer']//a[text()='Patents: Showing']"));

    //NEW DASHBOARD
    //DEFAULT TILES
    //ELITE AND ABOVE USERS
    public final Element onexoneAlertsAsTile1 = $("#dashboard-sortable>div.onexone:eq(0):contains('New Alerts from the Past 24 Hours')");
    public final Element onexoneNewsAsTile2 = $("#dashboard-sortable>div.onexone:eq(1):contains('News Articles from the Past 7 Days')");
    public final Element onexoneReportsAsTile3 = $("#dashboard-sortable>div.onexone:eq(2):contains('RPX Reports from the Past 7 Days')");
    public final Element onexoneNewCampAsTile4 = $("#dashboard-sortable>div.onexone:eq(3):contains('New Campaigns Filed YTD')");
    public final Element onexoneDefAddedAsTile5 = $("#dashboard-sortable>div.onexone:eq(4):contains('Defendants Added in Campaigns YTD')");
    public final Element onexoneUniqueDefendantsAsTile6 = $("#dashboard-sortable>div.onexone:eq(5):contains('Unique Defendants in Campaigns YTD')");
    public final Element onexoneNewCasesFiledAsTile7 = $("#dashboard-sortable>div.onexone:eq(6):contains('New Cases Filed YTD')");
    public final Element onexonePTABPetitionsFiledAsTile8 = $("#dashboard-sortable>div.onexone:eq(7):contains('New PTAB Petitions Filed YTD')");
    public final Element onexoneCampaignsInvolvingDefAsTile9 = $("#dashboard-sortable>div.onexone:eq(8):contains('New Campaigns Involving Selected Defendants YTD')");
    public final Element onexoneMostRecentPatentLitTileAsTile10 = $("#dashboard-sortable>div.onexone:eq(9):contains('Most Recent Patent Litigations')");
    public final Element onexoneSavedPagesAsTile11 = $("#dashboard-sortable>div.onexone:eq(10):contains('Saved Pages')");

    //BASIC, PLUS AND PRIME USERS
    public final Element onexoneMostRecentPatentLitTileAsTile2 = $("#dashboard-sortable>div.onexone:eq(1):contains('Most Recent Patent Litigations')");
    public final Element onexoneSavedPagesAsTile3 = $("#dashboard-sortable>div.onexone:eq(2):contains('Saved Pages')");

    //TILES IN DASHBOARD
    public final Element alertTile = $("div[data-url='/alerts/todays_alert']");
    public final Element newsArticlesTile = $("div[data-url='/news/dashboard_news']");
    public final Element rpxReportsTile = $("div[data-url='/lca_reports/rpx_reports_tile_dashboard']");
    public final Element newCampTile = $("div[data-url='/campaigns/new_campaigns_filed_dashboard']");
    public final Element defAddedTile = $("div[data-url='/campaigns/total_campaign_defendants_dashboard']");
    public final Element uniqueDefendantTile = $("div[data-url='/dashboard/unique_defendants']");
    public final Element newCasesTile = $("div[data-url='/dashboard/new_cases_filed']");
    public final Element newPTABPetitionsFiled = $("div[data-url='/dashboard/new_ptab_petitions_filed']");
    public final Element campaignsInvolvingDefTile = $("div[data-url='/analytics/new_campaigns_filed_by_defendant_dashboard']");
    public final Element mostRecentCasesTile = $("div[data-url='/dashboard/recent_cases']");
    public final Element savedPagesTile = $("div[data-url='/save_pages']");
    public final Element acquisitionsAsTile = $("div[data-url='/portfolios/recent_acquisitions']");
    public final Element recentPetitionsFiledByRPX = $("div[data-url='/ipr/recent_petitions']");


    //LINKS IN DASHBOARD
    public final Element editDashboardLink = $(".edit-dboard-btn");
    public final Element saveDashboardLink = $(".save-dboard-btn");

    public void saveDashboard() {
        if (saveDashboardLink.isDisplayed()) {
            saveDashboardLink.click();
            addButtonInTiles.waitUntilInvisible();
            tileLoadIcon.waitUntilInvisible();
            tileOverlay.waitUntilInvisible();
        }
    }

    public final Element emptyDashboardMsg = $("#empty_dashboard div[class='text-center']");

    //EDIT MODE
    public final Element tileOverlay = $("#dashboard-sortable .blockUI.blockOverlay");
    public final Element addButton = $("#container_add_button");

    public void openEditMode() {
        if (editDashboardLink.isDisplayed()) {
            editDashboardLink.click();
            tileLoadIcon.waitUntilInvisible();
        }
    }

    public void openAddModalInEditMode() {
        openEditMode();
        if (!addTilesModal.isDisplayed()) {
            if (addButtonInTiles.isDisplayed()) {
                addButtonInTiles.click();
                addTilesModal.waitUntilVisible();
            }
        }
    }

    public void closeAddModalInEditMode() {
        if (addTilesModal.isDisplayed()) {
            addTilesModalCloseIcon.click();
            addTilesModal.waitUntilInvisible();
        }
    }

    public final Element closeIcon = $("#dashboard-sortable div .cancel-icon");
    public final Element tileItems = $("tile-item");

    public void removeAllTilesInEditMode() {
        openEditMode();
        if (closeIcon.isDisplayed()) {
            List<WebElement> closeIcons = closeIcon.getElements();
            for (WebElement closeIcon : closeIcons) {
                closeIcon.click();
            }
            tileItems.waitUntilInvisible();
        }
    }

    public void addSingleTileInEditMode(String tileName, String tileSize) {
        removeAllTiles();
        openAddModalInEditMode();
        $(By.xpath("//div[@id='sortable-dashboard-modal-content']//p[text()=\"" + tileName + "\"]")).click();
        $(By.xpath("//div[@id='sortable-dashboard-modal-content']//p[text()=\"" + tileName + "\"]")).waitUntilVisible();
        closeAddModalInEditMode();
        $(By.xpath("//div[@class='size-resizing']/div[text()='" + tileSize + "']")).click();
        $(By.xpath("//div[@class='size-resizing']/div[text()='" + tileSize + "'][@class='size-option button']")).waitUntilVisible();
    }

    public void addAllTilesInEditMode() {
        openAddModalInEditMode();
        if (inactiveTilesInEditModal.isDisplayed()) {
            List<WebElement> inactiveTiles = inactiveTilesInEditModal.getElements();
            System.out.println("elem count: " + inactiveTiles.size());
            for (WebElement inactiveTile : inactiveTiles) {
                inactiveTile.click();
            }
        }
        closeAddModalInEditMode();
    }

    public void resizeAllTileInEditMode(String size) {
        List<WebElement> resizeElems = $(By.xpath("//div[@class='size-resizing']/div[text()='" + size + "'][contains(@class,'secondary')]")).getElements();
        for (WebElement resizeElem : resizeElems) {
            resizeElem.click();
        }
        tileLoadIcon.waitUntilInvisible();
    }

    public final Element addButtonInTiles = $("#container_add_button");
    public final Element addTilesModal = $("#sortable-dashboard-modal.open");
    public final Element addTilesModalCloseIcon = $("#sortable-dashboard-modal .close-reveal-modal");
    public final Element inactiveTilesInEditModal = $("#sortable-dashboard-modal-content>div>div:not([class*='secondary'])");

    public final Element activeAlertTileInEditModal = $(By.xpath("//div[@class='content text-center active']/p[text()=\"Today's Alerts\"]"));
    public final Element activeRecentLitigationsTileInEditModal = $(By.xpath("//div[@class='content text-center active']/p[text()='Recent Patent Litigations']"));
    public final Element activeSavedPagesTileInEditModal = $(By.xpath("//div[@class='content text-center active']/p[text()='Saved Pages']"));
    public final Element activeNewCampaignsTileInEditModal = $(By.xpath("//div[@class='content text-center active']/p[text()='New Campaigns Filed']"));
    public final Element activeTotalDefTileInEditModal = $(By.xpath("//div[@class='content text-center active']/p[text()='Total Defendants Added in Campaigns']"));
    public final Element activeUniqueDefTileInEditModal = $(By.xpath("//div[@class='content text-center active']/p[text()='Unique Defendants Added in Campaigns']"));
    public final Element activeNewCasesTileInEditModal = $(By.xpath("//div[@class='content text-center active']/p[text()='New Cases Filed by Jurisdiction']"));
    public final Element activeNewPTABPetitionsInEditModal = $(By.xpath("//div[@class='content text-center active']/p[text()='New PTAB Petitions Filed']"));
    public final Element activeNewCampaignSelectedDefendentInEditModal = $(By.xpath("//div[@class='content text-center active']/p[text()='New Campaigns Involving Selected Defendants']"));
    public final Element activeLatestNewsInEditModal = $(By.xpath("//div[@class='large-4 column item tile-selection-item ']//p[text()='Latest News']"));
    public final Element activeLatestRPXReportsInEditModal = $(By.xpath("//div[@class='content text-center active']/p[text()='Latest RPX Reports']"));
    public final Element activeRecentAcquisitionsByRPXInEditModal = $(By.xpath("//div[@class='content text-center active']/p[text()='Recent Acquisitions by RPX']"));
    public final Element activeRecentPetetionsByRPXInEditModal = $(By.xpath("//div[@class='content text-center active']/p[text()='Recent Petitions Filed by RPX']"));


    public final Element disabledNewCampaignsTileInEditModal = $(By.xpath("//div[contains(@class,'tile-disabled')]//p[text()='New Campaigns Filed']"));
    public final Element disabledTotalDefTileInEditModal = $(By.xpath("//div[contains(@class,'tile-disabled')]//p[text()='Total Defendants Added in Campaigns']"));
    public final Element disabledUniqueDefTileInEditModal = $(By.xpath("//div[contains(@class,'tile-disabled')]//p[text()='Unique Defendants Added in Campaigns']"));
    public final Element disabledNewCasesTileInEditModal = $(By.xpath("//div[contains(@class,'tile-disabled')]//p[text()='New Cases Filed by Jurisdiction']"));
    public final Element disabledNewPTABPetitionsInEditModal = $(By.xpath("//div[contains(@class,'tile-disabled')]//p[text()='New PTAB Petitions Filed']"));

    public final Element disabledNewCampInvolvingSelectedDefInEditModal = $(By.xpath("//div[contains(@class,'tile-disabled')]//p[text()='New Campaigns Involving Selected Defendants']"));
    public final Element disabledLatestNewsTileInEditModal = $(By.xpath("//div[contains(@class,'tile-disabled')]//p[text()='Latest News']"));
    public final Element disabledRPXReportsTileInEditModal = $(By.xpath("//div[contains(@class,'tile-disabled')]//p[text()='Latest RPX Reports']"));

    public final Element disabledRecentAcquisitionsByRPXTileInEditModal = $(By.xpath("//div[contains(@class,'tile-disabled')]//p[text()='Recent Acquisitions by RPX']"));
    public final Element disabledRecentPetetionsByRPXTileInEditModal = $(By.xpath("//div[contains(@class,'tile-disabled')]//p[text()='Recent Petitions Filed by RPX']"));

    //TILE FUNCTION
    public void saveSingleTile(String tileName, String tileSize) {
        addSingleTileInEditMode(tileName, tileSize);
        saveDashboard();
    }

    public void removeAllTiles() {
        removeAllTilesInEditMode();
        saveDashboard();
    }

    public void expandTile(String fromTileSize) {
        if (!expandedTile.isDisplayed()) {

            switch (fromTileSize) {
                case "S":
                    expandIconSmallTile.click();
                    break;
                case "M":
                    expandIconMediumTile.click();
                    break;
                case "L":
                    expandIconLargeTile.click();
                    break;
            }
            expandedTile.waitUntilVisible();
        }
    }

    public void closeExpandedTile() {
        if (expandedTile.isDisplayed()) {
            expandedTileClose.click();
            expandedTile.waitUntilInvisible();
        }
    }

    public final Element titleInExpandedModal = $("#sortable-dashboard-modal .summary_title>h2");
    public final Element expandedTile = $("#sortable-dashboard-modal");
    public final Element expandedTileClose = $("#sortable-dashboard-modal .close-reveal-modal");
    public final Element noDataMsgInExpandedModal = $("#sortable-dashboard-modal .no-data");
    public final Element noDataMsgInExpandedSavedPagesModal = $("#sortable-dashboard-modal div[class*='hide'] .no-data");
    public final Element viewAllInExpandedModal = $("#sortable-dashboard-modal .columns.view-all>a");

    public final Element newCasesFiledGraphInExpandedTile = $("#sortable-dashboard-modal-content div[data-behavior='new_cases_field_chart'] .highcharts-container");

    public void saveAllTiles(String size) {
        removeAllTilesInEditMode();
        addAllTilesInEditMode();
        resizeAllTileInEditMode(size);
        saveDashboard();
    }

    //SMALL TILE
    public final Element titleInSmallTile = $(".summary_title .valign-center");
    public final Element countInSmallTile = $(".summary_title .new_matters_count");
    public final Element noDataMsgInSmallTile = $(".onexone .no-data");
    public final Element expandIconSmallTile = $(".onexone .preview.icon-new-tab");

    public final Element newCasesFiledChartSmallTile = $(".onexone div[data-behavior='new_cases_field_chart'] .highcharts-container");

    //MEDIUM TILE
    public final Element titleInMediumTile = $(".onextwo .summary_title>h2");
    public final Element noDataMsgInMediumTile = $(".onextwo .no-data");
    public final Element expandIconMediumTile = $(".onextwo .preview.icon-new-tab");
    public final Element viewAllInMediumTile = $(".onextwo .columns.view-all>a");

    public final Element noDataMsgInMediumSavedPagesTile = $(".onextwo .hide-for-small-tile-only .no-data");
    public final Element newCasesFiledGraphMediumTile = $(".onextwo div[data-behavior='new_cases_field_chart'] .highcharts-container");

    //LARGE TILE
    public final Element titleInLargeTile = $(".twoxtwo .summary_title>h2");
    public final Element noDataMsgInLargeTile = $(".twoxtwo .no-data");
    public final Element expandIconLargeTile = $(".twoxtwo .preview.icon-new-tab");
    public final Element viewAllInLargeTile = $(".twoxtwo .columns.view-all>a");

    public final Element noDataMsgInLargeSavedPagesTile = $(".twoxtwo .hide-for-small-tile-only .no-data");
    public final Element newCasesFiledGraphLargeTile = $(".twoxtwo div[data-behavior='new_cases_field_chart'] .highcharts-container");

    //Main MENU
    public final Element myRPXMenu = $("li.h-dropdown a:contains('My RPX')");
    public final Element intelligence = $("li.h-dropdown a:contains('Intelligence')");
    public final Element visual_analytics = $("li.h-dropdown a:contains('Visual Analytics')");
    public final Element myAccountMenu = $("li.account-space li.h-dropdown");


    public final AutoComplete judgeSearchBox = $("#judge_venue_lawfirm_stats_modal.open input#judge", AutoComplete.class);
    public final AutoComplete venueSearchBox = $("#judge_venue_lawfirm_stats_modal.open input#venue", AutoComplete.class);
    public final AutoComplete lawFirmSearchBox = $("#judge_venue_lawfirm_stats_modal.open input#lawfirm", AutoComplete.class);

    //SubMenu
    public void expandIntelligenceMenu() {
        if (intelligence.isDisplayed()) {
            intelligence.moveTo();
        }
    }

    public void expandVisualAnalyticMenu() {
        if (visual_analytics.isDisplayed()) {
            visual_analytics.moveTo();
        }
    }

    public void expandMyRpxMenu() {
        if (myRPXMenu.isDisplayed()) {
            myRPXMenu.moveTo();
        }
    }

    public void accessJudgeVenueLawFirmStatsMenu() {
        expandVisualAnalyticMenu();
        judgeVenueLawFirmLink.click();
        judgeSearchBox.waitUntilVisible();
    }

    public void accessNPEListstatsMenu() {
        expandIntelligenceMenu();
        npeList_LNK.click();
    }

    public void expandAccountMenu() {
        if (myAccountMenu.isDisplayed()) {
            myAccountMenu.moveTo();
        }
    }

    public void MyRPXMenu() {
        if (myAccountMenu.isDisplayed()) {
            myAccountMenu.moveTo();
        }
    }

    //SAVED PAGE TILE TABLE
    public final Element savedPagesTile_count = $(".sortable_item_container .db-saved-page div.summary_title:contains('Pinned Pages'):visible .new_matters_count");
    public final Element savedPagesTile_Links = $(".sortable_item_container .db-saved-page:has(div.summary_title:contains('Pinned Pages'):visible) div.summary-table-row:visible div:not(.summary-table-header) a");

    public Element getSavePageLink(String sectionName) {
        return $(".content-div .db-saved-page .summary-table-header:contains('" + sectionName + "'):visible~div a");
        //*[@id='sortable-dashboard-modal-content']//div[contains(@class,'overflow-for-large-tile')]//div[contains(text(),'"+ sectionName + "')]/following-sibling::div//a

    }

    public boolean checkSavedPageLinks(String sectionName, String pageId) {
        return getSavePageLink(sectionName).getAttribute("href")
                .contains(pageId);
    }

    public final Element intelligenceTab = $(".tabs.dashboard-header dd>a:contains('Intelligence')");
    public final Element myLitigationsTab = $(".tabs.dashboard-header dd>a:contains('My Litigations')");
    public final Element trendsTab = $(".tabs.dashboard-header dd>a:contains('Trends')");

    //DASHBORD MAIN MENU LINKS
    public final Element myRPX_LNK = $("#primary-nav a:contains('My RPX')");
    public final Element visual_analytics_LNK = $("#primary-nav a:contains(Visual Analytics)");
    public final Element intelligence_LNK = $("#primary-nav a:contains('Intelligence')");
    public final Element accountsMenu = $("li.account-space a.account-name");

    public final Element features_LNK = $(By.xpath("//*[@id='primary-nav']//a[text()='Features']"));
    public final Element myRpxInsurance_LNK = $(By.xpath("//*[@id='primary-nav']//a[text()='My RPX Insurance']"));
    public final Element createAcc_LNK = $(By.xpath("//*[@id='primary-nav']//a[text()='Create Account']"));
    public final Element login_LNK = $("#primary-header a.login-btn");

    public final Element upgradeMyAcc_LNK = $("#primary-nav a:contains(Upgrade)");

    public final Element marketplace_LNK = $(By.xpath("//*[@id='primary-nav']//div[contains(@class,'dropdown')]//a[text()='Marketplace']"));

    //Under Intelligence Menu
    public final Element npeList_LNK = $("ul#intel-menu li:contains(NPE List) a");
    public final Element news_LNK = $("ul#intel-menu li:contains(News) a");
    public final Element rpxReports_LNK = $("ul#intel-menu li:contains(RPX Reports) a");
    public final Element riskReduReports_LNK = $("ul#intel-menu li:contains(Patent Risk Reduction Report) a");
    public final Element priorArtSearchRep_LNK = $("ul#intel-menu li:contains(Prior Art Search Reports) a");
    public final Element rpxIPRs_LNK = $("ul#intel-menu li:contains(RPX IPRs) a");
    public final Element lca_LNK = $("ul#intel-menu li:contains(Litigation Campaign Assessments) a");
    public final Element rpxPerspective = $("ul#intel-menu li:contains(RPX Perspectives) a");
    public final Element blog = $("ul#intel-menu li:contains(Blog) a");

    //Under Visual Analytics
    public final Element partyAnalytics_LNK = $("ul#visan-menu li:contains(Party Analytics) a");
    public final Element customSectorAnalytics_LNK = $("ul#visan-menu li:contains(Custom Sector Analytics) a");
    public final Element ptabAnalytics_LNK = $("ul#visan-menu li:contains(PTAB Analytics) a");
    public final Element chinaAnalyticsLink = $("ul#visan-menu li:contains(Chinese Analytics) a");
    public final Element DCAnalyticsLink = $("ul#visan-menu li:contains(District Court Analytics) a");

    //Under My Accounts
    public final Element myAccount_LNK = $("ul#account-menu li:contains('My Account') a");
    public final Element features_LNK_InMenu = $("ul#account-menu li:contains('Features') a");
    public final Element rpxContact_LNK = $("ul#account-menu li:contains('RPX Contact') a");
    public final Element memberScoreCard_LNK = $("ul#account-menu li:contains('Member Scoreboard') a");
    public final Element admin_LNK = $("ul#account-menu li:contains('Admin') a");
    public final Element viewAsAccount = $("ul#account-menu li:contains('View as Account') a");
    public final Element logout_LNK = $("ul#account-menu li:contains('Log Out') a");

    //Under My Accounts
    public final Element myCompany_LNK = $("ul#my-rpx-menu li:contains('My Company') a");
    public final Element myPortfolio_LNK = $("ul#my-rpx-menu li:contains('Portfolio') a");
    public final Element myMarketplace_LNK = $("ul#my-rpx-menu li a:contains('RPX Marketplace')");

    //--todo  Need to remove the below link once analysed
    public final Element judgeVenueLawFirmLink = $("#visual_analytics a:contains('Judge, Venue, and Law Firm Statistics')");

    public final Element tos_Link = $("#primary-footer .nav a[href*='terms-of-service']");

    public Element getRowFeatureLink(String featureName) {
        return $("div.background-container:has(ul.inline-list:contains('" + featureName + "')) div.learn-more-container>a.learn-more");
    }

    public Element getColumnFeatureLink(String featureName) {
        return $("h2.feature_title:contains('" + featureName + "')+div+a.learn-more");
    }

    public final Highchart newCampaignsFiled = $("div[data-legend-title='New Campaigns Filed']", (Configure<Highchart>) chart ->
            {
                chart.axisLabels("filedYear", "svg g:nth-of-type(10) text");
                chart.dataLabels("total", "svg g:nth-of-type(6) text tspan");
                chart.dataLabels("operating", "svg g:nth-of-type(7) g text");
                chart.dataLabels("npe", "svg g:nth-of-type(8) g text");
            }
    );

    public final Highchart newPtabPetitionsFiled = $(".yearly div[data-legend-title='New PTAB Petitions Filed']", (Configure<Highchart>) chart ->
            {
                chart.axisLabels("filedYear", "svg g:nth-of-type(10) text");
                chart.dataLabels("total", "svg g[class='highcharts-stack-labels']:nth-of-type(6) text tspan");
                chart.dataLabels("operating", "svg g:nth-of-type(7) text");
                chart.dataLabels("npe", "svg g:nth-of-type(8) text");
            }
    );

    public final Highchart uniqueDefendantsInCampaigns = $("div[data-legend-title='Unique Defendants Added in Campaigns']", (Configure<Highchart>) chart ->
            {
                chart.axisLabels("filedYear", "svg g:nth-of-type(11) text");
                chart.dataLabels("total", "svg g[class*='highcharts-series']:nth-of-type(7) text");
                chart.dataLabels("operating", "svg g:nth-of-type(9) text");
                chart.dataLabels("npe", "svg g[class*='highcharts-series']:nth-of-type(8) text");
            }
    );

    public final Highchart defendantsAddedInCampaigns = $("div[data-legend-title='Total Defendants Added in Campaigns']", (Configure<Highchart>) chart ->
            {
                chart.axisLabels("filedYear", "svg g:nth-of-type(10) text");
                chart.dataLabels("total", "svg g[class='highcharts-stack-labels']:nth-of-type(6) text tspan");
                chart.dataLabels("operating", "svg g:nth-of-type(7) g text");
                chart.dataLabels("npe", "svg g:nth-of-type(8) g text");
            }
    );


    public void bannerSearch(Map<String, Object> data) {
//        String searchString;
//        if (!(Boolean) data.get("SpecificPhraseSearch"))
//            searchString = data.get("FieldName").toString() + data.get("SearchInput").toString().replaceAll("\\'", "");
//        else
//            searchString = data.get("FieldName").toString() + "\"" + data.get("SearchInput").toString().replaceAll("\'", "") + "\"";
        searchTextBox.inputText(data.get("SearchInput").toString());
        searchSubmit.click();
        waitForLoading();
        currentSearch.waitUntilVisible();
    }

    public final Highchart newCasesFiledDonutChart = $(".new_cases_filed.campaign_filed_container", (Configure<Highchart>) chart ->
            {
                chart.dataLabels("itc_operating", "svg g:nth-of-type(3) g:nth-of-type(1) text");
                chart.dataLabels("itc_npe", "svg g:nth-of-type(3) g:nth-of-type(2) tspan");
                chart.dataLabels("lit_operating", "svg g:nth-of-type(3) g:nth-of-type(3) text");
                chart.dataLabels("lit_npe", "svg g:nth-of-type(3) g:nth-of-type(4) tspan");
                chart.dataLabels("ptab_operating", "svg g:nth-of-type(3) g:nth-of-type(5) text");
                chart.dataLabels("ptab_npe", "svg g:nth-of-type(3) g:nth-of-type(6) tspan");
                chart.dataLabels("itc_total", "div[class*='highcharts-data-labels highcharts-series'] div:nth-of-type(1) span");
                chart.dataLabels("lit_total", "div[class*='highcharts-data-labels highcharts-series'] div:nth-of-type(2) span");
                chart.dataLabels("ptab_total", "div[class*='highcharts-data-labels highcharts-series'] div:nth-of-type(3) span");
            }
    );

    public Integer getLitigationCount(Object litType) {
        String lit = litType.toString();
        int litCount = 0;
        if (lit.equalsIgnoreCase("campaign_Count")) {
            litCount = groupedResultsCount.getElement("campaign_Count").getIntData();
        } else if (lit.equalsIgnoreCase("PatentLitigation")) {
            litCount = groupedResultsCount.getElement("Lit_Count").getIntData();
        } else if (lit.equalsIgnoreCase("PTAB")) {
            litCount = groupedResultsCount.getElement("Ptab_Count").getIntData();
        } else if (lit.equalsIgnoreCase("ITC")) {
            litCount = groupedResultsCount.getElement("ITC_Count").getIntData();
        } else if (lit.equalsIgnoreCase("FederalCircuit")) {
            litCount = groupedResultsCount.getElement("FC_Count").getIntData();
        } else {
            System.out.println("Invalid Litigation Type");
        }
        return litCount;
    }


    public final StaticContent priorArtAndLcaReports = $("div.rpx-reports-dashboard div[class='show-for-small-tile-only']", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("report_title", "a[href*='campaigns']");
            }
    );

    public final StaticContent newsArticlesForPastOneWeek = $("div.news-dashboard", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("news_title", "li[class='dashboard-news-link'] a");
            }
    );

    public final StaticContent recentAcquisitionsForPastOneMonth = $(".recent-cases:has(.new_matters_desc:contains('Recent Acquisitions'))", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("acquisition_title", ".text-left a");
            }
    );

    public String getFlashMessage() {
        return flashMsg.getText().split("\\n")[0];
    }
}