package com.rpxcorp.insight.page.my_portal;

import com.rpxcorp.insight.module.SelectBox;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;

import java.util.ArrayList;

public class MyAlertsPage extends BasePage {

    public MyAlertsPage() {
        this.url = new PageUrl("alerts");
    }

    @Override
    public boolean at() {
        return alertTitle.waitUntilVisible();
        // alertsHeader.waitUntilVisible();
    }

    public final Element alertTitle = $("h5.section-title:contains('Insight Emails')");
    public final Element dailyLitAlert = $("#user_lit_email_subscription");
    public final Element weeklyNewsletter = $("#user_news_email_subscription");
    public final Element monthlyNPEUpdate = $("#user_monthly_npe_update_subscription");
    public final Element quarterlyRiskReduction = $("#user_quarterly_risk_reduction_report");
    public final Element quarterlyFeatureRelease= $("#user_quarterly_feature_release_updates");


    public final Element unsubscribe_Btn = $(".alert.button[value='Unsubscribe All']");
    public final Element weeklyNewsletterLabel = $("label[for='user_news_email_subscription']");

    public final Element monthly_npe_update_subscription=$("#user_monthly_npe_update_subscription");
    public final Element saveSubscription = $(".button[value='Save Subscriptions']");
    public final Element marketSectorAddAlertButton= $("div.alert_accordion:has(h5:contains('Market Sector Litigation Alert')) span:contains('Add Alert')");
    public final Element marketSectorDialog = $("#alert-modal");
    public final Element createAlertBtn = $("input[value='Create Alert']");
    public final Element updateAlertBtn = $("input[value='Update Alert']");
    private final Element deleteAlertBtn = $(".delete_alert_in_modal");
    public void openMarketSectorAlert(){
            if(!marketSectorDialog.isDisplayed()){
                marketSectorAddAlertButton.click();
                marketSectorDialog.waitUntilVisible();
            }
    }
    public void createMarketSectorAlert() {
        createAlertBtn.waitUntilVisible();
        createAlertBtn.click();
        marketSectorDialog.waitUntilInvisible();
    }
    public final SelectBox markeSectorsList = $("select#market_sector_id",SelectBox.class);
    public final SelectBox markeSectorsValuesDisabled =$("select#market_sector_id option[disabled='disabled']",SelectBox.class);
    public final Table marketSectorAlertTable = $("div.alert_accordion:has(h5:contains('Market Sector Litigation Alert')) table", (Configure<Table>) table ->   //.alert_accordion:nth-child(2) table
    {
                table.uniqueId("td:nth-child(1)");
                table.nextPage("div.alert_accordion:has(h5:contains('Market Sector Litigation Alert')) div.paging_will_paginate span.paginate_button:contains('Next')");
                table.lastPage("div.alert_accordion:has(h5:contains('Market Sector Litigation Alert')) .paging_will_paginate span[class$='_linkList']>span:last-child");
            }
    );
    public final Table entityAlertTable = $("div.alert_accordion:has(h5:contains('Entity Alerts')) table", (Configure<Table>) table -> //.alert_accordion:nth-child(3) table
        {
            table.uniqueId("td:nth-child(1) a");
            table.nextPage("div.alert_accordion:has(h5:contains('Entity Alerts')) div.paging_will_paginate span.paginate_button:contains('Next')");
            table.lastPage("div.alert_accordion:has(h5:contains('Entity Alerts')) .paging_will_paginate span[class$='_linkList']>span:last-child");
        }
    );

    public final Table campaignAlertTable = $("div.alert_accordion:has(h5:contains('Campaign Alerts')) table", (Configure<Table>) table ->  //.alert_accordion:nth-child(4) table
        {
            table.uniqueId("td:nth-child(1) a");
            table.nextPage("div.alert_accordion:has(h5:contains('Campaign Alerts')) div.paging_will_paginate span.paginate_button:contains('Next')");
            table.lastPage("div.alert_accordion:has(h5:contains('Campaign Alerts')) .paging_will_paginate span[class$='_linkList']>span:last-child");
        }
    );

    public final Table districtCourtAlertTable = $("div.alert_accordion:has(h5:contains('District Court Alerts')) table", (Configure<Table>) table ->   //.alert_accordion:nth-child(5) table
            {
                table.uniqueId("td:nth-child(1) a");
                table.nextPage("div.alert_accordion:has(h5:contains('District Court Alerts')) div.paging_will_paginate span.paginate_button:contains('Next')");
                table.lastPage("div.alert_accordion:has(h5:contains('District Court Alerts')) .paging_will_paginate span[class$='_linkList']>span:last-child");
            }
    );

    public final Table ptabAlertTable = $("div.alert_accordion:has(h5:contains('PTAB Alerts')) table", (Configure<Table>) table ->  //.alert_accordion:nth-child(6) table
            {
                table.uniqueId("td:nth-child(1) a");
                table.nextPage("div.alert_accordion:has(h5:contains('PTAB Alerts')) div.paging_will_paginate span.paginate_button:contains('Next')");
                table.lastPage("div.alert_accordion:has(h5:contains('PTAB Alerts')) .paging_will_paginate span[class$='_linkList']>span:last-child");
            }
    );
    public final Table itcAlertTable = $("div.alert_accordion:has(h5:contains('ITC Alerts')) table", (Configure<Table>) table ->  //.alert_accordion:nth-child(7) table
            {
                table.uniqueId("td:nth-child(1) a");
                table.nextPage("div.alert_accordion:has(h5:contains('ITC Alerts')) div.paging_will_paginate span.paginate_button:contains('Next')");
                table.lastPage("div.alert_accordion:has(h5:contains('ITC Alerts')) .paging_will_paginate span[class$='_linkList']>span:last-child");
            }
    );

    public final Table patentAlertTable = $("div.alert_accordion:has(h5:contains('Patent Alerts')) table", (Configure<Table>) table -> //.alert_accordion:nth-child(8) table
        {
            table.uniqueId("td:nth-child(1) a");
            table.nextPage(".alert_accordion:has(h5:contains('Patent Alerts')) div.paging_will_paginate span.paginate_button:contains('Next')");
            table.lastPage(".alert_accordion:has(h5:contains('Patent Alerts')) .paging_will_paginate span[class$='_linkList']>span:last-child");
        }
    );

    public final Table lawfirmAlertTable = $("div.alert_accordion:has(h5:contains('Law Firm Alerts')) table", (Configure<Table>) table ->  //.alert_accordion:nth-child(9) table
            {
            table.uniqueId("td:nth-child(1) a");
            table.nextPage("div.alert_accordion:has(h5:contains('Law Firm Alerts')) div.paging_will_paginate span.paginate_button:contains('Next')");
            table.lastPage("div.alert_accordion:has(h5:contains('Law Firm Alerts')) .paging_will_paginate span[class$='_linkList']>span:last-child");
            }
    );

    public final Table federalCircuitAlertTable = $("div.alert_accordion:has(h5:contains('Federal Circuit Alerts')) table", (Configure<Table>) table ->   //.alert_accordion:nth-child(5) table
            {
                table.uniqueId("td:nth-child(1) a");
                table.nextPage(".alert_accordion:has(h5:contains('Federal Circuit Alerts')) div.paging_will_paginate span.paginate_button:contains('Next')");
                table.lastPage(".alert_accordion:has(h5:contains('Federal Circuit Alerts')) .paging_will_paginate span[class$='_linkList']>span:last-child");
            }
    );


    public void saveSubscriptions() {
        saveSubscription.click();
        waitForLoading();
    }
    public void selectAllAlertOptions() {
        if(dailyLitAlert.getAttribute("checked")==null){
            dailyLitAlert.click();
        }
        if(weeklyNewsletter.getAttribute("checked")==null){
            weeklyNewsletter.click();
        }
        if(monthlyNPEUpdate.getAttribute("checked")==null){
            monthlyNPEUpdate .click();
        }
        if(quarterlyRiskReduction.getAttribute("checked")==null){
            quarterlyRiskReduction.click();
        }
        if(quarterlyFeatureRelease.getAttribute("checked")==null){
            quarterlyFeatureRelease.click();
        }
    }
    public void deSelectAllAlertOptions() {
        if(dailyLitAlert.getAttribute("checked")!=null){
            dailyLitAlert.click();
        }
        if(weeklyNewsletter.getAttribute("checked")!=null){
            weeklyNewsletter.click();
        }
        if(monthlyNPEUpdate.getAttribute("checked")!=null){
            monthlyNPEUpdate.click();
        }
        if(quarterlyRiskReduction.getAttribute("checked")!=null){
            quarterlyRiskReduction.click();
        }
        if(quarterlyFeatureRelease.getAttribute("checked")!=null){
            quarterlyFeatureRelease.click();
        }
    }

    public void quarterlyFeature(String action) {
        if(action == "select") {
            if(!quarterlyFeatureRelease.isSelected())
                quarterlyFeatureRelease.click();
            //quarterlyFeatureRelease.scrollAndClickOn();
        } else {
            if(quarterlyFeatureRelease.isSelected())
                quarterlyFeatureRelease.click();
        }
    }



    public ArrayList<String> getSubscripedOptions(){
        return  $("form[action='/user#general'] input:checked+label").getAllData();
    }

}
