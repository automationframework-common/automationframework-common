package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.module.Table;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;

public class UserSubscriptionViewPage extends Page {

    public UserSubscriptionViewPage() {
        this.url = new PageUrl("admin/users/{ID}/subscriptions");
    }

    @Override
    public boolean at() {
        return userTitle.waitUntilVisible();
    }

    public final Element userTitle = $("h5:contains(subscriptions)");

    public final Table marketSectorAlertTable = $("div.alert_accordion:has(h2:contains('Market Sector Litigation Alert')) table", (Configure<Table>) table ->   //.alert_accordion:nth-child(2) table
            {
                table.uniqueId("td:nth-child(1) a");
                table.nextPage(".alert_accordion:has(h5:contains('Market Sector Litigation Alert')) div.paging_will_paginate span.paginate_button:contains('Next')");
                table.lastPage(".alert_accordion:has(h5:contains('Market Sector Litigation Alert')) .paging_will_paginate span[class$='_linkList']>span:last-child");
            }
    );
    public final Table entityAlertTable = $("div.alert_accordion:has(h5:contains('Entity Alerts')) table", (Configure<Table>) table -> //.alert_accordion:nth-child(3) table
            {
                table.uniqueId("td:nth-child(1) a");
                table.nextPage(".alert_accordion:has(h5:contains('Entity Alerts')) div.paging_will_paginate span.paginate_button:contains('Next')");
                table.lastPage(".alert_accordion:has(h5:contains('Entity Alerts')) .paging_will_paginate span[class$='_linkList']>span:last-child");
            }
    );

    public final Table campaignAlertTable = $("div.alert_accordion:has(h5:contains('Campaign Alerts')) table", (Configure<Table>) table ->  //.alert_accordion:nth-child(4) table
            {
                table.uniqueId("td:nth-child(1) a");
                table.nextPage(".alert_accordion:has(h5:contains('Campaign Alerts')) div.paging_will_paginate span.paginate_button:contains('Next')");
                table.lastPage(".alert_accordion:has(h5:contains('Campaign Alerts')) .paging_will_paginate span[class$='_linkList']>span:last-child");
            }
    );

    public final Table districtCourtAlertTable = $("div.alert_accordion:has(h5:contains('District Court Alerts')) table", (Configure<Table>) table ->   //.alert_accordion:nth-child(5) table
            {
                table.uniqueId("td:nth-child(1) a");
                table.nextPage(".alert_accordion:has(h5:contains('District Court Alerts')) div.paging_will_paginate span.paginate_button:contains('Next')");
                table.lastPage(".alert_accordion:has(h5:contains('District Court Alerts')) .paging_will_paginate span[class$='_linkList']>span:last-child");
            }
    );

    public final Table ptabAlertTable = $("div.alert_accordion:has(h5:contains('PTAB Alerts')) table", (Configure<Table>) table ->  //.alert_accordion:nth-child(6) table
            {
                table.uniqueId("td:nth-child(1) a");
                table.nextPage(".alert_accordion:has(h5:contains('PTAB Alerts')) div.paging_will_paginate span.paginate_button:contains('Next')");
                table.lastPage(".alert_accordion:has(h5:contains('PTAB Alerts')) .paging_will_paginate span[class$='_linkList']>span:last-child");
            }
    );
    public final Table itcAlertTable = $("div.alert_accordion:has(h5:contains('ITC Alerts')) table", (Configure<Table>) table ->  //.alert_accordion:nth-child(7) table
            {
                table.uniqueId("td:nth-child(1) a");
                table.nextPage(".alert_accordion:has(h5:contains('ITC Alerts')) div.paging_will_paginate span.paginate_button:contains('Next')");
                table.lastPage(".alert_accordion:has(h5:contains('ITC Alerts')) .paging_will_paginate span[class$='_linkList']>span:last-child");
            }
    );

    public final Table patentAlertTable = $("div.alert_accordion:has(h5:contains('Patent Alerts')) table", (Configure<Table>) table -> //.alert_accordion:nth-child(8) table
            {
                table.uniqueId("td:nth-child(1) a");
                table.nextPage(".alert_accordion:has(h5:contains('Patent Alerts')) div.paging_will_paginate span.paginate_button:contains('Next')");
                table.lastPage(".alert_accordion:has(h5:contains('Patent Alerts')) .paging_will_paginate span[class$='_linkList']>span:last-child");
            }
    );

    public final Table lawfirmAlertTable = $("div.alert_accordion:has(h5:contains('Law Firm Alerts')) table", (Configure<Table>) table ->  //.alert_accordion:nth-child(9) table
            {
                table.uniqueId("td:nth-child(1) a");
                table.nextPage(".alert_accordion:has(h5:contains('Law Firm Alerts')) div.paging_will_paginate span.paginate_button:contains('Next')");
                table.lastPage(".alert_accordion:has(h5:contains('Law Firm Alerts')) .paging_will_paginate span[class$='_linkList']>span:last-child");
            }
    );

    public final Table federalCircuitAlertTable = $("div.alert_accordion:has(h5:contains('Federal Circuit Alerts')) table", (Configure<Table>) table ->   //.alert_accordion:nth-child(5) table
            {
                table.uniqueId("td:nth-child(1) a");
                table.nextPage(".alert_accordion:has(h5:contains('Federal Circuit Alerts')) div.paging_will_paginate span.paginate_button:contains('Next')");
                table.lastPage(".alert_accordion:has(h5:contains('Federal Circuit Alerts')) .paging_will_paginate span[class$='_linkList']>span:last-child");
            }
    );

}
