package com.rpxcorp.insight.page;

import com.rpxcorp.testcore.element.Element;

public class ResetPasswordPage extends BasePage {

    @Override
    public boolean at() {

        return newPassword.waitUntilVisible();
    }

    public final Element newPassword = $("#user_password");
    public final Element confirmPassword = $("#user_password_confirmation");
    public final Element change_pswd_btn = $("input[value='Change my password']");
    public final String flashText = "";

    public void submitNewPassword(String newPaswd, String cnfmPaswd) {
        newPassword.waitUntilVisible();
        newPassword.sendKeys(newPaswd);
        confirmPassword.sendKeys(cnfmPaswd);
        change_pswd_btn.click();
    }

}
