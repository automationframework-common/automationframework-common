package com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.InternalAppsPortfolioPage;
import com.rpxcorp.insight.page.PatentRiskReductionAdminPage;
import com.rpxcorp.insight.page.PatentRiskReductionPage;
import com.rpxcorp.testcore.Assert;
import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

@Authenticate(role = "ADMIN")
public class AdminQuarterlyPRRRTest extends BaseFuncTest {
    PatentRiskReductionAdminPage patentRiskReductionAdminPage;
    PatentRiskReductionPage patentRiskReductionPage;
    InternalAppsPortfolioPage internalAppsPortfolioPage;

    @Test(priority = 1, groups="P3", description = "Verify Link to Portfolio page is present next to acquisition name in Admin page | RPX-13353 Add Acquiflow link to QRRR admin page")
    public void verifyLinkToPortfolioPageInAdminPage() throws Exception {
        to(patentRiskReductionAdminPage);
        patentRiskReductionAdminPage.patentRiskPanelTabs.select("DEFENSIVE ACQUISITIONS");
        String acuiName = patentRiskReductionAdminPage.acquiflowName.getText();
        withNewWindow(patentRiskReductionAdminPage.acquiflowLink, () -> {
            internalAppsPortfolioPage.login();
            Assert.isTrue(internalAppsPortfolioPage.pageTitle.getText().contains(acuiName), "Acquiflow link title is not matching to the Internal apps portfolio page");
        });
    }

    @Test(priority = 2, groups="P3", description = "Verify Link to Portfolio page is not present next to acquisition name in final publish page | RPX-13353 Add Acquiflow link to QRRR admin page")
    public void verifyLinkToPortfolioPageInPublishPage() throws Exception {
        to(patentRiskReductionPage);
        patentRiskReductionAdminPage.patentRiskPanelTabs.select("DEFENSIVE ACQUISITIONS");
        Assert.isFalse(patentRiskReductionAdminPage.acquiflowLink.isDisplayed(), "Acquiflow link is availbale in the Publish page");
    }
}
