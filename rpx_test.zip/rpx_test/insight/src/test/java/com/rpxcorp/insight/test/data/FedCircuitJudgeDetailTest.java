package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.detail.FedCircuitJudgeDetailPage;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.TableData;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

@Authenticate(role = "MEMBER")
public class FedCircuitJudgeDetailTest extends BaseDataTest {
    FedCircuitJudgeDetailPage fedCircuitJudgeDetailPage;
    TableData tableData;
    Map<String, String> staticData;
    HashMap<String, TableData> subData = new HashMap<String, TableData>();
    ResultSet resultSet;

    @Factory(dataProvider = "returnData")
    public FedCircuitJudgeDetailTest(String dataDescription, String judgeID) {
        this.dataId = judgeID;
        this.dataDescription = dataDescription;
    }

    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("FedCircuitJudgeDetailTest");
    }

    @BeforeClass
    public void loadPage() {
        urlData.put("ID", dataId);
        this.dataUrl = fedCircuitJudgeDetailPage.getDeclaredUrl(urlData);
        to(fedCircuitJudgeDetailPage, urlData);
    }

    @Test(description = "Verify Title", priority = 1)
    public void Verify_Title() throws Exception {
        assertEquals(fedCircuitJudgeDetailPage.pageTitle.getData(), sqlProcessor.getResultData("FedCircuitJudgeDetail.TITLE", dataId),
                "Title mismatch between DB and UI");
    }

    @Test(description = "Verify Active Appeals associated to Judge", priority = 2)
    public void Verify_Active_Cases() throws Exception {
        staticData = fedCircuitJudgeDetailPage.judgeDetail.getData();
        assertEquals(staticData.get("Active Appeals"),
                sqlProcessor.getResultCount("FedCircuitJudgeDetail.FEDCIRCUIT_ACTIVE", dataId), "active_appeals");

    }

    @Test(description = "Verify InActive Appeals associated to Judge", priority = 3)
    public void Verify_InActive_Cases() throws Exception {
        assertEquals(staticData.get("Inactive Appeals"),
                sqlProcessor.getResultCount("FedCircuitJudgeDetail.FEDCIRCUIT_INACTIVE", dataId), "inactive_appeals");
    }


}