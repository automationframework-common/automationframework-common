package com.rpxcorp.insight.page.intelligence;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class SearchFAQsPage extends BasePage {

    public SearchFAQsPage() {
        this.url = new PageUrl("advanced_search/faq");
    }

    @Override
    public boolean at() {
        return pageTitle.waitUntilVisible();
    }

    public final Element pageTitle = $("#content .section-title");
    public final Element faqSectionsLinks = $(".triangle_bullets.section_index li a");
    public final Element faqSectionsLink1 = $(".triangle_bullets.section_index li:nth-of-type(1) a");
    public final Element faqSectionsLink2 = $(".triangle_bullets.section_index li:nth-of-type(2) a");
    public final Element faqSectionsLink3 = $(".triangle_bullets.section_index li:nth-of-type(3) a");
    public final Element faqSectionsLink4 = $(".triangle_bullets.section_index li:nth-of-type(4) a");
    public final Element faqSectionsLink5 = $(".triangle_bullets.section_index li:nth-of-type(5) a");
    public final Element faqSectionsLink6 = $(".triangle_bullets.section_index li:nth-of-type(6) a");
    

    public final Element faqsTopicsButton = $(".button-group.right li>a");
    public final Element faqsTopicsPopUp = $("#faq_pages_menu_modal");
    
    public final String link1Text = "Gauge Your Interest in Patent Portfolios for Sale";
    public final String link2Text = "Has a Patent Been Litigated?";
    public final String link3Text = "Determine Your next move in Patent Litigation";
    public final String link4Text = "What NPEs Has a Law Firm Represented?";
    public final String link5Text = "Which Companies Have Been Named Alongside Me?";
    public final String link6Text = "What Campaigns Are Driven by Prolific NPEs?";   

    public final String[] searchFaqsIndexTitles = { link1Text, link2Text, link3Text, link4Text, link5Text,
            link6Text };

}
