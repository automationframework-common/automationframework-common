package com.rpxcorp.insight.page.payment;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class PaymentErrorsPage extends BasePage {

    @Override
    public boolean at() {
        return header.waitUntilVisible();
    }

    public final Element errorMsg = $(".panel .large-12.columns");
    public final Element header = $(".large-6.small-12.columns");
}
