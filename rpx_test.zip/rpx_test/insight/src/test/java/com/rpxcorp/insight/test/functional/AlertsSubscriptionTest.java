package com.rpxcorp.insight.test.functional;

import com.google.gson.JsonObject;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.account.UserSubscriptionViewPage;
import com.rpxcorp.insight.page.account.UserViewPage;
import com.rpxcorp.insight.page.account.UsersPage;
import com.rpxcorp.insight.page.detail.AlertsSubscriptionPage;
import com.rpxcorp.insight.page.detail.BaseDetailPage;
import com.rpxcorp.insight.page.my_portal.MyAlertsPage;
import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.util.List;
@Authenticate(role = "MEMBER")
public class AlertsSubscriptionTest extends BaseFuncTest {
    BaseDetailPage detailPage;
    AlertsSubscriptionPage alertsSubscriptionPage;
    MyAlertsPage myAlerts;
    private Table alertsTable;
    private String[] dataIds;
    private String page;
    UsersPage adminUserPage;
    UserViewPage adminUserViewPage;
    UserSubscriptionViewPage userSubscriptionViewPage;

    /******* TEST METHODS ********/
    @Test(priority = 1,groups="P2")
    public void createAlertWithDefault() throws Exception {
        navigatetoPage(dataIds[0]);
        accessCreateAlert();
        assertEquals(alertsSubscriptionPage.title.getText(),"Create "+dataAsString("titleText")+" Alert");
        // * Verify Default Selected Options
        assertSelectedOptions(dataAsList("defaultSelectedEvents"),dataAsList("defaultSelectedRpxReportEvents"), dataAsString("defaultSelectedFrequency"));
        alertsSubscriptionPage.createAlert();
        assertAlertSubscribed(dataAsList("defaultSelectedEvents"),dataAsList("defaultSelectedRpxReportEvents"), dataAsString("defaultSelectedFrequency"));
        closeAlertDialog();
    }


    @Test(priority = 1,groups="P2")
    public void createAlertByChangingOptions() throws Exception {
        navigatetoPage(dataIds[1]);
        accessCreateAlert();
        alertsSubscriptionPage.caseEventsCheckList.unselectInTableFormat(dataAsString("inputEvent"));
        alertsSubscriptionPage.rpxReportsEventsCheckList.unselectInTableFormat(dataAsString("inputRpxReportsEvent"));
        alertsSubscriptionPage.frequencyRadio.selectValue("weekly");
        alertsSubscriptionPage.createAlert();
        assertAlertSubscribed(dataAsList("expectedModifiedEvents"),dataAsList("expectedModifiedRpxReportsEvents"), "Weekly");
        closeAlertDialog();
    }


    @Test(priority = 1,groups="P2")
    public void createAlertBySelectAllEvents() throws Exception {
        navigatetoPage(dataIds[2]);
        accessCreateAlert();
        alertsSubscriptionPage.selectAllEvent();
        alertsSubscriptionPage.selectAllReportsEvent();
        alertsSubscriptionPage.frequencyRadio.selectValue("hourly");
        alertsSubscriptionPage.createAlert();
        assertAlertSubscribed(dataAsList("expectedAllEvents"),dataAsList("expectedRpxReportsEvents"), "Hourly");
        closeAlertDialog();
    }

    @Test(priority = 1,groups="P2")
    public void createAlertBySelectNoneEvents() throws Exception {
        navigatetoPage(dataIds[3]);
        accessCreateAlert();
        alertsSubscriptionPage.selectNoneEvent();
        alertsSubscriptionPage.selectNoneRpxReportsEvent();
        alertsSubscriptionPage.createAlertBtn.click();
        alertsSubscriptionPage.errorMessage.waitUntilVisible();
        assertEquals(alertsSubscriptionPage.errorMessage.getText(),dataAsString("expectedErrorMessage"),
                "Expected error message");
        closeAlertDialog();
    }

    @Test(priority = 2/*, dependsOnMethods = "createAlertByChangingOptions"*/,groups="P2")
    public void modifyAlertBySelectingOptions() throws Exception {
        navigatetoPage(dataIds[1]);
        accessModifyAlert();
        assertEquals(alertsSubscriptionPage.title.getText(),"Modify "+dataAsString("titleText")+" Alert");
        alertsSubscriptionPage.caseEventsCheckList.selectInTableFormat(dataAsString("inputEvent"));
        alertsSubscriptionPage.rpxReportsEventsCheckList.selectInTableFormat(dataAsString("inputRpxReportsEvent"));
        alertsSubscriptionPage.frequencyRadio.selectValue("daily");
        alertsSubscriptionPage.updateAlert();
        assertAlertSubscribed(dataAsList("defaultSelectedEvents"),dataAsList("defaultSelectedRpxReportEvents"),dataAsString("defaultSelectedFrequency"));
        closeAlertDialog();
    }

    @Test(priority = 2/*, dependsOnMethods = "createAlertBySelectAllEvents"*/,groups="P2")
    public void modifyAlertBySelectingNone() throws Exception {
        navigatetoPage(dataIds[2]);
        accessModifyAlert();
        alertsSubscriptionPage.selectNoneEvent();
        alertsSubscriptionPage.selectNoneRpxReportsEvent();
        alertsSubscriptionPage.updateAlertBtn.click();
        alertsSubscriptionPage.errorMessage.waitUntilVisible();
        assertEquals(alertsSubscriptionPage.errorMessage.getText(),dataAsString("expectedErrorMessage"),
                "Expected error message");
        closeAlertDialog();
    }

    @Test(priority = 3/*, dependsOnMethods = "createAlertWithDefault"*/,groups="P2")
    public void deleteAlert() throws Exception {
        navigatetoPage(dataIds[0]);
        accessModifyAlert();
        alertsSubscriptionPage.deleteAlert();
        assertEquals(detailPage.createAlertBtn.waitUntilVisible(), true,
                "Create button has to be displayed after alert deleted");
    }

    @Test(priority = 2 /*dependsOnMethods = "createAlertWithDefault"*/,groups="P2")
    public void VerifyAddedAlertInMyAlerts() throws Exception {
        navigatetoMyAlerts();
        alertsTable.waitUntilVisible();
        assertEquals(alertsTable.waitforRow(dataIds[0]), true, "Added alert should be visible in My alerts page");
        alertsTable.editRow(dataIds[0]);
        waitForAlertSubscriptionPopup();
        assertSelectedOptions(dataAsList("defaultSelectedEvents"),dataAsList("defaultSelectedRpxReportEvents"),dataAsString("defaultSelectedFrequency"));
        closeAlertDialog();
    }

    @Test(priority = 2, dataProvider = "sortColumns",groups = {"P4","func_sorting"}/*, dependsOnMethods = { "createAlertWithDefault",
            "createAlertByChangingOptions", "createAlertBySelectAllEvents" }*/)
    public void verifySortinMyAlerts(String columnName, String columnType) throws Exception {
        navigatetoMyAlerts();
        alertsTable.waitUntilVisible();
        alertsTable.sort(columnName);
        alertsTable.waitUntilVisible();
        assertColumnSort(columnType, "ASC", alertsTable.getColumn(columnName));
        alertsTable.sort(columnName);
        alertsTable.waitUntilVisible();
        assertColumnSort(columnType, "DESC", alertsTable.getColumn(columnName));
    }

    @DataProvider
    public Object[][] sortColumns() throws Exception {
        return new Object[][] { { "filed date", "date" }, { "title", "string" } };
    }

    @Test(priority = 4/* ,dependsOnMethods = "createAlertBySelectAllEvents"*/,groups="P2")
    public void modifyAlertInMyAlerts() throws Exception {
        navigatetoMyAlerts();
        alertsTable.waitforRow(dataIds[2]);
        alertsTable.editRow(dataIds[2]);
        waitForAlertSubscriptionPopup();
        alertsSubscriptionPage.selectNoneEvent();
        alertsSubscriptionPage.selectNoneRpxReportsEvent();
        alertsSubscriptionPage.caseEventsCheckList.selectInTableFormat(dataAsList("inputEvent_MyAlerts"));
        alertsSubscriptionPage.rpxReportsEventsCheckList.selectInTableFormat(dataAsList("inputRpxReports_MyAlerts"));
        alertsSubscriptionPage.frequencyRadio.selectValue("weekly");
        alertsSubscriptionPage.updateAlert();
        navigatetoPage(dataIds[2]);
        assertAlertSubscribed(dataAsList("inputEvent_MyAlerts"),dataAsList("inputRpxReports_MyAlerts"), "Weekly");
        closeAlertDialog();
    }

    @Test(priority = 4/*, dependsOnMethods = "createAlertByChangingOptions"*/,groups="P2")
    public void deleteAlertInMyAlerts() throws Exception {
        navigatetoMyAlerts();
        alertsTable.waitforRow(dataIds[1]);
        alertsTable.deleteRow(dataIds[1]);
        myAlerts.acceptAlert();
        navigatetoPage(dataIds[1]);
        assertEquals(detailPage.createAlertBtn.waitUntilVisible(), true,
                "Create button has to be displayed after alert deleted");
    }
    

    @Test(priority=5/*,dependsOnMethods="createAlertBySelectAllEvents"*/,groups="P2")
    @Authenticate(role = "ADMIN")
    public void checkAlertFilterInAdminAccountPage() throws Exception {
    	to(adminUserPage,true);
    	adminUserPage.selectFilter("Alerts");
    	adminUserPage.searchUserByEmail(config.getProperty("MEMBER_EMAIL"));
    	adminUserPage.userList_Table.waitUntilVisible();
    	adminUserPage.userNameLink.click();
    	at(adminUserViewPage);
    	assertTrue(adminUserViewPage.alert_Btn.isDisplayed(), "Alert button is not available in user view Page "+adminUserViewPage.getCurrentUrl());
    	adminUserViewPage.alert_Btn.click();
    	at(userSubscriptionViewPage);
    	alertsTable = (Table) userSubscriptionViewPage.object(dataAsString("myAlertTable_Object"));
    	assertEquals(alertsTable.waitforRow(dataIds[2]),true,"User subscribed alert is not displayed at Admin User subscription page");
    }

    /******* HELPER METHODS ********/
    private void navigatetoPage(String id) throws Exception {
        this.urlData.put("ID", id);
        to(page, urlData);
    }
    
    public void closeAlertDialog() {
    	if(detailPage.alert_dialog.isDisplayed())
    	{	
    		detailPage.close_alert_dialog.waitUntilVisible();
    		detailPage.close_alert_dialog.click();
    		detailPage.alert_dialog.waitUntilInvisible();
    	}
    }

    private void navigatetoMyAlerts() throws Exception {
        to(myAlerts);
        alertsTable = (Table) myAlerts.object(dataAsString("myAlertTable_Object"));
    }

    private void accessCreateAlert() {
        detailPage.createAlertBtn.click();
        waitForAlertSubscriptionPopup();
    }

    private void accessModifyAlert() {
    	closeAlertDialog();
    	detailPage.modifyAlertBtn.waitUntilClickable();
        detailPage.modifyAlertBtn.click();
        waitForAlertSubscriptionPopup();
    }

    private void waitForAlertSubscriptionPopup() {
        if (alertsSubscriptionPage == null) {
            at(alertsSubscriptionPage);
        } else {
            alertsSubscriptionPage = at(alertsSubscriptionPage);
        }
        detailPage.alert_dialog.waitUntilVisible();
    }

    private void assertAlertSubscribed(List<String> expectedSelectedEvents,List<String> expectedSelectedReportsEvents, String expectedSelectedFrequency)
            throws Exception {
        assertEquals(detailPage.modifyAlertBtn.waitUntilVisible(), true,
                "Modify button has to be displayed after alert created");
        accessModifyAlert();
        assertSelectedOptions(expectedSelectedEvents,expectedSelectedReportsEvents,expectedSelectedFrequency);
    }

    private void assertSelectedOptions(List<String> expectedEvents, List<String> expectedReportEvents, String expectedFrequency) throws Exception {
        assertEquals(alertsSubscriptionPage.caseEventsCheckList.getSelectedTableField(), expectedEvents,
                "Selected Event Options");
        assertEquals(alertsSubscriptionPage.frequencyRadio.getSelectedField().replace("\n",""), expectedFrequency, "Selected Frequency");
        assertEquals(alertsSubscriptionPage.rpxReportsEventsCheckList.getSelectedTableField(), expectedReportEvents,
                "Selected Rpx Reports Event Options");                
    }

    /******* CONFIGIRATION METHODS ********/
    @BeforeClass
    public void setup() throws Exception {
        dataIds = getDBData(dataAsString("TESTDATA_QUERY_KEY"), "5");
        //enableFeature("Alerts Overhaul");

    }

    @Factory(dataProvider = "alertSubsriptionPages")
    public AlertsSubscriptionTest(String page, JsonObject testData) {
        this.page = page;
        this.testData = testData;
    }

    @DataProvider()
    public static Object[][] alertSubsriptionPages() throws Exception {
        JsonObject testSuiteData = getJsonTestData("AlertsSubscriptionTest.json");
        return new Object[][] {
           { "LitigationDetailPage", testSuiteData.getAsJsonObject("LITIGATION") },
             { "ITCDetailPage", testSuiteData.getAsJsonObject("ITC") },
             { "PtabDetailPage", testSuiteData.getAsJsonObject("PTAB") },
                { "FedCircuitDetailPage", testSuiteData.getAsJsonObject("FEDERALCIRCUIT")
                }
        };
    }

}
