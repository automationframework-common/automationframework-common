package com.rpxcorp.insight.page.payment;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class DocumentCreditLogin extends BasePage {

    public DocumentCreditLogin() {
        this.url = new PageUrl("payments/add_credit");
    }

    @Override
    public boolean at() {
        return login_Link.waitUntilVisible();
    }

    public final Element login_Link=$("#primary-header #public_login_btn");
    public final Element paymentLoginPanel = $(".payment_login .panel");

    public final Element createANewOneLink = $("a[data-source*='payment_login']");
    public final Element forgotPasswordLink = $("#forgot_password");

    public final Element userEmail = $("input[id='user_email'][tabindex]");
    public final Element password = $("input[id='user_password'][tabindex]");
    public final Element loginNowBtn = $("input[value='Login Now']");

    public void login(String mailId, String pwd) {
        userEmail.sendKeys(mailId);
        password.sendKeys(pwd);
        loginNowBtn.click();
    }

    public final Element paymentLoginError = $(".login_holder .errors:visible");
}
