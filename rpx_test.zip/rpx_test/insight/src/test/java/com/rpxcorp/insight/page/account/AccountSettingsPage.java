package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.BraintreeUtil;
import org.openqa.selenium.Keys;

import java.util.Map;

public class AccountSettingsPage extends BasePage {

    public AccountSettingsPage() {
        this.url = new PageUrl("user/edit");
    }

    @Override
    public boolean at() {
        return myAccountsHeader.waitUntilVisible();
    }

    public final Element myAccountsHeader = $("#user_profile h5:contains('Basic Information')");

    /** BASIC INFORMATION OBJECTS  */
    public final Element firstName = $("#user_first_name");
    public final Element lastName = $("#user_last_name");
    public final Element industry = $("#user_industry");
    public final Element email = $("#user_email");

    public final Element companyStatic = $("form.edit_user label:contains('Company:')");

    public  final Element emailToolTip=$("label:contains('Email') span.help");




    /** PAYMENT INFORMATION SECTION NEW*/
    public final Element delete_card_trialuser=$(".payment_method a.delete_card");

    /** PAYMENT INFORMATION SECTION */
    public final Element card_expire_alert=$(".payment_information .card_expire_alert");
    public final Element delete_card=$(".payment_method a.delete_default_card");
    public final Element add_new_card_btn=$("a[data-reveal-id='add_payment_method_modal']");
    public final Element add_card_modal=$("#add_payment_method_modal h2");
    public final Element card_change_msg=$(".payment_information .success_messages");
    public final Element payment_Button = $(".pay_button input");
    public final Element cardNumber = $(".add-payment-method-view form #credit-card-number");
    public final Element cardExpiredDate = $(".add-payment-method-view form #expiration");
    public final Element cardCVV = $(".add-payment-method-view form #cvv");
    public final Element cardPostalCode = $(".add-payment-method-view form #postal-code");
    public final Element iframe = $("#braintree-dropin-frame");
    public final Element countryDropdown = $("#s2id_user_details_country_code");
    public final Element countrySearch = $("input.select2-input:visible()");
    public final Element countrySelect = $("ul.select2-results li:nth-of-type(1)");





    public void selectCountry(String country) {
        countryDropdown.waitUntilVisible();
        countryDropdown.click();
        countrySearch.waitUntilVisible();
        countrySearch.sendKeys(country);
        countrySelect.waitUntilVisible();
        countrySearch.sendKeys(country+ Keys.RETURN);
        //countrySelect.waitUntilVisible();
        //countrySelect.click();
        try {
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e);
        }
    }
    
    public void enterCardDetails(Map<String, String> map) {

        iframe.waitUntilSwitchToFrame();
        cardNumber.waitUntilVisible();
        cardNumber.sendKeys(map.get("card_number"));
        cardExpiredDate.sendKeys(map.get("expiration_date"));
        cardCVV.sendKeys(map.get("cvv"));
        cardPostalCode.sendKeys(map.get("postal_code"));
        getDriver().switchTo().defaultContent();
        selectCountry(map.get("country"));
    }
    
    public Element getDefaultInputButton(String card_token) {
        System.out.println("The CardToken Value is"+card_token);
    	return $("input[type='radio'][value='"+card_token+"']");
    }
    
    public Element getDeleteButton(String card_token) {
    	return $("a[href='/payments/delete_payment_method?token="+card_token+"']");
    }
    
    public void addNewCard(Map<String, String> cardData) {
    	add_new_card_btn.waitUntilVisible();
		add_new_card_btn.click();
		enterCardDetails(cardData);
		payment_Button.click();
		waitForLoading();
		add_new_card_btn.waitUntilVisible();
    }
    
    public String deleteCard(String custId,String cardLast4Digit) {
    	String token=BraintreeUtil.getCreditCardToken(custId,cardLast4Digit);		
    	getDeleteButton(token).waitUntilVisible();
		getDeleteButton(token).click();
		return acceptAlert();
    }
    
    public void setDefaultCard(String custId,String cardLast4Digit){
    	String token=BraintreeUtil.getCreditCardToken(custId,cardLast4Digit);
    	getDefaultInputButton(token).select();
		card_change_msg.waitUntilVisible();
    }
    
    
}
