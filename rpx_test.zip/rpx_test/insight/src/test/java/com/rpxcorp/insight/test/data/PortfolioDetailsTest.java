package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.detail.PortfolioDetailPage;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.TableData;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.sql.ResultSet;
import java.util.Map;
@Test(groups = "Portfolio")
@Authenticate(role = "MEMBER")
public class PortfolioDetailsTest extends BaseDataTest {
    PortfolioDetailPage portfolioDetailPage;
    TableData tableData;
    Map<String, String> staticData;
    ResultSet resultSet;

    @Factory(dataProvider = "returnData")
    public PortfolioDetailsTest(String dataDescription, String ptabId) {
        this.dataId = ptabId;
        this.dataDescription = dataDescription;
    }

    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("PortfolioDetail");
    }

    @BeforeClass
    public void loadPage() {
        urlData.put("ID", dataId);
        this.dataUrl = portfolioDetailPage.getDeclaredUrl(urlData);
        to(portfolioDetailPage, urlData);
    }

    @Test(description = "Verify Title", priority = 1)
    public void Title() throws Exception {
        resultSet = sqlProcessor.getResultData("PortfolioDetail.HEADER_DETAILS", dataId);
        assertEquals(portfolioDetailPage.detailPageTitle.getData(), resultSet, "title");
    }

    @Test(description = "Verify Source", priority = 2)
    public void Source() throws Exception {
        assertEquals(portfolioDetailPage.source.getData(), resultSet, "source");
    }

    @Test(description = "Verify Acquisition Date", priority = 3)
    public void Acquisition_Date() throws Exception {
        assertEquals(portfolioDetailPage.acquition_date.getData(), resultSet, "acquisition_date");
    }

    @Test(description = "Fast Facts| Verify document for fast facts", priority = 2)
    public void fastFacts() throws Exception {
    	assertEquals(portfolioDetailPage.getFastFactId(), sqlProcessor.getSinglResultValue("PortfolioDetail.FAST_FACTS", dataId));
    }

    @Test(description = "Verify data in Asset Information Table", priority = 8)
    public void AssetInformation_Family() throws Exception {
        resultSet = sqlProcessor.getResultData("PortfolioDetail.ASSETS_INFO_TABLE", dataId);
        tableData = portfolioDetailPage.assets_Info.getData();
        assertEquals(tableData, resultSet);
    }
    @Test(description = "Assignments| Verify displayed assignments for a portfolio", priority = 11)
    public void assignments() throws Exception {
    	assertEquals(portfolioDetailPage.assignmentsTable.getData(), 
    			 sqlProcessor.getResultData("PortfolioDetail.ASSIGNMENTS", dataId));
    }
}