package com.rpxcorp.insight.module;

import com.rpxcorp.testcore.element.Element;

import java.util.ArrayList;
import java.util.List;

public class MultiSelectCheckBox extends Element {

    public MultiSelectCheckBox(String selector) {
        super(selector);
    }

    public void clickAndSelectCheckbox(String value){
        if (value != null && !value.isEmpty() ) {
            if(!$(".ms-drop.bottom:visible()").isDisplayed()){
                $("div.ms-parent button.ms-choice").click();
                $(".ms-drop.bottom").waitUntilVisible();
            }
            if($("label input[value='"+value+"']").getAttribute("checked") == null)
                $("label input[value='"+value+"']").click();
        }
    }

    public void clickAndSelectMultipleCheckBox(List<String> arraylist){
        for(String value : arraylist){
            clickAndSelectCheckbox(value);
        }

    }
}
