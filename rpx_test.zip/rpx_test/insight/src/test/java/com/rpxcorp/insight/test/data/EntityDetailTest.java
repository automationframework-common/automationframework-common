package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.detail.EntityDetailPage;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.TableData;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.sql.ResultSet;
import java.util.HashMap;
@Test(groups = "Entity")
public class EntityDetailTest extends BaseDataTest {
	@Factory(dataProvider = "returnData")
	public Object[] factoryMethod(String dataDescription, String entityId) {
		return new Object[] { new SubsidiariesTest(dataDescription + " Include Subsidiaries", entityId, true)
				,new SubsidiariesTest(dataDescription + " Exclude Subsidiaries", entityId, false) 
		};
	}

	@DataProvider
	public static Object[][] returnData() throws Exception {
		return getTestData("EntityDetail");
	}
	@Test(groups = "Entity")
	@Authenticate(role = "MEMBER")
	public class SubsidiariesTest extends BaseDataTest {

		EntityDetailPage entityDetailPage;
		TableData litigationTableData, petitionTableData;
		private boolean isInclude = true;
		String subsidiaryList = "";
		HashMap<String, Integer> uiCount = new HashMap<>(), dbCount = new HashMap<>();
		Boolean runOnce = true;

		public SubsidiariesTest(String dataDescription, String entityId, Boolean include) {
			this.dataId = entityId;
			this.dataDescription = dataDescription;
			this.isInclude = include;				
		}

		@BeforeClass
		public void loadPage() throws Exception {
			urlData.put("ID", dataId);
			if (isInclude == false) {
				urlData.put("INCLUDE_SUBSD", "false");
				subsidiaryList = this.dataId;
			} else {
				subsidiaryList = getDataIdasString(
						sqlProcessor.getResultData("EntityDetail.SUBSIDARYLIST", this.dataId));
				subsidiaryList = subsidiaryList.isEmpty() ? this.dataId : subsidiaryList + "," + this.dataId;			
			}
			this.dataUrl = entityDetailPage.getDeclaredUrl(urlData);			
			to(entityDetailPage,urlData);
		}

		@Test(description = "Verify entity name")
		public void Entity_Name() throws Exception {
			assertEquals(entityDetailPage.detailPageTitle.getData(),
					sqlProcessor.getResultData("EntityDetail.ENTITY_NAME", dataId), "name");
		}

		@Test(description = "Verify subsidary list")
		public void SubsidiaryList() throws Exception {
			assertEquals(entityDetailPage.subsidariesList.getData(),
					sqlProcessor.getResultData("EntityDetail.RELATED_ENTITIES_LIST", dataId));
		}

		@Test(description = "Verify Subsidiary Count")
		public void Subsidiary_Count() throws Exception {
			assertEquals(entityDetailPage.subsidariesCount.getIntData(),
					sqlProcessor.getResultCount("EntityDetail.RELATED_ENTITIES_LIST", dataId));
		}

		@Test(description = "Verify Affiliate list")
		public void AffiliateList() throws Exception {
			assertEquals(entityDetailPage.affilatesList.getData(),
					sqlProcessor.getResultData("EntityDetail.AFFILIATES", dataId));
		}

		@Test(description = "Verify Affiliate Count")
		public void Affiliate_Count() throws Exception {
			assertEquals(entityDetailPage.affilatesCount.getIntData(),
					sqlProcessor.getResultCount("EntityDetail.AFFILIATES", dataId));
		}

		@Test(description = "Verify active cases Count")
		public void activeCaseCountInStats() throws Exception {
			if (isInclude)
				assertEquals(entityDetailPage.overview_panel.getData("active"),
						sqlProcessor.getSingleValue(sqlProcessor.getResultData("EntityDetail.OVERVIEW_COUNT", subsidiaryList), "active"));
			else
				assertEquals(entityDetailPage.overview_panel.getData("active"),
						sqlProcessor.getSingleValue(sqlProcessor.getResultData("EntityDetail.OVERVIEW_COUNT_EXC_SUB", dataId), "active"));
		}

		@Test(description = "Verify inactive cases Count")
		public void inactiveCaseCountInStats() throws Exception {
			if (isInclude)
				assertEquals(entityDetailPage.overview_panel.getData("inactive"),
						sqlProcessor.getSingleValue(sqlProcessor.getResultData("EntityDetail.OVERVIEW_COUNT", subsidiaryList), "inactive"));
			else
				assertEquals(entityDetailPage.overview_panel.getData("inactive"),
						sqlProcessor.getSingleValue(sqlProcessor.getResultData("EntityDetail.OVERVIEW_COUNT_EXC_SUB", dataId), "inactive"));
		}

		@Test(description = "Verify patent in litigation count in stats")
		public void patentLitigationCountInStats() throws Exception {
			if (isInclude)
				assertEquals(entityDetailPage.overview_panel.getData("patents_in_litigation")   ,
						sqlProcessor.getResultCount(sqlProcessor.getResultData("EntityDetail.PATENT_ALL", subsidiaryList)));
			else
				assertEquals(entityDetailPage.overview_panel.getData("patents_in_litigation"),
						sqlProcessor.getResultCount(sqlProcessor.getResultData("EntityDetail.PATENT_ALL_EXC_SUB", dataId)));
		}

		@Test(description = "Verify petition count in stats")
		public void petitionCountInStats() throws Exception {
			if (isInclude)
				assertEquals(entityDetailPage.overview_panel.getData("petitions")   ,
						sqlProcessor.getResultCount(sqlProcessor.getResultData("EntityDetail.PTAB_ALL_INC_SUB", subsidiaryList)));
			else
				assertEquals(entityDetailPage.overview_panel.getData("petitions"),
						sqlProcessor.getResultCount(sqlProcessor.getResultData("EntityDetail.PTAB_ALL_EXC_SUB", dataId)));
		}

		@Test(description = "RPX-13143 || Verify related entities count in stats")
		public void relatedEntitiesCountInStats() throws Exception {
				assertEquals(entityDetailPage.overview_panel.getData("related_entities")   ,
						sqlProcessor.getResultCount(sqlProcessor.getResultData("EntityDetail.RELATED_ENTITIES_LIST", dataId)));
		}

		@Test(description = "Verify Patents", dataProvider = "patent", priority = 1)
		public void Patents(String query) throws Exception {
			if (query.toLowerCase().contains("plaintiff")) {
				entityDetailPage.selectPatentPlaintiffTabLink();
				uiCount.put(query, entityDetailPage.patentPlaintiffTabLink.getIntData());
			} else if (query.toLowerCase().contains("defendant")) {
				entityDetailPage.selectPatentDefendantTab();
				uiCount.put(query, entityDetailPage.patentDefendantTabLink.getIntData());
			} else
				uiCount.put(query, entityDetailPage.patentCount.getIntData());

			ResultSet rs = sqlProcessor.getResultData("EntityDetail." + query, dataId);
			dbCount.put(query, sqlProcessor.getResultCount(rs));

			assertEquals(entityDetailPage.patent_table.getData(), rs);
		}

		@Test(description = "Verify Campiagn view", dataProvider = "campaign", priority = 3)
		public void Litigation_campaign_view(String query) throws Exception {
			ResultSet rs = sqlProcessor.getResultData("EntityDetail." + query, subsidiaryList);
			int rsCount=sqlProcessor.getResultCount(rs);
			if(rsCount>0) {
				try {
					entityDetailPage.litigation_table.waitUntilVisible();
					if (query.toLowerCase().contains("_active"))
						entityDetailPage.filterActiveCases();
					else if (query.toLowerCase().contains("_inactive"))
						entityDetailPage.filterInActiveCases();
					else
						entityDetailPage.filterAllCases();

					if (query.toLowerCase().contains("_npe"))
						entityDetailPage.filterNPE();
					else if (query.toLowerCase().contains("_others"))
						entityDetailPage.filterOthers();

					if (query.toLowerCase().contains("plaintiff"))
						entityDetailPage.selectLitPlaintiffTabLink();
					else if (query.toLowerCase().contains("defendant"))
						entityDetailPage.selectLitDefendantTab();
					assertEquals(entityDetailPage.litigation_table.getData(), rs, "campaign_name", "start_date",
							"most_recent_case", "termination_date", "jurisdiction");
				} catch (Exception e){
					System.out.println(e);
				}
			}else {
				assertEquals(sqlProcessor.getResultCount(rs),0);
			}
		}

		@Test(description = "RPX-14563 || Verify 'Defendant Parents' column in Litigations Table as Campiagn view", priority = 2)
		public void Litigations_DefendantParents_in_campaign_view() throws Exception {
			if (isInclude)
				assertEquals(entityDetailPage.litigation_table.getData(),
						sqlProcessor.getResultData("EntityDetail.CAMP_WITH_DEFENDANT_PARENTS_INC_SUB", subsidiaryList),
						"defendant_parents");
			else
				assertEquals(entityDetailPage.litigation_table.getData(),
						sqlProcessor.getResultData("EntityDetail.CAMP_WITH_DEFENDANT_PARENTS_EXC_SUB", subsidiaryList),
						"defendant_parents");

		}

		@Test(description = "Verify Non Campiagn view", dataProvider = "non_campaign", priority = 4)
		public void Litigation_Non_campaign_view(String query) throws Exception {
			ResultSet rs = sqlProcessor.getResultData("EntityDetail." + query, subsidiaryList);
			int rsCount=sqlProcessor.getResultCount(rs);
			if(rsCount>0) {
				try {
					entityDetailPage.litigation_table.waitUntilVisible();
					if(entityDetailPage.litigation_table.isDisplayed()) {
						if (this.runOnce) {
							entityDetailPage.nonCampaignView();
							this.runOnce = false;
						}
						if ( (query.toLowerCase().contains("active")) && !(query.toLowerCase().contains("inactive")) )
							entityDetailPage.filterActiveCases();
						else if (query.toLowerCase().contains("inactive"))
							entityDetailPage.filterInActiveCases();
						else
							entityDetailPage.filterAllCases();

						if (query.toLowerCase().contains("_npe"))
							entityDetailPage.filterNPE();
						else if (query.toLowerCase().contains("_others"))
							entityDetailPage.filterOthers();

						if (query.toLowerCase().contains("plaintiff"))
							entityDetailPage.selectLitPlaintiffTabLink();
						else if (query.toLowerCase().contains("defendant"))
							entityDetailPage.selectLitDefendantTab();
						assertEquals(entityDetailPage.litigation_table.getData(), rs, "start_date", "case_name", "termination_date",
								"jurisdiction");
					}
				} catch (Exception e){
					System.out.println(e);
				}
			}else{
				assertEquals(sqlProcessor.getResultCount(rs),0);
			}
		}

		@Test(description = "Verify Petition ", dataProvider = "petition", priority = 5)
		public void PetitionerTable(String filter, String query) throws Exception {
			ResultSet rs = sqlProcessor.getResultData("EntityDetail." + query, subsidiaryList);
			int rsCount=sqlProcessor.getResultCount(rs);
			if(rsCount>0) {
				try {
			entityDetailPage.selectPartyTypeValues(filter);
			petitionTableData = (TableData) entityDetailPage.petition_table.getData();
			assertEquals(petitionTableData,rs, "patent_number", "case_number", "institution_decision_date");
				} catch (Exception e){
					System.out.println(e);
				}
			}else{
				assertEquals(sqlProcessor.getResultCount(rs),0);
			}
		}

		@Test(description = "Verify Petition ", dataProvider = "petitionTabs", priority = 6)
		public void PetitionerTable_tabs(String filter, String query) throws Exception {
			ResultSet rs = sqlProcessor.getResultData("EntityDetail." + query, subsidiaryList);
			int rsCount=sqlProcessor.getResultCount(rs);
			if(rsCount>0) {
				try {
			entityDetailPage.selectPartyTypeValues(filter);
			if (query.toLowerCase().contains("parties"))
				entityDetailPage.selectPartiesTab();
			else if (query.toLowerCase().contains("_patent_"))
				entityDetailPage.selectPatentsTab();
			assertEquals(entityDetailPage.partiesNPatentTable.getSubtableData(),rs);
				} catch (Exception e){
					System.out.println(e);
				}
			}else{
				assertEquals(sqlProcessor.getResultCount(rs),0);
			}
		}

		@Test(description = "Verify Petition ", dataProvider = "petitionTabs", priority = 6)
		public void petitionCountPartiesPatentTab(String filter, String query) throws Exception {
			entityDetailPage.selectPartyTypeValues(filter);

			if (query.toLowerCase().contains("parties"))
				entityDetailPage.selectPartiesTab();
			else if (query.toLowerCase().contains("_patent_"))
				entityDetailPage.selectPatentsTab();
		}

		@DataProvider
		public Object[][] campaign() {
			if (isInclude)
				return new String[][] { { "CAMP_ALL_CASES" }, { "CAMP_ACTIVE_CASES" }, { "CAMP_INACTIVE_CASES" },
						{ "CAMP_PLAINTIFF_CASES" }, { "CAMP_ACTIVE_PLAINTIFF_CASES" }, { "CAMP_INACTIVE_PLAINTIFF_CASES" },
						{ "CAMP_DEFENDANT_CASES" }, { "CAMP_ACTIVE_DEFENDANT_CASES" }, { "CAMP_INACTIVE_DEFENDANT_CASES" },
					    { "CAMP_ALL_CASES_NPE" }, { "CAMP_ACTIVE_CASES_NPE" }, { "CAMP_INACTIVE_CASES_NPE" },
						{ "CAMP_PLAINTIFF_CASES_NPE" },{ "CAMP_ACTIVE_PLAINTIFF_CASES_NPE" },{ "CAMP_INACTIVE_PLAINTIFF_CASES_NPE" },
						{ "CAMP_DEFENDANT_CASES_NPE" },{ "CAMP_ACTIVE_DEFENDANT_CASES_NPE" },{ "CAMP_INACTIVE_DEFENDANT_CASES_NPE" },
						{ "CAMP_ALL_CASES_OTHERS" }, { "CAMP_ACTIVE_CASES_OTHERS" }, { "CAMP_INACTIVE_CASES_OTHERS" },
						{ "CAMP_PLAINTIFF_CASES_OTHERS" },{ "CAMP_ACTIVE_PLAINTIFF_CASES_OTHERS" },{ "CAMP_INACTIVE_PLAINTIFF_CASES_OTHERS" },
						{ "CAMP_DEFENDANT_CASES_OTHERS" },{ "CAMP_ACTIVE_DEFENDANT_CASES_OTHERS" },{ "CAMP_INACTIVE_DEFENDANT_CASES_OTHERS" } };
			else
				return new String[][] { { "CAMP_ALL_CASES_EXC_SUB" }, { "CAMP_PLAINTIFF_CASES_EXC_SUB" },
					{ "CAMP_DEFENDANT_CASES_EXC_SUB" }, { "CAMP_ACTIVE_CASES_EXC_SUB" },
					{ "CAMP_ACTIVE_PLAINTIFF_CASES_EXC_SUB" }, { "CAMP_ACTIVE_DEFENDANT_CASES_EXC_SUB" },
					{ "CAMP_INACTIVE_CASES_EXC_SUB" }, { "CAMP_INACTIVE_PLAINTIFF_CASES_EXC_SUB" },
					{ "CAMP_INACTIVE_DEFENDANT_CASES_EXC_SUB" }, { "CAMP_ALL_CASES_NPE_EXC_SUB" },
					{ "CAMP_ALL_CASES_OTHERS_EXC_SUB" }, { "CAMP_ACTIVE_CASES_NPE_EXC_SUB" },
					{ "CAMP_ACTIVE_CASES_OTHERS_EXC_SUB" }, { "CAMP_INACTIVE_CASES_NPE_EXC_SUB" },
					{ "CAMP_INACTIVE_CASES_OTHERS_EXC_SUB" } };
		}

		@Test(description = "Verify Cases by Market Sector section", priority = 6)
		public void Verfiy_Cases_By_Market_Sector() throws Exception {
			if (isInclude)
				assertEquals(entityDetailPage.cases_By_Market_Sector.getData(),
						sqlProcessor.getResultData("EntityDetail.CASES_BY_MARKET_SECTOR_INC_SUB", dataId));
			else
				assertEquals(entityDetailPage.cases_By_Market_Sector.getData(),
						sqlProcessor.getResultData("EntityDetail.CASES_BY_MARKET_SECTOR_EXC_SUB", dataId));

		}

		@Test(description = "Verify Count", priority = 7)
		public void verify_count() throws Exception {
			assertEquals(uiCount, dbCount);
		}

		@DataProvider
		public Object[][] non_campaign() {
			if (isInclude)
				return new String[][] { { "ALL_CASES" }, { "ACTIVE_CASES" }, { "INACTIVE_CASES" },
						{ "PLAINTIFF_CASES" }, { "ACTIVE_PLAINTIFF_CASES" }, { "INACTIVE_PLAINTIFF_CASES" },
						{ "DEFENDANT_CASES" }, { "ACTIVE_DEFENDANT_CASES" }, { "INACTIVE_DEFENDANT_CASES" },
						{ "ALL_CASES_NPE" }, { "ACTIVE_CASES_NPE" },  { "INACTIVE_CASES_NPE" },
						{ "ALL_CASES_OTHERS" }, { "ACTIVE_CASES_OTHERS" }, { "INACTIVE_CASES_OTHERS" } };
			else
				return new String[][] { { "ALL_CASES_EXC_SUB" }, { "ACTIVE_CASES_EXC_SUB" }, { "INACTIVE_CASES_EXC_SUB" },
						{ "PLAINTIFF_CASES_EXC_SUB" }, { "ACTIVE_PLAINTIFF_CASES_EXC_SUB" }, { "INACTIVE_PLAINTIFF_CASES_EXC_SUB" },
						{ "DEFENDANT_CASES_EXC_SUB" }, { "ACTIVE_DEFENDANT_CASES_EXC_SUB" }, { "INACTIVE_DEFENDANT_CASES_EXC_SUB" },
						{ "ALL_CASES_NPE_EXC_SUB" }, { "ACTIVE_CASES_NPE_EXC_SUB" },  { "INACTIVE_CASES_NPE_EXC_SUB" },
						{ "ALL_CASES_OTHERS_EXC_SUB" }, { "ACTIVE_CASES_OTHERS_EXC_SUB" }, { "INACTIVE_CASES_OTHERS_EXC_SUB" } };
		}

		@DataProvider
		public Object[][] patent() {
			if (isInclude)
				return new String[][] { { "PATENT_ALL" }, { "PATENT_PLAINTIFF" }, { "PATENT_DEFENDANT" } };
			else
				return new String[][] { { "PATENT_ALL_EXC_SUB" }, { "PATENT_PLAINTIFF_EXC_SUB" },
					{ "PATENT_DEFENDANT_EXC_SUB" } };

		}

		@DataProvider
		public Object[][] petition() {
			if (isInclude)
				return new String[][] { { "All", "PTAB_ALL_INC_SUB" }, { "Patent Owner", "PTAB_PATENTOWNER_INC_SUB" }, { "Petitioner", "PTAB_PETITIONER_INC_SUB" }, { "Privy", "PTAB_PRIVY_INC_SUB" }, { "Real Party in Interest", "PTAB_REALPARTY_INC_SUB" } };
			else
				return new String[][] { { "All", "PTAB_ALL_EXC_SUB" }, { "Patent Owner", "PTAB_PATENTOWNER_EXC_SUB" }, { "Petitioner", "PTAB_PETITIONER_EXC_SUB" }, { "Privy", "PTAB_PRIVY_EXC_SUB" }, { "Real Party in Interest", "PTAB_REALPARTY_EXC_SUB" } };
		}

		@DataProvider
		public Object[][] petitionTabs() {
			if (isInclude)
				return new String[][] { { "Patent Owner", "PTAB_PARTIES_PATENTOWNER_INC_SUB" }, { "Petitioner", "PTAB_PARTIES_PETITIONERS_INC_SUB" }, { "Privy", "PTAB_PARTIES_PRIVY_INC_SUB" },
					{ "Real Party in Interest", "PTAB_PARTIES_REALPARTY_INC_SUB" }, { "All", "PTAB_PARTIES_ALL_INC_SUB" }, { "Petitioner", "PTAB_PATENT_PETITIONERS_INC_SUB" }, { "Patent Owner", "PTAB_PATENT_PATENTOWNER_INC_SUB" },
					{ "Privy", "PTAB_PATENT_PRIVY_INC_SUB" }, { "Real Party in Interest", "PTAB_PATENT_REALPARTY_INC_SUB" }, { "All", "PTAB_PATENT_ALL_INC_SUB" }};
			else
				return new String[][] { { "Patent Owner", "PTAB_PARTIES_PATENTOWNER_EXC_SUB" }, { "Petitioner", "PTAB_PARTIES_PETITIONERS_EXC_SUB" }, { "Privy", "PTAB_PARTIES_PRIVY_EXC_SUB" },
					{ "Real Party in Interest", "PTAB_PARTIES_REALPARTY_EXC_SUB" }, { "All", "PTAB_PARTIES_All_EXC_SUB" }, { "Petitioner", "PTAB_PATENT_PETITIONERS_EXC_SUB" }, { "Patent Owner", "PTAB_PATENT_PATENTOWNER_EXC_SUB" },
					{ "Privy", "PTAB_PATENT_PRIVY_EXC_SUB" }, { "Real Party in Interest", "PTAB_PATENT_REALPARTY_EXC_SUB" }, { "All", "PTAB_PATENT_ALL_EXC_SUB" } };
		}

		// @Test(description="Verify Recent Activities",priority =7)
		public void Recent_Activity() throws Exception {
			if (isInclude)
				assertEquals(entityDetailPage.recentActivity.getData(),
						sqlProcessor.getResultData("EntityDetail.RECENT_ACTIVITY_INC_SUB", dataId));
			else
				assertEquals(entityDetailPage.recentActivity.getData(),
						sqlProcessor.getResultData("EntityDetail.RECENT_ACTIVITY_EXC_SUB", dataId));

		}
	}
}