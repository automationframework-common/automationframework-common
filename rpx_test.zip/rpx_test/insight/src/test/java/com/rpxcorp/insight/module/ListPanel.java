package com.rpxcorp.insight.module;

import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;

import com.rpxcorp.testcore.element.Element;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class ListPanel extends Element {
	private String dataKey;
	Element viewAllLink;
	Element viewLessLink;
	Element link;
	Element displayedRecords;

	public ListPanel(By locator) {
		super(locator);
	}

	public ListPanel(String selector) {
		super(selector);
	}

	public void dataKey(String dataKey){
		this.dataKey=dataKey;
	}

	public void viewAllLink(By by) {
		this.viewAllLink = new Element(by);
	}

	public void viewLessLink(By by) {
		this.viewLessLink = new Element(by);
	}

	public void viewAllLink(String selector) {
		this.viewAllLink = new Element(selector);
	}

	public void viewLessLink(String selector) {
		this.viewLessLink = new Element(selector);
	}
	public void link(String selector) {
		this.link = new Element(selector);
	}

	public Element link() {
		return this.link;
	}

	public Element viewAllLink() {
		return this.viewAllLink;
	}

	public Element viewLessLink() {
		return this.viewLessLink;
	}

	public ArrayList<String> getData() {
		if (viewAllLink != null) {
			if (viewAllLink.isDisplayed()) {
				viewAllLink.click();
				new Element(By.cssSelector(".blockUI.blockOverlay")).waitUntilInvisible();
				new Element(By.cssSelector(".blockUI.blockMsg.blockElement>img")).waitUntilNoElementPresent();
			}
		}
		ArrayList<String> listData = new ArrayList<String>();
		if (isPresent()) {
			Document doc = Jsoup.parse(getInnerHtml());
			if (dataKey==null)
				dataKey="li>a";
			Elements lists = doc.select(dataKey.trim());
			for (org.jsoup.nodes.Element list : lists) {
				listData.add(list.text());
			}
		}
		return listData;
	}

	public Element displayedRecords() {
		return displayedRecords;
	}

	public void displayedRecords(String selector) {
		this.displayedRecords = new Element(selector);
	}   

//	public void viewAll() {
//		if (viewAllLink.isDisplayed()) {
//			viewAllLink.click();
//			viewLessLink.waitUntilVisible();
//		}
//	}

//	public void viewLess() {
//		if (viewLessLink.isDisplayed()) {
//			viewLessLink.click();
//			viewAllLink.waitUntilVisible();
//		}
//	}

	public void viewLess() {
		if (viewLessLink.isDisplayed()) {
			viewLessLink.click();
			waitForRequestInit();
			if (viewAllLink != null)
				getWait().until(ExpectedConditions.elementToBeClickable(viewAllLink));
		}
	}

	public void viewAll() {
		if (viewAllLink != null) {
			if (viewAllLink.isDisplayed()) {
				viewAllLink.click();
				waitForRequestInit();
				if (viewLessLink != null)
					getWait().until(ExpectedConditions.elementToBeClickable(viewLessLink));
				//viewLesslink.waitUntilVisible();
			}
		}
	}


}
