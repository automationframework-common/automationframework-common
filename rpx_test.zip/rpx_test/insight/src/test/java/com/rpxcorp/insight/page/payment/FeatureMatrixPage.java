package com.rpxcorp.insight.page.payment;

import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author gandhimathia
 *
 */
public class FeatureMatrixPage extends BasePage {

    public FeatureMatrixPage() {
        this.url = new PageUrl("payments/options");
    }

    @Override
    public boolean at() {       
        matrixTable.waitUntilVisible();
        return false;
    }

    public final Element matrixTable = $(".payments_matrix");
    public final Element options = $(".pricing-table.labels li:not(.title):not(.price)");

    public final Element basicSubscribe = $("#content a:contains(Get started)"); //Basic Signup

    public final Element basicUpgrade = $(By.xpath("//li[contains(text(),'Basic')]/../li//a[contains(@class,'disabled')][text()='Upgrade']"));
    public final Element plusSubscribe = $(By.xpath("//li[contains(text(),'Plus')]/../li/a[contains(@class,'button text-transform')][text()='Free Trial']"));
    public final Element plusUpgrade = $(By.xpath("//li[contains(text(),'Plus')]/../li//a[contains(@class,'disabled')][text()='Upgrade']"));

    public final Element anonymousprimeSubscribe =$(".links>a[data-plan=prime]:contains(Free 14 Day Trial)");
    public final Element primeFreeTrial = $(".links a[data-plan-token=prime_infinite]:contains(Free Trial)");
    public final Element primeUpgrade = $("ul.pricing-table.prime li a:contains('Upgrade')");

    public final Element primeContactUs = $("li:contains('Prime')~li>a:contains('Contact Us')[href='mailto:insight@rpxcorp.com?subject=RPX Insight Upgrade - Prime Account']");
    public final Element primeUpgradeEnabled = $("ul.inline-list ul li.upgrade-btn a");
    public final Element primeCurrentSubscription = $(".links a:contains(Current Subscription)");//$(By.xpath("//li[contains(text(), 'Prime')][@class='title']/..//a[text()='Current Subscription'][contains(@class, 'disabled')]"));

    public final Element eliteContactUs = $(".links a:contains('Contact Us')[href='mailto:insight@rpxcorp.com?subject=RPX Insight Upgrade - Elite Account']");
    public final Element eliteCurrentSubscription = $(".links a:contains(Current Subscription)");
    
    public final Element memberContactUs = $(
            ".links a:contains('Contact Us')[href='mailto:insight@rpxcorp.com?subject=RPX Insight Upgrade - Member Account']");
    public final Element memberCurrentSubscription = $(".links a:contains(Current Subscription)");


    public final Element pageData = $(By.xpath("//ul[@class='pricing-table labels']//li"));
    public final Element Data = $(By.xpath("//ul[@class='pricing-table labels']//li[3]"));
    public final Element help = $(".panel>h5");

    public final StaticContent paymentMatrix = $(".payments_matrix", (Configure<StaticContent>) dataForm ->
        {
            dataForm.content("doc_credit_basic", "ul:nth-of-type(2) li:not(.price):contains($)");
            dataForm.content("doc_credit_plus", "ul:nth-of-type(4) li:not(.price):contains($)");
            dataForm.content("doc_credit_prime", "ul:nth-of-type(6) li:not(.price):contains($)");
            dataForm.content("doc_credit_elite", "ul:nth-of-type(8) li:not(.price):contains($)");
        }
    );
    public final Table featureMatrixTable=$(".payments_matrix",(Configure<Table>) table -> {
            table.column("feature","ul.labels li.bullet-item");
            table.column("basic","ul.basic li.bullet-item |i.icon-checkmark?YES:text()");
            table.column("plus","ul.plus li.bullet-item|i.icon-checkmark?YES:text()");
            table.column("prime","ul.prime li.bullet-item|i.icon-checkmark?YES:text()");
            table.column("elite","ul.elite li.bullet-item|i.icon-checkmark?YES:text()");
            table.column("member","ul.member li.bullet-item|i.icon-checkmark?YES:text()");
    });

    //Upgradation subscription Model
    public final Element changeSubscriptionButton = $("li.cta-button>a[data-reveal-id='swap_subscription_modal']");
    public final Element changeSubsciptionModal = $("div#swap_subscription_modal");
    public final Element changeSubsciptionTerms = $("div#swap_subscription_modal .modal-content>p:nth-of-type(2)");
    public final Element confirmChangeSubscriptionBtn = $("form>input[value='Confirm Change']");
    public final Element changesubscriptionTerm1InModal = $("div#swap_subscription_modal .modal-content>p:nth-of-type(1)");
    public final Element changesubscriptionTerm2InModal = $("div#swap_subscription_modal .modal-content>p:nth-of-type(2)");

    //new payment method
    public Map<String, String> getCancellationTermsForTrialUser() {
        Map<String, String> upgradationTerms = new HashMap<String, String>();

        openChangeSubscriptionModal();
        upgradationTerms.put("term_1", changesubscriptionTerm1InModal.getText());
        upgradationTerms.put("term_2", changesubscriptionTerm2InModal.getText());
        return upgradationTerms;
    }

    public final Element loginlink = $("#signup-modal a:contains('Login here')");
    public final Element user_email_TextBox = $("#user_email[required='required']:visible()");
    public final Element password_TextBox = $(By.id("user_password"));
    public final Element login_btn = $("input[value*='Login']");
    public void loginwithoutExpanding(String username, String password) {
        user_email_TextBox.waitUntilVisible();
    	user_email_TextBox.sendKeys(username);
        password_TextBox.sendKeys(password);
        login_btn.click();
    }

    public final Element userUpgradeForm = $("form#user_upgrade_form");
    public final Element upgradeFirstName = $("form#user_upgrade_form input#user_first_name");
    public final Element upgradeLastName = $("form#user_upgrade_form input#user_last_name");
    public final Element upgradeCompany = $("form#user_upgrade_form input#user_extended_user_detail_attributes_company");
    public final Element upgradeUpdateBtn = $("button#signup-btn");

    public void userUpgradeFormPersonalInfoUpdate(String firstName , String lastName , String comName){
        //if(userUpgradeForm.isDisplayed()){
            userUpgradeForm.waitUntilVisible();
            upgradeFirstName.sendKeys(firstName);
            upgradeLastName.sendKeys(lastName);
            upgradeCompany.sendKeys(comName);
            userUpgradeFormClickUpdateNow();
        //}
    }

    public void userUpgradeFormClickUpdateNow(){
        userUpgradeForm.waitUntilVisible();
        upgradeUpdateBtn.click();
        userUpgradeForm.waitUntilInvisible();
    }

    public void openChangeSubscriptionModal() {
        if(!changeSubsciptionModal.isDisplayed()) {
            changeSubscriptionButton.click();
            changeSubsciptionModal.waitUntilVisible();
        }
    }

    //new payment Method
    public void acceptTermsAndChangeSubscription() {
        openChangeSubscriptionModal();
        confirmChangeSubscriptionBtn.click();
        changeSubsciptionModal.waitUntilInvisible();
    }

    public Map<String, String> getUpgradationTermsForUser() {
        Map<String, String> upgradationTerms = new HashMap<String, String>();

        openChangeSubscriptionModal();
        upgradationTerms.put("term_1", changesubscriptionTerm1InModal.getText());
        upgradationTerms.put("term_2", changesubscriptionTerm2InModal.getText());
        return upgradationTerms;
    }

    public Map<String, String> getDowngradationTermsForUser() {
        Map<String, String>  downngradeTerms = new HashMap<String, String>();

        openChangeSubscriptionModal();
        downngradeTerms.put("term_1", changesubscriptionTerm1InModal.getText());
        return downngradeTerms;
    }

//    public void continueSubscription() {
//        openChangeSubscriptionModal();
//        continueSubscriptionBtn.click();
//        cancelFreeTrialModal.waitUntilInvisible();
//    }



    //new payment method
    public void clickOnSubscribeButtonnew(String role) throws Exception{
        String subscribeButton = String.format(".payments_matrix *[data-plan='%s']", role.toLowerCase());
        Thread.sleep(2000);
        $(subscribeButton).waitUntilClickable();
        $(subscribeButton).click();
    }

    public String getPrice(String role) {
        String priceValue = String.format("//li[contains(text(),'%s')]/../li[@class='price']", role);
        return $(By.xpath(priceValue)).getText().replaceFirst("/month", "").trim();
    }


    ////li[contains(text(),'%s')]/../li//input[@class='button']
    public void clickOnUpgradeButton(String role) {
        String subscribeButton = String.format("li.cta-button>a[data-plan-token='%s"+"_monthly']", role.toLowerCase());
        $(subscribeButton).waitUntilVisible();
        $(subscribeButton).click();
        //$(By.xpath(subscribeButton)).click();
    }


    //new payment method //li.cta-button>form>input[data-plan='%s']
    public void clickOnUpgradeButtonnew(String role) throws Exception{
        Thread.sleep(2000);
        String subscribeButton = String.format(".payments_matrix a[data-plan-token='%s"+"_infinite']", role.toLowerCase());
        $(subscribeButton).waitUntilVisible();
        $(subscribeButton).click();
    }


    public Map<String, String> getMatrixData(String role) {
        Map<String, String> matrixElement = new HashMap<String, String>();
        // List<WebElement>
        // elem=getDriver().findElements(By.xpath("//li[(text()='"+role+"')]/following-sibling::li"));
        int columnIndex = 0;
        switch (role) {
        case "Basic":
            columnIndex = 2;
            break;
        case "Plus":
            columnIndex = 4;
            break;
        case "Prime":
            columnIndex = 6;
            break;
        case "Elite":
            columnIndex = 8;
            break;
        case "Member":
            columnIndex = 10;
            break;
        }
        List<WebElement> elem = getDriver().findElements(By.cssSelector(".payments_matrix ul.pricing-table:nth-of-type("
                + columnIndex + ") li:not([class='featured_button'])"));
        matrixElement.put("Role", role);
        String data;
        for (int elemIndex = 3; elemIndex < 20; elemIndex++) {
            try {
                elem.get(elemIndex).findElement(By.tagName("i")).getText();
                data = "Yes";
            } catch (Exception e) {
                data = "No";
            }
            matrixElement.put(pageData.getElements().get(elemIndex).getText().trim()
                    .replaceAll("[^\\u0009\\u000a\\u000d\\u0020-\\uD7FF\\uE000-\\uFFFD]", ""), data);
        }
        return matrixElement;
    }

    // DOCUMENT PURCHASE
    public final Element docPurchaseBtn = $("div[class='purchase_button'] a");

    @SuppressWarnings("deprecation")
	public String getToolTipHeaders(String feature) {
        Actions action = new Actions(getDriver());
        String tooltipHeader;
        $("div.payments_matrix td>span:contains('" + feature + "')").moveTo();
        action.pause(2000).build().perform();
         tooltipHeader = $("span.tooltip h5:visible()").getText();
//        String tooltip = getDriver()
//                .findElement(
//                        By.xpath("//ul[@class='pricing-table labels']//li/span[contains(text(),'" + feature + "')]"))
//                .getAttribute("data-selector");
//        String[] tooltipText = getDriver().findElement(By.xpath("//span[@id='" + tooltip + "']")).getText().split("\n");
//        tooltipHeader = tooltipText[0].trim().replaceAll("[^\\u0009\\u000a\\u000d\\u0020-\\uD7FF\\uE000-\\uFFFD]", "");
//        action.release(getDriver().findElement(
//                By.cssSelector("div.payments_matrix td>span:contains('\" + feature + \"')]"))).build()
//                .perform();
        return tooltipHeader;
    }

    public List<String> timelineData() {
        List<String> timelineData = new ArrayList<String>();
        timelineData.add("Choose Account");
        timelineData.add("Create Account");
        timelineData.add("Add Payment");
        timelineData.add("Confirm Account");
        return timelineData;
    }

    public final Element timeline_bar = $(".progress.small-centered.columns.small-6.round");
    // FAQ's Section
    public final Element faqSection = $("div.content-faq");
    public final Element faq1 = $("#FAQ1");
    public final Element faq2 = $("#FAQ2");
    public final Element faq3 = $("#FAQ3");
    public final Element faq4 = $("#FAQ4");
    public final Element faq5 = $("#FAQ5");
    public final Element faq6 = $("#FAQ6");

    public final Element faq = $("div.content-faq p>a");

    public boolean checkAnnualSubscriptionAndMonthlyCredit(String role,String expectedValue) {
    	String subscriptionXpath=String.format("//li[contains(text(),'%s')]/..//li[contains(text(),'%s')]",role,expectedValue);
    	return $(By.xpath(subscriptionXpath)).isDisplayed();
    }
    
    public final Element contactUs_Lnk=$(By.xpath("//div[@class='insight-contact-us' and contains(text(),'For any')]/a[@href='mailto:insight@rpxcorp.com?subject=RPX Insight Subscription Question']"));
    public final Element title=$("div.subscription-title");
    
    // SIGN UP FORM
    public final Element createAccountTitle = $("#signup-modal h1");
    public final Element first_name = $("#user_first_name");
    public final Element last_name = $("#user_last_name");
    public final Element email_id = $("#user_email");
    public final Element comp_name = $("#signup_form input[id*='_company']");
    public final Element password = $("#user_password");
    public final Element confirm_password = $("#user_password_confirmation");
    public final Element continue_Button = $("form#signup_form #signup-btn span");
    
	public void submitSignUpForm(HashMap<String, String> userData) {
		createAccountTitle.waitUntilVisible();
		first_name.sendKeys(userData.get("first_name"));
		last_name.sendKeys(userData.get("last_name"));
		email_id.sendKeys(userData.get("mail_id"));
		password.sendKeys(userData.get("password"));
        comp_name.sendKeys(userData.get("company"));
		confirm_password.sendKeys(userData.get("cnf_password"));
		continue_Button.click();
	}
    
}
