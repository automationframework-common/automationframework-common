package com.rpxcorp.insight.page.error_page;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class NewsMemberAcessPage extends BasePage {

    @Override
    public boolean at() {
        News_promo_text.waitUntilVisible();
        newsArticles_promo_msg.waitUntilVisible();
        return News_promo_text.waitUntilTextPresent("RPX members only");//("Members Access");
    }

    public final Element newsArticles_promo_msg = $("div.anonymous-upgrade-block:contains('Access to the full article is currently available to RPX members only. Please')>a");

}
