package com.rpxcorp.insight.page.advance_search;

import com.rpxcorp.insight.module.AutoComplete;
import com.rpxcorp.insight.module.DatePicker;
import com.rpxcorp.testcore.element.Element;

import java.util.Map;

public class LitigationAdvanceSearchPage extends AdvanceSearchPage {

    @Override
    public boolean at() {
        return partyName.waitUntilVisible();
    }

    public final Element patentLitigation = $("a.litigation_link");
    public final Element partyName = $("#all_parties");
    public final Element partyNameAutoCompleteText = $(".ui-menu-item a");
    public final Element attorneyName = $("#all_attorneys");
    public final Element lawFirmName = $("#all_lawfirms");
    public final Element judgeName=$("form#litigations_search_form input#judge");
    public final Element all_parties_judgename = $("div.section:has(.section-heading:contains('All Parties')) li>label:contains('Judge Name')+input"); // for role auth

    //plaintiff/patent owner
    public final Element plaintiffName = $("#plaintiff");
    public final Element plaintiffAttorneyName = $("#plaintiff_attorney");
    public final Element plaintiffLawFirmName = $("#plaintiff_lawfirm");

    //Defendent/Petitioner
    public final Element defendantName = $("#defendant");
    public final Element defendantAttorneyName = $("#defendant_attorney");
    public final Element defendantLawFirmName = $("#defendant_lawfirm");
    public final Element currentSearchSection = $("#searchq_revised");
    public final Element resultCount = $(".count");
    public final Element submitButton = $(".active input[name='commit']");
    public final Element priorArtIcon=$("i.prior_art_icon");
    public final Element plaintiff_Outcome=$("#plaintiff_outcome");//>optgroup
    public final Element defendant_Outcome=$("#defendant_outcome");//>optgroup
    public final Element partyOutcome_TooltipMsg=$("span.tooltip[style*='display: block']");
    public final Element plaintiffTerminationDate_Label=$(".termination-date>label:contains('Plaintiff Termination date')");
    public final DatePicker plaintiffTermination_FromDate=$("#from_plaintiff_termination_date",DatePicker.class);
    public final DatePicker plaintiffTermination_ToDate=$("#to_plaintiff_termination_date",DatePicker.class);
    public final Element defendantTerminationDate_Label=$(".termination-date>label:contains('Defendant Termination date')");
    public final DatePicker defendantTermination_FromDate=$("#from_defendant_termination_date",DatePicker.class);
    public final DatePicker defendantTermination_ToDate=$("#to_defendant_termination_date",DatePicker.class);
    public final Element case_Status_Dropdown=$("#case_status_detail");
    public final Element litigationCaseType= $("#s2id_case_type");

    //Case Details
    public final Element docketDescription = $("#docket_text");
    public final Element accusedProduct = $("#accused_product");
    public final AutoComplete patentInSuit = $("#patent_number", AutoComplete.class);
    public final Element caseDetails_marketSector = $("select#market_sector_id");
    public final Element caseDetails_marketSector_All = $("select#market_sector_id>option");
    public final Element caseDetails_litCaseType = $("select#case_type");
    public final Element caseDetails_litCaseType_All = $("select#case_type>option");
    public final Element jurisdiction = $("select#juridiction_state_court");//jurisdiction_type_details
    public final Element Jurisdiction_input = $("input#s2id_autogen5");
    public final Element jurisdiction_District_All = $("select#jurisdiction_type_details>optgroup[label='District Court']>option");
    public final Element jurisdiction_PTAB_All = $("select#jurisdiction_type_details>optgroup[label='PTAB']>option");
    public final Element jurisdiction_ITC_All = $("select#jurisdiction_type_details>optgroup[label='ITC']>option");
    public final Element jurisdiction_FED_All = $("select#jurisdiction_type_details>optgroup[label='Federal Circuit']>option");
    //public final Element federal_circuit = $(".cafc_options_container label:contains('Appealed in Federal Circuit')");
    public final Element case_filed_date = $("div.section:has(.section-heading:contains('Case Details')) li>label:contains('Filed Date')");


    public void moveToPartyOutcomeTooltipTag(String partyOutcomeName) {
    	$("label:contains('"+partyOutcomeName+"') span").moveTo();
    	partyOutcome_TooltipMsg.waitUntilVisible();
    }

    public void search(Map<String, String> data) throws Exception {
        partyName.sendKeys(data.get("Party Name"));
        attorneyName.sendKeys(data.get("Attorney Name"));
        lawFirmName.sendKeys(data.get("Law Firm Name"));
        judgeName.sendKeys(data.get("Judge Name"));
        plaintiffName.sendKeys(data.get("Plaintiff Name"));
        plaintiffAttorneyName.sendKeys(data.get("Plaintiff Attorney Name"));
        plaintiffLawFirmName.sendKeys(data.get("Plaintiff Law Firm Name"));
        defendantName.sendKeys(data.get("Defendant Name"));
        defendantAttorneyName.sendKeys(data.get("Defendant Attorney Name"));
        defendantLawFirmName.sendKeys(data.get("Defendant Law Firm Name"));
        docketDescription.sendKeys(data.get("Docket Description"));
        accusedProduct.sendKeys(data.get("Accused Product"));
        patentInSuit.sendKeys(data.get("Patent In Suite"));
        case_Status_Dropdown.selectByOption(data.get("Case Status"));
        plaintiff_Outcome.selectByOption(data.get("Plaintiff Outcome"));
        defendant_Outcome.selectByOption(data.get("Defendant Outcome"));
        plaintiffTermination_FromDate.selectDate(data.get("PlaintiffOutcomeTermination_FromDate"));
        plaintiffTermination_ToDate.selectDate(data.get("PlaintiffOutcomeTermination_ToDate"));
        defendantTermination_FromDate.selectDate(data.get("DefendantOutcomeTermination_FromDate"));
        defendantTermination_ToDate.selectDate(data.get("DefendantOutcomeTermination_ToDate"));
        if (data.get("Jurisdiction") != null && (data.get("Jurisdiction").isEmpty())) {
            Jurisdiction_input.sendKeys(data.get("Jurisdiction").trim());
        }else {
            jurisdiction.selectByOption(data.get("Jurisdiction"));
        }
        submitButton.click();
        waitForLoading();
    }

}
