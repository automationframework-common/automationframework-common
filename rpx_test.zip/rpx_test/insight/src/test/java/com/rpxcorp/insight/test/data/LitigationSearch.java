package com.rpxcorp.insight.test.data;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rpxcorp.insight.page.search.LitigationSearchPage;
@Authenticate(role = "MEMBER")
public class LitigationSearch extends BaseDataTest {

    LitigationSearchPage litigationSearchPage;
    String searchText = "";
    Map<String, String> staticData;
    ResultSet resultSet;

    @BeforeClass
    public void loadPage() {
        this.urlData.put("CURRENT SEARCH", searchText);
        this.dataUrl = litigationSearchPage.getDeclaredUrl(urlData);
        to(litigationSearchPage, urlData);
    }

    @Test(description = "Verify the count of NPE Litigations on NPE set as true", priority = 1)
    public void isNPE_True_Count() throws Exception {
        litigationSearchPage.enter_searchtext("is_npe:true");
        litigationSearchPage.switch_ungrouped_view();
        assertEquals(litigationSearchPage.no_group_patent_lit_count.getIntData(),
                sqlProcessor.getResultCount("LitigationSearch.ISNPE_TRUE_COUNT"));
    }

    @Test(description = "Verify the Litigations after is_NPE set as True", priority = 2)
    public void isNPE_True() throws Exception {
        List<String> ids = litigationSearchPage.search_result.getUniqueId_Values();
        assertEquals(litigationSearchPage.search_result.getData(),
                sqlProcessor.getResultData("LitigationSearch.ISNPE_TRUE_VALUES", ids), "case_name");
    }

    @Test(description = "Verify the count of non NPE Litigations on NPE set as true", priority = 3)
    public void isNPE_False_Count() throws Exception {
        litigationSearchPage.enter_searchtext("is_npe:false");
        litigationSearchPage.switch_ungrouped_view();
        assertEquals(litigationSearchPage.no_group_patent_lit_count.getIntData(),
                sqlProcessor.getResultCount("LitigationSearch.ISNPE_FALSE_COUNT"));
    }

    @Test(description = "Verify the Litigations after is_NPE set as false", priority = 4)
    public void isNPE_False() throws Exception {
        List<String> ids = litigationSearchPage.search_result.getUniqueId_Values();
        assertEquals(litigationSearchPage.search_result.getData(),
                sqlProcessor.getResultData("LitigationSearch.ISNPE_FALSE_VALUES", ids), "case_name");
    }

    @Test(dataProvider = "getPTABSearchInput")
    public void verifyPTABTooltipData(String caseNum, String isGrouped, String queryKey) throws Exception {
        loadPage(caseNum, isGrouped);
        to(litigationSearchPage, urlData);

        HashMap<String, String> params = new HashMap<>();
        params.put("case_num", caseNum);

        litigationSearchPage.caseTitle.clickAndHold();
        litigationSearchPage.ptabTooltipContent.waitUntilVisible();
        assertEquals(litigationSearchPage.ptabTooltipContent.getData(),
                sqlProcessor.getResultData("AdvanceSearchDetail." + queryKey, params));
    }

    @DataProvider
    public Object[][] getPTABSearchInput(){
        return new Object[][] {{"IPR2017-01672", "false", "PTAB_STATUS_INFO"}};
    }

    @Test(dataProvider = "getSearchInput")
    public void verifyLitigationTooltipData(String caseNum, String isGrouped, String queryKey) throws Exception {
        loadPage(caseNum, isGrouped);
        to(litigationSearchPage, urlData);

        HashMap<String, String> params = new HashMap<>();
        params.put("case_num", caseNum);

        litigationSearchPage.caseTitle.clickAndHold();
        litigationSearchPage.litTooltipContent.waitUntilVisible();
        assertEquals(litigationSearchPage.litTooltipContent.getData(),
                sqlProcessor.getResultData("AdvanceSearchDetail." + queryKey, params));
    }
}
