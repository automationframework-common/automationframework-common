package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.advance_search.AdvanceSearchPage;
import com.rpxcorp.insight.page.advance_search.LitigationAdvanceSearchPage;
import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;

@Authenticate(role = "MEMBER")
public class LitigationAdvanceSearchTest extends BaseDataTest{

	LitigationAdvanceSearchPage litigationAdvanceSearchPage;
	AdvanceSearchPage advanceSearchPage;


	@Test(description = "RPX-13015 - Verify District, PTAB , ITC court multiple dropdown verification ")
	public void verifyPTABJurisdictionNameInJurisdictionListBox() throws Exception {
		ArrayList<String> itcCourt = new ArrayList<>();
		itcCourt.add("ITC");
		to(advanceSearchPage);
		advanceSearchPage.searchFormTabLinks.select(AdvanceSearchPage.SEARCHTAB.Patent_Litigation);
		at(litigationAdvanceSearchPage);
		assertEquals(litigationAdvanceSearchPage.jurisdiction_District_All.getAllData() , new ArrayList<String>(Arrays.asList(sqlProcessor.getListValue("AdvanceSearchDetail.DISTRICT_COURTS", "normalized_court_name"))));
		assertEquals(litigationAdvanceSearchPage.jurisdiction_PTAB_All.getAllData() , new ArrayList<String>(Arrays.asList(sqlProcessor.getListValue("AdvanceSearchDetail.PTAB_COURTS", "description"))));
		assertEquals(litigationAdvanceSearchPage.jurisdiction_ITC_All.getAllData() , itcCourt);
	}

	@Test(description = "Verify Market sector multiple dropdown verification || RPX-13016 - Add checkboxes in advanced litigation search drop down menus")
	public void verifyMarketSectorListBox() throws Exception {
		to(advanceSearchPage);
		advanceSearchPage.searchFormTabLinks.select(AdvanceSearchPage.SEARCHTAB.Patent_Litigation);
		at(litigationAdvanceSearchPage);
		assertEquals(litigationAdvanceSearchPage.caseDetails_marketSector_All.getAllData() , new ArrayList<String>(Arrays.asList(sqlProcessor.getListValue("AdvanceSearchDetail.MARKET_SECTOR","name"))));
	}


	@DataProvider
	public Object[][] getSearchInput(){
		return new Object[][] {{"gandce-25699", "false", "LIT_STATUS_INFO"}};		
	}		
}
