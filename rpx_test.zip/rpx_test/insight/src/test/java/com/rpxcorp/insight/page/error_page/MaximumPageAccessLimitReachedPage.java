package com.rpxcorp.insight.page.error_page;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
//import com.sun.jna.platform.win32.OaIdl;

public class MaximumPageAccessLimitReachedPage extends BasePage {

    //public final Element
    @Override
    public boolean at() {
        pageTitle.waitUntilVisible();

        return pageTitle.waitUntilTextPresent("Maximum Page Views Reached");
    }

    public final Element errorMessage = $("#content .panel p");
}
