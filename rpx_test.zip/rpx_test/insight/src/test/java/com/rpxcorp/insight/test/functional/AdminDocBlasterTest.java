/**
 * 
 */
package com.rpxcorp.insight.test.functional;

import java.util.ArrayList;

import com.rpxcorp.testcore.Authenticate;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.rpxcorp.insight.page.detail.LitigationDetailPage;
import com.rpxcorp.oldtest.page.DBData;
@Authenticate(role = "ADMIN")
public class AdminDocBlasterTest extends BaseFuncTest {
    LitigationDetailPage litigationDetail;
    DBData dbData = new DBData();
    private String dataId;


    @Test(priority = 1, groups="P3", description = "RPX-10029 CP-3880:Verification of Docket entries section in lit details page for existing doc blaster documents")
    public void docBlasterUpdationForExistingDocument() throws Exception {
        dataId = dbData.getLitDocBlaster(false);
        this.urlData.put("ID", dataId);
        to(litigationDetail, urlData);
        litigationDetail.docket_entries.viewAll();
        litigationDetail.overlay_Loading.waitUntilInvisible();
        Assert.assertTrue(litigationDetail.docBlasterDocType.isDisplayed());
        Assert.assertEquals(false, litigationDetail.docBlasterGreenTick.isPresent());
    }

    @Test(priority = 2, groups="P3", description = "RPX-10029 CP-3886:Verification of Docket entries section in lit details page for non-existing documents in doc blaster")
    public void docBlasterUpdation() throws Exception {
        dataId = dbData.getLitDocBlaster(true);
        this.urlData.put("ID", dataId);
        to(litigationDetail, urlData);
        litigationDetail.docket_entries.viewAll();
        litigationDetail.overlay_Loading.waitUntilInvisible();
        litigationDetail.docket_entries.waitUntilVisible();
        Assert.assertTrue(litigationDetail.docBlasterUpload.isDisplayed(), "Add to DocBlaster icon is not available");
        Assert.assertEquals(false, litigationDetail.docBlasterRedCross.isPresent());
    }

    @Test(priority = 3, groups="P3", description = "RPX-10029  CP-3888:Verification of case stage events in document type dropdown of Add to DocBlaster popup"
            + " CP-4032:Verify that the new icon is replaced with the word 'Requested' if user submits a document.")
    public void docBlasterUploadPopup() throws Exception {
        String[] litDocTypes;
        dataId = dbData.getLitDocBlaster(true);
        System.out.println(dataId);
        this.urlData.put("ID", dataId);
        to(litigationDetail, urlData);
        litigationDetail.docket_entries.viewAll();
        litigationDetail.overlay_Loading.waitUntilInvisible();
        litigationDetail.docket_entries.waitUntilVisible();
        litigationDetail.docBlasterUpload.waitUntilVisible();
        int entryIndex = litigationDetail.getRowIndexforDocBlasterUpload();        
        litigationDetail.docBlasterUpload.click();
        litigationDetail.docBlasterUploadPopupDropDown.waitUntilVisible();
        ArrayList<String> docTypes = litigationDetail.getOptionFromDocType();
        java.util.Collections.sort(docTypes);
        litDocTypes = docTypes.toArray(new String[docTypes.size()]);
        assertEquals(litDocTypes, litigationDetail.docTypes_array);
        litigationDetail.docBlasterUploadPopupDropDownOptions.click();
        litigationDetail.docBlasterPopupSubmit.click();
        litigationDetail.docBlasterPopupSubmit.waitUntilInvisible();
        assertEquals(litigationDetail.docRequestSuccessMsg.getText(), "Document request sent successfully.");
        litigationDetail.docUploadPopupClose.click();
        litigationDetail.docUploadPopup.waitUntilInvisible();
        litigationDetail.refresh();
        litigationDetail.docket_entries.viewAll();
        assertEquals(litigationDetail.getDocBlasterUploadedStatus(entryIndex).getText(), "Request Made");
        Assert.assertTrue(litigationDetail.getDocBlasterStatus(entryIndex),
                "Add to Docblaster icon is not changed after doc blaster upload request");
    }
}
