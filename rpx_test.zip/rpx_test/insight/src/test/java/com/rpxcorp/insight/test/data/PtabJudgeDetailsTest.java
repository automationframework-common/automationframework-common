package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.detail.PtabJudgeDetailPage;
import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

@Authenticate(role = "MEMBER")
public class PtabJudgeDetailsTest extends BaseDataTest{

    PtabJudgeDetailPage ptabJudgeDetailPage;

    /* TEST CONFIGURATIONS */
    @Factory(dataProvider = "returnData")
    public PtabJudgeDetailsTest(String dataDescription, String ptabJudId) {
        this.dataDescription = dataDescription;
        this.dataId = ptabJudId;
    }

    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("PtabJudgeDetail");
    }

    @BeforeClass
    public void loadPage() {
        this.urlData.put("ID", dataId);
        this.dataUrl = ptabJudgeDetailPage.getDeclaredUrl(urlData);
        to(ptabJudgeDetailPage, urlData);
    }

    @Test(description = "Verify Title", priority = 1)
    public void verifyTitle() throws Exception {
        assertEquals(ptabJudgeDetailPage.title.getData(),
                sqlProcessor.getSinglResultValue("PtabJudgeDetail.TITLE", dataId));
    }

    @Test(description = "Verify Stats bar counts", priority = 1)
    public void verifyStatsBar() throws Exception {
        assertEquals(ptabJudgeDetailPage.statsBarContent.getData(),
                sqlProcessor.getResultData("PtabJudgeDetail.STATS_BAR", dataId));
    }

    @Test(description = "Verify all petitions information in petition table", priority = 1)
    public void verifyPetitionsTable() throws Exception {
        ptabJudgeDetailPage.petitionsTable.waitUntilVisible();
        assertEquals(ptabJudgeDetailPage.petitionsTable.getData(),
                sqlProcessor.getResultData("PtabJudgeDetail.PETITIONS_ALL", dataId));
    }

    @Test(description = "Verify active petitions information in petition table", priority = 2)
    public void verifyActivePetitionsTable() throws Exception {
        ptabJudgeDetailPage.click_active_filter_lits();
        assertEquals(ptabJudgeDetailPage.petitionsTable.getData(),
                sqlProcessor.getResultData("PtabJudgeDetail.PETITIONS_ACTIVE", dataId));
    }

    @Test(description = "Verify inactive petitions information in petition table", priority = 3)
    public void verifyInactivePetitionsTable() throws Exception {
        ptabJudgeDetailPage.click_inactive_filter_lits();
        assertEquals(ptabJudgeDetailPage.petitionsTable.getData(),
                sqlProcessor.getResultData("PtabJudgeDetail.PETITIONS_INACTIVE", dataId));
    }
}
