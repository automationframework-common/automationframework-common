package com.rpxcorp.insight.page;

import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;

public class PatentRiskReductionAdminPage extends Page{

    public PatentRiskReductionAdminPage() {
        this.url = new PageUrl("admin/patent_risk_reduction_report");
    }

	@Override
	public boolean at() {
		return patentRiskTitle.waitUntilVisible();
	}

	public final Element patentRiskTitle = $(".small-12>h1");
	public final Tabs patentRiskPanelTabs = new Tabs(".panel .tabs");
	public final Element acquiflowName=$("#def-acquisitions a[href*='/portfolios']");
	public final Element acquiflowLink = $("#def-acquisitions a[href*='acquiflow.internapp']");
	public final Element PatentRiskReductionReportPromoMsg = $("li#quarterly-reports .subscription-promo-message:contains(Start with a Free Trial)");

	public void clickDefensiveAcquisitions(){
		patentRiskPanelTabs.select("DEFENSIVE ACQUISITIONS");
	}
}
