package com.rpxcorp.insight.page.account;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import com.rpxcorp.insight.module.Tabs;
import org.openqa.selenium.By;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;

public class GlobalConfigPage extends Page {

    public GlobalConfigPage() {
        this.url = new PageUrl("/admin/global_config");
    }

    @Override
    public boolean at() {
        return globalConfigSection.waitUntilVisible();
    }

    public Element pageLimitTextBox = $("h5:contains('{frequency} Limit')+ul+div>div"+
            "[id^='{role}'].active div:has(>.prefix:contains('{pageName}'))+div>input");
    public Element pageLimitUpdateBtn =$("h5:contains('{frequency} Limit')+ul+div>div[id^='{role}'].active .button");

    public Tabs PageViewAndDownloadLimits = new Tabs("div.restricted_page_view_and_downloads dl.tabs");

    public void selectPageLimitTab(String frequency,String role){
        // TODO implement of option for modules and clean this code
        Tabs pageLimitTab= $("h5:contains('"+frequency+" Limit')+ul",Tabs.class);
        String value = Arrays.stream(role.split("-")).map(StringUtils::capitalize).collect(Collectors.joining(" "));
        pageLimitTab.select(value);
        pageLimitUpdateBtn.of(frequency, role).waitUntilVisible();
    }

    public void setPageViewLimit(String frequency, String role,Map<String, String> data) {
        selectPageLimitTab(frequency,role);
        for (Map.Entry<String, String> pageLimit : data.entrySet()) {
            pageLimitTextBox.of(frequency, role, pageLimit.getKey()).sendKeys(pageLimit.getValue());
        }
        pageLimitUpdateBtn.of(frequency, role).click();
    }



    public Element pageDownloadTextBox = $(".restricted_page_view:eq(1) h5:contains('{frequency} Limit')+ul+div>div"+
            "[id^='download_{role}'].active div:has(>.prefix:contains('{pageName}'))+div>input");
    public Element pageDownlodUpdateBtn =$(".restricted_page_view:eq(1) h5:contains('{frequency} Limit')+ul+div>div[id^='download_{role}'].active .button");



    public void selectPageDownloadTab(String frequency,String role){
        // TODO implement of option for modules and clean this code
        Tabs pageDownloadTab= $(".restricted_page_view:eq(1) h5:contains('"+frequency+" Limit')+ul",Tabs.class);
        pageDownloadTab.select(StringUtils.capitalize(role));
        pageDownlodUpdateBtn.of(frequency, role).waitUntilVisible();
    }


    public void setPageViewDownloadLimit(String frequency, String role,Map<String, String> data) {
        selectPageDownloadTab(frequency,role);
        for (Map.Entry<String, String> pageLimit : data.entrySet()) {
            pageDownloadTextBox.of(frequency, role, pageLimit.getKey()).sendKeys(pageLimit.getValue());
        }
        pageDownlodUpdateBtn.of(frequency, role).click();
    }

    public final Element flashMessage = $("#flash_name");
    public final Element globalConfigSection = $(".large-4.columns.centered>div");

    public final Element adminLitDocDownloadLimit = $(By.xpath("//span[text()='Admin']/../..//input"));
    public final Element primeLitDocDownloadLimit = $(By.xpath("//span[text()='Prime']/../..//input"));
    public final Element memberLitDocDownloadLimit = $(By.xpath("//span[text()='Member']/../..//input"));
    public final Element plusLitDocDownloadLimit = $(By.xpath("//span[text()='Plus']/../..//input"));
    public final Element eliteLitDocDownloadLimit = $(By.xpath("//span[text()='Elite']/../..//input"));
    public final Element basicLitDocDownloadLimit = $(By.xpath("//span[text()='Basic']/../..//input"));
    public final Element staffLitDocDownloadLimit = $(By.xpath("//span[text()='Staff']/../..//input"));
    //public final Element underwriterLitDocDownloadLimit = $(By.xpath("//span[text()='Underwriter']/../..//input"));
    public final Element litDocDownloadLimitUpdate_btn = $(
            "form[action*='document_credit_update'] input[value='Update']");

    public final Element trialUserTab = $(".small-12 a[href*='#trial-user']");

    public final Element memberUserPageAccessTab = $(".small-12 a[href*='#member']");
    public final Element memberUserDownloadTab = $(".small-12 a[href*='#download_member']");

    public final Element entityDetailPageLimit = $("#restricted_page_limit_208_allowed_limit");
    public final Element litDetailPageLimit = $("#restricted_page_limit_209_allowed_limit");
    public final Element itcDetailPageLimit = $("#restricted_page_limit_210_allowed_limit");
    public final Element ptabDetailPageLimit = $("#restricted_page_limit_211_allowed_limit");
    public final Element portfolioDetailPageLimit = $("#restricted_page_limit_212_allowed_limit");
    public final Element patentDetailPageLimit = $("#restricted_page_limit_213_allowed_limit");
    public final Element marketPlaceDetailPageLimit = $("#restricted_page_limit_214_allowed_limit");
    public final Element campaignDetailPageLimit = $("#restricted_page_limit_215_allowed_limit");
    public final Element entitySearch = $("#restricted_page_limit_216_allowed_limit");
    public final Element litSearch = $("#restricted_page_limit_217_allowed_limit");
    public final Element patentSearch = $("#restricted_page_limit_218_allowed_limit");
    public final Element allSearch  = $("#restricted_page_limit_219_allowed_limit");
    public final Element trialUSerPageAccessUpdate_btn = $ ("#trial-user input[value='Update']");

    public final Element reportTrialUserTab = $(".small-12 a[href*='#download_trial-user']");

    public final Element dossierDownloadLimit = $("#report_download_limit_46_allowed_limit");
    public final Element excelDetailsPageDownloadLimit = $("#report_download_limit_49_allowed_limit");
    public final Element excelSearchPageDownloadLimit = $("#report_download_limit_50_allowed_limit");
    public final Element LCADownloadLimit = $("#report_download_limit_47_allowed_limit");
    public final Element priorArtSearchPageDownloadLimit = $("#report_download_limit_48_allowed_limit");

    public final Element trialUserDownloadUpdate_btn = $ ("#download_trial-user input[value='Update']");

    //locators for page access limit pages in global config page RPX-12925 -- Add user's current download limits and clear functionality in admin view page
    public final Element allgConfigSearchLimit = $("#member_daily form[action*='restricted_page_limit']>div:nth-of-type(12) input");
    public final Element campaigngConfigPageLimit = $("#member_daily form[action*='restricted_page_limit']>div:nth-of-type(8) input");
    public final Element entitygConfigDetailLimit = $("#member_daily form[action*='restricted_page_limit']>div:nth-of-type(1) input");
    public final Element entitygConfigSearchLimit = $("#member_daily form[action*='restricted_page_limit']>div:nth-of-type(9) input");
    public final Element ITCgConfigDetailPageLimit = $("#member_daily form[action*='restricted_page_limit']>div:nth-of-type(3) input");
    public final Element litgConfigDetailLimit = $("#member_daily form[action*='restricted_page_limit']>div:nth-of-type(2) input");
    public final Element litgConfigSearchLimit = $("#member_daily form[action*='restricted_page_limit']>div:nth-of-type(10) input");
    public final Element marketplacegConfigDetailLimit = $("#member_daily form[action*='restricted_page_limit']>div:nth-of-type(7) input");
    public final Element PTABgConfigDetailPageLimit = $("#member_daily form[action*='restricted_page_limit']>div:nth-of-type(4) input");
    public final Element patentgConfigDetailLimit = $("#member_daily form[action*='restricted_page_limit']>div:nth-of-type(6) input");
    public final Element patentgConfigSearchLimit = $("#member_daily form[action*='restricted_page_limit']>div:nth-of-type(11) input");
    public final Element portfoliogConfigDetailLimit = $("#member_daily form[action*='restricted_page_limit']>div:nth-of-type(5) input");

    //locators for download limit in admin/users page RPX-12925 -- Add user's current download limits and clear functionality in admin view page
    public final Element dossiergConfigLimit = $("#download_member_daily form[action*='report_download_limit']>div:nth-of-type(1) input");
    public final Element priorArtSearchReportgConfigLimit = $("#download_member_daily form[action*='report_download_limit']>div:nth-of-type(5) input");
    public final Element excelSearchgConfigLimit = $("#download_member_daily form[action*='report_download_limit']>div:nth-of-type(3) input");
    public final Element excelDetailsgConfigLimit = $("#download_member_daily form[action*='report_download_limit']>div:nth-of-type(2) input");
    public final Element LCAgConfigLimit = $("#download_member_daily form[action*='report_download_limit']>div:nth-of-type(4) input");


    public void setLitDocDownloadLimit(Map<String, String> data) {
        adminLitDocDownloadLimit.sendKeys(data.get("admin"));
        basicLitDocDownloadLimit.sendKeys(data.get("basic"));
        memberLitDocDownloadLimit.sendKeys(data.get("member"));
        plusLitDocDownloadLimit.sendKeys(data.get("plus"));
        eliteLitDocDownloadLimit.sendKeys(data.get("elite"));
        primeLitDocDownloadLimit.sendKeys(data.get("prime"));
        staffLitDocDownloadLimit.sendKeys(data.get("staff"));
        //underwriterLitDocDownloadLimit.sendKeys(data.get("underwriter"));
    }

    public void setPageAccessLimit(Map<String, String> accesData) {
        entityDetailPageLimit.sendKeys(accesData.get("entityDetails"));
        litDetailPageLimit.sendKeys(accesData.get("litDetails"));
        itcDetailPageLimit.sendKeys(accesData.get("itcDetails"));
        ptabDetailPageLimit.sendKeys(accesData.get("ptabDetails"));
        portfolioDetailPageLimit.sendKeys(accesData.get("portfolioDetails"));
        patentDetailPageLimit.sendKeys(accesData.get("patentDetails"));
        marketPlaceDetailPageLimit.sendKeys(accesData.get("marketPlaceDetails"));
        campaignDetailPageLimit.sendKeys(accesData.get("campaignDetails"));
        entitySearch.sendKeys(accesData.get("entitySearch"));
        litSearch.sendKeys(accesData.get("litSearch"));
        patentSearch.sendKeys(accesData.get("patentSearch"));
        allSearch.sendKeys(accesData.get("allSearch"));
    }

    public void setDownloadLimit(Map<String, String> accesData) {
        dossierDownloadLimit.sendKeys(accesData.get("dossier"));
        excelDetailsPageDownloadLimit.sendKeys(accesData.get("excelDetailsPage"));
        excelSearchPageDownloadLimit.sendKeys(accesData.get("excelSearchPage"));
        LCADownloadLimit.sendKeys(accesData.get("LCA"));
        priorArtSearchPageDownloadLimit.sendKeys(accesData.get("priorArtSearchPage"));
    }

    public void updateLitDocDownloadLimit() {
        litDocDownloadLimitUpdate_btn.click();
        waitForFlashMessage();
    }

    public void setAndUpdateLitDocDownloadLimit(Map<String, String> data) {
        setLitDocDownloadLimit(data);
        updateLitDocDownloadLimit();
    }

    public void setAndUpdatePageAccessLimit(Map<String, String> data) {
        setPageAccessLimit(data);
    }

    public void setAndUpdateDownloadLimit(Map<String, String> data) {
        setDownloadLimit(data);
    }

    public boolean waitForFlashMessage() {
        return flashMessage.waitUntilTextPresent("Your settings have been successfully saved.");
    }

    public Map<String, String> getMonthlyDocumentCredit() {
        Map<String, String> monthlyDocCredit = new HashMap<String, String>();
        monthlyDocCredit.put("doc_credit_basic",
                "$" + basicLitDocDownloadLimit.getAttribute("value").replace(".00", ""));
        monthlyDocCredit.put("doc_credit_plus", "$" + plusLitDocDownloadLimit.getAttribute("value").replace(".00", ""));
        monthlyDocCredit.put("doc_credit_prime",
                "$" + primeLitDocDownloadLimit.getAttribute("value").replace(".00", ""));
        monthlyDocCredit.put("doc_credit_elite",
                "$" + eliteLitDocDownloadLimit.getAttribute("value").replace(".00", ""));

        return monthlyDocCredit;
    }
}
