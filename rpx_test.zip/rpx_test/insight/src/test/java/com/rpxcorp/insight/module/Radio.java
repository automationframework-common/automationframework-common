package com.rpxcorp.insight.module;

import com.rpxcorp.testcore.element.Element;

public class Radio extends Element {
    public Radio(String selector) {
        super(selector);
    }

    public void selectValue(String value) {
        if (value != null && !value.isEmpty())
        $(" [value='" + value + "']").click();
    }

    public void selectById(String value) {
        if (value != null && !value.isEmpty())
            $(" [id='" + value + "']").click();
    }
    public void selectByOption(Object option){
        selectByOption((String) option);
    }
    public void selectByOption(String value) {
        if (value != null && !value.isEmpty())
            $(":contains('" + value+ "') input").click();
    }
    public String getSelectedField() {
        return $("td:has(input:checked)+td").getText();
    }

    public boolean isRadioselected(String labelName) {
       return  $("input:checked+label:contains('"+labelName+"')").isEnabled();
    }
}
