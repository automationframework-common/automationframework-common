package com.rpxcorp.insight.page.payment;

import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class PaymentSuccessPage extends BasePage {

    @Override
    public boolean at() {
        rpx_Logo.waitUntilVisible();
        loading.waitUntilInvisible();
        return upgradeRoleText.waitUntilVisible();
    }

    public final Element upgradeRoleText = $("span.plan_highlight");
    public final Element title = $("h2.success:contains('Account Upgrade Successful')");
    public final StaticContent order_info = $(".purchase_summary", (Configure<StaticContent>) dataForm ->
        {
            dataForm.content("order_date", "div:contains(Purchase Date:)+div.columns");
            dataForm.content("order_number", "div:contains(Confirmation Number:)+div.columns");
            dataForm.content("account_type", "div:contains(Account Type:)+div.columns");
            dataForm.content("account_charged", "div:contains(Amount Charged:)+div.columns");
            dataForm.content("subscription_type", "div:contains(Subscription Type:)+div.columns");
        }
    );

    //Added for new payment
    public final StaticContent order_info_new = $(".purchase_summary", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("trial_start_date", "div:contains(Trial Start Date:)+div.columns");
                dataForm.content("subscription_plan", "div:contains(Subscription Plan:)+div.columns");
                dataForm.content("subscription_fee", "div:contains(Subscription Fee:)+div.columns");
                dataForm.content("billing_start_date", "div:contains(Billing Start Date:)+div.columns");
                dataForm.content("billing_date", "div:nth-child(1) div:nth-child(1)+div.columns");//"//div[@class='purchase_summary']//div[text()='Billing Date:']/following-sibling::div"
                dataForm.content("next_billing_date", "div:contains(Next Billing Date:)+div.columns");
            }
    );

    public final Element featureSectionTitle = $("#sidebar div h4");
    public final Element featureSection = $("div[data-behavior='load_async_content']");
    // public final Element thankUMsg=$("p.thank_you:has(span)");
    public final String thanUMsg1 = "Thank you for subscribing to ";
    public final String thanUMsg2 = "You now have enhanced access to the largest, most comprehensive database of information on patents, litigations, and entities.";
    public final String thanUMsg3 = "To activate your account, please use the link sent to the registered email.";

    public String getTodayDate() {
        Date today;
        SimpleDateFormat formatter;
        formatter = new SimpleDateFormat("MMMM d, yyyy");
        today = new Date();
        formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
        return formatter.format(today);

    }

    // SPECIAL OFFER
    public final Element specialOfferSection = $(By.xpath("//div[@class='panel']/h4[text()='Special Offer']/.."));

    // Time line Bar
    public final Element timeline_bar = $(".progress.small-centered.columns.small-6.round");
    public final Element timelineStatusBar = $("span[class='meter secondary current_stage']");

    public String[] getStageColor() {
        String[] colors = new String[3];
        for (int index = 1; index <= 3; index++) {
            if (getDriver()
                    .findElement(By.cssSelector(
                            ".progress.small-centered.columns.small-6.round span:nth-of-type(" + index + ")"))
                    .getCssValue("background-color").contentEquals("rgba(49, 149, 205, 1)")) {
                colors[index - 1] = "blue";
            } else if (getDriver()
                    .findElement(By.cssSelector(
                            ".progress.small-centered.columns.small-6.round span:nth-of-type(" + index + ")"))
                    .getCssValue("background-color").contentEquals("rgba(186, 188, 190, 1)")) {
                colors[index - 1] = "grey";
            }
        }
        return colors;
    }

    public String getThankUMsg() {
        return $("div.panel>p.thank_you:nth-of-type(1)").getText();
    }
}
