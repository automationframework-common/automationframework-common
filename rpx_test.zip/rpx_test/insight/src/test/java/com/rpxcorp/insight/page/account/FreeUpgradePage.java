package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FreeUpgradePage extends BasePage {

    public FreeUpgradePage() {
        this.url = new PageUrl("user/free_upgrade");
    }

    @Override
    public boolean at() {
        return upgradeBtn.waitUntilVisible();
    }

    public final Element upgradeBtn = $("#user_upgrade_form #signup-btn");
    public final Element firstNameTxt = $("#user_upgrade_form #user_first_name");
    public final Element lastNameTxt = $("#user_upgrade_form #user_last_name");
    public final Element companyTxt = $("#user_upgrade_form #user_extended_user_detail_attributes_company");
    public final Element userEmailTxt = $("#user_upgrade_form #user_email");

    public final Element errors = $(".payment-user-details .errors");
    public final Element formTitle = $(".payment-user-details h4");
    
    public void saveUpgradeForm(Map<String, String> formData) {
        firstNameTxt.sendKeys(formData.get("first_name"));
        lastNameTxt.sendKeys(formData.get("last_name"));
        companyTxt.sendKeys(formData.get("company"));
        userEmailTxt.sendKeys(formData.get("email"));
        upgradeBtn.click();
    }
}
