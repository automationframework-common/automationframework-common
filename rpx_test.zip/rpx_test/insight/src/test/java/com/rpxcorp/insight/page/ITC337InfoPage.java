package com.rpxcorp.insight.page;

import org.openqa.selenium.By;

import com.rpxcorp.testcore.element.Element;

public class ITC337InfoPage extends BasePage{

	@Override
	public boolean at() {
		return itc337infoTitle.waitUntilVisible();
	}

	public final Element itc337infoTitle = $(By.xpath("//div[@id='header']//h1[text()='337Info']"));
}
