package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.detail.LawfirmDetailPage;
import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.util.Map;

@Authenticate(role = "MEMBER")
public class LawfirmDetailsTest extends BaseDataTest{
	LawfirmDetailPage lawfirmDetailPage;
	Map<String, String> staticData;	
	int resultSetCount;
    @Factory(dataProvider = "returnData")
    public LawfirmDetailsTest(String dataDescription, String lawId) {
        this.dataDescription = dataDescription;
        this.dataId = lawId;
    }
    
    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("LawfirmDetail");
    }

    @BeforeClass
    public void loadPage() {
        this.urlData.put("ID", dataId);
        this.dataUrl = lawfirmDetailPage.getDeclaredUrl(urlData);
        to(lawfirmDetailPage, urlData);
    }
    
    @Test(description = "Verify Title", priority = 1)
    public void Verify_Title() throws Exception {
        assertEquals(lawfirmDetailPage.lawfirmPageTitle.getData(), 
        		sqlProcessor.getResultData("LawfirmDetail.TITLE", dataId), "title");
    }
    
    @Test(description = "Verify total cases in stats", priority = 2)
    public void verifyTotalCaseCountStats() throws Exception {
    	assertEquals(lawfirmDetailPage.metricsSection.getData("total_cases"), 
    			sqlProcessor.getResultData("LawfirmDetail.TOTAL_CASE_COUNT", dataId), "total_cases");       
    }
    
    @Test(description = "Verify total parties represented in stats", priority = 2)
    public void verifyPartyRepresentedStats() throws Exception {
    	assertEquals(lawfirmDetailPage.metricsSection.getData("parties_represented"), 
    			sqlProcessor.getResultData("LawfirmDetail.TOTAL_PARTIES_REPRESENTED", dataId), "parties_represented");       
    }
    
    @Test(description = "Verify average cases per year in stats", priority = 2)
    public void verifyAverageCasesPerYearStats() throws Exception {
    	assertEquals(lawfirmDetailPage.metricsSection.getData("average_cases_per_year"), 
    			sqlProcessor.getResultData("LawfirmDetail.STATS_DETAILS", dataId), "average_cases_per_year");       
    }
    
    @Test(description = "Verify average cases length in stats", priority = 2)
    public void verifyAverageCasesLengthStats() throws Exception {
    	assertEquals(lawfirmDetailPage.metricsSection.getData("average_length_of_case_in_days"), 
    			sqlProcessor.getResultData("LawfirmDetail.STATS_DETAILS", dataId), "average_length_of_case_in_days");       
    }
    
    @Test(description = "Verify Litigation Section for All Cases", priority = 3)
    public void verifyLitigationSectionAll() throws Exception {
        lawfirmDetailPage.litigation_Section.waitUntilVisible();
        assertEquals(lawfirmDetailPage.litigation_Section.getData(),
                sqlProcessor.getResultData("LawfirmDetail.LITIGATIONS_ALL", dataId));
    }
    
    @Test(description = "Verify Litigation Section for Active Cases", priority = 4)
    public void verifyLitigationSectionActive() throws Exception {
    	lawfirmDetailPage.clickActiveFilterLits();
        assertEquals(lawfirmDetailPage.litigation_Section.getData(),
                sqlProcessor.getResultData("LawfirmDetail.LITIGATIONS_ACTIVE", dataId));
    }

    @Test(description = "Verify Litigation Section for Inactive Cases", priority = 5)
    public void verifyLitigationSectionInActive() throws Exception {
    	lawfirmDetailPage.clickInactiveFilterLits();
        assertEquals(lawfirmDetailPage.litigation_Section.getData(),
                sqlProcessor.getResultData("LawfirmDetail.LITIGATIONS_INACTIVE", dataId));
    }
    
   //@Test(description = "Verify Cases by Market Sector section", priority = 6)
    public void verifyCasesByMarketSector() throws Exception {
        assertEquals(lawfirmDetailPage.casesByMarketSector.getData(),
                sqlProcessor.getResultData("LawfirmDetail.CASES_BY_MARKET_SECTOR", dataId));
    }
    
    @Test(description = "Verify Active Cases", priority = 7)
    public void verifyActiveCaseCount() throws Exception {
    	assertEquals(lawfirmDetailPage.lawfirmProfileSection.getData("activeCaseCount"),
               sqlProcessor.getSingleValue(sqlProcessor.getResultData("LawfirmDetail.STATS_DETAILS", dataId), "active_cases"));    	
    }
    
    @Test(description = "Verify Inactive Cases", priority = 7)
    public void verifyInactiveCaseCount() throws Exception {
    	assertEquals(lawfirmDetailPage.lawfirmProfileSection.getData("inactiveCaseCount"),
               sqlProcessor.getSingleValue(sqlProcessor.getResultData("LawfirmDetail.STATS_DETAILS", dataId), "inactive_cases"));    	
    }
    
    @Test(description = "Verify plaintiff counsel count", priority = 7)
    public void verifyPlaintiffCounselCount() throws Exception {
    	assertEquals(lawfirmDetailPage.lawfirmProfileSection.getData("plaintiffCounsel"),
               sqlProcessor.getResultData("LawfirmDetail.PLAINTIFF_COUNSEL_COUNT", dataId), "plaintiff_counsel");    	
    }
    
    @Test(description = "Verify defense counsel count", priority = 7)
    public void verifyDefenseCounselCount() throws Exception {
    	assertEquals(lawfirmDetailPage.lawfirmProfileSection.getData("defenseCounsel"),
               sqlProcessor.getResultData("LawfirmDetail.DEFENDANT_COUNSEL_COUNT", dataId), "defendant_counsel");    	
    }
    
    @Test(description = "Verify counsel for npe count", priority = 7)
    public void verifyNPECounselCount() throws Exception {
    	assertEquals(lawfirmDetailPage.lawfirmProfileSection.getData("counselForNpe"),
               sqlProcessor.getResultData("LawfirmDetail.NPE_COUNSEL_OVERALL", dataId), "npe_counsel");    	
    }
    
    @Test(description = "Verify counsel against npe count", priority = 7)
    public void verifyCounselAgainstNPECount() throws Exception {
    	assertEquals(lawfirmDetailPage.lawfirmProfileSection.getData("counselAgainstNPE"),
               sqlProcessor.getResultData("LawfirmDetail.COUNSEL_AGAINST_NPE", dataId), "counsel_against_npe");    	
    }
    
    @Test(description = "Verify lead counsel count", priority = 7)
    public void verifyLeadCounselCount() throws Exception {
    	assertEquals(lawfirmDetailPage.lawfirmProfileSection.getData("leadCounsel"),
               sqlProcessor.getResultData("LawfirmDetail.LEAD_COUNSEL", dataId), "lead_counsel");    	
    }
    
    @Test(description = "RPX-13191 | Verify other counsel count", priority = 7)
    public void verifyOtherCounselCount() throws Exception {
    	assertEquals(lawfirmDetailPage.lawfirmProfileSection.getData("other"),
               sqlProcessor.getResultData("LawfirmDetail.LOCAL_COUNSEL", dataId), "local_counsel");    	
    }
    
    @Test(description = "Verify parties represented count", priority = 7)
    public void verifyTopPartiesCount() throws Exception {    	
    	assertEquals(lawfirmDetailPage.statsByParties.getData(), 
    			sqlProcessor.getResultData("LawfirmDetail.TOP_PARTIES_REPRESENTED", dataId));    	
    }
    
    @Test(description = "Verify judges represented count", priority = 7)
    public void verifyTopJudgesCount() throws Exception { 
    	lawfirmDetailPage.topPartiesRepresented.selectValue("Top Judges");
    	assertEquals(lawfirmDetailPage.statsByJudges.getData(), 
    			sqlProcessor.getResultData("LawfirmDetail.TOP_JUDGES", dataId));    	
    }
    
    @Test(description = "Verify venues represented count", priority = 7)
    public void verifyTopVenuesCount() throws Exception { 
    	lawfirmDetailPage.topPartiesRepresented.selectValue("Top Venues");
    	assertEquals(lawfirmDetailPage.statsByVenues.getData(), 
    			sqlProcessor.getResultData("LawfirmDetail.TOP_VENUES", dataId));    	
    }

    @Test(description = "Verify lawfirm Petitions", priority = 7)
    public void verifyLawfirmPetitions() throws Exception {
        resultSetCount=sqlProcessor.getResultCount("LawfirmDetail.PETITIONS", dataId);
        if(resultSetCount>0) {
            lawfirmDetailPage.petition_table.waitUntilVisible();
            lawfirmDetailPage.petition_table.viewAll();
            assertEquals(lawfirmDetailPage.petition_table.getData(),
                    sqlProcessor.getResultData("LawfirmDetail.PETITIONS", dataId));
        } else {
            assertEquals(lawfirmDetailPage.petition_table.isDisplayed(),false);
        }
        assertEquals(lawfirmDetailPage.metricsSection.getIntData("petitions"),resultSetCount);

    }
}