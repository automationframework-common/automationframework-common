/**
 * 
 */
package com.rpxcorp.insight.page.detail;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

/**
 * @author gandhimathia
 *
 */
public class AliasesDetailPage extends BasePage {

    public AliasesDetailPage() {
        this.url = new PageUrl("aliases/{ID}");
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.rpxcorp.insight.page.BasePage#at()
     */
    @Override
    public boolean at() {
        // TODO Auto-generated method stub
        waitForPageLoad();
        return false;
    }


    public final Element createAlertEntity = $("[data-track-action='create_alert']");
    public final Element aliases = $(".large-12.columns .columns>h5");
    public final Element title = $("h1.detail-page-title");
}
