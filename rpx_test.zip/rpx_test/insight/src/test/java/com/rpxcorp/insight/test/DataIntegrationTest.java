package com.rpxcorp.insight.test;

import com.rpxcorp.testcore.Assert;
import com.rpxcorp.testcore.UITest;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.HTTPUtil;
import com.rpxcorp.testcore.util.SQLProcessor;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.*;
/*
 @author: Prasanna
 @Description: This test is used to check source site latest data vs our system data
 */

public class DataIntegrationTest extends UITest {
    SQLProcessor sqlProcessor=new SQLProcessor();
    public static final Properties config = ConfigUtil.config();
    Document doc;
    String db_check;
    public static String methodName;
    String itc_Url=config.getProperty("ITC_URL");

    @Test(description = "verify new lits data in our system",dataProvider = "testCases")
    public void check_NewLits(String tCase_Title,String expData,String columnName,String dbQuery,String URL) throws Exception {
        String[] expected_Data;
        List<String> actual;
        if(expData!="N/A") {
            expected_Data = expData.replace("'", "").split(",");
            actual = new ArrayList(Arrays.asList(expected_Data));
            Assert.isEquals(sqlProcessor.getListValue(dbQuery, expData, columnName), actual);
        }
    }

    @DataProvider(name="testCases")
    public Object[][] testCases() throws Exception {
        return new Object[][]{{"Check New ITC Cases Data",getITCLatestComplaintsFromSite(),"docket_number","Integration_Test_Queries.ITC_DOCKET_CHECK",itc_Url},
                {"Check New PTAB Cases Data", getRecentPTABCasesFromSite(),"case_num","Integration_Test_Queries.PTAB_CASE_NUM_CHECK","https://ptab.uspto.gov/login"}};
    }

    public String getITCLatestComplaintsFromSite() throws  Exception{
        List<String> doc_numbers=new ArrayList<String>();
        HTTPUtil itc_url=new HTTPUtil(itc_Url);
        Boolean isNoData=true;
        Elements latest_itc_doc_num=itc_url.loadPage(itc_Url).select("#recom-investigations tbody>tr td>div>p:contains(Docket Number)");
        if(latest_itc_doc_num.size()==0){
            isNoData=false;
        }
        if(isNoData) {
            db_check = "'";
            for (org.jsoup.nodes.Element elem : latest_itc_doc_num) {
                String doc_number = elem.text().replaceAll("[\\D]", "").trim();
                db_check = db_check + doc_number + "','";
                doc_numbers.add(doc_number);
            }
            this.db_check = db_check.trim().substring(0, (db_check.length() - 2));

        } else {
            this.db_check="N/A";
        }
        System.out.println(db_check);
        return db_check;
    }

    public String getRecentPTABCasesFromSite() throws Exception{
        List<String> case_numbers=new ArrayList<String>();
        case_numbers=getPtabCases();
        if(case_numbers!=null) {
            Object[] actual = case_numbers.toArray();
            db_check = "'";
            for (Object case_num : actual) {
                db_check = db_check + case_num + "','";
                case_numbers.add((String)case_num);
            }
            this.db_check = db_check.trim().substring(0, (db_check.length() - 2));
        } else {
            this.db_check="N/A";
        }
        return db_check;
    }

    private List<String> getPtabCases() throws InterruptedException {
        List<String> data=new ArrayList<>();
            Element user_Id=new Element("input[ng-model='username']");
            Element pswd=new Element("input[ng-model='password']");
            Element login_Btn=new Element("[id='PTAB-login-button']");
            Element busy_Loading=new Element("body[block-ui='main'  and aria-busy='true'");
            Element proceedingNumber=new Element("form div.form-group [ng-model='mcdSearchCriteria.proceedingNumber']");
            Element search_Btn=new Element("form [id='searchButton']");
            Element filterBY_Exp=new Element("div.ng-scope h4:contains(Filter by) i.fa-angle-right");
            Element filterBYDate_Exp=new Element("span:contains(Dates) i");
            Element filing_StartDatePicker=new Element("div.input-group:contains('Filing Date') #filingStartDate md-icon");
            Element add_Filter=new Element("[id='FilterAdd']");

            //Dates for PTAB
            String to_date,from_date;
            Calendar cal = Calendar.getInstance();
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
            to_date=dateFormat.format(cal.getTime());
            cal.add(Calendar.DATE, -3);
            from_date=dateFormat.format(cal.getTime());

            //Login
            config.setProperty("BROWSER","Chrome");
            getBrowser().getDriver().get("https://ptab.uspto.gov/#/login");
            login_Btn.waitUntilVisible();
            busy_Loading.waitUntilInvisible();
            login_Btn.waitUntilVisible();
            user_Id.sendKeys("munny.smile@gmail.com");
            pswd.sendKeys("RpxIntake@123");
            login_Btn.click();
            Thread.sleep(10000);
            busy_Loading.waitUntilInvisible();
            if(getDriver().getCurrentUrl().contains("forbidden") || getDriver().getCurrentUrl().contains("error")){
                getDriver().navigate().refresh();
            }
            busy_Loading.waitUntilInvisible();

            //Search
            getDriver().get("https://ptab.uspto.gov/#/external/search");
            Thread.sleep(10000);
            busy_Loading.waitUntilInvisible();
            proceedingNumber.waitUntilClickable();
            proceedingNumber.click();
            proceedingNumber.sendKeys("-");
            search_Btn.submit();
            Thread.sleep(10000);
            busy_Loading.waitUntilInvisible();
            //Entering Filed Date
            filterBY_Exp.click();
            filterBYDate_Exp.waitUntilVisible();
            filterBYDate_Exp.click();
            filing_StartDatePicker.waitUntilVisible();
            Thread.sleep(10000);
             new Element("#filingStartDate input").getElement().sendKeys(from_date);
            Thread.sleep(500);
            new Element("#filingEndDate input").getElement().sendKeys(to_date);
            Thread.sleep(500);
            add_Filter.click();
            Thread.sleep(1000);
            busy_Loading.waitUntilInvisible();
            new Element("#searchResults_tablePageSizeDropdown").selectByOption("100");
            Thread.sleep(1000);
            busy_Loading.waitUntilInvisible();
            new Element("table[st-table='searchResults']").waitUntilVisible();

            if(!new Element("tfoot").getText().contains("No records")) {
                Document doc = Jsoup.parse(getPageSource());
                Elements case_nums = doc.select("table[st-table='searchResults'] tbody>tr td:nth-child(1)");
                List<String> finalData = data;
                case_nums.stream().forEach(c -> finalData.add(c.text()));
                data=finalData;
            } else {
                data=null;
        }
        System.out.println(data);
            return data;
    }
}
