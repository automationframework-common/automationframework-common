package com.rpxcorp.insight.test.data;
import com.rpxcorp.insight.page.detail.ChinesePRBDetailPage;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.TableData;
import org.testng.annotations.Test;

import java.sql.ResultSet;
import java.util.Map;

@Authenticate(role = "MEMBER")
@Test(groups = {"Lits","PRB"})
public class ChinesePRBDetailTest extends BaseDataTest {
    ChinesePRBDetailPage chinesePRBDetailPage;
    TableData tableData;
    Map<String, String> staticData;
    ResultSet resultSet;

    /* TEST CONFIGURATIONS */
 /*   @Factory(dataProvider = "returnData")
    public ChinesePRBDetailTest(String dataDescription, String PRBId) throws Exception {
        this.dataDescription = dataDescription;
        this.dataId = getPageId(PRBId);
    }
    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("ChinesePRBDetail");
    }

    @BeforeClass
    public void loadPage() {
        this.urlData.put("ID", dataId);
        this.dataUrl = chinesePRBDetailPage.getDeclaredUrl(urlData);
        to(chinesePRBDetailPage, urlData);
    }

    @Test(description = "Verify Title")
    public void verifyTitle() throws Exception {
        assertEquals(chinesePRBDetailPage.title.getData(),
                sqlProcessor.getSinglResultValue("ChinesePRBDetail.TITLE", dataId));
    }*/
}
