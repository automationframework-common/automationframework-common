package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class RpxAccountEditPage extends BasePage {

    public RpxAccountEditPage() {
        this.url = new PageUrl("admin/rpx_accounts/{ID}/edit");
    }

    @Override
    public boolean at() {
        assertPageTitle("Edit company details");
        return saveChanges_Btn.waitUntilVisible();
    }

    public final Element saveChanges_Btn = $(".button[value='Save Changes']");
    public final Element active_Checkbox=$("#rpx_account_settings_active");
    
    public void activateAccount(boolean isAcivate) {
    	if(!active_Checkbox.isSelected()==isAcivate) {
    		active_Checkbox.click();
    	}    	
    }
    
    public void saveChanges() {
    	saveChanges_Btn.click();
    	loading.waitUntilInvisible();
    }

}
