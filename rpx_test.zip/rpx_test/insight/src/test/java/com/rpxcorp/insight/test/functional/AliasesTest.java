package com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.detail.*;
import com.rpxcorp.insight.page.error_page.PageNotFoundPage;
import com.rpxcorp.testcore.Authenticate;
import org.testng.Assert;
import org.testng.annotations.Test;
@Test(groups = "Aliases")
@Authenticate(role = "MEMBER")
public class AliasesTest extends BaseFuncTest {

    AliasesDetailPage aliasesPage;
    VenueDetailPage venueDetailPage;
    JudgeDetailPage judgeDetailPage;

    @Test(priority = 1, groups = "P2", description = "RPX-10119 Validating alias page navigation of type Entity ")
    public void checkEntityAliasesPageNavigation() throws Exception {
        to(aliasesPage, getDBData("ALIASES_FOR_ENTITY"), false);
        at(EntityDetailPage.class);
        String url = String.format(getConfig("BASE_URL") + "/ent");
        Assert.assertTrue(getDriver().getCurrentUrl().contains(url),
                "Expected: " + url + " Actual: " + getDriver().getCurrentUrl());
        Assert.assertTrue(aliasesPage.createAlertEntity.isDisplayed());
    }

    @Test(priority = 2, groups = "P2", description = "RPX-10119 Validating alias page navigation of type venue ")
    public void checkVenueAliasesPageNavigation() throws Exception {
        to(aliasesPage, getDBData("ALIASES_FOR_VENUE"), false);
        at(venueDetailPage);
        String url = String.format(getConfig("BASE_URL") + "/venue");
        Assert.assertTrue(getDriver().getCurrentUrl().contains(url),
                "Expected: " + url + " Actual: " + getDriver().getCurrentUrl());
        Assert.assertTrue(venueDetailPage.venueProfile.isDisplayed());

    }

    @Test(priority = 3, groups = "P2", description = "RPX-10119 Validating alias page navigation of type Judge ")
    public void checkJudgeAliasesPageNavigation() throws Exception {
        to(aliasesPage, getDBData("ALIASES_FOR_JUDGE"), false);
        at(judgeDetailPage);
        String url = String.format(getConfig("BASE_URL") + "/judge");
        Assert.assertTrue(getDriver().getCurrentUrl().contains(url),
                "Expected: " + url + " Actual: " + getDriver().getCurrentUrl());
        Assert.assertTrue(judgeDetailPage.judgeProfile.isDisplayed());
    }

    @Test(priority = 4, groups = "P3", description = "RPX-10119 Validating aliases page with invalid id")
    public void checkAliasesPageNavigationWithInvalidId() throws Exception {
        to(aliasesPage, "85963249", false);
        at(PageNotFoundPage.class);
        String url = String.format(getConfig("BASE_URL") + "/aliases/85963249");
        Assert.assertEquals(getDriver().getCurrentUrl(), url);
    }
    @Test(priority = 5, groups = "P3", description = "Validating aliases page with aliases without entity | RPX-7648,RPX-10119")
    public void checkAliasesPageNavigation() throws Exception {
        String aliasid=getDBData("ALIASES_WITHOUT_ENTITY");
        to(aliasesPage, aliasid);
        String url = String.format(getConfig("BASE_URL") + "/aliases/" + aliasid);
        Assert.assertEquals(getDriver().getCurrentUrl(), url);
        Assert.assertTrue(((String) aliasesPage.aliases.getText())
                .contains("This entity has not yet been matched to the RPX corporate hierarchy"));
    }
}
