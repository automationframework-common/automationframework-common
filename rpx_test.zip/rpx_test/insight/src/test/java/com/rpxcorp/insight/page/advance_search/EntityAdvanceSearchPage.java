package com.rpxcorp.insight.page.advance_search;

import com.rpxcorp.insight.module.AutoComplete;
import com.rpxcorp.insight.module.CheckList;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

import java.util.Map;

public class EntityAdvanceSearchPage extends AdvanceSearchPage {
    public EntityAdvanceSearchPage() {
        this.url = new PageUrl("advanced_search#entityTab");
    }
    public final AutoComplete entityName = $("#ent_name", AutoComplete.class);
    public final CheckList entityType = $("div:has(>.entity-types)",CheckList.class);
    public final CheckList marketSector = $("div:has(>.market-sectors)", CheckList.class);
    public final Element npeCheckbox = $(".entity-types label:contains('NPE') input:enabled");
    public final Element npeCheckboxLabel = $(".entity-types label:contains('NPE')");

    @Override
    public boolean at() {
        return entityName.waitUntilVisible();
    }

    public void search(Map<String, Object> data) {
        entityName.inputText(data.get("Entity"));
        entityType.select(data.get("Entity Type"));
        marketSector.select(data.get("Market Sector"));
        submitButton.click();
    }

    public void mouseOverNPEOption(){
        entityType.seeMore();
        npeCheckboxLabel.moveTo(1,1);
        tooltip.waitUntilVisible();
    }

}
