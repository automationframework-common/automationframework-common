package com.rpxcorp.insight.page.detail;


import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;

public class ChinesePRBJudgeDetailPage extends BaseDetailPage{
    public ChinesePRBJudgeDetailPage() {
        this.url = new PageUrl("china_prb/judges/{ID}");
    }

    public final Element pageTitle = $(".header-name .section-title:visible");
    public final Element sectionTitle = $(
            ".block-header h5.section-title");
    public final Element reexamSectionCaseCount=$("#litigation-cases div.row.margin-0:has(h5.sub-section-title:contains('Total PRB Reexaminations'))");
    public final Element InactiveReexamSectionCaseCount=$("#litigation-cases div.row.margin-0:has(h5.sub-section-title:contains('Inactive PRB Reexaminations'))");
    public final StaticContent metricsSection = $(".panel-metrics", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("inactiveCasesCount", ".metrics_card:contains(Inactive Cases) .count");
            }
    );
    public final Table reexamination_Section = $("#litigations-container .venue_judge_case_table", (Configure<Table>) table ->
            {
                table.uniqueId("td.case_title a");
                table.nextPage("div#litigation-cases ul.pagination.pagination li:last-child");
                table.lastPage("div#litigation-cases ul.pagination.pagination li:nth-last-child(2)");
            }
    );
}
