package com.rpxcorp.insight.test.data;

import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.rpxcorp.insight.page.intelligence.NPE_ProfilePage;
@Authenticate(role = "MEMBER")
public class NPEProfileTest extends BaseDataTest {
    NPE_ProfilePage npeProfilePage;

    @BeforeClass
    public void navigateIPRPage() {
        this.dataDescription = "NPE Profile Page";
        this.dataUrl = npeProfilePage.getDeclaredUrl();
         to(npeProfilePage);
    }

    @Test(description = "Verify NPE Profiles Table Data", priority = 2)
    public void NPE_Profile_Table_Data() throws Exception {
        assertEquals(npeProfilePage.NPE_table.getData(), sqlProcessor.getResultData("Intelligence.NPE_PROFILES"));
    }

}
