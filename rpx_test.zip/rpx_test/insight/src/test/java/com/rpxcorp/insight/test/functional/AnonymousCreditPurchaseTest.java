package com.rpxcorp.insight.test.functional;

import com.mailosaur.model.Email;
import com.mailosaur.model.Link;
import com.rpxcorp.insight.page.HomePage;
import com.rpxcorp.insight.page.LoginPage;
import com.rpxcorp.insight.page.LoginPage.ROLES;
import com.rpxcorp.insight.page.account.MyAccountPage;
import com.rpxcorp.insight.page.account.ProfilePage;
import com.rpxcorp.insight.page.account.TermOfServicePage;
import com.rpxcorp.insight.page.account.UsersAddToWhiteListPage;
import com.rpxcorp.insight.page.payment.*;
import com.rpxcorp.oldtest.page.DBData;
import com.rpxcorp.oldtest.util.EmailApiUtil;
import com.rpxcorp.testcore.util.BraintreeUtil;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.ExcelUtil;
import org.testng.Assert;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

public class AnonymousCreditPurchaseTest extends BaseFuncTest {

    UsersAddToWhiteListPage whiteListPage;
    FeatureMatrixPage featureMatrixPage;
    DocumentCreditLogin documentCreditLogin;
    DocumentCreditCreateAccount documentCreditCreateAccount;
    AddCreditPage addCreditPage;
    MyAccountPage myAccountPage;
    CreditPurchaseSuccessPage creditPurchaseSuccessPage;
    HomePage homePage;
    LoginPage loginPage;
    ProfilePage profilePage;

    DBData db = new DBData();
    Date date = new Date();
    SoftAssert softAssert;
    SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM d, yyyy", Locale.US);
    ExcelUtil testData = new ExcelUtil(ConfigUtil.config().get("testResourcesDir") + "/test_data/DocumentCredit.xls");

    private Map<String, String> purchaseDetails, purchaseSummaryAfterPayment;
    private String confirmationLink, purchaseDate, currentUrl;

    /** SUCCESSFUL ANONYMOUS CREDIT PURCHASE TESTS **/
    @BeforeGroups(groups = "anonymous_credit_purchase")
    public void preActionsForCreditPurchase() throws Exception {
        String[] emailIDs = testData.getAllDataFromColumn("AnonymousCreditPurchase", "mail_id");
        addToWhiteList(emailIDs);

        ExcelUtil testData = new ExcelUtil(
                ConfigUtil.config().get("testResourcesDir") + "/test_data/DocumentCredit.xls");
        purchaseDetails = testData.getDataAsMap("AnonymousCreditPurchase", 1, 2);
    }

    @AfterGroups(groups = { "anonymous_credit_purchase", "anonymous_credit_purchase_failure", "login_form_validation",
            "signup_form_add_credit" })
    public void logoutAfterPurchase() {
        loginPage.logout();
    }

    @Test(priority = 1, groups = { "anonymous_credit_purchase",
            "anonymous_credit_purchase_failure" }, description = "Anonymous credit purchase - delete user from portal")
    public void deleteUserAndLogout() throws Exception {
        deleteUser(purchaseDetails.get("mail_id"));
        logout();
        EmailApiUtil.deleteRecipientEmails(purchaseDetails.get("mail_id"), 5000);
    }

    @Test(priority = 2, groups = { "anonymous_credit_purchase",
            "anonymous_credit_purchase_failure" }, description = "Anonymous credit purchase - Verify navigation to login form  on clicking purchase button in options page")
    public void verifyLoginPageNavigation() {
        to(featureMatrixPage);
        featureMatrixPage.docPurchaseBtn.click();
        at(documentCreditLogin);
    }

    @Test(priority = 3, groups = { "anonymous_credit_purchase",
            "anonymous_credit_purchase_failure" }, description = "Anonymous credit purchase - Verify sign up form navigation from login form")
    public void verifyCreateAccountNavigation() {
        documentCreditLogin.createANewOneLink.click();
        at(documentCreditCreateAccount);
    }

    @Test(priority = 4, groups = { "anonymous_credit_purchase",
            "anonymous_credit_purchase_failure" }, description = "Anonymous credit purchase - Verify create account with valid details in sign up form")
    public void verfiyCreateAccount() {
        softAssert = new SoftAssert();
        documentCreditCreateAccount.enterSignUpInformation(purchaseDetails.get("first_name"),
                purchaseDetails.get("last_name"), purchaseDetails.get("mail_id"), purchaseDetails.get("password"));
        documentCreditCreateAccount.continueBtn.click();
        at(addCreditPage);
        softAssert.assertEquals(addCreditPage.timeline_bar.isPresent(), false, "Time line bar is displayed");
        softAssert.assertAll();
    }

    @Test(priority = 5, groups = { "anonymous_credit_purchase",
            "anonymous_credit_purchase_failure" }, description = "Anonymous credit purchase - Verify that confirmation mail is received after sign up")
    public void verifyConfirmationLinkFromMail() throws Exception {
        // READING FROM LATEST RECIEVED MAIL FOR CONFIRMATION LINK
        Email[] confirmationEmail = EmailApiUtil.getRecipientEmails(purchaseDetails.get("mail_id"));
        Link[] confirmationEmailLinks = confirmationEmail[0].html.links;
        confirmationLink = confirmationEmailLinks[0].toString();
        Assert.assertTrue(confirmationLink.contains("confirmation?confirmation_token"),
                "Confirmation link is not as expected: " + "Actual link from mail: " + confirmationLink);
        EmailApiUtil.deleteRecipientEmails(purchaseDetails.get("mail_id"), 3000);
    }

    @Test(priority = 6, groups = "anonymous_credit_purchase", description = "Anonymous credit purchase - Verify add credit with valid information")
    public void verfiyAddCredit() throws Exception{
        softAssert = new SoftAssert();
        addCreditPage.loading.waitUntilInvisible();
        softAssert.assertEquals(addCreditPage.timeline_bar.isPresent(), false, "Time line bar is displayed");
        addCreditPage.purchaseCredits(purchaseDetails);
        at(creditPurchaseSuccessPage);
        creditPurchaseSuccessPage.loading.waitUntilInvisible();
        softAssert.assertEquals(false, creditPurchaseSuccessPage.timeline_bar.isPresent(),
                "Time line bar is displayed");
        softAssert.assertAll();
    }

    @Test(priority = 7, groups = "anonymous_credit_purchase", description = "Anonymous credit purchase - Verify summary in thank you page after successful document credit purchase")
    public void verifySummaryAfterSuccessfulPurchase() {
        softAssert = new SoftAssert();
        purchaseSummaryAfterPayment = creditPurchaseSuccessPage.purchaseSummary.getData();
        purchaseDate = creditPurchaseSuccessPage.purchaseDate.getText();
        String confirmationMessage = creditPurchaseSuccessPage.activateMessage.getText();
        currentUrl = getDriver().getCurrentUrl();
        // CONFIRMATION MESSAGE VALDIATION
        softAssert.assertTrue(
                confirmationMessage
                        .contains("Please go activate your account via the link sent to the registered email"),
                "Message for user to confirm account is not as expected, Actual: " + confirmationMessage);

        // PURCHASE SUMMARY VALDIATION
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        softAssert.assertEquals(purchaseDate, dateFormat.format(date),
                "Purchase date is not expected" + " Actual: " + purchaseDate + " Expected: " + dateFormat.format(date));
        softAssert.assertFalse(
                purchaseSummaryAfterPayment.get("confirmation_number").replace("Confirmation Number: ", "").isEmpty(),
                "Confirmation number is empty");
        softAssert.assertEquals("Purchase Type: "+purchaseSummaryAfterPayment.get("purchase_type").trim().replaceAll("\n", ""),
                "Purchase Type: Document Credit Purchase",
                "Purchase Type is not as expected" + " Actual: " + purchaseSummaryAfterPayment.get("purchase_type"));
        softAssert.assertEquals("Amount Charged: "+purchaseSummaryAfterPayment.get("amount_charged").trim().replaceAll("\n", ""),
                "Amount Charged: $" + purchaseDetails.get("credit_amount"),
                "Amount charged is not as expected" + " Actual: " + purchaseSummaryAfterPayment.get("amount_charged")
                        + " Expected: " + "Amount Charged: $" + purchaseDetails.get("credit_amount"));
        softAssert.assertEquals(creditPurchaseSuccessPage.timelineStatusBar.isPresent(), false,
                "Time line bar is displayed");
        softAssert.assertAll();
    }

    @Test(priority = 8, groups = "anonymous_credit_purchase", description = "Anonymous credit purchase - Verify details in the transaction email with details in success page")
    public void verifyTransactionEmail() throws Exception {
        softAssert = new SoftAssert();
        Email[] email = EmailApiUtil.getRecipientEmails(purchaseDetails.get("mail_id"));
        String emailBody = email[0].text.body;

        softAssert.assertEquals(email[0].from[0].toString(), "RPX Insight <insight@rpxcorp.com>",
                "From address is not as expected " + "Actual from address in email: " + email[0].from[0].toString()
                        + " Expected: " + " RPX Insight <insight@rpxcorp.com>");
        softAssert.assertTrue(email[0].subject.contains("Document Credit Purchase Successful"),
                "Subject of the email is not as expected, Actual: " + email[0].subject);
        softAssert.assertTrue(emailBody.contains("Hello " + purchaseDetails.get("first_name")),
                "Salutation in not as expected, Actual email content: " + emailBody + " Expected : "
                        + purchaseDetails.get("first_name"));
        softAssert.assertTrue(emailBody.contains("Purchase Date:\r\n" + purchaseDate),
                "Purchase date is not as in success page, Actual email content: " + emailBody
                        + " Expected : Purchase Date:\r\n" + purchaseDate);

        String confNumberSummaryPage = purchaseSummaryAfterPayment.get("confirmation_number")
                .replace("Confirmation Number: ", "Confirmation Number:\r\n");
        softAssert.assertTrue(emailBody.contains(confNumberSummaryPage),
                "Confirmation Number is not as in success page, Actual email content: " + emailBody + " Expected: "
                        + confNumberSummaryPage);
        softAssert.assertTrue(emailBody.contains("Purchase Type:\r\nDocument Credit Purchase"),
                "Purchase type is not as in success page, Actual email content: " + emailBody + "Expected: "
                        + "Purchase Type:\r\nDocument Credit Purchase");

        String amountChargedSummaryPage = purchaseSummaryAfterPayment.get("amount_charged").replace("Amount Charged: ",
                "Amount Charged:\r\n");
        softAssert.assertTrue(emailBody.contains(amountChargedSummaryPage),
                "Amount charged is not as in success page, Actual email content: " + emailBody + " Expected: "
                        + amountChargedSummaryPage);
        softAssert.assertAll();
    }

    @Test(priority = 9, groups = "anonymous_credit_purchase", description = "Anonymous credit purchase - Verify login with the confirmation link after successful document credit purchase")
    public void verifyLoginWithConfirmationLink() {
        getDriver().get(confirmationLink);
        at(homePage);
        homePage.flashMsg.waitUntilTextPresent("Your account was successfully confirmed. You are now signed in.");
    }

    @Test(priority = 10, groups = "anonymous_credit_purchase", description = "Anonymous credit purchase - Verify credits in my accounts page after successful document credit purchase")
    public void verifyCreditInMyAccounts() throws Exception {
        to(myAccountPage);
        String purchasedBalanceAfterPurchase = myAccountPage.docCreditBalance.getData("purchased_balance").replace("$",
                "");
        assertEquals(purchasedBalanceAfterPurchase, purchaseDetails.get("credit_amount"),
                "Amount credited is not same as amount purchased, " + " Amount credited in profile tab: "
                        + purchasedBalanceAfterPurchase);
    }

    @Test(priority = 11, groups = "anonymous_credit_purchase", description = "Verify braintree side validations for credit purchase transaction")
    public void verifyTransactionAtBraintree() {
        String orderId = purchaseSummaryAfterPayment.get("confirmation_number").replace("Confirmation Number: ", "");
        Assert.assertEquals(BraintreeUtil.getTransactionStatus(orderId).get("AMOUNT"),
                purchaseSummaryAfterPayment.get("amount_charged").replace("$", "").replace("Amount Charged: ", ""));
        Assert.assertEquals(BraintreeUtil.getTransactionStatus(orderId).get("RESP_CODE"), "1000");
        Assert.assertEquals(BraintreeUtil.getTransactionStatus(orderId).get("STATUS"), "SUBMITTED_FOR_SETTLEMENT");
        Assert.assertEquals(BraintreeUtil.getTransactionStatus(orderId).get("COUNTRY_NAME"),
                purchaseDetails.get("country"));
        Assert.assertEquals(BraintreeUtil.getTransactionStatus(orderId).get("POSTAL_CODE"),
                purchaseDetails.get("postal_code"));
    }

    @Test(priority = 12, groups = "anonymous_credit_purchase", description = "RPX-10573 verify summary page is displayed after login in")
    public void verifySummaryPageAfterLogin() throws Exception {
        logout();
        getDriver().get(currentUrl);
        loginPage.errorPageLogin.click();
        loginPage.login_holder.waitUntilVisible();
        loginFromCurrentPage(purchaseDetails.get("mail_id"), purchaseDetails.get("password"));
        at(CreditPurchaseSuccessPage.class);
        logout();
    }

    @Test(priority = 13, groups = "anonymous_credit_purchase", description = "RPX-10573 verify dashboard page is displayed after login in with basic user from thank you page")
    public void verifyDashboardPageAfterLoginWithBasicUserFromThankyouPage() throws Exception {
        logout();
        getDriver().get(currentUrl);
        loginPage.errorPageLogin.click();
        loginPage.login_holder.waitUntilVisible();
        loginFromCurrentPageAs(ROLES.BASIC);
        at(homePage);
        logout();
    }

    /** UNSUCCESSFUL ANNONYMOUS CREDIT PURCHASE TESTS **/
    @BeforeGroups(groups = "anonymous_credit_purchase_failure")
    public void preActionsForCreditPurchaseFailure() throws Exception {
        String[] emailIDs = testData.getAllDataFromColumn("AnonymousCreditPurchase", "mail_id");
       addToWhiteList(emailIDs);

        ExcelUtil testData = new ExcelUtil(
                ConfigUtil.config().get("testResourcesDir") + "/test_data/DocumentCredit.xls");
        purchaseDetails = testData.getDataAsMap("AnonymousCreditPurchase", 1, 3);
    }

    @Test(priority = 14, groups = "anonymous_credit_purchase_failure", description = "Anonymous credit purchase - Verify add credit with invalid information for failure")
    public void verifyAddFailureCredit() throws Exception{
        softAssert = new SoftAssert();
        addCreditPage.loading.waitUntilInvisible();
        softAssert.assertEquals(addCreditPage.timeline_bar.isPresent(), false, "Time line bar is displayed");
        addCreditPage.purchaseCredits(purchaseDetails);
        softAssert.assertTrue(addCreditPage.paymentErrorMsg.isDisplayed(),
                "Error message for invalid payment details is not displayed");
        softAssert.assertAll();
    }

    @Test(priority = 15, groups = "anonymous_credit_purchase_failure", description = "Anonymous credit purchase - Verify login with the confirmation link after document credit purchase failure")
    public void verifyLoginWithConfirmationLinkAfterFailure() {
        getDriver().get(confirmationLink);
        at(homePage);
        homePage.flashMsg.waitUntilTextPresent("Your account was successfully confirmed. You are now signed in.");
    }

    @Test(priority = 16, groups = "anonymous_credit_purchase_failure", description = "Anonymous credit purchase - Verify credits in my accounts page after document credit purchase failure")
    public void verifyCreditInMyAccountsAfterFailure() throws Exception {
        to(myAccountPage);
        String purchasedBalanceAfterPurchase = myAccountPage.docCreditBalance.getData("purchased_balance").replace("$",
                "");
        assertEquals(purchasedBalanceAfterPurchase, "0.00", "Amount is not $0.00 in profile tab, "
                + " Amount credited in profile tab: " + purchasedBalanceAfterPurchase);
    }

    /** LOGIN FORM VALIDATION TESTS **/
    @AfterMethod(groups = "login_signup_credit_purchase")
    public void logoutAfterMethod() {
    	loginPage.logout();
    }

    @Test(priority = 101, groups = "login_signup_credit_purchase", description = "Anonymous Credit Login Form - Verify invalid password error message and contents of URL")
    public void verifyLoginFromAnonymousPurchaseverifyInvalidPasswordFromLoginform() {
        softAssert = new SoftAssert();
        navigateToDocumentCreditLogin();
        loginPage.login("auto_basic1@rpxcorp.com", "invalid");
        documentCreditLogin.paymentLoginError.waitUntilVisible();
        String loginError = documentCreditLogin.paymentLoginError.getText().trim();

        softAssert.assertEquals(loginError, "Invalid email or password.",
                "Error displayed for invalid password is not expected, " + "Actual error displayed: " + loginError);
        softAssert.assertFalse(getDriver().getCurrentUrl().contains("invalid"),
                "Url after invalid password displays the entered password, " + "Actual URL: "
                        + getDriver().getCurrentUrl());
        softAssert.assertAll();
    }

    //Not needed since login form is same throughout the application
//    @Test(priority = 102, groups = "login_signup_credit_purchase", description = "Anonymous Credit Login Form - Verify forgot password link navigation")
//    public void verifyForgotPasswordFromLoginForm() {
//        to(documentCreditLogin);
//        documentCreditLogin.forgotPasswordLink.click();
//        at(ForgetPasswordPage.class);
//    }

    @Test(priority = 103, groups = "login_signup_credit_purchase", description = "Anonymous Credit Login Form - Verify that user(document credit purchase applicable) is directed to add credit page on login")
    public void verifyLoginFromAnonymousPurchase() {
        to(documentCreditLogin);
        loginPage.login("auto_basic1@rpxcorp.com", "Welcome1");
        at(addCreditPage);
        addCreditPage.loading.waitUntilInvisible();
    }

    /** SIGN UP FORM VALIDATION TESTS **/
    @Test(priority = 105, groups = "login_signup_credit_purchase", description = "Anonymous Credit Signup Form - Verify continue without entering info in sign up form")
    public void verifySignUpWithoutInfo() {
        to(documentCreditCreateAccount);
        documentCreditCreateAccount.continueBtn.click();
        at(DocumentCreditCreateAccount.class);
    }

    @Test(priority = 106, groups = "login_signup_credit_purchase", description = "Anonymous Credit Signup Form - Verify terms of condition link navigation from sig up form")
    public void verifyTermsOfConditionLinkNavigation() throws Exception {
        to(documentCreditCreateAccount);
        withNewWindow(documentCreditCreateAccount.termsOfService, () -> {
            at(TermOfServicePage.class);
        });
    }

    // @Test(priority = 107, groups = "login_signup_credit_purchase",
    // description = "Anonymous Credit Signup Form - Verify that linked-in user
    // is directed to add credit page on login")
    public void verifyLinkedInLogin() {
        to(documentCreditCreateAccount);
        loginFromCurrentPageAs(ROLES.LINKEDIN);
        at(AddCreditPage.class);
    }

    @Test(priority = 108, groups = "login_signup_credit_purchase", description = "Anonymous Credit Signup Form - Verify that user is directed to login form from sign up from login here link")
    public void verifyLoginFormNavigationFromSignUp() {
        to(documentCreditCreateAccount);
        documentCreditCreateAccount.loginHereLink.click();
        loginPage.login_btn.waitUntilVisible();
    }

private void navigateToDocumentCreditLogin(){
    to(documentCreditLogin);
}

}