package com.rpxcorp.insight.page;

import org.openqa.selenium.By;

import com.rpxcorp.insight.module.Table;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class LitigationCaseTypesPage extends BasePage {

	public LitigationCaseTypesPage() {
		this.url = new PageUrl("lits/ctype");
	}

	@Override
	public boolean at() {		
		return title.waitUntilVisible();
	}

	public final Element title = $(".large-12.columns>h1");
	public final Table litTypesTable = new Table(".large-12.columns.table-expand");	

	public String getCaseTypeDescription(String caseType) {
		return $(By.xpath("//table/tbody//td/a[contains(text(),'" + caseType + "')]/../../td[2]")).getText();
	}

	public Element caseTypeLink(String caseType) {
		return $(By.xpath("//table/tbody//td/a[contains(text(),'" + caseType + "')]/../../td[2]"));
	}
}
