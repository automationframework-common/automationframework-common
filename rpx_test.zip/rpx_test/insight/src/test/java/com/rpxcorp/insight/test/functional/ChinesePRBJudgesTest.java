package com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.DocketEntryPage;
import com.rpxcorp.insight.page.detail.ChinesePRBDetailPage;
import com.rpxcorp.insight.page.detail.ChinesePRBJudgeDetailPage;
import com.rpxcorp.insight.page.detail.EntityDetailPage;
import com.rpxcorp.insight.page.detail.PatentDetailPage;
import com.rpxcorp.oldtest.page.DBData;
import com.rpxcorp.testcore.Authenticate;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.sql.ResultSet;
import java.util.ArrayList;

@Authenticate(role = "MEMBER")
public class ChinesePRBJudgesTest extends BaseFuncTest {
    ChinesePRBJudgeDetailPage chinesePRBJudgePage;
    ResultSet intialExpectedTableValue;
    String dataId, dataUrl;
    DBData db = null;
    String id = null;
    ChinesePRBDetailPage chinesePRBDetailPage;
    EntityDetailPage entityDetailPage;
    PatentDetailPage patentDetailPage;
    DocketEntryPage docketPage;
    SoftAssert softAssert;

    @BeforeClass
    public void navigateJudgePage() throws Exception {
        db = new DBData();
    }
    /**
     * STATS SECTION
     **/

    @Test(priority = 100, groups = {"P2", "smoke"}, description = "RPX-15982 Chinese PRB Judge Details Page - Part 1 - Stats")
    public void verifySectionInPRBJudgePage() throws Exception {
        String title[] = {"PRB Reexaminations"};//"Judge Profile","Cases by Market Sector"
        to(chinesePRBJudgePage, 1029226);
        chinesePRBJudgePage.metricsSection.isDisplayed();
        chinesePRBJudgePage.sectionTitle.waitUntilVisible();
        ArrayList<String> sectionHeader = chinesePRBJudgePage.sectionTitle.getAllData();
        assertTrue(sectionHeader.get(0).contains(title[0]),
                "Title of Reexamination section didn't match, Actual: " + sectionHeader.get(0) + "Expected: " + title[0]);
    }
    @Test(priority = 101, groups = "P2", description = "RPX-15982 Chinese PRB Judge Details Page - Part 1 - Stats")
    public void verifyPRBJudgePageTitle() throws Exception {
        assertEquals(getTitle().contains(chinesePRBJudgePage.detailPageTitle.getText()), true,
                "Title of Page didn't match with Judge Name");
    }
    @Test(priority = 102, groups = "P2", description = "Verify Chinese PRB Reexamination metrics")
    public void verifyPRBStaticsVsSectionsStatistics() throws Exception {
        to(chinesePRBJudgePage, 1821866);
        chinesePRBJudgePage.metricsSection.getElement("inactiveCasesCount").click();
        chinesePRBJudgePage.waitForLoading();
        assertEquals(chinesePRBJudgePage.metricsSection.getIntData("inactiveCasesCount"), chinesePRBJudgePage.InactiveReexamSectionCaseCount.getIntData(), "The Metrics Section in 'INACTIVE CASES' count is not matching with Reexamination Section Inactive Cases Count");
    }
    /**
     * REEXAMINATION SECTION
     **/

    @BeforeGroups(groups = "PRB_judges_reexamination_section")
    public void loadReexaminationSectionData() {
        to(chinesePRBJudgePage, 1029226);
        at(chinesePRBJudgePage);
    }
    @Test(priority = 301, groups = {"P2", "PRB_judges_reexamination_section"}, description = "Validate reexamination section table header")
    public void verifyReexaminationTableHeader() throws Exception {
        String expHeader[] = {"Decision Date", "Case Name", "Decision Number"};
        chinesePRBJudgePage.reexamination_Section.waitUntilVisible();
        assertEquals((chinesePRBJudgePage.reexamination_Section.getHeaderData()), (expHeader),
                "Reexamination table header is not as expected");
    }
    @Test(priority = 302, groups = {"P2", "PRB_judges_reexamination_section"}, description = "Validate reexamination section case name link")
    public void verifyCaseNameLinkInReexaminationTable() throws Exception {
        String caseNameInColumn = chinesePRBJudgePage.reexamination_Section.getColumnLinkText("Case Name");
        withNewWindow(chinesePRBJudgePage.reexamination_Section.getColumnLinkElem("Case Name"), () -> {
            at(chinesePRBDetailPage);
            String caseNameDetailsPage = chinesePRBDetailPage.detailPageTitle.getText();
            Assert.assertTrue(caseNameDetailsPage.contains(caseNameInColumn),
                    "case name in table is not equal to details page case name");
        });
    }
    @Test(priority = 303, groups = {"P2", "PRB_judges_reexamination_section"}, description = "Validate reexamination section case number link")
    public void verifyCaseNumberLinkInReexaminationTable() throws Exception {
       String caseNoInColumn = "Decision: "+chinesePRBJudgePage.reexamination_Section.getColumnLinkText("Decision Number");
        withNewWindow(chinesePRBJudgePage.reexamination_Section.getColumnLinkElem("Decision Number"), () -> {
            at(chinesePRBDetailPage);
            String caseNoDetailsPage = chinesePRBDetailPage.subheading.getData("Decision_Number");
            Assert.assertEquals(caseNoDetailsPage, caseNoInColumn,
                    "case number in table is not equal to details page Decision number");
        });
    }
    @BeforeGroups(groups = "PRB_judges_reexamination_section_sort")
    public void loadJudgeWithReexaminationForSort() {
        to(chinesePRBJudgePage, 1029226);
    }
    @Test(priority = 350, groups = {"P4", "PRB_judges_reexamination_section_sort","func_sorting"}, description = "Validate 'Decision date' desc as default sort in reexamination section [RPX-16185]")
    public void verifyDefaultSortInReexaminationTable() {
        assertColumnSort("date", "desc", chinesePRBJudgePage.reexamination_Section.getColumn("Decision Date"));
    }
    @Test(priority = 351, groups = {"P4", "PRB_judges_reexamination_section_sort","func_sorting"}, description = "Validate reexamination section all case sorting", dataProvider = "reexaminationsTableSortData")
    public void verifyAllCasesSortingInreexaminationTable(String columnName, String sortType, String dataType)
            throws Exception {
        chinesePRBJudgePage.reexamination_Section.sort(columnName);
        assertColumnSort(dataType, sortType, chinesePRBJudgePage.reexamination_Section.getColumn(columnName));
    }
    @DataProvider
    public Object[][] reexaminationsTableSortData() {
        return new Object[][] { { "Decision Date", "asc", "date" }, { "Decision Date", "desc", "date" },
                { "Case Name", "asc", "non-date" }, { "Case Name", "desc", "non-date" },
                { "Decision Number", "asc", "non-date" }, { "Decision Number", "desc", "non-date" }
        };
    }
}
