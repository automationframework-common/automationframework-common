package com.rpxcorp.insight.page.detail;

import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CampaignDetailPage extends BaseDetailPage {

	public CampaignDetailPage() {
		this.url = new PageUrl("litigation_campaign/{ID}");
	}

	@Override
	public boolean at() {
		waitForPageLoad();
		return detailPageTitle.isPresent();
	}


	public final Element campaign_overview_cms=$("div.campaign-overview p:not(:empty)");  //div[@class='async_campaign_info']//p[text()]
	public final Element plaintiff_overview_cms=$("div#plaintff_list_container .async_campaign_info > .async_content:has(p):not(:empty)");
	public final Element patentCampaign_overview_cms=$("div.patents-in-campaign .async_campaign_info > .async_content:has(p):not(:empty)");
	public final Element campaign_overview_promomsg = $("div.campaign-overview div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element plaintiff_overview_promomsg = $("div#plaintff_list_container div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element patentCampaign_overview_promomsg = $("div.patents-in-campaign div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element campaignPatentSection=$("#campaign_patents_section");
	public final Element campaignTitleNpeCallout = $("div.header-name .npe-indicator");
	public final Element campaignTitlePtabCallout = $("div.header-name span.ptab-tag");
	public final Element campaignTitleSCCallout = $("div.header-name span.sc_call_out");
	public final Element panel = $(".panel");
	public final Element itcTag= $(".itc-tag");
	public final Element initiatedDate = $("#content .details.subtitle>li:contains('Initiated')");
	public final Element plantiffCounselTitle=$("#plaintff_list_container .res-header-font div:contains('Plaintiffs')");
	public final Element campaignPatentWithNoData=$("div[class*='patents']");
	public final Element venueUSMap=$(".venue-title:contains('Venues')+div#venus_map_renderer");
	public final Element venueChinaMap = $(".venue-title:contains('Venues')+div#cn_venus_map_renderer");
	public final Element campPetition=$("#campaign_petitions_section");
	public final Element campaignDetailHeading = $(".small-12.columns.title-area>h1");
	public final Element caseViewTab = $("a#case_overview_tab_link");
	public final Element accusedProductTab = $("a#accused_product_link");
	public final Element patentGridTab = $("a[data-behavior='patent_grid_tab']");//dd:has(a:contains('Patent Grid'))
	public final Element campaignOverviewSection=$("div.campaign-overview");
	public final Element defendantTab = $(".campaign-overview dd #overview_table_tab_link");
	public final Element defendantSearchBox = $("#campaign_defendants_filter input");
	public final Element subTitle = $(".inline-list.subtitle li:nth-child(1)");
	public final Element status = $(".title-area h1 span:last-child");
	public final Element overViewChart=$("#overview_chart");
	public final Element venuesChart=$(".venues #venus_map_renderer");
	public final Element chinaVenuesChart=$("div#cn_venus_map_renderer");
	public final Element cmsContent=$(".async_campaign_info");
	public final Element viewAllVisible=$("#campaign_patents_section  a.view-all[style='display: none;']");
	//	public final Element campaignMetricsSectionCount=$(".metrics .panel li span");
	public final Element patentSectionTitle=$("a#patents_in_suit_tab_link");
	public final Element timelineTab=$("#overview_chart_tab_header>a[href='#overview_chart']");
	public final Element defendantTabitcCallout=$("#campaign_defendants tr.odd:first-child  td:first-child a+a");
	public final Element defendantParentLink=$("#campaign_defendants tr:nth-of-type(1)>td>span:nth-of-type(1)>a:not([class='span_left'])");
	public final Element timeLineAssignment=$("div[class*='TS-series_legend_item_Assignments']");
	public final Element timeLineLitigations=$("div[class*='TS-series_legend_item_Litigations']");
	public final Element timeLinePrevious=$(".TS-choose.TS-choose_prev");
	public final Element timeLineNext=$(".TS-choose.TS-choose_next");
	public final Element timeLineAssignmentField=$(".TS-notch_Assignments.TS-notch_color_1.TS-notch_active");
	public final Element timeLineAssignmentCheckbox=$(".TS-series_legend_swatch.TS-series_legend_swatch_1");
	public final Element timeLineYear=$(".TS-notchbar_container .TS-year_notch");

	public final Element searchCompany=$("#company_name");
	public final Element overviewCompany=$("div.highcharts-axis-labels span.has-tip");//.highcharts-axis-labels.highcharts-xaxis-labels span
	public final Element sortDefault=$("#campaign_chart_sort option[selected='selected']");
	public final String chartXAxis="#render_campaign_overview_chart .highcharts-series.highcharts-tracker rect";
	public final Element selectDefendantSort=$("#campaign_chart_sort option[value='name']");
	public final Element exportBtn =$("a[data-behavior='download_campaign_timeline']>span:contains('Export')");

	public final Element defendantActiveCase=$("#cases_type_active");
	public final Element defendantInactiveCase=$("#cases_type_inactive");
	public final Element defendantAllcases=$("#cases_type_all");
	
	//Related Entity Text -Authorization
	public final Element plaintiff_relatedEntity=$(By.xpath("//*[@class='plaintiff']//div[contains(text(),'Related to Parent Entity')]"));
	public final Element itcCalloutDefendantTimeline = $("div#render_campaign_overview_chart span[class='itc_call_out']"); //#render_campaign_overview_chart a[class='itc_call_out']
	public final Element ptabCalloutDefendantTimeline = $("div#render_campaign_overview_chart span[class='ptab_call_out']");	//#render_campaign_overview_chart a[class='ptab_call_out']
/*		public final StaticContent overviewPanel = $(".panel-metrics", (Configure<StaticContent>) dataForm ->
		{
			dataForm.content("Case Count", "div.columns:contains(Cases in Campaign) .metrics-round-shape");
			dataForm.content("Petitions Count", "div.columns:contains(Petitions in Campaign) .metrics-round-shape");
			dataForm.content("Defendants Count", "div.columns:contains(Defendants in):contains(Campaign) .metrics-round-shape");
			dataForm.content("Defendants Terminated Count", "div.columns:contains(Defendants):contains(Terminated) .metrics-round-shape");
			dataForm.content("Patents Count", "div.columns:contains(Patents in Campaign) .metrics-round-shape");
		}
	);*/

			public final StaticContent overviewPanel = $(".panel-metrics", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("Case Count", "div.metrics_card:contains(Cases in Campaign) .count");
				dataForm.content("Appeals count ", "div.metrics_card:contains(Appeals in Campaign) .count");  //Recently Added
                dataForm.content("Petitions Count", "div.metrics_card:contains(Petitions in Campaign) .count");
                dataForm.content("Defendants Count", "div.metrics_card:contains(Defendants in Campaign) .count");
                dataForm.content("Defendants Terminated Count", "div.metrics_card:contains(Defendants Terminated) .count");
                dataForm.content("Patents Count", "div.metrics_card:contains(Patent):contains(in Campaign) .count");
            }
        );
	public final Table patent_table = $("table.patents-in-campaign ", (Configure<Table>) table ->
		{
			table.viewAllLink("#campaign_patents_section  a.view-all");
			table.uniqueId(" td.patnum span>span.hide");
			table.subTable(new Table(".timeline-placeholder"));
			table.expandSubTableLink("tr:nth-of-type(1) .button.small.secondary.timeline_toggles.timeline_hidden");
		}
	);


	public final Table case_table = $("#case_overview_table table.litigations_table", (Configure<Table>) table ->
		{
			table.viewAllLink("#case_overview_table a.view-all");
			table.uniqueId(" td:nth-child(2) a[href] ");
		}
	);

	public final Table caseTable = $("#case_overview_table table", (Configure<Table>) table ->
		{
			table.viewAllLink("#case_overview_table a.view-all");
			table.row("tbody tr");
		}
	);

	public final Tabs campaignOverviewTabs = new Tabs("div.campaign-overview dl dd");

	public void selectPatentGrid(){
		campaignOverviewTabs.select("Patent Grid");
		waitForPageLoad();
	}

	public final Element defendantTabLink = $("#overview_table_tab_link");
	public final Table defendant_table = $("#campaign_defendants", (Configure<Table>) table ->
		{
			table.uniqueId("td:nth-child(1)>a:last-child");
			table.viewAllLink(".campaign_defendants a.view-all");			
			table.row("table#campaign_defendants>tbody>tr[role='row']");
			table.subTable($(".nested_inner_table", (Configure<Table>) subTable ->
				{
					subTable.uniqueId("td:not([style*='hidden']):nth-child(3) a[href]");
				}));
			table.expandSubTableLink("img.open");
		}
	);
	
	
	public final Element accusedProductsTabLink = $("#accused_product_link");
	public void selectAccusedProductsTab() {
        if (accusedProductsTabLink.isDisplayed()) {
            accusedProductsTabLink.click();
            waitForPageLoad();
        }
    }
	public final Table accusedProductTable = $("#related_accused_products_table", (Configure<Table>) table ->
		{			
			table.uniqueId("td:nth-child(2) a[href]");
			table.displayedRecords("#campaign_accused_products tbody tr:not([style*='none'])");
			table.viewAllLink(By.xpath("//div[@id='campaign_accused_products']//a[text()='View All']"));
			table.viewLessLink(By.xpath("//div[@id='campaign_accused_products']//a[text()='View Less']"));
		}
	);
	public final Element defendantLinkInAccusedProducts = $("#campaign_accused_products tbody tr td a");
	public final Element noAccusedProductsMsg = $("#campaign_accused_products span");
	
	public final Element petitions_table = $(".related_petitions_table ", (Configure<Table>) table ->
		{
			table.viewAllLink(".related_petitions_table   a.view-all");
			table.uniqueId("td:nth-child(3) a[href]");
		}
	);
	public final Element plaintiff_table = $("#plaintff_list_container ", (Configure<Table>) table ->
		{
			table.viewAllLink("#plaintff_list_container a.view-all");
			table.uniqueId("h4 a[href]");
			table.column("plaintiff_ent_name", "h4 a[href]");
			table.column("counsel_details", ".plaintiff>div:not(.async_campaign_info):not(.subsidiary_info)");
			
			
		}
	);
	public final Element plaintiffNpeCallout = $(".plaintiff span.npe_tag.red");
	
	public final Table petitionerTable = $("#related_petitions_petitioners.active", (Configure<Table>) table ->
		{
			table.row("div.handle");
			table.uniqueId("div.handle>a[href]");
			table.expandSubTableLink("div.group.nested div.handle");
			table.subTable($("table.table_section", (Configure<Table>) subTable ->
				{
					subTable.uniqueId("td:nth-child(2) a[href]");
				}));
		}
	);

	public String getInitiatedDate() {
		if(initiatedDate.isDisplayed()) {
			return initiatedDate.getText();
		}
		else return "";
	}

	public final Table petitionPatentTable = $("#related_petitions_patents.active", (Configure<Table>) table ->
		{
			table.row("div.handle");
			table.uniqueId("div.handle>a");
			table.expandSubTableLink("div.group.nested div.handle");
			table.subTable($("table.table_section", (Configure<Table>) subTable ->
				{
					subTable.uniqueId("td:nth-child(2) a[href]");
				}));
		}
	);
	public final Table petitionsPetitionTable=new Table("#related_petitions_petitions");
	
	//SINGLE LCA
	public final Element singleLcaDownload = $("a[href*='/lca_reports/'] .icon-download-2");
	public final Element singleLcaUpdate = $("#lca-update-request-link>a");

	public final Element requestLCALink = $(By.xpath(".//*[@id='lca-new-request-link']/a[text()='Request for a Litigation Campaign Assessment']"));
	public final Element lcaRequest_link = $(".qtip-content a");
	public final Element lcaDownloadReport_link = $(".button[target='blank'][href*='/lca_reports']");
	public final Element lcaResponseModal = $("#request_response_modal");
	public final Element lcaResponseModal_message = $("#request_response_modal div");
	public final Element lcaResponseModal_close = $("#request_response_modal a");
	
	public final Element viewLCALink = $(By.xpath("//*[@id='lca-request-link']/a[text()='View Litigation Campaign Assessment Reports']"));
	public final Element lcaReportModal = $("#lca_report_modal");
	public final Element lcaReportModal_close = $("#lca_report_modal .close-reveal-modal");
	public final Element lcaReport_title = $("#lca_report_modal .modal-title");
	public final Element lcaReportDownload = $("#lca_report_modal .icon-download");
	public final Table lcaReportTable = new Table("#lca_report_modal table");
	public final Element defandantTabItcCallout=$("#campaign_defendants .itc_call_out");
	public final Element petitionersTabInPetition=$("#campaign_petitions_section dd:not([class*='active']) a[href='#related_petitions_petitioners']");
	public final Element petitionersAccordion=$("#related_petitions_petitioners .group.clear_styling.nested.collapsed:nth-of-type(1)");
	public final Element petitionersAccordionCount=$("#related_petitions_petitioners .group.clear_styling.nested .result-count");
	public final Table petitionersTable=new Table("#related_petitions_petitioners .group.clear_styling.nested table");
	public final Element petitionersAccordionHeader=$("#related_petitions_petitioners .handle>a");

	public final Element patentsTabInPetition=$("#campaign_petitions_section dd:not([class*='active']) a[href='#related_petitions_patents']");
	public final Element patentsAccordion=$("#related_petitions_patents .group.clear_styling.nested.collapsed:nth-of-type(1)");
	public final Element patentsAccordionCount=$("#related_petitions_patents .group.clear_styling.nested .result-count");
	public final Table patentsTable=new Table("#related_petitions_patents .group.clear_styling.nested table");
	public final Element patentsAccordionHeader=$("#related_petitions_patents .handle>a");
	public final Element campPetitionCollapsed=$("#campaign_petitions_section.group.active.clear_styling.collapsed");
	public final Element campaignPetitionSection=$("#campaign_petitions_section .handle");
	public final Element campaignPetitionsWithoutData=$("#related_petitions_petitions>span");
	public final Element campaignPetitionersWithoutData=$("#related_petitions_petitioners>span");
	public final Element campaignPatentsWithoutData=$("#related_petitions_patents>span");
	public final Element venueSectionsCount=$(".highcharts-series-group .highcharts-series.highcharts-tracker:nth-of-type(1) path");
	public final String venuesText=".highcharts-data-labels g:not([visibility='hidden']):nth-of-type(";
	public final Element venuesCasesCount=$(".highcharts-tooltip>span>span"); 

	//DEFENDANT TIMELINE SECTION for ELite and above userspatentInCampaignCAFCTag
	public final Element defendant = $("#s2id_defendant_name_filter");
	public final Element defendantStatus = $("#s2id_defendant_status_filter");
	public final Element judgeAndVenue = $("#s2id_judge_or_venue_name_filter");
	public final Element event = $("#s2id_document_type_filter");
	public final Element campaignTopMarker = $("#overview_chart g[className='campaign-top-marker']");

	//CAFC Tag in Campaign
    public final Element defendantTimelineCAFCTag = $("div#render_campaign_overview_chart span.cafc_call_out");
    public final Element defendantViewCAFCTag = $("table#campaign_defendants span.cafc_call_out");
	public final Element patentInCampaignCAFCTag = $("table.patents-in-campaign span.cafc_call_out");

    //CAFC Federal Opinion
	public final Element federalCircuit = $("#document_type_filter>option[value='all_fc']");
	public final Element federalCircuitOpinion = $("#document_type_filter>option[value='all_fc']");
	public final Element xAxisLabelName = $(".highcharts-axis-labels span[class='has-tip']");
	public final Element cafcTagCallOut = $(".highcharts-axis-labels .cafc_call_out");

	//CN Tag in Chinese Campaign
	public final Element defendantTimelineCNTag = $("div#render_campaign_overview_chart span.cn_call_out");
	public final Element defendantViewCNTag = $("table#campaign_defendants span.cn_call_out");
	public final Element patentGridCNTag = $("div#defendant_patent_grid span.cn_call_out");

	//DEFENDANT TIMELINE SECTION for others
	public final Element companyName = $("#company_name");
	public final Element campaignSort = $("#campaign_chart_sort");
	public final Element allOption = $("#cases_type option:contains('All')");
	public final Element activeOption = $("#cases_type option:contains('Active')");
	public final Element inactiveOption = $("#cases_type option:contains('Inactive')");
	public final Element campaign_section_SignOnMsg = $("//section[@id='content']//a[text()='Sign In']");
    public final Element campaign_section_UpgradeMsg = $("//section[@id='content']//a[text()='Start with a Free Trial']");

	public final Element plaintiffSectionShowAll=$("#plaintff_list_container a.show-all-counsel");
	public final Element plaintiffCounselInfo=$("div.counsel-content div.counsel-party:visible"); //#plaintff_list_container div[style='display: block;']
	public final Element plaintiffLinks=$(".plaintiff div:nth-child(1)>a");
	public final Element plaintiffLinksSub=$(".plaintiff div.subsidiary_info>a");
	public final Element plaintiffLinksCounselInfo=$(".plaintiff a[class]");
	public final StaticContent campaignHeader=$("div.header-name", (Configure<StaticContent>) dataForm ->
		{
			dataForm.content("NPE",".npe-indicator");
			dataForm.content("PTAB",".ptab-tag");
			dataForm.content("ITC",".itc-tag");
			dataForm.content("CAFC",".cafc-tag");
			dataForm.content("CN",".cn-tag");
			dataForm.content("Status",".status");
			dataForm.content("Date",".inline-list");
		}
	);

	public int getColumnCountWithValues()
	{
		int count = 0;
		List<String> columnValues=defendant_table.getColumn("End Date");
		for(String val:columnValues)
			if(!val.isEmpty())
				count=count+1;
		return count;		
	}
	public final Table petitiontable = $("#related_petitions_petitions", (Configure<Table>) table ->
		{
			table.viewAllLink("#related_petitions_petitions a.view-all.no-border:contains(View All)");
			table.viewLessLink("#related_petitions_petitions a.view-all.no-border:contains(View Less)");
			table.displayedRecords("#related_petitions_petitions tbody tr:not([style*='none'])");
		}
	);
	public void selectDefendantTab() {
		defendantTabLink.waitUntilVisible();
		defendantTabLink.click();
		waitForPageLoad();
		defendant_table.waitUntilVisible();
	}



	// TODO Make this code generic with jquery selector concept
	public void expandAlldefandant() {
		if (defendant_table.isDisplayed()) {
			if(!defendant_table.subtable().isDisplayed()) {
				JavascriptExecutor js = (JavascriptExecutor) getDriver();
				js.executeScript("$('#campaign_defendants tr').click()", "");
				waitForPageLoad();
			}
		}
	}	

	public void loadPetitionerWithAccordionExpand()
	{
		if(petitionersTabInPetition.isPresent())
			petitionersTabInPetition.click();
		if(petitionersAccordion.isPresent())
			petitionersAccordion.click();
	}
	public void loadPatentsWithAccordionExpand()
	{
		if(patentsTabInPetition.isPresent())
			patentsTabInPetition.click();
		if(patentsAccordion.isPresent())
			patentsAccordion.click();
	}
	public int getTotalCasesCountInVenuesMap()
	{
		int count=0;
		for(int i=1;i<=venueSectionsCount.count();i++)
		{
			if(getDriver().findElements(By.cssSelector(venuesText+i+") text tspan")).size()!=0)
			{       
				if($(venuesText+i+") text tspan").getIntData()>0)
				{
					$(venuesText+i+") text tspan").click();
					count=count+venuesCasesCount.getIntData();
				}

			}

		}
		return count;
	}
	public List<String> getxAxis()
	{
		List<String> xaxis= new ArrayList<String>();
		int size=$(chartXAxis).getAllData().size();
		System.out.println("Size"+size);
		for(int index=1; index<=size;index++)
			xaxis.add(getDriver().findElement(By.cssSelector(chartXAxis+":nth-of-type("+index+")")).getAttribute("x"));
		return xaxis;
	}	

	public final Element campaignCounselInfo = $("li.plaintiff div.counsel-content .counsel-party");
	public final Element accusedProductsMasked = $("div#async_modal:contains('Accused products are not included in your current subscription. Please upgrade your account')");
	public final Element ptabCasesInDefModal = $("div.overview_defendant_details a[href*='/ptab']");
	public final Element counselinfo = $("a.counsel+div.counsel-content div.counsel-party");

	public final Element itcMostRecentCaseMasked = $(By.xpath("//table[@id='campaign_defendants']//tbody/tr[2]/td[3]//a[text()='337-TA-000']"));
	public final Element itcMostRecentCase = $(By.xpath("//table[contains(@id,'campaign_defendants')]//tbody/tr[2]/td[3]//a[not(text()='337-TA-000')]"));
	public final Element firstSubtableOpen = $("tr:nth-of-type(1) .open.cursor-pointer");
	public final Element firstSubtableClose = $("tr:nth-of-type(1) .close.cursor-pointer");
	public void selectDefendantView() {
		if(defendantTabLink.isDisplayed()) {
			defendantTabLink.click();
			waitForPageLoad();
			defendant_table.waitUntilVisible();
		}
	}
	public final Element lcaBtnToolTip = $(".qtip-content div:visible:contains('Litigation Campaign')");
	public final Element lcaBtnPromoMsg = $(".qtip-content div.undefined:contains('Litigation Campaign Assessments are not available')>a:contains('Upgrade')");
	public final Element noLcaMsg = $(".qtip-content div:visible:contains('Litigation Campaign Assessment Not Available') a:contains('Request')");


	public void clickAndHoldLcaButton() {
		if(lcaButton.isDisplayed()) {
			lcaButton.moveTo();
			lcaBtnToolTip.waitUntilVisible();
		}
	}


	public void selectDefendantTabAndExpandSubtable() {
		if(!defendant_table.isDisplayed())
			selectDefendantView();
		if(firstSubtableOpen.isDisplayed()) {    		
			firstSubtableOpen.click();
			defendant_table.subtable().waitUntilVisible();
		}
	}

//	public final Element patentGrid = $("a[href='#defendant_patent_table']");
//
//	public void selectPatentGridTab() {
//		if (patentGrid.isDisplayed()) {
//			patentGrid.click();
//			waitForPageLoad();
//		}
//	}
	
	public HashMap<String, ArrayList<String>> getPatentGridData() {
		Element patentGridTableHeader = $("#defendant_patent_table table th");	
		List<WebElement> patentGridTableRows= $("#defendant_patent_table table tbody tr").getElements();		 
		ArrayList<String> headerdata = new ArrayList<>();	

		for(int headerCount=1; headerCount < patentGridTableHeader.size(); headerCount++){			
			headerdata.add(patentGridTableHeader.getData(headerCount).toString());
		}

		HashMap<String, ArrayList<String>> defendantPatentMap = new HashMap<>();		 
		for(WebElement patentGridTableRow: patentGridTableRows){	
			ArrayList<String> patentdata = new ArrayList<>();	
			List<WebElement> columns = patentGridTableRow.findElements(By.cssSelector("td"));

			for(int cellCount=1; cellCount<columns.size(); cellCount++) {				
				if(columns.get(cellCount).findElements(By.cssSelector("span")).size()!=0){					 
					patentdata.add(headerdata.get(cellCount-1));
				}				
			}
			defendantPatentMap.put(columns.get(0).getText(), patentdata);			
		}		 
		return defendantPatentMap;		 
	}
	
	public final Element defSubtableItcDateFiledEmpty = $("table.nested_inner_table tbody>tr:nth-of-type(2)>td:nth-child(2):empty"); //$(By.xpath("//table[contains(@class,'nested_inner_table')]//tbody/tr[2]/td[1][not(text())]"));
	public final Element defSubtableItcCaseName_Masking = $("table.nested_inner_table tbody>tr:nth-of-type(2)>td:nth-child(3):contains('ITC access not available')>a:contains(Learn More)");//$(By.xpath("//table[contains(@class,'nested_inner_table')]//tbody/tr[2]/td[2][contains(text(),'ITC access not available')]/a[text()='Learn More']"));
	public final Element defSubtableItcCaseNoMasked = $("table.nested_inner_table tbody>tr:nth-of-type(2)>td:nth-child(4)>a:contains(337-TA-000)"); //$(By.xpath("//table[contains(@class,'nested_inner_table')]//tbody/tr[2]/td[3]/a[text()='337-TA-000']"));
	public final Element defSubtableItcCaseNo = $(By.xpath("//table[contains(@class,'nested_inner_table')]//tbody/tr[2]/td[4]/a[not(text()='337-TA-000')]")); //$("table.nested_inner_table tbody>tr:nth-of-type(2)>td:nth-child(4)>a:not(337-TA-000)");
	public final Element defSubtableItcTermDateEmpty = $("table.nested_inner_table tbody>tr:nth-of-type(2)>td:nth-child(5):empty"); //$(By.xpath("//table[contains(@class,'nested_inner_table')]//tbody/tr[2]/td[4][not(text())]"));
	public final Element defSubtableItcCaseNameLink = $("table.nested_inner_table tbody>tr:nth-of-type(2)>td:nth-child(3):has(a.case_details)"); //$(By.xpath("//table[contains(@class,'nested_inner_table')]//tbody/tr[2]/td[2]/a[contains(@href,'/itc/')]"));

	public void caseViewInCampaignOverview() {
		if(!case_table.isDisplayed()) {
			caseViewTab.click();
			case_table.waitUntilVisible();
		}
	}

	// AUTHORIZATION PLAINTIFF
	public final Element plaintiffWithoutCounselInfo = $("#plaintff_list_container span:contains('No representation listed')");
	public final Element plaintiffWithCounselInfo = $("#plaintff_list_container .counsel-content>.counsel-party");
	public final Element showAllCouncelExpandLink = $("a.arrow.counsel.active.secondary.collapsed");
	public final Element plaintiffPromotionalLnk = $(By
			.xpath("//div[@class='panel plaintiff_list']//div[contains(text(),'Counsel Data is not included')]/a[text()='Upgrade']"));
	public final Element plaintiffPromotionalLnk_without_FF = $(By
			.xpath("//div[@class='panel plaintiff_list']//h4[contains(text(),'Counsel Information is not included')]"));

	public void expandCounselInfo() {
		if (showAllCouncelExpandLink.isDisplayed()) {
			JavascriptExecutor js = (JavascriptExecutor) getDriver();
			js.executeScript("$('a.arrow.counsel.active.secondary').click()", "");
			showAllCouncelExpandLink.waitUntilInvisible();
		}
	}
	
/*	public final Element counsel_count = $("#plaintff_list_container a.arrow.counsel.active.secondary.collapsed");
	public Object getCounselCount() {
		if(counsel_count.isDisplayed()) {			
			return counsel_count.getData();
		}
		return null;
	}	*/
	public final Element counsel_count = $("#plaintff_list_container ", (Configure<Table>) table ->
		{
			table.uniqueId(".plaintiff:contains(Counsel) h4 a[href]");
			table.column("counsel_count", "a.arrow.counsel.active.secondary.collapsed");
		}
	);
	
	public final Element promoInAccusedProducts = $(By.xpath("//div[@id='campaign_accused_products']//div[contains(text(),'Accused Products are not included')]/a[text()='Upgrade']"));
	public final Element promoInAccusedProducts_without_FF = $(By.xpath("//div[@id='campaign_accused_products']//h4[contains(text(),'not included in your current subscription')]"));
	
	public final Element plaintiffParties = $(".plaintiff>h4>a");
	public List<String> getPlaintiffParties() {
		List<WebElement> parties = plaintiffParties.getElements();
		List<String> data = new ArrayList<String>();
		for(int partyCount = 0; partyCount < parties.size(); partyCount++) {	
			String key =  parties.get(partyCount).getText().trim();					
			if(key.contains("...")) {						
				key = parties.get(partyCount).getAttribute("title").trim();				
				data.add(key);
			}	
			else 
				data.add(key);				
		}		
		return data;
	}

	
	//Role Authorization for Alerts
    public final Element dc_Events=$("input#District_Court_Events:not([class*='greyed-out'])");
    public final Element ptab_Events=$("input#PTAB_Events:not([class*='greyed-out'])");
    public final Element itc_Events=$("input#ITC_Events:not([class*='greyed-out'])");
    public final Element rpx_Reports_Events=$("input#RPX_Reports:not([class*='greyed-out'])");
    public final Element prior_art_Report_Event=$("input#alert_event__400:not([class*='greyed-out'])");
    public final Element event_Promotional_Msg=$(".events_promotional_msg a[href='/payments/options']");
    public final Element reportBuilderDialog_Promo = $(By.xpath("//div[@id='data_download_modal']//div[contains(text(), 'Data downloads only available for Elite or Member Users.')]"));
    
    //NEWS Section
    public final Element news_title = $(".news_title");
    
    //AUTHORIZATION PETITION SECTION
    public final Element petition_tab_pc=$("#related_petitions_petitions .subscription-promo-message a:contains('Start with a Free Trial')");
    public final Element petition_tab_data=$("#related_petitions_petitions tbody tr>td>a[href*='/patent/']");
    public final Element petioners_tab_data=$("#related_petitions_petitioners div.group.nested");
    public final Element patents_tab_data=$("#related_petitions_patents div.group.nested");
    public final Element petitioners_tab_pc=$("#related_petitions_petitioners .subscription-promo-message a:contains('Start with a Free Trial')");
    public final Element patents_tab_pc=$("#related_petitions_patents .subscription-promo-message a:contains('Start with a Free Trial')");

	public void selectTabInPRBReexaminationSection(String tabName) {
		Element activeTab = $("#campaign_prb_section dd.active a");
		if (!activeTab.getText().toUpperCase().contains(tabName.toUpperCase())) {
			String xpath = String.format(
					"//*[@id='campaign_prb_section']//dd/a[contains(text(),'%s')]",
					tabName);
			Element requiredTab = $(By.xpath(xpath));
			requiredTab.click();
		}
	}
	public void selectTabInusReexaminationSection(String tabName) {
		Element activeTab = $("#campaign_us_reexam_section  dd.active a");
		if (!activeTab.getText().toUpperCase().contains(tabName.toUpperCase())) {
			String xpath = String.format(
					"//*[@id='campaign_us_reexam_section ']//dd/a[contains(text(),'%s')]",
					tabName);
			Element requiredTab = $(By.xpath(xpath));
			requiredTab.click();
		}
	}
	//US Reexamination started

	public final Table usreexamination_table = $("#campaign_us_reexam_section table", (Configure<Table>) table ->
	{
		table.uniqueId("td:nth-child(3) a[href]");
		table.viewAllLink(By.xpath("//*[@id='campaign_us_reexam_section']//a[text()='View All']"));
		table.viewLessLink(By.xpath("//*[@id='campaign_us_reexam_section']//a[text()='View Less']"));
		table.displayedRecords("#campaign_us_reexam_section table tbody tr:not([style='display: none;'])");
	});


	public final Tabs usReexam = new Tabs("#campaign_us_reexam_section dl.tabs");
	public void selectUSReexamPatentsTab() {
		if (patentsTabLink.isDisplayed()) {
			patentsTabLink.click();
			waitForSectionLoading();
		}
	}
	public final Element usreexampatentsTabLink = $("#campaign_us_reexam_section [data-lit-type=patents] a");
	public final Element usreexamtitleWithoutNpeTag = $("#content h1 span:not(.npe_tag)");
	public final Element usreexamentLinkAtRequesterTab=$("#reexamination_requester div.handle a");
	public final Element usreexamMetricsForRequester=$("#reexamination_requester div:nth-of-type(1) div.handle li.result-count");
	public final Table usreexamPatentTable = $("#reexamination_patents.content.active", (Configure<Table>) table -> {
		table.row("div.group.nested");
		table.uniqueId("div.handle>a");
		table.expandSubTableLink("div.group.nested div.handle");
		table.subTable($("table.table_section", (Configure<Table>) subtable ->
		{
			subtable.uniqueId("td:nth-child(2) a[href]");
			subtable.displayedRecords("#reexamination_patents div.group:nth-child(1) table tbody tr");
		}));

	});
	public final Table usreexamrequesterTable = $("#reexamination_requester.content.active", (Configure<Table>) table -> {
		table.row("div.group.nested");
		table.uniqueId("div.handle>a");
		table.expandSubTableLink("div.group.nested div.handle");
		table.subTable($("table.table_section", (Configure<Table>) subtable ->
		{
			subtable.uniqueId("td:nth-child(2) a[href]");
			subtable.displayedRecords("#reexamination_requester #recent-litigation-cases- div.content table tbody tr");
		}));

	});
	public final Element usreexamMetricsForPatent =$("#reexamination_patents div:nth-of-type(1) div.handle li.result-count");
	public final Element usreexampatListAtPatentTab=$("#reexamination_patents div:nth-of-type(1) div.handle");


	//US Reexamination End

	//PRB Reexamination started

	public final Table reexamination_table = $("#chinese_prb_reexamination table", (Configure<Table>) table ->
	{
		table.uniqueId("td:nth-child(3) a[href]");
		table.viewAllLink(By.xpath("//*[@id='chinese_prb_reexamination']//a[text()='View All']"));
		table.viewLessLink(By.xpath("//*[@id='chinese_prb_reexamination']//a[text()='View Less']"));
		table.displayedRecords("#chinese_prb_reexamination table tbody tr:not([style='display: none;'])");
	});


	public final Tabs prbReexam = new Tabs("#campaign_prb_section dl.tabs");
	public void selectPatentsTab() {
		if (patentsTabLink.isDisplayed()) {
			patentsTabLink.click();
			waitForSectionLoading();
		}
	}
	public final Element patentsTabLink = $("#campaign_prb_section [data-lit-type=patents] a");
	public final Element titleWithoutNpeTag = $("#content h1 span:not(.npe_tag)");
	public final Element entLinkAtRequesterTab=$("#chinese_prb_requester div.handle a");
	public final Element ReexaminationMetricsForRequester=$("#chinese_prb_requester div:nth-of-type(1) div.handle li.result-count");
	public final Table requesterNPatentTable = $("#chinese_prb_patents.content.active", (Configure<Table>) table -> {
		table.row("div.group.nested");
		table.uniqueId("div.handle>a");
		table.expandSubTableLink("div.group.nested div.handle");
		table.subTable($("table.table_section", (Configure<Table>) subtable ->
		{
			subtable.uniqueId("td:nth-child(2) a[href]");
			subtable.displayedRecords("#campaign_prb_section .active>div:nth-of-type(1) table tbody tr:not([style='display: none;'])");
		}));

	});
	public final Table requesterTable = $("#chinese_prb_requester.content.active", (Configure<Table>) table -> {
		table.row("div.group.nested");
		table.uniqueId("div.handle>a");
		table.expandSubTableLink("div.group.nested div.handle");
		table.subTable($("table.table_section", (Configure<Table>) subtable ->
		{
			subtable.uniqueId("td:nth-child(2) a[href]");
			subtable.displayedRecords("#chinese_prb_requester .active>div:nth-of-type(1) table tbody tr:not([style='display: none;'])");
		}));

	});
	public final Element reexaminationMetricsForRequester =$("#chinese_prb_patents div:nth-of-type(1) div.handle li.result-count");
	public final Element PRBpatListAtPatentTab=$("#chinese_prb_patents div:nth-of-type(1) div.handle");

	//PRB Reexamination ended

    }
