package com.rpxcorp.insight.page;

import org.openqa.selenium.By;

import com.rpxcorp.testcore.element.Element;

public class LitigationDocumentConfirmationPage extends BasePage {

    @Override
    public boolean at() {
        return confirmationHeader.waitUntilVisible();
    }

    public final Element confirmationHeader = $(
            By.xpath("//*[@id='doc_download_modal']/div/h2[text()='Document Credit Confirmation']"));

    public final Element accountCredit = $(".small-3.columns.available_credit.text-right");
    public final Element documentCost = $(".small-3.columns.doc_cost.text-right");

    public final Element confirmDebitBtn = $(".button.download_link");
    public final Element cancelBtn = $(".button.secondary.cancle");
}
