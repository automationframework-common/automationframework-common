package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class BillingHistoryPage extends BasePage {

    public BillingHistoryPage() {
        this.url = new PageUrl("user/edit#fndtn-panel_billing_history");
    }

    @Override
    public boolean at() {
        return billing_history_panel.waitUntilVisible();
    }

    public final Element billing_history_panel = $("#panel_billing_history");

    public final Element noTransactions = $("h5[class='text-center']");
    public final Element billing_doc = $("a.document");
}
