package com.rpxcorp.insight.page.intelligence;

import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;

public class RpxIPRsPage extends BasePage {

    public RpxIPRsPage() {
        this.url = new PageUrl("rpx_iprs");
    }

    @Override
    public boolean at() {
        searchTextBox.waitUntilVisible();
        return petitionSummaryCount.waitUntilVisible();
    }

    /* CONTENT OF ENTITY DETAIL PAGE * */
    public final Element pageTitle = $("h1");
    public final Element searchBtn = $("form[action='/rpx_iprs'] .button[value='Search']");
    public final Element clearBtn = $("a.button[href='/rpx_iprs']");

    public final Element noPetitionMsg = $(".row.ipr .search_div+div.columns p");
    public final Element petitionSummaryCount = $("div.columns table.ipr_table tbody tr:nth-child(1) td:nth-child(1) a");
    public final Table IPR_table = $(".ipr_table", (Configure<Table>) table ->
        {
           table.nextPage("div.large-12.columns ul.pagination.pagination li:last-child:visible");
           table.lastPage("div.large-12.columns ul.pagination.pagination li:nth-last-child(2):visible");
            table.uniqueId("a[href*=/ptabs]");
        }
    );
    
    public final StaticContent metricsSection = $(".big-stats", (Configure<StaticContent>) dataForm ->
    	{
    	dataForm.content("campaigns", "li:contains(Campaigns) span");
    	dataForm.content("petitions_filed", "li:contains(Petitions) span");
    	dataForm.content("unique_patents_challenged", "li:contains(Challenged) span");            
    	}
    );  
    
    public final Element pagination = $(".pagination");
    public final Element lastPageLink = $("div.larrge-12.columns ul.pagination.pagination li:nth-last-child(2)");
    public final Element nextLink = $("ul.pagination.pagination .arrow a[rel='next']");
    public final Element viewPetitionBtn = $(".ipr_table td:last-child a");

    public final Element litigationSearchBtn = $(".search_div span.search_action_container input[name='commit']");
    public final Element litigationSearchBox = $(".search_div span.search_text_container>input[type='text']");
    public final Element clearButton = $(".search_div span.search_action_container a#clear_docket_form:visible");
    public void search(String searchKey) {
        if (!clearButton.isDisplayed()) {
            searchRPXIPR(searchKey);
        }else {
            clearButton.click();
            loading.waitUntilInvisible();
            clearButton.waitUntilInvisible();
            searchRPXIPR(searchKey);
        }
    }
    public void searchRPXIPR(String searchKey) {
        litigationSearchBox.sendKeys(searchKey);
        litigationSearchBtn.click();
        loading.waitUntilInvisible();
    }

    public void clear() {
        if (clearButton.isDisplayed())
        clearButton.click();
        at();
    }

}
