 package com.rpxcorp.insight.test.functional.advancedsearch;

import com.rpxcorp.insight.page.advance_search.AdvanceSearchPage;
import com.rpxcorp.insight.page.advance_search.AdvanceSearchPage.SEARCHTAB;
import com.rpxcorp.insight.page.advance_search.EntityAdvanceSearchPage;
import com.rpxcorp.insight.page.search.EntitySearchPage;
import com.rpxcorp.insight.test.functional.BaseFuncTest;
import com.rpxcorp.testcore.Assert;
import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.List;

 @Authenticate(role = "MEMBER")
public class EntityAdvanceSearchTest extends BaseFuncTest{
    AdvanceSearchPage advanceSearchPage;
    EntityAdvanceSearchPage entityAdvanceSearchPage;
    EntitySearchPage entitySearchPage;

    @Test(priority = 1, groups="P2", description = "verify default visible and all entity type list")
    public void verifyDefaultEntityTypeList() throws Exception {
        navigateToEntityAdvanceSearch();
        //Assert.isEquals(entityAdvanceSearchPage.entityType.getVisibleList(),dataAsList("Visible Entity Types"));
        Assert.isEquals(entityAdvanceSearchPage.entityType.getAllField(),dataAsList("All Entity Types"));
    }

    @Test(priority = 2, groups="P2",description = "verify default visible and all market sector list")
    public void verifyDefaultMarketSectorList() throws Exception {
        navigateToEntityAdvanceSearch();
        Assert.isEquals(entityAdvanceSearchPage.marketSector.getVisibleList(),dataAsList("All Market Types"));
        //Assert.isEquals(entityAdvanceSearchPage.marketSector.getAllField(),dataAsList("All Market Types"));
    }
    @Test(priority = 3, groups="P2",dataProvider = "json",description = "verify entity auto suggest")
    public void verifyEntityNameAutoSuggest(String searchValue, List<String> expectedParent, List<String> expectedChild,String assertMessage) {
        navigateToEntityAdvanceSearch();
        entityAdvanceSearchPage.entityName.sendKeys(searchValue);
        Assert.isEquals(entityAdvanceSearchPage.entityName.getParentDropDownValue(),expectedParent);
        Assert.isEquals(entityAdvanceSearchPage.entityName.getChildDropDownValue(),expectedChild);
    }
     @Test(priority = 4, groups="P2",dataProvider = "json",description = "verify entity auto suggest")
     public void verifySearch(HashMap<String,Object> data) {
         navigateToEntityAdvanceSearch();
         entityAdvanceSearchPage.search(data);
         at(entitySearchPage);
         System.out.println(entitySearchPage.marketSector.getSelectedFilter());
         Assert.isEquals(entitySearchPage.getPartialUrl(),
                 "/advanced_search/search_entities?commit=Search&"+data.get("ExpectedUrl")+"&grouped=true&search_type=entities&utf8=✓");
         Assert.isEquals(entitySearchPage.getAppliedFilters(),data.get("ExpectedFilters"));
         Assert.isTrue(entitySearchPage.enity_results_count.getIntData()> 0,"");
     }
    /* TODO CASES
        * select all
        * select none
        * Market Sector link
        * Clear fields
     */
    public void navigateToEntityAdvanceSearch(){
        to(advanceSearchPage);
        advanceSearchPage.searchFormTabLinks.select(SEARCHTAB.Entity);
        at(entityAdvanceSearchPage);
    }
}