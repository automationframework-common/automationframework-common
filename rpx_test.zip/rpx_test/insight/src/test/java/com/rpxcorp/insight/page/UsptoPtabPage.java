package com.rpxcorp.insight.page;

import com.rpxcorp.testcore.element.Element;

public class UsptoPtabPage extends BasePage {

	@Override
	public boolean at() {
		return loginPanel.waitUntilVisible();
	}

	public final Element loginPanel = $(".login-panel.panel.panel-primary.login-height");
}
