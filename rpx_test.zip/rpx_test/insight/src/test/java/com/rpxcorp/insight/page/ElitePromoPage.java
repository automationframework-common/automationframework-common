package com.rpxcorp.insight.page;

import com.rpxcorp.testcore.element.Element;


public class ElitePromoPage extends BasePage {
    @Override
    public boolean at() {
        return elitePromoMsg.waitUntilVisible();
    }

    public final Element elitePromoMsg = $("a.subscribe_page_link.blocked-content-promo.trial:contains('Available with Elite subscription and above')");

}
