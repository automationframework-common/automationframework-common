package com.rpxcorp.insight.page.error_page;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class AccountActivationErrorPage extends BasePage {

    @Override
    public boolean at() {
        // TODO Auto-generated method stub
        return activationErrorMessage.waitUntilVisible();
    }

    public final Element activationErrorMessage = $("#activation");
}
