package com.rpxcorp.insight.page.intelligence;

import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;

public class MarketPlacePage extends BasePage {

    public MarketPlacePage() {
        this.url = new PageUrl("marketplace/acquisition-opportunities");
    }

    @Override
    public boolean at() {
        assertPageTitle("RPX Marketplace");
        $(".graph-bar").waitUntilVisible();
        return recent_activity_table.waitUntilVisible();
    }

    public final Element xAxisTextForGraph = $("#render_overview_timeline .highcharts-xaxis-labels text");
    public final Element stageInformationTypes = $("#stage_descriptions p>strong");
    /* CONTENT OF NPE PROFILE PAGE * */
    public final Table recent_activity_table = $(".dataTables_wrapper table", (Configure<Table>) table ->
        {
            table.uniqueId("td:nth-child(3)>a");
        }
    );
    
    public final Element download_Btn=$(".text-right a:contains(Download)");
    public final Element download_Btn_InPopUp=$("#download-popup a:contains(Download as an Excel file)");
    public final Element closeIcon_InDownloadPopup=$("#download-popup a.close-reveal-modal");

}
