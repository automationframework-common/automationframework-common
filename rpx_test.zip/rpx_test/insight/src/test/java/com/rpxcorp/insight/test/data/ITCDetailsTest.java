package com.rpxcorp.insight.test.data;

import java.sql.ResultSet;
import java.util.Map;

import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import com.rpxcorp.insight.page.detail.ITCDetailPage;
import com.rpxcorp.testcore.TableData;
@Authenticate(role = "MEMBER")
@Test(groups = {"Lits","ITC"})
public class ITCDetailsTest extends BaseDataTest {

    ITCDetailPage itcDetailPage;
    TableData tableData;
    Map<String, String> staticData;
    ResultSet resultSet;

    @Factory(dataProvider = "returnData")
    public ITCDetailsTest(String dataDescription, String ptabId) {
        this.dataId = ptabId;
        this.dataDescription = dataDescription;
    }

    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("ITCDetail");
    }

    @BeforeClass
    public void loadPage() {
        urlData.put("ID", dataId);
        this.dataUrl = itcDetailPage.getDeclaredUrl(urlData);
        to(itcDetailPage, urlData);
    }

    @Test(description = "Verify Complainants")
    public void Complainants() throws Exception {
        assertEquals(itcDetailPage.complainants.getData(),
                sqlProcessor.getResultData("ITCDetail.COMPLAINANTS", dataId));
    }

    @Test(description = "Verify Respondants")
    public void Respondants() throws Exception {
        assertEquals(itcDetailPage.respondents.getData(), sqlProcessor.getResultData("ITCDetail.RESPONDANTS", dataId));
    }
    
    @Test(description = "Verify complaint is displayed in view complaint")
   	public void complaintDocument() throws Exception {    	
   		assertEquals(itcDetailPage.getComplaintNumber(),
   				sqlProcessor.getSinglResultValue("ITCDetail.COMPLAINT_FILED_DOCUMENT_ID", dataId));
   	}

    @Test(description = "Verify 'Title' column in Patent-in-Suit Table", priority = 1)
    public void Patent_in_Suit_Title() throws Exception {
        tableData = itcDetailPage.patent_table.getData();
        resultSet = sqlProcessor.getResultData("ITCDetail.PATENT_IN_SUIT", dataId);
        assertEquals(tableData, resultSet, "title");
    }
    
    @Test(description = "Verify 'Est. Priority Date' column in Patent-in-Suit Table", priority = 2)
    public void Patent_in_Suit_Priority_date() throws Exception {
        assertEquals(tableData, resultSet, "est_priority_date");
    }

    @Test(description = "Verify Title", priority = 3)
    public void Title() throws Exception {
        resultSet = sqlProcessor.getResultData("ITCDetail.HEADER_INFO", dataId);
        assertEquals(itcDetailPage.title.getData(), resultSet, "title");
    }

    @Test(description = "Verify Investigation Number", priority = 4)
    public void Investigation_Number() throws Exception {
        staticData = itcDetailPage.subtitle.getData();
        assertEquals(staticData.get("investigation_number"), resultSet, "investigation_number");
    }

    @Test(description = "Verify Filed Date", priority = 5)
    public void Filed_Date() throws Exception {
        assertEquals(staticData.get("filed_date"), resultSet, "filed_date");
    }

    @Test(description = "Verify Terminated", priority = 6)
    public void Terminated() throws Exception {
        assertEquals(staticData.get("terminated"), resultSet, "terminated");
    }

    @Test(description = "Verify ITC Case Type in Left Panel in Overview Section", priority = 7)
    public void caseType() throws Exception {
    	staticData = itcDetailPage.overview_panel.getData();
        assertEquals(staticData.get("case_type"), sqlProcessor.getResultData("ITCDetail.CASE_TYPE", dataId),
                "case_type");
    }

    @Test(description = "Verify Status in Left Panel in Overview Section", priority = 7)
    public void status() throws Exception {
        assertEquals(staticData.get("status"), sqlProcessor.getResultData("ITCDetail.STATUS", dataId),
                "status");
    }

    @Test(description = "Verify Judge in Left Panel in Overview Section", priority = 8)
    public void judge() throws Exception {
        assertEquals(staticData.get("judge"), sqlProcessor.getResultData("ITCDetail.JUDGE", dataId), "judge");
    }

    @Test(description = "Verify Generanl Counsel in Right Panel in Overview Section", priority = 7)
    public void general_counsel() throws Exception {
        assertEquals(staticData.get("general_counsel"),
                sqlProcessor.getResultData("ITCDetail.GENERAL_COUNSEL", dataId), "general_counsel");
    }

    @Test(description = "Verify Unfair Import Officer in Right Panel in Overview Section", priority = 8)
    public void unfair_import_officer() throws Exception {
        assertEquals(staticData.get("unfair_import_officer"),
                sqlProcessor.getResultData("ITCDetail.UNFAIR_IMPORT_OFFICER", dataId), "unfair_import_officer");
    }

    @Test(description = "Verify Country of Origin in Right Panel in Overview Section", priority = 8)
    public void country_of_origin() throws Exception {
        assertEquals(staticData.get("country_of_origin"),
                sqlProcessor.getResultData("ITCDetail.COUNTRY_OF_ORIGIN", dataId), "country_of_origin");
    }


    @Test(description = "Verify FederalCircuitAppeal in Overview Section", priority = 8)
    public void verifyFederalCircuitAppeal() throws Exception {
        assertEquals(staticData.get("fedcircuit_appeal"),
                sqlProcessor.getResultData("ITCDetail.NOTICE_OF_APPEAL", dataId), "fedcircuit_appeal");
    }

    @Test(description = "Verify Litigation Cases Count", priority = 9)
    public void Litigation_case_count() throws Exception {
        resultSet = sqlProcessor.getResultData("ITCDetail.CAMPAIGN_CASES_COUNT", dataId);
        assertEquals(itcDetailPage.caseTabLink.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    @Test(description = "Verify Litigation Cases Table", priority = 10)
    public void Litigation_cases() throws Exception {
        resultSet = sqlProcessor.getResultData("ITCDetail.CAMPAIGN_CASES", dataId);
        assertEquals(itcDetailPage.litigation_cases.getData(), resultSet, "date_filed", "case_name", "case_number",
                "termination_date");
    }

    @Test(description = "Verify Accused Products Table", priority = 11)
    public void Accused_Products() throws Exception {
        itcDetailPage.selectAccusedProductsTab();
        assertEquals(itcDetailPage.camp_accused_table.getData(),
                sqlProcessor.getResultData("ITCDetail.CAMPAIGN_ACCUSEDPRODUCTS", dataId));
    }

    @Test(description = "Verify Patents Count", priority = 12)
    public void Patent_count() throws Exception {
        itcDetailPage.selectPatentTab();
        resultSet = sqlProcessor.getResultData("ITCDetail.CAMPAIGN_PATENTS", dataId);
        assertEquals(itcDetailPage.patentsTabLink.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    @Test(description = "Verify Patents Table", priority = 13)
    public void Patents() throws Exception {
        assertEquals(itcDetailPage.camp_patent_table.getData(), resultSet);
    }
    @Test(description = "Verify complainant count", priority = 1)
    public void complainantsCount() throws Exception {
    	staticData = itcDetailPage.metricsSection.getData();    	
    	assertEquals(staticData.get("complainantCount"), 
    			sqlProcessor.getResultCount(sqlProcessor.getResultData("ITCDetail.COMPLAINANTS", dataId)));
    }
    
    @Test(description = "Verify respondent count", priority = 1)
    public void respondentsCount() throws Exception {
    	assertEquals(staticData.get("respondentsCount"),
    			sqlProcessor.getResultCount(sqlProcessor.getResultData("ITCDetail.RESPONDANTS", dataId)));
    }
    
    @Test(description = "Verify patent in suit count", priority = 1)
    public void patentInSuitCount() throws Exception {
    	assertEquals(staticData.get("patentsInSuitCount"),
    			sqlProcessor.getResultCount(sqlProcessor.getResultData("ITCDetail.PATENT_IN_SUIT", dataId)));
    }
    
    @Test(description = "Verify docket entries count", priority = 1)
    public void docketEntriesCount() throws Exception {
    	assertEquals(staticData.get("docketEntriesCount"),
    			sqlProcessor.getResultCount(sqlProcessor.getResultData("ITCDetail.DOCKET_ENTRIES", dataId)));
    }

    @Test(description = "Verify Defendants Count", priority = 14)
    public void Defendant_count() throws Exception {
        resultSet = sqlProcessor.getResultData("ITCDetail.CAMPAIGN_DEFENDANTS", dataId);
        assertEquals(itcDetailPage.defendantsTabLink.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    @Test(description = "Verify Defendants Table", priority = 15)
    public void Defendants() throws Exception {
        itcDetailPage.selectdefendantsTab();
        assertEquals(itcDetailPage.defendant_table.getData(), resultSet, "defendant_parent", "defendants",
                "most_recent_case", "start_date", "end_date");
    }

    @Test(description = "Verify Defendants Sub Table", priority = 16)
    public void Defendants_subtable() throws Exception {
        itcDetailPage.expandAlldefandant();
        assertEquals(itcDetailPage.defendant_table.getSubtableData(),
                sqlProcessor.getResultData("ITCDetail.CAMPAIGN_DEFENDANTS_SUBTABLE", dataId));
    }
    
    @Test(description = "Verify terminated date for Complainants", priority = 19)
    public void complainantTerminatedDate() throws Exception {
        assertEquals(itcDetailPage.complainantTerminatedDate.getData(), 
        		sqlProcessor.getResultData("ITCDetail.COMPLAINANT_TERMINATED_DATE", dataId));
    }
    
    @Test(description = "Verify Disposition for Respondents", priority = 19)
    public void disposition() throws Exception {
    	assertEquals(itcDetailPage.disposition.getData(),
        		sqlProcessor.getResultData("ITCDetail.RESPONDENT_DISPOSITION", dataId));
    }
    
    @Test(description = "Verify lawfirm information for Complainants", priority = 19)
    public void complainantLawfirmInformation() throws Exception {
    	assertEquals(itcDetailPage.complainantLawfirmContent.getData(),
        		sqlProcessor.getResultData("ITCDetail.COMPLAINANT_LAWFIRM_NAME", dataId));
    }
    
    @Test(description = "Verify lawfirm information for Respondents", priority = 19)
    public void respondentLawfirmInformation() throws Exception {
    	assertEquals(itcDetailPage.respondentLawfirmContent.getData(), 
        		sqlProcessor.getResultData("ITCDetail.RESPONDENT_LAWFIRM_NAME", dataId));
    }

    @Test(description = "Verify Docket Entries Count", priority = 19)
    public void Docket_Entries_Count() throws Exception {
        resultSet = sqlProcessor.getResultData("ITCDetail.DOCKET_ENTRIES", dataId);
        assertEquals(itcDetailPage.docketEntries_count.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    // TODO: will take it later with pagination
   // @Test(description = " ", priority = 20)
    public void DocketEntries() throws Exception {
        assertEquals(itcDetailPage.docketEntries.getData(), resultSet, "date_received", "doc_type", "phase", "security",
                "filed_by", "on_behalf_of", "firmorg");
    }

    // @Test(description = "Verify Title of Litigation Docket Entries",priority
    // = 20)
    public void DocketEntries_Title() throws Exception {
        assertEquals(itcDetailPage.docketEntries.getPopupSubtableData(), resultSet, "title");
    }

    // @Test(description = "Verify the associated Documents section in Docket
    // Entries Page",priority=21)
    public void Associated_docs() throws Exception {
        assertEquals(itcDetailPage.docketAssociatedDocumentsTable.getPopupSubtableData(),
                sqlProcessor.getResultData("ITCDetail.DOCKET_ASSOCIATED_DOCUMENTS", dataId));
    }
}