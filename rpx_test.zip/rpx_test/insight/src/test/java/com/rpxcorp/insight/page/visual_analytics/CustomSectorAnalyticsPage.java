package com.rpxcorp.insight.page.visual_analytics;

import com.rpxcorp.insight.module.DatePicker;
import com.rpxcorp.insight.module.Highchart;
import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.Keys;

import java.util.ArrayList;
import java.util.Arrays;

public class CustomSectorAnalyticsPage extends BasePage{

	public CustomSectorAnalyticsPage() {
		this.url = new PageUrl("analytics/custom_sector_analytics");
	}

	@Override
	public boolean at() {
		//getDeclaredUrl("custom_sector_analytics");
		loading.waitUntilInvisible();
		contentLoading.waitUntilInvisible();
		return panel.waitUntilVisible();
	}
	public final  Element customSectorPromomsg = $(".market_sector_analytics a[href='/subscribe']");

	public final  Element unauthorizesAccessPromoMessage = $("#flash_name");
	public final Element panel = $("body.market_sector_analytics-page");
	public final Element campaignTypeDropdown = $("#campaign_analytics_type");

	public final Element litYearlyChartArea = $("#market_sector_analytics_litigation  .highcharts-no-data tspan");
	public final Element litDefChartArea = $("#market_sector_analytics_defendants .highcharts-no-data tspan");
	public final Element litPlaintiffChartArea  = $("#market_sector_analytics_litigations_top_ten .highcharts-no-data tspan");
	public final Element litVenuesChartArea  = $("#market_sector_analytics_lit_top_ten_venues .highcharts-no-data tspan");
	public final Element litNPEDefChartArea = $("#market_sector_analytics_cases_by_npe_types .highcharts-no-data tspan");

	public final Element ptabYearlyChartArea = $("#market_sector_analytics_petitions .highcharts-no-data tspan");
	public final Element ptabPetitionsbyAgeChartArea = $("#market-sector-analytics-petitions-by-duration-and-sg .highcharts-no-data tspan");
	public final Element ptabPetitionersChartArea = $("#market_sector_analytics_ptabs_top_ten .highcharts-no-data tspan");

	public final Element patentsYearlyChartArea = $("#market_sector_analytics_patent .highcharts-no-data tspan");
	public final Element patentsAgeChartArea = $("#market_sector_analytics_patents_offered .highcharts-no-data tspan");
	public final Element patentsChartArea =$("#market_sector_analytics_patent_filers .highcharts-no-data tspan");

	public final Element patentsChartWithOnePatentCPCCode = $("#msa_patents_content .cost_analytics_chart_column>div");

	public final Element promoMsgForCustomSector = $(".large-12>div[class='logged_in page_blocked market_sector_analytics']");


	public final Element topPatentPartyTypeOptions = $("#market_sector_analytics_patent_filers");
	public void selectCampaignTypeYAxisValue(String campaignType) {
		campaignTypeDropdown.selectByOption(campaignType);
	}

	//Litigation Tab
    public final Tabs customSectorTabs = new Tabs ("div.analytics-ptab dl.tabs dd");
    public final Element litCampaignSectionYAxis =$("div.header-item:has(label:contains('Y-Axis')) select#litigations_analytics_type");
    public final Element litCampaignHighChart = $(".campaign_dashboard_wrapper .market_sector_analytics_chart_container_yearly:visible()");
    public final Element litDefendantsHighChart = $(".chart-container #market_sector_analytics_defendants:visible()");
    public final Element litTopPlaintiffHightChart = $(".chart-container #market_sector_analytics_litigations_top_ten:visible()");
    public final Element litTopVenuesHightChart = $(".chart-container #market_sector_analytics_lit_top_ten_venues:visible()");
    public final Element littopNPETypeHightChart = $(".chart-container #market_sector_analytics_cases_by_npe_types:visible()");

    //PTAB Tab
    public final Element ptabIPRPetitionsHighChart = $("div.chart-container #market_sector_analytics_petitions:visible()");
    public final Element ptabChallengedPatent = $("div.chart-container #market-sector-analytics-petitions-by-duration-and-sg:visible()");
    public final Element ptabTopIPRPetitions= $("div.chart-container #market_sector_analytics_ptabs_top_ten");

    //Patent Tab
    public final Element patentGrantedYear = $("div.patents_granted_container #market_sector_analytics_patent");
    public final Element patentOfferForSale = $("div.chart-container #market_sector_analytics_patents_offered");
    public final Element patentTopFilers = $("div.chart-container #market_sector_analytics_patent_filers");

    //Patents Tabs

    public void selectCustomSectorGroup(String groupName){
        $(".button-group.radius li a:contains('"+groupName+"'):visible()").waitUntilVisible();
        $(".button-group.radius li a:contains('"+groupName+"'):visible()").click();

    }
    public final Highchart campaignDefendantTypeChart = $(".market_sector_analytics_litigation_chart_container_yearly", (Configure<Highchart>) chart ->
	{
		chart.axisLabels("year", "svg g:nth-of-type(10) text");
		chart.dataLabels("npe", "svg g:nth-of-type(8) g");
		chart.dataLabels("operating_company", "svg g:nth-of-type(7) g text");
		chart.dataLabels("total_count", "svg g:nth-of-type(6) text tspan");

	}
			);

	public final Highchart petitionCountBasedOnCaseType = $("#market_sector_analytics_ptabs_top_ten", (Configure<Highchart>) chart ->
	{
		chart.axisLabels("company", "g[class*='highcharts-axis-labels'] text");
		chart.dataLabels("npe_oc_total", "svg g[class='highcharts-stack-labels']:nth-of-type(6) text");
		chart.dataLabels("npe_oc_count", "svg g:nth-of-type(7) g text");			
	}
			);

	public final Element topPTABPartyTypeOptions = $("#market_sector_analytics_ptabs_top_ten #stats_type");
	public final Element ptabCaseTypeOptions = $("#market_sector_analytics_ptabs_top_ten #case_type");
	public void selectTopPetitionsBasedOnCaseType(String petition_type, String case_type) {
		topPTABPartyTypeOptions.selectByOption(petition_type);
		ptabCaseTypeOptions.selectByOption(case_type);
	}

	public final Element petitionTypeFiledForYear = $("#petitions_analytics_type");
	public void selectPetitionsTypeFiledForYear(String petition_type) {
		petitionTypeFiledForYear.selectByOption(petition_type);		
	}

	public final Highchart petitionFiled = $("#market_sector_analytics_petitions .yearly", (Configure<Highchart>) chart ->
	{
		chart.axisLabels("year", "svg g:nth-of-type(11) text");
		chart.dataLabels("total", "svg g:nth-of-type(6) text");
		chart.dataLabels("npe", "svg g:nth-of-type(9) text");
		chart.dataLabels("oc", "svg g:nth-of-type(8) text");
	}
			);

	public final Highchart venuesInfringementAndDjCases = $("#market_sector_analytics_lit_top_ten_venues", (Configure<Highchart>) chart ->
	{		
		chart.dataLabels("total", "svg g[class='highcharts-stack-labels']:nth-of-type(6) text");		
		chart.dataLabels("npe_oc_court", "svg g[class*='highcharts-axis-labels']:nth-of-type(9) text");
		chart.dataLabels("npe_oc_count", "svg g[class*='highcharts-data-labels']:nth-of-type(7) text");
	}
			);

	public final Element top10CaseTypeInVenue = $("#market_sector_analytics_lit_top_ten_venues #stats_type");
	public void selectTop10CasesTypeInVenues(String top10_type) {
		top10CaseTypeInVenue.selectByOption(top10_type);		
	}

	public final Element caseTypeInVenue = $("#market_sector_analytics_lit_top_ten_venues #case_type");
	public final Element rankByCaseType = $("#market_sector_analytics_lit_top_ten_venues #order_type_Cases");
	public final Element rankByDefendantsType = $("#market_sector_analytics_lit_top_ten_venues #order_type_Defendants");
	public void selectCasesTypeInVenues(String case_type) {
		caseTypeInVenue.selectByOption(case_type);		
	}

	public final Element patentTypeFilersGrantees = $("#market_sector_analytics_patent_filers #patents_analytics_type");		
	public void selectPatentTypeFilersGrantees(String patent_type) {		
		patentTypeFilersGrantees.selectByOption(patent_type);				
	}		

	public final Element customMarketSectorTypesDropDown = $("#selected_market_sectors");		
	public void selectCustomMarketSectorTypes(String market_type) {		
		customMarketSectorTypesDropDown.selectByOption(market_type);				
	}		

	public final Element ageLengthOfPatentDropdown = $("#market-sector-analytics-petitions-by-duration-and-sg #stats_type");		
	public void selectAgeLengthOfPatent(String patent_type) {		
		ageLengthOfPatentDropdown.selectByOption(patent_type);				
	}		

	public final Element submitButton = $(".market_sector_analytics_form input[name='commit']");
	public final Element resetButton = $(".market_sector_analytics_form input#reset_button");
	public final Element litTabTitle = $("#market_sector_analytics_litigation h3 span");

	public void selectFromToDate(String from_date, String to_date) throws Exception {
		submitButton.scrollAndFocus();
		fromDate.selectDate(from_date);
		toDate.selectDate(to_date);				
		submitButton.click();
		litTabTitle.waitUntilVisible();
	}

	public final DatePicker fromDate = new DatePicker("#from_date");		
	public final DatePicker toDate = new DatePicker("#to_date");		
	public final Highchart patentsTop10FilersGrantees = $("#market_sector_analytics_patent_filers", (Configure<Highchart>) chart ->		
	{				
		chart.axisLabels("ent_name", "svg g[class*='highcharts-xaxis-labels']:nth-of-type(8) text");		
		chart.axisLabels("total", "svg g[class='highcharts-stack-labels']:nth-of-type(6) text");		
	}		
			);		

	public final Highchart ageOfChallengedPatent = $("#market-sector-analytics-petitions-by-duration-and-sg", (Configure<Highchart>) chart ->		
	{				
		chart.axisLabels("year", "svg g:nth-of-type(10) text");		
		chart.dataLabels("npe", "svg g[class*='highcharts-data-labels']:nth-of-type(8) text");		
		chart.dataLabels("oc", "svg g[class*='highcharts-data-labels']:nth-of-type(7) text");		
		chart.dataLabels("total", "svg g[class*='highcharts-stack-labels']:nth-of-type(6) text");		
	}		
	);

	public final Element addCustomSectorLink= $(".custom-market-sector-new");
	public final Element editCustomSectorLink = $(".custom-market-sector-edit");
	public final Element deleteCustomSectorLink = $(".custom-market-sector-delete");
	public final Element codesForDefendantPatent = $("div[title*='{value}'] input");
	public final Element nextButton = $("#customize_market_sector_modal a.next_step_btn");
	public final Element patentCPCodes = $("div[title='{value}'] input");
	public final Element customMArketSectorName = $( "#custom_market_sector_name");
	public final Element unionSelection = $(".small-8 label #{value}");
	public final Element clearAllNAICSOption = $(".naics_codes .clear_all a");
	public final Element clearAllCPCOption = $(".cpc_descriptions .clear_all a");
	public final Element submit = $("div.modal-content a[data-behavior= save_custom_market_sector]");
	public final Element ajaxLoader =$("img[src='/images/ajax-loader.gif']");
	public final Element defendantChild = $("#child_954135");
	public final Element patentChild = $("#treemultiselect-0-91");

	public final Element ALLOption = $("#selected_market_sectors>option");
	public final Element customsectorTitle = $("div.cust-filters div.parent-checkbox:contains('{value}') div");
//	public final Element customSectordropdown = $("div.market-sectors .ms-parent button.ms-choice");
//	public final Element dropdownSearchBox = $("div.ms-parent  div.ms-search input");
	public final Element actualDefendantCodes = $("#custom-tree-multiselect .selected div[class='custom-section']");
	public final Element actualDefCodes = $("#custom-tree-multiselect .selected div[class='custom-section'] .item");
	public final Element actualPatentCodes = $("#cpc-tree-multiselect .selected div[class='section']");
			//".cpc_descriptions .tree-multiselect .selected>.section>.title");
	public final Element actualPatCodes = $(".cpc_descriptions .tree-multiselect .selected>.section .section>.title");

	public final Element selectedDefendantCodes = $(".tree-multiselect .selected>div");
	public final Element editDefendantCodes = $("div[title='111150 - Corn Farming' ]");
	public final Element editPatentCPCodes = $("div[title='D - TEXTILESPAPER' ] input");



	public final Element visibleNIACS = $("div[title='-1 - Unknown NAICS Code'] label");
	public void accessNew(){
		addCustomSectorLink.click();
		loading.waitUntilNoElementPresent();
		visibleNIACS.waitUntilVisible();
	}

    //public final Element globalCustomSectorOption = $x(".//*[@id='selected_market_sectors']/optgroup[1]/option[text()='{value}']");
	public final Element CustomSectorOption = $("#facet-search-modal ul.refine_facets_list li:contains('{value}') div.checked");
	public final Element CustomSectorOptionSelect = $("#facet-search-modal ul.refine_facets_list li:contains('{value}') div");
	public final Element showMoreSectorOptions = $("#facet-search-modal .facet_options li");
	public final Element yourCustomShowMore = $("div.controls a[data-modal-title='Your Custom Sectors']");
	public final Element curatedSectorShowMore = $("div.controls a[data-modal-title='RPX Curated Sectors']");
	public final Element facetSearch = $("#facet-search-modal input#facet_refine_search");
	public final Element customSectorSubmitBtn = $("#facet-search-modal a.submit_btn");
	public final Element customSectorCancelBtn = $("#facet-search-modal a.cancel_btn");
	public void accessEdit(String customName) throws Exception{
		selectCustomSector(customName);
		editCustomSectorLink.click();
		Thread.sleep(3000);
		ajaxLoader.waitUntilInvisible();
		visibleNIACS.waitUntilVisible();
	}

	public void selectCustomSector(String cName){
		clickCustomSectorShowMore();
		facetSearch.sendKeys(cName);
		if(!CustomSectorOption.of(cName).isDisplayed()){
			CustomSectorOptionSelect.of(cName).click();
		}
		customSectorSubmitBtn.click();
	}

	public void selectCuratedSector(String cName){
		clickCuratedSectorShowMore();
		facetSearch.sendKeys(cName);
		if(!CustomSectorOption.of(cName).isDisplayed()){
			CustomSectorOptionSelect.of(cName).click();
		}
		customSectorSubmitBtn.click();
	}

	public void clickCustomSectorShowMore(){
		yourCustomShowMore.click();
		showMoreSectorOptions.waitUntilVisible();
	}

	public void clickCuratedSectorShowMore(){
		curatedSectorShowMore.click();
		showMoreSectorOptions.waitUntilVisible();
	}

    public void selectDefendantCodes(String[] dcodesArray)
	{
		if(dcodesArray != null) {
			for (String dcodes : dcodesArray) {
				codesForDefendantPatent.of(dcodes).waitUntilClickable();
				codesForDefendantPatent.of(dcodes).click();
			}
		}
	}

	public void selectPatentCodes(String[] pcodesArray){
		if(pcodesArray!=null) {
				for (String pcodes : pcodesArray) {
					codesForDefendantPatent.of(pcodes).click();
				}
		}
	}

	public ArrayList<String> getExpectedDefendantCodes(String[] dcodesArray) {
		ArrayList<String> dCodesArray = new ArrayList<String>(Arrays.asList(dcodesArray));
		return dCodesArray;
	}

	public ArrayList<String> getExpectedPatentCodes(String[] pcodesArray) {
		ArrayList<String> pCodesArray = new ArrayList<String>(Arrays.asList(pcodesArray));
		return pCodesArray;
	}

	public final Element errorSelector = $(".small-8 .errors");
    public final Element customSectorVisibility = $(" .small-12 input[name='{value}']");

	public void saveCustomSectorData(String[] dcodesArray, String[] pCodesArray, String unionOption, String customName){
		selectDefendantCodes(dcodesArray);
		nextButton.click();
		selectPatentCodes(pCodesArray);
		nextButton.click();
		unionSelection.of(unionOption).select();
		customMArketSectorName.sendKeys(customName);
		if(customName.contains("global")) customSectorVisibility.of("is_public").select();
        else if(customName.contains("org")) customSectorVisibility.of("organizational").select();
		submit.click();
		loading.waitUntilNoElementPresent();
		contentLoading.waitUntilNoElementPresent();
		detailPageTitle.waitUntilVisible();
	}

	public final Element customSectorAllOption = $("div.ms-parent li.group:has(label:contains('Your Custom Sectors'))+li input");
	public void deleteCustomSector(String cName){
		detailPageTitle.waitUntilTextPresent("Custom Sector Analytics");
		selectCustomSector(cName);
		deleteCustomSectorLink.waitUntilVisible();
		deleteCustomSectorLink.click();
		acceptAlert();
		loading.waitUntilNoElementPresent();
		detailPageTitle.waitUntilVisible();
	}

	public final Element NAICSSearchTextbox = $("#custom-tree-multiselect input[class='search']");
	public final Element CPCSearchTextbox = $("#cpc-tree-multiselect input[class='search']");
	public final Element viewMoreOption = $("div.custom-section .view_more");
	public final Element viewMoreLoading = $("div.custom-section .view_more:contains('Loading...')");
	public final Element NAICSCodesBeforeViewMore = $("#custom-tree-multiselect .selections>div:nth-of-type(2) div[class='item']");
	public final Element invalidNAICSDataLoc = $("#custom-tree-multiselect .selections");
	public final Element invalidCPCDataLoc = $("#cpc-tree-multiselect .selections");
	public final Element visibleSearchNIACS = $("div[title='112519 - Other Aquaculture'] label");

	public void searchCodes(String searchText, String codeOption) throws Exception {
		if (codeOption == "NAICS")
			NAICSSearchTextbox.sendKeys(searchText);
		else
			CPCSearchTextbox.sendKeys(searchText);
		if (searchText != "TestingInvalidData@" && searchText != "Z1autoinvalid@") {
			codesForDefendantPatent.of(searchText).waitUntilVisible();//eDekka LLC
			codesForDefendantPatent.of(searchText).click();
		} if (searchText == "TestingInvalidData@") {
			Thread.sleep(2000);
			NAICSSearchTextbox.sendKeys(Keys.ENTER);
			loading.waitUntilNoElementPresent();
		}else if(searchText == "Z1autoinvalid@"){
				Thread.sleep(2000);
				CPCSearchTextbox.sendKeys(Keys.ENTER);
				loading.waitUntilNoElementPresent();
			}
		}

	public void dataForSearchCodes(String NAICSSearchText, String CPCSearchText, String customName) throws Exception{
		searchCodes(NAICSSearchText, "NAICS");
		nextButton.click();
		searchCodes(CPCSearchText, "CPC");
		nextButton.click();
		customMArketSectorName.sendKeys(customName);
		submit.click();
	}

}
