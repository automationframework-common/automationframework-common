package com.rpxcorp.insight.test.functional;


import com.rpxcorp.insight.page.LoginPage;
import com.rpxcorp.insight.page.account.AlertAnnouncementPage;
import com.rpxcorp.testcore.Assert;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.oldtest.util.EmailApiUtil;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Authenticate(role = "ADMIN")
public class AlertAnnouncementTest extends BaseFuncTest{
    AlertAnnouncementPage announcementPage;

    public void setupTestData() throws Exception {
        this.testData=getJsonTestData(this.getClass().getSimpleName()+".json");
        HashMap<String, String> param = new HashMap<>();
        param.put("title","Quarterly Update");
        processDB("RESET_ALERT_ANOUNCEMENT",param);
    }

    @Test(groups = "P3")
    public void previewAnnouncement() throws Exception {
        to(announcementPage);
        announcementPage.accessPreviewMail();
        String subject = announcementPage.previewMail.getText();
        assertEquals(announcementPage.previewModal_Subject.getValue(),subject);

    }
    @Test(priority = 1, groups = "P3")
    public void verifyDefaultEditRecipientOption() throws Exception {
        to(announcementPage);
        Assert.isEquals(announcementPage.recipents_Roles.getText(),"All");
        Assert.isEquals(announcementPage.recipents_UserGroup.getText(),"All");
        announcementPage.accessEditRecipients();
        Assert.isEquals(announcementPage.editModal_RoleList.getAllField(),dataAsList("User Roles"));
        Assert.isEquals(announcementPage.editModal_UserGroupList.getAllField(),dataAsList("User Groups"));
        Assert.isEquals(announcementPage.editModal_RoleList.getSelectedField(),dataAsList("Default User Roles"));
        Assert.isEquals(announcementPage.editModal_UserGroupList.getSelectedField(),dataAsList("Default User Groups"));
    }

    @Test(priority = 2, groups = "P3")
    public void editRecipientsBySelectingAll() throws Exception {
        to(announcementPage);
        announcementPage.accessEditRecipients();
        announcementPage.editModal_UserGroupList.selectAll();
        announcementPage.editModal_RoleList.selectAll();
        announcementPage.saveEditRecipients();
        Assert.isEquals(announcementPage.recipents_Roles.getText(),"All");
        Assert.isEquals(announcementPage.recipents_UserGroup.getText(),"All");
        announcementPage.accessEditRecipients();
        Assert.isEquals(announcementPage.editModal_RoleList.getSelectedField(),dataAsList("Default User Roles"));
        Assert.isEquals(announcementPage.editModal_UserGroupList.getSelectedField(),dataAsList("Default User Groups"));
    }

    @Test(priority = 3, groups = "P3")
    public void editRecipientsByChangingOptions() throws Exception {
        to(announcementPage);
        announcementPage.accessEditRecipients();
        announcementPage.editModal_RoleList.selectAll();
        announcementPage.editModal_UserGroupList.unselect("Quarterly Feature Release recipients");
        announcementPage.editModal_RoleList.selectNone();
        announcementPage.editModal_RoleList.select("prime");
        announcementPage.editModal_RoleList.select("basic");
        announcementPage.saveEditRecipients();
        announcementPage.recipents_Roles.waitUntilTextPresent(",");
        Assert.isEquals(announcementPage.recipents_Roles.getText().toLowerCase().split(", "),dataAsList("Changed User Roles"));
        Assert.isEquals(announcementPage.recipents_UserGroup.getText().split(", "),dataAsList("Changed User Groups"));
        announcementPage.accessEditRecipients();
        Assert.isEquals(announcementPage.editModal_RoleList.getSelectedField(),dataAsList("Changed User Roles"));
        Assert.isEquals(announcementPage.editModal_UserGroupList.getSelectedField(),dataAsList("Changed User Groups"));
    }

    @Test(priority = 4, groups = "P3")
    public void editRecipientsBySelectingNone() throws Exception {
        to(announcementPage);
        announcementPage.accessEditRecipients();
        announcementPage.editModal_RoleList.selectAll();
        announcementPage.editModal_UserGroupList.selectNone();
        announcementPage.editModal_DoneBtn.click();
        Assert.isEquals(announcementPage.acceptAlert(),"Please select atleast one checkbox from each section.");
        announcementPage.editModal_UserGroupList.selectAll();
        announcementPage.editModal_RoleList.selectNone();
        announcementPage.editModal_DoneBtn.click();
        Assert.isEquals(announcementPage.acceptAlert(),"Please select atleast one checkbox from each section.");
    }

    @Test(priority = 5, groups = "P3")
    public void closeEditRecipientsModel() throws Exception {
        to(announcementPage);
        announcementPage.accessEditRecipients();
        List<String> roleSelectedBefore = announcementPage.editModal_RoleList.getSelectedField();
        List<String> userGroupSelectedBefore = announcementPage.editModal_UserGroupList.getSelectedField();
        announcementPage.editModal_UserGroupList.getSelectedField();
        announcementPage.editModal_UserGroupList.selectNone();
        announcementPage.editModal_UserGroupList.select("Weekly Newsletter recipients");
        announcementPage.editModal_RoleList.selectAll();
        announcementPage.editModal_RoleList.unselect("elite");
        announcementPage.closeEditRecipients();
        announcementPage.accessEditRecipients();
        Assert.isEquals(announcementPage.editModal_RoleList.getSelectedField(),roleSelectedBefore);
        Assert.isEquals(announcementPage.editModal_UserGroupList.getSelectedField(),userGroupSelectedBefore);
    }

    @Test(priority = 6, groups = "P3")
    public void sendMailToRecipients() throws Exception {
        // : GIVEN
        String emailId="alert_announcement.ba6f4fe1@mailosaur.io";
        // : SET UP
        EmailApiUtil.deleteRecipientEmails(emailId);
        deleteUser(emailId);
        createUserIfDontExists(emailId, LoginPage.ROLES.PLUS);
        // : TEST
        to(announcementPage);
        announcementPage.accessEditRecipients();
        announcementPage.editModal_UserGroupList.selectNone();
        announcementPage.editModal_UserGroupList.select("Beta testers");
        announcementPage.editModal_RoleList.selectNone();
        announcementPage.editModal_RoleList.select("plus");
        announcementPage.saveEditRecipients();
        announcementPage.sendMail();
        System.out.println(announcementPage.mailSent_Date.getText());
        Map<String, String> content = EmailApiUtil.getEmailContent(emailId, 0);
        Assert.isTrue(content.get("subject").contains("Quarterly Update"),"");
    }
}
