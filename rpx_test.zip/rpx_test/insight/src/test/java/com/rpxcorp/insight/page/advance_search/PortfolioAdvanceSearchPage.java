package com.rpxcorp.insight.page.advance_search;

import java.util.Map;

import com.rpxcorp.insight.module.AutoComplete;
import com.rpxcorp.insight.module.DatePicker;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import org.openqa.selenium.JavascriptExecutor;

public class PortfolioAdvanceSearchPage extends AdvanceSearchPage {
    public PortfolioAdvanceSearchPage() {
        this.url = new PageUrl("advanced_search#portfolioTab");
    }
    @Override
    public boolean at() {
        return portfolio_inventorName.waitUntilVisible();
    }

    //locators for portfolio tab are added in the AdvanceSearchPage
    public final Element submitButton = $(".active input[name='commit']");

    public void search(Map<String, String> data) {
        portfolio_portfolioName.sendKeys(data.get("Portfolio Name"));
        portfolio_title.sendKeys(data.get("Title"));
        portfolio_abstractTextBox.sendKeys(data.get("Abstract Text Box"));
        portfolio_claims.sendKeys(data.get("Claims"));
        portfolio_assetNumber.sendKeys(data.get("Asset Number"));
        portfolio_inventorName.sendKeys(data.get("Inventor Name"));
        portfolio_currentAssignee.sendKeys(data.get("Current Assignee"));
        portfolio_allAssignee.sendKeys(data.get("All Assignee"));
        portfolio_originalAssignee.sendKeys(data.get("Original Assignee"));
        JavascriptExecutor js = (JavascriptExecutor) getDriver();
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        submitButton.click();
    }
}
