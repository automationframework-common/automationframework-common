package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.module.Table;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;

public class RpxAccountPage extends Page {

    public RpxAccountPage() {
        this.url = new PageUrl("admin/rpx_accounts");
    }

    @Override
    public boolean at() {
        return activeRpxMember_Table.waitUntilVisible();
    }

    public final Element activeRpxMember_Table = new Table(".search_results .large-9.columns>table");

}
