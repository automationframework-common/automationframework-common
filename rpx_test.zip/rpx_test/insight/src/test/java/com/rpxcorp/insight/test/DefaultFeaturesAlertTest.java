package com.rpxcorp.insight.test;

import com.rpxcorp.testcore.UITest;
import com.rpxcorp.testcore.util.SQLProcessor;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

public class DefaultFeaturesAlertTest extends UITest {

    SQLProcessor sqlProcessor = SQLProcessor.getInstance();

    @Test(description = "Verify the default settings for Weekly News letter and notify team in case of deviation",groups = "WeeklyFeature")
    public void checkWeeklyDefaultSchedule() throws Exception {
        HashMap<String, Map<String, String>> weeklyNewsLetterFeature=new HashMap<>();
        String is_Updated,updated_by,updated_at,scheduled_at;
        ResultSet resultSet=sqlProcessor.getResultData("DefaultFeatures.WEEKLY");
        weeklyNewsLetterFeature=sqlProcessor.getResultDataAsMultiMap(resultSet,"feature_name","is_default_schedule_updated","updated_by","scheduled_at_utc","feature_name","updated_at_utc");
        is_Updated=weeklyNewsLetterFeature.get("weekly_newsletter_datetime").get("is_default_schedule_updated");
        updated_at=weeklyNewsLetterFeature.get("weekly_newsletter_datetime").get("updated_at_utc");
        updated_by=weeklyNewsLetterFeature.get("weekly_newsletter_datetime").get("updated_by");
        scheduled_at=weeklyNewsLetterFeature.get("weekly_newsletter_datetime").get("scheduled_at_utc");
        System.out.println(is_Updated+":"+is_Updated.getClass().getSimpleName());
        if(is_Updated.contains("t"))
        Assert.fail("The weekly Email default trigger is changed to "+scheduled_at+" UTC by "+updated_by+" at "+updated_at+" UTC");
    }

    @Test(description = "Verify the default feature for Daily Litigation Party Alert and notify team in case of deviation",groups = "DLAFeature")
    public void checkDefaultFeatureFlag() throws Exception {
        HashMap<String, Map<String, String>> weeklyNewsLetterFeature=new HashMap<>();
        String is_Changed,updated_by,updated_at;
        ResultSet resultSet=sqlProcessor.getResultData("DefaultFeatures.DLA_PARTY_TYPE_FLAG");
        weeklyNewsLetterFeature=sqlProcessor.getResultDataAsMultiMap(resultSet,"feature_name","is_default_feature_updated","updated_by","updated_at","feature_name");
        is_Changed=weeklyNewsLetterFeature.get("Daily Litigation alert party tag").get("is_default_feature_updated");
        updated_at=weeklyNewsLetterFeature.get("Daily Litigation alert party tag").get("updated_at");
        updated_by=weeklyNewsLetterFeature.get("Daily Litigation alert party tag").get("updated_by");
        System.out.println("Feature Flag Status"+is_Changed);
        if(is_Changed.contains("t")) {
            String status = "Disabled";
            Assert.fail("The default feature flag for Daily Litigation Party Alert is " + status +" by  " + updated_by + " at " + updated_at + " UTC");
        }
    }




}
