package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class AdminPage extends BasePage {

    public AdminPage() {
        this.url = new PageUrl("admin");
    }

    @Override
    public boolean at() {
        assert page_title.text().equals("Administration");
        return adminMenu_list.waitUntilVisible();
    }
    public final Element page_title = $("h5.section-title");
    public final Element adminMenu_list = $("#content .large-12 ul");

    public final Element npeReportLink = $(".admin-navbar-items li>a[href='/admin/npe_reports']");

}
