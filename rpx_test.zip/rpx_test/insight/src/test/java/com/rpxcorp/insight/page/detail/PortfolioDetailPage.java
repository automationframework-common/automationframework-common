package com.rpxcorp.insight.page.detail;

import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.insight.module.ListPanel;

public class PortfolioDetailPage extends BasePage {

	public PortfolioDetailPage() {
		this.url = new PageUrl("portfolios/{ID}");
	}

	@Override
	public boolean at() {
		waitForPageLoad();
		return portfolioDetailPageTitle.waitUntilVisible();
	}

	//AUTHORIZATION
	public final Element portfolioDetailPageTitle=$(".portfolios-page.portfolios-show.insight");
	public final Element assignee_section=$(By.xpath("//*[text()[contains(.,'Assignees')]]"));
	public final Element sellerBroker_section=$(By.xpath("//*[text()[contains(.,'Seller/Broker Information')]]"));
	public final Element download_FastFacts=$(By.xpath("//a/span[text()='Download Fast Facts']"));

	//TITLE AND SOURCE
	public final Element source = $(By.xpath("//h3[contains(text(),'Source')]"));
	public final Element acquition_date = $(".header-info.details.subtitle li:has(b:contains(Acquisition Date:))");
	public final Element fastFacts = $(By.xpath("//span[contains(text(),'Fast')]/.."));
	public String getFastFactId(){		
		if(fastFacts.isDisplayed()) {
			return fastFacts.getAttribute("href").substring(fastFacts.getAttribute("href").indexOf("portfolios") + 1).replaceAll("\\D+","").trim();
		}
		return "";
	}

	//METRICS
	public final StaticContent metrics = $("#metric-statistics", (Configure<StaticContent>) dataForm ->
		{
			dataForm.content("us_patent", "div.columns div.metrics_card:contains(US Patents) div.count");
			dataForm.content("int_patent", "div.columns div.metrics_card:contains(International Patents) div.count");
			dataForm.content("us_application", "div.columns div.metrics_card:contains(US Applications) div.count");
			dataForm.content("int_application", "div.columns div.metrics_card:contains(International Applications) div.count");
		}
	);

	//ASSIGNEE 
	public final Table assignees_table = $("table.assignee-table", (Configure<Table>) table ->
		{
			table.uniqueId("td:nth-child(1) a[href]");
			table.displayedRecords("#campaign_accused_products tbody tr:not([style*='none'])");
			table.viewAllLink(By.xpath("//div[@id='current_assignee']//span[2]/a[contains(text(),'View All')]"));
			table.viewLessLink(By.xpath("//div[@id='current_assignee']//span[2]/a[contains(text(),'View Less')]"));
		}
	);
	public final Element portfolioLinkInAssignees = $(".assignee-table .normal_whitespace");
	public final Element noAssigneesMsg = $("#current_assignee .panel.table-margin>p");

	//SELLER/BROKER INFORMATION
	public final Element sellerBrokerTitle = $("#seller_broker_information h2");
	public final Table seller_table = $("table.seller-table", (Configure<Table>) table ->
		{
			table.uniqueId("td:nth-child(1) a[href]");
			table.displayedRecords(".seller-table tbody tr:not([style*='none'])");
			table.viewAllLink(By.xpath("//div[@id='seller_broker_information']//span[2]/a[contains(text(),'View All')]"));
			table.viewLessLink(By.xpath("//div[@id='seller_broker_information']//span[2]/a[contains(text(),'View Less')]"));
		}
	);
	public final Element portfolioLinkInSellerTable = $(".seller-table tbody td a");
	public final Element noSellerBrokerInfoMsg = $("#seller_broker_information .table-margin>p");

	//REPRESENTATIVE CLAIMS
	public final ListPanel representativeClaims = $("#representative_claims", (Configure<ListPanel>) list ->
		{
			list.displayedRecords("#representative_claim_records div:not([style*='none']) p>a");
			list.viewAllLink(By.xpath("//div[@id='representative_claims']//span/a[text()='View More']"));
			list.viewLessLink(By.xpath("//div[@id='representative_claims']//span/a[text()='View Less']"));
		}
	);
	public final Element representativePatentLink = $("#representative_claims .show a");
	public final Element noRepresentativeClaims = $("#representative_claims p");

	//ASSET LIST
	public final Element assetInfoTitle = $("#patents .header-section>h4");
	public final Table assets_Info = $("table.patents-table ", (Configure<Table>) table ->
		{			
			table.uniqueId("td:nth-child(2)");
			table.column("file_number","td:nth-child(2)");
			table.column("asset_number","td:nth-child(3)");
			table.column("family","td:nth-child(1)");
			table.column("est_priority_date","td:nth-child(4)");
			table.column("title","td:nth-child(5)");
			table.column("tags","td:nth-child(6)");
			table.column("litigated","td:nth-child(7)");
			table.column("ptab","td:nth-child(8)");
			table.displayedRecords("table.patents-table tbody tr:not([style*='none'])");
			table.viewAllLink(By.xpath("//div[@id='patents']//span//a[text()='View All']"));
			table.viewLessLink(By.xpath("//div[@id='patents']//span//a[text()='View Less']"));
		}
	);

	public final Table assets_Info_func = $("table.patents-table ", (Configure<Table>) table ->
			{
				table.uniqueId("td:nth-child(2)");
				table.displayedRecords("table.patents-table tbody tr:not([style*='none'])");
				table.viewAllLink(By.xpath("//div[@id='patents']//span//a[text()='View All']"));
				table.viewLessLink(By.xpath("//div[@id='patents']//span//a[text()='View Less']"));
			}
	);

	public final Element assetInfoAssetNumberLink = $("table.patents-table tbody tr td a[href*='/pat']");
	public final Element litigatedLink = $("table.patents-table tbody tr td a[href*='advanced']");

	//ASSIGNMENTS
	public final Element assignmentsTitle = $("#assignments div.header-section h4");
	public final Table assignmentsTable = $(".assignments-table", (Configure<Table>) table ->
		{
			table.uniqueId("td>a");
			table.displayedRecords(".assignments-table tbody tr:not([style*='none'])");
			table.viewAllLink(By.xpath("//div[@id='assignments']//a[contains(text(),'View All')]"));
			table.viewLessLink(By.xpath("//div[@id='assignments']//a[contains(text(),'View Less')]"));
		}
	);
	public final Element assigneeLinkAssignmentsTable = $(".assignments-table td a");	
	public final Element noAssignmentsMsg = $("#assignments .body-section>p");

	public final Element tags = $("#tags", (Configure<ListPanel>) list ->
		{
			list.dataKey(".panel:has(.tags) li");
		}
	);
	public final Element tagsTitle = $("#tags .header-section>h4");
	public final Element noTagsMsg = $("#tags .body-section>p");
}

