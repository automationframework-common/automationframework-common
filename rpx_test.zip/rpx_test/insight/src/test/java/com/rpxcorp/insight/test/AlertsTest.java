package com.rpxcorp.insight.test;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.rpxcorp.insight.util.AlertHarness;
import com.rpxcorp.testcore.util.ConfigLoader;
import com.rpxcorp.testcore.util.ConfigUtil;
import org.apache.commons.lang3.StringUtils;
import org.testng.ITest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.io.File;
import java.util.*;


public class AlertsTest extends AlertHarness implements ITest {
    public static final Properties config = ConfigUtil.config();
    static final String testSuitePath = config.get("testResourcesDir")
            + "/test_case/alerts_test/";
    String testSuiteName;

    @Factory(dataProvider = "testSuites")
    public AlertsTest(String testSuiteName) {
        System.out.println(testSuiteName);
        this.testSuiteName = testSuiteName;
    }

    @Test(dataProvider = "testCases")
    public void checkAlerts(String testName, String testDescription, JsonObject testSteps) throws Exception {
        System.out.println("------------------------------");
        System.out.println(testName);
        System.out.println(testDescription);
        for (Map.Entry<String, JsonElement> testStep : testSteps.entrySet()) {
            System.out.println("Started: "+testStep.getKey());
            executeSteps(testStep.getKey(),testStep.getValue());
        }
    }


    /* * * * CONFIGURATION * * * */

    @DataProvider
    public Object[][] testSuites() throws Exception {
        String selectiveTest =config.getProperty("test");
        List<String> selectiveTests = new ArrayList<>();
        //Selective Testsuites
        if(selectiveTest != null)
            selectiveTests = Arrays.asList(selectiveTest.split(","));
        File[] listOfFiles = new File(testSuitePath).listFiles();
        ArrayList<String> tests = new ArrayList<>();
        for (int i = 0; i < listOfFiles.length; i++) {
            String fileName=listOfFiles[i].getName();
            if(selectiveTests.contains(fileName.split(".json")[0])&&!StringUtils.isEmpty(selectiveTest)) {
                tests.add(fileName);
            }
        }
        Object[][] testSuites = new String[tests.size()][1];
        int j=0;
        for (String test:tests){
            testSuites[j][0]=test;
            j++;
        }
        return testSuites;
    }

    @DataProvider
    public Object[][] testCases() throws Exception {
        JsonObject json = ConfigLoader.loadJson(testSuitePath + this.testSuiteName);//+".json"
        Set<Map.Entry<String, JsonElement>> testCases = json.entrySet();
        Object[][] testdata = new Object[testCases.size()][3];
        int i = 0;
        for (Map.Entry<String, JsonElement> testCase : testCases) {
            testdata[i][0] = testCase.getKey();
            JsonObject testObject = testCase.getValue().getAsJsonObject();
            testdata[i][1] = testObject.get("description").getAsString();
            testdata[i][2] = testObject.get("test_step").getAsJsonObject();
            i++;
        }
        return testdata;
    }

    @Override
    public String getTestName() {
        return this.testSuiteName;
    }

    /* * * * * * HELPER CLASS * * * * * */

    private void executeSteps(String stepName,JsonElement stepData) throws Exception {
        if(stepName.startsWith("#"))
            return;
        switch (stepName){
            case "input_events":
                insertAlertData(stepData);
                break;
            case "waitFor.cortal":
                waitForCortal(5,900,stepData); //2100
                break;
            case "waitFor.solr":
                waitForSolr(5,900,stepData); //2100
                break;
            case "subscribe":
                subscribe(stepData.getAsJsonObject());
                break;
            /*case "triggerMail":
                String date= DateFormatUtils.format(new Date(), "YYYY-MM-DD");
                triggerMail(stepData.getAsString(),date+" 12:15");
                break;*/
            case "assert.solr":
                assertSolr(stepData.getAsJsonObject());
                break;
            /*case "assert.mail":
                assertMail(stepData.getAsJsonObject());
                break;*/
            case "assert.subscription":
                assertSubscription(stepData.getAsJsonObject());
                break;
            case "setDataId":
                setDataId(stepData.getAsString());
                break;
        }
    }

}

