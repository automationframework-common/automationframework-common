package com.rpxcorp.insight.page.search;

import com.rpxcorp.insight.module.DatePicker;
import com.rpxcorp.insight.page.detail.BaseDetailPage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

import java.util.List;

import static java.lang.Thread.sleep;

public class NewsSearchPage extends BaseDetailPage {

    public NewsSearchPage() {
        this.url = new PageUrl("news/details");
        url.param("SEARCH NEWS", "searchq");
        url.param("FROM DATE", "news_browser_controls[from]");
        url.param("TO DATE", "news_browser_controls[to]");
        url.param("CATEGORIES", "news_browser_controls[category_ids][]");
        url.param("MARKET SECTORS", "news_browser_controls[market_sector_ids][]");
    }

    @Override
    public boolean at() {
        return newsSearchHolder.waitUntilVisible();
    }
    /* CONTENT OF NEWS SEARCH PAGE * */
    public final Element newsSearchHolder = $("#search_holder");
    public final String newsCategory = "//label[contains(text(),'";
    public final Element searchButton = $(".filter .small.button[value='Search']");
    public final Element categoriesInResults = $(".panel .categories");
    public final Element newsTitle = $(".articles_list .news_details_title");
    public final Element newsDate = $(".articles_list .date");
    public final Element newsDetail = $(".articles_list .news_details_excerpt");
    public final Element newsReadmore = $(".articles_list .news_read_more a");
    public final Element newsLists = $(".articles_list .panel");
    public final Element total_result_count =$("#search_results_replaced_content div.count-info p");
    public final Element total_result_count_NoPagination =$(".note:contains('Displaying') b:eq(0)");
    public final Element pagination = $("#pagination_section li.arrow:not(li.arrow.unavailable) a:contains('Next')");
    public final Element marktMsgTitle = $("span.anonymous_news_msg:contains('RPX publishes the latest news')");
    public final Element marktMsgSubscrbBtn = $(".homepage_subscribe_banner .button[href='/subscribe']");
    
    //SEARCH OPTIONS
    public final DatePicker fromDate = $("#news_browser_controls_from", DatePicker.class);
    public final DatePicker toDate = $("#news_browser_controls_to",DatePicker.class);

    public void selectCategory(String category) {
        $(".facet-header-title:contains('Categories')+div label:contains('"+category+"') input").click();
    }

    public int getNewsCountFromDisplayingContent(){
        int newsCount=0;
        if(!pagination.isPresent()){
            String newsText = total_result_count_NoPagination.getText();
                if(!newsText.contains("all")){
                    newsCount = Integer.parseInt(newsText.trim());
                }else{
                    String[] newsCountSplit = total_result_count_NoPagination.getText().split(" ");
                    newsCount = Integer.parseInt(newsCountSplit[1].trim());
                }
        }else{
            String[] countString = total_result_count.getText().split("of");
            newsCount = Integer.parseInt((countString[1]).replaceAll("[\\D]", "").trim());
        }
        return newsCount;
    }

    public int getResultsDisplayedCount() throws  Exception{
        List<String> resultsCount = newsLists.getAllData();
        int resultsDisplayed = resultsCount.size();
        while (pagination.isPresent()) {
            pagination.click();
            sleep(2000);
            loading.waitUntilInvisible();
            resultsCount = newsLists.getAllData();
            resultsDisplayed = resultsDisplayed + resultsCount.size();
        }
        return resultsDisplayed;

    }
}
