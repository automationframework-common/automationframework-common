package com.rpxcorp.insight.page;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.rpxcorp.testcore.element.StaticElement;
import com.rpxcorp.testcore.page.StaticPage;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class AlertMailPage extends StaticPage {
    public StaticElement summaryTable = $(".summary_table tr");
    public StaticElement dcPartyInfo =$("table[id^=dc]");

    public JsonObject getSummaryData(){
        JsonObject json = new JsonObject();
        Elements rows = summaryTable.getElements();
        String subHeader = null;
        for (int i = 1; i < rows.size();i++) {
            Element row = rows.get(i);
            JsonObject entry = new JsonObject();
            entry.addProperty("New Matters",row.child(1).text());
            entry.addProperty("Party Updates",row.child(2).text());
            entry.addProperty("Docket Updates",row.child(3).text());
           if(row.classNames().contains("subheader")){;
               entry.add("entry",new JsonArray());
               subHeader=row.child(0).text();
               json.add(subHeader,entry);

            } else {
               json.getAsJsonObject(subHeader).getAsJsonArray("entry").add(entry);
            }
        }
        return json;
    }

    public JsonObject getDCEvents(){
        JsonObject json = new JsonObject();
        Elements rows = dcPartyInfo.getElements();
        for (int i = 0; i < rows.size();i++) {
            Element row = rows.get(i);
            JsonObject dcinfo = new JsonObject();
            JsonArray events = new JsonArray();
            Element campaign = row.select("a[href*=/campaigns/]").get(0);
            Element lit = row.select("a[href*=/lit/]").get(0);
            dcinfo.addProperty("Campaign Name",campaign.text());
            dcinfo.addProperty("Campaign Link",campaign.attr("href"));
            dcinfo.addProperty("Litigation Name",lit.text());
            dcinfo.addProperty("Litigation Link",lit.attr("href"));
            dcinfo.addProperty("Patent",row.select("table:eq(2) th:eq(1)").text().replaceAll("\\\\r","").replaceAll("\\\\n","").trim());
            dcinfo.addProperty("Date Filed",row.select("table:eq(3) th:eq(0)").text().replaceAll("\\\\r","").replaceAll("\\\\n","").substring(13));
            //-------- PARTY INFO -----
            Elements party_infos = row.select(".party_info");
            for(Element party_info : party_infos){
                Elements headings =party_info.select(".party_header td");
                for (int j = 0; j < headings.size();j++) {
                    JsonObject event = new JsonObject();
                    Elements value = party_info.select(".party_details td:eq(" + j + ")");
                    String parties="";
                    for(Element val : value){
                        parties+=val.text()+",";
                    }
                    event.addProperty(headings.get(j).text(),parties);
                    events.add(event);
                }
            }
            //--------
            dcinfo.add("events",events);
            json.add(row.attr("id").substring(3),dcinfo);
        }

    return json;
    }
}

