package com.rpxcorp.insight.page.detail;

import com.rpxcorp.insight.module.Radio;
import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

public class LawfirmDetailPage extends BaseDetailPage{
	
	public LawfirmDetailPage() {
		this.url = new PageUrl("lawfirms/{ID}");
    }


	public final Element sectionTitle = $("div.handle");
	public final Element panelTitle = $("div.panel.activity .section-title");
	public final Element lawfirmPageTitle = $(".small-11 h1");
    public final Element lawFirmUpgradePromoMessage = $("section#content div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element lawfirm_section_SignOnMsg=$("section#content div.subscription-promo-message:contains('Sign In')");
	public final Element ChineseOnlylawFirmUpgradePromoMessage = $("section#content div.subscription-promo-message:contains('Start with a Free Trial')");
	//public final Element lawfirmTotalCasesCount = $(".entity-stats .metrics_card:contains('Total Cases') .count");

	public final Element litigationsCount = $("#litigation-cases div.columns div.row div.metrics-round-shape");
	public final Element litigationsCountText = $("#litigation-cases div.columns div.row h5");
	public String getSectionLitigationCountText(){
		String litCountText = litigationsCount.getText().concat(" "+litigationsCountText.getText());
		return litCountText;
	}
	//public final Element litigationsNoCaseFoundText = $("#litigation-cases .large-12 span");
	public final Element litigationsNoCaseFoundText = $("#litigation-cases .large-12 span:contains(No  cases found)");


	public final Element clearBtn = $("#clear_search_form");

	public final Element caseType = $("div#litigation-cases .choose-box select#cases_type");

	public void applyStatusFilterForLitigation(String filterOption){
		caseType.waitUntilVisible();
		caseType.selectByOption(filterOption);
		loading.waitUntilInvisible();
	}
//	public final Element allOption = $("#all-case-type");
//	public final Element activeOption = $("#active-case-type");
//	public final Element inactiveOption = $("#inactive-case-type");


	public final Element paginationSelectedOption = $(".current");

	public final Element lawfirmStatTitle = $(".lawfirm-stats-by-litigations h5");

		public final Element totalPartiesRespresented = $("#total-parties-represented");

	public final Element lawfirmStatGraphForPartiesRepresented= $("#lawfirm_stats_top_parties_represented .graph");
	public final Element lawfirmStatGraphForJudges= $("#lawfirm_stats_top_judges .graph");
	public final Element lawfirmStatGraphForVenue= $("#lawfirm_stats_top_venues .graph");

	public final Element litigationsTableRowTitle = $("#litigation-cases table tr");

	public final Element lawfirmSectionLeftdGreyedBArs = $("dGreyColor");
	public final Element lawfirmSectionRightlGreyedBArs = $("lGreyColor");

	private  String extractCount;
	private String expectedTotalCount;


	@Override
    public boolean at() {
        loading.waitUntilNoElementPresent();
        return waitForPageLoad();
        //return title.waitUntilVisible();
    }

	public final Element clearButton = $("span.search_action_container a#clear_docket_form");
	public void searchLitigation(String searchKey) {
		if (!clearButton.isDisplayed()) {
			searchBtnClickInLitigationTable(searchKey);
		}else {
			clearButton.click();
			loading.waitUntilInvisible();
			clearButton.waitUntilInvisible();
			searchBtnClickInLitigationTable(searchKey);
		}
	}

	public void clear() {
		clearButton.click();
		loading.waitUntilInvisible();
	}


	public final Element litigationSearchBtn = $("div.search_container span.search_action_container input[name='commit']");
	public final Element litigationSearchBox = $("span.search_text_container input.search_text");
	public void searchBtnClickInLitigationTable(String searchKey) {
		litigationSearchBox.sendKeys(searchKey);
		litigationSearchBtn.click();
		loading.waitUntilInvisible();
	}

	public final Element avg_cases_per_year_metrics = $(".big-stats li:contains('Avg Case'):contains('Per Year')");

	public final StaticContent lawfirmProfileSection = $("#lawfirm_profile_section", (Configure<StaticContent>) dataForm ->
    	{
    	dataForm.content("Active Cases", ".profile-graph:contains(Active Cases) div.profile-bar-left");
    	dataForm.content("Inactive Cases", ".profile-graph:contains(Active Cases) div.profile-bar-right");
    	dataForm.content("Plaintiff Counsel", ".profile-graph:contains(Plaintiff Counsel) div.profile-bar-left");
    	dataForm.content("Defense Counsel", ".profile-graph:contains(Plaintiff Counsel) div.profile-bar-right");
    	dataForm.content("Counsel for NPE", ".profile-graph:contains(Counsel for NPE) div.profile-bar-left");
    	dataForm.content("Counsel Against NPE", ".profile-graph:contains(Counsel for NPE) div.profile-bar-right");
    	dataForm.content("Lead Counsel", ".profile-graph:contains(Lead Counsel) div.profile-bar-left");
    	dataForm.content("Others", ".profile-graph:contains(Lead Counsel) div.profile-bar-right");
    	}
	);
	
	public final StaticContent metricsSection = $(".panel-metrics", (Configure<StaticContent>) dataForm ->
	    {
	    	dataForm.content("total_cases", ".metrics_card:contains(Total Cases) .count");
			dataForm.content("petitions", ".metrics_card:contains(Total Petitions) .count");
	    	dataForm.content("parties_represented", ".metrics_card:contains(Parties Represented) .count");
	    	dataForm.content("average_cases_per_year", ".metrics_card:contains(Avg Cases Per Year) .count");
	    	dataForm.content("average_length_of_case_in_days", ".metrics_card:contains(Avg Case Length) .count");
	    }
	); 	
	
	 public final Table statsByParties = $("#stats-by-litigation", (Configure<Table>) table ->
	 	{
	      table.uniqueId("ul[id='lawfirm_stats_top_parties_represented'] a");
	      table.column("count", " ul[id='lawfirm_stats_top_parties_represented'] div[class='graph-count']");
	 	}
	);

	public final Radio topPartiesRepresented = new Radio(".choose-lawfirm-stats");

	public final Table statsByJudges = $("#stats-by-litigation", (Configure<Table>) table ->
	 	{
	      table.uniqueId("ul[id='lawfirm_stats_top_judges'] a");
	      table.column("count", " ul[id='lawfirm_stats_top_judges'] div[class='graph-count']");
	 	}
	);

	public final Table statsByVenues = $("#stats-by-litigation", (Configure<Table>) table ->
	 	{
	      table.uniqueId("ul[id='lawfirm_stats_top_venues'] a");
	      table.column("count", " ul[id='lawfirm_stats_top_venues'] div[class='graph-count']");
	 	}
	);	
	
	public final Table litigation_Section = $("#litigations-container .venue_judge_case_table", (Configure<Table>) table ->
     	{
     		table.uniqueId("td.case_title a");
     		table.nextPage("div#litigation-cases ul.pagination.pagination li:last-child");
     		table.lastPage("div#litigation-cases ul.pagination.pagination li:nth-last-child(2)");
     	}
	 );
	 
	 public final Element activeLitigation = $("#active-case-type");
	 public final Element inactiveLitigation = $("#inactive-case-type");
	 
	 public void clickActiveFilterLits() {
		 waitForPageLoad();
		 if (!activeLitigation.isSelected()) {
			 activeLitigation.click();
			 waitForPageLoad();
		 }
	 }

	 public void clickInactiveFilterLits() {
		 waitForPageLoad();
		 if (!inactiveLitigation.isSelected()) {
			 inactiveLitigation.click();
			 waitForPageLoad();
		 }
	 }

	 public String getTotalLitigationCasesCount(){
		 extractCount = metricsSection.getElement("total_cases").getText();//split("[a-zA-Z]+")
		 expectedTotalCount = extractCount;
		 return expectedTotalCount;
	 }

	 public void clickLawFirmProfileOptions(Element element){
	 	element.click();
		 litigationsCount.waitUntilVisible();
	 }

	 public String setExpectedTextforLawFirmProfileOptions(String value, String expression){
	 	String exp = value.concat(expression);
	 	loading.waitUntilNoElementPresent();
		 return exp;
	 }
	 
	 public final Table casesByMarketSector = $("ul.bar-graph", (Configure<Table>) table ->
	 	{
         table.uniqueId("div.graph-label");
         table.column("count", " .graph-count ");
	 	}
	);

	public final Table lawfirm_litigation_table = $("table.venue_judge_case_table", (Configure<Table>) table ->
			{
				table.next(".arrow a[rel='next']");
				table.prevoius(".pagination .unavailable");


			}
	);

	public final Table recent_activities = $("#recent_activity", (Configure<Table>) table ->
			{
				table.displayedRecords("#recent_activity ul:not([style*='none']) li>a:not([class])");
				table.viewAllLink(By.xpath("//div[@id='recent_activity']/span/a[text()='View All']"));
				table.viewLessLink(By.xpath("//div[@id='recent_activity']/span/a[text()='View Less']"));
			}
	);

	public final Table petition_table = $("#related_petitions_petitions table", (Configure<Table>) table ->
			{
				table.uniqueId("td:nth-child(3) a");
				table.viewAllLink(By.xpath("//div[@id='related_petitions_petitions']/a[text()='View All']"));
				table.viewLessLink(By.xpath("//div[@id='related_petitions_petitions']/a[text()='View Less']"));
				table.displayedRecords("#related_petitions_petitions table tbody tr:not([style='display: none;'])");
				table.tdViewAllLink(By.cssSelector("td:nth-child(4)"));
			}
	);
}
