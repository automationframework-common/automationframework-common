package com.rpxcorp.insight.test.functional;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.jayway.jsonpath.DocumentContext;
import com.rpxcorp.insight.api.AdminAPI;
import com.rpxcorp.insight.api.LoginAPI;
import com.rpxcorp.insight.page.AccountActivationPage;
import com.rpxcorp.insight.page.HomePage;
import com.rpxcorp.insight.page.LoginPage;
import com.rpxcorp.insight.page.LoginPage.ROLES;
import com.rpxcorp.insight.page.account.CreateUserPage;
import com.rpxcorp.insight.page.account.UserViewPage;
import com.rpxcorp.insight.page.account.UsersAddToWhiteListPage;
import com.rpxcorp.oldtest.util.EmailApiUtil;
import com.rpxcorp.testcore.UITest;
import com.rpxcorp.testcore.util.*;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpHead;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.testng.ITest;
import org.testng.annotations.AfterClass;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

// TODO Necessary methods has to be added
public class BaseFuncTest extends UITest implements ITest {



    private String jenkinsUName = "dsingaram";
    private String jenkinsPass = "GymQ^*Sb";
    private String jenkinsAPIToken = "1154b4736c3689c83b5ce239c9791d88ff"; //Need to create new token if changes in credential (Manage Jenkins -> Manager Users -> Click the User -> Configure -> API Token Section(Add new Token)
    private String jobPath = "Insight-Trigger_Rake_Task-qa-iap75";

    SQLProcessor sqlProcessor = SQLProcessor.getInstance();
    DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
    protected LoginPage loginPage;
    CreateUserPage createUserPage;
    protected HomePage homePage;
    UserViewPage userViewPage;
    UsersAddToWhiteListPage addToWhitelist;
    AccountActivationPage accountActivationPage;
    protected LoginAPI loginApi = new LoginAPI();
    protected AdminAPI adminApi = new AdminAPI();
    static final Properties config = ConfigUtil.config();
    final static String testFilePath = config.get("testResourcesDir") + "/data_queries/";
    protected HashMap<String, String> urlData = new HashMap<String, String>();
    HTTPUtil jenkins = new HTTPUtil("http://newci/job/", "dsingaram", "GymQ^*Sb");
    String unique_Id = DateFormatUtils.format(new Date(), "ddMMHHmm");

    @AfterClass(alwaysRun = true)
    public void closeBrowser() {
        clearCacheAndQuit();
    }

    @Override
    public String getTestName() {
        return "";
    }

    protected String getDBData(String queryKey) throws Exception {
        return getDBData(queryKey, "1")[0];
    }

    protected String[] getDBData(String queryKey, String limitCount) throws Exception {
        HashMap<String, String> queryParams = new HashMap<>();
        queryParams.put("LIMIT_VALUE", limitCount);
        return sqlProcessor.getListValue("FuntionalTestData." + queryKey, queryParams, "data_id");
    }

    protected int processDB(String queryKey, HashMap<String, String> queryParams) throws Exception {

        return sqlProcessor.updateData("FuntionalTestData." + queryKey, queryParams);
    }

    protected int processDB(String queryKey) throws Exception {
        return sqlProcessor.processUpdate(queryKey);
    }

    /**
     * COMMON HELPER METHODS
     **/

    // LOGIN AND LOGOUT METHODS
    public void loginAs(ROLES roleName) {
        if (getAuth() == null) {
            getDriver().manage().deleteAllCookies();
            to(loginPage);
            String username = getConfig(roleName + "_EMAIL");
            if (roleName == ROLES.LINKEDIN) {
                loginPage.loginasLinkedIn(username, getConfig(roleName + "_PSWD"));
            } else {
                loginPage.login(username, getConfig(roleName + "_PSWD"));
            }
            loginPage.waitForDashboardPage();
            setAuth(username + "::" + roleName);
        }
    }

    public void login(String userName, String password) throws Exception{
        login(userName, password, null);
    }

    public void login(String userName, String password, ROLES roleName) throws Exception{
        getDriver().navigate().to(getDriver().getCurrentUrl());
        to(loginPage);
        loginPage.login(userName, password);
        Thread.sleep(3000);
        loginPage.waitForDashboardPage();
        setAuth(userName + "::" + roleName);
    }

    public void loginFromCurrentPage(String userName, String password) {
        loginPage.login(userName, password);
        loginPage.waitForDashboardPage();
        setAuth(userName + "::");
    }

    public void loginFromCurrentPageAs(ROLES roleName) {
        String username = loginPage.loginAs(roleName);
        homePage.accountsMenu.waitUntilVisible();
        setAuth(username + "::" + roleName);
    }

    public void logout() {
        if (!loginPage.logout_link.isPresent() || !loginPage.login_link.isDisplayed()) {   //removed &&
            to(homePage, false);
            if (!loginPage.login_link.isPresent()) {
                loginPage.logout();
            }
        }

        setAuth(null);
    }

    public void closeAndOpenBrowser() {
        if (!getDriver().toString().contains("null"))
            closeBrowser();
        to(loginPage);
    }

    public void logoutAndLoginAs(ROLES roleName) {
        logout();
        at(loginPage);
        loginAs(roleName);
    }

    public void logoutAndLoginAs(String username, String password) throws Exception{
        logout();
        at(loginPage);
        login(username, password);
    }

    public void loginAsLinkedIn(String username, String password) {
        loginPage.loginasLinkedIn(username, password);
        setAuth(username + "::" + "");
    }

    public void logoutAndLoginAsLinkedIn(String username, String password) {
        logout();
        at(loginPage);
        loginAsLinkedIn(username, password);
    }

    // USER CREATE AND DELETE
    public void conformAccount(String confirmationEmail) {
        getDriver().navigate().to(confirmationEmail);
        at(homePage);
    }

    public void activateAccountAndLogin(String activationLink, String password) {
        toUrl(activationLink);
        at(accountActivationPage);
        accountActivationPage.setPassword(password);
        at(homePage);
    }

    protected void loginWithNewUser(String emailId, ROLES role) throws Exception {
        logout();
        deleteUser(emailId);
        createUser(emailId, role);
        login(emailId, "Welcome@1", role);
    }

    protected void loginWithNewUser(String emailId, String companyName, ROLES role) throws Exception {
        logout();
        deleteUser(emailId);
        createUser(emailId, companyName, role);
        login(emailId, "Welcome@1", role);
    }

    protected void loginWithNewUser(String firstName, String lastName, String companyName, String emailId, ROLES role) throws Exception {
        logout();
        deleteUser(emailId);
        createUser(firstName, lastName, companyName, emailId, role);
        login(emailId, "Welcome@1", role);
    }

    protected void createUserIfDontExists(String emailId, ROLES roles) throws Exception {
        if (!isUserExists(emailId)) {
            createUser(emailId, roles);
        }
    }

    protected boolean isUserExists(String emailId) throws Exception {
        HashMap<String, String> params = new HashMap<>();
        params.put("EMAIL", emailId);
        return sqlProcessor.getResultCount("FuntionalTestData.GET_USER", params) == 1;
    }

    protected void reCreateUser(String emailId, ROLES roles, Map<String, String> options) throws Exception {
        deleteUser(emailId);
        createUser(emailId, roles, options);
    }

    protected void reCreateUser(String emailId, ROLES roles) throws Exception {
        reCreateUser(emailId, roles, new HashMap<>());
    }

    protected void createUser(String emailId, ROLES roles) throws Exception {
        createUser(emailId, roles, new HashMap<>());
    }

    protected void createUser(String emailId, String companyName, ROLES roles) throws Exception {
        createUser(emailId, companyName, roles, new HashMap<>());
    }

    protected void createUser(String emailId, ROLES roles, Map<String, String> options) throws Exception {
        apiLoginAs(ROLES.ADMIN);
        adminApi.addToWhiteList(emailId);
        String activationLink = adminApi.createUser(emailId, roles, options);
        adminApi.activateUser(activationLink, "Welcome@1");
    }

    protected void createUser(String emailId, String companyName, ROLES roles, Map<String, String> options) throws Exception {
        apiLoginAs(ROLES.ADMIN);
        adminApi.addToWhiteList(emailId);
        String activationLink = adminApi.createUser(emailId, companyName, roles, options);
        adminApi.activateUser(activationLink, "Welcome@1");
    }

    protected void createUser(String firstName, String lastName, String companyName, String emailId, LoginPage.ROLES roles) throws Exception {
        apiLoginAs(ROLES.ADMIN);
        adminApi.addToWhiteList(emailId);
        String activationLink = adminApi.createUser(firstName, lastName, companyName, emailId, roles);
        adminApi.activateUser(activationLink, "Welcome@1");
    }

    protected String createInActiveUser(String emailId, ROLES roles) throws Exception {
        apiLoginAs(ROLES.ADMIN);
        adminApi.addToWhiteList(emailId);
        return adminApi.createUser(emailId, roles);
    }

    protected void deleteUser(String... userEmailIds) throws Exception {
        apiLoginAs(ROLES.ADMIN);
        for (String userEmailId : userEmailIds) {
            deleteUserFromBraintreeIfExist(userEmailId);
            adminApi.deleteUser(getUserId(userEmailId));
            adminApi.deleteFromWhiteList(getUserId(userEmailId));
        }
    }


    protected void deleteUser(List<String> userEmailIds) throws Exception {
        apiLoginAs(ROLES.ADMIN);
        for (String userEmailId : userEmailIds) {
            deleteUserFromBraintreeIfExist(userEmailId);
            adminApi.deleteUser(getUserId(userEmailId));
            adminApi.deleteFromWhiteList(getUserId(userEmailId));
        }
    }

    private void deleteUserFromBraintreeIfExist(String user_EmailId) throws Exception {
        BraintreeUtil.deleteCustomer(getBraintreeCustomerId(user_EmailId));

    }

    protected int setExpirationDateForTrialUser(String emailId) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        HashMap<String, String> queryParam = new HashMap();
        queryParam.put("ID", getUserId(emailId));
        queryParam.put("PASTDATE", sdf.format(cal.getTime()));//Brain Tree Format(eg.2018-05-24)
        return processDB("SET_EXPIRATION_DATE", queryParam);
    }

    protected int setExpirationDateForSubscribedUser(String emailId) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        HashMap<String, String> queryParam = new HashMap();
        String dataId = getUserId(emailId);
        queryParam.put("CUSTOMERTOKEN", sqlProcessor.getSinglResultValue("FuntionalTestData.GET_CUSTOMER_TOKEN", dataId));
        queryParam.put("PASTDATE", sdf.format(cal.getTime()));//Brain Tree Format(eg.2018-05-24)
        return processDB("SET_ENDDATE_SUBSCIBEDUSER", queryParam);
    }


    protected String getUserId(String userEmailId) throws Exception {
        HashMap<String, String> param = new HashMap();
        param.put("EMAIL", userEmailId);
        return sqlProcessor.getSingleValue(sqlProcessor.getResultData("FuntionalTestData.GET_USER", param), "id");

    }

    protected void deleteAndAddUserToWhiteList(String mailId) throws Exception {
        deleteUser(mailId);
        addToWhiteList(mailId);
    }

    protected void deleteFromWhiteList(String mailId) throws Exception {
        deleteWhiteList(mailId);
    }

    protected void enableFeature(String... featureNames) throws Exception {
        changeFeature(true, featureNames);
    }

    protected void disableFeature(String... featureNames) throws Exception {
        changeFeature(false, featureNames);
    }

    protected void changeFeature(boolean enable, String... featureNames) throws Exception {
        apiLoginAs(ROLES.ADMIN);
        for (String feature : featureNames) {
            adminApi.changeFeature(feature, enable);
        }
    }

    protected void addToWhiteList(String... emailIds) throws Exception {
        apiLoginAs(ROLES.ADMIN);
        for (String emailId : emailIds) {
            adminApi.addToWhiteList(emailId);
        }
    }

    protected void deleteWhiteList(String... emailIds) throws Exception {
        apiLoginAs(ROLES.ADMIN);
        for (String emailId : emailIds) {
            adminApi.deleteFromWhiteList(getUserId(emailId));
        }
    }

    protected void apiLoginAs(ROLES roleName) throws Exception {
        loginApi.login(getConfig(roleName + "_EMAIL"), getConfig(roleName + "_PSWD"));
    }

    protected static JsonObject getJsonDataQueries(String jsonFilePath) throws Exception {
        return ConfigLoader.loadJson(testFilePath + jsonFilePath);
    }

    //UI METHODS
    public void asAdminCreateUserAndLoginUI(Map<String, String> userData)
            throws Exception {
        logoutAndLoginAs(ROLES.ADMIN);
        String activationEmail = createUserFromAdminUI(userData);
        logout();
        activateAccountAndLogin(activationEmail, userData.get("password"));
    }

    public String createUserFromAdminUI(Map<String, String> userData)
            throws Exception {
        String emailId = userData.get("mail_id");

        deleteUser(emailId);
        EmailApiUtil.deleteRecipientEmails(emailId);

        to(addToWhitelist);
        addToWhitelist.addToWhiteList(emailId);

        to(createUserPage);
        createUserPage.createUser(userData);
        at(userViewPage);

        return EmailApiUtil.getLinkFromEmail(emailId, 0, 0);
    }

    public String getDate() {
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        calendar.setTimeZone(TimeZone.getTimeZone("UTC"));
        System.out.println("Time :" + calendar.get(Calendar.HOUR_OF_DAY) + ":" + calendar.get(Calendar.MINUTE) + ":" + calendar.get(Calendar.SECOND));
        return dateFormat.format(calendar.getTime());
    }

    public String getDate(int format, int count) {
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("PST"));
        calendar.add(format, count);
        return dateFormat.format(calendar.getTime());
    }

    public String getBraintreeCustomerId(String email) throws Exception {
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("EMAIL", email);

        return SQLProcessor.getInstance().getSingleValue("FuntionalTestData.SUBSCRIPTION_CUSTOMER_ID", params, "token");
    }

    public void triggerRakeTask(String taskName) throws Exception {
        String statusUrl = "Insight-Trigger_Rake_Task-qa-iap75/lastBuild/api/json";
        String command = "curl -i -X POST \"http://"+jenkinsUName+":"+jenkinsAPIToken+"@newci/job/"+jobPath+"/buildWithParameters?Task="+taskName+"&Environment="+config.getProperty("RAKE_ENV")+"&Submit=Build\"";
        triggerRakeTask(new HashMap<>(),statusUrl,command);
    }

    public void triggerReportRakeTask() throws Exception {
        String statusUrl = "Insight_Reports_Job/lastBuild/api/json";
        String command = "curl -i -X POST \"http://"+jenkinsUName+":"+jenkinsAPIToken+"@newci/job/Insight_Reports_Job/build?\"";
        triggerRakeTask(new HashMap<>(),statusUrl,command);
    }
    public void verifyFileDownload(String link) throws Exception {

        HttpClient httpClient = HttpClientBuilder.create().build();
        HttpHead request = new HttpHead(link);
        HttpResponse response = httpClient.execute(request);
        String contentType = response.getFirstHeader("Content-Type").getValue();
        int contentLength = Integer.parseInt(response.getFirstHeader("Content-Length").getValue());

    }

    public String convertCountToKilo(String count) {
        String kiloValue="";
        int countValue = Integer.parseInt(count.replaceAll("[\\D]", "").trim());
        if (countValue <= 999) {
            kiloValue = count.replaceAll("[\\D]", "").trim();
        } else if (countValue > 999 || countValue <= 9999) {
            kiloValue = count.charAt(0) + "K+";
        } else if (countValue > 10000 || countValue <= 99999) {
            kiloValue = count.charAt(1) + "K+";
        }else{
            System.out.println("Not a valid scenario");
        }
        return kiloValue;
    }

    public boolean PageReady(){
        try {
            getWait(10).until((ExpectedCondition<Boolean>) webDriver -> //Document Ready
                    ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
            getWait(10).until((ExpectedCondition<Boolean>) webDriver -> //Ajax Ready
                    ((JavascriptExecutor) webDriver).executeScript("return jQuery.active.toString()").equals("0"));
            System.out.println("Document and Ajax are ready");
        }catch (TimeoutException e){
            System.out.println("wait for javascript throwing error"+e);
        }
        return true;
    }

	public void triggerRakeTask(HashMap<String,String> params,String statusUrlPath,String command) throws Exception {
        long timeout = 1000*60*20;
        DocumentContext jsonValue = jenkins.getJSON(statusUrlPath);
        String old_id =((JsonPrimitive) jsonValue.read("id")).getAsString();
        params.put("Submit","Build");
        //jenkins.post("Insight-Trigger_Rake_Task-qa-iap75/buildWithParameters",params);
        //String command = "curl -i -X POST \"http://"+jenkinsUName+":"+jenkinsAPIToken+"@newci/job/"+jobPath+"/buildWithParameters?Task="+taskName+"&Environment="+config.getProperty("RAKE_ENV")+"&Submit=Build\"";
        Process process = Runtime.getRuntime().exec(command);
        process.getInputStream();


        String id=old_id;
        long startTime = System.currentTimeMillis();
        while(true) {
            DocumentContext json = jenkins.getJSON(statusUrlPath);
            id = ((JsonPrimitive) json.read("id")).getAsString();
            if(!id.equalsIgnoreCase(old_id)) {
                JsonElement resultValue = json.read("result");
                if (!resultValue.isJsonNull() && resultValue.getAsString().equalsIgnoreCase("success"))
                    break;
            }
            if(System.currentTimeMillis() - startTime > timeout)
                new Error("Rake Task Jobs reached maximum time out");

        }
        //Thread.sleep(20000);
    }

}
