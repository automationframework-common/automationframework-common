package com.rpxcorp.insight.page.payment;

import org.openqa.selenium.By;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class CreditPurchaseFailurePage extends BasePage {

    @Override
    public boolean at() {
        return failureHeader.waitUntilVisible();
    }

    public final Element failureHeader = $(
            By.xpath("//h2[@class='failure'][text()='Document Credit Purchase Failed']"));
}
