package com.rpxcorp.insight.module;

import com.rpxcorp.testcore.TableData;
import com.rpxcorp.testcore.element.Element;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

public class Facet extends Table {

    Element closePopup;
    Element showMoreLink;
    Element showLessLink;
    Element clearAll;   
    Element showMoreDialog;
    Element selectedOptionsListInShowMoreDialog;
    Element unSelectedOptionsListInShowMoreDialog;
    Element submitBtnInShowMoreDialog;
    
    public Facet(By locator) {
        super(locator);
    }

    public Facet(String selector) {
        super(selector);
    }

    public void showMoreDialog(String selector) {
        this.showMoreDialog = new Element(selector);
    }
    
    public void submitBtnInShowMoreDialog(String selector) {
        this.submitBtnInShowMoreDialog = new Element(selector);
    }
    public void selectedOptionsInShowMoreDialog(String selector) {
        this.selectedOptionsListInShowMoreDialog = new Element(selector);
    }
    
    public void submitPopup(String selector) {
        this.submitBtnInShowMoreDialog = new Element(selector);
    }
    
    public void unSelectedOptionsInShowMoreDialog(String selector) {
        this.unSelectedOptionsListInShowMoreDialog = new Element(selector);
    }
    
    public void closePopup(String selector) {
        this.closePopup = new Element(selector);
    }
    
    public void submitPopup() {
        submitBtnInShowMoreDialog.click();
    }
    
    public void showMoreLink(String selector) {
        this.showMoreLink = new Element(selector);
    }
    
    public void showLessLink(String selector) {
        this.showLessLink = new Element(selector);
    }
    
    public void clearAll(String selector) {
    	this.clearAll=new Element(selector);
    }
    
    public void clearAll() {
    	clearAll.click();
    	new Element(By.cssSelector(".blockUI.blockOverlay")).waitUntilInvisible();
        new Element(By.cssSelector(".blockUI.blockMsg.blockElement>img")).waitUntilNoElementPresent();
    }
    
	public void showMore() {
		if (showMoreLink.isDisplayed()) {
			showMoreLink.click();
			if (showMoreDialog != null) {
				showMoreDialog.waitUntilVisible();
			} else {
				showLessLink.waitUntilVisible();
			}
		}
	}

	public void expandFacet(String facetName) {
		
		if (!getElement().getAttribute("class").contains("uncollapsed")) {
			// Expand Facet
			getElement().findElement(By.cssSelector(".filters div.title")).click();
			new Element(By.cssSelector(".blockUI.blockOverlay"))
					.waitUntilInvisible();
			new Element(By.cssSelector(".blockUI.blockMsg.blockElement>img"))
					.waitUntilNoElementPresent();
		}
	}

	public void selectOptionFromFacetShowMoreDialog(String optionName) {
		showMore();
		if (showMoreDialog!=null & showMoreDialog.isDisplayed()) {
			if (!getSelectedOptionsFromShowMoreDialog().contains(optionName)) {
				if (!unSelectedOptionsListInShowMoreDialog.$(
						"input[value='" + optionName + "']").isSelected()) {
					unSelectedOptionsListInShowMoreDialog.$(
							"input[value='" + optionName + "']").click();
					new Element(By.cssSelector(".blockUI.blockOverlay"))
					.waitUntilInvisible();
					new Element(By.cssSelector(".blockUI.blockMsg.blockElement>img"))
					.waitUntilNoElementPresent();	
					submitBtnInShowMoreDialog.click();
					new Element(By.cssSelector(".blockUI.blockMsg.blockElement>img"))
					.waitUntilNoElementPresent();	
				}
			}
		}
	}

	public void selectOptionsFromFacetSection(String facetName,
			String optionName) {
		if (!$(
				":has(div:contains(" + facetName
						+ ")) li:has(span:contains(" + optionName
						+ ")) a.remove.apply_filter").isDisplayed()) {
			$(
					":has(div:contains(" + facetName
							+ ")) li:has(span:contains(" + optionName
							+ ")) a.apply_filter").click();

			new Element(By.cssSelector(".blockUI.blockOverlay")).waitUntilInvisible();
			new Element(By.cssSelector(".blockUI.blockMsg.blockElement>img")).waitUntilNoElementPresent();

		}

	}

	public void selectOptionFromSearchResultsFacetSection(String facetName,
			String optionName) {
		expandFacet(facetName);
		if (!$(":has(div:contains(" + facetName
						+ ")) li:has(span:contains(" + optionName + ")) span.label_text")
				.isDisplayed()) {
			selectOptionFromFacetShowMoreDialog(optionName);
		} else {
			selectOptionsFromFacetSection(facetName, optionName);
		}

	}

    public List<String> getOptionFromSearchResultsFacetSection(String facetName) {
        expandFacet(facetName);
        if (!$(":has(div:contains(" + facetName + ")) li span.label_text").isDisplayed());
        return $(":has(div:contains(" + facetName + ")) li span.label_text").getAllData();
    }

    public List<String> getSelectedOptionFromSearchResultsFacetSection(String facetName) {
        expandFacet(facetName);
        if (!$(":has(div:contains(" + facetName + ")) li span.linkholder").isDisplayed());
        return $(":has(div:contains(" + facetName + ")) li span.linkholder").getAllData();
    }

    private List<String> getSelectedOptionsFromShowMoreDialog() {
		return selectedOptionsListInShowMoreDialog.getAllData();
	}

	public TableData getData() {
        return getData(-1);
    }

    @Override
    public TableData getData(int rowCount) {
        try {
            if (activationlink != null) {
                if (activationlink.getAttribute("class") == "filters collapsible collapsed") {
                    activationlink.click();
                    new Element(By.cssSelector(".blockUI.blockOverlay")).waitUntilInvisible();
                    new Element(By.cssSelector(".blockUI.blockMsg.blockElement>img")).waitUntilNoElementPresent();
                }
            }
            if (viewAllLink != null) {
                if (viewAllLink.isDisplayed()) {
                    viewAllLink.click();
                    new Element(By.cssSelector(".blockUI.blockOverlay")).waitUntilInvisible();
                    new Element(By.cssSelector(".blockUI.blockMsg.blockElement>img")).waitUntilNoElementPresent();
                }
            }
            return getCustomTableData(rowCount);
        } finally {
            closeFacet_Popup();
        }
    }

    public void closeFacet_Popup() {
        if (closePopup.isDisplayed()) {
            closePopup.click();
        }
    }


    public List<String> getFacetFilterHeaders() {
        List<String> timelineData = new ArrayList<String>();
        List<WebElement> options = $("").getElements();
        for (WebElement opt : options)
            timelineData.add(opt.getText());
        return timelineData;
    }

}
