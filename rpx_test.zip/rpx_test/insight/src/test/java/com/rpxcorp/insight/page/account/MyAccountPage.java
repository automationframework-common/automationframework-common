package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.module.*;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MyAccountPage extends BasePage {

    public MyAccountPage() {
        this.url = new PageUrl("user/edit");
    }

    @Override
    public boolean at() {
        return myAccountsHeader.waitUntilVisible();
    }


    public final AutoComplete company_Auto = $("input#user_company", AutoComplete.class);
    public final Element updateBasicInfoBtn = $("input[value='Update Basic Information']");
    public final Element basicInfoSuccess = $("form#edit_user:visible .success_messages");


    public final Element title = $(".large-12.columns>h1");
    public final Element activeTab = $(".tab-title.active a");
    public final Element userProfile = $("#user_profile");
    public final Element profile_tab = $("a[href='#panel_profile']");
    public final Element myAccountsHeader = $("#user_profile h5:contains('Basic Information')");
    public final Tabs myAccountsTabs = new Tabs("div.mg-bt-tabs dl.tabs");
    public final Element paymentChangePassword = $(".row.payment_buttons a:contains('Change Password')");
    public final Element paymentEditProfile = $(".row.payment_buttons a:contains('Edit Profile')");
    public final Element paymentSaveProfile = $(".payment_buttons input[value='Save']:visible");
    public final StaticContent docCreditBalance = $("div:has(h5:contains(Document Credit Balance))", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("Monthly Subsciption Balance", " label:contains(Monthly Subscription Balance:)>span");
                dataForm.content("purchased_balance", " label:contains(Purchased Balance:)>span");
                dataForm.content("monthly_spend", " label:contains(Monthly Spend:)>span");
            }
    );

    public final Element purchaseMoreCreditBtn = $(".payment_buttons a:contains('Purchase More Credit')");
    public final Element upgradeRoleLink = $("li.upgrade-btn a:contains('Upgrade')");
    public final Element sub_startDate = $("th:contains('Subscription Start Date:')+td");
    public final Element acc_renewalDate = $("th:contains('Account Renewal Date:')+td");
    public final Element user_role_name = $("th:contains('Subscription Type:')+td");
    public final Element monthly_subscription_amount = $("#panel_profile label:contains('Monthly Subscription Balance:')>span");
    public final Element purchased_balance = $("#panel_profile label:contains('Purchased Balance:')>span");
    public final Element monthly_spend = $("#panel_profile label:contains(Monthly Spend:)>span");
    public final Element subscription_renewal_date = $("table#user_profile_attributes_table tr#subscription_renewal_date>th");
    public final Element subscription_end_date = $("table#user_profile_attributes_table tr#subscription_end_date>th");
    public final Element subscriptionFlashMsg = $(".cancel_subscription_flash");

    public final Element basicInfoErrorMsg = $(".basic_info.errors li");

    public void updateBasicInformation(Map<String, String> data) {
        paymentEditProfile.click();
        firstName_editMode.sendKeys(data.get("first_name"));
        lastName_editMode.sendKeys(data.get("last_name"));
        email_editMode.sendKeys(data.get("email"));
        company_editMode.sendKeys(data.get("company"));
        paymentSaveProfile.click();
        loading.waitUntilNoElementPresent();
    }

    public final Element firstName_editMode = $("#edit_user input#user_first_name");
    public final Element lastName_editMode = $("#edit_user input#user_last_name");
    public final Element email_editMode = $("#edit_user input#user_email");
    public final Element company_editMode = $("#edit_user input#user_company");
    public final Element companyEditModeStatic = $("form.edit_user label:contains('Company')+p");


    public final Element firstName = $("div#user_profile label:contains('First Name')+input");
    public final Element lastName = $("div#user_profile label:contains('Last Name')+input");
    public final Element email = $("div#user_profile label:contains('Email')+input");
    public final Element company = $("div#user_profile label:contains(Company)+input");
    public final Element company1 = $("div#user_profile label:contains(Company)+p");
    public final Element subscription_type = $("div#user_profile label:contains('Subscription Type')+p");
    public final Element trialStartDate = $("div#user_profile label:contains('Trial Start Date')+p"); // The field is displayed only if the user on trial period
    public final Element billingStartDate = $("div#user_profile label:contains('Billing Start Date')+p"); // The field is displayed only if the user on trial period
    public final Element trialExpiryDate = $("div#user_profile label:contains('Trial Expiration Date')+p"); //The field is displayed only if the user cancel the subscription in trial period
    public final Element nontrialBillingDate = $("div#user_profile label:contains('Billing Date'):not(label:contains('Next'))+p"); //The field is displayed only if the user on non-trial period
    public final Element nontrialNextBillingDate = $("div#user_profile label:contains('Next Billing Date')+p"); //The field is displayed only if the user on non-trial period
    public final Element nontrialSubscriptionEndDate = $("div#user_profile label:contains('Subscription End Date')+p"); //The field is displayed only if the user cancel the subscription in non-trial period
    public final Element autoRenewCheckbox = $("div#user_profile form>input#user_subscription_auto_renew");

    public Map<String, String> profile_info_TrialUser() {
        Map<String, String> data = new HashMap<String, String>();
        data.put("first_name", firstName.getAttribute("value"));
        data.put("last_name", lastName.getAttribute("value"));
        data.put("email", email.getAttribute("value"));
        data.put("company", company.getAttribute("value"));
        data.put("subscription_type", subscription_type.getText());
        data.put("trial_start_date", trialStartDate.getText());
        data.put("billing_start_date", billingStartDate.getText());
        return data;
    }

    public Map<String, String> profile_info_CancelledTrialUser() {
        Map<java.lang.String, java.lang.String> data = new HashMap<java.lang.String, java.lang.String>();
        data.put("first_name", firstName.getAttribute("value"));
        data.put("last_name", lastName.getAttribute("value"));
        data.put("email", email.getAttribute("value"));
        data.put("company", company.getAttribute("value"));
        data.put("subscription_type", subscription_type.getText());
        data.put("trial_start_date", trialStartDate.getText());
        data.put("trial_expiry_date", trialExpiryDate.getText());
        return data;
    }

    public Map<String, String> profile_info_NonTrialUser() {
        Map<java.lang.String, java.lang.String> data = new HashMap<java.lang.String, java.lang.String>();
        data.put("first_name", firstName.getAttribute("value"));
        data.put("last_name", lastName.getAttribute("value"));
        data.put("email", email.getAttribute("value"));
        data.put("company", company.getAttribute("value"));
        data.put("subscription_type", subscription_type.getText());
        data.put("nontrial_billing_date", nontrialBillingDate.getText());
        data.put("nontrial_nextbillingdate", nontrialNextBillingDate.getText());
        return data;
    }

    public Map<String, String> profile_info_CancelledNonTrialUser() {
        Map<java.lang.String, java.lang.String> data = new HashMap<java.lang.String, java.lang.String>();
        data.put("first_name", firstName.getAttribute("value"));
        data.put("last_name", lastName.getAttribute("value"));
        data.put("email", email.getAttribute("value"));
        data.put("company", company.getAttribute("value"));
        data.put("subscription_type", subscription_type.getText());
        data.put("nontrial_billing_date", nontrialBillingDate.getText());
        data.put("nontrial_subscription_enddate", nontrialSubscriptionEndDate.getText());
        return data;
    }


    public final Element firstNameEdit = $("form.edit_user div.columns:contains(First Name) input");
    public final Element lastNameEdit = $("form.edit_user div.columns:contains(Last Name) input");
    public final Element emailEdit = $("form.edit_user div.columns:contains(Company Name) input");
    public final Element compNameEdit = $("form.edit_user div.columns:contains(Company Name) p");
    public final Element subscriptionEdit = $("form.edit_user div.columns:contains(Subscription Type) p");
    public Map<String, String> profile_Info_AdminUser_EditMode() throws Exception {
        Map<java.lang.String, java.lang.String> data = new HashMap<java.lang.String, java.lang.String>();
        data.put("first_name", firstNameEdit.getText());
        data.put("last_name", lastNameEdit.getText());
        data.put("email", emailEdit.getText());
        data.put("company", compNameEdit.getText());
        data.put("subscription_type", subscriptionEdit.getText());
        return data;
    }


    public Map<String, String> profile_Info_AdminUser() throws Exception {
        Map<java.lang.String, java.lang.String> data = new HashMap<java.lang.String, java.lang.String>();
        data.put("first_name", firstName.getAttribute("value"));
        data.put("last_name", lastName.getAttribute("value"));
        data.put("email", email.getAttribute("value"));
        data.put("company1", company1.getText());
        data.put("subscription_type", subscription_type.getText());
        return data;
    }
    public Map<String, String> profile_Info_AdminCreatedMemberAndAbove() throws Exception {
        Map<java.lang.String, java.lang.String> data = new HashMap<java.lang.String, java.lang.String>();
        data.put("first_name", firstName.getAttribute("value"));
        data.put("last_name", lastName.getAttribute("value"));
        data.put("email", email.getAttribute("value"));
        data.put("company1", company1.text());
        data.put("subscription_type", subscription_type.getText());
        return data;
    }

    /**
     * CHANGE PASSWORD OBJECTS
     */
    public final Element oldPassword = $("input#user_current_password");
    public final Element newPassword = $("input#user_password");
    public final Element passwordConfirmation = $("input#user_password_confirmation");
    public final Element changePwdSuccessMsg = $("[action*='update_password'] .success_messages");
    public final Element changePwdErrorMsg = $("[action*='update_password'] .errors li");
    public final Element passwordSaveBtn = $("div.payment_buttons input[value='Save']:visible");

    public final Element companyAutoSuggest = $("div#s2id_user_viewing_account_id");
    public final Element company_list = $("#s2id_autogen1_search");


    public void selectAccount(String country) {
        companyAutoSuggest.waitUntilVisible();
        companyAutoSuggest.click();
        company_list.waitUntilVisible();
        company_list.sendKeys(country + Keys.RETURN);

    }

    public final Element save_viewing_preferences_btn = $("#viewAsAccountModal input[value='Save Viewing Preferences']");

    public void changePassword(Map<String, String> data) {
        paymentChangePassword.click();
        oldPassword.waitUntilVisible();
        oldPassword.sendKeys(data.get("current_password"));
        newPassword.sendKeys(data.get("new_password"));
        passwordConfirmation.sendKeys(data.get("confirm_password"));
        passwordSaveBtn.click();
        //loading.waitUntilInvisible();
    }

    public String getAccRenewalDate() {
        acc_renewalDate.waitUntilVisible();
        return acc_renewalDate.getText();
    }

    public String getMonthlySubScriptionAmount() {
        monthly_subscription_amount.waitUntilVisible();
        return monthly_subscription_amount.getText();
    }

    public String getUserRole() {
        user_role_name.waitUntilVisible();
        return user_role_name.getText();
    }


    public final Element billing_history_tab = $("a[href='#panel_billing_history']");

    //Document History
    public final Element document_history_tab = $("a[href='#panel_document_history']");
    public final Element documentHistoryHeader = $("#dockets_wrapper h5:contains('Document History')");
    public final Element document_history_panel = $("#panel_document_history.active h4");
    public final Element no_Records_document_history = $("#panel_document_history h3:contains(No documents found.)");
    public final Element noTransactionMessage = $(com.rpxcorp.testcore.By.xpath("//div[@class='large-12 columns']/h5[text()='No documents found.']"));
    public final Table documentHistoryTable = new Table(".doc_history_table");
    public final Element latestDocument = $(com.rpxcorp.testcore.By.xpath("//table[@class='doc_history_table']//tr[1]/td[1]/a"));


    public final Element confirmCancellationBtnnew = $("input[value='Confirm Cancellation']");
    //CANCEL SUBSCRIPTION
    public final Element cancelSubscriptionBtn = $("#cancel_subscription_btn");
    public final Element cancelSubscriptionModal = $("#cancel_subscription_modal");
    public final Element continueSubscriptionBtn = $("div.modal-content a:contains('Continue Subscription')");//.button.close-reveal-modal
    public final Element confirmCancellationBtn = $("input[value='Accept Terms and Confirm Cancellation']");

    public final Element cancelSubscriptionModalClose = $("#cancel_subscription_modal .close-reveal-modal");
    public final Element cancellationTerm1InModal = $("#cancel_subscription_modal .modal-content>p:nth-of-type(1)");
    public final Element cancellationTerm2InModal = $("#cancel_subscription_modal .modal-content>p:nth-of-type(2)");
    public final Element cancelSubscriptionFlashMsg = $(".cancel_subscription_flash");
    public final Element cancelSubscriptionMsg = $("div#subs_cancel_message");
    public final Element feedbackFormSubmitBtn = $("ul.inline-list input[value='Submit']");
    public final Element feedbackFormCancelBtn = $("ul.inline-list a[data-behavior='close_reveal_modal']");
    public final Element subscriptionFeedBackModel = $("div#subscription_feedback");

    //CANCEL FREE TRIAL
    public final Element cancelFreeTrialBtn =$("#cancel_free_trial_btn");
    public final Element cancelFreeTrialModal = $("#cancel_free_trial_modal");
    public final Element cancellationTermTrialModal = $("div#cancel_free_trial_modal .modal-content>p:nth-of-type(1)");
    public final Element changeSubscription = $("div.payment_buttons a:contains('Change Subscription')");

    //Switch Subscription
    public final Element switchAnnualSubscription = $("div.payment_buttons a[data-reveal-id='switch_monthly_annual_modal']");//div.payment_buttons>a:contains('Switch to an Annual Subscription')
    public final Element switchSubscriptionModel = $("#switch_monthly_annual_modal");
    public final Element switchSubscriptionModelContent = $(".modal-content>#plan_confirmation_text>p:nth-of-type(1)");
    public final Element changePlan = $("select#plan_token");
    public final Element btnChangeSubscription = $(".modal-content input[value='Confirm Change']");
    public final Element btnContinueSubscription = $(".modal-content a:contains('Continue Current Subscription')");


    public String acceptTermsAndCancelSubscriptionForSubscribedUser() {
        openCancelSubscriptionModal();
        confirmCancellationBtnnew.click();
        waitForLoading();
        cancelSubscriptionMsg.waitUntilTextPresent("Your subscription has been succesfully cancelled");
        return cancelSubscriptionMsg.getText();
    }

    public void continueSubscription() {
        openCancelSubscriptionModal();
        continueSubscriptionBtn.click();
        cancelSubscriptionModal.waitUntilInvisible();
    }

    public String acceptTermsAndCancelSubscription() {
        openCancelSubscriptionModal();
        confirmCancellationBtn.click();
        cancelSubscriptionModal.waitUntilInvisible();
        return cancelSubscriptionFlashMsg.getText();
    }

    public void openSwitchSubscriptionModal() {
        if (!switchSubscriptionModel.isDisplayed()) {
            switchAnnualSubscription.click();
            switchSubscriptionModel.waitUntilVisible();
        }
    }

    public void openCancelSubscriptionModal() {
        if (!cancelSubscriptionModal.isDisplayed()) {
            cancelSubscriptionBtn.click();
            cancelSubscriptionModal.waitUntilVisible();
        }
    }

    public void openCancelSubscriptionModalForTrialUser() {
        if (!cancelFreeTrialModal.isDisplayed()) {
            cancelFreeTrialBtn.click();
            cancelFreeTrialModal.waitUntilVisible();
        }
    }

    public void clickCancelButtonInCancelSubscriptionFeedBackForm() {
        feedbackFormCancelBtn.waitUntilVisible();
        feedbackFormCancelBtn.click();
        subscriptionFeedBackModel.waitUntilInvisible();
    }

    //new payment method
    public Map<String, String> getCancellationTermsForTrialUser() {
        Map<String, String> cancellationTerms = new HashMap<String, String>();

        openCancelSubscriptionModalForTrialUser();
        cancellationTerms.put("term_1", cancellationTermTrialModal.getText());
        return cancellationTerms;
    }


    public Map<String, String> getCancellationTermsForSubscribedUser() {
        Map<String, String> cancellationTerms = new HashMap<String, String>();

        openCancelSubscriptionModal();
        cancellationTerms.put("term_1", cancellationTerm1InModal.getText());
        return cancellationTerms;
    }

    //Need to delted once old functionality depreciated
    public Map<String, String> getCancellationTerms() {
        Map<String, String> cancellationTerms = new HashMap<String, String>();

        openCancelSubscriptionModal();
        cancellationTerms.put("term_1", cancellationTerm1InModal.getText());
        cancellationTerms.put("term_2", cancellationTerm2InModal.getText());

        return cancellationTerms;
    }

    //new payment Method
    public void continueSubscriptionnew() {
        openCancelSubscriptionModalForTrialUser();
        continueSubscriptionBtn.click();
        cancelFreeTrialModal.waitUntilInvisible();
    }

    //new payment Method
    public String acceptTermsAndCancelSubscriptionForTrialUser() {
        openCancelSubscriptionModalForTrialUser();
        confirmCancellationBtnnew.click();
        waitForLoading();
        cancelSubscriptionMsg.waitUntilTextPresent("Your subscription has been succesfully cancelled");
        return cancelSubscriptionMsg.getText();
    }

    public void clickSubmitButtonInCancelSubscriptionFeedBackForm() {
        feedbackFormSubmitBtn.waitUntilVisible();
        feedbackFormSubmitBtn.click();
        subscriptionFeedBackModel.waitUntilInvisible();
    }
    public Map<String, String> getSwitchSubscriptionModelContent(String subscriptionName) {
        Map<String, String> switchSubscriptionContent = new HashMap<String, String>();
        openSwitchSubscriptionModal();
        selectPlanInChangeSubscriptionModal(subscriptionName);
        switchSubscriptionContent.put("modelContent", switchSubscriptionModelContent.getText());
        return switchSubscriptionContent;
    }

    public void selectPlanInChangeSubscriptionModal(String subscriptionName) {
        openSwitchSubscriptionModal();
        changePlan.selectByOption(subscriptionName);
        //btnChangeSubscription.click();
    }

    public final Element purchase_more_credit=$(By.xpath("//*[@id='panel_profile']//a[text()='Purchase More Credit']"));

    public static ArrayList<String> subscriptionStaticFeedbackLabel(){
        ArrayList<String> expected_CheckedOption=new ArrayList<String>();
        expected_CheckedOption.add("The product does not offer information or features that I need for my research.");
        expected_CheckedOption.add("The subscription price is too high.");
        expected_CheckedOption.add("I like RPX Insight but switching from an existing service that I currently use would be difficult.");
        expected_CheckedOption.add("I only had a short term requirement which is fulfilled. I may upgrade again in the future.");
        return expected_CheckedOption;
    }


    public final Element disabledAutoRenewOption = $("input[id='subscription_auto_renew'][disabled='disabled']");

    public final Element feedbackform_Description = $("div.subscription-feedback p");
    public final CheckList feedbackform_reasons = (CheckList) $("div.subscription-feedback li>label" , CheckList.class);
    public final Element feedbackform_reason_1 = $("div.subscription-feedback label[for=info_or_feature_insufficient]");
    public final Element feedbackform_reason_2 = $("div.subscription-feedback label[for=price_too_high]");
    public final Element feedbackform_reason_3 = $("div.subscription-feedback label[for=switching_difficult]");
    public final Element feedbackform_reason_4 = $("div.subscription-feedback label[for=will_subscribe_again]");
    public final Element feedbackform_comments = $("div.subscription-feedback textarea#comments");

    public Map<String, String> getCancelSubscriptionFeedbackContent() {
        Map<String, String> feedbackFormContent = new HashMap<String, String>();

        feedbackFormContent.put("cancelmsg", feedbackform_Description.getText());
        feedbackFormContent.put("reason1", feedbackform_reason_1.getText());
        feedbackFormContent.put("reason2", feedbackform_reason_2.getText());
        feedbackFormContent.put("reason3", feedbackform_reason_3.getText());
        feedbackFormContent.put("reason4", feedbackform_reason_4.getText());
        return feedbackFormContent;
    }
}