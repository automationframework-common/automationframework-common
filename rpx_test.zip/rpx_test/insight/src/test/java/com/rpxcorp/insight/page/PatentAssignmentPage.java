package com.rpxcorp.insight.page;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;

public class PatentAssignmentPage extends Page {

    public PatentAssignmentPage() {
        this.url = new PageUrl("patent_assignment/{ID}");
    }

    public final Element patent_Assignment = $("assignment-details .assignment-info");
	public final Element pdf_doc_link=$(".assignment-panel a[href*=assignments] i");

    @Override
    public boolean at() {
    	return patent_Assignment.waitUntilVisible();
    }
}
