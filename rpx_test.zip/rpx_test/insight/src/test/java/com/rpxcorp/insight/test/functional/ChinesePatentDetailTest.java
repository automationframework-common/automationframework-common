package com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.PatentAssignmentPage;
import com.rpxcorp.insight.page.UsptoLegacyAssignmentDocPage;
import com.rpxcorp.insight.page.account.MyAccountPage;
import com.rpxcorp.insight.page.detail.*;
import com.rpxcorp.insight.page.error_page.PatentWithdrawnPage;
import com.rpxcorp.insight.page.search.LitigationSearchPage;
import com.rpxcorp.insight.page.search.PatentSearchPage;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.element.Element;
import org.testng.Assert;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
@Authenticate(role = "MEMBER")
@Test(groups = {"ChinesePatent"})
public class ChinesePatentDetailTest extends BaseFuncTest {

    PortfolioDetailPage portfolioDetailPage;
    ChinesePatentDetailPage chinesePatentDetailsPage;
    PatentWithdrawnPage patentWithdrawnPage;
    EntityDetailPage entityDetailsPage;
    LitigationDetailPage litigationDetailPage;
    LitigationSearchPage litigationSearchPage;
    PtabDetailPage ptabDetailPage;
    UsptoLegacyAssignmentDocPage assignmentDoc;
    PatentAssignmentPage patentAssignmentPage;
    PatentSearchPage patentSearchPage;
    BaseDetailPage baseDetailPage;
    CampaignDetailPage campaignDetailPage;
    MyAccountPage myAccountPage;

    SoftAssert softAssert;
    /** SMOKE TESTS **/
    @Test(priority = 1, groups = "smoke", description = "Verify all sections in Chinese Patent details page")
    public void verifyAllSectionsInCNPatentDetailsPage() throws  Exception {
        SoftAssert softAssert = new SoftAssert();
        this.urlData.put("ID", "CN204119349U");
        to(chinesePatentDetailsPage, urlData);
        softAssert.assertTrue(chinesePatentDetailsPage.detailPageTitle.isDisplayed(),"The Title is not getting displayed in the Patent details page");
        //softAssert.assertTrue(patentDetailsPage.patent_frontPage_img.isDisplayed(),"The 'Patent Image' Section is not getting displayed in the Patent details page");
        softAssert.assertTrue(chinesePatentDetailsPage.overview_panel.isDisplayed(),"The 'Metrics' Section is not getting displayed in the Patent details page");
        softAssert.assertTrue(chinesePatentDetailsPage.litigation_table.isDisplayed(),"The 'Litigation' Section is not getting displayed in the Patent details page");
        softAssert.assertTrue(chinesePatentDetailsPage.reexamination_table.isDisplayed(),"The 'Petition' Section is not getting displayed in the Patent details page");
        softAssert.assertTrue(chinesePatentDetailsPage.citiations_table.isDisplayed(), "The 'Citations' section is not getting displayed in the Patent details page");
        softAssert.assertTrue(chinesePatentDetailsPage.claimData.isDisplayed(), "The 'Claims' section is not getting displayed in the Patent details page");
        softAssert.assertTrue(chinesePatentDetailsPage.specifications.isDisplayed(), "The 'Specifications' section is not getting displayed in the Patent details page");
        softAssert.assertTrue(chinesePatentDetailsPage.patent_info.isDisplayed(), "The 'Patent Information' section is not getting displayed in the Patent details page");
        softAssert.assertTrue(chinesePatentDetailsPage.familyMembers.isDisplayed(), "The 'Family Member' section is not getting displayed in the Patent details page");
        softAssert.assertAll();
    }
    /** METRICS SECTION TESTS**/
    @Test(priority=2,description="Verify Chinese Patent Details Page metrics")
    public void verifyCNPatStaticsVsSectionsStatistics() throws  Exception{
        softAssert = new SoftAssert();
        to(chinesePatentDetailsPage,"CN203688939U");
        softAssert.assertEquals(chinesePatentDetailsPage.overview_panel.getIntData("associated_case") , chinesePatentDetailsPage.associated_defendants_TabLink.getIntData() , "The Associated Case Count in metrics section is not equal with Associated case section count");
        softAssert.assertEquals(chinesePatentDetailsPage.overview_panel.getIntData("associated_defendants") , chinesePatentDetailsPage.associated_defendants_TabLink.getIntData() , "The Associated defendant Count in metrics section is not equal with Associated defendant section count");
        softAssert.assertEquals(chinesePatentDetailsPage.overview_panel.getIntData("forward_citations") , chinesePatentDetailsPage.forward_citations_TabLink.getIntData() , "The Forward Citations Count in metrics section is not equal with Citation section count");
        //--TODO Add Two more fields(casses count and defendants count)
        softAssert.assertAll();
    }
    /** PATENT INFO TEST **/
    @BeforeGroups(groups = "cn_patent_info")
    public void loadPatentsWithKeyEntites() {
        this.urlData.put("ID", "CN204119349U");
        to(chinesePatentDetailsPage, urlData);
    }

    @Test(priority = 201, groups = {"P2", "cn_patent_info"}, description = "Verify current assignee link navigation from patent info")
    public void verifyCurrentAssigneeLinkInCNPatentInfo() throws Exception {
        to(chinesePatentDetailsPage, urlData);
        String currentAssigneeLinkText = chinesePatentDetailsPage.currentAssignee.getText().toLowerCase();
        chinesePatentDetailsPage.currentAssignee.click();
        at(entityDetailsPage);
        String entTitle = entityDetailsPage.detailPageTitle.getText().toLowerCase();
        entityDetailsPage.navigateBack();
        assertEquals(entTitle, currentAssigneeLinkText, "Current assignee link in patent info and its corresponding ent/aliases page title not matches");
    }
    @Test(priority = 202, groups = {"P2","cn_patent_info"}, description = "Verify sponsoring entity link navigation from patent info")
    public void verifySponsoringEntityLinkInPatentInfo() throws Exception {
        to(chinesePatentDetailsPage, urlData);
        String sponsoringEntityLinkText = chinesePatentDetailsPage.sponsoringEntity.getText().toLowerCase();
        chinesePatentDetailsPage.sponsoringEntity.click();
        at(entityDetailsPage);
        String entTitle = entityDetailsPage.detailPageTitle.getText().toLowerCase();
        entityDetailsPage.navigateBack();
        assertEquals(entTitle, sponsoringEntityLinkText, "Sponsoring entity link in patent info and its corresponding ent/aliases page title not matches");
    }
    @Test(priority = 203, dataProvider="json" ,groups = {"P3", "cn_patent_info"}, description = "Inventor links should search by inventor names || RPX-13116")
    public void verifyCNPatentInfoDetails(String linkField) throws Exception {
        softAssert = new SoftAssert();
        to(chinesePatentDetailsPage, urlData);
        Element linkElement = chinesePatentDetailsPage.object(linkField);
        String patentInfoLinkText =linkElement.getText().toLowerCase();
        withNewWindow(linkElement, () -> {
            at(patentSearchPage);
            if(linkField.equalsIgnoreCase("inventors"))
                softAssert.assertTrue(patentSearchPage.currentSearch.getText().trim().toLowerCase().equals("inventor:\""+patentInfoLinkText+"\""));
            else {
                softAssert.assertTrue(patentSearchPage.currentSearch.getText().trim().toLowerCase().equals("all_examiners:\""+patentInfoLinkText+"\""));
            }
            softAssert.assertTrue(patentSearchPage.patent_results_count.getIntData() > 0);
        });
        softAssert.assertAll();
    }
    /** FAMILY MEMBERS TEST **/
    @BeforeGroups(groups = "cn_family_members")
    public void loadCNPatentsWithFamilyMembers() {
        this.urlData.put("ID", "CN204119349U"); //US7653706B2
        to(chinesePatentDetailsPage, urlData);
    }

    @Test(priority = 401, groups = {"P3", "cn_family_members"}, description = "Verify family members title")
    public void verifyFamilyMembersTitle() {
        Assert.assertTrue(chinesePatentDetailsPage.familyMembers_title.getText().contains("Family Member"),
                "Title is not as expected");
    }

    @Test(priority = 402, groups = {"P2", "cn_family_members"}, description = "Verfiy chinese patent link in family members")
    public void verifyCNFamilyMembersLinkInfamlyMembers() throws Exception {
        String patName = chinesePatentDetailsPage.familyMembers_patentLink.getText().replace("-"," ").toLowerCase();
        chinesePatentDetailsPage.familyMembers_patentLink.click();
        at(ChinesePatentDetailPage.class);
        String patTitleDetailsPage = chinesePatentDetailsPage.detailPageTitle.getText().replace("-"," ").toLowerCase();
        //chinesePatentDetailsPage.navigateBack();
        at(ChinesePatentDetailPage.class);
        assertEquals(patTitleDetailsPage, patName);
    }
    @Test(priority = 404, groups = {"P2", "cn_family_members"}, description = "Verify sponsoring entity link in famil members")
    public void verifyCNSponsoringEntityLinkInFamilyMembers() throws Exception {
        String sponsoringEntity = chinesePatentDetailsPage.familyMembers_sponsoringEntLink.getText();
        chinesePatentDetailsPage.familyMembers_sponsoringEntLink.click();
        at(entityDetailsPage);
        String entityNameDetailsPage = entityDetailsPage.detailPageTitle.getText();
        entityDetailsPage.navigateBack();
        at(PatentDetailPage.class);
        assertEquals(entityNameDetailsPage, sponsoringEntity);
    }
    /** FIRST CLAIM TESTS **/
    @BeforeGroups(groups = "cn_first_claim")
    public void loadCNPatentWithImages() {
        this.urlData.put("ID", "CN204119349U");
        to(chinesePatentDetailsPage, urlData);
    }

    @Test(priority = 501, groups = {"P3","cn_first_claim"}, description = "Verify Chinese patent first claim title")
    public void verifyCNFirstClaimTitle() {
        Assert.assertTrue(chinesePatentDetailsPage.first_claim_title.isDisplayed(), "Title is not as expected");
    }
    @Test(priority = 502, groups = "cn_first_claim", description = "Verify whether Chinese first claim is displayed")
    public void verifyCNFirstClaimTextDisplayed() {
        Assert.assertFalse(chinesePatentDetailsPage.first_claimText.getText().isEmpty(), "First claim is empty");
    }
    @Test(priority = 503, groups = {"P3", "cn_first_claim"}, description = "Verify view all claims in first claim")
    public void verifyViewAllCNClaimsInFirstClaim() {
        softAssert = new SoftAssert();
        softAssert.assertTrue(chinesePatentDetailsPage.viewAllClaims.isDisplayed(),
                "View all claims is not displayed in first claim section");
        softAssert.assertTrue(chinesePatentDetailsPage.viewAllClaims.getAttribute("href").contains("#claims"),
                "View all claims is not linked to claims section");
        softAssert.assertAll();
    }
    @Test(priority = 504, groups = {"P3", "cn_first_claim"}, description = "Verfiy whether front page is displayed in first claim")
    public void verifyCNFrontPageInFirstClaim() {
        softAssert = new SoftAssert();
        to(chinesePatentDetailsPage,"CN204119349U");
        chinesePatentDetailsPage.patent_frontPage_img.waitUntilVisible();
        softAssert.assertTrue(
                chinesePatentDetailsPage.patent_frontPage_img.getAttribute("src").contains("-patents.s3.amazonaws.com"),
                "Patent images are not linked to twin dolphin");
        softAssert.assertAll();
    }
    @Test(priority = 505, groups = {"P3", "cn_first_claim"}, description = "Verify patent images from first claim")
    public void verifyCNPatentImagesInFirstClaim() throws Exception {
        softAssert = new SoftAssert();
        String viewImagesBtnText = chinesePatentDetailsPage.viewImages_btn.getText();
        String imagesCountInBtn = viewImagesBtnText.substring(viewImagesBtnText.indexOf("(") + 1,
                viewImagesBtnText.indexOf(")"));

        softAssert.assertTrue(chinesePatentDetailsPage.viewPatentImages(), "Chinese Patent images are not displayed");
        ;
        String patentImagesDisplayed = Integer.toString(chinesePatentDetailsPage.claimImages.getElements().size());
        softAssert.assertEquals(patentImagesDisplayed, imagesCountInBtn,
                "Chinese Patent images displayed doesnt matches with the count in details page");
        softAssert.assertTrue(chinesePatentDetailsPage.closePatentImages(), "Chinese Patent images is container is not closed");
        softAssert.assertAll();
    }
    /** LITIGATION SECTION - CAMPAIGN VIEW  TESTS**/
    @BeforeGroups(groups = "cn_pat_lit_camp_section")
    public void loadCNLitigationCampaignSection() {
        this.urlData.put("ID", "CN1797810A");//US7934148B2
        to(chinesePatentDetailsPage, urlData);
    }
    @Test(priority = 601,groups = {"P2", "cn_pat_lit_camp_section"}, description = "Verify Litigation Campaign - Campaign View - Table Header")
    public void verifyCNLitCamp_CampView_TableHeader() throws Exception {
        String expHeader[] = {"Campaign Name", "Start Date", "Defendant Parents", "Most Recent Case", "Termination Date", "Jurisdiction"};
        assertEquals(chinesePatentDetailsPage.litigation_table.getHeaderData(), expHeader, "Defendant table header");
    }
    @Test(priority=602,groups={"P4","cn_pat_lit_camp_section","func_sorting"},description="Verify table default sort column")
    public void checkDefaultSortForCNCampaignName() {
        assertColumnSort("string", "desc",chinesePatentDetailsPage.litigation_table.getColumn("Campaign Name"));
    }

    @Test(priority=603,groups={"P4","cn_pat_lit_camp_section","func_sorting"},dataProvider="cn_pat_lit_campaign_table",description="Verify related campaign table sort")
    public void checkRelatedCNLitCampaignSort(String columnType,String sortType,String columnName) throws Exception {
        chinesePatentDetailsPage.litigation_table.sort(columnName);
        assertColumnSort(columnType, sortType, chinesePatentDetailsPage.litigation_table.getColumn(columnName));
    }
    @DataProvider(name="cn_pat_lit_campaign_table")
    public Object[][] CNcampaignData() {
        return new Object[][]{{"string","ASC","Campaign Name"},{"string","DESC","Campaign Name"},
                {"date","ASC","Start Date"},{"date","DESC","Start Date"},
                {"string","ASC","Defendant Parents"},{"string","DESC","Defendant Parents"},
                {"string","ASC","Most Recent Case"},{"string","DESC","Most Recent Case"},
                {"date","ASC","Termination Date"},{"date","DESC","Termination Date"},
        {"string","ASC","Jurisdiction"},{"string","DESC","Jurisdiction"}};
}
    @Test(priority=604,groups = {"P2","cn_pat_lit_camp_section"},description="verify camapign redirection from Litigations Section")
    public void checkCNCampaignLinkRedirection() throws Exception{
        SoftAssert softAssert = new SoftAssert();
        String campaignName=chinesePatentDetailsPage.litigation_table.getColumnLinkElem("Campaign Name").getText();
        withNewWindow(chinesePatentDetailsPage.litigation_table.getColumnLinkElem("Campaign Name"), () ->{
            at(campaignDetailPage);
            softAssert.assertTrue(campaignDetailPage.detailPageTitle.getText().toLowerCase().contains(campaignName.toLowerCase()),campaignName+" is not in Campaign title:"+campaignDetailPage.detailPageTitle.getText());
        });
        chinesePatentDetailsPage.litigation_table.waitUntilVisible();
        softAssert.assertAll();
    }
    @Test(priority=605,dataProvider = "cncampViewMostRecentCase",groups = {"P2","cn_pat_lit_camp_section"},description="verify camapign most recent case redirection")
    public void checkCNCampaignMostRecentCaseRedirection(String recentCase) throws Exception{
        softAssert = new SoftAssert();
        chinesePatentDetailsPage.campView_recentCase.getElement(recentCase).waitUntilVisible();
        String recentCaseLink = chinesePatentDetailsPage.campView_recentCase.getElement(recentCase).getText().toLowerCase();
        withNewWindow(chinesePatentDetailsPage.campView_recentCase.getElement(recentCase), () -> {
            at(baseDetailPage);
            String titleInDetailsPage = baseDetailPage.getCaseNumber().toLowerCase();
            softAssert.assertEquals(recentCaseLink, titleInDetailsPage, "Most Recent Case link text and corresponding litigation details page title not matched");
        });
        softAssert.assertAll();
    }

    @DataProvider
    public Object[][] cncampViewMostRecentCase() {
        return new Object[][] {
                {"itc_recentCase"},
                { "fc_recentCase"},
                { "lit_recentCase"},
        };
    }
    /** LITIGATION SECTION - CAMPAIGN VIEW - DEFENDANT TESTS **/
    @BeforeGroups(groups = "CN_lit_camp_case_view_defendant_tab")
    public void loadPatentWithLitigationCases() {
        this.urlData.put("ID", "CN201833371U");
        to(chinesePatentDetailsPage, urlData);
    }

    @Test(priority = 701, groups = {"P2", "CN_lit_camp_case_view_defendant_tab"}, description = "Verify Litigation Campaign - Case View - Defendant table header")
    public void verifyCNLitCamp_CaseView_DefendantTab_TableHeader() throws Exception {
        chinesePatentDetailsPage.selectDefendantTabInLitigationCaseView();
        String expHeader[] = {"Defendant Parent", "Defendants", "Most Recent Case", "Earliest Start Date", "Ultimate End Date"};
        assertEquals(chinesePatentDetailsPage.defendant_non_camp_table.getHeaderData(), expHeader, "Defendant table header");
    }
    @Test(priority = 702, groups = {"P3","CN_lit_camp_case_view_defendant_tab"}, description = "Verify view less in Litigation Campaign - Case View - Defendant table")
    public void verifyCNLitCamp_CaseView_DefendantTab_ViewLess() {
        softAssert = new SoftAssert();
        chinesePatentDetailsPage.selectDefendantTabInLitigationCaseView();
        chinesePatentDetailsPage.defendant_non_camp_table.viewAll();
        int recordsBeforeViewLess = chinesePatentDetailsPage.defendant_non_camp_table.displayedRecords().getElements().size();
        chinesePatentDetailsPage.defendant_non_camp_table.viewLess();
        int recordsAfterViewLess = chinesePatentDetailsPage.defendant_non_camp_table.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsAfterViewLess == 7, "7 records are not displayed after view less");
        softAssert.assertTrue(recordsBeforeViewLess > recordsAfterViewLess, "Records displayed after view less is not less than records before view less");
        softAssert.assertAll();
    }
    @Test(priority = 703, groups = {"P3","CN_lit_camp_case_view_defendant_tab"}, description = "Verify view all in Litigation Campaign - Case View - Defendant table")
    public void verifyCNLitCamp_CaseView_DefendantTab_ViewAll() {
        softAssert = new SoftAssert();
        chinesePatentDetailsPage.selectDefendantTabInLitigationCaseView();
        int recordsBeforeViewAll = chinesePatentDetailsPage.defendant_non_camp_table.displayedRecords().getElements().size();
        chinesePatentDetailsPage.defendant_non_camp_table.viewAll();
        int recordsAfterViewAll = chinesePatentDetailsPage.defendant_non_camp_table.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsBeforeViewAll == 7, "7 records are not displayed before view all");
        softAssert.assertTrue(recordsAfterViewAll > recordsBeforeViewAll, "Records displayed after view all is not greater than records before view all");
        softAssert.assertAll();
    }
    @Test(priority = 704, groups = {"P2", "CN_lit_camp_case_view_defendant_tab"}, description = "Verify Defendant Parent link in Litigation Campaign - Case View - Defendant table")
    public void verifyCNLitCamp_CaseView_DefendantTab_DefParentLink() throws Exception {
        softAssert = new SoftAssert();
        chinesePatentDetailsPage.selectDefendantTabInLitigationCaseView();
        String defParentLinkFromTable = chinesePatentDetailsPage.def_nonCampView_defParentLink.getText().toLowerCase();
        withNewWindow(chinesePatentDetailsPage.def_nonCampView_defParentLink,() -> {
            at(entityDetailsPage);
            String entTitleFromDetails = entityDetailsPage.detailPageTitle.getText().toLowerCase();
            softAssert.assertEquals(entTitleFromDetails, defParentLinkFromTable, "Defendant Parent link text and corresponding entity details page title not matched");
        });
        softAssert.assertAll();
    }
    @Test(priority = 705, groups = {"P2", "CN_lit_camp_case_view_defendant_tab"}, description = "Verify Defendants link in Litigation Campaign - Case View - Defendant table")
    public void verifyCNLitCamp_CaseView_DefendantTab_DefendantsLink() throws Exception {
        softAssert = new SoftAssert();
        chinesePatentDetailsPage.selectDefendantTabInLitigationCaseView();
        String defParentLinkFromTable = chinesePatentDetailsPage.def_nonCampView_defLink.getAttribute("title").toLowerCase();
        withNewWindow(chinesePatentDetailsPage.def_nonCampView_defLink, () -> {
            at(entityDetailsPage);
            String entTitleFromDetails = entityDetailsPage.detailPageTitle.getText().toUpperCase().toLowerCase();
            softAssert.assertEquals(entTitleFromDetails, defParentLinkFromTable, "Defendants link text and corresponding entity details page title not matched");
        });
        softAssert.assertAll();
    }
    //groups = "lit_camp_case_view_defendant_tab"
    @Test(dataProvider = "CNdefTableMostRecentCase" , groups = "P2", description = "Verify most recent case link in Litigation Campaign - Case View - Defendant table(Lit/ITC/FC) - [RPX-17318]")
    public void verifyCNLitCamp_CaseView_DefendantTab_MostRecentCaseLink(String recentCase ) throws Exception {
        softAssert = new SoftAssert();
        to(chinesePatentDetailsPage, "CN101595433B");
        chinesePatentDetailsPage.selectDefendantTabInLitigationCaseView();
        chinesePatentDetailsPage.defendant_non_camp_table.viewAllLink().click();
        chinesePatentDetailsPage.def_nonCampView_recentCase.getElement(recentCase).waitUntilVisible();
        String mostRecentLink = chinesePatentDetailsPage.def_nonCampView_recentCase.getElement(recentCase).getText().toLowerCase();
        withNewWindow(chinesePatentDetailsPage.def_nonCampView_recentCase.getElement(recentCase), () -> {
            at(baseDetailPage);
            String titleInDetailsPage = baseDetailPage.getCaseNumber().toLowerCase();
            softAssert.assertEquals(mostRecentLink, titleInDetailsPage, "Most Recent Case link text and corresponding litigation details page title not matched");
        });
        softAssert.assertAll();
    }
    @DataProvider
    public Object[][] CNdefTableMostRecentCase() {
        return new Object[][] {
                {"itc_recentCase"},
                {"fc_recentCase"},
                {"lit_recentCase"},
        };
    }
   // ----need to fix--
    @Test(priority = 707, groups = {"P4","CN_lit_camp_case_view_defendant_tab","func_sorting"}, description = "Verify default sort in Litigation Campaign - Case View - Defendant table")
    public void verifyCNLitCamp_CaseView_DefendantTab_DefaultSort() {
        chinesePatentDetailsPage.selectDefendantTabInLitigationCaseView();
        assertColumnSort("date", "desc", chinesePatentDetailsPage.defendant_non_camp_table.getColumn("Earliest Start Date"));
    }
    @Test(priority = 708, groups = {"P4","CN_lit_camp_case_view_defendant_tab","func_sorting"}, dataProvider = "defendantSortData",
            description = "Verify sorting in Chinese Litigation Campaign - Case View - Defendant table")
    public void verifyCNLitCamp_CaseView_DefendantTab_Sorting(String columnName, String sortType, String dataType) throws Exception {
         chinesePatentDetailsPage.selectDefendantTabInLitigationCaseView();
        chinesePatentDetailsPage.defendant_non_camp_table.sort(columnName);
        assertColumnSort(dataType, sortType, chinesePatentDetailsPage.defendant_non_camp_table.getColumn(columnName));
    }
    @DataProvider
    public Object[][] defendantSortData() {
        return new Object[][] { {"Defendant Parent", "asc", "string"}, {"Defendant Parent", "desc", "string"},
                {"Defendants", "asc", "string"}, {"Defendants", "desc", "string"}, {"Earliest Start Date", "asc", "date"}, { "Earliest Start Date", "desc", "date"},
                {"Ultimate End Date", "asc", "date"}, { "Ultimate End Date", "desc", "date"}};
    }
    @Test(priority = 710, dataProvider = "cn_defendantSearchData", groups = {"P2", "CN_lit_camp_case_view_defendant_tab"},
            description = "Verify search in Litigation Campaign - Case View - Defendant table")
    public void verifyCNLitCamp_CaseView_DefendantTab_Search(String searchTerm) {
        chinesePatentDetailsPage.selectDefendantTabInLitigationCaseView();
        chinesePatentDetailsPage.defendantSearch(searchTerm);
        for (String actualRowValue : chinesePatentDetailsPage.defendant_non_camp_table.getRows()) {
            Assert.assertTrue(actualRowValue.contains(searchTerm), "Search term not retrieved in results, Search term: " + searchTerm +
                    " Actual value in table: " + actualRowValue);
        }
    }
    @DataProvider
    public Object[][] cn_defendantSearchData() {
        return new Object[][] { {"Shandong Hongxin Chemical Co. Ltd"}, {"Shandong Hongxin Chemical Co. Ltd"}, {"CN-13-RE32791-370814"}, {"09/09/2014"} };
    }
    @Test(priority = 711, dataProvider = "invalidCNDefendantSearchData", groups = {"P3", "CN_lit_camp_case_view_defendant_tab"},
            description = "Verify invalid search in Litigation Campaign - Case View - Defendant table")
    public void verifyCNLitCamp_CaseView_DefendantTab_InvalidSearch(String searchTerm) throws Exception {
        chinesePatentDetailsPage.selectDefendantTabInLitigationCaseView();
        chinesePatentDetailsPage.defendantSearch(searchTerm);
        assertEquals(chinesePatentDetailsPage.noSearchResults.getText(), "No matching records found", "Message for invalid search not as expected");
    }
    @DataProvider
    public Object[][] invalidCNDefendantSearchData() {
        return new Object[][] { {"***INVALID ENTRY DATA***"} };
    }
    /** LITIGATION SECTION - CASE VIEW - DEFENDANT SUB TABLE TESTS **/
    @BeforeGroups(groups = "cn_lit_camp_case_view_defendant_tab_subTable")
    public void loadCNPatentWithLitigationDefendantSubtable() {
        this.urlData.put("ID", "CN201833371U");
        to(chinesePatentDetailsPage, urlData);
    }

    @Test(priority = 712, groups = {"P2", "cn_lit_camp_case_view_defendant_tab_subTable"}, description = "Verify header in Litigation Campaign - Case View - Defendant sub table")
    public void verifyCNLitCamp_CaseView_DefendantTab_subTableHeader() throws Exception {
        chinesePatentDetailsPage.selectDefendantTabInLitigationCaseView();
        chinesePatentDetailsPage.defendant_non_camp_table.expandSubTable();
        String expHeader[] = {"Date Filed", "Case Name", "Case Number", "Closed Date"};
        List<String> actualHeaderList = new ArrayList<String>(Arrays.asList(chinesePatentDetailsPage.defendant_non_camp_table.subtable().getHeaderData()));
        actualHeaderList.remove("Id");
        String actualHeader[] = actualHeaderList.toArray(new String[actualHeaderList.size()]);
        assertEquals(actualHeader, expHeader, "Defendant sub table header");
    }
    @Test(priority = 713, groups = {"P2", "cn_lit_camp_case_view_defendant_tab_subTable"},
            description = "Verify Case Name link in Litigation Campaign - Case View - Defendant sub table")
    public void verifyCNLitCamp_CaseView_DefendantTab_subTableCaseNameLink() throws Exception {
        softAssert = new SoftAssert();
        chinesePatentDetailsPage.selectDefendantTabInLitigationCaseView();
        chinesePatentDetailsPage.defendant_non_camp_table.expandSubTable();
        String caseNameFromSubTable = chinesePatentDetailsPage.def_nonCampView_subTable_caseNameLink.getText().toLowerCase();
        withNewWindow(chinesePatentDetailsPage.def_nonCampView_subTable_caseNameLink, () -> {
            at(litigationDetailPage);
            String litTitleFromDetails = litigationDetailPage.detailPageTitle.getText().toLowerCase();
            softAssert.assertEquals(litTitleFromDetails, caseNameFromSubTable, "Case name link text and corresponding litigation details page title not matched");
        });
        softAssert.assertAll();
    }
}
