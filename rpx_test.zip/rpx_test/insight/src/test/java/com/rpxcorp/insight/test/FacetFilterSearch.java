package com.rpxcorp.insight.test;

import com.rpxcorp.insight.page.LoginPage;
import com.rpxcorp.insight.page.search.EntitySearchPage;
import com.rpxcorp.insight.test.data.BaseDataTest;
import com.rpxcorp.testcore.Assertion;
import com.rpxcorp.testcore.driver.Browser;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.util.ConfigLoader;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.ExcelUtil;
import com.rpxcorp.testcore.util.SQLProcessor;
import org.apache.commons.lang3.StringUtils;
import org.testng.ITest;
import org.testng.ITestContext;
import org.testng.annotations.*;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class FacetFilterSearch extends Assertion implements ITest {

    class SearchPageReader extends BaseDataTest {
        Browser browser;
        SQLProcessor sqlProcessor = SQLProcessor.getInstance();
        EntitySearchPage entitySearchPage = new EntitySearchPage();
        private Map<String, String> test_data;
        private String testCase;
        private String testScenario;
        private String pageName;
        private String locatorId;
        private String preActions;
        private String queryKeys;
        private String columnName;
        private List<String> uniqueid_vals;

        public SearchPageReader(Browser browser, String pageName, String testCase, String testScenario,
                Map<String, String> test_data, String locatorId, String preActions, String queryKeys,
                String columnName) {
            this.browser = browser;
            this.testCase = testCase;
            this.test_data = test_data;
            this.pageName = pageName;
            this.locatorId = locatorId;
            this.preActions = preActions;
            this.queryKeys = queryKeys;
            this.columnName = columnName;
            this.testScenario = testScenario;
        }

        public Object getUIData() throws Exception {
            try {
                Page page = to(pageName, browser, test_data);
                if (StringUtils.isNotBlank(preActions)) {
                    Object retVal = page.invokeMethod(preActions);
                    getPreactionReturnObject(preActions, retVal);
                }
                String[] locator = locatorId.split(",");
                if (locator.length == 2) {
                    return page.object(locator[0]).getData(Integer.parseInt(locator[1]));
                }
                return page.object(locatorId).getData();
            } catch (Exception e) {
                return "No results";
            }
        }

        public void assertDBData() throws Exception {
            String[] queryKeyArr = this.queryKeys.split(",");
            ResultSet rs;
            if (testCase.toLowerCase().contains("count")) {
                for (int i = 0; i < queryKeyArr.length; i++)
                    queryKeyArr[i] = pageName + "." + queryKeyArr[i] + "_" + testScenario + "_COUNT";
                assertEquals(getUIData(), sqlProcessor.getResultData(queryKeyArr, this.test_data), "count");
            } else if (testCase.toLowerCase().contains("values")) {
                for (int i = 0; i < queryKeyArr.length; i++)
                    queryKeyArr[i] = pageName + "." + queryKeyArr[i] + "_" + testScenario + "_VALUES";
                Object uiValues = getUIData();
                if (uniqueid_vals == null)
                    assertEquals(uiValues, "No results");
                else
                    assertEquals(uiValues, sqlProcessor.getResultData(queryKeyArr, uniqueid_vals, this.test_data));
            } else {
                for (int i = 0; i < queryKeyArr.length; i++)
                    queryKeyArr[i] = pageName + "." + queryKeyArr[i];
                rs = sqlProcessor.getResultData(queryKeyArr);
                assertEquals(getUIData(), rs);
            }
        }

        private void getPreactionReturnObject(String preActionName, Object retVal) {
            if (retVal == null)
                return;
            switch (preActionName) {
            case "getUniqueIDs_grouped":
                if (retVal instanceof List) {
                    uniqueid_vals = (List<String>) retVal;
                }
                break;
            case "getUniqueIDs_nonGrouped":
                if (retVal instanceof List) {
                    uniqueid_vals = (List<String>) retVal;
                }
                break;
            default:
                break;
            }

        }
    }

    private Map<String, String> test_data;
    private String[][] validationPoints;
    private String pageName;
    static String suiteName;
    static String[][] validationPoints_Static;
    static Properties site1_config;
    static Browser site1_browser;
    LoginPage loginPage;

    @BeforeSuite
    public void setup() {
        site1_browser = new Browser(site1_config);
        to(loginPage, site1_browser);
        loginPage.login("auto_admin@rpxcorp.com", "Welcome@1");
        loginPage.waitForDashboardPage();
    }

    @AfterSuite
    public void teardown() {
        site1_browser.getDriver().quit();
    }

    @Test(dataProvider = "validationPoints")
    public void assertValidationPoint(String testCase, String defaultUrlParams, String testScenario, String locatorId,
            String preActions, String columnName) throws Exception {
        Map<String, String> testData = new HashMap<String, String>(test_data);
        testData.put("defaultUrl", defaultUrlParams);
        SearchPageReader siteReader = new SearchPageReader(site1_browser, pageName, testCase, testScenario, testData,
                locatorId, preActions, testData.get("QUERY"), columnName);
        siteReader.assertDBData();
    }

    @Factory(dataProvider = "testDatas")
    public FacetFilterSearch(Map<String, String> test_data) {
        this.test_data = test_data;
        this.pageName = suiteName + "Page";
        this.validationPoints = validationPoints_Static;
    }

    @DataProvider
    public static Object[][] testDatas(ITestContext context) {
        suiteName = context.getCurrentXmlTest().getParameter("Suite_Name");
        site1_config = ConfigLoader.loadProp(ConfigUtil.config().get("testResourcesDir") + "/environment/"
                + ConfigUtil.config().get("ENV") + ".properties");
        ExcelUtil testData = new ExcelUtil(
                ConfigUtil.config().get("testResourcesDir") + "/test_data/FacetSearchTestData.xls");
        ExcelUtil testCase = new ExcelUtil(
                ConfigUtil.config().get("testResourcesDir") + "/test_case/FacetSearchTestCase.xls");
        validationPoints_Static = testCase.getAllDataFromColumn(suiteName, new Object[] { 0, 1, 2, 3, 4, 5 }, 2);
        return testData.getAllCoumnDataAsMap(suiteName);
    }

    @DataProvider
    public Object[][] validationPoints() {
        return validationPoints;
    }

    @Override
    public String getTestName() {
        return this.test_data.get("Test Data Description") + ";" + ConfigUtil.config().getProperty("BASE_URL")
                + getPagePartialUrl(pageName, test_data);
    }

}