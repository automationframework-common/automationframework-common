package com.rpxcorp.insight.module;

import com.rpxcorp.testcore.element.Element;
import org.openqa.selenium.By;

import java.util.ArrayList;

public class AutoComplete extends Element {

    public final  Element dropdown = new Element(".ui-autocomplete .ui-menu-item:visible");
    public final  Element dropdown_Parent = new Element(".ui-autocomplete .ui-menu-item.autocomplete-parent:visible");
    public final  Element dropdown_Child = new Element(".ui-autocomplete .ui-menu-item:visible:not('.autocomplete-parent')");

    public AutoComplete(By locator) {
        super(locator);
    }

    public AutoComplete(String selector) {
        super(selector);
    }

    public void select(String value){
        if (value != null && !value.isEmpty() ) {
            sendKeys(value);
            Element resultValue = new Element(".ui-autocomplete .ui-menu-item:contains('" + value + "')");
            resultValue.waitUntilVisible();
            resultValue.click();
        }
    }

    public ArrayList<String> getDropDownValue(){
        waitForRequestInit();
        waitForDOM();
        dropdown.waitUntilVisible();
        return dropdown.getAllData();
    }

    public ArrayList<String> getParentDropDownValue(){
        waitForRequestInit();
        waitForDOM();
        dropdown.waitUntilVisible();
        return dropdown_Parent.getAllData();
    }

    public ArrayList<String> getChildDropDownValue(){
        waitForRequestInit();
        waitForDOM();
        dropdown.waitUntilVisible();
        return dropdown_Child.getAllData();
    }

}
