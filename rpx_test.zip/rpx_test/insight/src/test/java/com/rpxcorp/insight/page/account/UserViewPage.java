package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

public class UserViewPage extends BasePage {

    public UserViewPage() {
        this.url = new PageUrl("admin/users/{ID}");
    }

    @Override
    public boolean at() {
        return userTitle.waitUntilVisible();
    }

    public final Element userTitle = $(".profile_header .title");
    public final Element browserUsage_chart = $("#chart_view");
    public final Element disable_btn = $(".button[href*='toggle_active']");
    public final Element usedDocumnetCreditInfo = $(".reset_info>span");
    public final Element litDownloadReset_btn = $(".reset_info>a");
    public final Element flashMessage = $("#flash_name");
    public final Element role = $("div.profile_body .columns:contains(Basic information) td:contains(Insight Role)+td");
    public final Element userRole = $(By.xpath("//td[text()='Insight Role']/following-sibling::td[1]"));
    public final Element userCompany = $(By.xpath("//td[text()='Company']/following-sibling::td[1]"));
    public final Element edit_Btn = $("div.profile_header a:contains(Edit)");
    public final Element enable_Btn = $(By.xpath("//a[text()='Enable']"));
    public final Element disable_Btn = $("a:contains('Disable')");
    public final Element alert_Btn= $(By.xpath("//*[@class='row profile_header']//a[text()='Alerts']"));
    public final Element activationLink = $("td[id*='activation_link']");
    public final Element generate_ActivationLnk=$("a#new_activation_link");
    public final Element validity=$("[id*='activation_expiry_']");
    public final Element subscription_expires_Txt=$(By.xpath("//td/text()[contains(.,'Subscription Expires On')]"));
    public final Element subscription_exprires_value=$("tr:contains(Subscription Expire) td:nth-of-type(2)");
    public final Element activationResponse_Modal=$("#actvation_response_modal.open");    
    public final Element activationModal_Close=$("#actvation_response_modal a.close-reveal-modal");

    //locators for page access limit pages in admin/users page RPX-12925 -- Add user's current download limits and clear functionality in admin view page
    public final Element allSearchLimit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(1)>td:nth-of-type(3)");
    public final Element campaignPageLimit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(4)>td:nth-of-type(3)");
    public final Element entityDetailPageLimit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(5)>td:nth-of-type(3)");
    public final Element entitySearchLimit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(6)>td:nth-of-type(3)");
    public final Element ITCDetailPageLimit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(7)>td:nth-of-type(3)");
    public final Element litDetailPageLimit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(8)>td:nth-of-type(3)");
    public final Element litSearchLimit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(9)>td:nth-of-type(3)");
    public final Element marketplaceDetailLimit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(10)>td:nth-of-type(3)");
    public final Element PTABDetailPageLimit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(11)>td:nth-of-type(3)");
    public final Element patentDetailLimit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(12)>td:nth-of-type(3)");
    public final Element patentSearchLimit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(13)>td:nth-of-type(3)");
    public final Element portfolioDetailLimit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(14)>td:nth-of-type(3)");




    //locators for page access visit in admin/users page RPX-12925 -- Add user's current download limits and clear functionality in admin view page
    public final Element allSearchVisit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(1)>td:nth-of-type(2)");
    public final Element entityDetailPageVisit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(5)>td:nth-of-type(2)");
    public final Element litDetailPageVisit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(8)>td:nth-of-type(2)");
    public final Element marketplaceDetailVisit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(10)>td:nth-of-type(2)");
    public final Element patentDetailVisit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(12)>td:nth-of-type(2)");
    public final Element patentSearchVisit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(1) tbody tr:nth-of-type(13)>td:nth-of-type(2)");

    public final Element pageAccessReset = $("form[action*='restricted_page_limit'] p input");
    public final Element DownloadReset = $("form[action*='report_download_limit'] p input");

    //locators for download limit in admin/users page RPX-12925 -- Add user's current download limits and clear functionality in admin view page
    public final Element dossierLimit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(2) tbody tr:nth-of-type(1)>td:nth-of-type(3)");
    public final Element priorArtSearchReportLimit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(2) tbody tr:nth-of-type(2)>td:nth-of-type(3)");
    public final Element excelSearchLimit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(2) tbody tr:nth-of-type(3)>td:nth-of-type(3)");
    public final Element excelDetailsLimit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(2) tbody tr:nth-of-type(4)>td:nth-of-type(3)");
    public final Element LCALimit = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(2) tbody tr:nth-of-type(5)>td:nth-of-type(3)");


    //locators for actual download limit in admin/users page RPX-12925 -- Add user's current download limits and clear functionality in admin view page
    public final Element dossierDownload = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(2) tbody tr:nth-of-type(1)>td:nth-of-type(2)");
    public final Element priorArtSearchReportDownload = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(2) tbody tr:nth-of-type(2)>td:nth-of-type(2)");
    public final Element excelSearchDownload = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(2) tbody tr:nth-of-type(3)>td:nth-of-type(2)");
    public final Element excelDetailsDownload = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(2) tbody tr:nth-of-type(4)>td:nth-of-type(2)");
    public final Element LCADownload = $(".large-12 >div:nth-of-type(3)>div:nth-of-type(2) tbody tr:nth-of-type(5)>td:nth-of-type(2)");



    public void closeActivationModal() {
    	if(activationModal_Close.isDisplayed()) {
    		activationModal_Close.click();
    		validity.waitUntilVisible();
    	}
    }
    public String getUsedDocDownloadCredit() {
        return usedDocumnetCreditInfo.getText().split("/")[0].replace("$", "").trim();
    }

    public String getTotalCreditDocDownload() {
        return usedDocumnetCreditInfo.getText().split("/")[1].replace("$", "").trim();
    }
    public void resetLitDocDownloadLimit() {
        litDownloadReset_btn.click();
        flashMessage.waitUntilTextPresent("Download Limits was successfully reset");
    }

    public void resetPageLimit() {
        pageAccessReset.click();
        flashMessage.waitUntilTextContains("User page view count has been successfully reset");
        at();
    }

    public void resetPageDownloadLimit() {
        DownloadReset.click();
        flashMessage.waitUntilTextContains("User download count has been successfully reset");
        at();
    }

    public String getUserRole() {
        userRole.waitUntilVisible();
        return userRole.getText();
    }
    
    public String getCompanyName() {
    	userCompany.waitUntilVisible();
        return userCompany.getText();
    }

    public void clickOnEditUser() {
        edit_Btn.waitUntilVisible();
        edit_Btn.click();
    }

    public final Table userHistory_Table = $("h5:contains('User History')+table",Table.class);

    public final Table pageView_Table = $("h5:contains('Page view')+table",Table.class);


    public List<String> getRestrictedOptions(String type) {
    	List<String> data = new ArrayList<String>();
    	List<WebElement> selectedOptions = null;
    	
    	if(type.equals("/"))
    		selectedOptions = $(By.xpath("//h5[text()='Restrictions']/../table//td/i[@class='icon-checkmark']/../../td[1]")).getElements();
    	else if(type.equals("X"))
    		selectedOptions = $(By.xpath("//h5[text()='Restrictions']/../table//td/i[@class='icon-cross']/../../td[1]")).getElements();
    	
    	for(WebElement selectedOption : selectedOptions) {
    		data.add(selectedOption.getText().trim());
    	}
    	
    	return data;
    }
    
    public String getActivationToken() {
    	String activationLinkText=activationLink.getText();
    	return activationLinkText.substring(activationLinkText.lastIndexOf("/") + 1);
    }
}
