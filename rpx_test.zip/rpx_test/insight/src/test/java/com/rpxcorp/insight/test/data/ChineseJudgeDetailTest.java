package com.rpxcorp.insight.test.data;

import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.insight.page.detail.ChineseJudgeDetailPage;
import com.rpxcorp.testcore.TableData;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.util.Map;

@Authenticate(role = "MEMBER")
public class ChineseJudgeDetailTest extends BaseDataTest{

    ChineseJudgeDetailPage chineseJudgeDetailPage;
    TableData tableData;
    Map<String, String> staticData;

    /* TEST CONFIGURATIONS */
    @Factory(dataProvider = "returnData")
    public ChineseJudgeDetailTest(String dataDescription, String chJudId) throws Exception {
        this.dataDescription = dataDescription;
        this.dataId = getPageId(chJudId);
    }

    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("ChineseJudgeDetail");
    }

    @BeforeClass
    public void loadPage() {
        this.urlData.put("ID", dataId);
        this.dataUrl = chineseJudgeDetailPage.getDeclaredUrl(urlData);
        to(chineseJudgeDetailPage, urlData);
    }

    @Test(description = "Verify Title")
    public void verifyTitle() throws Exception {
        assertEquals(chineseJudgeDetailPage.detailPageTitle.getData(),
                sqlProcessor.getSinglResultValue("ChineseJudgeDetail.TITLE", dataId));
    }

    @Test(description = "Verify inactive cases in Stats bar")
    public void verifyInactiveCasesCountInStats() throws Exception {
        assertEquals(chineseJudgeDetailPage.statsBarContent.getData("inactive_petitions"),
                sqlProcessor.getResultCount("ChineseJudgeDetail.LITIGATIONS_INACTIVE", dataId));
    }

    @Test(description = "Verify inactive cases in Litigaton section")
    public void verifyInactiveCases() throws Exception {
        assertEquals(chineseJudgeDetailPage.litigation_Section.getData(),
                sqlProcessor.getResultData("ChineseJudgeDetail.LITIGATIONS_INACTIVE", dataId));
    }
}
