package com.rpxcorp.insight.page;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;

public class AnalystSearchPage extends Page{

	@Override
	public boolean at() {
        pageTitle.waitUntilVisible();
		return loading.waitUntilInvisible();
	}

	public final Element assetCount = $(".headline-boxes .text-center:contains('Assets') .ng-binding");
	public final Element patentCount = $("div.clearfix totals-widget.ng-isolate-scope ng-pluralize:contains(Patent)");
    public final Element pageTitle =$(".heading-section .header-main");
	public final Element commonSpinner =$(".fa-spinner:visible");
	public final Element loading = $("div.grid-loading.patent-grid>i.fa.fa-spinner.fa-spin");
}
