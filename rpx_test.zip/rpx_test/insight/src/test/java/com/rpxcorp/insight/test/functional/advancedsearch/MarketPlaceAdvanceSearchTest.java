package com.rpxcorp.insight.test.functional.advancedsearch;

import com.rpxcorp.insight.module.AutoComplete;
import com.rpxcorp.insight.page.advance_search.AdvanceSearchPage;
import com.rpxcorp.insight.page.advance_search.AdvanceSearchPage.SEARCHTAB;
import com.rpxcorp.insight.page.advance_search.MarketPlaceAdvanceSearchPage;
import com.rpxcorp.insight.test.functional.BaseFuncTest;
import com.rpxcorp.testcore.Assert;
import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.Test;

import java.util.List;

@Authenticate(role = "MEMBER")
public class MarketPlaceAdvanceSearchTest extends BaseFuncTest{
    AdvanceSearchPage advanceSearchPage;
    MarketPlaceAdvanceSearchPage marketPlaceAdvanceSearchPage;

    @Test(priority = 1, groups = "P2", dataProvider="json", description = "verify patent title auto suggest with case insensitive search")
    public void verifyPortNameNSellerAutoSuggestWithValidData(String searchField, String searchValue, List<String> expectedDropDown, String assertMessage) throws Exception {
        navigateToMarketAdvanceSearch();
        AutoComplete autoSuggestElem = (AutoComplete) marketPlaceAdvanceSearchPage.object(searchField);
        autoSuggestElem.sendKeys(searchValue);
        Assert.isEquals(autoSuggestElem.getDropDownValue(),expectedDropDown);
    }

    private void navigateToMarketAdvanceSearch() {
        to(advanceSearchPage);
        advanceSearchPage.searchFormTabLinks.select(SEARCHTAB.Marketplace);
        at(marketPlaceAdvanceSearchPage);
    }
}
