provpackage com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.AnalystSearchPage;
import com.rpxcorp.testcore.Authenticate;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.rpxcorp.insight.page.detail.AcquisitionDetailPage;
import com.rpxcorp.insight.page.search.MarketPlaceSearchPage;
import org.testng.asserts.SoftAssert;

@Authenticate(role = "MEMBER")
public class AcquisitionDetailTest extends BaseFuncTest {
    AcquisitionDetailPage acquisition;
    MarketPlaceSearchPage marketPlaceSearchPage;
    SoftAssert softAssert = new SoftAssert();

    @Test(priority = 1, groups = {"smoke","P2"}, description = "Verify all sections in Litigation details page")
    public void verifyAllSectionsInPortfolioDetailsPage() throws Exception {
        softAssert = new SoftAssert();
        this.urlData.put("ID", "4787");//4211
        to(acquisition, urlData);
        softAssert.assertTrue(acquisition.detailPageTitle.isDisplayed(),"The 'Title' is not getting displayed in the Acquisitions Details Page");
        softAssert.assertTrue(acquisition.header_info.isDisplayed(),"The 'Header Info' is not getting displayed in the Acquisitions Details Page");
        softAssert.assertTrue(acquisition.overview_status.isDisplayed(),"The 'Metrics Section' is not getting displayed in the Acquisitions Details Page");
        softAssert.assertTrue(acquisition.timeline_chart.isDisplayed(),"The 'Timeline' is not getting displayed in the Acquisitions Details Page");
        softAssert.assertTrue(acquisition.assignee_table.displayedRecords().isDisplayed(),"The 'Assignees' table is not getting displayed in the Acquisitions Details Page");
        softAssert.assertTrue(acquisition.seller_broker_info.displayedRecords().isDisplayed(),"The 'Seller/Broker Information' table is not getting displayed in the Acquisitions Details Page");
        softAssert.assertTrue(acquisition.assignmentsTable.displayedRecords().isDisplayed(),"The 'Assignments' table is not getting displayed in the Acquisitions Details Page");
        softAssert.assertTrue(acquisition.document_section_table.isDisplayed(),"The 'Document' is not getting displayed in the Acquisitions Details Page");
        softAssert.assertTrue(acquisition.representative_claims.isDisplayed(), "The 'Representative Claim' table is not getting displayed in the Acquisitions Details Page");
        softAssert.assertTrue(acquisition.patent_information.isDisplayed(),"The 'Patent Information' table is not getting displayed in the Acquisitions Details Page");
        softAssert.assertTrue(acquisition.tags.isDisplayed(),"The 'tags' section is not getting displayed in the Acquisitions Details Page");
        softAssert.assertAll();
    }
    @Test(priority = 1, groups = "P2", description = "RPX-10127:Stage change to pending not made on marketplace/acquisition details page")
    public void checkStageInfoForPending() throws Exception {
        this.urlData.put("STAGE", "Pending");
        this.urlData.put("header_type","Marketplace");
        to(marketPlaceSearchPage, urlData);
        withNewWindow(marketPlaceSearchPage.acquisition_opportunity_link,() -> {
        at(acquisition);
        Assert.assertEquals(acquisition.header_info.getData("stage").replace("Stage: ",""), "Pending");
        });
    }

    @Test(priority=2, groups = "P2", description="RPX-10102:Unable to download seller materials in aquisitions")
    public void checkSellerMaterialDownload() throws Exception {
        to(acquisition, 3962);
        withNewWindow(acquisition.sellerMaterial_document_link, () -> {
            Assert.assertTrue(getDriver().getPageSource().contains("application/pdf"), "PDF document is not loaded");
            Assert.assertFalse(getDriver().getCurrentUrl().contains("s3"), "PDF document URL doesnt show S3 bucket");
            Assert.assertTrue(getDriver().getCurrentUrl().contains("/opportunity_documents/"), "URL is not navigated to /admin/npe_reports");
        });
    }

    @Test(priority = 960, groups = "P2", description="View in Anacampalyst | View in Analyst link has to redirect to analyst search and related portfolio has to be displayed | RPX-13500")
    public void verifyViewInAnalystLink() throws Exception {
        String email_Admin = "auto_analyststaff@rpxcorp.com";
        logoutAndLoginAs(email_Admin, "Welcome@1");
        to(acquisition, 3962);
        Assert.assertEquals(acquisition.viewInAnalyst.getLink(),
                getConfig("ANALYST_BASE_URL")+"/#/portfolios/17124");
        withNewWindow(acquisition.viewInAnalyst,()->{
            AnalystSearchPage analystSearchPage = at(AnalystSearchPage.class);
            analystSearchPage.commonSpinner.waitUntilInvisible();
            //analystSearchPage.pageTitle.waitUntilTextPresent("Karr - OMA");
            assertTrue(analystSearchPage.patentCount.getIntData() >= 1,"No patent found for potfolio in analyst");
            com.rpxcorp.testcore.Assert.isEquals(analystSearchPage.getCurrentUrl(), getConfig("ANALYST_BASE_URL") + "/#/portfolios/17124?gcs=grid&pgq=portfolio_ids__eq7:717124&page=1&gvs=table");
        });
    }
}
