package com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.advance_search.*;
import com.rpxcorp.insight.page.advance_search.AdvanceSearchPage.SEARCHTAB;
import com.rpxcorp.insight.page.detail.ITCDetailPage;
import com.rpxcorp.insight.page.detail.LitigationDetailPage;
import com.rpxcorp.insight.page.detail.PtabDetailPage;
import com.rpxcorp.insight.page.search.*;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.ExcelUtil;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.*;
@Authenticate(role = "MEMBER")
public class AdvanceSearchFormTest extends BaseFuncTest {
    ExcelUtil testData = new ExcelUtil(
    ConfigUtil.config().get("testResourcesDir") + "/test_data/AdvanceSearchForm.xls");
    PatentAdvanceSearchPage rpxPatentPage;
    MarketPlaceAdvanceSearchPage rpxMarketPlacePage;
    PortfolioAdvanceSearchPage rpxPortfolioPage;
    AdvanceSearchPage advanceSearchPage;
    PatentSearchPage patentSearchPage;
    MarketPlaceSearchPage marketPlacePage;
    EntitySearchPage entitySearchPage;
    EntityAdvanceSearchPage advEntitySearchPage;
    LitigationAdvanceSearchPage advLitSearchPage;
    LitigationSearchPage litSearchPage;
    PortfolioSearchPage portfolioSearchPage;
    LitigationDetailPage litigationDetailPage;
    PtabDetailPage ptabDetailPage;
    ITCDetailPage itcDetailPage;
    AssignmentSearchPage assignmentSearchPage;
    
    private String page;

    @Test(description = "Market Place Advance Search Form", groups = {"P3", "smoke"}, dataProvider = "MarketPlace")
    public void verifyMarketPlaceAdvanceSearchForm(Map<String, String> data) throws Exception {
        String excelInput = "";
        to(advanceSearchPage);
        advanceSearchPage.searchFormTabLinks.select(SEARCHTAB.Marketplace);
        at(rpxMarketPlacePage);
        rpxMarketPlacePage.search(data);
        at(marketPlacePage);
        if(data.get("Expected Current Search") == null){
           excelInput = "";
        }else
        {
          excelInput = data.get("Expected Current Search");
        }
        assertEquals(marketPlacePage.currentSearch.getText(), excelInput);
        Assert.assertTrue(marketPlacePage.getMarketPlaceCount() > 0);
    }

    @Test(description = "Entity Advance Search Form", groups = {"P3", "smoke"}, dataProvider = "Entity")
    public void verifyEntityAdvanceSearchForm(Map<String, Object> data) throws Exception {
        to(advanceSearchPage);
        advanceSearchPage.searchFormTabLinks.select(SEARCHTAB.Entity);
        at(advEntitySearchPage);
        advEntitySearchPage.search(data);
        at(entitySearchPage);
        assertEquals(entitySearchPage.currentSearch.getText(), data.get("Expected Current Search"));
        Assert.assertTrue(entitySearchPage.enity_results_count.getIntData() > 0);
    }

    @Test(description = "Patent Litigation Tab Advance Search Form", groups = {"P3", "smoke"}, dataProvider = "PatentLitigation")
    public void verifyPatentLitigationAdvanceSearchForm(Map<String, String> data) throws Exception {
        to(advanceSearchPage);
        advanceSearchPage.searchFormTabLinks.select(SEARCHTAB.Patent_Litigation);
        at(advLitSearchPage);
        advLitSearchPage.search(data);
        at(litSearchPage);
        assertEquals(litSearchPage.search_textarea.getText(), data.get("Expected Current Search"));
        Assert.assertTrue(litSearchPage.campaign_count.getIntData() > 0);
    }

    @Test(groups = "P3", description = "Parties data for PTAB cases through Patent Litigation Tab Advance Search Form ( Party Name,Plaintiff Name,Defendant Name)", dataProvider = "cases_parties")
    public void verifyPartiesDataForPtabCases(Map<String, String> data) throws Exception {
        to(advanceSearchPage);
        advanceSearchPage.searchFormTabLinks.select(SEARCHTAB.Patent_Litigation);
        at(advLitSearchPage);
        advLitSearchPage.search(data);
        at(litSearchPage);
        assertEquals(litSearchPage.search_textarea.getText(), data.get("Expected Current Search"));
        Assert.assertTrue(litSearchPage.campaign_count.getIntData() > 0);
        litSearchPage.jurisdiction_facet.selectOptionFromSearchResultsFacetSection("Jurisdiction", "PTAB");
        at(litSearchPage);
        litSearchPage.switch_ungrouped_view();
        at(litSearchPage);
        assertTrue(litSearchPage.search_result.getColumn("case#").contains(data.get("expected_case_id")),"Expected Case id:"+data.get("expected_case_id")+" is not available in party search results "+litSearchPage.getCurrentUrl());
    }


    @Test(description = "Portfolio Tab Advance Search Form", groups = {"P3", "smoke"}, dataProvider = "Portfolio")
    public void verifyPortfolioAdvanceSearchForm(Map<String, String> data) throws Exception {
        to(advanceSearchPage);
        advanceSearchPage.searchFormTabLinks.select(SEARCHTAB.Portfolio);
        at(rpxPortfolioPage);
        rpxPortfolioPage.search(data);
        at(portfolioSearchPage);
        assertEquals(portfolioSearchPage.currentSearch.getText(), data.get("Expected Current Search"));
        Assert.assertTrue(portfolioSearchPage.portfolios_count.getIntData() > 0);
    }
    
    @Test(description = "Patent Tab Advance Search Form - Assignment Data", groups = {"P3", "smoke"}, dataProvider = "Patent_AssignmentData")
    public void verifyPatentAssignmentData(Map<String, String> data) throws Exception {
        to(advanceSearchPage);
        advanceSearchPage.searchFormTabLinks.selectExactTabName(SEARCHTAB.Patent);
        at(rpxPatentPage);
        rpxPatentPage.search(data);
        at(patentSearchPage);        
        assertEquals(patentSearchPage.currentSearch.getText(), data.get("Expected Current Search"));
        Assert.assertTrue(patentSearchPage.patent_results_count.getIntData() > 0);
        patentSearchPage.nonFamilyView();
        assertTrue(patentSearchPage.non_family_table_pats.getAllData().contains(data.get("exp_patent")),"Available Patent Results:"+patentSearchPage.family_table.getAllData()+" doesnt have expected patent"+data.get("exp_patent"));
        
    }

    @Test(description = "ADV Patent Search Form|Applications of withdrawn patent family should be retrieved in advance search results|RPX-11475,RPX-11460", groups = {"P3", "smoke"} ,dataProvider = "patnum_Search")
    public void verifyPatNumSearch(Map<String, String> data) throws Exception {
        to(advanceSearchPage);
        advanceSearchPage.searchFormTabLinks.selectExactTabName(SEARCHTAB.Patent);
        at(rpxPatentPage);
        rpxPatentPage.search(data);
        at(patentSearchPage);
        Assert.assertTrue(patentSearchPage.patent_results_count.getIntData() > 0);
        patentSearchPage.nonFamilyView();
        assertTrue(patentSearchPage.non_family_table_pats.getAllData().contains(data.get("exp_patent")),"Available Patent Results:"+patentSearchPage.family_table.getAllData()+" doesnt have expected patent"+data.get("exp_patent"));
        
    }
    
    @Test(dataProvider="searchData",groups = "P3", description="Go To Advanced Search| Verify respective tab should be highlighted when we click on Go To Advance Search link from Search Results|RPX-12077")
    public void verifyGoToAdvSearchLinkAtSearchPages(String page,String expTab) throws Exception {
    	urlData.put("CURRENT SEARCH","Communications");
    	to(page,urlData);
        advanceSearchPage.clickOnAdvancedSearchLink();
    	assertEquals(advanceSearchPage.searchFormTab.getActiveTabName(),expTab);
    }
    
    @DataProvider(name="searchData")
    public Object[][] getSearchData() {
    	return new Object[][] {{"LitigationSearchPage","Patent Litigation"},{"PortfolioSearchPage","Portfolio"},
    			{"PatentSearchPage","Patent"},{"MarketPlaceSearchPage","Marketplace"},
    			{"EntitySearchPage","Entity"},{"AssignmentSearchPage","Assignment"}
    	};
    }
    
    @Test(groups = "P3", description = "Patent Litigation Tab Advance Search Form-Party outcome|RPX-12520,RPX-12600", dataProvider = "PatentLitigation_PartyOutcomes")
    public void verifyPatentLitigationAdvanceSearchFormForPartyOutcome(Map<String, String> data) throws Exception {
        to(advanceSearchPage);
        advanceSearchPage.searchFormTabLinks.selectExactTabName(SEARCHTAB.Patent_Litigation);
        at(advLitSearchPage);
        advLitSearchPage.search(data);
        at(litSearchPage);        
        Assert.assertTrue(litSearchPage.campaign_count.getIntData() > 0);
        withNewWindow(litSearchPage.litigation_camp_table.getColumnLinkElem("Case Name"), () -> {
            at(litigationDetailPage);
            assertTrue(litigationDetailPage.plaintiff_OutcomeStatus.getAllData().toString().toLowerCase().contains(data.get("exp_plaintiff_status").toLowerCase()),"Lit Page:"+litigationDetailPage.getCurrentUrl()+", Expected plaintiff outcome status:"+data.get("exp_plaintiff_status").toLowerCase()+", Actual plaintiff outcome status:"+litigationDetailPage.plaintiff_OutcomeStatus.getAllData().toString().toLowerCase());
            assertTrue(litigationDetailPage.defendant_OutcomeStatus.getAllData().toString().toLowerCase().contains(data.get("exp_defendants_status").toLowerCase()),"Lit Page:"+litigationDetailPage.getCurrentUrl()+", Expected Defendant outcome status:"+data.get("exp_defendants_status").toLowerCase()+", Actual defendant outcome status:"+litigationDetailPage.defendant_OutcomeStatus.getAllData().toString().toLowerCase());
        });
    }
    
    @Test(groups = "P3", description = "Patent Litigation Tab Advance Search Form-Party outcome UI |RPX-12603,12597,12600")
    public void verifyPatentLitigationAdvanceSearchFormForPartyOutcomeUI() throws Exception {
    	SoftAssert asserts=new SoftAssert();
    	String expTooltip_Msg="Party outcomes only available for closed NPE cases. Outcomes may not be available for certain cases filed prior to 2012.";
        to(advanceSearchPage);
        advanceSearchPage.searchFormTabLinks.select(SEARCHTAB.Patent_Litigation);
        at(advLitSearchPage);
        //PartyOutcome tooltip verifications
        advLitSearchPage.moveToPartyOutcomeTooltipTag("Defendant Outcome");
        assertEquals(advLitSearchPage.partyOutcome_TooltipMsg.getText(),expTooltip_Msg);
        advLitSearchPage.moveToPartyOutcomeTooltipTag("Plaintiff Outcome");
        asserts.assertEquals(advLitSearchPage.partyOutcome_TooltipMsg.getText(),expTooltip_Msg);
        //PartyOutcome Date label verification
        asserts.assertTrue(advLitSearchPage.plaintiffTerminationDate_Label.isDisplayed());
        asserts.assertTrue(advLitSearchPage.defendantTerminationDate_Label.isDisplayed());
        //Clear functionality for PartyOutcome
        advLitSearchPage.plaintiff_Outcome.selectByOption("Dismissed");
        advLitSearchPage.defendant_Outcome.selectByOption("Dismissed");
        //--todo enable below code once issue is fixed(RPX-15542)
        //advLitSearchPage.clearFields.click();
        //asserts.assertEquals(advLitSearchPage.defendant_Outcome.getSelectedOption(),"Select Outcome");
        //asserts.assertEquals(advLitSearchPage.plaintiff_Outcome.getSelectedOption(),"Select Outcome");
        asserts.assertAll();

    }
    
    @Test(groups = "P3", description = "Patent Litigation Tab Advance Search Form-Judge |RPX-12736", dataProvider = "PatentLitigation_Judges")
    public void verifyPatentLitigationAdvFormForJudges(Map<String, String> data) throws Exception {
        to(advanceSearchPage);
        advanceSearchPage.searchFormTabLinks.select(SEARCHTAB.Patent_Litigation);
        at(advLitSearchPage);
        advLitSearchPage.search(data);
        at(litSearchPage);        
        Assert.assertTrue(litSearchPage.campaign_count.getIntData() > 0);
        assertEquals(litSearchPage.search_textarea.getText(), data.get("Expected Current Search"));
        withNewWindow(litSearchPage.litigation_camp_table.getColumnLinkElem("Case Name"), () -> {
            validateJudgeData(data.get("exp_Judge"));           
        });
    }
    
    @Test(groups = "P3", description="ADV FORM - Patent Litigation Search Tab - Case Status Description|RPX-12733",dataProvider="PatentLitigation_CaseStatus")
    public void verifyAdvForm_PatLit_CaseStatus(Map<String, String> data) throws Exception {
        to(advanceSearchPage);
        advanceSearchPage.searchFormTabLinks.select(SEARCHTAB.Patent_Litigation);
        at(advLitSearchPage);
        advLitSearchPage.search(data);
        at(litSearchPage);        
        Assert.assertTrue(litSearchPage.campaign_count.getIntData() > 0);
        assertEquals(litSearchPage.search_textarea.getText(), data.get("Expected Current Search"));
        litSearchPage.switch_ungrouped_view();        
        Set<String> caseStatus_ResultsList = new HashSet<String>(litSearchPage.campaign_table.getColumn("Status"));
        Set<String> expSet=new HashSet<String>(new ArrayList<String>(Arrays.asList(data.get("Case Status"))));
        assertEquals(caseStatus_ResultsList,expSet);
    }

    //Todo - RPX-15419
   //@Test(description="ADV FORM - Patent Litigation Search Tab - Docket Description|RPX-12731",dataProvider="PatentLitigation_DocketDescriptions")
    public void verifyAdvForm_PatLit_DocketDescription(Map<String, String> data) throws Exception {
        to(advanceSearchPage);
        advanceSearchPage.searchFormTabLinks.select(SEARCHTAB.Patent_Litigation);
        at(advLitSearchPage);
        advLitSearchPage.search(data);
        at(litSearchPage);        
        Assert.assertTrue(litSearchPage.campaign_count.getIntData() > 0);
        assertEquals(litSearchPage.search_textarea.getText(), data.get("Expected Current Search"));
        withNewWindow(litSearchPage.litigation_camp_table.getColumnLinkElem("Case Name"), () -> {
            validateDocketTitleData(data.get("Docket Description"));           
        });
    }

    @Test(groups = "P3", description = "ADV FORM - Patent Litigation Search Tab|RPX-13183 - Patent tab does not display any patents in this case" , dataProvider="jurisdiction_Search")
    public void verifyAdvForm_PatLit_PatentTab(Map<String, String> data) throws Exception {
        to(advanceSearchPage);
        advanceSearchPage.searchFormTabLinks.select(SEARCHTAB.Patent_Litigation);
        at(advLitSearchPage);
        advLitSearchPage.search(data);
        at(litSearchPage);
        litSearchPage.litSearchTab.select("PATENT");
        litSearchPage.overlay_Loading.waitUntilInvisible();
        Assert.assertTrue(litSearchPage.patent_camp_table.size()>0);

    }

    @Test(groups = "P3", description="ADV FORM - Patent Search Tab - Assignee type dropdown 'Clear Fields' Functionality|RPX-17021",dataProvider="Assignee Type ClearFields")
    public void verifyAdvForm_Patent_AssigneeTypeClearFields(Map<String, String> data) throws Exception {
        to(advanceSearchPage);
        advanceSearchPage.searchFormTabLinks.selectExactTabName(SEARCHTAB.Patent);
        at(rpxPatentPage);
        rpxPatentPage.currentAssigneeType.selectByOption(data.get("Current Assignee Type"));
        rpxPatentPage.anyAssigneeType.selectByOption(data.get("Any Assignee Type"));
        rpxPatentPage.originalAssigneeType.selectByOption(data.get("Original Assignee Type"));
        rpxPatentPage.assignorType.selectByOption(data.get("Assigner Type"));
        rpxPatentPage.clearFields.click();
        String currAssigneText = rpxPatentPage.currentAssigneeType.getSelectedOption();
        String allAssigneText = rpxPatentPage.anyAssigneeType.getSelectedOption();
        String orgAssigneText = rpxPatentPage.originalAssigneeType.getSelectedOption();
        String assignorText = rpxPatentPage.assignorType.getSelectedOption();
        assertEquals(currAssigneText , "Please Select" , "The string 'Please Select' is not displayed after " +
                "clicked the 'Clear Fields' Link in Patent Search Page for 'Current Assignee Type' Field");
        assertEquals(allAssigneText , "Please Select" , "The string 'Please Select' is not displayed after " +
                "clicked the 'Clear Fields' Link in Patent Search Page for 'Any Assignee Type' Field");
        assertEquals(orgAssigneText , "Please Select" , "The string 'Please Select' is not displayed after " +
                "clicked the 'Clear Fields' Link in Patent Search Page for 'Original Assignee Type' Field");
        assertEquals(assignorText , "Please Select" , "The string 'Please Select' is not displayed after " +
                "clicked the 'Clear Fields' Link in Patent Search Page for 'Assignor Type' Field");
    }

    private void validateDocketTitleData(String exp_docket) {
    	String url=getDriver().getCurrentUrl();
    	if(url.contains("/lit/")) {
			at(litigationDetailPage);
			litigationDetailPage.docketEntriesSearchBox.sendKeys(exp_docket+Keys.ENTER);
			litigationDetailPage.overlay_Loading.waitUntilInvisible();
			litigationDetailPage.docket_entries.waitUntilVisible();			
		    assertTrue(litigationDetailPage.docket_entries.getRows()[0].contains(exp_docket),"Expected dockets is:"+exp_docket+" not listed in results: "+litigationDetailPage.docket_entries.getRows()[0]);
		} else if(url.contains("/ptabs/")) {
			at(ptabDetailPage);
			ptabDetailPage.docket_Search_Input.sendKeys(exp_docket+Keys.ENTER);
			ptabDetailPage.docket_table.waitUntilVisible();			
			assertTrue(ptabDetailPage.docket_table.getRows()[0].contains(exp_docket),"Expected docket is:"+exp_docket+" not available in results list:"+ptabDetailPage.docket_table.getRows()[0]);
		} else if(url.contains("/itc/")) {
			at(itcDetailPage);
			itcDetailPage.docketEntriesSearchBox.sendKeys(exp_docket+Keys.ENTER);
			itcDetailPage.overlay_Loading.waitUntilInvisible();			
			assertTrue(itcDetailPage.docketEntries.getRows()[1].contains(exp_docket),"Expected docket is:"+exp_docket+" not listed in results:"+itcDetailPage.docketEntries.getRows()[1]);	
		}
	}

	private void validateJudgeData(String exp_Judge) {
		String url=getDriver().getCurrentUrl();
		if(url.contains("/lit/")) {
			at(litigationDetailPage);
			assertTrue(litigationDetailPage.overview_panel.getData("assigned_judge").contains(exp_Judge),"Exp Judge is:"+exp_Judge+" is not in available judges:"+litigationDetailPage.overview_panel.getData("assigned_judge")+"\n"+url);
		} else if(url.contains("/ptabs/")) {
			at(ptabDetailPage);
			if(ptabDetailPage.case_Detail.getData("Administrative_Judges").contains("Administrative Judges")){ //Administrative Judges (Non-Panel)
                assertTrue(ptabDetailPage.case_Detail.getData("Administrative_Judges").contains(exp_Judge),"Exp Judge is:"+exp_Judge+" is not in available judges:"+ptabDetailPage.case_Detail.getData("Administrative_Judges")+"\n"+url);
            }else{
                assertTrue(ptabDetailPage.case_Detail.getData("Panel_Judges").contains(exp_Judge),"Exp Judge is:"+exp_Judge+" is not in available judges:"+ptabDetailPage.case_Detail.getData("Panel_Judges")+"\n"+url);
            }
		} else if(url.contains("/itc/")) {
            at(itcDetailPage);
            assertTrue(itcDetailPage.overview_panel.getData("judge").replaceAll("\n", " ").contains(exp_Judge), "Exp Judge:" + exp_Judge + " is not in available judges: " + itcDetailPage.overview_panel.getData("judge") + "\n" + url);
        }
		
	}

    @DataProvider(name = "Entity")
    public Object[][] getAdvanceSearchFormEntityData() {
        return testData.getAllCoumnDataAsMap("Entity");
    }



	@DataProvider(name = "MarketPlace")
    public Object[][] getAdvanceSearchFormMarketPlaceData() {
        return testData.getAllCoumnDataAsMap("MarketPlace");
    }

    @DataProvider(name = "PatentLitigation")
    public Object[][] getAdvanceSearchFormPatentLitigationData() {
        return testData.getAllDataFromColumnAsMap("PatentLitigation",1,24);
    }
    
    @DataProvider(name = "PatentLitigation_PartyOutcomes")
    public Object[][] getAdvanceSearchFormPatentLitigationDataForPartyOutcome() {
        return testData.getAllDataFromColumnAsMap("PatentLitigation",25,25);
    }
    
    @DataProvider(name = "PatentLitigation_Judges")
    public Object[][] getAdvFormPatentLitForJudges() {
        return testData.getAllDataFromColumnAsMap("PatentLitigation",26,28);
    }
    
    @DataProvider(name = "PatentLitigation_DocketDescriptions")
    public Object[][] getAdvFormPatentLitForDocketTitle() {
        return testData.getAllDataFromColumnAsMap("PatentLitigation",29,31);
    }
    
    @DataProvider(name = "PatentLitigation_CaseStatus")
    public Object[][] getAdvFormPatentLitForCaseStatus() {
        return testData.getAllDataFromColumnAsMap("PatentLitigation",32,37);
    }

    @DataProvider(name = "jurisdiction_Search")
    public Object[][] getAdvanceSearchFormJurisdictionData() {
        return testData.getAllDataFromColumnAsMap("PatentLitigation",38,38);
    }

    @DataProvider(name = "Assignee Type ClearFields")
    public Object[][] getAdvanceSearchFormAssigneeTypeClearFields() {
        return testData.getAllDataFromColumnAsMap("Patent",4,4);
    }

    @DataProvider(name = "Portfolio")
    public Object[][] getAdvanceSearchFormPortfolioData() {
        return testData.getAllCoumnDataAsMap("Portfolio");
    }

    @DataProvider(name="cases_parties")
    public Object[][] getAdvancedSearchFormPartiesData() {
    	return testData.getAllDataFromColumnAsMap("PatentLitigation", 18,21);
    }

    @DataProvider(name = "Patent_AssignmentData")
    public Object[][] getAdvanceSearchFormPatentAssignmentData() {
        return testData.getAllDataFromColumnAsMap("Patent",1,1);
    }

    @DataProvider(name = "patnum_Search")
    public Object[][] getAdvanceSearchFormPatnumData() {
        return testData.getAllDataFromColumnAsMap("Patent",2,2);
    }


}
