package com.rpxcorp.insight.api;

import java.util.HashMap;

import com.rpxcorp.testcore.driver.APICache;

public class LoginAPI extends APICache {

    public void login(String username, String password) throws Exception {
        if(authenticatedUser.get() == null || authenticatedUser.get().isEmpty() || !authenticatedUser.get().equals(username)){
            clearCache();
            HashMap<String, String> params = new HashMap<>();
            String token = getAPIInstance().getCSRF_Token("/users/sign_in");
            params.put("authenticity_token", token);
            params.put("request_path", "/public_login");
            params.put("company_needed", "false");
            params.put("user[email]", username);
            params.put("user[password]", password);
            params.put("user[remember_me]", "0");
            getAPIInstance().post("/users/sign_in", params);
            authenticatedUser.set(username);
        }
    }
}
