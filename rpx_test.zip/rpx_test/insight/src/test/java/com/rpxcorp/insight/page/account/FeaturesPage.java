package com.rpxcorp.insight.page.account;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class FeaturesPage extends BasePage {

	public FeaturesPage() {
		this.url = new PageUrl("admin/features");
	}

	@Override
	public boolean at() {
		assert featurePageTitle.text().equals("Features");
		return featureField.waitUntilVisible();
	}

	public final Element featurePageTitle = $("h5.section-title");
	public final Element featureField = $(".large-12.columns");

	public String getFeatureStatus(String name) {
		String featureName = String
				.format("//td[contains(text(),'%s')]/following-sibling::td[2]/form/input[@type='submit']", name);
		Element feature = $(By.xpath(featureName));
		return feature.getAttribute("value").trim().toUpperCase();
	}

	public void changeFeatureStatus(String name, String changeStatus) {
		if (!getFeatureStatus(name).equalsIgnoreCase(changeStatus)) {
			String featureName = String.format("//td[contains(text(),'%s']/..//select", name);
			Select feature = new Select(new Element(By.xpath(featureName)));
			feature.selectByVisibleText(changeStatus);
		}
	}
	
	public void setFeature(Map<String, String> featureData) {
		for (Map.Entry<String, String> entry : featureData.entrySet()) {		    
		    setFeature(entry.getKey(), entry.getValue());
		}
	}
	
	public void setFeature(String features[], String featureStatus[]) {
		for (int featureCnt = 0; featureCnt < features.length; featureCnt++) {			
			setFeature(features[featureCnt], featureStatus[featureCnt]);
		}	
	}
	
	public void setFeature(String featureName, String featureStatus) {
		Select feature = new Select(new Element(By.xpath("//td[text()='" + featureName + "']/..//select")));
		feature.selectByVisibleText(featureStatus);
	}
}
