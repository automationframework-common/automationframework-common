package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.module.SelectBox;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class AdminBulkUserCreatePage extends BasePage {

    public AdminBulkUserCreatePage() {
        this.url = new PageUrl("admin/bulk_users/new");
    }

    @Override
    public boolean at() {
        return title.waitUntilVisible();
    }

    public final Element title = $(".section-title:contains('Create Bulk Users')");
    public final SelectBox userRole = $("#s2id_user_user_role_users_attributes_0_user_role_id", SelectBox.class);
    public final SelectBox userAccount = $("#s2id_user_rpx_id a", SelectBox.class);
    public final Element upload_File = $("input#user_upload_bulk_user");
    public final Element create_BulkUser_Btn = $("input[value='Create Bulk users']");

}
