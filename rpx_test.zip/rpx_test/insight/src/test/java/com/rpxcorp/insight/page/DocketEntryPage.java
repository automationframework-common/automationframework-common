package com.rpxcorp.insight.page;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;

import static org.testng.Assert.assertTrue;

public class DocketEntryPage extends Page {

    public DocketEntryPage() {
        this.url = new PageUrl("download_docket_entry/{ID}");
    }

    public final Element document_container = $("#viewerContainer");

    @Override
    public boolean at() {
        return getDriver().getPageSource().contains("application/pdf");
    }
}
