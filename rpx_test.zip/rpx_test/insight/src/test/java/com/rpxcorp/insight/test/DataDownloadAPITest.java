package com.rpxcorp.insight.test;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.rpxcorp.insight.test.data.BaseDataTest;
import com.rpxcorp.testcore.util.ConfigLoader;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.ExcelUtil;
import com.rpxcorp.testcore.util.SQLProcessor;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class DataDownloadAPITest extends BaseDataTest{

	SQLProcessor sqlProcessor = SQLProcessor.getInstance();
	SoftAssert softAssert;
	public final String testSuiteName;
	String testSuitePath=ConfigUtil.config().get("testResourcesDir") + "/data_queries/data_download.json";

	@Factory(dataProvider = "testSuites")
	public DataDownloadAPITest(String testSuiteName) {
		this.testSuiteName = testSuiteName;
	}

	@Test(description = "Verify Data Download | Data check for litigation fields", dataProvider = "getChineseLitIds")
	public void verifyDataDownload(String apiQuery,String dbQuery,String testData) throws Exception {
		assertResultSet(sqlProcessor.getResultData(apiQuery,testData ),
				sqlProcessor.getResultData(dbQuery,testData));
	}	
	
	@DataProvider
	public Object[][] getChineseLitIds() throws FileNotFoundException {
		JsonObject json = ConfigLoader.loadJson(testSuitePath);

		return new Object[][] {
				{json.get(this.testSuiteName).getAsJsonObject().getAsJsonObject("LITIGATION_FIELDS_API_RESULTS").toString(),json.get(this.testSuiteName).getAsJsonObject().getAsJsonObject("LITIGATION_FIELDS_ACTUAL_RESULTS").toString(),json.get(this.testSuiteName).getAsJsonObject().getAsJsonObject("test_data").toString()},
				{json.get(this.testSuiteName).getAsJsonObject().getAsJsonObject("PARTY_AND_COUNSEL_API_RESULTS").toString(),json.get(this.testSuiteName).getAsJsonObject().getAsJsonObject("PARTY_AND_COUNSEL_ACTUAL_RESULTS").toString(),json.get(this.testSuiteName).getAsJsonObject().getAsJsonObject("test_data").toString()},
				{json.get(this.testSuiteName).getAsJsonObject().getAsJsonObject("PATENT_FIELDS_API_RESULTS").toString(),json.get(this.testSuiteName).getAsJsonObject().getAsJsonObject("PATENT_FIELDS_ACTUAL_RESULTS").toString(),json.get(this.testSuiteName).getAsJsonObject().getAsJsonObject("test_data").toString()}
		};
	}

	@DataProvider
	public Object[][] testSuites()throws Exception {
		JsonObject json = ConfigLoader.loadJson(testSuitePath);
		Gson gson = new Gson();
		Map<String,HashMap<String,String>> jsonData = new HashMap<String,HashMap<String,String>>();
		jsonData = (Map<String,HashMap<String,String>>) gson.fromJson(json, jsonData.getClass());
		ArrayList<String> data=new ArrayList(Arrays.asList(jsonData.keySet()));
		Object[][] testSuites = new String[data.size()][1];
		for (int i = 0; i < data.size(); i++) {
			testSuites[i][0] = data.get(i);
		}
		return testSuites;
	}

}
