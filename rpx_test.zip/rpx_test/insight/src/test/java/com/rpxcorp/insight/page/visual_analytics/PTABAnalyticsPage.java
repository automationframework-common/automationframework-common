package com.rpxcorp.insight.page.visual_analytics;
import com.rpxcorp.insight.module.Highchart;
import com.rpxcorp.insight.module.ListPanel;
import com.rpxcorp.insight.module.Radio;
import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

public class PTABAnalyticsPage extends BasePage {
    public PTABAnalyticsPage() {
        this.url = new PageUrl("analytics/ptab");
    }

    @Override
    public boolean at() {
        loading.waitUntilInvisible();
        contentLoading.waitUntilInvisible();
        return pTABsearchPanelTabs.waitUntilVisible();
    }
    public final Tabs pTABsearchPanelTabs = new Tabs("div.columns.down-tabs .tabs");
    public final Element titlePTABAnalyticsSection =$("h1.detail-page-title");
    public final Element petitionFiledChart =$("#general div.ent_lit_search #petitions-filed");
    public final Element petitionTechCenter =$("#general div.ent_lit_search #pettion-by-tech-center");
    public final Element partyTab =$("div.top-petitition-field .analytics-chart-title h2");
    public final Element topPetitionerChart =$("div.top-petitition-field div#ptab-top-petitioners");
    public final Element topPatentOwnerChart =$("div.top-petitition-field div#ptab-top-patent-owners");
    public final Element lawfirmPetitionerChart =$(".top-lawfirm-field div.cost_analytics_chart_column  div#petitioners-counsel-chart");
    public final Element lawfirmPatentOwnerChart =$(".top-lawfirm-field div.cost_analytics_chart_column  div#patent-owners-counsel-chart");
    public final Element judgeInstitutionDecisionChart =$("#judges div.top-judge-field div#ptab-top-petitioners");
    public final Element judgeFinalDecisionChart =$("#judges div.cost_analytics_chart_column div#ptab-top-patent-owners");

    public final Element outcomeSankey =$("#ptab-analytics-outcome-tab div.ptab_analytics_sankey_chart #container");
    public final Element outcomedonutChartInstitutionChart =$("div.ptab-analytics-outcomes-donut-chart div.pre_trial_phase:nth-child(1) div.cost_analytics_chart_column");
    public final Element outcomedonutChartFinalDecisionChart =$("div.ptab-analytics-outcomes-donut-chart div.pre_trial_phase:nth-child(2) div.cost_analytics_chart_column");
    public final Element outcomeOvertimeChart =$("div.outcomes-over-time-chart #outcome-over-time-chart");
    public final Element loginpromomsg = $("#login-modal");

    public final Element outcomeOvertimeChartPromomsg =$("#ptab-analytics-outcome-tab div.outcomes-over-time-chart .subscription-promo-message:contains('This feature is restricted to Elite and Member subscribers')");
    public final Element lawfirmChart =$("#law_firm div.row");
    public final Element lawfirmChartPromomsg =$("#law_firm div.subscription-promo-message:contains('This feature is restricted to Elite and Member subscribers')");
    public final Element judgeChartPromomsg =$("#judges div.subscription-promo-message:contains('This feature is restricted to Elite and Member subscribers')");

    public final Element JudgeChart =$("#judges div.row");
    public final Element Comparetab =$("#compare div.comparison section div.content>select#comparison_type");

    public void openPtabAnalyticsGeneralTab() {
        loading.waitUntilInvisible();
        if(!loginpromomsg.isDisplayed()) {
            pTABsearchPanelTabs.select("General");
            petitionFiledChart.waitUntilVisible();
        }
    }
    public void openPtabAnalyticsPartyTab() {
        loading.waitUntilInvisible();
        if(!loginpromomsg.isDisplayed()) {
            pTABsearchPanelTabs.select("Party");
            partyTab.waitUntilVisible();
        }
    }
    public void openPtabAnalyticsLawfirmTab() {
        loading.waitUntilInvisible();
        if(!loginpromomsg.isDisplayed()) {
            pTABsearchPanelTabs.select("Law Firm");
            lawfirmChart.waitUntilVisible();
        }
    }
    public void openPtabAnalyticsJudgeTab() {
        loading.waitUntilInvisible();
        if(!loginpromomsg.isDisplayed()) {
            pTABsearchPanelTabs.select("Judge");
            JudgeChart.waitUntilVisible();
        }
    }
    public void openPtabAnalyticsOutcomeTab() {
        loading.waitUntilInvisible();
        if(!loginpromomsg.isDisplayed()){
            pTABsearchPanelTabs.select("Outcome");
            outcomeSankey.waitUntilVisible();
        }
    }
    public void openPtabAnalyticsCompareTab() {
        loading.waitUntilInvisible();
        if(!loginpromomsg.isDisplayed()) {
            pTABsearchPanelTabs.select("Compare");
            Comparetab.waitUntilVisible();
        }
    }

}
