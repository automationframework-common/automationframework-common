package com.rpxcorp.insight.page;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class NpeEmailPreviewPage extends BasePage {
	
	public NpeEmailPreviewPage() {
        this.url = new PageUrl("admin/npe_reports/preview_report");
    }

	@Override
	public boolean at() {		
		return npeUpdateBanner.waitUntilVisible();
	}
	
	public final Element npeUpdateBanner = $("img[alt='Monthly NPE Update']");
}
