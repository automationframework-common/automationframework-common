package com.rpxcorp.insight.page.intelligence;

import com.rpxcorp.insight.module.DatePicker;
import com.rpxcorp.insight.module.MultiSelect;
import com.rpxcorp.insight.module.SelectBox;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.Map;

public class LCAReportsPage extends BasePage {

    public LCAReportsPage() {
        this.url = new PageUrl("lca_reports");
    }

    @Override
    public boolean at() {
        assertPageTitle("Litigation Campaign Assessments");
        return lcareport_table.waitUntilVisible();
    }
    public final Element lcaRowsCount = $(".lca_index_table tbody tr>td:nth-child(1)>a");

    // LCA TABLE
    public final Table lcareport_table = $(".lca_index_table", (Configure<Table>) table ->
        {
            table.uniqueId("tbody tr>td:nth-child(1)>a");
           table.nextPage("ul.pagination.pagination li:last-child");
           table.lastPage("ul.pagination.pagination li:nth-last-child(2)");
        }
    );
    public final Element campaignLinkInTable = $(".lca_index_table .campaign-name");
    public final Element plaintiffLinkInTable = $(".lca_index_table td:nth-of-type(2) a");

    public final Element downloadreportBtnInTable = $("table.lca_index_table tr:nth-child({value}) td a.button");

    public final Element downloadBtn = $("table.lca_index_table tr:nth-child({value}) li:contains('Download') a");
    public final Element updateRequestButtonInTable = $("table.lca_index_table tr:nth-child({value}) li:contains('Request an Update') a");
    public final Element editreportBtnInTable = $("table.lca_index_table tr:nth-child({value}) li:contains('Edit') a");
    public final Element deletereportBtnInTable = $("table.lca_index_table tr:nth-child({value}) li:contains('Delete') a");

    public final Element updateRequestButtonInTableLCA = $("table.lca_index_table li:contains('Request an Update') a:visible");
    public final Element editreportBtnInTableLCA = $("table.lca_index_table li:contains('Edit') a:visible");
    public final Element deletereportBtnInTableLCA = $("table.lca_index_table li:contains('Delete') a:visible");

    public void openDropdown() {
        if (!downloadBtn.of(1).isDisplayed()) {
            downloadreportBtnInTable.of(1).click();
            downloadBtn.of(1).waitUntilVisible();
        }
    }
    // LCA SEARCH AND CLEAR
    public final Element litCampaignSearchBox = $(".adv-facets textarea#searchq_revised");
    public final Element litCampaignSearchBtn = $(".adv-facets img.search-icon-pos");



    public void search(String value) {
    	waitForLoading();
    	searchCampaignAssessment(value);
    }

    public void searchCampaignAssessment(String value) {
        litCampaignSearchBox.sendKeys(value);
        litCampaignSearchBtn.click();
        loading.waitUntilInvisible();
    }
    public final Element recordCountMsg = $(".right-analytics-section .columns p");

    // LCA DELETE
    public void searchAndDeleteFromLcaTable(String... lca) {
    	for(int lcaCnt = 0; lcaCnt < lca.length; lcaCnt++) {
    		searchAndDeleteFromLcaTable(lca[lcaCnt]);
    	}
    }
    
    //TODO replace it with API or DB query
    public void searchAndDeleteFromLcaTable(String searchText) {
        if (searchText != null && !searchText.trim().isEmpty() & searchText != "") {
            search(searchText);
            if(!noLcaAvailableMsg.isDisplayed()) {
            	if (lcareport_table.isDisplayed()) {
                int recordCount = lcaRowsCount.count();
                for (int cnt = 1; cnt <= recordCount; cnt++) {
                    deleteLCAReport(cnt);
                    search(searchText);
                   }
                }
            }
            
        }
    }

    //TODO replace it with API or DB query
    public void verifyCreatedReportGettingDisplayed(String searchText) {
        if (searchText != null && !searchText.trim().isEmpty() & searchText != "") {
            search(searchText);
            Assert.assertEquals(lcareport_table.getColumnLinkElem("CAMPAIGN NAME").getText().toLowerCase(),searchText.toLowerCase(),"The LCA Report is not added successfully");
        }
    }

    // LCA RESPONSE MODAL
    public final Element lcaResponseModal = $("#request_response_modal");
    public final Element lcaResponseModalClose = $("#request_response_modal .close-reveal-modal");
    public final Element msgInLcaResponseModal = $("#request_response_modal div");
    public final Element noLcaAvailableMsg=$(".panel p:contains('No Litigation')");
    public void openLcaResponseModal() {
    	updateRequestButtonInTable.waitUntilVisible();
        updateRequestButtonInTable.click();
        lcaResponseModal.waitUntilVisible();
    }

    public void closeLcaResponseModal() {
        lcaResponseModalClose.click();
        lcaResponseModal.waitUntilInvisible();
    }

    // ADD/EDIT LCA REPORT
    public final Element addreport_btn = $(".button[href='/lca_reports/new']");
    public final Element lca_modal = $("#async_modal");
    public final Element lcaReport_Upload_AlertMsg = $("#report_modal div.row:nth-child(1)");
    public final Element lcaReport_Upload_Confirmation = $("div#report_modal button:contains('Done')");
    public final SelectBox reportTitle = $("#s2id_lca_report_campaign_id",SelectBox.class);
    public final SelectBox linkToCampaign =$("#s2id_lca_report_campaign_link_id", SelectBox.class);
    public final MultiSelect plaintiffInformation =$("#s2id_lca_report_plaintiff_ids",MultiSelect.class);
    public final DatePicker updatedDate = new DatePicker("#lca_report_publication_date");
    public final Element fileUpload = $("#lca_report_file");
    public final Element createReportButton = $("input[value='Create Report']");
    public final Element closeLcaModal = $(".modal-content .close-reveal-modal");
    public final Element cancelInLcaModal = $("#new_lca_report button[name='cancel']");

    public void openLcaAddModal() {
        addreport_btn.waitUntilVisible();
        addreport_btn.click();
        reportTitle.waitUntilVisible();
    }

    public void closeLcaAddModal() {
        closeLcaModal.waitUntilVisible();
        closeLcaModal.click();
        lca_modal.waitUntilInvisible();
    }

    public void cancelLcaAddModal() {
        cancelInLcaModal.waitUntilVisible();
        cancelInLcaModal.click();
        lca_modal.waitUntilInvisible();
    }

    public void addLCAReport(Map<String, String> data) throws Exception {
        openLcaAddModal();
        setDataInReportModal(data.get("title_PartialText"),data.get("report_title"), data.get("campaign_PartialText"), data.get("link_to_campaign"), data.get("plaintiff_info"),
                data.get("updated_date"), data.get("file"));
        createReportButton.click();
       lcaReport_Upload_Confirmation.click();
    }
    
    public void addLcaReport(String title_PartialText, String report_title, String campaign_PartialText,String campaign_link, String plaintiffs, String date, String fileName) throws Exception {
		openLcaAddModal();
		setDataInReportModal(title_PartialText,report_title, campaign_PartialText ,campaign_link, plaintiffs, date, fileName);
		createReportButton.click();
		lca_modal.waitUntilInvisible();
    }

    public void setDataInReportModal(String title_PartialText, String report_title, String campaign_PartialText ,String campaign_link, String plaintiffs, String date,
            String fileName) throws Exception {

            //If Title is real campaign name, the auto suggest is not working.So typing partial text and select the title
            reportTitle.type(title_PartialText);
            reportTitle.select(report_title);

            //Type partial text and select the campaign. The autosuggest is not working if we paste full campaign name
            linkToCampaign.type(campaign_PartialText);
            linkToCampaign.select(campaign_link);

        setPlaintiffInformationInModal(plaintiffs);
        if (date != null && !date.isEmpty() && date != "")
            updatedDate.selectDate(date);
        if (fileName != null && !fileName.trim().isEmpty() && fileName != "")
            fileUpload.sendKeys(ConfigUtil.config().get("testResourcesDir").toString() + "/test_data/" + fileName);
    }

    public void setPlaintiffInformationInModal(String plaintiff_info) throws Exception {
        if (plaintiff_info != null && !plaintiff_info.trim().isEmpty()) {
            String plaintiffs[] = plaintiff_info.split(":");
            for (String plaintiff : plaintiffs) {
                System.out.println("plaintiff info: " + plaintiff);
                plaintiffInformation.typeAndselect(plaintiff);
            }
        }
    }

    public final Element lcaErrorsInModal = $(".panel>div:not([style*='none']) .errors:not(:empty):visible");

    public void openLcaEditModal() {
        //expandDropdownMenu("1");
        editreportBtnInTable.of("1").click();
        waitForLoading();
        plaintiffInfoCloseInLcaModal.waitUntilVisible();
    }


    public void deleteLCAReport(int cnt) {
        String recorPosition = Integer.toString(cnt);
        //expandDropdownMenu(recorPosition); NO need to expand to delete the record
        deletereportBtnInTable.of(recorPosition).click();
        acceptAlert();
        String pageNotFound = $("#content h1").getText();
            if(pageNotFound.equalsIgnoreCase("Page Not Found")){
                navigateBack();
            }

        //alertMessage.waitUntilTextContains("Litigation Campaign Assessment was successfully deleted.");
        }

    public final Element plaintiffInfoCloseInLcaModal = $(".reveal-modal.xlarge.open #s2id_lca_report_plaintiff_ids ul li a");
    public final Element lcaModal=$(".reveal-modal.xlarge.open");

    public void clearPlaintiffInfoInLcaModal() {
        int plaintiffSize = plaintiffInfoCloseInLcaModal.count();
        System.out.println("count: " + plaintiffInfoCloseInLcaModal.count());
        for (int cnt = 1; cnt <= plaintiffSize; cnt++) {
            $("#s2id_lca_report_plaintiff_ids ul li a:nth-of-type(1)").click();
        }
    }

    public final Element lcaButtonMenuExpand = $("table.lca_index_table tbody tr:nth-child({value}) td>a.button.down-arrow-white");
    public final Element lcaButtonMenu = $(".f-dropdown.nd-top-menu:visible()");
    public void expandDropdownMenu(String recodPosition){
        if(!lcaButtonMenu.isDisplayed()){
            Actions actions = new Actions(getDriver());
            actions.moveToElement(lcaButtonMenuExpand.of(recodPosition).getElement()).build().perform();
            lcaButtonMenuExpand.of(recodPosition).click();
            lcaButtonMenu.waitUntilVisible();
        }

    }

    public final Element updateReportBtn = $("#submit-report");

    public void updateLcaReport() {
        updateReportBtn.click();
        plaintiffInfoCloseInLcaModal.waitUntilInvisible();
    }

    public final Element cancelInEditModal = $("button[class*='secondary cancel']");

    public void cancelLcaEditModal() {
        cancelInEditModal.click();
        plaintiffInfoCloseInLcaModal.waitUntilInvisible();
    }

    public ArrayList<String> getAutoCompleteTextList() {
        plaintiffInformationAutoCompleteList.waitUntilVisible();
        return plaintiffInformationAutoCompleteList.getAllData();
    }
    
    public void updateLca(String actualTitle, String newTitle,  String fileName) throws Exception {
    	search(actualTitle);
		openLcaEditModal();	
		setDataInReportModal(newTitle,newTitle, null,null, null, null, fileName);
		updateLcaReport();
    }

    // DELETE AND ADD LCA
    public void deleteAndAddLca(Map<String, String> data) throws Exception {
        searchAndDeleteFromLcaTable(data.get("report_title"));
        addLCAReport(data);
        lca_modal.waitUntilInvisible();
    }

    public void sendPlaintiffInformationText(String plaintiffInformationText) {
        plaintiffInformationTextBox.waitUntilVisible();
        plaintiffInformationTextBox.sendKeys(plaintiffInformationText);
    }

    public final Element plaintiffInformationTextBox = $("#s2id_autogen3");
    public final Element plaintiffInformationAutoCompleteList = $(".select2-results li div div");
}
