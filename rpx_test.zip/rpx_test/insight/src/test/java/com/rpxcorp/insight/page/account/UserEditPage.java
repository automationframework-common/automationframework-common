package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.module.SelectBox;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;
import org.apache.commons.lang3.text.WordUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.HashMap;

public class UserEditPage extends Page {

    public UserEditPage() {
        this.url = new PageUrl("admin/users/{ID}/edit");
    }

    @Override
    public boolean at() {
        return saveUser_btn.waitUntilVisible();
    }

    public final Element saveUser_btn = $(".button[name='save_user_changes']");
    // TODO change below two selector as 'select' box module
    public final Element userType_selectBox = $("#s2id_user_user_user_type_attributes_user_type_id a");
    public final Element userRole_selectBox = $(
            "#s2id_user_user_role_users_attributes_0_user_role_id input:not([disabled])");

    public final Element first_name = $("#user_first_name");
    public final Element last_name = $("#user_last_name");
    public final Element email = $("#user_email");
    public final Element user_role = $("#select2-chosen-1");
    public final Element user_account = $("div[id*='user_account_id']>a span.select2-chosen");
    public final Element userRole = $("div.panel label:contains( Insight User Role)+div a[class='select2-choice']");
    public final Element userRoleSearch = $("div.select2-search input#s2id_autogen1_search");
    public final Element userRoleSelect = $("ul.select2-results span.select2-match");
    public final Element userAccount = $("#s2id_user_account_id a[class='select2-choice']");
    public final Element userAccSearch = $("div.select2-search input#s2id_autogen2_search");
    public final Element userAccSelect = $("ul#select2-results-2 li:nth-of-type(1)");
    public final Element subscription_expiration_date=$("#user_extended_user_detail_attributes_trial_expiration_date");
    public final Element datePicker = $(".daterangepicker ");
    public final Element datePickerDate = $(".daterangepicker td");
    public final Element dateClearBtn=$(".daterangepicker button:contains('Clear')");
    public final SelectBox userAccounts =$("#s2id_user_account_id", SelectBox.class);
    
    public HashMap<String, String> getUserInfo() {
        HashMap<String, String> userInfo = new HashMap<>();
        userInfo.put("first_name", first_name.getAttribute("value"));
        userInfo.put("last_name", last_name.getAttribute("value"));
        userInfo.put("email", email.getAttribute("value"));
        userInfo.put("subscription_type", WordUtils.capitalize(user_role.getText()));
        userInfo.put("company1", user_account.getText());

        return userInfo;
    }

    public void updateRole(String role) throws Exception{
        Thread.sleep(2000);
        userRole.click();
        userRoleSearch.waitUntilVisible();
        userRoleSearch.sendKeys(role);
        userRoleSelect.waitUntilVisible();
        userRoleSelect.click();
    }

    public void selectAccount(String accountName) {
        userAccount.click();
        userAccSearch.waitUntilVisible();
        userAccSearch.sendKeys(accountName);
        userRoleSelect.waitUntilVisible();
        userAccSelect.click();
    }    
    
    public void setSubScriptionExpiresDate() {
    	subscription_expiration_date.click();
    	datePicker.waitUntilVisible();
    	datePickerDate.click();
    	datePicker.waitUntilInvisible();
    }
    
    public void clearSubscriptionExpiresDate() {
    	subscription_expiration_date.click();
    	datePicker.waitUntilVisible();
    	dateClearBtn.click();
    	subscription_expiration_date.waitUntilVisible();
    }
    
    public final Element disabledOptions = $(By.xpath("//div[contains(@class, 'profile_body')]//div[contains(@class, 'boolean')]/input[@disabled='disabled']/../label"));
    public final Element enabledOptions = $(By.xpath("//div[contains(@class, 'profile_body')]//div[contains(@class, 'boolean')]/input[not(@disabled='disabled')][not(@type='hidden')]/../label"));
    
    public void editUserOption(String option, String editType) throws Exception{
        WebElement element =  $("div.profile_body div:has(label:contains('"+option+"'))>input:visible()");
    	if(editType.equals("X")) {
    		if(element.isSelected())
                element.click();
    	} else {
    		if(!element.isSelected())
                element.click();
    	}
    	saveUser_btn.click();
    	Thread.sleep(3000);
    }
    
    //RESET PSWD BUTTON
    public final Element reset_Pswd_Btn=$("input[value='Send reset password email']");
    
    
}
