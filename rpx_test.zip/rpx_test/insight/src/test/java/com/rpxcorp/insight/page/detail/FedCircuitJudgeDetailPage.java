package com.rpxcorp.insight.page.detail;

import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;

public class FedCircuitJudgeDetailPage extends BasePage {

    public FedCircuitJudgeDetailPage() {
        this.url = new PageUrl("fed_c/judges/{ID}");
    }

    @Override
    public boolean at() {
        waitForPageLoad();
        return pageTitle.waitUntilVisible();
    }

    public final StaticContent judgeDetail = $(".entity-stats", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("Active Appeals", "li:nth-child(1) span");
                dataForm.content("Inactive Appeals", "li:nth-child(2) span");
                dataForm.content("Average Appeals per Year", "li:nth-child(3) span");
                dataForm.content("Average Appeal Length", "li:nth-child(4) span");
            }
    );



}