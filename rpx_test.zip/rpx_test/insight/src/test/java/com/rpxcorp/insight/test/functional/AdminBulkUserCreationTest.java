package com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.AccountActivationPage;
import com.rpxcorp.insight.page.LoginPage.ROLES;
import com.rpxcorp.insight.page.account.AdminBulkUserCreatePage;
import com.rpxcorp.insight.page.account.UsersPage;
import com.rpxcorp.oldtest.util.EmailApiUtil;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.util.ConfigUtil;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
@Authenticate(role = "ADMIN")
public class AdminBulkUserCreationTest extends BaseFuncTest{
	AdminBulkUserCreatePage adminBulkUserCreatePage;
    AccountActivationPage accountActivationPage;
    UsersPage usersPage;
    String validFilePath=ConfigUtil.config().get("testResourcesDir") + "/test_data/bulk_user_sample.csv";    
    String email_id="bulk_user.ba6f4fe1@mailosaur.io";//Same email id mentioned in sample upload file

    @Test(priority=1,dataProvider="roles",groups="P3", description="Bulk User Creation | Verify user creation through Admin bulk user creation page | RPX-12142")
    public void checkBulkUserCreation(String role) throws Exception
    {	//cleanup Users Data
		to(adminBulkUserCreatePage);
    	deleteAndAddUserToWhiteList(email_id);
    	EmailApiUtil.deleteRecipientEmails(email_id);
    	adminBulkUserCreatePage.userRole.select(role);
    	if(role.equalsIgnoreCase("member") || role.equalsIgnoreCase("elite")) {
    		adminBulkUserCreatePage.userAccount.typeAndselect("Google LLC");
    	}
    	adminBulkUserCreatePage.upload_File.sendKeys(validFilePath);
    	adminBulkUserCreatePage.create_BulkUser_Btn.click();
    	at(usersPage);
    	assertTrue(usersPage.alertMessage.getText().contains("All users have been successfully created"),"All users have been successfully created -- msg is not displayed after successful upload");
    	usersPage.searchUserByEmail(email_id);
    	assertTrue(usersPage.getUserRoleFromResultsTable().equalsIgnoreCase(role),"Expected:"+role+",Actual:"+usersPage.getUserRoleFromResultsTable());
    	to(homePage);
    	Thread.sleep(3000);
    	logout();
    	String activation_Link=EmailApiUtil.getLinkFromEmail(email_id, 0, 0);
    	getDriver().get(activation_Link);
    	at(accountActivationPage);
    	accountActivationPage.setPassword("Welcome@1");
    	at(homePage);
    	logout();
    	loginAs(ROLES.ADMIN);
    	to(adminBulkUserCreatePage);
    }
    
    @DataProvider(name="roles")
    public Object[][] getRoles() {
    	return new Object[][] {{"basic"},{"prime"},{"plus"},{"elite"},{"member"}};
    }
    
  }
