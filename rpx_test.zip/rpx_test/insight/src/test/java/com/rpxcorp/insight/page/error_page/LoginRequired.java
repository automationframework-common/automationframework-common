package com.rpxcorp.insight.page.error_page;

import org.openqa.selenium.By;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class LoginRequired extends BasePage {

	  @Override
	    public boolean at() {
	        pageTitle.waitUntilVisible();
	        content.waitUntilVisible();
	        login_Modal.waitUntilVisible();
	        return pageTitle.waitUntilTextPresent("Login Required");
	    }
	    
	    public final Element login_Modal=$("#login-modal #login_form");
	    public final Element content=$(By.xpath("//p[contains(text(),'The page you are trying to access is available only for logged in users. Please contact')]//a[@href='mailto:insight@rpxcorp.com']"));
}
