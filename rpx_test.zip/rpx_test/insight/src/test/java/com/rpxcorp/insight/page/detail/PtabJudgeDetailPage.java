package com.rpxcorp.insight.page.detail;

import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

public class PtabJudgeDetailPage extends BaseDetailPage{

    public PtabJudgeDetailPage() {
        this.url = new PageUrl("ptab/judges/{ID}");
    }

    public final Element title = $("h1.detail-page-title");
    public final Element ptabjudgeprofileSignOnMsg = $("img[src*='/assets/new_sankey']+div.subscription-promo-message-container-mask+div.subscription-promo-message:contains('Sign In')");
    public final Element ptabjudgeprofilePromoMsg = $("img[src*='/assets/new_sankey']+div.subscription-promo-message-container-mask+div.subscription-promo-message:contains('Start with a Free Trial')");

    public final StaticContent statsBarContent = $(".big-stats", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("active_petitions", "#litigations-active-cases .count");
                dataForm.content("inactive_petitions", "#litigations-inactive-cases .count");
                dataForm.content("average_cases_per_year", "div.columns:nth-child(3) .count");
                dataForm.content("average_length_of_case_in_days", "div.columns:nth-child(4) .count");
            }
    );

    public final Table petitionsTable = $("#litigations-container .venue_judge_case_table", (Configure<Table>) table ->
            {
                table.uniqueId("td.case_title a");
                table.nextPage("div#litigation-cases ul.pagination.pagination li:last-child");
                table.lastPage("div#litigation-cases ul.pagination.pagination li:nth-last-child(2)");
            }
    );

    public final Element activeLitigation = $(By.cssSelector("#active-case-type"));
    public final Element inactiveLitigation = $(By.cssSelector("#inactive-case-type"));
    public void click_active_filter_lits() {
        waitForPageLoad();
        if (!activeLitigation.isSelected()) {
            activeLitigation.click();
            waitForPageLoad();
        }
    }

    public void click_inactive_filter_lits() {
        waitForPageLoad();
        if (!inactiveLitigation.isSelected()) {
            inactiveLitigation.click();
            waitForPageLoad();
        }
    }
    public final Element sectionTitle = $(".block-header h5.section-title");
    public final Element panelTitle = $("div.panel.activity .section-title");
    public final Element recentActivityHeader = $("#litigations_section>h2");
    public final Element techCenterHeader= $(".petitions-by-tech-center .sector-title");
    public final Element marketSectorLink=$(".bar-graph li:nth-child(1) a[href^='/tech_center/']");
    public final Table cases_By_Market_Sector = $("ul.bar-graph", (Configure<Table>) table ->
            {
                table.uniqueId("div.graph-label");
                table.column("count", " .graph-count ");
            }
    );

}
