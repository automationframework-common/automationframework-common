package com.rpxcorp.insight.test.data;

import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.rpxcorp.insight.page.intelligence.MarketPlacePage;
@Authenticate(role = "MEMBER")
public class MarketPlaceTest extends BaseDataTest {
    MarketPlacePage marketPlacePage;

    @BeforeClass
    public void navigateIPRPage() {
        this.dataDescription = "Market Place Page";
        this.dataUrl = marketPlacePage.getDeclaredUrl();
        to(marketPlacePage);
    }

    @Test(description = "Verify Recent Activity Table Data", priority = 2)
    public void Recent_Activity_Table_Data() throws Exception {
        assertEquals(marketPlacePage.recent_activity_table.getData(),
                sqlProcessor.getResultData("Intelligence.MARKET_PLACE_RECENT_ACTIVITY"));
    }

}
