package com.rpxcorp.insight.page.search;

import com.rpxcorp.insight.module.Facet;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;

public class PortfolioSearchPage extends BasePage {

    public PortfolioSearchPage() {
        this.url = new PageUrl("advanced_search/search_portfolios") {
            {
                param("CURRENT SEARCH", "searchq");
                param("CURRENT_ASSIGNEE", "current_assignee[]");
                param("ORIGINAL_ASSIGNEE", "original_assignee[]");
                param("RPX OWNERSHIP RIGHTS", "deal_rpx_rights[]");
                param("APPLICATION STATUS", "application_status[]");
                param("PRIMARY MARKET SECTOR", "deal_primary_market_sector[]");
                param("TECHNOLOGY AREA", "tech_tags[]");
                param("ACQUISITION TYPE", "deal_acquisition_type[]");
                param("LITIGATED", "is_litigated[]");
                param("PATENT FILING FROM DATE", "from_filing_date");
                param("PATENT FILING TO DATE", "to_filing_date");
                param("PRIORITY FROM DATE", "from_priority_date");
                param("PRIORITY TO DATE", "to_priority_date");
                param("PATENT ISSUE FROM DATE", "from_pf_grant_date");
                param("PATENT ISSUE TO DATE", "to_pf_grant_date");
                param("RPX ACQUISITION FROM DATE", "from_deal_acquisition_date");
                param("RPX ACQUISITION TO DATE", "to_deal_acquisition_date");
            }
        };
    }

    @Override
    public boolean at() {
        waitForPageLoad();
        return portfolioDownloadButton.waitUntilVisible();
    }

    /* CONTENT OF PORTFOLIO SEARCH PAGE * */
    public final Facet litigated_facet = new Facet("div#sidebar form.advanced_search_refine section.filters:has(div:contains('Litigated'))");
    public final Facet portfolioRights_facet = new Facet("div#sidebar form.advanced_search_refine section.filters:has(div:contains('Applicable Patent License Restrictions'))");
    public final Facet current_search = new Facet("section.filters:nth-of-type(1)");
    public final Element currentSearch = $("#searchq_revised");
    public final Element patents_count = $("h2#result-title>span.count:nth-child(1)");
    public final Element portfolios_count = $("div#search_results_replaced_content .metrics_card a:contains(Portfolio) .count");

    public final Table search_result = $(".search-results table.results", (Configure<Table>) table ->
        {
            table.column("Porttfolio Name", "tr a.title");
            table.column("Assets", ".group_stats td:nth-child(3)");
            table.column("Patents", ".result-count");
        }
    );
    public final Element portfolioDownloadButton = $(".search-portfolio a.data_download_btn:contains('Download')");
    public final Element portfolioGroupedSearchResults= $(".grouped_results .asset-title");
}
