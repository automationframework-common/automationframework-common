package com.rpxcorp.insight.page.error_page;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class PatentWithdrawnPage extends BasePage {

    @Override
    public boolean at() {
        pageTitle.waitUntilVisible();
        patentWithdrawn_msg.waitUntilTextPresent("The patent you are searching for has been withdrawn from the USPTO.");
        return pageTitle.waitUntilTextPresent("Patent Withdrawn");
    }
    
    public final Element patentWithdrawn_msg=$(".panel p");
}
