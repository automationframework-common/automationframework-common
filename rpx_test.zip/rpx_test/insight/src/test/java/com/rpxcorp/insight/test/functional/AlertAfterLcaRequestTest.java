package com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.detail.AlertsSubscriptionPage;
import com.rpxcorp.insight.page.detail.BaseDetailPage;
import com.rpxcorp.insight.page.detail.CampaignDetailPage;
import com.rpxcorp.insight.page.detail.EntityDetailPage;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.ExcelUtil;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;

public class AlertAfterLcaRequestTest extends BaseFuncTest {

	BaseDetailPage detailPage;
	AlertsSubscriptionPage alertsSubscriptionPage;
	CampaignDetailPage campaignPage; 
	EntityDetailPage entity;
	private ExcelUtil userData = new ExcelUtil(ConfigUtil.config().get("testResourcesDir") + "/test_data/TestDataForApp.xls");


	@BeforeClass
	public void createUserAndLogin() throws Exception {
		to(loginPage);
		asAdminCreateUserAndLoginUI(userData.getDataAsMap("User Data", 1, 11));
	}

	@Test(priority = 1, dataProvider = "noAlertData", groups = "P3", description = "Verify New Alert created with LCA option after LCA request")
	public void verifyNewLCAAlertAfterRequest(String pageId, String type) throws Exception {
		this.urlData.put("ID", pageId);
		to(campaignPage, urlData);
		requestLCA(type);
		assertLcaAlert();
	}
	@DataProvider
	public Object[][] noAlertData() {
		return new Object[][] {
				{ "36071", "single_lca_update" },
				{ "15175", "multiple_lca_update" }
		};
	}

	@Test(priority = 2, dataProvider = "existingAlertWithoutLCAData", groups = "P3", description = "Verify that for users without LCA option in alert, lca is selected after lca request")
	public void verifyExistingAlertWithoutLCAAfterLCARequest(String pageId, String type, 
			String caseEvent, String ptabEvent, String itcEvent, String reportEvent, String freq) throws Exception {
		this.urlData.put("ID", pageId);
		to(entity, urlData);
		createAlert(caseEvent, ptabEvent, itcEvent, reportEvent, freq);
		requestLCA(type);
		entity.closeLCAModal();
		assertLcaAlert(caseEvent, ptabEvent, itcEvent, freq);
	}
	@DataProvider
	public Object[][] existingAlertWithoutLCAData() {
		return new Object[][] {
				{ "51381", "new_request", "Defendant Added", "", "", "", "daily" },
				{ "81005", "single_lca_update_ent_with_many_campaigns", "Case Closed", "", "", "", "weekly" },
				{ "75584", "multiple_lca_update", "Plaintiff Terminated", "", "", "", "hourly" }
		};
	}

	@Test(priority = 3, dataProvider = "existingAlertWithLCAData", groups = "P3", description = "Verify that for users with LCA option in alert, no change in alerts after LCA request")
	public void verifyExistingAlertWithLCAAfterLCARequest(String pageId, String type, 
			String caseEvent, String ptabEvent, String itcEvent, String reportEvent, String freq) throws Exception {
		this.urlData.put("ID", pageId);
		to(entity, urlData);

		createAlert(caseEvent, ptabEvent, itcEvent, reportEvent, freq);
		requestLCA(type);
		entity.closeLCAModal();
		assertLcaAlert(caseEvent, ptabEvent, itcEvent, freq);
	}
	@DataProvider
	public Object[][] existingAlertWithLCAData() {
		return new Object[][] {
				{ "57953", "new_request", "Defendant Added", "", "", "Litigation Campaign Assessment Added", "daily" },
				{ "429019", "single_lca_update_ent_with_many_campaigns", "Case Closed", "", "", "Litigation Campaign Assessment Added", "weekly" },
				{ "86899", "multiple_lca_update", "Plaintiff Terminated", "", "", "Litigation Campaign Assessment Added", "hourly" }
		};
	}

	public void requestLCA(String type) {
		if(type.contains("multiple"))
			requestFromMultipleLCAs();
		else if(type.contains("_ent_with_many_campaigns")) {
			detailPage.clickAndHoldLcaButton();
			detailPage.requestLca();
			detailPage.requestAnUpdateForFirstLca();
		}
		else
			requestLCA();
	}

	private void requestLCA() {
		detailPage.clickAndHoldLcaButton();
		detailPage.requestLca();
		detailPage.loading.waitUntilInvisible();
		detailPage.closeLcaRequestResponseModal();
	}

	private void requestFromMultipleLCAs() {
		detailPage.openLCAModal();
		detailPage.requestAnUpdateForFirstLca();
		detailPage.closeLCAModal();
	}

	private void createAlert(String caseEvent, String ptabEvent, String itcEvent, String reportEvent, String frequency) {
		detailPage.accessCreateAlert();
		at(alertsSubscriptionPage);

		alertsSubscriptionPage.selectNoneEvent();        
		alertsSubscriptionPage.selectNonePtabEvent();
		alertsSubscriptionPage.selectNoneItcEvent();
		alertsSubscriptionPage.selectNoneRpxReportsEvent();

		alertsSubscriptionPage.caseEventsCheckList.selectInTableFormat(caseEvent);
		alertsSubscriptionPage.ptabEventsCheckList.selectInTableFormat(ptabEvent);
		alertsSubscriptionPage.itcEventsCheckList.selectInTableFormat(itcEvent);
		alertsSubscriptionPage.rpxReportsEventsCheckList.selectInTableFormat(reportEvent);
		alertsSubscriptionPage.frequencyRadio.selectValue(frequency);

		alertsSubscriptionPage.createAlert();
	}

	private void assertLcaAlert() throws Exception {		
		detailPage.refresh();
		detailPage.accessModifyAlert();
		at(alertsSubscriptionPage);
		assertEquals(alertsSubscriptionPage.caseEventsCheckList.getSelectedField(), java.util.Collections.emptyList(), "Litigation events list not expected");	
		assertEquals(alertsSubscriptionPage.ptabEventsCheckList.getSelectedField(), java.util.Collections.emptyList(), "PTAB events list not expected");
		assertEquals(alertsSubscriptionPage.itcEventsCheckList.getSelectedField(), java.util.Collections.emptyList(), "ITC events list not expected");
		assertEquals(alertsSubscriptionPage.rpxReportsEventsCheckList.getSelectedTableField().get(0), "Litigation Campaign Assessment Added", "RPX Reports events list not expected");
		assertEquals(alertsSubscriptionPage.frequencyRadio.getSelectedField().replace("\n",""), "Hourly", "Frequency is not expected");
		detailPage.closeAlertDialog();
	}

	private void assertLcaAlert(String expCaseEvent, String expPtabEvent, String expItcEvent, String expFreq) throws Exception {		
		detailPage.refresh();
		detailPage.accessModifyAlert();
		at(alertsSubscriptionPage);

		String expFreqForAssert = "";
		switch (expFreq) {
		case "daily":
			expFreqForAssert = "Daily (M-F)";
			break;
		case "weekly":
			expFreqForAssert = "Weekly";
			break;
		case "hourly":
			expFreqForAssert = "Hourly";
			break;
		}

		assertEquals(alertsSubscriptionPage.caseEventsCheckList.getSelectedTableField(), new ArrayList<String>(Arrays.asList(expCaseEvent.split(","))), "Litigation events list not expected");
		assertEquals(alertsSubscriptionPage.ptabEventsCheckList.getSelectedTableField(), java.util.Collections.emptyList(), "PTAB events list not expected");
		assertEquals(alertsSubscriptionPage.itcEventsCheckList.getSelectedTableField(), java.util.Collections.emptyList(), "ITC events list not expected");
		assertEquals(alertsSubscriptionPage.rpxReportsEventsCheckList.getSelectedTableField().get(0), "Litigation Campaign Assessment Added", "RPX Reports events list not expected");
		assertEquals(alertsSubscriptionPage.frequencyRadio.getSelectedField().replace("\n",""), expFreqForAssert, "Frequency is not expected");
		detailPage.closeAlertDialog();
	}
}
