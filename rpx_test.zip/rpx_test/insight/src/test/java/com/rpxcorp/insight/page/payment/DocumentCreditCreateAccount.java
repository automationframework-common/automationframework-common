package com.rpxcorp.insight.page.payment;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class DocumentCreditCreateAccount extends BasePage {

    public DocumentCreditCreateAccount() {
        this.url = new PageUrl("payments/user_details");
    }

    @Override
    public boolean at() {
        return signUpPanel.waitUntilVisible();
    }

    public final Element signUpPanel = $(".payment_registration");

    // SIGN UP DETAILS
    public final Element firstName = $("#user_first_name");
    public final Element lastName = $("#user_last_name");
    public final Element email = $("#user_email");
    public final Element password = $("#user_password");
    public final Element confirmPassword = $("#user_password_confirmation");

    public final Element continueBtn = $("#signup-btn");

    public void enterSignUpInformation(String fName, String lName, String mailId, String pwd) {
        firstName.sendKeys(fName);
        lastName.sendKeys(lName);
        email.sendKeys(mailId);
        password.sendKeys(pwd);
        confirmPassword.sendKeys(pwd);
    }

    public final Element loginHereLink = $(".payment_registration a#payment_login_btn");
    public final Element termsOfService = $(".signup-company a");
}
