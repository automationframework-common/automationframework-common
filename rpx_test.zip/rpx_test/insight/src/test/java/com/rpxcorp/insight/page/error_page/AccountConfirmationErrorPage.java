package com.rpxcorp.insight.page.error_page;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class AccountConfirmationErrorPage extends BasePage {

    public AccountConfirmationErrorPage() {
        this.url = new PageUrl("users/confirmation"){{
            param("TOKEN_ID","confirmation_token");
        }};

    }

    @Override
    public boolean at() {
        return confirmationErrorMessage.waitUntilVisible();
    }

    public final Element confirmationErrorMessage = $("#error_explanation li");
    public final Element resendConfirmationMail = $(".button[value='Resend confirmation instructions']");
    public final Element resendEmail = $("#user_email");
}
