package com.rpxcorp.insight.page.error_page;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class PageNotFoundPage extends BasePage {

    public final Element errorMessage = $(".panel>p");
    public final Element logo = $("#logo");
    public final Element rpxCorporationSiteLink = $(".nav .dropdown>ul>li");

    @Override
    public boolean at() {
    	logo.waitUntilVisible();
        return assertPageTitle("Page Not Found");
    }

}
