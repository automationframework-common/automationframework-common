package com.rpxcorp.insight.page.detail;

import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import java.util.List;

public class ChinesePatentDetailPage extends BaseDetailPage {

    public ChinesePatentDetailPage() {
        this.url = new PageUrl("/patent/cn/{ID}");
    }

    @Override
    public boolean at() {
        waitForPageLoad();
        waitForLoading();
        return detailPageTitle.waitUntilVisible();
    }

    /* CONTENT OF PATENT DETAIL PAGE * */
    public final Element claim_header = $("div#claims div.handle");
    public final Element rpxPortfolio = $(".presenter-name-cls a[href='#patent_portfolio']");
    public final Element rpxPortfolioTooltip = $(".presenter-name-cls span[title='This patent is part of an RPX Portfolio']");
    public final Element patentTitleWithoutCallouts = $("h1.presenter-name-cls>span:not([class])");
    public final StaticContent header_info = $(".header-info.details", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("patent_number", "li:nth-child(1)");
                dataForm.content("filed_date", "li:contains(Filed)");
                dataForm.content("issued_date", "li:contains(Issued)");
                dataForm.content("priority_date", "li:contains(Est. Priority Date)");
            }
    );
    public final Element patent_download = $("i[title='Download Patent']");
    public final Element reexaminationCertificate = $(".header-info.details .reexam-icon:visible");

    public final Element no_petitions = $(".group.active.clear_styling.ptab_cases_section .table-margin span");
    public final StaticContent overview_panel = $(".panel-metrics", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("associated_case", "div.metrics_card:contains(Associated Cases) .count");
                dataForm.content("associated_defendants", "div.metrics_card:contains(Associated Defendants) .count");
                dataForm.content("forward_citations", "div.metrics_card:contains(PRB Reexaminations) .count");
                dataForm.content("reexaminations", "div.metrics_card:contains(Forward Citations) .count");
            }
    );
    public final Element accusedProductTitle = $("#accused_products>div>h2");
    public final Element login_share_link_btn = $("a[title='Login Share Link']");
    // TODO replace below xpath to jquery selector implementation
    public final Element assignmentTitle = $(".assignment-metrics span");
    public final Element claimTitle = $(By.xpath("//div[@id='claims']//../../div/h2"));
    public final Element first_claim_title = $(By.xpath("//h2[contains(text(),'First Claim')]"));
    public final Element first_claimText = $(".claim-text>p");
    public final Element patent_frontPage_img = $("img.patent-frontpage");
    public final Element viewImages_btn = $(".claim-placeholder.button");
    public final Element imagesContainer = $(".clearing-container");
    public final Element claimImages = $(".carousel ul.block-grid li.clearing-feature a");
    public final Element viewAllClaims = $(".first-claim-section .view-all.jump");
    public final Element closeImagesContainer = $(".clearing-container a.clearing-close");

    //PATENT INFO
    public final Element currentAssignee = $("div.ownership li.en_toggle div.status:contains('Current Assignee')+a.patent_entity_link");
    public final Element sponsoringEntity = $(".ownership li:nth-child(2) a");
    public final Element inventors = $(".ownership li:nth-child(3) a");
    public final Element primaryExaminers = $(".ownership li:nth-child(4) a");
    public final Element assistantExaminers = $(".ownership li:nth-child(5) a");
    public final Element grantedPatentValue = $(By.xpath("//*[contains(text(),'GRANTED PATENT')]/../div/a"));
    public final Element grantedApplicationValue = $(By.xpath("//*[contains(text(),'APPLICATION')]/../div/a"));

    public final StaticContent patentCodesInformation = $(".codes", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("patent", "li:contains(GRANTED PATENT) div a");
                dataForm.content("application", "li:contains(APPLICATION) div a");
            }
    );

    public final Element assigmentTabLink = $(By.xpath("//*[contains(text(),'Assignment View')]"));
    public void selectAssignmentViewTab() {
        waitForLoading();
        if (assigmentTabLink.isDisplayed()) {
            assigmentTabLink.click();
            waitForPageLoad();
        }
    }

    public final Element showAssetsLink = $("#patent-assignments-chart a[title='Show Assets']");

    public void openAssetsList() {
        if (showAssetsLink.isDisplayed())
            showAssetsLink.click();
        loadingAssetSymbol.waitUntilInvisible();
        //assetInfo.waitUntilTextPresent(assetInfo.getData("patent"));
        patentValue.waitUntilVisible();
    }

    public final Element realted_campaigns = $("#patent-assignments-chart .assignment-info>div div[class*='row']:nth-of-type(3)");
    public final Table assignmentInfo = $("#patent-assignments-chart", (Configure<Table>) table ->
            {
                table.nextPage(".pagination li:nth-last-child(2)");
                table.viewAllLink("//*[@id='patent-assignments-chart']//a[@title='view all assignments']");
                table.viewLessLink("//*[@id='patent-assignments-chart']//a[@title='hide few assignments']");
                table.displayedRecords("#patent-assignments-chart .assignment-tooltip-content");
                table.uniqueId("span[class='label-info'] a");
                table.column("executed_date", ".header-info .row div:nth-of-type(1) span:nth-of-type(2)");
                table.column("recorded_date", " .header-info .row div:nth-of-type(2) span:nth-of-type(2)");
                table.column("reel_frame", " .header-info .row div:nth-of-type(3) span[class='label-info'] a");
                table.column("conveyance", " .header-title");
                table.column("assignee", " .assignment-info .right a");
                table.column("assignors", " .assignment-info .left>div>div");
                table.column("correspondents", ".assignment-info span[class='label-info'] span");
                table.subTable($(".patent-list", (Configure<Table>) subTable ->
                {
                    subTable.uniqueId(".ui-grid-row div[class*='ui-grid-cell']:nth-of-type(1) a");
                    subTable.column("patent", ".ui-grid-row div[data-col-name='patnum'] a");
                    subTable.column("title", ".ui-grid-row div:nth-of-type(2) div[class*='ng-binding']");
                    subTable.column("priority_date", ".ui-grid-row div:nth-of-type(3) div[class*='ng-binding']");
                }));
                table.expandSubTableLink("a[title='Show Assets']");
            }
    );

    public final Element patentValue = $("#patent-assignments-chart .ui-grid-row div[data-col-name='patnum'] a");
    public final Table assetInfo = $("#patent-assignments-chart", (Configure<Table>) table ->
            {
                table.nextPage(".pagination li:nth-last-child(2)");
                table.viewAllLink("//*[@id='patent-assignments-chart']//a[@title='view all assignments']");
                table.viewLessLink("//*[@id='patent-assignments-chart']//a[@title='hide few assignments']");
                table.displayedRecords("#patent-assignments-chart .assignment-tooltip-content");
                table.uniqueId(".header-info .row div:nth-of-type(3) span[class='label-info'] a;.ui-grid-row div[class*='ui-grid-cell']:nth-of-type(1) a");
                table.column("patent", ".ui-grid-row div[data-col-name='patnum'] a");
                table.column("title", ".ui-grid-row div:nth-of-type(2) div[class*='ng-binding']");
                table.column("priority_date", ".ui-grid-row div:nth-of-type(3) div[class*='ng-binding']");
            }
    );

    public final Element loadingAssetSymbol = $("fa fa-refresh fa-spin rpx-icon");
    /*public final StaticContent assetInfo = $("#patent-assignments-chart", (Configure<StaticContent>) dataForm ->
	    {
	    	dataForm.content("unique_id", ".ui-grid-row div[class*='ui-grid-cell']:nth-of-type(1) a");
	    	dataForm.content("patent", ".ui-grid-row div[data-col-name='patnum'] a");
	    	dataForm.content("title", ".ui-grid-row div:nth-of-type(2) div[class*='ng-binding']");
	    	dataForm.content("priority_date", ".ui-grid-row div:nth-of-type(3) div[class*='ng-binding']");
	    }
   );*/

    //FAMILY MEMBERS
    public final Element familyMembers_title = $(".family-members h2");
    public final Element familyMembers = $(".family-members", (Configure<Table>) table ->
            {
                table.viewAllLink(".family-members .view-all-entries");
                table.uniqueId("a.lit_doc");
                table.column("patent_number", ".secondary li:nth-child(1)");
                table.column("title", " .lit_doc");
                table.column("current_assignee", " .tertiary li:nth-child(1) ");
                table.column("sponsoring_entity", " .tertiary li:nth-child(2) ");
                table.column("issued_date", ".secondary li:nth-child(2)");

            }
    );
    public final Element familyMembers_patentLink = $("li.family-member:nth-child(1) a.lit_doc");
    public final Element familyMembers_currentAssigneeLink = $(".tertiary>li:first-child a");
    public final Element familyMembers_sponsoringEntLink = $(".tertiary>li:last-child a");

    public final Element forward_citations_TabLink = $("#citations a[href='#forward_citations']");
    public final Element reference_cited_TabLink = $("#citations a[href='#references_cited']");
    public final Element reference_cited_Table = $("#references_cited a.lit_doc");
    public final Element associated_defendants_TabLink = $("#litigations a[href='#litigations-container-content']");

    public final Element citiations_table = $("#citations div.active.content", (Configure<Table>) table ->
            {
                table.uniqueId("a.lit_doc");
                table.column("filed_date", ".file-date");
                table.column("current_assignee", "td:nth-child(2)");
                table.column("sponsoring_entity", "td:nth-child(3)");
                table.column("patent_number", "a.lit_doc");
                table.viewAllLink(By.xpath("//div[@id='references_cited']//a[contains(text(),'View All')]"));
                table.viewLessLink(By.xpath("//div[@id='references_cited']//a[contains(text(),'View Less')]"));
                table.displayedRecords("#references_cited>table, #forward_citations>div:not([style*='none'])>table");
            }
    );

    public final Table forward_citations = $("#forward_citations tr[class='content']", (Configure<Table>) table ->
            {
                table.viewAllLink(By.xpath("//div[@id='forward_citations']//a[contains(text(),'View All')]"));
                table.viewLessLink(By.xpath("//div[@id='forward_citations']//a[contains(text(),'View Less')]"));
                table.displayedRecords("#forward_citations>table, #forward_citations>div:not([style*='none'])>table");
                table.column("current_assignee", "#forward_citations td:nth-child(2)");
                table.column("sponsoring_entity", "#forward_citations td:nth-child(3)");
                table.column("patent_number", "#forward_citations td:nth-of-type(1) a");
            }
    );
    public final Element citations_viewAsSearch = $("#citations_outer .view-as-search");
    public final Table references_cited = $("#references_cited tr[class='content']", (Configure<Table>) table ->
            {
                table.viewAllLink(By.xpath("//div[@id='references_cited']//a[contains(text(),'View All')]"));
                table.viewLessLink(By.xpath("//div[@id='references_cited']//a[contains(text(),'View Less')]"));
                table.displayedRecords("#references_cited>table, #references_cited>div:not([style*='none'])>table");
                table.column("current_assignee", "#references_cited td:nth-child(2)");
                table.column("sponsoring_entity", "#references_cited td:nth-child(3)");
                table.column("patent_number", "#references_cited tr.content td:nth-of-type(1)");
            }
    );
    public final Element claims = $("#claims");
    public final Element claimData = $(".claims ul li");
    public final Element claims_title = $(By.xpath("//h2[contains(text(),'Claims')]"));
    public final Element independent_claims = $(".panel.claims ul.claim.independent");
    public final Element viewDependantClaims = $(By.xpath("//span[contains(text(),'View Dependent Claims')]/.."));
    public final Element hideDependantClaims = $(By.xpath("//span[contains(text(),'Hide Dependent Claims')]/.."));
    public final Element hiddenDependantClaims = $("ul[class*='dependant hidden']:not([class*='expanded'])>li");
    public final Element expandedDependantClaims = $(".dependant.hidden.expanded>li");

    public final Element downloadPatentLink = $(".header-info.details a");

    public String getPatentLink() {
        String[] url = downloadPatentLink.getAttribute("href").split("/");
        System.out.println("url: " + url[4].toString());
        return url[4];
    }

    public final Element petition_title = $("#petitions>div>h2");
    public final Table petition_table = $("#patent_ptab_cases table", (Configure<Table>) table ->
            {
                table.viewAllLink("#patent_ptab_cases a.view-all");
                table.uniqueId("td:nth-child(3) a[href]");
                table.viewAllLink(By.xpath("//*[@id='patent_ptab_cases']//a[contains(text(),'View All')]"));
                table.viewLessLink(By.xpath("//*[@id='patent_ptab_cases']//a[contains(text(),'View Less')]"));
                table.displayedRecords("#patent_ptab_cases tbody tr:not([style*='none'])");
            }
    );
    public final Element petition_viewAsSearch = $(".ptab_cases_section .view-as-search i");

    public final Element caseViewInLitigations = $("div.pat-lits-section .icon-cross:visible");
    public final Element campaignViewInLitigations = $(".icon-briefcase");
    public final Table litigation_table = $("li#litigations-container-content table.lit_campaigns_table", (Configure<Table>) table ->
            {
                table.viewAllLink("#litigations-container-content a.view-all");
                table.uniqueId("td:nth-child(3) a[href]");
            }
    );

    public final Table multipleReexamCertificate = $("#reexamination_modal", (Configure<Table>) table ->
            {
                table.uniqueId("tbody>tr td:nth-child(1)");

            }
    );


    public final Table rpxPortfolio_table = $("div#patent_portfolio table", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(1) a[href]");
                table.viewAllLink("#litigations-container-content a.view-all");
            }
    );

    public final StaticContent campView_recentCase = $("#litigations-container-content table", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("itc_recentCase", "td:nth-child(4)>a[href^='/itc/']");
                dataForm.content("fc_recentCase", "td:nth-child(4)>a[href^='/fed_c/']");
                dataForm.content("lit_recentCase", "td:nth-child(4)>a[href^='/lit/']");
            }
    );


    //AUTHORIZATION
    public final Element litigation_promo_msg = $("img[src*='/assets/patent_litigation_campaign']+div.subscription-promo-message-container-mask+div.subscription-promo-message:contains('Start with a Free Trial')");
    public final Element litigation_non_camp_table = $("#litigations-container-content table", (Configure<Table>) table ->
            {
                table.viewAllLink("#litigations-container-content a.view-all");
                table.uniqueId("td:nth-child(2) a[href]");
            }
    );
    public final Element litDefendantTabLink = $("#litigation-cases [data-lit-type=defendant] a");

    //LIT CAMP - NON-CAMP VIEW - DEFENDANT TAB
    public final Element defendantTableSearch = $("#defendants-container-content .dataTables_filter> label >input");
    public final Table defendant_non_camp_table = $(".table-expand.clickable-rows", (Configure<Table>) table ->
            {
                table.uniqueId("td.defendant_parent a");
                table.viewAllLink("#defendants-container-content a.view-all");
                table.viewLessLink(By.xpath("//li[@id='defendants-container-content']//a[text()='View Less']"));
                table.row("table.table-expand.clickable-rows tbody>tr.group-item[role='row']");
                table.subTable($(".nested_inner_table", (Configure<Table>) subTable ->
                {
                    subTable.uniqueId("td:nth-child(3) a[href]");
                }));
                table.expandSubTableLink(".open.cursor-pointer");
                table.displayedRecords("#defendants-container-content table tbody tr:not([style*='none'])");
            }
    );

    public final Element def_nonCampView_defParentLink = $(".defendant_parent a");
    //"#defendants-container-content table tbody tr td:nth-of-type(1)");
    public final Element def_nonCampView_defLink = $("td>a[title*='Mengzi']");
    //"#defendants-container-content table tbody tr td:nth-of-type(2)");
    //public final Element def_nonCampView_recentCase = $("#defendants-container-content td>a[href*='/lit/txedce']");
    //"#defendants-container-content table tbody tr td:nth-of-type(3)");

    public final StaticContent def_nonCampView_recentCase = $("#defendants-container-content table", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("itc_recentCase", "td:nth-child(3)>a[href^='/itc/']");
                dataForm.content("fc_recentCase", "td:nth-child(3)>a[href^='/fed_c/']");
                dataForm.content("lit_recentCase", "td:nth-child(3)>a[href^='/lit/']");
            }
    );


    public void defendantSearch(String searchTerm) {
        defendantTableSearch.clear();
        defendantTableSearch.sendKeys(searchTerm);
        waitForLoading();
    }

    public final Element noSearchResults = $("#defendants-container-content .dataTables_empty");
    public final Element def_nonCampView_subTable_caseNameLink = $(".nested_inner_table tbody tr td:nth-of-type(3)");
    public final Element def_nonCampView_subTable_caseNoLink = $(".nested_inner_table tbody tr td:nth-of-type(4)");

    public final Table assignments = $(".assignments", (Configure<Table>) table ->
            {
                table.uniqueId("td span:contains(Reel) a[href]");
                table.column("recorded_date", "td>span:contains(Recorded)");
                table.column("executed_date", "td>span:contains(Executed)");
                table.column("reel_frame", "td>span:contains(Reel)");
                table.column("assignors", "td:has(div.status:contains(Assignors))");
                table.column("assignee", "td:has(div.status:contains(Assignee))");
                table.column("conveyance", "td:has(div.status:contains(Conveyance))");
                table.column("correspondents", "td.correspondents");
                table.viewAllLink(By.xpath("//div[@class='panel assignments']//a[contains(text(),'View All')]"));
                table.viewLessLink(By.xpath("//div[@class='panel assignments']//a[contains(text(),'View Less')]"));
                table.displayedRecords("#assignments div:not([style*='none'])>div.table-expand table");
                table.hiddenRecords(".assignments>div[style*='none']>table");
            }
    );
    public final Element reelFramePdfLink = $("a[title='Download the patent assignment']:visible");

    public String getHrefFromreelFramePdf() {
        String href = "";
        if (reelFramePdfLink.isDisplayed()) {
            return reelFramePdfLink.getAttribute("href");
        }
        return href;
    }

    public Element assignmentCount = $("#assignments div.handle h2");
    //public final Element assignmentTable = $("#assignments .content");
    public final Element reelFrameLink = $("div.assignment-tooltip-content span.label-info a");

   /* public String getReelFrameValue() {
        if (assignmentTable.isDisplayed() && reelFrameLink.isDisplayed())
            return reelFrameLink.getText();
        else
            return "";
    }*/

    public final Table reelFrameTable = $(".assignment_reel_frame table", (Configure<Table>) table ->
            {
                table.uniqueId("td>a");
            }
    );
    public final Element reelFrameClose = $("#async_modal .close-reveal-modal");
    public final Element totalAssetsCount = $(".assignment_reel_frame .right li:last-child");

    public void openReelFrame() {
        if (assignmentInfo.isDisplayed()) {
            reelFrameLink.click();
            waitForLoading();
            totalAssetsCount.waitUntilVisible();
        }
    }

    public void closeReelFrame() {
        if (reelFrameClose.isDisplayed()) {
            reelFrameClose.click();
            reelFrameTable.waitUntilInvisible();
        }
    }

    public final Element reelFrameModal_div = $(".patent_assignment");

    public String getReelFrameData() {
        reelFrameModal_div.waitUntilVisible();
        return reelFrameModal_div.getText();
    }

    public final Element assignments_title = $(By.xpath("//h2[contains(text(),'Assignment')]"));
    public final Element assignors_link = $(".assignment-tooltip-content .assignment-info-content span[ng-repeat*='.assignor_details'] a");
    public final Element assignee_link = $(".assignment-tooltip-content .assignment-info-content span[ng-repeat*='.assignee_details'] a");
    public final Element abstract_title = $(By.xpath("//h2[contains(text(),'Abstract')]"));
    public final Element abstract_content = $(By.xpath("//h2[contains(text(),'Abstract')]/../..//div//p"));
    public final Element assignmentsReelFrameLink = $(".assignments a[data-behavior='async_modal']");
    public final Table assignmentsReelFrame = new Table(".assignment_reel_frame>table");
    public final Element campaignview_button = $("a[data-behavior='entity_lits_campaign_toggle']");
    public final Element all_button = $(By.id("all-case-type"));
    public final Element active_button = $(By.id("active-case-type"));
    public final Element inactive_button = $(By.id("inactive-case-type"));
    public final Element timelineComponent = $(".timeline_setter");
    public final Element priorArtReport = $("[data-behavior='prior_art_report_gtm']");
    public final Element timeLineYear = $(".TS-notchbar_container .TS-year_notch");
    public final Element specification_title = $(By.xpath("//h2[contains(text(),'Specification')]"));
    public final Table specifications = $("#patent-specfications", (Configure<Table>) table ->
            {
                table.viewAllLink(By.xpath("//*[@class='panel specification']//a[text()='View All']"));
                table.viewLessLink(By.xpath("//*[@class='panel specification']//a[text()='View Less']"));
            }
    );

    // AUTHORIZATION
    public final Element defendantLinkInLitCampaign = $(
            "#litigation-cases a[data-behavior='async_modal prevent_click_propagation']");
    public final Element defendantModal = $("#async_modal table");
    public final Element itcMostRecentCaseMasked = $(By
            .xpath("//table[contains(@class,'campaign_defendants_table')]//tbody/tr[1]/td[3]//a[text()='337-TA-000']"));
    public final Element itcMostRecentCase = $(By.xpath(
            "//table[contains(@class,'campaign_defendants_table')]//tbody/tr[1]/td[3]//a[not(text()='337-TA-000')]"));
    public final Element firstSubtableOpen = $("tr:nth-of-type(1) .open.cursor-pointer");
    public final Element firstSubtableClose = $("tr:nth-of-type(1) .close.cursor-pointer");
    public final Element defSubtableItcDateFiledEmpty = $("table.nested_inner_table tbody>tr:nth-of-type(1)>td:nth-child(2):empty"); //$(By.xpath("//*[@id='async_modal']//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[1][not(text())]"));
    public final Element defSubtableItcCaseName_Login = $(By.xpath(
            "//*[@id='async_modal']//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[2][text()='Please login to view.']"));
    public final Element defSubtableItcCaseName_Masking = $("table.nested_inner_table tbody>tr:nth-of-type(1)>td:nth-child(3):contains('ITC access not available')>a:contains(Learn More)"); //$(By.xpath("//*[@id='async_modal']//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[2][contains(text(),'ITC access not available')]/a[text()='Learn More']"));
    public final Element defSubtableItcCaseNoMasked = $("table.nested_inner_table tbody>tr:nth-of-type(1)>td:nth-child(4)>a:contains(337-TA-000)"); //$(By.xpath("//*[@id='async_modal']//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[3]/a[text()='337-TA-000']"));
    public final Element defSubtableItcCaseNo = $(By.xpath("//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[4]/a[not(text()='337-TA-000')]")); //$(By.xpath("//*[@id='async_modal']//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[3]/a[not(text()='337-TA-000')]"));
    public final Element defSubtableItcTermDateEmpty = $("table.nested_inner_table tbody>tr:nth-of-type(1)>td:nth-child(5):empty"); //$(By.xpath("//*[@id='async_modal']//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[4][not(text())]"));
    public final Element defSubtableItcCaseNameLink = $("table.nested_inner_table tbody>tr:nth-of-type(1)>td:nth-child(3):has(a.case_details)"); //$(By.xpath("//*[@id='async_modal']//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[2]/a[contains(@href,'/itc/')]"));

    public final Element litigations_pc_signIn = $("div#litigations-container div.subscription-promo-message a:contains('Sign In')");
    /* public final Element litigations_pc_signIn_without_FF = $(By.xpath(
             "//h2[contains(text(),'Litigation')]/../following-sibling::div//a[contains(text(),'sign in')]"));*/
    public final Element litigations_pc = $(".pat-lits-section .promotional_content a[href*='mailto']");
    public final Element maskedCampNameInCampViewOfLitigations =$(".lit_campaigns_table  td:first-child:contains('ITC CAMPAIGN (X,XXX,XXX)')");
    public final Element dummyRecentCaseInCampViewOfLitigations = $(
            By.xpath("//table[contains(@class,'lit_campaigns_table')]//tr[1]/td[4]//a[text()='337-TA-000']"));
    public final Element campNameInCampViewOfLitigations = $(".lit_campaigns_table  td:first-child a");
    public final Element mostRecentCaseInCampViewOfLitigations = $(By.xpath(
            "//table[contains(@class,'lit_campaigns_table')]//tr[1]/td[4]//a[not(contains(text(),'337-TA-000'))]"));
    public final Element startDateInCampViewOfLitigations = $(
            By.xpath("//table[contains(@class,'lit_campaigns_table')]//tr[1]/td[2][text()='02/09/2001']"));
    public final Element termDateInCampViewOfLitigations = $(
            By.xpath("//table[contains(@class,'lit_campaigns_table')]//tr[1]/td[5][text()='03/01/2002']"));
    public final Element emptyStartDateInCampViewOfLitigations = $(
            By.xpath("//table[contains(@class,'lit_campaigns_table')]//tr[1]/td[2][not(text())]"));
    public final Element emptyTermDateInCampViewOfLitigations = $(
            By.xpath("//table[contains(@class,'lit_campaigns_table')]//tr[1]/td[5][not(text())]"));
   //PRB Reexamination section started
    public final Table reexamination_table = $("#chinese_prb_reexamination table", (Configure<Table>) table ->
    {
        table.uniqueId("td:nth-child(3) a[href]");
        table.viewAllLink(By.xpath("//*[@id='chinese_prb_reexamination']//a[text()='View All']"));
        table.viewLessLink(By.xpath("//*[@id='chinese_prb_reexamination']//a[text()='View Less']"));
        table.displayedRecords("#chinese_prb_reexamination table tbody tr:not([style='display: none;'])");
    });

    public void selectTabInPRBReexaminationSection(String tabName) {
        Element activeTab = $("#campaign_prb_section dd.active a");
        if (!activeTab.getText().toUpperCase().contains(tabName.toUpperCase())) {
            String xpath = String.format(
                    "//*[@id='campaign_prb_section']//dd/a[contains(text(),'%s')]",
                    tabName);
            Element requiredTab = $(By.xpath(xpath));
            requiredTab.click();
        }
    }
    public void selectPatentsTab() {
        if (patentsTabLink.isDisplayed()) {
            patentsTabLink.click();
            waitForSectionLoading();
        }
    }
    public final Element reexamination_title = $("#reexamination_tab h2");
    public final Element reexaminationTabLink = $("#reexamination_tab a[href='#chinese_prb_reexamination']");
    public final Element patentsTabLink = $("#campaign_prb_section [data-lit-type=patents] a");
    public final Element titleWithoutNpeTag = $("#content h1 span:not(.npe_tag)");
    public final Element entLinkAtRequesterTab=$("#chinese_prb_requester div.handle a");
    public final Element ReexaminationMetricsForRequester=$("#chinese_prb_requester div:nth-of-type(1) div.handle li.result-count");
    public final Table requesterNPatentTable = $("#chinese_prb_patents.content.active", (Configure<Table>) table -> {
        table.row("div.group.nested");
        table.uniqueId("div.handle>a");
        table.expandSubTableLink("div.group.nested div.handle");
        table.subTable($("table.table_section", (Configure<Table>) subtable ->
        {
            subtable.uniqueId("td:nth-child(2) a[href]");
            subtable.displayedRecords("#campaign_prb_section .active>div:nth-of-type(1) table tbody tr:not([style='display: none;'])");
        }));

    });
    public final Table requesterTable = $("#chinese_prb_requester.content.active", (Configure<Table>) table -> {
        table.row("div.group.nested");
        table.uniqueId("div.handle>a");
        table.expandSubTableLink("div.group.nested div.handle");
        table.subTable($("table.table_section", (Configure<Table>) subtable ->
        {
            subtable.uniqueId("td:nth-child(2) a[href]");
            subtable.displayedRecords("#chinese_prb_requester .active>div:nth-of-type(1) table tbody tr:not([style='display: none;'])");
        }));

    });
    public final Element reexaminationMetricsForRequester =$("#chinese_prb_patents div:nth-of-type(1) div.handle li.result-count");
    public final Element PRBpatListAtPatentTab=$("#chinese_prb_patents div:nth-of-type(1) div.handle");

    //PRB Reexamination ended

    public final Element accused_products_pc = $(By.xpath("//div[@id='accused_products']//div[@class='subscription-promo-message']/a[text()='Start with a Free Trial']"));
    public final Element accused_products_pc_without_FF = $(By.xpath("//div[@id='accused_products']//a[text()='Learn more']"));
    public final Element accused_products_signin = $(By.xpath("//div[@id='accused_products']//div[@class='subscription-promo-message']/a[text()='Sign In']"));
    //    public final Element accused_products_signin_without_FF = $(By.xpath("//div[@id='accused_products']//a[text()='sign in']"));
    // REEL FRAME
    public final Element assignmentsReelFrame_signin = $(
            ".assignments a[class='no_context_menu'][data-behavior='static_tooltip']");
    public final String view_AllClaims = ".view-all-claims";
    public final Element defendant_Modal_subTable = $(By.xpath(
            "//*[@id='async_modal']//table[contains(@class,'nested_inner_table')]"));

    public void loadDefendantModal() {
        if (defendantLinkInLitCampaign.isDisplayed()) {
            defendantLinkInLitCampaign.click();
            overlay_Loading.waitUntilInvisible();
            defendantModal.waitUntilVisible();
        }
    }

    public void openDefendantSubtable() {
        if (!defendantModal.isDisplayed()) {
            loadDefendantModal();
        }
        if (firstSubtableOpen.isDisplayed()) {
            firstSubtableOpen.click();
            defendant_Modal_subTable.waitUntilVisible();
        }
    }

    public void viewReelFrameModal() {
        switchTabTo("Assignment View");
        if (assignmentsReelFrameLink.isDisplayed()) {
            assignmentsReelFrameLink.click();
            assignmentsReelFrame.waitUntilVisible();
        }
    }

    public void selectDefendantTab() {
        if (litDefendantTabLink.isDisplayed()) {
            litDefendantTabLink.click();
            waitForPageLoad();
        }
    }

    public void selectDefendantTabInLitigationCaseView() {
        caseViewInLitigations();
        selectDefendantTab();
    }

    // TODO Make this code generic with jquery selector concept
    public void expandAlldefandant() {
        if (defendant_non_camp_table.isDisplayed()) {
            if (!defendant_non_camp_table.subtable().isDisplayed()) {
                JavascriptExecutor js = (JavascriptExecutor) getDriver();
                js.executeScript("$('#defendants-container-content tr').click()", "");
                waitForPageLoad();
                waitForLoading();
            }
        }
    }

    public void changeCampaignView() {
        if (campaignview_button.isDisplayed()) {
            campaignview_button.click();
            waitForPageLoad();
        }
    }

    public void caseViewInLitigations(){
        if (caseViewInLitigations.isDisplayed()) {
            caseViewInLitigations.click();
            waitForPageLoad();
            campaignViewInLitigations.waitUntilVisible();
        }
    }

    public void campaignViewInLitigations() {
        if (campaignViewInLitigations.isDisplayed()) {
            campaignViewInLitigations.click();
            waitForPageLoad();
            caseViewInLitigations.waitUntilVisible();
        }
    }

    public void filterAllCases() {
        if (all_button.isDisplayed()) {
            all_button.click();
            waitForPageLoad();
        }
    }

    public void filterActiveCases() {
        if (active_button.isDisplayed()) {
            active_button.click();
            waitForPageLoad();
        }
    }

    public void filterInActiveCases() {
        if (inactive_button.isDisplayed()) {
            inactive_button.click();
            waitForPageLoad();
        }
    }

    public void selectReference_cited_Tab() {
        waitForLoading();
        if (reference_cited_TabLink.isDisplayed()) {
            reference_cited_TabLink.click();
            //reference_cited_Table.waitUntilVisible();
            $("#references_cited.active table").waitUntilVisible();

            waitForPageLoad();
        }
    }

    public boolean viewPatentImages() {
        viewImages_btn.click();
        return imagesContainer.waitUntilVisible();
    }

    public boolean closePatentImages() {
        closeImagesContainer.click();
        return detailPageTitle.waitUntilVisible();
    }

    public boolean viewDependantClaims() {
        viewDependantClaims.click();
        viewDependantClaims.waitUntilInvisible();
        return hideDependantClaims.waitUntilVisible();
    }

    public boolean hideDependantClaims() {
        hideDependantClaims.click();
        hideDependantClaims.waitUntilInvisible();
        return viewDependantClaims.waitUntilVisible();
    }

    public List<String> getRecordedDatesFromAssignments() {
        List<String> dates = assignmentInfo.getColumn("executed_date");
        return dates;
    }

    public void expandAllclaims() {
        JavascriptExecutor js = (JavascriptExecutor) getDriver();
        js.executeScript("$('" + view_AllClaims + "').click();");
        waitForPageLoad();
        waitForLoading();
    }

    //Role Authorization for Alerts
    public final Element rpx_Reports_Events = $("input#RPX_Reports:not([class*='greyed-out'])");
    public final Element prior_art_Report_Event = $("input#alert_event__400:not([class*='greyed-out'])");
    public final Element new_dc_Event = $("input#alert_event__300:not([class*='greyed-out'])");
    public final Element new_ptab_Event = $("input#alert_event__301:not([class*='greyed-out'])");
    public final Element new_itc_Event = $("input#alert_event__302:not([class*='greyed-out'])");
    public final Element alert_Btn_SignInMsg = $(By.xpath("//div[@class='qtip-content']//div[contains(text(), 'Please')]"));
    public final Element alert_Btn_SignInMsg_FF = $("#alerts_controls_holder a[data-ot-content*='sign in']");
    public final Element alert_Btn_PromoMsg = $(By.xpath("//div[@class='qtip-content']//div[contains(text(),'Patent alerts are not available')]/a[text()='Upgrade']"));
    public final Element alert_Btn_ToolTip = $(".qtip-content:visible");
    public final Element event_Promotional_Msg = $(".events_promotional_msg a[href='/payments/options']");

    //ASSIGNMENT SECTION:
    public final Element assignnment_uspto_doc = $("#shared_component_tabular_view div.page-content.assignment-tooltip-content.ng-scope a[title='Download the patent assignment']");
    public final Element real_frame_PopUp_assignnment_uspto_doc = $(".assignment_reel_frame a.icon-file-pdf.uspto_pdf_link");

    public Element getReelFramePDFDocElement(String reel_frame_Name) {
        return $(".label-info a[href*='" + reel_frame_Name + "']");
    }

    public final Element reIssuedPatentText = $("li:contains(Re-issued)");
    public final Element grantedPatentText = $("li:contains(GRANTED PATENT)");

    //PATENT INFO
    public final StaticContent patent_info = $(".panel.patent-info", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("granted_patNum", "li:contains(GRANTED PATENT) a");
                dataForm.content("application_patNum", "li:contains(APPLICATION) a");
                dataForm.content("reissuedas_patNum", "li:contains(Re-issued) a");
                dataForm.content("reissueof_patNum", "li:contains(Re-issue) a");
            }
    );

    //ASSIGNMENT or TIMELINE VIEW TAB
    public final Element assignmentActiveTab = $("#patent-assignments-chart dl.tabs dd.active a");
    public final Element assignment_Default_TimeLineView = $("#patent-assignments-chart div#assignment-chart");
    public final Element assignment_Default_AssignmentView = $("#patent-assignments-chart .tabs .active a:contains('Assignment View')");
    public final Element assignment_TimeLineChart = $("div.content.active div.assigment-sankey div#assignment-chart");
    public final Element timelinepromomsg = $("#patent-assignments-chart div.assignment-sankey-content-ele div.subscription-promo-message a:contains('Start with a Free Trial')");
    public final Element timelinepromosignin= $("#patent-assignments-chart div.assignment-sankey-content-ele div.subscription-promo-message a:contains('Sign In')");

    public void switchTabTo(String activeTab) {
        if (!assignmentActiveTab.getText().equalsIgnoreCase(activeTab)) {
            $("#patent-assignments-chart dl.tabs a:contains('" + activeTab + "')").click();
        }
    }

    public void selectAssignmentView() {
        switchTabTo("Assignment View");
    }
    public void selectTimeLineView() {
        switchTabTo("Timeline View");
    }
    public final Element timeLine_TopCircles = $("#timelineTop circle.pin-head");
    public final Element timeLine_TopCircles_Tooltip = $(".d3-tip-top.s[style*='pointer-events: all']");
    public final Element timeLine_TopCircles_Tooltip_assignmentLnk = $(".d3-tip-top.s[style*='pointer-events: all'] .tip-container h5>a");

    public String getAssignmentTooltipTableData(String rowContent) {
        return $(".d3-tip-top.s[style*='pointer-events: all'] table tbody tr:contains(" + rowContent + ") td:nth-of-type(2)").getText();
    }

    public final Element timeLine_Assignment_PopUp = $("#shared_sankey_detail_modal.open .modal-content");
    public final StaticContent assignment_PopUp = $("#shared_sankey_detail_modal", (Configure<StaticContent>) dataForm ->
    {
        dataForm.content("Executed", ".label-header:contains(Executed)+span");
        dataForm.content("Asset", ".patent-header:contains(Asset)");
        dataForm.content("Reel", ".label-header:contains(Reel)+span");
        dataForm.content("Assignors", ".left .assignee-name a");
        dataForm.content("Assignee", ".right .assignee-name a");
    });

    public void closeAssignmentPopup() {
        if (timeLine_Assignment_PopUp.$("a.close-reveal-modal").isDisplayed()) {
            timeLine_Assignment_PopUp.$("a.close-reveal-modal").click();
            timeLine_Assignment_PopUp.waitUntilInvisible();
        }
    }

    public final Element timeline_Chart_AssigneeNode = $("#assignment-chart g.node>rect+text");
    public final Element assigneeNode_Tooltip = $(".d3-assignment-tip[style*='pointer-events: all'] .tip-container h5");
    public String getAssigneeNodeTooltipData(String rowContent) {
        return $(".d3-assignment-tip[style*='pointer-events: all'] tbody tr:contains(" + rowContent + ") td:nth-of-type(2)").getText();
    }

    public final Element cafcCallout = $(".cafc-tag.callout");

    public String getCAFCCallout() {
        String calloutText = "";
        detailPageTitle.waitUntilVisible();
        if (cafcCallout.isDisplayed()) {
            calloutText = cafcCallout.getText();
        }
        return calloutText;
    }

    public final Table campaign_name = $("#DataTables_Table_0", (Configure<Table>) table ->
    {
        table.uniqueId("tbody td:nth-of-type(1) a");
        table.next("DataTables_Table_0_next paginate_button");
    });

    public final Element viewInAnalyst=$(".view-in-analyst>a:contains('View in RPX Analyst')");
}
