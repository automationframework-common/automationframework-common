package com.rpxcorp.insight.page.advance_search;

import com.rpxcorp.insight.module.AutoComplete;
import com.rpxcorp.insight.module.DatePicker;
import com.rpxcorp.insight.module.Radio;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

import java.util.Map;

public class PatentAdvanceSearchPage extends AdvanceSearchPage {
    public PatentAdvanceSearchPage() {
        this.url = new PageUrl("advanced_search#patentTab");
    }

    @Override
    public boolean at() {
        return abstractTextBox.waitUntilVisible();
    }

    public final AutoComplete title = $("#title", AutoComplete.class);
    public final AutoComplete patentNumber = $("#patnum", AutoComplete.class);
    public final AutoComplete applicationNumber = $("#appnum", AutoComplete.class);
    public final Element abstractTextBox = $("#patents_search_form input#abstract");
    public final Element claims = $("#claims");
    public final Element inventorName = $("#inventor");
    public final AutoComplete currentAssignee = $("#current_assignee",AutoComplete.class);
    public final AutoComplete anyAssignee = $("#all_assignee",AutoComplete.class);
    public final AutoComplete originalAssignee = $("#original_assignee",AutoComplete.class);
    public final AutoComplete assignor=$("#assignor",AutoComplete.class);
    public final Element currentAssigneeType = $("#current_assignee_type");
    public final Element anyAssigneeType = $("#all_assignee_type");
    public final Element originalAssigneeType =$("#patent_sponsor_type");
    public final Element assignorType =$("#assignor_type");
    public final Element patentType =$("#s2id_patent_status ul.select2-choices");
    public final DatePicker executionFromDate=$("#from_assignment_execution_date",DatePicker.class);
    public final DatePicker executionToDate=$("#to_assignment_execution_date",DatePicker.class);
    public final DatePicker priorityFromDate=$("#from_priority_date",DatePicker.class);
    public final DatePicker priorityToDate=$("#to_priority_date",DatePicker.class);
    public final DatePicker filingFromDate=$("#from_filing_date",DatePicker.class);
    public final DatePicker filingToDate=$("#to_filing_date",DatePicker.class);
    public final DatePicker publishedFromDate=$("#from_publication_date",DatePicker.class);
    public final DatePicker publishedToDate=$("#to_publication_date",DatePicker.class);
    public final DatePicker issuedFromDate=$("#from_grant_date",DatePicker.class);
    public final DatePicker issuedToDate=$("#to_grant_date",DatePicker.class);
    public final DatePicker expirationFromDate=$("#from_expiration_date",DatePicker.class);
    public final DatePicker expirationToDate=$("#to_expiration_date",DatePicker.class);

    public void searchd(Map<String, Object> data) throws Exception {
        title.inputText(data.get("Title"));
        patentNumber.inputText(data.get("Patent Number"));
        applicationNumber.inputText(data.get("Application Number"));
        abstractTextBox.inputText(data.get("Abstract"));
        inventorName.inputText(data.get("Inventor Name"));
        patentType.selectByOption(data.get("Status"));
        claims.inputText(data.get("Claims"));
        currentAssignee.inputText(data.get("Current Assignee"));
        currentAssigneeType.selectByOption(data.get("Current Assignee Type"));
        anyAssignee.inputText(data.get("Any Assignee"));
        anyAssigneeType.selectByOption(data.get("Any Assignee Type"));
        originalAssignee.inputText(data.get("Original Assignee"));
        originalAssigneeType.selectByOption(data.get("Original Assignee Type"));
        assignor.inputText(data.get("Assignor"));
        assignorType.selectByOption(data.get("Assignor Type"));
        executionFromDate.selectDate(data.get("Assignment Execution From Date"));
        executionToDate.selectDate(data.get("Assignment Execution To Date"));
        priorityFromDate.selectDate(data.get("Est. Priority From Date"));
        priorityToDate.selectDate(data.get("Est. Priority To Date"));
        filingFromDate.selectDate(data.get("Filing From Date"));
        filingToDate.selectDate(data.get("Filing To Date"));
        publishedFromDate.selectDate(data.get("Published From Date"));
        publishedToDate.selectDate(data.get("Published To Date"));
        issuedFromDate.selectDate(data.get("Issue From Date"));
        issuedToDate.selectDate(data.get("Issue To Date"));
        expirationFromDate.selectDate(data.get("Expiration From Date"));
        expirationToDate.selectDate(data.get("Expiration To Date"));
        submitButton.click();
    }
    // TODO remove it after removing it usage
    public void search(Map<String, String> data) throws Exception {
        title.sendKeys(data.get("Title"));
        abstractTextBox.sendKeys(data.get("Abstract Text Box"));
        claims.sendKeys(data.get("Claims"));
        patentNumber.sendKeys(data.get("Patent Number"));
        inventorName.sendKeys(data.get("Inventor Name"));
        legalStatus.sendKeys(data.get("Legal Status"));
        applicationNumber.sendKeys(data.get("Application Number"));
        currentAssignee.sendKeys(data.get("Current Assignee"));
        anyAssignee.sendKeys(data.get("All Assignee"));//allAssignee
        originalAssignee.sendKeys(data.get("Original Assignee"));
        assignor.sendKeys(data.get("Assignor"));
        if(data.get("Assignment Execution Date � From")!=null)
            expirationFromDate.selectDate(data.get("Assignment Execution Date � From"));
        if(data.get("Assignment Execution Date � To")!=null)
            executionToDate.selectDate(data.get("Assignment Execution Date � To"));
        if(data.get("Current Assignee Type")!=null)
            currentAssigneeType.selectByOption(data.get("Current Assignee Type"));
        if(data.get("Any Assignee Type")!=null)
            anyAssigneeType.selectByOption(data.get("Any Assignee Type"));
        if(data.get("Original Assignee Type")!=null)
            originalAssigneeType.selectByOption(data.get("Original Assignee Type"));
        if(data.get("Assigner Type")!=null)
            assignorType.selectByOption(data.get("Assigner Type"));
        submitButton.click();
    }
}
