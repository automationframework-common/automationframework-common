package com.rpxcorp.insight.test.analytics;

import com.rpxcorp.insight.page.HomePage;
import com.rpxcorp.insight.page.LitigationDocumentPage;
import com.rpxcorp.insight.page.analytics.DCAnalytics;
import com.rpxcorp.insight.page.detail.*;
import com.rpxcorp.insight.page.search.PatentSearchPage;
import com.rpxcorp.insight.test.functional.BaseFuncTest;
import com.rpxcorp.testcore.Authenticate;
import org.testng.Assert;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.List;

@Authenticate(role = "MEMBER")
@Test(groups = {"DCAnalytics"})
public class DCAnalyticsTest extends BaseFuncTest {

    HomePage homePage;
    BaseDetailPage baseDetailPage;
    LitigationDetailPage litigationDetailPage;
    PatentDetailPage patentDetailPage;
    PatentSearchPage patentSearchPage;
    EntityDetailPage entityDetailPage;
    PtabDetailPage ptabDetailPage;
    CampaignDetailPage campaignDetailPage;
    LitigationDocumentPage litigationDocumentPage;
    ITCDetailPage itcDetailPage;
    DCAnalytics dcAnalytics;
    SoftAssert softAssert;


    /**
     * SMOKE TESTS
     **/

    @Test(priority = 101, groups = {"smoke","P2"}, description = "Verify all sections in Litigation details page")
    public void verifyAllTabsInDCAnalyticsPage() throws Exception {
        softAssert = new SoftAssert();
        to(dcAnalytics, urlData);
        //General Tab
        Assert.assertTrue(dcAnalytics.metricsSection.isDisplayed(),"The metrics section is not displayed in the DC Analytics Page");
        dcAnalytics.litigationCampaignTabs.select("General");
        Assert.assertTrue(dcAnalytics.generalTotalCampaignDef.isDisplayed(),"The 'Total Campaign Defendants' Chart is not displayed");
        Assert.assertTrue(dcAnalytics.generalLitMarketSector.isDisplayed(),"The 'Litigations by Market sector' Chart is not displayed");
        dcAnalytics.litigationCampaignTabs.select("Venue");
        Assert.assertTrue(dcAnalytics.venueLitFiledByVenue.isDisplayed(),"The 'Litigations Filed by Venue' Chart is not displayed");
        Assert.assertTrue(dcAnalytics.venueLitOverTime.isDisplayed(),"The 'Litigations Filed by Venue' Chart is not displayed");
        dcAnalytics.litigationCampaignTabs.select("Party");
        Assert.assertTrue(dcAnalytics.partyTopPlaintiffs.isDisplayed(),"The 'Top Plaintiffs' Chart is not displayed in Party tab");
        Assert.assertTrue(dcAnalytics.partyTopDefendants.isDisplayed(),"The 'Top Defendants' Chart is not displayed in Party tab");
        dcAnalytics.litigationCampaignTabs.select("Law Firm");
        Assert.assertTrue(dcAnalytics.lawFirmTopPlaintiffs.isDisplayed(),"The 'Top Plaintiffs' Chart is not displayed in Law-Firm tab");
        Assert.assertTrue(dcAnalytics.lawFirmTopDefendants.isDisplayed(),"The 'Top Defendants' Chart is not displayed in Law-Firm tab");
        dcAnalytics.litigationCampaignTabs.select("Judge");
        Assert.assertTrue(dcAnalytics.judgeTopJudgesByCases.isDisplayed(),"The 'Most Active Judges' Chart is not displayed in Judge tab");
        Assert.assertTrue(dcAnalytics.judgeTopJudgesByOutcomes.isDisplayed(),"The 'Top Judges' Chart is not displayed in Judge tab");
        dcAnalytics.litigationCampaignTabs.select("Outcome");
        Assert.assertTrue(dcAnalytics.outcomeByYear.isDisplayed(),"The 'Outcome By Year' Chart is not displayed in Outcome tab");
        dcAnalytics.outcomeSwitchChart("Bar Chart");
        Assert.assertTrue(dcAnalytics.defendantOutcomesBarChart.isDisplayed(),"The 'Defendant Outcomes - Bar Chart' Outcome tab is not displayed");
        dcAnalytics.litigationCampaignTabs.select("Motions");
        Assert.assertTrue(dcAnalytics.motionOutcomes.isDisplayed(),"The 'Motions' Chart is not displayed in Motions tab");
        dcAnalytics.motionChartSwitch("Duration");
        Assert.assertTrue(dcAnalytics.motionduration.isDisplayed(),"The 'Defendant Outcomes - Bar Chart' Outcome tab is not displayed");
        dcAnalytics.litigationCampaignTabs.select("Appeal");
        Assert.assertTrue(dcAnalytics.appealsOverTime.isDisplayed(),"The 'Appeals over Time' Chart is not displayed in Appeal tab");
        Assert.assertTrue(dcAnalytics.appealissuesBasisAppeal.isDisplayed(),"The 'Issues Basis for Appeal' Chart is not displayed in Appeal tab");
        Assert.assertTrue(dcAnalytics.appealeventBasisAppeal.isDisplayed(),"The 'Event Basis for Appeal' Chart is not displayed in Appeal tab");
        Assert.assertTrue(dcAnalytics.appealingParty.isDisplayed(),"The 'Appealing Party' Chart is not displayed in Appeal tab");
        Assert.assertTrue(dcAnalytics.appealOutcomes.isDisplayed(),"The 'Appeal Outcomes' Chart is not displayed in Appeal tab");
        softAssert.assertAll();
    }

    @BeforeGroups(groups = "basicValidation")
    public void facetBasicValidation(){
        to(dcAnalytics, urlData);
    }
    //Left Side Filter Validations Starts
    @Test(priority = 201, groups = {"P2","basicValidation"}, dataProvider = "json",description = "Verify facet filter headers")
    public void verifyFacetFilterHeaders(List<String> expectedFilterHeaders) throws Exception {
        Assert.assertEquals(dcAnalytics.facetHeader.getFacetFilterHeaders(),expectedFilterHeaders);
    }

    @Test(priority = 202, groups = {"P2","basicValidation"}, dataProvider = "json", description = "Verify facet filter validation")
    public void verifyFacetSubFilterValidation(String facetName , List<String> facetSubHeader) throws Exception {
        dcAnalytics.expandFacet(facetName);
        Assert.assertEquals(dcAnalytics.facetSubHeader(facetName).getFacetFilterHeaders(),facetSubHeader);
    }

    @Test(priority = 203, groups = {"P2","basicValidation"}, dataProvider = "json", description = "Verify sub-facet search filter validation")
    public void verifyFacetSearchSubFilterValidation(String facetName , List<String> facetSubHeader) throws Exception {
        facetBasicValidation();
        dcAnalytics.expandFacet(facetName);
        Assert.assertEquals(dcAnalytics.facetSubHeaderSearchType(facetName).getFacetFilterHeaders(),facetSubHeader);
    }

    //Patent Filter Validation Starts Here
    @BeforeGroups(groups = "GeneralTab")
    public void loadGeneralTab(){
        to(dcAnalytics);
        dcAnalytics.litigationCampaignTabs.select("General");
    }

    @Test(priority = 501, groups = {"P2","GeneralTab"}, dataProvider = "json", description = "General Tab Chart Validation")
    public void verifyGeneralTabValidation(String fieldName, String Value,String viewType) throws Exception {
        this.urlData.clear();
        this.urlData.put(fieldName,Value);
        to(dcAnalytics, this.urlData);
        dcAnalytics.generalViewDropdown.waitUntilVisible();
        dcAnalytics.generalViewDropdown.selectByOption(viewType);
        Assert.assertTrue(dcAnalytics.generalTotalCampaignDef.isDisplayed(),"The 'Total Campaign Defendants' Chart is not displayed");
        Assert.assertTrue(dcAnalytics.generalLitMarketSector.isDisplayed(),"The 'Litigations by Market sector' Chart is not displayed");
        verifyLeftSideFilterAlphaNumeric(Value);
    }

    //Patent Filter Validation Starts Here
    @BeforeGroups(groups = "VenueTab")
    public void loadVenueTab(){
        to(dcAnalytics);
        dcAnalytics.litigationCampaignTabs.select("Venue");
    }

    @Test(priority = 502, groups = {"P2","VenueTab"}, dataProvider = "json", description = "Venue Tab Chart Validation")
    public void verifyVenueTabValidation(String fieldName, String Value,String viewType1,String viewType2,String viewType3) throws Exception {
        this.urlData.clear();
        this.urlData.put(fieldName,Value);
        to(dcAnalytics, this.urlData);
        dcAnalytics.litigationCampaignTabs.select("Venue");
        dcAnalytics.litFiledByVenue.selectByOptionAndWaitForAjaxLoader(viewType1);
        Assert.assertTrue(dcAnalytics.venueLitFiledByVenue.isDisplayed(),"The 'Total Campaign Defendants' Chart is not displayed");
        dcAnalytics.litFiledByVenueOverTime.selectByOptionAndWaitForAjaxLoader(viewType2);
        Assert.assertTrue(dcAnalytics.venueLitOverTime.isDisplayed(),"The 'Litigations by Market sector' Chart is not displayed");
        dcAnalytics.venueOutcome.clickAndSelectCheckbox(viewType3);
        dcAnalytics.outcomedropdown.click();
        Assert.assertTrue(dcAnalytics.topVenuesByOutcome_Events.isDisplayed(),"The 'Total Venues by Outcome - Number of Events' Chart is not displayed");
        Assert.assertTrue(dcAnalytics.topVenuesByOutcome_Duration.isDisplayed(),"The 'Total Venues by Outcome - Duration' Chart is not displayed");
        verifyLeftSideFilterRemovingSpecialChar(Value);
    }

    @BeforeGroups(groups = "PartyTab")
    public void loadPartyTab(){
        to(dcAnalytics);
        dcAnalytics.litigationCampaignTabs.select("Party");
    }

    @Test(priority = 503, groups = {"P2","PartyTab"}, dataProvider = "json", description = "Party Tab Chart Validation")
    public void verifyPartyTabValidation(String fieldName, String Value,String viewTypePlaintiffs,String viewTypeDefend,String partyType,String outcome) throws Exception {
        this.urlData.clear();
        this.urlData.put(fieldName,Value);
        to(dcAnalytics, this.urlData);
        dcAnalytics.litigationCampaignTabs.select("Party");
        dcAnalytics.partyTopPlaintiffsDdown.selectByOptionAndWaitForAjaxLoader(viewTypePlaintiffs);
        Assert.assertTrue(dcAnalytics.partyTopPlaintiffs.isDisplayed(),"The 'Top Plaintiffs' Chart in party tab not displayed");
        dcAnalytics.partyTopDefendantsDdown.selectByOptionAndWaitForAjaxLoader(viewTypeDefend);
        Assert.assertTrue(dcAnalytics.partyTopDefendants.isDisplayed(),"The 'Top Defendants' Chart in party tab is not displayed");
        dcAnalytics.partyOutcomeType.selectByOptionAndWaitForAjaxLoader(partyType);
        Assert.assertTrue(dcAnalytics.partyEvents.isDisplayed(),"The 'Total Parties by Outcome - Number of Events' Chart in party tab is not displayed");
        dcAnalytics.partyOutcome.clickAndSelectCheckbox(outcome);
        Assert.assertTrue(dcAnalytics.partyDuration.isDisplayed(),"The 'Total Parties by Outcome - Duration' Chart in party tab is not displayed");
        verifyLeftSideFilterRemovingSpecialChar(Value);
    }

    @BeforeGroups(groups = "LawFirmTab")
    public void loadLawFirmTab(){
        to(dcAnalytics);
        dcAnalytics.litigationCampaignTabs.select("Law Firm");
    }

    @Test(priority = 504, groups = {"P2","LawFirmTab"}, dataProvider = "json", description = "Law Firm Tab Chart Validation")
    public void verifyLawFirmTabValidation(String fieldName, String Value,String viewTypePlaintiffs,String viewTypeDefend,String partyType,String outcome) throws Exception {
        this.urlData.clear();
        this.urlData.put(fieldName,Value);
        to(dcAnalytics, this.urlData);
        dcAnalytics.litigationCampaignTabs.select("Law Firm");
        dcAnalytics.lawfirmTopPlaintiffsDdown.selectByOptionAndWaitForAjaxLoader(viewTypePlaintiffs);
        Assert.assertTrue(dcAnalytics.lawFirmTopPlaintiffs.isDisplayed(),"The 'Top Law Firms Representing Plaintiffs' Chart in Law Firm tab not displayed");
        dcAnalytics.lawfirmTopDefendantsDdown.selectByOptionAndWaitForAjaxLoader(viewTypeDefend);
        Assert.assertTrue(dcAnalytics.lawFirmTopDefendants.isDisplayed(),"The 'Top Law Firms Representing Defendants' Chart in Law Firm tab is not displayed");
        dcAnalytics.lawfirmOutcomeType.selectByOptionAndWaitForAjaxLoader(partyType);
        Assert.assertTrue(dcAnalytics.lawFirmEvents.isDisplayed(),"The 'Total Law Firms by Outcome - Number of Events' Chart in Law Firm tab is not displayed");
        //dcAnalytics.lawfirmoutcome.selectByOptionAndWaitForAjaxLoader(outcome);
        dcAnalytics.lawfirmoutcome.clickAndSelectCheckbox(outcome);
        Assert.assertTrue(dcAnalytics.lawFirmDuration.isDisplayed(),"The 'Total Law Firms by Outcome - Duration' Chart in Law Firm tab is not displayed");
        verifyLeftSideFilterRemovingSpecialChar(Value);
    }


    @BeforeGroups(groups = "JudgeTab")
    public void loadJudgeTab(){
        to(dcAnalytics);
        dcAnalytics.litigationCampaignTabs.select("Judge");
    }

    @Test(priority = 505, groups = {"P2","JudgeTab"}, dataProvider = "json", description = "Judge Tab Chart Validation")
    public void verifyJudgeTabValidation(String fieldName, String Value,String viewTypeTopJudgesOutcomes,String outcome) throws Exception {
        this.urlData.clear();
        this.urlData.put(fieldName,Value);
        to(dcAnalytics, this.urlData);
        dcAnalytics.litigationCampaignTabs.select("Judge");
        Assert.assertTrue(dcAnalytics.judgeTopJudgesByCases.isDisplayed(),"The 'Top Judges - By number of cases' Chart in Law Firm tab not displayed");
        dcAnalytics.topJudgesMotionOutcomesDdown.selectByOptionAndWaitForAjaxLoader(viewTypeTopJudgesOutcomes);
        Assert.assertTrue(dcAnalytics.judgeTopJudgesByOutcomes.isDisplayed(),"The 'Top Judges - By motion outcomes' Chart in Law Firm tab is not displayed");
        dcAnalytics.topJudgesOutcomeType.clickAndSelectCheckbox(outcome);
        Assert.assertTrue(dcAnalytics.topJudgeEvents.isDisplayed(),"The 'Total Judges by Outcome - Number of Events' Chart in Law Firm tab is not displayed");
        Assert.assertTrue(dcAnalytics.topJudgeDuration.isDisplayed(),"The 'Total Judges by Outcome - Duration' Chart in Law Firm tab is not displayed");
        if(fieldName.contains("MarketSector")){
            verifyLeftSideFilterAlphaNumeric(Value);
        }else{
            verifyLeftSideFilterRemovingSpecialChar(Value);

        }

    }

    @BeforeGroups(groups = "OutcomeTab")
    public void loadOutcomeTab(){
        to(dcAnalytics);
        dcAnalytics.litigationCampaignTabs.select("Outcome");
    }

    @Test(priority = 506, groups = {"P2","OutcomeTab"}, dataProvider = "json", description = "OutcomeTab Tab Chart Validation")
    public void verifyOutcomeTabValidation(String fieldName, String Value) throws Exception {
        this.urlData.clear();
        this.urlData.put(fieldName,Value);
        to(dcAnalytics, this.urlData);
        dcAnalytics.litigationCampaignTabs.select("Outcome");
        Assert.assertTrue(dcAnalytics.defendantOutcomesSankey.isDisplayed(),"The 'Defendant Outcomes - Sankey' Chart in Outcome tab is not displayed");
        dcAnalytics.outcomeSwitchChart("Bar Chart");
        Assert.assertTrue(dcAnalytics.defendantOutcomesBarChart.isDisplayed(),"The 'Defendant Outcomes - Bar Chart' Outcome tab is not displayed");
        Assert.assertTrue(dcAnalytics.outcomeDuration.isDisplayed(),"The 'Outcome-Duration' Chart in Outcome tab is not displayed");
        Assert.assertTrue(dcAnalytics.outcomeByYear.isDisplayed(),"The 'Defendant Outcomes Over Time' Chart in Outcome tab is not displayed");
        verifyLeftSideFilterRemovingSpecialChar(Value);
    }

    @BeforeGroups(groups = "MotionsTab")
    public void loadMotionsTab(){
        to(dcAnalytics);
        dcAnalytics.litigationCampaignTabs.select("Motions");
    }

    @Test(priority = 507, groups = {"P2","MotionsTab"}, dataProvider = "json", description = "Motions Tab Chart Validation")
    public void verifyMotionsTabValidation(String fieldName, String Value,String partyType,String chartType,String partyType1,String chartType1) throws Exception {
        this.urlData.clear();
        this.urlData.put(fieldName,Value);
        to(dcAnalytics, this.urlData);
        dcAnalytics.litigationCampaignTabs.select("Motions");
        dcAnalytics.motionPartySwitch(partyType);
        dcAnalytics.motionChartSwitch(chartType);
        Assert.assertTrue(dcAnalytics.motionOutcomes.isDisplayed(),"The 'Motion Outcomes' Chart in Motions tab is not displayed");
        dcAnalytics.motionPartySwitch(partyType1);
        dcAnalytics.motionChartSwitch(chartType1);
        Assert.assertTrue(dcAnalytics.motionduration.isDisplayed(),"The 'Defendant Outcomes - Bar Chart' Outcome tab is not displayed");
        verifyLeftSideFilterRemovingSpecialChar(Value);
    }


    @BeforeGroups(groups = "AppealTab")
    public void loadAppealTab(){
        to(dcAnalytics);
        dcAnalytics.litigationCampaignTabs.select("Appeal");
    }

    @Test(priority = 508, groups = {"P2","AppealTab"}, dataProvider = "json", description = "Appeal Tab Chart Validation")
    public void verifyAppealTabValidation(String fieldName, String Value,String viewDropdown, String datePeriod) throws Exception {
        this.urlData.clear();
        this.urlData.put(fieldName,Value);
        to(dcAnalytics, this.urlData);
        dcAnalytics.litigationCampaignTabs.select("Appeal");
        dcAnalytics.appealOverTimeDdown.selectByOptionAndWaitForAjaxLoader(viewDropdown);
        dcAnalytics.motionPeriodSwitch(datePeriod);
        Assert.assertTrue(dcAnalytics.appealsOverTime.isDisplayed(),"The 'Issue Basis for Appeal' Chart in Appeal tab is not displayed");
        Assert.assertTrue(dcAnalytics.appealissuesBasisAppeal.isDisplayed(),"The 'Issue Basis for Appeal' Chart in Appeal tab is not displayed");
        Assert.assertTrue(dcAnalytics.appealeventBasisAppeal.isDisplayed(),"The 'Event Basis for Appeal' Chart in Appeal tab is not displayed");
        Assert.assertTrue(dcAnalytics.appealingParty.isDisplayed(),"The 'Appealing Party' Chart in Appeal tab is not displayed");
        Assert.assertTrue(dcAnalytics.appealOutcomes.isDisplayed(),"The 'Appeal Outcomes' Chart in Appeal tab is not displayed");
        verifyLeftSideFilterRemovingSpecialChar(Value);
    }

    //Compare Tab
    @BeforeGroups(groups = "CompareTab")
    public void loadCompareTab(){
        to(dcAnalytics);
        dcAnalytics.litigationCampaignTabs.select("Compare");
    }

    @Test(priority = 509, groups = {"P2","CompareTab"}, dataProvider = "json",description = "Compare Tab Chart Validation")
    public void verifyCompareTabValidation(String compType,String Comparision) throws Exception {
        dcAnalytics.compType.selectByOption(compType);
        dcAnalytics.compareTabSelectDefendants(Comparision);
        dcAnalytics.clickCompareButton();
        Assert.assertTrue(dcAnalytics.totalCasesFiledChart.isDisplayed(),"The 'Total Cases Filed' Chart in Compare tab is not displayed");
        Assert.assertTrue(dcAnalytics.outcomeChart.isDisplayed(),"The 'Outcome' Chart in Compare tab is not displayed");
        Assert.assertTrue(dcAnalytics.motionsChart.isDisplayed(),"The 'Motions' Chart in Compare tab is not displayed");
        Assert.assertTrue(dcAnalytics.topPlaintiffChart.isDisplayed(),"The 'Top Defendants' Chart in Compare tab is not displayed");
        Assert.assertTrue(dcAnalytics.topLawfirmPlaintiffChart.isDisplayed(),"The 'Top Defendants(Representing Plaintiffs)' Chart in Compare tab is not displayed");
        Assert.assertTrue(dcAnalytics.topLawfirmDefendantsChart.isDisplayed(),"The 'Top Lawfirms(Representing Defendants)' Chart in Compare tab is not displayed");
        Assert.assertTrue(dcAnalytics.topVenuesChart.isDisplayed(),"The 'Top Venues' Chart in Compare tab is not displayed");

    }

    @BeforeGroups(groups = "CaseList")
    public void loadCaseList(){
        to(dcAnalytics);
        dcAnalytics.mainTabs.select("Case List");
    }

    @Test(priority = 701, groups = {"P2","CaseList"}, description = "Case List - Verify Case Name Link Navigation")
    public void verifyCaseNameNavigationInCaseList() throws Exception {
        String lit_Title = dcAnalytics.caseList.getColumnLinkElem("CASE NAME").getText();
        String lit_CaseNumber = dcAnalytics.caseList.getColumnText("CASE #");
        withNewWindow(dcAnalytics.caseList.getColumnLinkElem("CASE NAME"), () -> {
            at(litigationDetailPage);
            String titleInDetailsPage = baseDetailPage.detailPageTitle.getText().toLowerCase();
            String caseNumberInDetailsPage = litigationDetailPage.docketNumberText.getText().toLowerCase();
            Assert.assertTrue(titleInDetailsPage.equalsIgnoreCase(lit_Title), "Case Title in DC Analytics Page is not matching with Litigation Details Page");
            Assert.assertTrue(lit_CaseNumber.equalsIgnoreCase(caseNumberInDetailsPage), "Case Number in DC Analytics Page is not matching with Litigation Details Page");
        });
    }

    @Test(priority = 702, groups = {"P2","CaseList"}, description = "Verify all sections in Litigation details page")
    public void verifyCampaignNameNavigationInCaseList() throws Exception {
        String campaignName = dcAnalytics.caseList.getColumnLinkElem("CAMPAIGN NAME").getText();
        withNewWindow(dcAnalytics.caseList.getColumnLinkElem("CAMPAIGN NAME"), () -> {
            at(campaignDetailPage);
            String detailsPageCampaignName = baseDetailPage.detailPageTitle.getText().toLowerCase();
            Assert.assertTrue(detailsPageCampaignName.equalsIgnoreCase(campaignName), "Case Title in DC Analytics Page is not matching with Litigation Page");
        });
    }


    @BeforeGroups(groups = "PatentList")
    public void loadPatentList(){
        to(dcAnalytics);
        dcAnalytics.mainTabs.select("Patent List");
    }

    @Test(priority = 801, groups = {"P2","PatentList"}, description = "Patent List - Verify Patent Number Link Navigation")
    public void verifyPatentNumberNavigationInPatentList() throws Exception {
        String pat_Title = dcAnalytics.patentList.getColumnLinkElem("Patent Number").getText();
        withNewWindow(dcAnalytics.patentList.getColumnLinkElem("Patent Number"), () -> {
            at(patentDetailPage);
            String patentNumber = patentDetailPage.header_info.getData("patent_number");
            Assert.assertTrue(patentNumber.equalsIgnoreCase(pat_Title), "Patent Number in the DC Analytics Page is not matching with Patent Details Page");
        });
    }

    @Test(priority = 802, groups = {"P2","PatentList"}, description = "Patent List - Verify Current Assignee Link Navigation")
    public void verifyCurrentAssigneeLinkNavigation() throws Exception {
        String currentAssignee = dcAnalytics.patentList.getColumnLinkElem("Current Assignee").getText();
        withNewWindow(dcAnalytics.patentList.getColumnLinkElem("Current Assignee"), () -> {
            at(entityDetailPage);
            String detailsPageEntTitle = baseDetailPage.detailPageTitle.getText().toLowerCase();
            Assert.assertTrue(detailsPageEntTitle.toLowerCase().contains(currentAssignee.toLowerCase()), "Current Assignee Name in DC Analytics Page is not matching with Entity Page");
        });
    }



    private void verifyLeftSideFilterRemovingSpecialChar(String actualValue){
        String actValue = actualValue.replaceAll("\\d","").replaceAll("[^a-zA-Z0-9\\s,-]","");
        Assert.assertTrue(dcAnalytics.getLeftSideAppliedFilterValues().contains(actValue),"The left side filter is not working as expected - Party Tab");
    }
    private void verifyLeftSideFilterAlphaNumeric(String actualValue){
        String actValue = actualValue.replaceAll("[^a-zA-Z0-9\\s]","");
        Assert.assertTrue(dcAnalytics.getLeftSideAppliedFilterValues().contains(actValue),"The left side filter is not working as expected - Party Tab");
    }
}
