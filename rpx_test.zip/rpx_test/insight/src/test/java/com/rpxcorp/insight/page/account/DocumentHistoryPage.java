package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.By;
import com.rpxcorp.testcore.element.Element;

public class DocumentHistoryPage extends BasePage {

    @Override
    public boolean at() {
        return document_history_panel.waitUntilVisible();
    }

    public final Element document_history_panel = $("#panel_document_history.active h4");
    public final Element no_Records_document_history=$("#panel_document_history h3:contains(No documents found.)");
	public final Element noTransactionMessage = $(By.xpath("//div[@class='large-12 columns']/h5[text()='No documents found.']"));
	
	public final Table documentHistoryTable = new Table(".doc_history_table");
	
	public final Element latestDocument = $(By.xpath("//table[@class='doc_history_table']//tr[1]/td[1]/a"));
}
