package com.rpxcorp.insight.page.detail;
        import com.rpxcorp.testcore.element.Element;
        import com.rpxcorp.testcore.page.Page;
        import com.rpxcorp.testcore.page.PageUrl;

public class ChineseAnalyticsPage extends Page {

    public ChineseAnalyticsPage() {
        this.url = new PageUrl("analytics/cn_lit");
    }

    @Override
    public boolean at() {
        return detailPageTitle.waitUntilVisible();
    }
    public final  Element chineseAnalyticsprimePromomsg = $(".cost_chart_promo_holder p:contains('Chinese Litigation analytics are available for Elite users and above')");
    public final  Element chineseAnalyticsanonymousPromomsg = $("a.reveal_login_from_grey_out:contains('sign in')");

    public final Element detailPageTitle = $(".presenter-name-cls.detail-page-title:visible");

}
