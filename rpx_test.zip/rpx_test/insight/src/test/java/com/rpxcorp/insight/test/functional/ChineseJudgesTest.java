package com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.DocketEntryPage;
import com.rpxcorp.insight.page.detail.ChineseJudgeDetailPage;
import com.rpxcorp.insight.page.detail.ChineseLitigationDetailPage;
import com.rpxcorp.insight.page.detail.EntityDetailPage;
import com.rpxcorp.insight.page.detail.PatentDetailPage;
import com.rpxcorp.oldtest.page.DBData;
import com.rpxcorp.testcore.Authenticate;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.sql.ResultSet;
import java.util.ArrayList;

@Authenticate(role = "MEMBER")
public class ChineseJudgesTest extends BaseFuncTest {
    ChineseJudgeDetailPage chineseJudgePage;
    ResultSet intialExpectedTableValue;
    String dataId, dataUrl;
    DBData db = null;
    String id = null;
    ChineseLitigationDetailPage chineseLitDetailPage;
    EntityDetailPage entityDetailPage;
    PatentDetailPage patentDetailPage;
    DocketEntryPage docketPage;
    SoftAssert softAssert;

    @BeforeClass
    public void navigateJudgePage() throws Exception {
        db = new DBData();
    }

    /**
     * STATS SECTION
     **/

    @Test(priority = 100, groups = {"P2", "smoke"}, description = "RPX-14076: Chinese Judge Details Page - Part 2 - Stats")
    public void verifySectionInJudgePage() throws Exception {
        SoftAssert softAssert = new SoftAssert();
        String title[] = {"Litigations"};//"Judge Profile","Cases by Market Sector"
        this.urlData.put("ID", "1452038");
        to(chineseJudgePage, urlData);
        chineseJudgePage.sectionTitle.waitUntilVisible();
        softAssert.assertTrue(chineseJudgePage.metricsSection.isPresent(), "Metrics section is not present in the PTAB details page");
        ArrayList<String> sectionHeader = chineseJudgePage.sectionTitle.getAllData();
        softAssert.assertTrue(sectionHeader.get(0).contains(title[0]),
                "Title of Litigations section didn't match, Actual: " + sectionHeader.get(0) + "Expected: " + title[0]);
    }

    @Test(priority = 101, groups = "P2", description = "RPX-14076: Chinese Judge Details Page - Part 2 - Stats")
    public void verifyJudgePageTitle() throws Exception {
        to(chineseJudgePage, 1452038);
        assertEquals(getTitle().contains(chineseJudgePage.pageTitle.getText()), true,
                "Title of Page doesn't match with Judge Name");
    }

    @Test(priority = 102, groups = "P2", description = "Verify Chinese litigation metrics")
    public void verifyLitStaticsVsSectionsStatistics() throws Exception {
        to(chineseJudgePage, 1452038);
        chineseJudgePage.metricsSection.getElement("inactiveCasesCount").click();
        chineseJudgePage.loading.waitUntilInvisible();
        assertEquals(chineseJudgePage.metricsSection.getIntData("inactiveCasesCount"), chineseJudgePage.litSectionPlaitiffCount.getIntData(), "The Metrics Section in 'INACTIVE CASES' count is not matching with Litigation Section Inactive Cases Count");
    }

    /**
     * LITIGATION SECTION
     **/

    @BeforeGroups(groups = "cn_judges_litigation_section")
    public void loadLitigationSectionData() {
        this.urlData.put("ID", "1452038");
        to(chineseJudgePage, urlData);
        at(chineseJudgePage);
    }
    @Test(priority = 301, groups = {"P2", "cn_judges_litigation_section"}, description = "Validate litigation section table header")
    public void verifyLitigationTableHeader() throws Exception {
        String expHeader[] = {"Date Filed", "Case Name", "Case Number", "Closed Date"};
        chineseJudgePage.litigation_Section.waitUntilVisible();
        assertEquals((chineseJudgePage.litigation_Section.getHeaderData()), (expHeader),
                "Litigation table header is not as expected");
    }
    @Test(priority = 302, groups = {"P2", "cn_judges_litigation_section"}, description = "Validate litigation section case name link")
    public void verifyCaseNameLinkInLitigationTable() throws Exception {
        String caseNameInColumn = chineseJudgePage.litigation_Section.getColumnLinkText("Case Name");
        withNewWindow(chineseJudgePage.litigation_Section.getColumnLinkElem("Case Name"), () -> {
            at(chineseLitDetailPage);
            String caseNameDetailsPage = chineseLitDetailPage.title.getText();
            Assert.assertEquals(caseNameDetailsPage, caseNameInColumn,
                    "case name in table is not equal to details page case name");
        });
    }
    @Test(priority = 303, groups = {"P2", "cn_judges_litigation_section"}, description = "Validate litigation section case number link")
    public void verifyCaseNumberLinkInLitigationTable() throws Exception {
        String caseNoInColumn = chineseJudgePage.litigation_Section.getColumnLinkText("Case Number");
        withNewWindow(chineseJudgePage.litigation_Section.getColumnLinkElem("Case Number"), () -> {
            at(chineseLitDetailPage);
            String caseNoDetailsPage = chineseLitDetailPage.header_info.getData("docket_number");
            Assert.assertEquals(caseNoDetailsPage, caseNoInColumn,
                    "case number in table is not equal to details page case number");
        });
    }
    @BeforeGroups(groups = "cn_judges_litigation_section_sort")
    public void loadJudgeWithLitigationsForSort() {
        this.urlData.put("ID", "1452038");
        to(chineseJudgePage, urlData);
    }
    @Test(priority = 350, groups = {"P4", "cn_judges_litigation_section_sort","func_sorting"}, description = "Validate 'Date Filed' desc as default sort in litigation section")
    public void verifyDefaultSortInLitigationTable() {
        assertColumnSort("date", "desc", chineseJudgePage.litigation_Section.getColumn("Date Filed"));
    }

    @Test(priority = 351, groups = {"P4", "cn_judges_litigation_section_sort","func_sorting"}, description = "Validate litigation section all case sorting", dataProvider = "litigationsTableSortData")
    public void verifyAllCasesSortingInLitigationTable(String columnName, String sortType, String dataType)
            throws Exception {
        chineseJudgePage.litigation_Section.sort(columnName);
        assertColumnSort(dataType, sortType, chineseJudgePage.litigation_Section.getColumn(columnName));
    }

    @DataProvider
    public Object[][] litigationsTableSortData() {
        return new Object[][] { { "Date Filed", "asc", "date" }, { "Date Filed", "desc", "date" },
                { "Case Name", "asc", "non-date" }, { "Case Name", "desc", "non-date" },
                { "Case Number", "asc", "non-date" }, { "Case Number", "desc", "non-date" },
                { "Closed Date", "asc", "date" }, { "Closed Date", "desc", "date" } };
    }

    @Test(priority = 352, groups = "P2", description = "Verify by default English toggle option is selected")
    public void verifyENglishCHineseToggle() throws Exception {
        to(chineseJudgePage, 1452038);
        assertTrue(chineseJudgePage.englishToggleOption.isDisplayed(), "Tooltip for EN toggle button selected");
    }
    @Test(priority = 353, groups = "P2", description = "Verify Chinese toggle option")
    public void verifyCHineseToggleOption() throws Exception {
        to(chineseJudgePage, 1452038);
        chineseJudgePage.englishToggleOption.click();
        chineseJudgePage.chineseToggleOption.waitUntilVisible();
        assertTrue(chineseJudgePage.chineseToggleOption.isDisplayed(), "Tooltip for CN toggle button selected");
        assertTrue(chineseJudgePage.chineseTitle.isDisplayed(),"Title of the Judge showing in chinese language");
    }
    //TODO Search in Litigation Section
}