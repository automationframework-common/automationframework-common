package com.rpxcorp.insight.page.detail;

import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

public class ChineseJudgeDetailPage extends BaseDetailPage{

    public ChineseJudgeDetailPage() {
        this.url = new PageUrl("china/judges/{ID}");
    }
    public final Element sectionTitle = $(
            ".block-header h5.section-title");
    public final Element ChinesejudgePageUpgradePromoMessage = $("section#content div:contains('Start with a Free Trial')");

    public final StaticContent statsBarContent = $(".big-stats", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("active_petitions", ".active_counts");
                dataForm.content("inactive_petitions", ".inactive_counts");
            }
    );
    public final Element chineselitigationsSectionPromoMsg = $("#litigations_section .subscription-promo-message:contains(Start with a Free Trial)");
    public final Element chineselitigationsSectionSignOnMsg = $("#litigations_section .subscription-promo-message:contains(Sign In)");

    public final Table litigation_Section = $("#litigations-container .venue_judge_case_table", (Configure<Table>) table ->
            {
                table.uniqueId("td.case_title a");
                    table.nextPage("div#litigation-cases ul.pagination.pagination li:last-child");
                table.lastPage("div#litigation-cases ul.pagination.pagination li:nth-last-child(2)");
            }
    );

    public final Element activeLitigation = $(By.cssSelector("#active-case-type"));
    public final Element inactiveLitigation = $(By.cssSelector("#inactive-case-type"));
    public void click_active_filter_lits() {
        waitForPageLoad();
        if (!activeLitigation.isSelected()) {
            activeLitigation.click();
            waitForPageLoad();
        }
    }

    public final Element litSectionPlaitiffCount=$("div#litigation-cases div.metrics-round-shape");
    public final StaticContent metricsSection = $(".panel-metrics", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("activeCasesCount", ".metrics_card:contains(Active Cases) .count");
                dataForm.content("inactiveCasesCount", ".metrics_card:contains(Inactive Cases) .count");
            }
    );

    public void click_inactive_filter_lits() {
        waitForPageLoad();
        if (!inactiveLitigation.isSelected()) {
            inactiveLitigation.click();
            waitForPageLoad();
        }
    }
    public final Element englishToggleOption = $("ul.action-button li[oldtitle='Click to see party names in Chinese']");
    public final Element chineseToggleOption = $("ul.action-button li[oldtitle='Click to see party names in English']");
    public final Element chineseTitle = $("h1.section-title.chn_toggle:visible");

}
