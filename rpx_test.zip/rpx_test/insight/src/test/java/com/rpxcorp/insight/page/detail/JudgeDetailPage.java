package com.rpxcorp.insight.page.detail;

import com.rpxcorp.insight.module.ListPanel;
import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class JudgeDetailPage extends BasePage {

    public JudgeDetailPage() {
        this.url = new PageUrl("judge/{ID}");
    }

    @Override
    public boolean at() {
        waitForPageLoad();
        return detailPageTitle.waitUntilVisible();
    }

    public final Element judgeProfile =$("#judge_venue_profile h5:contains('Judge Profile')");
    public final Element judgePageUpgradePromoMessage = $("section#content div:contains('Judge page is not included in your current subscription. Please')>a:contains('upgrade')");
    public final Element sectionTitle = $("div.handle");
    public final Element panelTitle = $("div.panel.activity .section-title");
    public final Element judgeProfileTab = $(".tabs a");
    public final Element activeCase = $("#litigations-active-cases span");
    public final Element inactiveLitigation = $(By.cssSelector("#inactive-case-type"));
    public final Element activeLitigation = $(By.cssSelector("#active-case-type"));
    public final Element litigationCaseCount = $("#litigation-cases .metrics-round-shape");
    public final Element litigationCaseCountHeader = $("#litigation-cases .sub-section-title");
    public final Element loading = $(By.cssSelector(".blockUI.blockMsg.blockElement>img"));
    public final Element sortField = $(By.cssSelector(".sort_rows.collapsed span"));
    public final Element toggleIcon = $("#non_verdict_orders em:not([class='switch_view hide'])");
    public final Element orderFound = $("#litigation-orders .small-7.columns h2");
    public final Element overlay_Loading = $(By.cssSelector(".blockUI.blockOverlay"));
    public final Element caseType = $("div#litigation-cases .choose-box select#cases_type");
    public final Table ORDER_TABLE = $("#litigation-orders table", (Configure<Table>) table ->
        {
           table.nextPage("#litigation-orders ul.pagination.pagination li:last-child");
           table.lastPage("#litigation-orders ul.pagination.pagination li:nth-last-child(2)");
        }
    );

    // Filter Locator

    // Order Tab
    public final Element orderTabNonVenueFilterIcon = $("#non_venue_orders .icon-cog2");
    public final Element orderTabFromDate = $("#non_venue_orders-from_filed_date");
    public final Element orderTabToDate = $("#non_venue_orders-to_filed_date");

    // Close Form
    public final Element orderTabCloseButton = $(
            "*[data-target='non_venue_orders'] a.small.button.secondary.close-reveal-modal.cancel_btn");
    public final Element orderTabApplyButton = $(
            ".modal-content *[data-target='non_venue_orders'] input[value='Apply']");

    // Date
    public final Element orderTabMonthDateSelector = $(".ui-datepicker-month");
    public final Element orderTabYearDateSelector = $(".ui-datepicker-year");
    public final Element orderTabDayDateSelector = $("td[data-event='click'] .ui-state-default");

    public final Element orderTabCaseType = $(
            By.xpath("//*[@data-target='non_venue_orders']//*[contains(text(), 'Case Type')]//..//button"));
    public final Element orderTabCaseTypeSelectedValue = $(
            By.xpath("//*[@data-target='non_venue_orders']//*[contains(text(), 'Case Type')]//..//button/span"));
    public final Element orderTabCaseTypeInput = $(By.xpath(
            "//*[@data-target='non_venue_orders']//*[contains(text(), 'Case Type')]//..//div[@class='ms-drop bottom']//label"));

    // Jury Verdicts Tab
    public final Element juryVerdictsTabVenueFilterIcon = $("#venue_orders .icon-cog2");
    public final Element juryVerdictsTabfromDate = $("#venue_orders-from_filed_date");
    public final Element juryVerdictsTabToDate = $("#venue_orders-to_filed_date");
    public final Element juryVerdictsFilterOptions = $("#facet-search-modal-venue_orders p");
    public final Element juryVerdictsPrevailingPartyTypeBtn = $(
            "#facet-search-modal-venue_orders .order_verdict_side .ms-parent.margin-bottom>button");
    public final Element juryVerdictsPrevailingPartyTypeOptions = $(
            "#facet-search-modal-venue_orders .order_verdict_side .ms-drop.bottom li:not([class='ms-select-all'])");
    public final Element juryVerdictsPrevailingPartyTypeSelectedOptions = $(
            "#facet-search-modal-venue_orders .order_verdict_side .ms-drop.bottom li[class='selected']");
    public final Element juryVerdictsPrevailingPartyTypeDeSelectedOptions = $(
            "#facet-search-modal-venue_orders .order_verdict_side .ms-drop.bottom li:not([class='ms-select-all']):not([class='selected'])");
    // Close Form
    public final Element juryVerdictsTabFilterCloseButton = $(
            "*[data-target='venue_orders'] a.small.button.secondary.close-reveal-modal.cancel_btn");
    public final Element juryVerdictsTabFilterApplyButton = $(
            ".modal-content *[data-target='venue_orders'] input[value='Apply']");

    // Table Locator
    public final Element docketLink = $("#litigation-orders td:nth-child(3) a[target='_blank']");

    // Document
    public final Element documentLink = $("#litigation-orders .document");

    public final Element judgeprofilePromoMsg = $("img[src*='assets/judges_orders_verdicts']+div.subscription-promo-message-container-mask+div.subscription-promo-message:contains('Start with a Free Trial')");
    public final Element judgeprofileSignOnMsg = $("img[src*='assets/judges_orders_verdicts']+div.subscription-promo-message-container-mask+div.subscription-promo-message:contains('Sign In')");
    public final Element litigationsSectionPromoMsg = $("div#litigations_section div.subscription-promo-message:contains(Start with a Free Trial)");
    public final Element litigationsSectionSignOnMsg = $("div#litigations_section div.subscription-promo-message:contains(Sign In)");

    // Graph Element
    public final Element ordersChart = $("#outcome_stats");
    public final Element graphXAxisLegend = $(".highcharts-legend .highcharts-legend-item text");
    public final Element graphXAxisLabelText = $("#outcome_stats .highcharts-axis-labels.highcharts-xaxis-labels text");

    public final Element orderOutcomeData[] = { $(".quick-outcome-stats tbody>tr td:nth-of-type(2)"),
            $(".quick-outcome-stats tbody>tr td:nth-of-type(3)"), $(".quick-outcome-stats tbody>tr td:nth-of-type(4)"),
            $(".quick-outcome-stats tbody>tr td:nth-of-type(5)") };
    public final Element graphEmptyText = $(".highcharts-no-data tspan");
    public final Element overloading = $(".blockUI.blockOverlay");

    // Graph Chart
    public final Element grantedChart = $(
            ".non_verdict_outcome_stats .highcharts-series.highcharts-series-0.highcharts-tracker");
    public final Element deniedChart = $(
            ".non_verdict_outcome_stats .highcharts-series.highcharts-series-1.highcharts-tracker");
    public final Element partialChart = $(
            ".non_verdict_outcome_stats .highcharts-series.highcharts-series-2.highcharts-tracker");
    public final Table LITIGATION_TABLE = new Table(
            "#litigations_section .clickable-rows.table_section.venue_judge_case_table");
    public final Element litigationSearchBox = $("span.search_text_container input.search_text");
    public final Table ORDER_SUBTABLE = new Table("#litigation-orders .case_details table");

    // Graph table
    public final Table orderTableOutcomeStat = new Table(".quick-outcome-stats");
    public final Element orderTableLegend = $(".highcharts-legend .highcharts-legend-item rect");

    public final Element orderTableGrantedLegend = $(".highcharts-legend .highcharts-legend-item:nth-of-type(1) rect");
    public final Element orderTableDeniedLegend = $(".highcharts-legend .highcharts-legend-item:nth-of-type(2) rect");
    public final Element orderTablePartialLegend = $(".highcharts-legend .highcharts-legend-item:nth-of-type(3) rect");

    // Jury Verdicts - Bar Graph
    public final Element juryVerdictStatChart = $(
            "#verdict_stats .highcharts-series.highcharts-series-0.highcharts-tracker rect");
    public final Element juryVerdictLegend = $("#verdict_stats .highcharts-axis-labels.highcharts-xaxis-labels text");

    // Order Tabe - Bar Graph
    String granted = "#highcharts-2 .highcharts-series.highcharts-series-0.highcharts-tracker rect";
    String denied = "#highcharts-2 .highcharts-series.highcharts-series-1.highcharts-tracker rect";
    String partial = "#highcharts-2 .highcharts-series.highcharts-series-2.highcharts-tracker rect";

    // Order Graph Dialog
    public final Element ordersDialog = $("#non_verdict_orders_table_content");
    public final Element verdictDialog = $("#verdict_orders_table_modal div.small-7.columns h2");
    public final Element orderDialogBreadcrumbs = $(".reveal-modal.xlarge.facet-search-modal.open ul.breadcrumbs-custom>li");

    // Order Graph Table Data
    public final Element noDataForOrdersTable = $(
            ".reveal-modal.xlarge.facet-search-modal.open table.no_order_found tr>td");// No
                                                                                       // data
                                                                                       // found
    public final Element ordersTableHeading = $(
            "#non_verdict_orders_table_content h5.no-of-found");
    public final Table ordersTable = $(
            ".reveal-modal.xlarge.facet-search-modal.open #non_verdict_orders_table_content table",Table.class);
    public final Element grantedChartBarValue = $(granted);
    public final Element deniedChartBarValue = $(denied);
    public final Element partialChartBarValue = $(partial);
    public final String grantedChartBar = "#outcome_stats .highcharts-data-labels.highcharts-series-0.highcharts-tracker text";
    public final String deniedChartBar = "#outcome_stats .highcharts-data-labels.highcharts-series-1.highcharts-tracker text";
    public final String partialChartBar = "#outcome_stats .highcharts-data-labels.highcharts-series-2.highcharts-tracker text";
    public final Element grantedChartBarText = $(grantedChartBar);
    public final Element deniedChartBarText = $(deniedChartBar);
    public final Element partialChartBarText = $(partialChartBar);

    public final Element grantedChartBarGraph = $(grantedChartBar + " tspan");
    public final Element deniedChartBarGraph = $(deniedChartBar + " tspan");
    public final Element partialChartBarGraph = $(partialChartBar + " tspan");

    public final Element grantedChartBars = $("#highcharts-2 g.highcharts-series rect[fill='#f0982d]");
    public final Element deniedChartBars = $(
            "#highcharts-2 .highcharts-data-labels.highcharts-series-1.highcharts-tracker tspan");
    public final Element partialChartBars = $(
            "#highcharts-2 .highcharts-data-labels.highcharts-series-2.highcharts-tracker tspan");
    public final Element closeOrderFilter = $("#non_verdict_orders_table_modal .close-reveal-modal");
    public final Element closeVerdictFilter = $("#verdict_orders_table_modal .close-reveal-modal");
    // Tooltip -Jury Verdict
    public final Element toolTipName = $("div.highcharts-tooltip span span");
    public final Element toolTipCount = $("div.highcharts-tooltip span td");

    // Header - Jury Verdict Count
    public final Element totalVerdictCount = $("#venue-verdicts h2");

    public final StaticContent judge_Detail = $(".entity-stats", (Configure<StaticContent>) dataForm ->
        {
            dataForm.content("Active Case", "div.metrics_card:contains(Active Case)");
            dataForm.content("Inactive Case", "div.metrics_card:contains(Inactive Cases) .count");
            dataForm.content("Average Cases per Year", "div.metrics_card:contains(Avg Cases Per Year) .count");
            dataForm.content("Average Case Length", "div.metrics_card:contains(Avg Case Length) .count");
        }
    );

    public final Table cases_By_Market_Sector = $("ul.bar-graph", (Configure<Table>) table ->
        {
            table.uniqueId("div.graph-label");
            table.column("count", " .graph-count ");
        }
    );

    public final Table litigation_Section = $("#litigations-container .venue_judge_case_table", (Configure<Table>) table ->
        {
            table.uniqueId("td.case_title a");
           table.nextPage("div#litigation-cases ul.pagination.pagination li:last-child");
           table.lastPage("div#litigation-cases ul.pagination.pagination li:nth-last-child(2)");
        }
    );
    public final Element litigation_section_all_cases_radioBtn = $("#litigation-cases #all-case-type");
    public final Element litigation_section_active_cases_radioBtn = $("#litigation-cases #active-case-type");
    public final Element litigation_section_inActive_cases_radioBtn = $("#litigation-cases #inactive-case-type");

    public final Element litCaseFilterButtonGroup = $("#litigations_section .choose-cases-type span label");
    public final Element litCaseSelectedFilterOption = $("#litigation-cases span>input[checked='checked']+label");
    public final Element litigationCaseTitle = $("#litigations_section td.case_title>a");
    public final Element litigationCaseNumber = $("#litigations_section td:nth-of-type(3)>a");
    public final Element litigationClearBtn = $("#litigations_section a#clear_search_form");
    public final Element litigationSearchBtn = $("div.search_container span.search_action_container input[name='commit']");
    public final Element switchViewButtonForJuryVerdictsTab = $(
            "#venue_orders em:not([class='switch_view hide'])>span");
    public final Table juryVerdictsTable = $("#jury_verdicts #venue-verdicts table", (Configure<Table>) table ->
        {
           table.nextPage("#jury_verdicts ul.pagination.pagination li:last-child");
           table.lastPage("#jury_verdicts ul.pagination.pagination li:nth-last-child(2)");
            table.subTable(new Table("#jury_verdicts #venue-verdicts table table.nested_inner_table"));
            table.expandSubTableLink("img.open");
        }
    );
    public final Element juryVerdictsTab = $(".tabs>dd:nth-of-type(2)>a");
    public final Element juryVerdictsTableTitle = $("#venue-verdicts h2");
    public final Element docketDocument = $("#jury_verdicts #venue-verdicts table a.document");
    public final Element docketNumberLnk = $("#jury_verdicts #venue-verdicts table tr>td:nth-of-type(3)>a");
    public final Element judgeLnk = $("#jury_verdicts #venue-verdicts table tr>td:nth-of-type(4)>a");
    public final Element errorHeader = $(".large-12.columns>h1");
    public final Table outcomeTable = new Table(".quick-outcome-stats");

    public void click_active_filter_lits() {
        waitForPageLoad();
        if (!activeLitigation.isSelected()) {
            activeLitigation.click();
            waitForPageLoad();
        }
    }

    public void click_inactive_filter_lits() {
        waitForPageLoad();
        if (!inactiveLitigation.isSelected()) {
            inactiveLitigation.click();
            waitForPageLoad();
        }
    }

    public String getToggleIconText() {
        return toggleIcon.getText();
    }

    public void toggleAllSubTable() {
        ((JavascriptExecutor) (getDriver())).executeScript("$('.open.cursor-pointer').click();");
    }

    public List<String> getLegendText() {
        return graphXAxisLegend.getAllData();
    }

    public List<String> getXAxisLabelText() {
        return graphXAxisLabelText.getAllData();
    }

    public void toggleView() {
        ((JavascriptExecutor) (getDriver())).executeScript("$('.icon-stats-bars4').click();");
    }

    public void clickOnAllCasesInLitgationSection() {
        if (!litigation_section_all_cases_radioBtn.isSelected()) {
            litigation_section_all_cases_radioBtn.click();
            loading.waitUntilInvisible();
        }
    }

    public void clickOnActiveCasesInLitgationSection() {
        if (!litigation_section_active_cases_radioBtn.isSelected()) {
            litigation_section_active_cases_radioBtn.click();
            loading.waitUntilInvisible();
        }
    }

    public void clickOnInActiveCasesInLitgationSection() {
        if (!litigation_section_inActive_cases_radioBtn.isSelected()) {
            litigation_section_inActive_cases_radioBtn.click();
            loading.waitUntilInvisible();
        }
    }

    /**
     * Apply Litigation case Type Filter based on filterOption name
     * 
     * @author pusulurip
     * @param filterOption
     */
    public void applyCaseFilterForLitigation(String filterOption) {
        caseType.waitUntilVisible();
        caseType.selectByOption(filterOption);
        loading.waitUntilInvisible();
    }
//        if (!litCaseSelectedFilterOption.getText().equalsIgnoreCase(filterOption)) {
//            for (WebElement filterButton : litCaseFilterButtonGroup.getElements()) {
//                if (filterButton.getText().equalsIgnoreCase(filterOption)) {
//                    filterButton.click();
//                    loading.waitUntilInvisible();
//                    break;
//                }
//            }
//        }


    /**
     * Do clear and search in Litigation Table
     * 
     * @author pusulurip
     * @param searchKey
     */
    public final Element clearButton = $("span.search_action_container a#clear_docket_form");
    public void searchInLitigationTable(String searchKey) {
        if (!clearButton.isDisplayed()) {
            searchBtnClickInLitigationTable(searchKey);
        }else {
            clearButton.click();
            loading.waitUntilInvisible();
            clearButton.waitUntilInvisible();
            searchBtnClickInLitigationTable(searchKey);
        }
    }

    /**
     * Do Search in Litigation Table
     * 
     * @author pusulurip
     * @param
     * 
     */
    public void searchBtnClickInLitigationTable(String searchKey) {
        litigationSearchBox.sendKeys(searchKey);
        litigationSearchBtn.click();
        loading.waitUntilInvisible();
    }

    /**
     * Click on Jury Verdicts Tab
     * 
     * @author pusulurip
     */
    public void clickOnJuryVerdictsTab() {
        clickOnTab("Jury Verdicts");
    }

    /**
     * Switch to Jury Verdicts Table View
     * 
     * @param viewType
     * @author pusulurip
     */
    public void clickOnswitchViewForJuryVerdicts(String viewType) {
        if (switchViewButtonForJuryVerdictsTab.getText().equalsIgnoreCase(viewType)) {
            switchViewButtonForJuryVerdictsTab.click();
        }
    }

    /**
     * Get Jury Verdict Graph Value
     * 
     * @return
     * @throws InterruptedException
     */
    public Map<String, Integer> getJuryVerdictsGraphValue() throws InterruptedException {
        int numberOfBar = juryVerdictStatChart.getElements().size();
        Map<String, Integer> graphValue = new HashMap<String, Integer>();
        Element bar = null;
        for (int nBar = 1; nBar <= numberOfBar; nBar++) {
            bar = $(String.format(
                    "#verdict_stats .highcharts-series.highcharts-series-0.highcharts-tracker rect:nth-child(%d)",
                    nBar));
            bar.click();
            bar.waitUntilClickable();
            Actions actions = new Actions(getDriver());
            actions.moveToElement(bar.getElement()).build().perform();
            toolTipName.waitUntilVisible();
            graphValue.put(toolTipName.getText(), Integer.parseInt(toolTipCount.getElements().get(1).getText()));
        }
        return graphValue;
    }

    public Map<String, Integer> getOrderTabToolTipTextValue() throws InterruptedException {
        int numberOfBar = grantedChartBarValue.getElements().size();
        Map<String, Integer> graphValue = new HashMap<String, Integer>();
        Element bar = null;
        for (int nBar = 1; nBar <= numberOfBar; nBar++) {
            bar = $(String.format(granted + ":nth-child(%d)", nBar));
            Thread.sleep(1000);
            // bar.click();
            bar.waitUntilClickable();
            Actions actions = new Actions(getDriver());
            actions.moveToElement(bar.getElement()).build().perform();
            toolTipName.waitUntilVisible();
            graphValue.put(toolTipName.getText(), Integer.parseInt(toolTipCount.getElements().get(1).getText()));
        }
        return graphValue;
    }

    /**
     * Disable all bar shown in Order Tab
     */
    public void disableOrderTabBar() {
        ((JavascriptExecutor) (getDriver()))
                .executeScript("$(\"#highcharts-2 .highcharts-legend rect[fill='#007dc3']\").click();");
        ((JavascriptExecutor) (getDriver()))
                .executeScript("$(\"#highcharts-2 .highcharts-legend rect[fill='#f0982d']\").click();");
        ((JavascriptExecutor) (getDriver()))
                .executeScript("$(\"#highcharts-2 .highcharts-legend rect[fill='#2b3b98']\").click();");
    }

    /**
     * Enable all bar shown in Order Tab
     */
    public void enableOrderTabBar() {
        ((JavascriptExecutor) (getDriver()))
                .executeScript("$(\"#highcharts-2 .highcharts-legend rect[fill!='#ccc']\").click();");
    }

    /**
     * Select date from calender
     * 
     * @param month
     * @param year
     * @param day
     */
    public void selectDate(String month, String year, int day) {
        orderTabMonthDateSelector.waitUntilVisible();
        Select selectMonth = new Select(orderTabMonthDateSelector.getElement());
        selectMonth.selectByVisibleText(month);
        Select selectYear = new Select(orderTabYearDateSelector.getElement());
        selectYear.selectByVisibleText(year);
        orderTabDayDateSelector.getElements().get(day - 1).click();
    }

    /**
     * Select Case Type
     * 
     * @param caseType
     */
    public void selectCaseType(String caseType) {
        orderTabCaseType.click();
        orderTabCaseTypeInput.waitUntilVisible();
        for (WebElement element : orderTabCaseTypeInput.getElements()) {
            if (element.getText().equalsIgnoreCase(caseType)) {
                element.click();
                break;
            }
        }
    }

    /**
     * To get Options from PrevailingPartyType dropdown
     * 
     * @author pusulurip
     * @param requiredOption
     * @return
     */
    public List<String> getOptionFromPrevailingPartyType(String requiredOption) {
        juryVerdictsPrevailingPartyTypeBtn.click();
        juryVerdictsPrevailingPartyTypeOptions.waitUntilVisible();
        List<String> dataList = new ArrayList<String>();
        switch (requiredOption) {
        case "All OPTIONS":
            dataList = juryVerdictsPrevailingPartyTypeOptions.getAllData();
            break;
        case "SELECTED OPTIONS":
            dataList = juryVerdictsPrevailingPartyTypeSelectedOptions.getAllData();
            break;
        case "DE SELECTED OPTIONS":
            dataList = juryVerdictsPrevailingPartyTypeDeSelectedOptions.getAllData();
            break;
        }
        return dataList;

    }

    /**
     * click on outcome type(Granted/Denied/Partial) element which has data
     * 
     * @param outComeType
     *            Granted/Denied/Partial
     * @param indexOfGraph
     *            1 for Transfers outcome type,2 for Stay outcome type,3 for
     *            Summary Judgment outcome type and 4 for JMOL outcome type
     * @return
     * @throws InterruptedException
     */
    public void clickOnOutComeGraph(String outComeType, int indexOfGraph) throws InterruptedException {
        waitForRequestInit();
        WebElement graph = null;
        switch (outComeType.toUpperCase()) {
        case "GRANTED":
            graph = getDriver().findElements(By.cssSelector(grantedChartBar)).get(indexOfGraph);

            break;
        case "DENIED":
            graph = getDriver().findElements(By.cssSelector(deniedChartBar)).get(indexOfGraph);
            break;
        case "PARTIAL":
            graph = getDriver().findElements(By.cssSelector(partialChartBar)).get(indexOfGraph);
            break;
        }

        Actions builder = new Actions(getDriver());
        builder.click(graph).build().perform();

        Thread.sleep(5000);
    }

    /**
     * Verify Breadcrumbs OrderType>OutcomeType data in Orders graph dailog
     * 
     * @param outComeType
     *            - Granted/Denied/Partial
     * @param indexOfGraph
     *            - Order Type index
     * @param isOutComeOrderDialog
     *            - true if outcome based order dialog else false
     * @return
     * @author pusulurip
     */
    public void verifyBreadcrumbsDataForOrderDialog(String outComeType, int indexOfGraph,
            boolean isOutComeOrderDialog) {
        String orderTypes[] = { "Preliminary Injunction", "Permanent Injunction", "Summary judgment", "JMOL" };
        orderDialogBreadcrumbs.waitUntilVisible();
        Assert.assertTrue(orderDialogBreadcrumbs.getAllData().get(0).equalsIgnoreCase(orderTypes[indexOfGraph]),
                orderTypes[indexOfGraph] + " order type in not available in Orders dialog Breadcrumbs");
        if (isOutComeOrderDialog) {
            Assert.assertTrue(orderDialogBreadcrumbs.getAllData().get(1).equalsIgnoreCase(outComeType),
                    outComeType + " Outcome for Order " + orderTypes[indexOfGraph]
                            + "is in not available in Orders dialog Breadcrumbs");
        }

    }

    /**
     * Click on Filter expand button to see filter options
     * 
     * @author pusulurip
     */
    public void expandFilterOptionsInDialog() {
        filterHeading.waitUntilVisible();
        if (filterHeading.getAttribute("aria-expanded").contains("false")) {
            JavascriptExecutor js = (JavascriptExecutor) getDriver();
            js.executeScript("$('.follow-content a.facet_button').click();");
        }
    }

    /**
     * Click on Filter expand button to collapse filter options
     * 
     * @author pusulurip
     */
    public void collapseFilterOptionsInDialog() {
        filterHeading.waitUntilVisible();
        if (filterHeading.getAttribute("aria-expanded").contains("true")) {
            JavascriptExecutor js = (JavascriptExecutor) getDriver();
            js.executeScript("$('.follow-content a.facet_button').click();");
        }
    }

    /**
     * Get list of Labels in Filter section
     * 
     * @return
     * @author pusulurip
     */
    public ArrayList<String> getFilterOptionInDialog() {
        expandFilterOptionsInDialog();
        return filterOptionNames.getAllData();
    }

    /**
     * Get Options List for CaseType,Filling Role Type,MarketSector and Motion
     * SubType
     * 
     * @param optionDiv
     * @param requiredOption
     * @return
     * @author pusulurip
     */
    public ArrayList<String> getFilterDropDownOptionsInDialog(String optionDiv, String requiredOption) {
        ArrayList<String> dataList = new ArrayList<String>();

        switch (requiredOption) {
        case "ALL":// ms-select-all
            dataList = $(optionDiv + " div[class*='ms-drop'] li:not([class='ms-select-all']) label").getAllData();
            break;
        case "SELECTED OPTIONS":
            dataList = $(optionDiv + " div[class*='ms-drop'] li[class^='selected'] label").getAllData();
            break;
        case "DE SELECTED OPTIONS":
            dataList = $(optionDiv + " div[class*='ms-drop'] li[class=' '] label").getAllData();
            break;
        }
        return dataList;
    }

    /**
     * @param optionDiv
     * @author Gandhimathi
     */
    public void clickOnDropDown(String optionDiv) {
        $(optionDiv + " .ms-choice div").click();
        $(optionDiv + " div.open").waitUntilVisible();
    }

    /**
     * @param text
     * @author Gandhimathi
     * @return index
     */
    public int getOrderIndex(String text) {
        List<String> axisList = getXAxisLabelText();
        int index = 1;
        for (String orderText : axisList) {
            if (orderText.equalsIgnoreCase(text.trim()))
                break;
            index++;
        }
        return index;
    }

    /**
     * @param orderText
     * @author Gandhimathi
     */
    public void clickOnOrdersText(String orderText) {
        overlay_Loading.waitUntilNoElementPresent();
    	ordersDialog.waitUntilInvisible();
        try{Thread.sleep(1000);}
        catch (Exception e){

        };
        graphXAxisLabelText.getElements().get((getOrderIndex(orderText) - 1)).click();
        try{Thread.sleep(1000);}
        catch (Exception e){

        };
        ordersDialog.waitUntilVisible();
        loading.waitUntilInvisible();
        overlay_Loading.waitUntilInvisible();
    }

    /**
     * @param option,numberOfOptions
     * @author Gandhimathi
     */
    public void selectOptionsFromDropDown(String option, int numberOfOptions) {
        for (int i = 0; i < numberOfOptions; i++)
            $(option + " li:not([class='ms-select-all']):not([class='group']):visible").getElements().get(i).click();
    }

    public void getHyphenedData(String option) {
        List<WebElement> options = $(
                option + " li:not([class='ms-select-all']):not([class='group']):not([class*='selected'])")
                        .getElements();
        for (WebElement opt : options)
            if (opt.getText().contains("-")) {
                ((JavascriptExecutor) getDriver()).executeScript(
                        "arguments[0].scrollIntoView(true);", opt);
                opt.click();
                break;
            }
    }

    public String breadCrumData(ArrayList<String> options) {
        String breadCrum = "";
        Collections.sort(options);
        for (int i = 0; i <= options.size(); i++) {
            if (i < 3) {
                breadCrum = breadCrum + options.get(i);
                if (i < 2)
                    breadCrum = breadCrum + ", ";
            }

            if (i == 4) {
                breadCrum = breadCrum + " and more";
                break;
            }
        }
        return breadCrum;
    }

    public int getOutcomeIndex(String outcome) {
        String[] types = { "granted", "denied", "partial" };
        return Arrays.asList(types).indexOf(outcome.toLowerCase());
    }

    /**
     * @param orderName,outcome
     * @author Gandhimathi
     */
    public void clickOnOutcomeTable(String orderName, String outcome) {
        overlay_Loading.waitUntilNoElementPresent();
    	ordersDialog.waitUntilInvisible();
        try{Thread.sleep(1000);}
        catch (Exception e){

        };
        $(".quick-outcome-stats tr:nth-of-type(" + (getOutcomeIndex(outcome) + 1) + ") .stat-order-value:nth-of-type("
                + (getOrderIndex(orderName) + 1) + ") a").click();
        try{Thread.sleep(1000);}
        catch (Exception e){

        };
        ordersDialog.waitUntilVisible();
        loading.waitUntilInvisible();
        overlay_Loading.waitUntilInvisible();
    }

    public void clickVerdictsTab() {
        $("a[href='#jury_verdicts'").click();
        loading.waitUntilInvisible();
        overlay_Loading.waitUntilInvisible();
    }

    public void clickOnVerdictOutcome(String outcome) {
        if (!$("#verdict_stats .highcharts-axis-labels").isDisplayed()) {
            clickVerdictsTab();
        }
        $("#verdict_stats .highcharts-axis-labels text:nth-of-type(" + getVerdictIndex(outcome) + ")").click();
        verdictDialog.waitUntilVisible();
        loading.waitUntilInvisible();
        overlay_Loading.waitUntilInvisible();
    }

    public int getVerdictIndex(String outcome) {
        String[] types = { "PLAINTIFF PATENTEE", "PLAINTIFF NON PATENTEE", "DEFENDANT PATENTEE", "UNAVAILABLE" };
        return Arrays.asList(types).indexOf(outcome) + 1;
    }

    public void closePopup() {
        if (closeOrderFilter.isDisplayed()) {
            closeOrderFilter.click();
        }
    }

    public void closeVerdictPopup() {
        if (closeVerdictFilter.isDisplayed()) {
            closeVerdictFilter.click();
        }
    }

    public final Table judge_orders_table = $(
            "#non_verdict_orders_table_content .nested_data_table.venue_judge_case_table", (Configure<Table>) table ->
        {
            table.uniqueId("td a[data-nested-tableurl]");
           table.nextPage("#non_verdict_orders_table_content ul.pagination.pagination li:last-child");
           table.lastPage("#non_verdict_orders_table_content ul.pagination.pagination li:nth-last-child(2)");
            table.expandSubTableLink("img.open");
            table.row(".nested_data_table.venue_judge_case_table>tbody>tr[class]");
            table.subTable($("table.nested_inner_table", (Configure<Table>) subTable ->
                {
                    subTable.uniqueId("td:nth-child(1) a[href]; td:nth-child(2);td:nth-child(5);td:nth-child(4)");
                }));
        });

    public final Table judge_verdicts_table = $(
            "#verdict_orders_table_content .nested_data_table.venue_judge_case_table", (Configure<Table>) table ->
        {
            table.uniqueId("td a[data-nested-tableurl]");
           table.nextPage("#verdict_orders_table_content ul.pagination.pagination li:last-child");
           table.lastPage("#verdict_orders_table_content ul.pagination.pagination li:nth-last-child(2)");
            table.expandSubTableLink("img.open");
        }
    );

    public final Element orders_modal_close = $("#non_verdict_orders_table_modal .close-reveal-modal");
    public final Element orders_doc_icon = $("#non_verdict_orders_table_modal .venue_judge_case_table td .document");

    /**
     * Return Order Out come(Granted/Denied/Partial) values from graph bar for
     * all order types(Transfer/Stay/Summary judgment/JMOL)
     * 
     * @param outComeGraphName
     * @return
     */
    public ArrayList<String> getOrderOutComeGraphValues(String outComeGraphName) {
        ArrayList<String> data = null;

        switch (outComeGraphName.toUpperCase()) {
        case "GRANTED":
            data = grantedChartBarText.getAllData();
            break;
        case "DENIED":
            data = deniedChartBarText.getAllData();
            break;
        case "PARTIAL":
            data = partialChartBarText.getAllData();
            break;
        }

        return data;
    }

    public void changeOutComeState(Element outcomeType, Element outcomeGraph, boolean isEnable) {
        if (isEnable) {
            if (outcomeType.getAttribute("fill").equalsIgnoreCase("#cccccc")) {
                outcomeType.click();
                outcomeGraph.waitUntilVisible();
            }
        } else {
            if (!outcomeType.getAttribute("fill").equalsIgnoreCase("#cccccc")) {
                outcomeType.click();
                outcomeGraph.waitUntilInvisible();
            }

        }
    }

    public void enableOrderOutcomeGraphs(String outComeGraphName) {
        switch (outComeGraphName.toUpperCase()) {
        case "GRANTED":
            changeOutComeState(orderTableGrantedLegend, grantedChart, true);
            changeOutComeState(orderTableDeniedLegend, deniedChart, false);
            changeOutComeState(orderTablePartialLegend, partialChart, false);

            break;
        case "DENIED":
            changeOutComeState(orderTableGrantedLegend, grantedChart, false);
            changeOutComeState(orderTableDeniedLegend, deniedChart, true);
            changeOutComeState(orderTablePartialLegend, partialChart, false);

            break;
        case "PARTIAL":
            changeOutComeState(orderTableGrantedLegend, grantedChart, false);
            changeOutComeState(orderTableDeniedLegend, deniedChart, false);
            changeOutComeState(orderTablePartialLegend, partialChart, true);

            break;
        case "ENABLE ALL":
            changeOutComeState(orderTableGrantedLegend, grantedChart, true);
            changeOutComeState(orderTableDeniedLegend, deniedChart, true);
            changeOutComeState(orderTablePartialLegend, partialChart, true);
            break;
        case "DISABLE ALL":
            changeOutComeState(orderTableGrantedLegend, grantedChart, false);
            changeOutComeState(orderTableDeniedLegend, deniedChart, false);
            changeOutComeState(orderTablePartialLegend, partialChart, false);
            break;
        }
    }

    public final Element ORDERS_OUTCOME = $("#orders_content .quick-outcome-stats ", (Configure<Table>) table ->
        {
            table.uniqueId("td:nth-child(1)");
            table.column("preliminary_injunction", "td:nth-child(2)");
            table.column("permanent_injunction", "td:nth-child(3)");
            table.column("summary_judgement", "td:nth-child(4)");
            table.column("jmol", "td:nth-child(5)");
        }
    );

    public void viewOrdersTable(String type, String outcome) {
        if (outcome.length() > 0 && outcome != null)
            clickOnOutcomeTable(type, outcome);
        else
            clickOnOrdersText(type);
    }

    public void closeOrdersTable() {
        orders_modal_close.click();
        ordersDialog.waitUntilInvisible();
    }

    public int getRandomNumber(int max) {
        Random ran = new Random();
        int index = ran.nextInt(max);
        System.out.println(index);
        return index;
    }

    public static final String grantedGraph = "#outcome_stats .highcharts-data-labels.highcharts-series-0.highcharts-tracker>g:nth-of-type(";
    public static final String deniedGraph = "#outcome_stats .highcharts-data-labels.highcharts-series-1.highcharts-tracker>g:nth-of-type(";
    public static final String partialGraph = "#outcome_stats .highcharts-data-labels.highcharts-series-2.highcharts-tracker>g:nth-of-type(";
    public static final String[] graphs = { grantedGraph, deniedGraph, partialGraph };
    public final Element orderGraph = $(
            "#outcome_stats #highcharts-0 .highcharts-series-group .highcharts-tracker rect");

    // GET ORDER GRAPH PERCENTAGE VALUES BASED ON ORDER TYPE TEXT
    public HashMap<String, List<String>> getGraphPercentage(String orderType) throws Exception {
        HashMap<String, List<String>> graphData = new HashMap<String, List<String>>();
        String index = String.valueOf(graphXAxisLabelText.getAllData().indexOf(orderType) + 1);
        Thread.sleep(2000);
        List<String> data = new ArrayList<String>();
        for (int i = 0; i < graphs.length; i++) {
            if (!$(graphs[i] + index + ") text").getText().equals("")) {
                data.add($(graphs[i] + index + ") text").getText());
            } else {

                data.add("0%");
            }
        }
        graphData.put(orderType, data);
        return graphData;
    }

    // GET PERCENTAGE OF ORDER OUTCOME BASED ON GRAPH TABLE DATA CALCULATION
    public HashMap<String, List<String>> getTableDataInPercentage(String orderType) {
        HashMap<String, List<String>> tableData = new HashMap<String, List<String>>();
        int index, total = 0;
        List<String> percentageFromTable = new ArrayList<String>();
        index = graphXAxisLabelText.getAllData().indexOf(orderType);
        List<Integer> columnDataForOutComeTable = orderOutcomeData[index].getAllDataInInteger();
        for (int i = 0; i < columnDataForOutComeTable.size(); i++) {
            total = columnDataForOutComeTable.get(i) + total;
        }
        for (int i = 0; i < columnDataForOutComeTable.size(); i++) {
            percentageFromTable
                    .add(String.valueOf(Math.round((columnDataForOutComeTable.get(i) * 100.0f) / total)) + "%");
        }
        tableData.put(orderType, percentageFromTable);
        return tableData;
    }

    public ArrayList<String> getFilterOptions() {
        ArrayList<String> filterOptions = new ArrayList<String>();
        // Filter options
        filterOptions.add("Case Type");
        filterOptions.add("Filing Party Role");
        filterOptions.add("Market Sector");
        filterOptions.add("Motion Subtype");
        filterOptions.add("Order Date");
        return filterOptions;

    }

    public ArrayList<String> getCaseTypeOptions() {
        ArrayList<String> expectedCaseTypeOptions = new ArrayList<String>();
        // Case type Options
        expectedCaseTypeOptions.add("NPE");
        expectedCaseTypeOptions.add("Operating Company");
        return expectedCaseTypeOptions;
    }

    public ArrayList<String> getpartyRoleOptions() {
        ArrayList<String> expectedPartyRoleOptions = new ArrayList<String>();
        // filling role type options
        expectedPartyRoleOptions.add("Defendant");
        expectedPartyRoleOptions.add("Other");
        expectedPartyRoleOptions.add("Plaintiff");
        return expectedPartyRoleOptions;
    }

    // JURY VERDICTS ELEMENTS & METHODS
    public final Element graph = $("rect.highcharts-background");
    public final Element verdicts_X_Axis_Label = $("#verdict_orders .highcharts-xaxis-labels text");
    public final Element verdicts_Graphs = $("#verdict_orders .highcharts-data-labels tspan");
    public final Element verdicts_Filter_title = $(".open h2");
    public final Element verdicts_Table_title = $(".open .row h2");
    public final Element verdicts_order_table_Close = $(".open a.close-reveal-modal");
    public final Element activeTab = $("dl>dd.active>a");
    public final String verdictsGraph[] = { "PLAINTIFF PATENTEE", "PLAINTIFF NON PATENTEE", "DEFENDANT PATENTEE",
            "UNAVAILABLE" };
    public final Element document_lnk = $("table.venue_judge_case_table a.document");

    public final Table VERDICTS_ORDER_TABLE = $("#verdict_orders_table_modal.open table.venue_judge_case_table",
            (Configure<Table>) table ->
        {
           table.nextPage("#verdict_orders_table_modal.open ul.pagination.pagination li:last-child");
           table.lastPage("#verdict_orders_table_modal.open ul.pagination.pagination li:nth-last-child(2)");
            table.subTable(new Table("table.venue_judge_case_table table.nested_inner_table"));
            table.expandSubTableLink("img.open");

        }
    );

    public void clickOnTab(String tabName) {
        String tab_Xpath = String.format("//dl/dd/a[contains(text(),'%s')]", tabName);
        Element tab = $(By.xpath(tab_Xpath));
        if (!activeTab.getText().equalsIgnoreCase(tabName)) {
            tab.click();
        }
    }

    public void clickOnVerdictsXAxis(String verdictName) {
        String xpath = String.format("//*[contains(@class,'highcharts-xaxis-labels')]//*[text()='%s']",
                verdictName.trim().toUpperCase());
        $(By.xpath(xpath)).click();
    }

    public List<String> getVerdictsXAxisLabels() {
        return verdicts_X_Axis_Label.getAllData();
    }

    public Map<String, String> getAllVerdictsCountFromGraph() {
        Map<String, String> countFromGraph = new HashMap<String, String>();
        List<String> graphData = verdicts_Graphs.getAllData();
        for (int i = 0; i < graphData.size(); i++) {
            countFromGraph.put(verdictsGraph[i], graphData.get(i));
        }
        return countFromGraph;
    }

    public void clickOnVerdictsGarph(String verdictName) throws InterruptedException {
        List<WebElement> verdictsGraph = verdicts_Graphs.getElements();
        verdictsGraph.get(getVerdictsXAxisLabels().indexOf(verdictName)).click();

    }

    public void waitForVerdictsFilterDialog() {
        loading.waitUntilInvisible();
        verdicts_Filter_title.waitUntilVisible();
    }

    public void waitForVerdictsTable() {
        loading.waitUntilInvisible();
        verdicts_Table_title.waitUntilVisible();
    }

    public void closeVerdictsOrderDialog() {
        if (verdicts_order_table_Close.isPresent()) {
            verdicts_order_table_Close.click();
        }
        VERDICTS_ORDER_TABLE.waitUntilInvisible();
        verdicts_Filter_title.waitUntilInvisible();
    }

    public Map<String, String> getAllVerdictsCountFromDialogTitle() throws InterruptedException {
        Map<String, String> countFromDialog = new HashMap<String, String>();
        for (String graphName : verdictsGraph) {
            countFromDialog.put(graphName, String.valueOf(getVerdictsCountFromDialogTitle(graphName)));
        }
        return countFromDialog;
    }

    public int getVerdictsCountFromDialogTitle(String verdictGraphName) throws InterruptedException {
        int count = 0;
        clickOnVerdictsGarph(verdictGraphName);
        waitForVerdictsFilterDialog();
        count = verdicts_Table_title.getIntData();
        closeVerdictsOrderDialog();
        Thread.sleep(200);
        return count;
    }

    public Map<String, String> getAllVerdictsRecordsSizeFromDialog() throws InterruptedException {
        Map<String, String> recordsSizeFromDialog = new HashMap<String, String>();
        for (String graphName : verdictsGraph) {
            recordsSizeFromDialog.put(graphName, String.valueOf(getVerdictRecordsSizeFromDialog(graphName)));
        }
        return recordsSizeFromDialog;
    }

    public int getVerdictRecordsSizeFromDialog(String verdictName) throws InterruptedException {
        int recordCount = 0, countFromTitle = 0;
        String columnName = null;
        clickOnVerdictsGarph(verdictName);
        waitForVerdictsFilterDialog();
        countFromTitle = verdicts_Table_title.getIntData();
        if (countFromTitle != 0) {
            columnName = VERDICTS_ORDER_TABLE.getHeaderData()[0];
            recordCount = VERDICTS_ORDER_TABLE.getColumn(columnName).size();
        } else {
            recordCount = verdicts_Table_title.getIntData();
        }
        closeVerdictsOrderDialog();
        Thread.sleep(200);
        return recordCount;
    }

    // JURY VERDICTS FILTER ELEMENTS & METHODS
    public final Element verdictsFilterButton = $("#verdict_orders .button-group a.button.icon-button.apply_filter ");
    // Order+Verdicts Filter
    public final Element filterHeading = $("#non_verdict_orders_table_modal .follow-content a.facet_button");
//    public final Element filterExpandLink = $(".facet-search-modal.open div.handle");
//    public final Element filterExpandDiv = $(".facet-search-modal.open div.group.active");
    public final Element filterOptionNames = $(".facet-search-modal.open .facets_holder div>p");
    public final String caseTypeDiv = ".facet-search-modal.open .facets_holder .case_type_normalized_name";
    public final String fillingPartyRoleDiv = ".facet-search-modal.open .facets_holder .order_normalized_filing_party_roles";
    public final String marketSectorDiv = ".facet-search-modal.open .facets_holder .case_market_sector_type_name";
    public final String orderSubtypeDiv = ".facet-search-modal.open .facets_holder .order_subtype";
    public final String orderDateDiv = ".facet-search-modal.open .facets_holder .date_filter";
    public final Element motionSubtypeSelectAll = $(".ms-select-all.selected");
    public final Element applyFilterBtn = $(".facet-search-modal.open input[value='Apply']");
    public final Element resetFilterBtn = $(".facet-search-modal.open a.reset_btn");
    public final Element cancelFilterBtn = $(".facet-search-modal.open a.cancel_btn");
    public final Element fromDateInFilterDialog = $(orderDateDiv + " input[placeholder='From date']");
    public final Element toDateInFilterDialog = $(orderDateDiv + " input[placeholder='To date']");
    public final Element dropDownOpenDiv = $(".open button div.open");
    public final Element caseTypeFilter = $(caseTypeDiv + " button div");
    public final Element marketSectorFilter = $(marketSectorDiv + " button div");

    public void expandFilterDialogForVerdict(String verdictName) throws InterruptedException {
        clickOnVerdictsXAxis(verdictName);
        waitForVerdictsTable();
        expandFilterOptionsInDialog();
    }

    public void selectOptionsInFilterDropDown(String dropDown, String[] options) {
        clickOnDropDownFilter(dropDown);
        selectOptions(options);
    }

    public void clickOnDropDownFilter(String dropDown) {
        switch (dropDown.toLowerCase()) {
        case "case type":
            caseTypeFilter.waitUntilClickable();
            caseTypeFilter.click();
            break;
        case "market sector":
            marketSectorFilter.waitUntilClickable();
            marketSectorFilter.click();
            break;
        }
    }

    public ArrayList<String> getListOfOptionFromDropDown(String dropDown, String requiredOptions) {
        ArrayList<String> options = new ArrayList<String>();
        clickOnDropDownFilter(dropDown);
        switch (dropDown.toLowerCase()) {
        case "case type":
            options = getFilterDropDownOptionsInDialog(caseTypeDiv, requiredOptions);
            break;
        case "market sector":
            options = getFilterDropDownOptionsInDialog(marketSectorDiv, requiredOptions);
            break;
        }
        return options;
    }

    public void selectOptions(String[] options) {
        for (String option : options) {
            String xpath = String.format("//*[contains(@class,'open')]//label[text()='%s']/input", option);
            if (!$(By.xpath(xpath)).isSelected()) {
                $(By.xpath(xpath)).click();
            }
        }
    }

    // Example data: "03/20/2010"
    public void selectFromDate(String dateInfo) throws ParseException {
        fromDateInFilterDialog.click();
        selectDate(getDate(dateInfo).get("month"), getDate(dateInfo).get("year"),
                Integer.parseInt(getDate(dateInfo).get("day")));
    }

    // Example data: "03/20/2010"
    public void selectToDate(String dateInfo) throws ParseException {
        toDateInFilterDialog.click();
        selectDate(getDate(dateInfo).get("month"), getDate(dateInfo).get("year"),
                Integer.parseInt(getDate(dateInfo).get("day")));
    }

    public void clickOnFilterButton() {
        verdicts_Filter_title.waitUntilInvisible();
        verdictsFilterButton.waitUntilClickable();
        verdictsFilterButton.click();
        verdicts_Filter_title.waitUntilVisible();
    }

    public HashMap<String, String> getDate(String date) throws ParseException {
        HashMap<String, String> data = new HashMap<String, String>();
        SimpleDateFormat currentFormat = new SimpleDateFormat("MM/dd/yyyy");
        SimpleDateFormat needFormat = new SimpleDateFormat("MMM,yyyy,dd");
        String dateInfo[] = needFormat.format(currentFormat.parse(date)).split(",");
        data.put("month", dateInfo[0]);
        data.put("year", dateInfo[1]);
        data.put("day", dateInfo[2]);
        return data;
    }

    public final Element recentActivityContent = $("div.activity:has(h2:contains('Recent Activities'))>ul");
    public final Element recentActivity = $("#recent_activity", (Configure<ListPanel>) list ->
        {
            list.viewAllLink(".view-all-link-margin .view-all");
            list.dataKey("li>a[href]");

        }
    );



}