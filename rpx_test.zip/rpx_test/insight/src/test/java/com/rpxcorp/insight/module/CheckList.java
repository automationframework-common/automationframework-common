package com.rpxcorp.insight.module;

import com.rpxcorp.testcore.element.Element;

import java.util.ArrayList;
import java.util.List;

public class CheckList extends Element {
    private Element selectAllNNone=$("input:not([value])");
    Element seeMore = $("a[data-function='see-more']");
    Element seeLess = $("a[data-function='see-less']");
    public final Element selectAll =$("a[data-function='select-all']");
    public final Element selectNone =$("a[data-function='select-none']");
    public CheckList(String selector) {
        super(selector);
    }


    public void select(Object value) {
        if(value != null){
            seeMore();
            if(value.getClass().equals(String.class)){
                select((String) value);
            }else if(value.getClass().equals(ArrayList.class)){
                select((List<String>) value);
            }
        }
    }

    public void select(String value) {
        if(!value.equals("")) {
            Element element = $("label:contains('" + value + "') input");
            if (element.isSelected() == false) {
                element.click();
            }
        }
    }

    public void select(List<String> arrayList) {
        for (String value : arrayList) {
            select(value);
        }
    }
    public void unselect(String[] values) {
        for (String value : values) {
            unselect(value);
        }
    }

    public void unselect(String value) {
        if(!value.equals("")) {
            Element element = $("label:contains('" + value + "') input");
            if (element.isSelected() == true) {
                element.click();
            }
        }
    }

    public void selectInTableFormat(Object value) {
        if(value != null){
            seeMore();
            if(value.getClass().equals(String.class)){
                selectInTableFormat((String) value);
            }else if(value.getClass().equals(ArrayList.class)){
                selectInTableFormat((List<String>) value);
            }
        }
    }

    public void selectInTableFormat(String value) {
        if(!value.equals("")) {
            Element element = $("tr:contains('" + value + "') input");
            if (element.isSelected() == false) {
                element.click();
            }
        }
    }

    public void selectInTableFormat(List<String> arrayList) {
        for (String value : arrayList) {
            selectInTableFormat(value);
        }
    }

    public void unselectInTableFormat(String[] values) {
        for (String value : values) {
            unselectInTableFormat(value);
        }
    }

    public void unselectInTableFormat(String value) {
        if(!value.equals("")) {
            Element element = $("tr:contains('" + value + "') input");
            if (element.isSelected() == true) {
                element.click();
            }
        }
    }

    public void selectAll(){
        if(selectAll.isDisplayed()){
            selectAll.click();
        }else if(!selectAllNNone.isSelected()) {
            selectAllNNone.click();
        }
    }
    public void selectNone(){
        if(selectNone.isDisplayed()){
            selectNone.click();
        }else if(selectAllNNone.isSelected()) {
            selectAllNNone.click();
        }else if(!selectAllNNone.isSelected()) {
            selectAllNNone.click();
            selectAllNNone.waitUntilElementSelected();
            selectAllNNone.click();
        }
    }
    public void seeMore(){
        if(seeMore.isDisplayed()) {
            seeMore.click();
            seeLess.waitUntilVisible();
            $(".more label:last").waitUntilVisible();
        }
    }
    public void seeLess(){
        if(seeLess.isDisplayed()) {
            seeLess.click();
            seeMore.waitUntilVisible();
        }
    }


    public ArrayList<String> getSelectedTableField() {
        return $("td:has(input:checked)+td").getAllData();
    }

    public ArrayList<String> getSelectedField() {
        return $("label:has(input:checked)").getAllData();
    }

    public ArrayList<String> getAllField() {
        seeMore();
        return $("label:has(input[value])").getAllData();
    }

    public ArrayList<String> getVisibleList() {
        return $("label:has(input[value]:visible)").getAllData();
    }
}
