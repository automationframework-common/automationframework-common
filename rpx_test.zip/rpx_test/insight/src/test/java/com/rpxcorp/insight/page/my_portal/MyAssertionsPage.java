package com.rpxcorp.insight.page.my_portal;

import java.util.ArrayList;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;

public class MyAssertionsPage extends Page {

    public MyAssertionsPage() {
        this.url = new PageUrl("assertions");
    }

    @Override
    public boolean at() {
        return loadAsyncContent.waitUntilVisible();
    }

    private final Element loadAsyncContent = $("*[data-behavior='load_async_content']");
    private final Element saveAssertion = $("#submit_assertion");
    private final Element addAssertionButton = $(".button-group.right a[href='/assertions/new']");
    private final Element assertingEntity = $("#assertion_asserting_ent_name");
    private final Element assertingEntityAutocompleteText = $("#ui-id-2 li a");
    private final Element cms_title=$("h2.cms_title");
    
    public void clickAddAssertionButton() {
        addAssertionButton.click();
        saveAssertion.waitUntilVisible();
    }

    public void sendAssertingEntityText(String assertingEntityText) {
        assertingEntity.clear();
        assertingEntity.sendKeys(assertingEntityText);
    }

    public ArrayList<String> getAutoCompleteTextList() {
        assertingEntityAutocompleteText.waitUntilVisible();
        return assertingEntityAutocompleteText.getAllData();
    }

}
