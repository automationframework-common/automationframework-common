package com.rpxcorp.insight.page.my_portal;

import org.openqa.selenium.By;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;

public class AssertionsViewPage extends Page {

    public AssertionsViewPage() {
        this.url = new PageUrl("assertions/{ID}");
    }

    @Override
    public boolean at() {
        return assertionOverview_panel.waitUntilVisible();
    }

    public final Element assertionOverview_panel = $(".panel #assertion_overview");
    // Related Entity Text -Authorization
    public final Element assertingEntityStats = $(
            By.xpath("//h2[text()='Asserting Entity Stats']/../div//ul/li[1][contains(text(),'Related')]"));
}
