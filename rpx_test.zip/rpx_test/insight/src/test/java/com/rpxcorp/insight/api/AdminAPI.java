package com.rpxcorp.insight.api;

import com.rpxcorp.insight.page.LoginPage;
import com.rpxcorp.testcore.driver.APICache;

import com.rpxcorp.testcore.util.HTTPUtil;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.HashMap;
import java.util.Map;

public class AdminAPI extends APICache {

    public void changeFeature(String featureName,boolean enable) throws Exception {
        String level=enable ? "1" : "0" ;
        HashMap<String, String> params = new HashMap<>();
        Document doc = getAPIInstance().loadPage("/admin/features");
        String token= getAPIInstance().getCSRF_Token(doc);
        Elements elements = doc.select("tr:has(td:contains(" + featureName + ")) form");
        if(elements.size() ==0)
            throw new Exception(featureName+" not found in Features Page");
        params.put("authenticity_token", token);
        params.put("level", level);
        getAPIInstance().put(elements.get(0).attr("action"), params);
    }

    public void deleteUser(String userID) throws Exception {
        if(!userID.isEmpty()){        	
            String message=getAPIInstance().get("/admin/users/vanish/"+userID);            
            if(!(message.contains("deleted") || message.startsWith("Record not found! please provide a valid user id"))) {           	
                throw new Exception("Problem in deleting user, response message: " + message);
            }
        }
    }


	private String createUserInternal(String emailId, String companyName , LoginPage.ROLES roles, Map<String,String> options) throws Exception {
		String token  = getAPIInstance().getCSRF_Token("/admin/users/new");
		String account_id="";
		if(roles.toString().equalsIgnoreCase("elite") ||
				roles.toString().equalsIgnoreCase("member") ||
				roles.toString().equalsIgnoreCase("staff"))
			account_id="RID-000035";
		HashMap<String, String> params = new HashMap<>();
		params.put("authenticity_token", token);
		params.put("user[first_name]", emailId);
		params.put("user[last_name]", "Test");
		params.put("user[email]", emailId);
		params.put("user[notes]", "");
		params.put("user[extended_user_detail_attributes][company]", companyName);
		params.put("user[auto_created]", "true");
		params.put("user[user_role_users_attributes][0][user_role_id]", roles.getDataId());
		params.put("user[extended_user_detail_attributes][id]", "");
		params.put("user[extended_user_detail_attributes][user_type]", "Default");
		params.put("user[user_permission_attributes][subscription_level]", "");
		params.put("user[account_id]", account_id);
		params.put("user[user_preference_attributes][lit_email_subscription]",options.get("daily_litigation_alert"));
		params.put("user[user_preference_attributes][news_email_subscription]",options.get("weekly_newsletter_alert"));
		params.put("user[user_preference_attributes][monthly_npe_update_subscription]",options.get("monthly_npe_update"));
		params.put("user[user_preference_attributes][quarterly_risk_reduction_report]",options.get("quarterly_risk_reduction_report"));
		params.put("user[user_preference_attributes][quarterly_feature_release_updates]",options.get("quarterly_risk_reduction_report"));
		params.put("user[user_permission_attributes][can_view_patents]",options.get("patents"));
		params.put("user[user_permission_attributes][prior_art_download_enabled]",options.get("prior_art_search_reports"));
		//params.put("user[user_permission_attributes][can_view_market_sector_analytics]",options.get("market_sector_analytics"));
		params.put("user[user_permission_attributes][can_view_cost_analytics]",options.get("litigation_cost_analytics"));
		params.put("user[user_permission_attributes][can_view_ptab_cost_analytics]",options.get("ptab_cost_analytics"));
		params.put("user[user_permission_attributes][alpha_tester]",options.get("alpha_user"));
		params.put("user[user_permission_attributes][beta_tester]",options.get("beta_user"));
		params.put("user[extended_user_detail_attributes][is_trial_user]",options.get("trial_user"));
		params.put("save_user_changes","Save User");
		String userPage=getAPIInstance().post("/admin/users",params);
		Document doc = Jsoup.parse(userPage);
		return doc.select("td[id*=activation_link_]").text();
	}

    private String createUserInternal(String emailId, LoginPage.ROLES roles, Map<String,String> options) throws Exception {
    	String token  = getAPIInstance().getCSRF_Token("/admin/users/new");
    	String account_id="";
		if(roles.toString().equalsIgnoreCase("elite") ||
				roles.toString().equalsIgnoreCase("member") ||
				roles.toString().equalsIgnoreCase("staff"))
			account_id="RID-000035";
    	HashMap<String, String> params = new HashMap<>();
    	params.put("authenticity_token", token);
    	params.put("user[first_name]", emailId);
    	params.put("user[last_name]", "Test");
    	params.put("user[email]", emailId);
    	params.put("user[notes]", "");
		params.put("user[auto_created]", "true");
    	params.put("user[user_role_users_attributes][0][user_role_id]", roles.getDataId());
		params.put("user[extended_user_detail_attributes][id]", "");
    	params.put("user[extended_user_detail_attributes][user_type]", "Default");
		params.put("user[user_permission_attributes][subscription_level]", "");
    	params.put("user[account_id]", account_id);
		params.put("user[user_preference_attributes][lit_email_subscription]",options.get("daily_litigation_alert"));
		params.put("user[user_preference_attributes][news_email_subscription]",options.get("weekly_newsletter_alert"));
		params.put("user[user_preference_attributes][monthly_npe_update_subscription]",options.get("monthly_npe_update"));
		params.put("user[user_preference_attributes][quarterly_risk_reduction_report]",options.get("quarterly_risk_reduction_report"));
		params.put("user[user_preference_attributes][quarterly_feature_release_updates]",options.get("quarterly_feature_update"));
		params.put("user[user_permission_attributes][can_view_patents]",options.get("patents"));
		params.put("user[user_permission_attributes][prior_art_download_enabled]",options.get("prior_art_search_reports"));
		//params.put("user[user_permission_attributes][can_view_market_sector_analytics]",options.get("market_sector_analytics"));
		params.put("user[user_permission_attributes][can_view_cost_analytics]",options.get("litigation_cost_analytics"));
		params.put("user[user_permission_attributes][can_view_ptab_cost_analytics]",options.get("ptab_cost_analytics"));
        params.put("user[user_permission_attributes][can_access_community_page]",options.get("rpx_community_webinars"));
		params.put("user[user_permission_attributes][alpha_tester]",options.get("alpha_user"));
		params.put("user[user_permission_attributes][beta_tester]",options.get("beta_user"));
		params.put("user[extended_user_detail_attributes][is_trial_user]",options.get("trial_user"));
		params.put("save_user_changes","Save User");
    	String userPage=getAPIInstance().post("/admin/users",params);
    	Document doc = Jsoup.parse(userPage);        
    	return doc.select("td[id*=activation_link_]").text();
    }
	public String createUser(String emailId, LoginPage.ROLES roles, Map<String,String> options) throws Exception {
		Map<String,String> defaultOptions= new HashMap<>();
		defaultOptions.put("daily_litigation_alert","1");
		defaultOptions.put("weekly_newsletter_alert","1");
		defaultOptions.put("monthly_npe_update","0");
		defaultOptions.put("quarterly_risk_reduction_report","0");
		defaultOptions.put("quarterly_feature_update","1");
		defaultOptions.put("patents","1");
		defaultOptions.put("prior_art_search_reports","0");
		//defaultOptions.put("market_sector_analytics","0");
		defaultOptions.put("litigation_cost_analytics","0");
		defaultOptions.put("ptab_cost_analytics","0");
        defaultOptions.put("rpx_community_webinars","0");
		defaultOptions.put("alpha_user","0");
		defaultOptions.put("beta_user","0");
		defaultOptions.put("trial_user","0");
		defaultOptions.putAll(options);
		return createUserInternal(emailId,roles,defaultOptions);
	}

	public String createUser(String emailId, String companyName, LoginPage.ROLES roles, Map<String,String> options) throws Exception {
		Map<String,String> defaultOptions= new HashMap<>();
		defaultOptions.put("daily_litigation_alert","1");
		defaultOptions.put("weekly_newsletter_alert","1");
		defaultOptions.put("monthly_npe_update","0");
		defaultOptions.put("quarterly_risk_reduction_report","0");
		defaultOptions.put("quarterly_feature_update","1");
		defaultOptions.put("patents","1");
		defaultOptions.put("prior_art_search_reports","0");
		defaultOptions.put("market_sector_analytics","0");
		defaultOptions.put("litigation_cost_analytics","0");
		defaultOptions.put("ptab_cost_analytics","0");
		defaultOptions.put("alpha_user","0");
		defaultOptions.put("beta_user","0");
		defaultOptions.put("trial_user","0");
		defaultOptions.putAll(options);
		return createUserInternal(emailId,companyName,roles,defaultOptions);
	}

	public String createUser(String emailId, LoginPage.ROLES roles) throws Exception {
		return createUser(emailId,roles,new HashMap<>());
	}

	public String createUser(String firstName , String lastName ,String companyName , String emailId, LoginPage.ROLES roles) throws Exception {
		String token  = getAPIInstance().getCSRF_Token("/admin/users/new");
		HashMap<String, String> params = new HashMap<>();
		params.put("authenticity_token", token);
		params.put("user[first_name]", firstName);
		params.put("user[last_name]", lastName);
		params.put("user[extended_user_detail_attributes][company]", companyName);
		params.put("user[email]", emailId);
		params.put("user[auto_created]", "true");
		params.put("user[notes]", "");
		params.put("user[trail_expiration_date]", "");
		params.put("user[user_role_users_attributes][0][user_role_id]", roles.getDataId());
		params.put("user[user_type", "Default");
		//params.put("user[rpx_id]", "RID-000035");
		params.put("user[lit_email_subscription]", "0");
		params.put("user[news_email_subscription]", "0");
		if(roles.getDataId().equalsIgnoreCase("member"))
			params.put("user[monthly_npe_update_subscription]", "1");
		params.put("user[quarterly_feature_release_updates]", "1");
		//params.put("user[can_view_assertions]", "0");
		params.put("user[can_view_patents]", "0");
		params.put("user[can_view_prior_art]", "0");
		params.put("user[prior_art_download_enabled]", "0");
		params.put("user[beta_tester]", "1");
		params.put("save_user_changes", "Save User");
		String userPage=getAPIInstance().post("/admin/users",params);
		Document doc = Jsoup.parse(userPage);
		return doc.select("td[id*=activation_link_]").text();
	}

    public void activateUser(String activationLink,String password) throws Exception {
        String id=activationLink.replaceFirst("^.*\\/(.*)$","$1");
        HTTPUtil http = getNewInstance();
        String token = http.getCSRF_Token("/activate/"+id);
        HashMap<String, String> params = new HashMap<>();
        params.put("authenticity_token", token);
        params.put("token", id);
        params.put("to_insurance", "false");
        params.put("requesting_company", "");
        params.put("client_company", "");
        params.put("password", password);
        params.put("password_confirmation", password);
        params.put("commit", "Set Password");
        String userPage= http.post("/activate",params);        
    }
	public void addToWhiteList(String emailId) throws Exception {
		HashMap<String, String> params = new HashMap<>();
		String token = getAPIInstance().getCSRF_Token("/admin/whitelists");
		params.put("authenticity_token", token);
		params.put("whitelist[email]", emailId);
		params.put("whitelist[created_by]", "auto_admin@rpxcorp.com");
		params.put("save_user_changes", "Save Whitelist User");
		getAPIInstance().post("/admin/whitelists", params);
	}
	
	public void deleteFromWhiteList(String id) throws Exception {
		HashMap<String, String> params = new HashMap<>();
		String token = getAPIInstance().getCSRF_Token("/admin/whitelists/"+id);
		params.put("authenticity_token", token);
		params.put("_method", "delete");
		getAPIInstance().post("/admin/whitelists/"+id, params);
	}
	public Map<String, String> getUserInfo(String id) throws Exception {
		Document doc = getAPIInstance().loadPage("/admin/users/"+id);
		Elements rowDatas = doc.select(".profile_body tr");
		Map<String,String> data= new HashMap<>();
		for(Element rowData:rowDatas){
			Element value = rowData.child(1);
			String textValue=value.text();
			Elements icon = value.select("i");
			if(icon.size() ==1){
				String className = icon.get(0).className();
				if(className.contentEquals("icon-cross")) {
					textValue = "NO";
				}else if(className.contentEquals("icon-checkmark")){
					textValue ="YES";
				}
			}
			data.put(rowData.child(0).text(),textValue);
		}
		return data;
	}
}
