package com.rpxcorp.insight.page.advance_search;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;

public class AdvanceSearchGlosaryPage extends Page {

    public AdvanceSearchGlosaryPage() {
        this.url = new PageUrl("advanced_search/glossary");
    }

    @Override
    public boolean at() {
        return syntaxExample_table.waitUntilVisible();
    }

    public final Element syntaxExample_table = $("div.section #Syntax_Examples table");

}
