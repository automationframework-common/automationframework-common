package com.rpxcorp.insight.test.data;

import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import com.rpxcorp.insight.page.detail.EntityDetailPage;
import com.rpxcorp.testcore.TableData;
@Test(groups = "Entity")
@Authenticate(role = "MEMBER")
public class EntityDetailsTest_ExcludeSubsidary extends BaseDataTest {
    EntityDetailPage entityDetailPage;
    TableData litigationTableData, petitionTableData;

    @Factory(dataProvider = "returnData")
    public EntityDetailsTest_ExcludeSubsidary(String dataDescription, String entityId) {
        this.dataId = entityId;
        this.dataDescription = dataDescription;
    }

    @BeforeClass
    public void loadPage() {
        urlData.put("ID", dataId);
        urlData.put("INCLUDE_SUBSD", "false");
        this.dataUrl = entityDetailPage.getDeclaredUrl(urlData);
        to(entityDetailPage, urlData);
    }

    @Test(description = "Verify Overview Cases Count", priority = 1)
    public void Overview_Count() throws Exception {
        assertEquals(entityDetailPage.overview_panel.getData(),
                sqlProcessor.getResultData("EntityDetail.OVERVIEW_COUNT_EXC_SUB", dataId));
    }

    @Test(description = "Verify All Patents Count", priority = 2)
    public void All_Patents_Count() throws Exception {
        assertEquals(entityDetailPage.patentCount.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.PATENT_ALL_EXC_SUB", dataId));
    }

    @Test(description = "Verify All Patents", priority = 2)
    public void AllPatents() throws Exception {
        assertEquals(entityDetailPage.patent_table.getData(),
                sqlProcessor.getResultData("EntityDetail.PATENT_ALL_EXC_SUB", dataId));
    }

    @Test(description = "Verify Patents as Plaintiff", priority = 3)
    public void PatentsasPlaintiff() throws Exception {
        entityDetailPage.selectPatentPlaintiffTabLink();
        assertEquals(entityDetailPage.patent_table.getData(),
                sqlProcessor.getResultData("EntityDetail.PATENT_PLAINTIFF_EXC_SUB", dataId));
    }

    @Test(description = "Verify Patents as Defendant", priority = 4)
    public void PatentasDefendant() throws Exception {
        entityDetailPage.selectPatentDefendantTab();
        assertEquals(entityDetailPage.patent_table.getData(),
                sqlProcessor.getResultData("EntityDetail.PATENT_DEFENDANT_EXC_SUB", dataId));
    }

    @Test(description = "Veify 'Date filed' column in Patent Owner Table", priority = 28)
    public void PatentOwnerTable_DateFiled() throws Exception {
        petitionTableData = (TableData) entityDetailPage.petition_table.getData();
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PATENTOWNER_EXC_SUB", dataId),
                "date_filed");
    }

    @Test(description = "Veify 'Patent Number' column in Patent Owner Table", priority = 29)
    public void PatentOwnerTable_PatentNumber() throws Exception {
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PATENTOWNER_EXC_SUB", dataId),
                "patent_number");
    }

    @Test(description = "Veify 'Case Number' column in Patent Owner Table", priority = 29)
    public void PatentOwnerTable_CaseNumber() throws Exception {
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PATENTOWNER_EXC_SUB", dataId),
                "case_number");
    }

    @Test(description = "Verify 'Status' column in Patent Owner Table", priority = 29)
    public void PatentOwnerTable_Status() throws Exception {
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PATENTOWNER_EXC_SUB", dataId),
                "status");
    }

    @Test(description = "Verify 'Institution Decision Date' column in Patent Owner Table", priority = 29)
    public void PatentOwnerTable_InstitutionDecisionDate() throws Exception {
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PATENTOWNER_EXC_SUB", dataId),
                "institution_decision_date");
    }

    @Test(description = "Verify 'Date filed' column in Petitioner Table", priority = 30)
    public void PetitionerTable_DateFiled() throws Exception {
        entityDetailPage.filterPetitioner();
        petitionTableData = (TableData) entityDetailPage.petition_table.getData();
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PETITIONER_EXC_SUB", dataId),
                "date_filed");
    }

    @Test(description = "Verify 'Patent Number' column in Petitioner Table", priority = 31)
    public void PetitionerTable_PatentNumber() throws Exception {
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PETITIONER_EXC_SUB", dataId),
                "patent_number");
    }

    @Test(description = "Verify 'Case Number' column in Petitioner Table", priority = 31)
    public void PetitionerTable_CaseNumber() throws Exception {
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PETITIONER_EXC_SUB", dataId),
                "case_number");
    }

    @Test(description = "Verify 'Status' column in Petitioner Table", priority = 31)
    public void PetitionerTable_Status() throws Exception {
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PETITIONER_EXC_SUB", dataId),
                "status");
    }

    @Test(description = "Verify 'Institution Decision Date' column in Petitioner Table", priority = 31)
    public void PetitionerTable_InstitutionDecisionDate() throws Exception {
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PETITIONER_EXC_SUB", dataId),
                "institution_decision_date");
    }

    @Test(description = "Verify Patent Owner Table in Parties view", priority = 32)
    public void PatentOwnerTable_in_parties_view() throws Exception {
        entityDetailPage.filterPatentOwner();
        entityDetailPage.selectPartiesTab();
        ;
        assertEquals(entityDetailPage.partiesNPatentTable.getSubtableData(),
                sqlProcessor.getResultData("EntityDetail.PTAB_PARTIES_PATENTOWNER_EXC_SUB", dataId));
        assert true;
    }

    @Test(description = "Verify Petitioner Table in Parties view", priority = 33)
    public void PetitionerTable_in_parties_view() throws Exception {
        entityDetailPage.filterPetitioner();
        assertEquals(entityDetailPage.partiesNPatentTable.getSubtableData(),
                sqlProcessor.getResultData("EntityDetail.PTAB_PARTIES_PETITIONERS_EXC_SUB", dataId));
        assert true;
    }

    @Test(description = "Verify Patent Patent Owner Table in Patent view", priority = 34)
    public void PatentOwnerTable_in_patent_view() throws Exception {
        entityDetailPage.filterPatentOwner();
        entityDetailPage.selectPatentsTab();
        assertEquals(entityDetailPage.partiesNPatentTable.getSubtableData(),
                sqlProcessor.getResultData("EntityDetail.PTAB_PATENT_PATENTOWNER_EXC_SUB", dataId));
        assert true;
    }

    @Test(description = "Verify Petitioner Table in Patent view", priority = 35)
    public void PetitionerTable_in_patent_view() throws Exception {
        entityDetailPage.filterPetitioner();
        assertEquals(entityDetailPage.partiesNPatentTable.getSubtableData(),
                sqlProcessor.getResultData("EntityDetail.PTAB_PATENT_PETITIONERS_EXC_SUB", dataId));
        assert true;
    }

    @Test(description = "Verify 'Campaign Name' column in Litigations Table as Campiagn view", priority = 6)
    public void Litigations_CampaignName_in_campaign_view() throws Exception {
        litigationTableData = (TableData) entityDetailPage.litigation_table.getData();
        assertEquals(litigationTableData, sqlProcessor.getResultData("EntityDetail.CAMP_ALL_CASES_EXC_SUB", dataId),
                "campaign_name");
    }

    @Test(description = "Verify 'Start Date' column in Litigations Table as Campiagn view", priority = 7)
    public void Litigations_StartDate_in_campaign_view() throws Exception {
        assertEquals(litigationTableData, sqlProcessor.getResultData("EntityDetail.CAMP_ALL_CASES_EXC_SUB", dataId),
                "start_date");
    }

    @Test(description = "Verify 'Most Recent Case' column in Litigations Table as Campiagn view", priority = 7)
    public void Litigations_MostRecentCase() throws Exception {
        assertEquals(litigationTableData, sqlProcessor.getResultData("EntityDetail.CAMP_ALL_CASES_EXC_SUB", dataId),
                "most_recent_case");
    }

    @Test(description = "Verify 'Termination Date' column in Litigations Table as Campiagn view", priority = 7)
    public void Litigations_TerminationDate_in_campaign_view() throws Exception {
        assertEquals(litigationTableData, sqlProcessor.getResultData("EntityDetail.CAMP_ALL_CASES_EXC_SUB", dataId),
                "termination_date");
    }

    @Test(description = "Verify 'Jurisdiction' column in Litigations Table as Campiagn view", priority = 7)
    public void Litigations_Jurisdisction_in_campaign_view() throws Exception {
        assertEquals(litigationTableData, sqlProcessor.getResultData("EntityDetail.CAMP_ALL_CASES_EXC_SUB", dataId),
                "jurisdiction");
    }

    @Test(description = "Verify 'Defendant Parents' column in Litigations Table as Campiagn view", priority = 8)
    public void Litigations_DefendantParents_in_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.CAMP_WITH_DEFENDANT_PARENTS", dataId), "defendant_parents");
    }

    @Test(description = "Verify Litigation Count in Campiagn view", priority = 5)
    public void All_Litigation_Count_in_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ALL_CASES_EXC_SUB", dataId));
    }

    @Test(description = "Verify Litigation Defendant Count in campaign view", priority = 9)
    public void Litigation_as_Defendant_Count_in_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_DEFENDANT_CASES_EXC_SUB", dataId));
    }

    @Test(description = "Verify Litigation Plaintiff Count in campaign view", priority = 9)
    public void Litigation_as_Plaintiff_Count_in_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_PLAINTIFF_CASES_EXC_SUB", dataId));
    }

    @Test(description = "Verify All Active Litigation Count in campaign view", priority = 10)
    public void ACTIVE_Litigation_Count_in_campaign_view() throws Exception {
        entityDetailPage.filterActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_CASES_EXC_SUB", dataId));
    }

    @Test(description = "Verify Active Litigation as Plaintiff Count in campaign view", priority = 11)
    public void Active_Litigation_as_Plaintiff_Count_in_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_PLAINTIFF_CASES_EXC_SUB", dataId));
    }

    @Test(description = "Verify Active Litigation as Defendant Count in campaign view", priority = 11)
    public void Active_Litigation_as_Defendant_Count_in_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_DEFENDANT_CASES_EXC_SUB", dataId));
    }

    @Test(description = "Verify All Inactive Litigation Count in campaign view", priority = 12)
    public void INACTIVE_Litigation_Count_in_campaign_view() throws Exception {
        entityDetailPage.filterInActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_CASES_EXC_SUB", dataId));
    }

    @Test(description = "Verify Inactive Litigation as Plaintiff Count in campaign view", priority = 13)
    public void Inactive_Litigation_as_Plaintiff_Count_in_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_PLAINTIFF_CASES_EXC_SUB", dataId));

    }

    @Test(description = "Verify Inactive Litigation as Defendant Count in campaign view", priority = 13)
    public void Inactive_Litigation_as_Defendant_Count_in_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_DEFENDANT_CASES_EXC_SUB", dataId));
    }

    @Test(description = "Verify All Litigation Count in non campaign view", priority = 14)
    public void All_Litigations_Count_in_non_campaign_view() throws Exception {
        entityDetailPage.changeCampaignView();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.ALL_CASES_EXC_SUB", dataId));
    }

    @Test(description = "Verify Litigation as Plaintiff Count in non campaign view", priority = 14)
    public void Litigations_As_Plaintiff_Count_in_non_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.PLAINTIFF_CASES_EXC_SUB", dataId));
    }

    @Test(description = "Verify Litigation as Defendant Count in non campaign view", priority = 14)
    public void Litigations_As_Defendant_Count_in_non_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.DEFENDANT_CASES_EXC_SUB", dataId));
    }

    @Test(description = "Verify All Litigations in non campaign view", priority = 15)
    public void AllLitigations_in_non_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.ALL_CASES_EXC_SUB", dataId), "start_date", "case_name",
                "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Litigations as Plaintiff in non campaign view", priority = 16)
    public void LitigationsAsPlaintiff_in_non_campaign_view() throws Exception {
        entityDetailPage.selectLitPlaintiffTabLink();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.PLAINTIFF_CASES_EXC_SUB", dataId), "start_date", "case_name",
                "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Litigations as Defendant in non campaign view", priority = 17)
    public void LitigationsAsDefendant_in_non_campaign_view() throws Exception {
        entityDetailPage.selectLitDefendantTab();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.DEFENDANT_CASES_EXC_SUB", dataId), "start_date", "case_name",
                "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Active Litigation Count in non campaign view", priority = 18)
    public void Active_Litigations_Count_in_non_campaign_view() throws Exception {
        entityDetailPage.filterActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.ACTIVE_CASES_EXC_SUB", dataId));
    }

    @Test(description = "Verify Active Litigation as Plaintiff Count in non campaign view", priority = 19)
    public void Active_Litigations_As_Plaintiff_Count_in_non_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.ACTIVE_PLAINTIFF_CASES_EXC_SUB", dataId));
    }

    @Test(description = "Verify Active Litigation as Defendant Count in non campaign view", priority = 19)
    public void Active_Litigations_As_Defendant_Count_in_non_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.ACTIVE_DEFENDANT_CASES_EXC_SUB", dataId));
    }

    @Test(description = "Verify Active Litigations in non campaign view", priority = 20)
    public void ActiveLitigations_in_non_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.ACTIVE_CASES_EXC_SUB", dataId), "start_date", "case_name",
                "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Active Litigations as Plaintiff in non campaign view", priority = 21)
    public void ActiveLitigationsAsPlaintiff_in_non_campaign_view() throws Exception {
        entityDetailPage.selectLitPlaintiffTabLink();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.ACTIVE_PLAINTIFF_CASES_EXC_SUB", dataId), "start_date",
                "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Active Litigations as Defendant in non campaign view", priority = 22)
    public void ActiveLitigationsAsDefendant_in_non_campaign_view() throws Exception {
        entityDetailPage.selectLitDefendantTab();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.ACTIVE_DEFENDANT_CASES_EXC_SUB", dataId), "start_date",
                "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify InActive Litigation Count in non campaign view", priority = 23)
    public void InActive_Litigations_Count_in_non_campaign_view() throws Exception {
        entityDetailPage.filterInActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.INACTIVE_CASES_EXC_SUB", dataId));
    }

    @Test(description = "Verify InActive Litigation as Plaintiff Count in non campaign view", priority = 24)
    public void InActive_Litigations_As_Plaintiff_Count_in_non_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.INACTIVE_PLAINTIFF_CASES_EXC_SUB", dataId));
    }

    @Test(description = "Verify InActive Litigation as Defendant Count in non campaign view", priority = 24)
    public void InActive_Litigations_As_Defendant_Count_in_non_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.INACTIVE_DEFENDANT_CASES_EXC_SUB", dataId));
    }

    @Test(description = "Verify InActive Litigations in non campaign view", priority = 25)
    public void InActiveLitigations_in_non_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.INACTIVE_CASES_EXC_SUB", dataId), "start_date", "case_name",
                "termination_date", "jurisdiction");
    }

    @Test(description = "Verify InActive Litigations as Plaintiff in non campaign view", priority = 26)
    public void InActiveLitigationsAsPlaintiff_in_non_campaign_view() throws Exception {
        entityDetailPage.selectLitPlaintiffTabLink();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.INACTIVE_PLAINTIFF_CASES_EXC_SUB", dataId), "start_date",
                "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify InActive Litigations as Defendant in non campaign view", priority = 27)
    public void InActiveLitigationsAsDefendant_in_non_campaign_view() throws Exception {
        entityDetailPage.selectLitDefendantTab();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.INACTIVE_DEFENDANT_CASES_EXC_SUB", dataId), "start_date",
                "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Litigation Count in Campiagn view NPE", priority = 41)
    public void All_Litigation_Count_in_campaign_view_NPE() throws Exception {
        entityDetailPage.changeCampaignView();
        entityDetailPage.filterNPE();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ALL_CASES_NPE_EXC_SUB", dataId));
    }

    @Test(description = "Verify 'Campaign Name' column in Litigations Table as Campiagn view NPE", priority = 41)
    public void Litigations_CampaignName_in_campaign_view_NPE() throws Exception {
        litigationTableData = (TableData) entityDetailPage.litigation_table.getData();
        assertEquals(litigationTableData, sqlProcessor.getResultData("EntityDetail.CAMP_ALL_CASES_NPE_EXC_SUB", dataId),
                "campaign_name");
    }

    @Test(description = "Verify Litigation Defendant Count in campaign view NPE", priority = 43)
    public void Litigation_as_Defendant_Count_in_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_DEFENDANT_CASES_NPE_EXC_SUB", dataId));
    }

    @Test(description = "Verify Litigation Plaintiff Count in campaign view NPE", priority = 43)
    public void Litigation_as_Plaintiff_Count_in_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_PLAINTIFF_CASES_NPE_EXC_SUB", dataId));
    }

    @Test(description = "Verify All Active Litigation Count in campaign view NPE", priority = 44)
    public void ACTIVE_Litigation_Count_in_campaign_view_NPE() throws Exception {
        entityDetailPage.filterActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_CASES_NPE_EXC_SUB", dataId));
    }

    @Test(description = "Verify Active Litigation as Plaintiff Count in campaign view NPE", priority = 45)
    public void Active_Litigation_as_Plaintiff_Count_in_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_PLAINTIFF_CASES_NPE_EXC_SUB", dataId));
    }

    @Test(description = "Verify Active Litigation as Defendant Count in campaign view NPE", priority = 45)
    public void Active_Litigation_as_Defendant_Count_in_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_DEFENDANT_CASES_NPE_EXC_SUB", dataId));
    }

    @Test(description = "Verify All Inactive Litigation Count in campaign view NPE", priority = 46)
    public void INACTIVE_Litigation_Count_in_campaign_view_NPE() throws Exception {
        entityDetailPage.filterInActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_CASES_NPE_EXC_SUB", dataId));
    }

    @Test(description = "Verify Inactive Litigation as Plaintiff Count in campaign view NPE", priority = 46)
    public void Inactive_Litigation_as_Plaintiff_Count_in_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_PLAINTIFF_CASES_NPE_EXC_SUB", dataId));

    }

    @Test(description = "Verify Inactive Litigation as Defendant Count in campaign view NPE", priority = 46)
    public void Inactive_Litigation_as_Defendant_Count_in_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_DEFENDANT_CASES_NPE_EXC_SUB", dataId));
    }

    @Test(description = "Verify All Litigation Count in non campaign view NPE", priority = 47)
    public void All_Litigations_Count_in_non_campaign_view_NPE() throws Exception {
        entityDetailPage.changeCampaignView();
        entityDetailPage.filterNPE();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.ALL_CASES_NPE_EXC_SUB", dataId));
    }

    @Test(description = "Verify Litigation as Plaintiff Count in non campaign view NPE", priority = 47)
    public void Litigations_As_Plaintiff_Count_in_non_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.PLAINTIFF_CASES_NPE_EXC_SUB", dataId));
    }

    @Test(description = "Verify Litigation as Defendant Count in non campaign view NPE", priority = 47)
    public void Litigations_As_Defendant_Count_in_non_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.DEFENDANT_CASES_NPE_EXC_SUB", dataId));
    }

    @Test(description = "Verify All Litigations in non campaign view NPE", priority = 48)
    public void AllLitigations_in_non_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.ALL_CASES_NPE_EXC_SUB", dataId), "start_date", "case_name",
                "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Litigations as Plaintiff in non campaign view NPE", priority = 49)
    public void LitigationsAsPlaintiff_in_non_campaign_view_NPE() throws Exception {
        entityDetailPage.selectLitPlaintiffTabLink();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.PLAINTIFF_CASES_NPE_EXC_SUB", dataId), "start_date",
                "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Litigations as Defendant in non campaign view NPE", priority = 50)
    public void LitigationsAsDefendant_in_non_campaign_view_NPE() throws Exception {
        entityDetailPage.selectLitDefendantTab();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.DEFENDANT_CASES_NPE_EXC_SUB", dataId), "start_date",
                "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Active Litigation Count in non campaign view NPE", priority = 51)
    public void Active_Litigations_Count_in_non_campaign_view_NPE() throws Exception {
        entityDetailPage.filterActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.ACTIVE_CASES_NPE_EXC_SUB", dataId));
    }

    @Test(description = "Verify Active Litigation as Plaintiff Count in non campaign view NPE", priority = 52)
    public void Active_Litigations_As_Plaintiff_Count_in_non_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.ACTIVE_PLAINTIFF_CASES_NPE_EXC_SUB", dataId));
    }

    @Test(description = "Verify Active Litigation as Defendant Count in non campaign view NPE", priority = 52)
    public void Active_Litigations_As_Defendant_Count_in_non_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.ACTIVE_DEFENDANT_CASES_NPE_EXC_SUB", dataId));
    }

    @Test(description = "Verify Active Litigations in non campaign view NPE", priority = 53)
    public void ActiveLitigations_in_non_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.ACTIVE_CASES_NPE_EXC_SUB", dataId), "start_date", "case_name",
                "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Active Litigations as Plaintiff in non campaign view NPE", priority = 54)
    public void ActiveLitigationsAsPlaintiff_in_non_campaign_view_NPE() throws Exception {
        entityDetailPage.selectLitPlaintiffTabLink();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.ACTIVE_PLAINTIFF_CASES_NPE_EXC_SUB", dataId), "start_date",
                "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Active Litigations as Defendant in non campaign view NPE", priority = 55)
    public void ActiveLitigationsAsDefendant_in_non_campaign_view_NPE() throws Exception {
        entityDetailPage.selectLitDefendantTab();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.ACTIVE_DEFENDANT_CASES_NPE_EXC_SUB", dataId), "start_date",
                "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify InActive Litigation Count in non campaign view NPE", priority = 56)
    public void InActive_Litigations_Count_in_non_campaign_view_NPE() throws Exception {
        entityDetailPage.filterInActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.INACTIVE_CASES_NPE_EXC_SUB", dataId));
    }

    @Test(description = "Verify InActive Litigation as Plaintiff Count in non campaign view NPE", priority = 57)
    public void InActive_Litigations_As_Plaintiff_Count_in_non_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.INACTIVE_PLAINTIFF_CASES_NPE_EXC_SUB", dataId));
    }

    @Test(description = "Verify InActive Litigation as Defendant Count in non campaign view NPE", priority = 57)
    public void InActive_Litigations_As_Defendant_Count_in_non_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.INACTIVE_DEFENDANT_CASES_NPE_EXC_SUB", dataId));
    }

    @Test(description = "Verify InActive Litigations in non campaign view NPE", priority = 58)
    public void InActiveLitigations_in_non_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.INACTIVE_CASES_NPE_EXC_SUB", dataId), "start_date",
                "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify InActive Litigations as Plaintiff in non campaign view NPE", priority = 59)
    public void InActiveLitigationsAsPlaintiff_in_non_campaign_view_NPE() throws Exception {
        entityDetailPage.selectLitPlaintiffTabLink();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.INACTIVE_PLAINTIFF_CASES_NPE_EXC_SUB", dataId), "start_date",
                "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify InActive Litigations as Defendant in non campaign view NPE", priority = 60)
    public void InActiveLitigationsAsDefendant_in_non_campaign_view_NPE() throws Exception {
        entityDetailPage.selectLitDefendantTab();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.INACTIVE_DEFENDANT_CASES_NPE_EXC_SUB", dataId), "start_date",
                "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Litigation Count in Campiagn view Others", priority = 61)
    public void All_Litigation_Count_in_campaign_view_Others() throws Exception {
        entityDetailPage.changeCampaignView();
        entityDetailPage.filterOthers();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ALL_CASES_OTHERS_EXC_SUB", dataId));
    }

    @Test(description = "Verify 'Campaign Name' column in Litigations Table as Campiagn view Others", priority = 61)
    public void Litigations_CampaignName_in_campaign_view_Others() throws Exception {
        litigationTableData = (TableData) entityDetailPage.litigation_table.getData();
        assertEquals(litigationTableData,
                sqlProcessor.getResultData("EntityDetail.CAMP_ALL_CASES_OTHERS_EXC_SUB", dataId), "campaign_name");
    }

    @Test(description = "Verify Litigation Defendant Count in campaign view Others", priority = 63)
    public void Litigation_as_Defendant_Count_in_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_DEFENDANT_CASES_OTHERS_EXC_SUB", dataId));
    }

    @Test(description = "Verify Litigation Plaintiff Count in campaign view Others", priority = 63)
    public void Litigation_as_Plaintiff_Count_in_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_PLAINTIFF_CASES_OTHERS_EXC_SUB", dataId));
    }

    @Test(description = "Verify All Active Litigation Count in campaign view Others", priority = 64)
    public void ACTIVE_Litigation_Count_in_campaign_view_Others() throws Exception {
        entityDetailPage.filterActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_CASES_OTHERS_EXC_SUB", dataId));
    }

    @Test(description = "Verify Active Litigation as Plaintiff Count in campaign view Others", priority = 65)
    public void Active_Litigation_as_Plaintiff_Count_in_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_PLAINTIFF_CASES_OTHERS_EXC_SUB", dataId));
    }

    @Test(description = "Verify Active Litigation as Defendant Count in campaign view Others", priority = 65)
    public void Active_Litigation_as_Defendant_Count_in_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_DEFENDANT_CASES_OTHERS_EXC_SUB", dataId));
    }

    @Test(description = "Verify All Inactive Litigation Count in campaign view Others", priority = 66)
    public void INACTIVE_Litigation_Count_in_campaign_view_Others() throws Exception {
        entityDetailPage.filterInActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_CASES_OTHERS_EXC_SUB", dataId));
    }

    @Test(description = "Verify Inactive Litigation as Plaintiff Count in campaign view Others", priority = 66)
    public void Inactive_Litigation_as_Plaintiff_Count_in_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_PLAINTIFF_CASES_OTHERS_EXC_SUB", dataId));

    }

    @Test(description = "Verify Inactive Litigation as Defendant Count in campaign view Others", priority = 66)
    public void Inactive_Litigation_as_Defendant_Count_in_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_DEFENDANT_CASES_OTHERS_EXC_SUB", dataId));
    }

    @Test(description = "Verify All Litigation Count in non campaign view Others", priority = 67)
    public void All_Litigations_Count_in_non_campaign_view_Others() throws Exception {
        entityDetailPage.changeCampaignView();
        entityDetailPage.filterOthers();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.ALL_CASES_OTHERS_EXC_SUB", dataId));
    }

    @Test(description = "Verify Litigation as Plaintiff Count in non campaign view Others", priority = 67)
    public void Litigations_As_Plaintiff_Count_in_non_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.PLAINTIFF_CASES_OTHERS_EXC_SUB", dataId));
    }

    @Test(description = "Verify Litigation as Defendant Count in non campaign view Others", priority = 67)
    public void Litigations_As_Defendant_Count_in_non_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.DEFENDANT_CASES_OTHERS_EXC_SUB", dataId));
    }

    @Test(description = "Verify All Litigations in non campaign view Others", priority = 68)
    public void AllLitigations_in_non_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.ALL_CASES_OTHERS_EXC_SUB", dataId), "start_date", "case_name",
                "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Litigations as Plaintiff in non campaign view Others", priority = 69)
    public void LitigationsAsPlaintiff_in_non_campaign_view_Others() throws Exception {
        entityDetailPage.selectLitPlaintiffTabLink();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.PLAINTIFF_CASES_OTHERS_EXC_SUB", dataId), "start_date",
                "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Litigations as Defendant in non campaign view Others", priority = 70)
    public void LitigationsAsDefendant_in_non_campaign_view_Others() throws Exception {
        entityDetailPage.selectLitDefendantTab();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.DEFENDANT_CASES_OTHERS_EXC_SUB", dataId), "start_date",
                "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Active Litigation Count in non campaign view Others", priority = 71)
    public void Active_Litigations_Count_in_non_campaign_view_Others() throws Exception {
        entityDetailPage.filterActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.ACTIVE_CASES_OTHERS_EXC_SUB", dataId));
    }

    @Test(description = "Verify Active Litigation as Plaintiff Count in non campaign view Others", priority = 72)
    public void Active_Litigations_As_Plaintiff_Count_in_non_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.ACTIVE_PLAINTIFF_CASES_OTHERS_EXC_SUB", dataId));
    }

    @Test(description = "Verify Active Litigation as Defendant Count in non campaign view Others", priority = 72)
    public void Active_Litigations_As_Defendant_Count_in_non_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.ACTIVE_DEFENDANT_CASES_OTHERS_EXC_SUB", dataId));
    }

    @Test(description = "Verify Active Litigations in non campaign view Others", priority = 73)
    public void ActiveLitigations_in_non_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.ACTIVE_CASES_OTHERS_EXC_SUB", dataId), "start_date",
                "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Active Litigations as Plaintiff in non campaign view Others", priority = 74)
    public void ActiveLitigationsAsPlaintiff_in_non_campaign_view_Others() throws Exception {
        entityDetailPage.selectLitPlaintiffTabLink();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.ACTIVE_PLAINTIFF_CASES_OTHERS_EXC_SUB", dataId), "start_date",
                "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Active Litigations as Defendant in non campaign view Others", priority = 75)
    public void ActiveLitigationsAsDefendant_in_non_campaign_view_Others() throws Exception {
        entityDetailPage.selectLitDefendantTab();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.ACTIVE_DEFENDANT_CASES_OTHERS_EXC_SUB", dataId), "start_date",
                "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify InActive Litigation Count in non campaign view Others", priority = 76)
    public void InActive_Litigations_Count_in_non_campaign_view_Others() throws Exception {
        entityDetailPage.filterInActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.INACTIVE_CASES_OTHERS_EXC_SUB", dataId));
    }

    @Test(description = "Verify InActive Litigation as Plaintiff Count in non campaign view Others", priority = 77)
    public void InActive_Litigations_As_Plaintiff_Count_in_non_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.INACTIVE_PLAINTIFF_CASES_OTHERS_EXC_SUB", dataId));
    }

    @Test(description = "Verify InActive Litigation as Defendant Count in non campaign view Others", priority = 77)
    public void InActive_Litigations_As_Defendant_Count_in_non_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.INACTIVE_DEFENDANT_CASES_OTHERS_EXC_SUB", dataId));
    }

    @Test(description = "Verify InActive Litigations in non campaign view Others", priority = 78)
    public void InActiveLitigations_in_non_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.INACTIVE_CASES_OTHERS_EXC_SUB", dataId), "start_date",
                "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify InActive Litigations as Plaintiff in non campaign view Others", priority = 79)
    public void InActiveLitigationsAsPlaintiff_in_non_campaign_view_Others() throws Exception {
        entityDetailPage.selectLitPlaintiffTabLink();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.INACTIVE_PLAINTIFF_CASES_OTHERS_EXC_SUB", dataId),
                "start_date", "case_name", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify InActive Litigations as Defendant in non campaign view Others", priority = 80)
    public void InActiveLitigationsAsDefendant_in_non_campaign_view_Others() throws Exception {
        entityDetailPage.selectLitDefendantTab();
        assertEquals(entityDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("EntityDetail.INACTIVE_DEFENDANT_CASES_OTHERS_EXC_SUB", dataId),
                "start_date", "case_name", "termination_date", "jurisdiction");
    }

}
