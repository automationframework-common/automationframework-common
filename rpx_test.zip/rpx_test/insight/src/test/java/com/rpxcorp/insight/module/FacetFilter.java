package com.rpxcorp.insight.module;

import com.rpxcorp.testcore.element.Element;

import java.util.ArrayList;

public class FacetFilter extends Element {

    public FacetFilter(String facetName) {
        super(".filters:has(>.title:contains('"+facetName+"'))");
    }
    public final Element clearAll= $(".all_none_toggle a");
    public final Element showMore= $("a.more");
    public final Element showLess= $("a.less");
    public final Element moreResult=$(".more-results li:last");
    public final DatePicker from_date=$("input[data-behavior='date_picker'][id^='from']",DatePicker.class);
    public final DatePicker to_date=$("input[data-behavior='date_picker'][id^='to']",DatePicker.class);
    public final Element clearFacet=$(".actions [data-behavior='clear_facet_fields']");
    public final Element submitFacet=$(".actions .submit_button");

    public void showMore() {
        if(showMore.isDisplayed()){
            showMore.click();
            showLess.waitUntilVisible();
            moreResult.waitUntilVisible();
        }
    }
    private void showLess() {
        if(showLess.isDisplayed()){
            showLess.click();
            showMore.waitUntilVisible();
        }
    }
    public ArrayList<String> getSelectedFilter() {
        return $("a:has(div.custom_checkbox.checked)+a span.linkholder").getAllData();
    }
    public ArrayList<String> getAppliedDates() {
        ArrayList<String> data = new ArrayList<>();
        String fromDateValue = from_date.getValue();
        String toDateValue = to_date.getValue();
        if(fromDateValue!=null && !fromDateValue.isEmpty())
            data.add(fromDateValue);
        if(toDateValue!=null && !toDateValue.isEmpty())
            data.add(toDateValue);
        return data;
    }

    public ArrayList<String> getAllFilter() {
        showMore();
       return  $("li .linkholder").getAllData();
    }
    public ArrayList<String> getUnSelectedFilter() {
        showMore();
        return $(".inactive-filters li.linkholder").getAllData();
    }
    private ArrayList<String> getVisibleFilters(){
        return $("li:visible").getAllData();
    }

}
