package com.rpxcorp.insight.page.search;

import com.rpxcorp.insight.module.Facet;
import com.rpxcorp.insight.page.detail.BaseDetailPage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class AssignmentSearchPage extends BaseDetailPage{

    public AssignmentSearchPage() {
        this.url = new PageUrl("advanced_search/search_assignments");
        this.url.param("ASSIGNOR","assignor_ent_alias_names[]");
        this.url.param("ASSIGNEE_TYPE","assignee_types[]");
        this.url.param("PATENT NUMBER","patent_numbers[]");
    }

    @Override
    public boolean at() {
        waitForPageLoad();
        return currentSearch.waitUntilVisible();
    }

    public final Facet litigated_facet = new Facet("div#sidebar form.advanced_search_refine section.filters:has(div:contains('Litigated'))");
    public final Element assignments_results_count = $("div#search_results_replaced_content .metrics_card a:contains(Patent Result) .count");
    public final Element total_result_count = $("div.search-assignments .count-info p");

    public int returnAssignmentsCount() throws Exception{
        int asignmentsCount=0;
        String[] countString = total_result_count.getText().split("of");
        asignmentsCount = Integer.parseInt((countString[1]).replaceAll("[\\D]", "").trim());
        return asignmentsCount;
    }

}


