package com.rpxcorp.insight.module;

import org.openqa.selenium.By;

import com.rpxcorp.testcore.element.Element;

import java.util.ArrayList;

public class Tabs extends Element {

	public Tabs(String selector) {
		super(selector);		
	}

	public Tabs(By selector) {
		super(selector);
	}

	public void loading() {
		new Element(By.cssSelector(".blockUI.blockOverlay")).waitUntilNoElementPresent();
		new Element(By.cssSelector(".blockUI.blockMsg.blockElement>img")).waitUntilNoElementPresent();		
	}
	
	public void select(Object tabName) {
		String value = tabName.toString();
		if(tabName.getClass().isEnum()){
			value=value.replaceAll("_"," ");
		}
		$(">:match('^"+value+"')").click(); //$(">:match('"+value+"$')").click();
		loading();
	}

	public void selectExactTabName(Object tabName) {
		String value = tabName.toString();
		if(tabName.getClass().isEnum()){
			value=value.replaceAll("_"," ");
		}
		$(">:match('^"+value+"$')").click(); //$(">:match('"+value+"$')").click();
		loading();
	}

	public String getActiveTabName() {
		return $(".active").getText();
	}
	public ArrayList<String> getAllTab(){
		return $(">:visible").getAllData();
	}
}
