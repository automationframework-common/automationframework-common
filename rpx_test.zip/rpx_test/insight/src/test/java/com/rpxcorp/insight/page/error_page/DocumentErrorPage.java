package com.rpxcorp.insight.page.error_page;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class DocumentErrorPage extends BasePage {

    @Override
    public boolean at() {
        errorMessage.waitUntilVisible();
        assert getPageTitle().equals("Document Error");
        return errorMessage.waitUntilVisible();
    }

    public final Element errorMessage = $("#content .panel");
}
