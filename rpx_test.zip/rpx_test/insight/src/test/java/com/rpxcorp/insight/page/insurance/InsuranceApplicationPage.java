package com.rpxcorp.insight.page.insurance;

import org.openqa.selenium.By;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;

public class InsuranceApplicationPage extends BasePage {

    public InsuranceApplicationPage() {
        this.url = new PageUrl("insuranceapplication");
    }

    @Override
    public boolean at() {
        pageTitle.waitUntilVisible();
        content.waitUntilVisible();
        return pageTitle.waitUntilTextPresent("RPX Insurance");
    }
    
    public final Element content=$(By.xpath("//p[contains(text(),'Thank you for your interest in RPX Insurance Services. For additional information, please contact your salesperson or send a message to')]//a[@href='mailto:insuranceservices@rpxcorp.com']"));

    public final Element confirm_Btn = $(".insurance-index-body .button[value='Confirm']");
    public final Element iframe = $(".sso-iframe-content.panel #insurance_iframe ");
    public final Element title=$(By.xpath("//h2[text()='My RPX Insurance Services']"));
}
