package com.rpxcorp.insight.page.error_page;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class NotAvailable extends BasePage {


    public final Element logo = $("#logo");

    @Override
    public boolean at() {
    	logo.waitUntilVisible();
        return assertPageTitle("Not Available");
    }

}
