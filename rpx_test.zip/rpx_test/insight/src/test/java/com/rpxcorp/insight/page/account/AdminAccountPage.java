package com.rpxcorp.insight.page.account;

import org.openqa.selenium.By;

import com.rpxcorp.insight.module.DatePicker;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class AdminAccountPage extends BasePage {

    public AdminAccountPage() {
        this.url = new PageUrl("admin/rpx_accounts");
    }

    @Override
    public boolean at() {
        return accountsTable.waitUntilVisible();
    }

    public final Table accountsTable = new Table(".large-9.columns table");
    public final String searchFilters = "//input[contains(@id,'";
    public final Element clearButton = $("#rpx_account_search a.close_button");
    public final Element filterButton = $(".rpx_account_search input[value='Filter']");
    public final Element loading = $(By.cssSelector(".blockUI.blockMsg.blockElement>img"));
    public final Element accountResults = $("#accounts_list tr");
    public final Element accountNameLink=$("#accounts_list tr>td>a");
    public final Element accountType = $(".list tr:has(th:contains('Account Record Type'))>td");
    public final Element isActive = $("#rpx_account_settings_active[checked='checked']");
    public final Element editAccountDetails = $(".list");
    public final Element editHeaderList = $(".list th");
    public final Element currentUsersHeaderList = $("#current_users th:nth-last-child(n+3)");
    public final String[] headerList = { "Name", "Account Record Type", "Active?", "Access to RPX Analyst",
            "Industry", "Owner", "Under NDA?","Show Membership Status?", "Membership Announced?",
            "Membership Start - End Dates", "RPX-ID", "Display Name", "Can view prior art search reports" , "Can view my portfolio"};
    public final String[] currentUsersColumn = { "Name", "Email", "Role", "Last Login", "Patent Viewing" };
    public final String selectYear = ".ui-datepicker-year option[value='";
    public final String selectMonth = ".ui-datepicker-month option[value='";
    public final String selectDate = "//table[@class='ui-datepicker-calendar']//a[text()='";
    public final Element account_Type=$("#q_account_record_type_eq");

    public void enterSearchText(String input, String searchField) {
        clearButton.click();
        $(By.xpath(searchFilters + searchField + "')]")).click();
        getDriver().findElement(By.xpath(searchFilters + searchField + "')]")).sendKeys(input);
    }

    public void clickSearchFilter(String searchField) {
        clearButton.click();
        $(By.xpath(searchFilters + searchField + "')]")).click();
    }
    
    public final DatePicker startDate = new DatePicker("#q_membership_start_date_gteq");
    public final DatePicker endDate = new DatePicker("#q_membership_expiration_date_lteq");
    
    public void clearFilters() {
    	clearButton.click();
        loading.waitUntilInvisible();
    }
    
    public void goToEditAccountPage(String acc_Name) {
    	enterSearchText(acc_Name,"name_cont");
    	filterButton.click();
        loading.waitUntilInvisible();
        accountNameLink.click();
    }
}
