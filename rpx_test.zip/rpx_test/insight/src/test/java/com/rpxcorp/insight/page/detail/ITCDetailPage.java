package com.rpxcorp.insight.page.detail;

import com.rpxcorp.insight.module.ListPanel;
import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import java.util.ArrayList;
import java.util.List;

public class ITCDetailPage extends BaseDetailPage {

    public ITCDetailPage() {
        this.url = new PageUrl("usitc/{ID}");
    }

    // WAIT FOR ITC DETAIL PAGE
    @Override
    public boolean at() {        
        title.waitUntilVisible();
        return waitForLoading();
    }

    // Title
    public final Element itcTitle = $(".presenter-name-cls span:not(.itc-tag)");

    /* CONTENT OF ITC DETAIL PAGE * */
    public final Element title = $(".presenter-name-cls>span:first-child");
    public final Element subTitle = $(".header-info.details.subtitle li:nth-child(1)");
    public final Element filedDate = $(".header-info.details.subtitle li:nth-child(2)");
    public final Element case_type = $("div.small-8.columns.content div.row div:nth-of-type(1) ul li:nth-of-type(1)");
    public final Element dispostion = $("div.small-8.columns.content div.row div:nth-of-type(1) ul li:nth-of-type(2)");
    public final Element court = $("div.small-8.columns.content div.row div:nth-of-type(1) ul li:nth-of-type(3)");
    public final Element judge = $("div.small-8.columns.content div.row div:nth-of-type(1) ul li:nth-of-type(4)");
    public final Element general_counsel = $(
            "div.small-8.columns.content div.row div:nth-of-type(2) ul li:nth-of-type(1)");
    public final Element unfair_import_officer = $(
            "div.small-8.columns.content div.row div:nth-of-type(2) ul li:nth-of-type(2)");
    public final Element country_of_origin = $(
            "div.small-8.columns.content div.row div:nth-of-type(2) ul li:nth-of-type(3)");

    public final Element itcLinkInSubTitle = $(".usitc_link");
    public final Element viewComplaintInSummary = $("#view-complaint");
    public final Element litCampaignLink = $("div[data-url*='related_cases'] div#litigation_campaign_section a[href*='campaign']");

    public final Element viewComplaintLink = $(".panel.overview a#view-complaint");
    public String  getComplaintNumber(){
    	String complaintNumber = "";
    	if(viewComplaintLink.isDisplayed()) {
    		String url = viewComplaintLink.getAttribute("href");
    		complaintNumber = url.substring(url.lastIndexOf('/') + 1).replace(".pdf", "").trim();
    	}
    	return complaintNumber;
    }
//Patent-In-Suit Section Promo
    public final Element itcPatentInformationSignOnMsg = $("div#patents_in_suit+div.content div.subscription-promo-message:contains('Sign In')");
    public final Element itcPatentInformationPromoMsg = $("div#patents_in_suit+div.content div.subscription-promo-message:contains('Start with a Free Trial')");

    public final ListPanel complainants = $("#sidebar", (Configure<ListPanel>) list ->
        {
            list.dataKey(".panel:has(.complainants) li>a");
            list.link("#complainants>ul>li a");
            list.displayedRecords("#complainants ul:not([style*='none']) li a");
            list.viewAllLink("#complainants a.view-all:contains('View All')");
            list.viewLessLink("#complainants a.view-all:contains('View Less')");
        }
    );
    public final Element respondentsNpeTag = $("#respondents span.npe_tag");

    public final ListPanel respondents = $("#sidebar", (Configure<ListPanel>) list ->
        {
            list.dataKey(".panel:has(.respondents) li>a");
            list.link("#sidebar .panel:nth-of-type(2) a");
            list.displayedRecords("#respondents ul:not([style*='none']) li a");
            list.viewAllLink("#respondents a.view-all:contains('View All')");
            list.viewLessLink("#respondents a.view-all:contains('View Less')");
        }
    );

    public final StaticContent subtitle = $(".subtitle", (Configure<StaticContent>) dataForm ->
        {
            dataForm.content("investigation_number", "li:nth-child(1)");
            dataForm.content("filed_date", "li:contains(Filed)");
            dataForm.content("terminated", "li:contains(Terminated)");
        }
    );
    
    public final StaticContent complainantTerminatedDate = $("#complainants", (Configure<StaticContent>) dataForm ->
    	{
	        dataForm.content("unique_id", "li a");
	        dataForm.content("terminated_date", "li div[class='status']");	        
    	}
    );
    
    public final StaticContent disposition  = $("#respondents", (Configure<StaticContent>) dataForm ->
		{
	        dataForm.content("unique_id", "li a");
	        dataForm.content("disposition", "li div[class='status']");
		}
    );
    public final Element complainantLink = $("ul.complainants div.lawfirm_link:has(span:contains('Counsel:'))");

    public final StaticContent complainantLawfirmContent = $("#complainants", (Configure<StaticContent>) dataForm ->
		{
	        dataForm.content("unique_id", "li>a");
	        dataForm.content("lawfirm_name", "div[class='lawfirm_link']");
		}
	);
    public final Element respondentsLink = $("ul.respondents div.lawfirm_link:has(span:contains('Counsel:'))");
    public final StaticContent respondentLawfirmContent = $("#respondents", (Configure<StaticContent>) dataForm ->
		{
	        dataForm.content("unique_id", "li>a");
	        dataForm.content("lawfirm_name", "div[class='lawfirm_link']");
		}
	);

    public final Table patent_table = $("table.patents-in-suit-table", (Configure<Table>) table ->
        {
            table.uniqueId("td:nth-child(2) a[href]");
            table.viewAllLink(By.xpath("//div[contains(@class, 'patents-in-suit')][not(@id)]//a[text()='View All']"));
            table.viewLessLink(By.xpath("//div[contains(@class, 'patents-in-suit')][not(@id)]//a[text()='View Less']"));
            table.displayedRecords(".patents-in-suit-table tbody tr:not([style*='none'])");
        }
    );

    public final Element lit_Campaign=$("div.content:has('div#lit-campaign')");
    public final Element respondent_Count=$("#respondents .round-shape");
    public final Element complainants_Count=$("#complainants .round-shape");
    public final Element patent_in_Suit_Count=$(".patents-in-suit>h4:contains('Patents-in-Suit')");
    
    public final Element viewAsSearchPatentInSuit = $("div.block-header:has(.section-title:contains('Patent Information')) li.view-link a");
    public final Element noPatentsInPatentInSuitMsg = $(".empty-lit-patents span");
    
    public final Tabs litigationCampaignTabs = new Tabs("#lit-campaign .tabs");
    public final Table camp_accused_table = $("#related_accused_products_table", (Configure<Table>) table ->
    	{
    		table.uniqueId("td:nth-child(2) a[href]");
    		table.viewAllLink(By.xpath("//div[contains(@id, 'simple4')]//a[text()='View All']"));
    		table.viewLessLink(By.xpath("//div[contains(@id, 'simple4')]//a[text()='View Less']"));
    		table.displayedRecords("#related_accused_products_table tbody tr:not([style*='none'])");
    	}
    );

    public final Table camp_patent_table = $("#related_patents_table_wrapper", (Configure<Table>) table ->
    	{
    		table.uniqueId("td:nth-child(1)");
    		table.viewAllLink(By.xpath("//div[contains(@id, 'simple3')]//a[text()='View All']"));
    		table.viewLessLink(By.xpath("//div[contains(@id, 'simple3')]//a[text()='View Less']"));
    		table.displayedRecords("#related_patents_table_wrapper tbody tr:not([style*='none'])");
    	}
    );
    public final Element noPatentsInLitCamp = $("#simple3 span");
    public final Element litCampViewAsSearchResults = $("div#litigation_campaign_section div.view-link.mobile-search-results-view");
    
    public final Table litigation_cases = $(".litigations_table", (Configure<Table>) table ->
    	{
    		table.uniqueId("td:nth-child(3)");
    		table.viewAllLink(By.xpath("//div[contains(@id, 'simple1')]//a[text()='View All']"));
    		table.viewLessLink(By.xpath("//div[contains(@id, 'simple1')]//a[text()='View Less']"));
    		table.displayedRecords(".litigations_table tbody tr:not([style*='none'])");
    	}
    );
    
    public final StaticContent overview_panel = $(".panel.overview .content", (Configure<StaticContent>) dataForm ->
    	{
	    	dataForm.content("case_type", ".block-header:contains(Case)");
	    	dataForm.content("disposition", ".block-header:contains(Disposition)");
	    	dataForm.content("court", ".block-header:contains(Court)");
            dataForm.content("status", ".block-header:contains(Status)");
	    	dataForm.content("judge", ".block-header:contains(Judge)");
	    	dataForm.content("general_counsel", ".block-header:contains(General)");
	    	dataForm.content("unfair_import_officer", ".block-header:contains(Office of Unfair)");
	    	dataForm.content("country_of_origin", ".block-header:contains(Country of Origin)");
            dataForm.content("fedcircuit_appeal" , ".block-header:contains(Federal Circuit Appeal)");
    	}
    );

    public final Table defendant_table = $("#campaign_defendants", (Configure<Table>) table ->
        {
            table.uniqueId("td:nth-child(1)>a:last-child");
            table.viewAllLink(".campaign_defendants a.view-all");
            table.viewLessLink(By.xpath("//div[@id='simple2']//a[text()='View Less']"));
            table.row("table#campaign_defendants>tbody>tr[role='row']");
            table.subTable($(".nested_inner_table", (Configure<Table>) subTable ->
                {
                    subTable.uniqueId("td:nth-child(3) a[href]");
                }
            ));
            table.expandSubTableLink(".open.cursor-pointer");
            table.displayedRecords("#campaign_defendants tbody tr:not([style*='none'])");
        }
    );
    public final Element noDefendantsNotes = $("#simple2 .note");
    public final Element litigationSearchBox = $(".dataTables_filter div.search_text_container>input[type='text']");
    public void defendantSearch(String searchTerm) {
        litigationSearchBox.sendKeys(searchTerm);
        waitForLoading();
    }
    public final Element noDataInDefendantTable = $("#campaign_defendants .dataTables_empty");
    
    public final Element caseTabLink = $("#lit-campaign a[href='#simple1']");
    public final Element defendantsTabLink = $("#lit-campaign a[href='#simple2']");
    public final Element patentsTabLink = $("#lit-campaign a[href='#simple3']");
    public final Element accusedProductsTabLink = $("#lit-campaign a[href='#simple4']");  
    
    public final StaticContent metricsSection = $(".panel-metrics", (Configure<StaticContent>) dataForm ->
    {
    	dataForm.content("complainantCount", "div.metrics_card a[href='#complainants'] .count");
    	dataForm.content("respondentsCount", "div.metrics_card a[href='#respondents'] .count");
    	dataForm.content("patentsInSuitCount", "div.metrics_card a[href='#patents_in_suit']");
    	dataForm.content("docketEntriesCount", "div.metrics_card a[href='#docket_entries_sections'] .count");
    }
    		);

    public final Element docketEntriesClearBtn = $("#dockets_wrapper span.search_action_container a#clear_docket_form");
    public final Element docketEntrySearchBtn = $("#dockets_wrapper div.search_container span.search_action_container input[name='commit']");
    public final Element docketEntriesSearchBox = $("#dockets_wrapper input#docket_entry_text");

    public void searchDocketEntries(String searchKey) {
        docketEntriesSearchBox.sendKeys(searchKey);
        docketEntrySearchBtn.click();
        loading.waitUntilInvisible();
    }
    public void docketEntriesSearch(String searchText) {
        if (!docketEntriesClearBtn.isDisplayed()) {
            searchDocketEntries(searchText);
        }else {
            docketEntriesClearBtn.click();
            loading.waitUntilInvisible();
            docketEntriesClearBtn.waitUntilInvisible();
            searchDocketEntries(searchText);
        }
    }


    // Docket Entries section
    public final Element docketEntries_count = $("#dockets_wrapper .section-subtitle");
    public final Element docketSearchValue = $("#docket_entry_text[value]");
    public final String docketEntriesColumn = "#docket_entries tbody>tr:not(:nth-of-type(2n))>td:nth-of-type(";
    public final String docketEntriesHeader = "#docket_entries thead";
    public final Element docketEntryLink = $(
            "#docket_entries tbody tr a:not([data-target='docket_entry_attachment_modal'])");
    public final Element docketEntriesActivePage = $("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li[class='current']");
    public final Element docketEntryTitle = $("#docket_entries tbody>tr:nth-child(even)");
    public final Element docketEntriesColumnSize = $("#docket_entries tbody>tr:not(:nth-of-type(2n))");
    public final Element docketEntriesnextPage = $("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:last-child");
    public final Element docketEntriesnextPageDisable = $(
            "#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:last-child[class='arrow unavailable']");
    public final Element docketEntriesLastPage = $("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:nth-last-child(2)");
    public final Element docketEntriesLastPageSelected = $(
            "#dockets_wrapper ul.pagination.pagination li:nth-last-child(2)[class='current']");
    public final Element docketEntriesNextPageSelected = $(
            "#dockets_wrapper ul.pagination.pagination li:nth-of-type(3)[class='current']");
    public final Element docketEntriesPreviousPageSelected = $(
            "#dockets_wrapper ul.pagination.pagination li:nth-last-child(3)[class='current']");
    public final Element docketEntriesPreviousPage = $("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:first-child");
    public final Element docketEntriesFirstPage = $("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:nth-child(2)");
    public final Element docketEntriesThirdPage = $("#dockets_wrapper ul.pagination.pagination li:nth-child(4)");
    public final Element docketEntriesFirstPageSelected = $(
            "#dockets_wrapper ul.pagination.pagination li:nth-child(2)[class='current']");
    public final Element docketEntriesPreviousPageDisabled = $(
            "#dockets_wrapper ul.pagination.pagination li:first-child[class='arrow unavailable']");
    public final Table docketEntries = $("#docket_entries", (Configure<Table>) table ->
        {
            table.row("tbody>tr:nth-child(odd)");
            table.uniqueId(" td:nth-of-type(1) ");
           table.nextPage("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:last-child");
           table.lastPage("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:nth-last-child(2)");
            table.subTable(new Table("tbody>tr:nth-child(even)"));
            table.viewAllLink(By.xpath("//*[@id='dockets_wrapper']//a[text()='View All']"));
            table.viewLessLink(By.xpath("//*[@id='dockets_wrapper']//a[text()='View Less']"));
            table.displayedRecords("#dockets_wrapper tbody>tr, #dockets_wrapper>div:not([style*='none']) tbody>tr");
        }
    );

    //DOCKET SECTION
    public final Element docket_entries = $("#docket_entries", (Configure<ListPanel>) list ->
            {
                list.dataKey("tbody tr");
            }
    );

    // COMPLAINANT PANEL
    public final Element complainantNpeTag = $("#sidebar span.npe_tag");
    public final Element respondentNpeTag = $("#respondents ul.respondents span.npe_tag");


    // FUNCTIONLITIES IN ITC DETAIL PAGE
    public void selectdefendantsTab() {
        if (defendantsTabLink.isDisplayed()) {
            defendantsTabLink.click();
            waitForPageLoad();
        }
    }

    public void selectPatentTab() {
        if (patentsTabLink.isDisplayed()) {
            patentsTabLink.click();
            waitForPageLoad();
        }
    }

    public void selectAccusedProductsTab() {
        if (accusedProductsTabLink.isDisplayed()) {
            accusedProductsTabLink.click();
            waitForPageLoad();
        }
    }

    // TODO Make this code generic with jquery selector concept
    public void expandAlldefandant() {
        if (defendant_table.isDisplayed()) {
        	if(!defendant_table.subtable().isDisplayed()) {
        		JavascriptExecutor js = (JavascriptExecutor) getDriver();
        		js.executeScript("$('#campaign_defendants tr[class]').click()", "");
        		waitForPageLoad();
        	}
        }
    }

    public List<String> getColumnDataForDocketTable(String columnName) {
        List<String> columnData = new ArrayList<String>();
        int columnIndex = docketEntries.getColumnIndex(columnName, docketEntriesHeader);
        columnData = $(docketEntriesColumn + columnIndex + ")").getAllData();
        return columnData;

    }

    // DOCKET ENTRY - ASSOCIATED DOCUMENTS POPUP DAILOG
    public final Table docketAssociatedDocumentsTable = $(".xlarge.open .docket_attachments_table", (Configure<Table>) table ->
        {
            table.selectedPage("#docket_entry_attachment_table_content ul.pagination.pagination li.current");
            table.prevoius("#docket_entry_attachment_table_content ul.pagination.pagination li:first-child");
            table.firstPage("#docket_entry_attachment_table_content ul.pagination.pagination li:first-child+li");
            table.next("#docket_entry_attachment_table_content ul.pagination.pagination li:last-child");
           table.lastPage("#docket_entry_attachment_table_content ul.pagination.pagination li:nth-last-child(2)");
            table.viewAllLink(By.xpath("//*[@id='docket_entry_attachment_table_content']//a[text()='View All']"));
            table.viewLessLink(By.xpath("//*[@id='docket_entry_attachment_table_content']//a[text()='View Less']"));
        }
    );

    public final Element docketWithManyDocs = $("a[data-id='183213']");
    public final Element docketWithLessDocs = $("a[data-id='183240']");
    public final Element docketAssociatedDocumentsTitle = $(".xlarge.open h4");
    public final Element docketLinkInAssociatedDocumentsDialog = $(".xlarge.open .docket_attachments_table a.document");
    public final Element closeAssociatedDocumentsDialog = $(".xlarge.open a.close-reveal-modal");

    public void closeAssociatedDocumentsDialog() {
        if (docketAssociatedDocumentsTable.isDisplayed()) {
            closeAssociatedDocumentsDialog.click();
            docketAssociatedDocumentsTable.waitUntilInvisible();
        }
    }
    
    
    //Role Authorization for Alerts
    public final Element itc_Events=$("input#ITC_Events:not([class*='greyed-out'])");
    public final Element rpx_Reports_Events=$("input#RPX_Reports:not([class*='greyed-out'])");
    public final Element prior_art_Report_Event=$("input#alert_event__400:not([class*='greyed-out'])");
    public final Element event_Promotional_Msg=$(".events_promotional_msg a[href='/payments/options']");
}

