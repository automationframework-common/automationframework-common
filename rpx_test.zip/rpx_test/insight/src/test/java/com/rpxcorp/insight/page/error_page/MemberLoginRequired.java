package com.rpxcorp.insight.page.error_page;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import org.openqa.selenium.By;

public class MemberLoginRequired extends BasePage {

	  @Override
	    public boolean at() {
	        pageTitle.waitUntilVisible();
	        content.waitUntilVisible();
	        return pageTitle.waitUntilTextPresent("Login Required");
	    }

	    public final Element content=$("p:contains('Access to the full article is currently available to RPX members only.') a[href='mailto:insight@rpxcorp.com']");
}
