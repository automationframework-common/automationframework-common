package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.detail.VenueDetailPage;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.TableData;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
@Authenticate(role = "MEMBER")
@Test(groups = "Venue")
public class VenueDetailTest extends BaseDataTest {
    VenueDetailPage venueDetailPage;
    TableData tableData;
    Map<String, String> staticData;
    ResultSet resultSet;
    HashMap<String, TableData> subData = new HashMap<String, TableData>();

    @Factory(dataProvider = "returnData")
    public VenueDetailTest(String dataDescription, String venueID) {
        this.dataId = venueID;
        this.dataDescription = dataDescription;
    }

    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("VenueDetail");
    }

    @BeforeClass
    public void loadPage() {
        urlData.put("ID", dataId);
        this.dataUrl = venueDetailPage.getDeclaredUrl(urlData);
        to(venueDetailPage, urlData);
    }

    @Test(description = "Verify Title", priority = 1)
    public void Verify_Title() throws Exception {
        assertEquals(venueDetailPage.pageTitle.getData(), sqlProcessor.getResultData("VenueDetail.TITLE", dataId),
                "title");
    }

    @Test(description = "Verify Active Cases associated to Venue", priority = 2)
    public void Verify_Active_Cases() throws Exception {
        staticData = venueDetailPage.venue_Detail.getData();
        assertEquals(staticData.get("Active Cases"),
                sqlProcessor.getResultCount("VenueDetail.LITIGATIONS_ACTIVE_COUNT", dataId), "active_cases");

    }

    @Test(description = "Verify InActive Cases associated to Venue", priority = 3)
    public void Verify_InActive_Cases() throws Exception {
        assertEquals(staticData.get("Inactive Cases"),
                sqlProcessor.getResultCount("VenueDetail.LITIGATIONS_INACTIVE_COUNT", dataId), "inactive_cases");
    }

    @Test(description = "Verify Average cases per year for the Venue", priority = 4)
    public void Verify_Average_Cases_Per_Year() throws Exception {
        assertEquals(staticData.get("Average Cases per Year"),
                sqlProcessor.getResultData("VenueDetail.AVERAGE_CASES_PER_YEAR", dataId), "average_cases_per_year");
    }

    @Test(description = "Verify Average case length for the Venue", priority = 5)
    public void Verify_Average_Case_Length() throws Exception {
        assertEquals(staticData.get("Average Case Length"),
                sqlProcessor.getResultData("VenueDetail.AVERAGE_CASE_LENGTH", dataId),
                "average_length_of_case_in_days");
    }

    @Test(description = "Verify Cases by Market Sector section", priority = 6)
    public void Verfiy_Cases_By_Market_Sector() throws Exception {
        assertEquals(venueDetailPage.cases_By_Market_Sector.getData(),
                sqlProcessor.getResultData("VenueDetail.CASES_BY_MARKET_SECTOR", dataId));
    }

    @Test(description = "Verify Litigation Section for All Cases", priority = 7)
    public void Verify_Litigation_All() throws Exception {
        venueDetailPage.litigation_Section.waitUntilVisible();
        assertEquals(venueDetailPage.litigation_Section.getData(),
                sqlProcessor.getResultData("VenueDetail.LITIGATIONS_ALL", dataId));
    }

    @Test(description = "Verify Litigation Section for Active Cases", priority = 8)
    public void Verify_Litigation_Active() throws Exception {
        venueDetailPage.applyCaseFilterForLitigation("Active");
        assertEquals(venueDetailPage.litigation_Section.getData(),
                sqlProcessor.getResultData("VenueDetail.LITIGATIONS_ACTIVE", dataId));
    }

    @Test(description = "Verify Litigation Section for InActive Cases", priority = 9)
    public void Verify_Litigation_Inactive() throws Exception {
        venueDetailPage.applyCaseFilterForLitigation("InActive");
        assertEquals(venueDetailPage.litigation_Section.getData(),
                sqlProcessor.getResultData("VenueDetail.LITIGATIONS_INACTIVE", dataId));
    }

    @Test(description = "Verify Orders Outcome table", priority = 9)
    public void orders_outcome() throws Exception {
        assertEquals(venueDetailPage.ORDERS_OUTCOME.getData(),
                sqlProcessor.getResultData("VenueDetail.ORDER_OUTCOME", dataId));
    }

    @Test(description = "Verify Order Table - ", dataProvider = "orderText", priority = 9)
    public void Verify_Orders(String orderType, String outcome, String query) throws Exception {
        venueDetailPage.closePopup();
        venueDetailPage.viewOrdersTable(orderType, outcome);
        TableData orders_table = venueDetailPage.venueProfile_orders_table.getData();      
        subData.put(orderType, venueDetailPage.venueProfile_orders_table.getPopupSubtableData());        
        venueDetailPage.closePopup();    
        assertEquals(orders_table, sqlProcessor.getResultData("VenueDetail.ORDER_" + query, dataId));
        assertEquals(subData.get(orderType),
                sqlProcessor.getResultData("VenueDetail.ORDERS_SUBTABLE_" + query, dataId));

    }

   /* @Test(description = "Verify Verdicts Table- ", dataProvider = "verdictText", priority = 12)
    public void Verify_Verdicts(String verdictType, String query) throws Exception {
        venueDetailPage.clickOnVerdictOutcome(verdictType);
        TableData orders_table = venueDetailPage.venue_verdicts_table.getData();
        venueDetailPage.closeVerdictPopup();
        assertEquals(orders_table, sqlProcessor.getResultData("VenueDetail.VERDICTS_" + query, dataId));
    }*/

    // @Test(description = "Verify Verdicts Sub Table -",
    // dataProvider="verdictText", priority = 13)
    public void Verify_Verdicts_Sub_Table(String verdictType, String query) throws Exception {
        assertEquals(subData.get(verdictType),
                sqlProcessor.getResultData("VenueDetail.VERDICTS_SUBTABLE_" + query, dataId));
    }

    @DataProvider(name = "orderText")
    public Object[][] orderText() {
        return new Object[][] { { "Preliminary Injunction", "", "Preliminary_Injunction" }, { "Preliminary Injunction", "Granted", "Preliminary_Injunction_GRANTED" },
                { "Preliminary Injunction", "Denied", "Preliminary_Injunction_DENIED" }, { "Preliminary Injunction", "Partial", "Preliminary_Injunction_PARTIAL" },
                { "Permanent Injunction", "", "Permanent_Injunction" }, { "Permanent Injunction", "Granted", "Permanent_Injunction_GRANTED" }, { "Permanent Injunction", "Denied", "Permanent_Injunction_DENIED" },
                { "Permanent Injunction", "Partial", "Permanent_Injunction_PARTIAL" },
                { "JMOL", "", "JMOL" },
                { "JMOL", "Granted", "JMOL_GRANTED" }, { "JMOL", "Denied", "JMOL_DENIED" },
                { "JMOL", "Partial", "JMOL_PARTIAL" },
                { "Summary judgment", "", "SUMMARY_JUDGEMENT" },
                { "Summary judgment", "Denied", "SUMMARY_JUDGEMENT_DENIED" },
                { "Summary judgment", "Partial", "SUMMARY_JUDGEMENT_PARTIAL" },
                { "Summary judgment", "Granted", "SUMMARY_JUDGEMENT_GRANTED" } };
    }

    @DataProvider(name = "verdictText")
    public Object[][] verdictText() {
        return new Object[][] { { "PLAINTIFF PATENTEE", "PLAINTIFF_PATENTEE" },
                { "PLAINTIFF NON PATENTEE", "PLAINTIFF_NON_PATENTEE" }, { "DEFENDANT PATENTEE", "DEFENDANT_PATENTEE" },
                { "UNAVAILABLE", "UNAVAILABLE" } };
    }

    @Test(description = "Verify Recent Activities", priority = 14)
    public void Recent_Activity() throws Exception {
        assertEquals(venueDetailPage.recentActivity.getData(),
                sqlProcessor.getResultData("VenueDetail.RECENT_ACTIVITY", dataId));
    }
}