package com.rpxcorp.insight.page.search;

import com.rpxcorp.insight.module.Facet;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.Keys;

import java.util.List;

public class MarketPlaceSearchPage extends BasePage {

    public MarketPlaceSearchPage() {
        this.url = new PageUrl("advanced_search/search_marketplaces") {
            {
                param("CURRENT SEARCH", "searchq");
                param("header_type", "header_search_type");
                param("STAGE", "mapped_stage[]");
                param("TECHNOLOGY AREA", "categories[]");
                param("SELLER/BROKER", "account_name[]");
                param("CURRENT ASSIGNEE", "curr_assignees[]");
                param("ORIGINAL ASSIGNEE", "orig_assignee[]");
                param("CLAIM CHARTS", "claim_charts[]");
                param("LITIGATED", "is_litigated[]");
                param("EST. PRIORITY FROM DATE", "from_priority_date");
                param("EST. PRIORITY TO DATE", "to_priority_date");
                param("INTAKE FROM DATE", "from_intake_date");
                param("INTAKE TO DATE", "to_intake_date");
                param("BID DEADLINE FROM DATE", "from_bid_deadline");
                param("BID DEADLINE TO DATE", "to_bid_deadline");
            }
        };
    }

    @Override
    public boolean at() {
        waitForPageLoad();
        return current_search.waitUntilVisible();
    }

    /* CONTENT OF MARKET PLACE SEARCH PAGE * */
    public final Facet litigated_facet = new Facet("div#sidebar form.advanced_search_refine section.filters:has(div:contains('Litigated'))");
    public final Element currentSearch = $("#searchq_revised");
    public final Facet current_search = new Facet("section.filters:nth-of-type(1)");
    public final Element acquisition_opportunities_count = $("div.search-marketplace .entity-top-section .count-info");
    public final Element acquisition_noResult_Msg = $("div.search-marketplace h2.no-results");
    public final Element seller_material_download_lnk = $("i.icon-briefcase");
    public final Element seller_material_dialog = $(".reveal-modal.xlarge.open");
    public final Element seller_material_dialog_close = $(".reveal-modal.xlarge.open a.close-reveal-modal");
    public final Element seller_material_Doc_link = $(".reveal-modal.xlarge.open table a");
    public final Element marketPlaceAdvLink = $("div.global_search_select_holder li:has(a:contains('Marketplace'))");
    public final Element acquisition_opportunity_link = $(".search-results table.results tr a.title");
    public final Table search_result = $(".search-results table.results", (Configure<Table>) table ->
        {
            table.column("Porttfolio Name", "tr a.title");
            table.column("US Patents", ".group_stats td:nth-child(4)");
            table.column("Patents", ".result-count");
        }
    );

    public final Table search_result_header_data = $(" .search-results table.results ", (Configure<Table>) table ->
        {
            table.uniqueId("td a[href].title");
            table.column("name", "tr a.title");
            table.column("us_patents_seller", ".group_stats td:nth-child(4)");
            table.column("intake_date", ".group_stats tbody tr td:eq(2)");
            table.column("bid_deadline_date", ".group_stats tbody tr td:eq(6)");
            table.column("stage", ".group_stats tbody tr td:eq(3)");
        }
    );

    public final Table search_result_patents = $(" .group-item ", (Configure<Table>) table ->
        {
            table.uniqueId("td a[href]");
            table.column("patnum", "td:eq(1)");
        }
    );
    public final Facet stage =$(".filters.collapsible.uncollapsed:nth-of-type(2) ", (Configure<Facet>) facet ->
        {
            facet.viewAllLink(".filters.collapsible.uncollapsed:nth-of-type(2) div.controls a.more");
            facet.uniqueId("span.label_text");
            facet.column("count", " .count ");
            facet.closePopup("div.reveal-modal.open a.small.button.secondary.close-reveal-modal.cancel_btn");
        }
    );

    public final Facet tech_Area =$("ul.refine_facets_list ", (Configure<Facet>) facet ->
        {
            facet.viewAllLink("div.controls a[data-facet-group='Technology Area']");
            facet.uniqueId("span.label_text");
            facet.column("count", " .count ");
            facet.closePopup("div.reveal-modal.open a.small.button.secondary.close-reveal-modal.cancel_btn");
        }
    );

    public final Facet seller_Broker =$("ul.refine_facets_list ", (Configure<Facet>) facet ->
        {
            facet.viewAllLink("div.controls a[data-facet-group='Seller/Broker']");
            facet.activationlink("form.advanced_search_refine section:nth-of-type(4)");
            facet.uniqueId("span.label_text");
            facet.column("count", " .count ");
            facet.closePopup("div.reveal-modal.open a.small.button.secondary.close-reveal-modal.cancel_btn");
        }
    );

    public final Facet current_Assignee =$("ul.refine_facets_list ", (Configure<Facet>) facet ->
        {
            facet.viewAllLink("div.controls a[data-facet-group='Current Assignee']");
            facet.activationlink("form.advanced_search_refine section:nth-of-type(5)");
            facet.uniqueId("span.label_text");
            facet.column("count", " .count ");
            facet.closePopup("div.reveal-modal.open a.small.button.secondary.close-reveal-modal.cancel_btn");
        }
    );

    public final Facet original_Assignee =$("ul.refine_facets_list ", (Configure<Facet>) facet ->
        {
            facet.viewAllLink("div.controls a[data-facet-group='Original Assignee']");
            facet.activationlink("form.advanced_search_refine section:nth-of-type(6)");
            facet.uniqueId("span.label_text");
            facet.column("count", " .count ");
            facet.closePopup("div.reveal-modal.open a.small.button.secondary.close-reveal-modal.cancel_btn");
        }
    );

    public final Facet claim_Charts =$("ul.refine_facets_list ", (Configure<Facet>) facet ->
        {
            facet.activationlink("form.advanced_search_refine section:nth-of-type(7)");
            facet.uniqueId("span.label_text");
            facet.column("count", " .count ");
            facet.closePopup("div.reveal-modal.open a.small.button.secondary.close-reveal-modal.cancel_btn");
        }
    );

    public final Facet litigated =$("ul.refine_facets_list ", (Configure<Facet>) facet ->
        {
            facet.activationlink("form.advanced_search_refine section:nth-of-type(8)");
            facet.uniqueId("span.label_text");
            facet.column("count", " .count ");
            facet.closePopup("div.reveal-modal.open a.small.button.secondary.close-reveal-modal.cancel_btn");
        }
    );

    public void searchInMarketPlaceResultsPage(String searchKey) {
        selectSearchType("Marketplace");
        searchTextBox.sendKeys(searchKey + Keys.ENTER);
        search_result.waitUntilVisible();
    }

    public final Table facet_search_result_header_data = $(" .search-results table.results ", (Configure<Table>) table ->
        {
            table.uniqueId("td a[href].title");
            table.column("portfolio_name", "tr a.title");
            // table.column("est_priority_date",".group_stats tbody tr
            // td:nth-child(2)");
            table.column("intake_date", ".group_stats tbody tr td:nth-child(3)");
            table.column("us_patents", ".group_stats tbody tr td:nth-child(4)");
            table.column("stage", ".group_stats tbody tr td:nth-child(5)");
            table.column("bid_deadline", ".group_stats tbody tr td:nth-child(7)");
        }
    );


    public int getMarketPlaceCount(){
        int acquisitionCountInt =0;
        if(!acquisition_noResult_Msg.isPresent()){
            String[] acquisitionCount = acquisition_opportunities_count.getText().split(" of ");
            acquisitionCountInt = Integer.parseInt((acquisitionCount[1]).replaceAll("[\\D]", "").trim());
        }else if(acquisition_noResult_Msg.isPresent()){
            acquisitionCountInt = 0;
        }
        ;
        return acquisitionCountInt;
    }
    public List<String> getUniqueIDs_grouped() {
        return facet_search_result_header_data.getUniqueId_Values();
    }

    public final Element marketPlaceSearchResults= $(".search-marketplace .grouped_results a.pat-title");

}
