package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.module.SelectBox;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import org.openqa.selenium.By;

import java.util.ArrayList;
import java.util.Map;

public class CreateUserPage extends BasePage {

    public CreateUserPage() {
        this.url = new PageUrl("admin/users/new");
    }

    @Override
    public boolean at() {
        return firstName.waitUntilVisible();
    }
    
    //FORM ELEMENTS
    public final Element firstName = $("#user_first_name");
    public final Element lastName = $("#user_last_name");
    public final Element email = $("#user_email");    
    public final Element user_Can_View_Patents= $("input#user_user_permission_attributes_can_view_patents");
    public final Element user_Prior_Art_Download= $("input#user_user_permission_attributes_prior_art_download_enabled");
    public final Element costAnalyticsOption = $("#user_user_permission_attributes_can_view_cost_analytics");
    public final Element alphaTesterOption = $("#user_alpha_tester");
    public final Element subscription_expiration_date=$("#user_extended_user_detail_attributes_trial_expiration_date");
    public final Element disabledOptions = $(By.xpath("//div[contains(@class, 'profile_body')]//div[contains(@class, 'boolean')]/input[@disabled='disabled']/../label"));
    public final Element enabledOptions = $(By.xpath("//div[contains(@class, 'profile_body')]//div[contains(@class, 'boolean')]/input[not(@disabled='disabled')][not(@type='hidden')]/../label"));
    public final Element selectedOptions = $(By.xpath("//div[contains(@class, 'profile_body')]//div[contains(@class, 'boolean')]/input[not(@disabled='disabled')][not(@type='hidden')][@checked='checked']/../label"));
    public final Element deselectedOptions = $(By.xpath("//div[contains(@class, 'profile_body')]//div[contains(@class, 'boolean')]/input[not(@disabled='disabled')][not(@type='hidden')][not(@checked='checked')]/../label"));
    public final Element validationMessage= $(".error small");
    public final Element allMandatoryMessage =$("form.new_user div.validation_error_message>small");
    public final SelectBox userRole =$("#s2id_user_user_role_users_attributes_0_user_role_id",SelectBox.class);
    public final SelectBox userAccount =$("#s2id_user_account_id",SelectBox.class);
    public final Element saveUserBtn = $("input[value='Save User']");

    public void createUser(Map<String, String> userInfo) throws Exception {
    	enterNewUserValues(userInfo.get("first_name"),
    			userInfo.get("last_name"), userInfo.get("mail_id"),
    			userInfo.get("user_role"),null);
    	if (userInfo.containsKey("can_view_patents")) {
    		if (userInfo.get("can_view_patents").equalsIgnoreCase("true")) 
    			user_Can_View_Patents.select();
    		else 
    			user_Can_View_Patents.unSelect();			
    	}
    	if (userInfo.containsKey("can_download_rpx_pilot")) {
    		if (userInfo.get("can_download_rpx_pilot").equalsIgnoreCase("true")) 
    			user_Prior_Art_Download.select();
    		else 
    			user_Prior_Art_Download.unSelect();			
    	}
    	if (userInfo.containsKey("can_view_cost_analytics")) {
    		if (userInfo.get("can_view_cost_analytics").equalsIgnoreCase("true")) 
    			costAnalyticsOption.select();
    		else 
    			costAnalyticsOption.unSelect();			
    	}
    	if (userInfo.containsKey("alpha_tester")) {
    		if (userInfo.get("alpha_tester").equalsIgnoreCase("true"))
    			alphaTesterOption.select();
    		else
    			alphaTesterOption.unSelect();			
    	}
        //$("#user_user_permission_attributes_can_view_new_insight").click();
    	saveUserBtn.click();
    }

    public void createUser(String fName, String lName, String emailId, String role) throws Exception {
        enterNewUserValues(fName, lName, emailId, role,null);
        saveUserBtn.click();
    }
    public ArrayList<String> getAllMandatoryMessage(){
       return allMandatoryMessage.getAllData();
    }
    public void enterNewUserValues(String fName, String lName, String emailId, String role,String account) throws Exception {
        firstName.sendKeys(fName);
        lastName.sendKeys(lName);
        email.sendKeys(emailId);
        userRole.select(role);
        if(account != null){
            userAccount.typeAndselect(account);
        }else if(!role.equalsIgnoreCase("prime")||!role.equalsIgnoreCase("plus")||!role.equalsIgnoreCase("basic")) {
        	userAccount.typeAndselect("Google LLC");
        }
    }
}
