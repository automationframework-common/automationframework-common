package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.LoginPage;
import com.rpxcorp.testcore.UITest;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.ExcelUtil;
import com.rpxcorp.testcore.util.SQLProcessor;
import org.testng.ITest;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

public class BaseDataTest extends UITest implements ITest {
	String dataId, dataUrl, dataDescription;
	String testName;
	static final ExcelUtil testDataSheet = new ExcelUtil(
			ConfigUtil.config().get("testResourcesDir") + "/test_data/DataTest.xls");
	static HashMap<String, Object[][]> testData = null;
	HashMap<String, String> urlData = new HashMap<String, String>();
	protected SQLProcessor sqlProcessor= SQLProcessor.getInstance();
	LoginPage loginPage;
	static long startTime;

	@BeforeSuite
	public void startTime() {
		testData = null;
		startTime =  System.currentTimeMillis();
	}

	@AfterSuite
	public void endTime() {
		System.out.println("Total time Taken :" + (System.currentTimeMillis() - startTime) / 1000);
	}


	@Override
	public String getTestName() {				
		return this.dataDescription
				+ (((this.dataId != null && !this.dataId.contains("select")) || (this.dataId != null && this.dataDescription != this.dataId)) ? " : " + this.dataId : "") + ";"
				+ this.dataUrl;
	}

	public synchronized static Object[][] getTestData(String testDataName) throws Exception {
		if (testData == null)
			setupTestData();
		return testData.get(testDataName);
	}

	private static void setupTestData() throws Exception {
		testData = new HashMap<String, Object[][]>();
		String testMode = ConfigUtil.config().getProperty("TEST_DATA_MODE");
		if (testMode ==null || testMode.endsWith("Excel")) {
			String[] dataSheets = testDataSheet.getAllSheetName();
			for (String dataSheet : dataSheets) {
				testData.put(dataSheet, testDataSheet.getAllDataFromColumn(dataSheet, new Object[] { 0, 1 }));
			}
		} else {
			String[][] dataQueries = testDataSheet.getAllDataFromColumn("DataQuery", new Object[] { 0, 1 });
			SQLProcessor sqlProcessor = SQLProcessor.getInstance();
			HashMap<String, String> queryParams = new HashMap<String, String>();
			queryParams.put("LIMIT_VALUE", ConfigUtil.config().getProperty("RANDOM_COUNT"));
			for (String[] dataQuery : dataQueries) {
				ResultSet resultSet = sqlProcessor.getResultDataFromQuery(dataQuery[1], queryParams);
				testData.put(dataQuery[0], resultSetToArray(resultSet));
				if (dataQuery[0].equals("EntityDetail"))
					queryParams.put("entityIds", getDataIdasString(resultSet));

			}
		}
	}

	// TODO Migrate this method to SQL processor as generic method
	private static Object[][] resultSetToArray(ResultSet resultSet) throws Exception {
		resultSet.last();
		Object[][] data = new Object[resultSet.getRow()][2];
		resultSet.beforeFirst();
		int index = 0;
		while (resultSet.next()) {
			data[index][0] = normalizeHtmlcode(resultSet.getString("data_description"));
			data[index][1] = resultSet.getString("data_id");
			index++;
		}
		return data;
	}

	// TODO Migrate this method to SQL processor as generic method
	protected static String getDataIdasString(ResultSet resultSet) throws SQLException {
		String ids = "";
		resultSet.beforeFirst();
		while (resultSet.next()) {
			ids = ids + "," + resultSet.getString(1);
		}
		if (ids.length() > 0)
			ids = ids.substring(1);
		return ids;
	}

	private static String normalizeHtmlcode(String value) {
		if (value == null)
			value = "";
		value = value.replaceAll("\u201c", "\"");
		value = value.replaceAll("\u201d", "\"");
		value = value.replaceAll("\u00A9", " ");
		return value = value.replaceAll("[^\\x00-\\x7F]", " ");
	}
	
	public void logoutAndLogin(String userName, String password) {
		loginPage = to(loginPage);
		loginPage.logout();
		setAuth(null);
		loginPage.login(userName, password);
		loginPage.waitForDashboardPage();
		setAuth(userName+"::"+"");
	}
	
	public String getPageId(String data) throws Exception {
		if(data.toLowerCase().contains("select")){
			ResultSet rs = sqlProcessor.getResultDataFromQuery(data, null);
			return sqlProcessor.getSingleValue(rs, 1); 			
		} else 
			return data;		
	}
	
	public void loadPage(String caseNum, String isGrouped) {
		this.urlData.clear();	
		this.urlData.put("CURRENT SEARCH", caseNum);
		this.urlData.put("GROUPED", isGrouped);		
	}
}
