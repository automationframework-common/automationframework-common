package com.rpxcorp.insight.page.error_page;

import org.openqa.selenium.By;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class MemberPromotionalPage extends BasePage {

    @Override
    public boolean at() {
        contact_us.waitUntilVisible();
        return false;
    }
    
    public final Element contact_us = $("div.columns div.subscription-promo-message>p:contains(members only.) a:contains('contact us')");
}
