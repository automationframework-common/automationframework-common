package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.module.Table;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;

public class EmailListPage extends Page {

    public EmailListPage() {
        this.url = new PageUrl("admin/emails");
    }

    @Override
    public boolean at() {
        return email_table.waitUntilVisible();
    }

    public final Element email_table = new Table("#emails table");

}
