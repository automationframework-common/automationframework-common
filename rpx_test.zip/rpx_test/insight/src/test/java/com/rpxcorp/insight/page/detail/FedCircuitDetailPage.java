package com.rpxcorp.insight.page.detail;

import com.rpxcorp.insight.module.ListPanel;
import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

public class FedCircuitDetailPage extends BaseDetailPage{

    public FedCircuitDetailPage() {
        this.url = new PageUrl("federal_circuit/{ID}");
    }

    @Override
    public boolean at() {
        loading.waitUntilNoElementPresent();
        waitForPageLoad();
        return detailPageTitle.waitUntilVisible();
    }
    public final Element fcTitle = $("div.detail-page-title>h1.detail-page-title");
    public final Element overviewCaseType= $("div.overview-items div.block-header div.block-value.color-red");

    public final Element viewAppealNoticeBtn = $("div.view-complaint-container>a:contains('View Appeal Notice')");
    public final Element appealNoticeUnavailable = $("#appeal_document:contains('Appeal Notice Unavailable')");

    //Getting Count
    public final Element appellant_count = $("#plaintiff_container div.round-shape");
    public final Element appellee_count = $("#defendants_container div.round-shape");
    public final Element accused_product_count = $("div[data-url$='accused_products'] .round-shape");
    public final Element accused_product_section = $("div#accused_pdts", (Configure<ListPanel>) list ->
            {
                list.viewAllLink(".panel.force_word_break .view-all");
                list.dataKey(" div ");
            }
    );
    public final Element patentInSuitHeader = $("#lit-campaign2 h4");
    public final Element docket_entries_count = $(".docket_entries_title h4");
    public final Table docket_entries = $("#docket_entries", (Configure<Table>) table ->
            {
                //table.uniqueId("td:nth-of-type(1) a[class='document'][href]");
                table.nextPage("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:last-child");
                table.lastPage("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:nth-last-child(2)");
                table.viewAllLink(By.xpath("//*[@id='dockets_wrapper']//a[text()='View All']"));
                table.viewLessLink(By.xpath("//*[@id='dockets_wrapper']//a[text()='View Less']"));
                table.displayedRecords("#dockets_wrapper tbody>tr, #dockets_wrapper>div:not([style*='none']) tbody>tr");
            }
    );

    public final Element docket_SignOnMsg=$("div#docket_entries_sections+div.content div.subscription_promo_message:contains('Please'):contains('to see additional information.')>a.reveal_login_from_grey_out");
    public final Element accused_product_panel = $("#accused_products div.accused_product_style");
    public final Element accused_product_panel_promo = $("div#accused_products div.subscription_promo_message:contains('Accused products are not included in your current subscription level. Please')>a[href='/subscribe']");
    public final Element accused_product_panel_promo_signin = $("div#accused_products div.subscription_promo_message:contains('Please'):contains('to see additional information.')>a.reveal_login_from_grey_out");

    public final Element no_accused_products = $("#simple4 span:contains('No accused products found')");
    public final Element accused_product_litcampaign_promo = $("div#simple4 div.subscription_promo_message:contains('Accused products are not included in your current subscription level. Please'):contains('your account.')>a[href='/subscribe']");
    public final Element accused_product_litcampaign_promo_signin = $("div#accused_products div.subscription_promo_message:contains('Please'):contains('to see additional information.')>a.reveal_login_from_grey_out");

    public final StaticContent headerContent  = $("#content>div.row.detail ul.header-info", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("appeal_number", "li:nth-of-type(1)");
                dataForm.content("filed", "li:nth-of-type(2)");
                dataForm.content("closed", "li:nth-of-type(3)");
                dataForm.content("latest_docket_entry", "li:nth-of-type(4)");
            }
    );

    public final StaticContent statsBarConent  = $(".panel-metrics", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("appellant", "div.metrics_card:contains(Appellant) .count");
                dataForm.content("appellee", "div.metrics_card:contains(Appellees) .count");
                dataForm.content("accused_products", "div.metrics_card:contains(Accused Product) .count");
                dataForm.content("patent_in_suit", "div.metrics_card:contains(Patents in Suit) .count");
                dataForm.content("docket_entry", "div.metrics_card:contains(Docket Entries) .count");
                dataForm.content("days_in_appeal", "div.metrics_card:contains(Days In Appeal) .count");
            }
    );

    public final StaticContent overviewConent  = $("div.overview", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("case_type", "li:contains(Case) span");
                dataForm.content("origin_case_number", "li:contains(Originating Case)");
                dataForm.content("court", "li:contains(Court)");
                dataForm.content("judges", "li:contains(Judge)");
            }
    );

    public final StaticContent overviewContentOrginCases  = $("div.overview", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("origin_case_number_lit", "div:contains('Originating Case')>div.block-value>a[href^='/litigation/']");
                dataForm.content("origin_case_number_ptabs", "div:contains('Originating Case')>div.block-value>a[href^='/ptab/']");
                dataForm.content("origin_case_number_itc", "div:contains('Originating Case')>div.block-value>a[href^='/usitc/']");
            }
    );

    public final Table patent_table = $("table.patents-in-suit-table", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(2) a[href]");
                table.viewAllLink(By.xpath("//div[contains(@class, 'patents-in-suit')][not(@id)]//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[contains(@class, 'patents-in-suit')][not(@id)]//a[text()='View Less']"));
                table.displayedRecords(".patents-in-suit-table tbody tr:not([style*='none'])");
            }
    );

    public final Element lit_Campaign=$("div.content:has('div#lit-campaign')");
    public final Element titleLinkPatentInSuit = $(".patents-in-suit-table tbody td a[class='lit_doc']");
    public final Element patentInfoViewAsSearch = $("div#patent_information a[href*='search_patents']");
    public final Element noPatentInSuitMsg = $("#patents_in_suit span");

    public final Table appellantPartiesContent = $("#plaintiff_container", (Configure<Table>) table ->
            {
                table.viewAllLink(By.xpath("//div[@id='plaintiff_container']//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[@id='plaintiff_container']//a[text()='View Less']"));
                table.displayedRecords("#plaintiff_container ul:not([style*='none']) li>a:not([class]):visible");
                table.uniqueId("ul>li>a:nth-of-type(1)");
                table.column("ent_name", "ul>li>a:nth-of-type(1)");
                table.column("counsel_details", "ul li>div:last-child");
            }
    );

    //Role Auth
    public final Element appellantSection = $("#plaintiff_container ul>li>a:nth-of-type(1)");
    public final Element appelleeSection =$("#defendants_container ul>li>a:nth-of-type(1)");

    public final Element AppellantsSectionEntityLink = $("#plaintiff_container>ul>li>a[href^='/entity/']");
    public final Element counselInfoArrowInAppellantSection = $("#plaintiff_container li a[class*=arrow]");
    public final Element counselContentInAppellantSection = $("#plaintiff_container li .counsel-content");
    public final Element showAllCounselInAppellantSection = $(By.xpath("//div[@id='plaintiff_container']//a[text()='Show All Counsel']"));
    public final Element hideAllCounelInAppellantSection = $(By.xpath("//div[@id='plaintiff_container']//a[text()='Hide All Counsel']"));
    public final Element plaintiff_showAllCounsel = $("div#plaintiff_container a:contains('Show All Counsel')");


    public final Table appelleePartiesContent = $("#defendants_container", (Configure<Table>) table ->
            {
                table.viewAllLink(By.xpath("//div[@id='defendants_container']//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[@id='defendants_container']//a[text()='View Less']"));
                table.displayedRecords("#defendants_container ul:not([style*='none']) li>a:not([class]):visible");
                table.uniqueId("ul>li>a:nth-of-type(1)");
                table.column("ent_name", "ul>li>a:nth-of-type(1)");
                table.column("counsel_details", "ul li>div:last-child");
            }
    );

    public final Table otherPartiesContent = $("#other_parties_container", (Configure<Table>) table ->
            {
                table.viewAllLink(By.xpath("//div[@id='defendants_container']//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[@id='defendants_container']//a[text()='View Less']"));
                table.displayedRecords("#defendants_container ul:not([style*='none']) li>a:not([class]):visible");
                table.uniqueId("ul>li>a:nth-of-type(1)");
                table.column("ent_name", "ul>li>a:nth-of-type(1)");
                table.column("counsel_details", "ul li>div:last-child");
            }
    );

    public final Element appelleeSectionEntityLink = $("#defendants_container>ul>li>a[href^='/entity/']");
    public final Element counselInfoArrowInAppelleeSection = $("#defendants_container li a[class*=arrow]");
    public final Element counselContentInAppelleeSection = $("#defendants_container li .counsel-content");
    public final Element hideAllCounelInAppelleeSection = $("div#defendants_container a:contains('Hide All Counsel')");
    public final Element appellee_showAllCounsel = $("div#defendants_container a:contains('Show All Counsel')");



    public final Table litigation_cases = $(".litigations_table", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(3)");
                table.viewAllLink(By.xpath("//div[contains(@id, 'simple1')]//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[contains(@id, 'simple1')]//a[text()='View Less']"));
                table.displayedRecords(".litigations_table tbody tr:not([style*='none'])");
            }
    );

    public final StaticContent case_name_number_Link = $(".litigations_table", (Configure<StaticContent>) content ->
            {
                content.content("itc_case_name", "td.itc_lit_title:nth-child(2)>a[href^='/usitc/']");
                content.content("itc_case_number", "td.itc_lit_title:nth-child(2)+td>a[href^='/usitc/']");
                content.content("fc_case_name", "td.itc_lit_title:nth-child(2)>a[href^='/federal_circuit/']");
                content.content("fc_case_number", "td.itc_lit_title:nth-child(2)+td>a[href^='/federal_circuit/']");
                content.content("lit_case_name", "td.itc_lit_title:nth-child(2)>a[href^='/litigation/']");
                content.content("lit_case_number", "td.itc_lit_title:nth-child(2)+td>a[href^='/litigation/']");
                content.content("cn_case_name", "td.itc_lit_title:nth-child(2)>a[href^='/litigation/china/']");
                content.content("cn_case_number", "td.itc_lit_title:nth-child(2)+td>a[href^='/litigation/china/']");
            }
    );

    public final Tabs litigationCampaignTabs = new Tabs("#lit-campaign dl");
    public final Element caseTabLink = $("#lit-campaign a[href='#simple1']");
    public final Element defendantsTabLink = $("#lit-campaign a[href='#simple2']");
    public final Element patentsTabLink = $("#lit-campaign a[href='#simple3']");
    //public final Element accusedProductsTabTable = $("#lit-campaign #related_accused_products_table");

    public final Table patent_accused_table = $("#lit-campaign div.active table", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(2) a[href]");
            }
    );

    public final Table defendant_table = $("#campaign_defendants", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(1)>a:last-child");
                table.viewAllLink(".campaign_defendants a.view-all");
                table.viewLessLink(By.xpath("//div[@id='simple2']//a[text()='View Less']"));
                table.row("table#campaign_defendants>tbody>tr[role='row']");
                table.subTable($(".nested_inner_table", (Configure<Table>) subTable ->
                {
                    subTable.uniqueId("td:nth-child(3) a[href]");
                }));
                table.expandSubTableLink(".open.cursor-pointer");
                table.displayedRecords("#campaign_defendants tbody tr:not([style*='none'])");
            }
    );
    public final Element noDataInDefendantTable = $("#campaign_defendants .dataTables_empty");
    //public final Element litCampDefendantTabDefParentLink = $("#campaign_defendants tbody tr td:nth-of-type(1) a");
    public final Element litCampDefendantTabDefLink = $("#campaign_defendants tbody td:nth-of-type(2) a");
    public final Element litCampDefendantMostRecentCaseLink = $("#campaign_defendants tbody td:nth-of-type(3) a");
    public final Element noDefendantsNotes = $("#lit-campaign #simple2 .note");
    public final Element defendantSearchBox = $(".dataTables_filter div.search_text_container>input[type='text']");
    public void defendantSearch(String searchTerm) {
        defendantSearchBox.sendKeys(searchTerm);
        waitForLoading();
    }

    public final Element caseNameLinkInLitCampDefTabSubTable = $("#campaign_defendants .nested_inner_table td:nth-of-type(3) a");
    public final Element caseNoLinkInLitCampDefTabSubTable = $("#campaign_defendants .nested_inner_table td:nth-of-type(4) a");
    public final Element campLinkInLitCampSection=$("#lit-campaign a[href*='campaign']");
    public final Element litigation_Section_PromoMsg=$("div#lit-campaign div.content.active div.subscription-promo-message:contains('Start with a Free Trial')");
    public final Element litigation_section_SignOnMsg=$("div#lit-campaign div.content.active div.subscription-promo-message:contains('Sign In')");


    public final Table camp_patent_table = $("#related_patents_table_wrapper", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(2) a[href]");
                table.viewAllLink(By.xpath("//div[contains(@id, 'simple3')]//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[contains(@id, 'simple3')]//a[text()='View Less']"));
                table.displayedRecords("#related_patents_table_wrapper tbody tr:not([style*='none'])");
            }
    );

    public void selectDefendantTab() {
        if (defendantsTabLink.isDisplayed()) {
            defendantsTabLink.click();
            waitForPageLoad();
        }
    }

    public void selectCasesTab() {
        if (caseTabLink.isDisplayed()) {
            caseTabLink.click();
            waitForPageLoad();
        }
    }


    public void selectPatentTab() {
        if (patentsTabLink.isDisplayed()) {
            patentsTabLink.click();
            waitForPageLoad();
        }
    }

    public final Table patentInLitigationCampaign = $("#lit-campaign div.active table", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(1)");
            }
    );

    public void expandAlldefandant() {
        if (defendant_table.isDisplayed()) {
            if(!defendant_table.subtable().isDisplayed()) {
                defendant_table.viewAll();
                $(".campaign_defendants .open.cursor-pointer:not([style=\"display: inline-block;\"])").getElements().forEach(element -> {
                    element.click();
                    waitForSectionLoading();
                });

            }
        }
    }

    public final Table PATENT_TABLE = $(".patents-in-suit-table ", (Configure<Table>) table ->
            {
                table.uniqueId(" .lit_doc ");
                table.viewAllLink(By.xpath("//div[@id='patents_in_suit']//span/a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[@id='patents_in_suit']//span/a[text()='View Less']"));
                table.displayedRecords(".patents-in-suit-table tbody tr:not([style*='none'])");
            }
    );
}
