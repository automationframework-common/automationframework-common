package com.rpxcorp.insight.page.payment;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.Select;

import java.util.HashMap;
import java.util.Map;

public class PaymentCheckoutPage extends BasePage {
    public PaymentCheckoutPage() {
        this.url = new PageUrl("payments/checkout");
    }

    @Override
    public boolean at() {
        rpx_Logo.waitUntilVisible();
        loading.waitUntilInvisible();
        return payment_Button.waitUntilVisible();
    }

    public final Element promoCmsHeader = $(".panel>div>h4");

    // Card Elements
    public final Element payment_Button = $(".pay_button input");
    public final Element startTrialBtn = $(".pay_button input[value='Start Free Trial']");//input[name='process_payment']

    public void clickStartTrialButton(){
        ((JavascriptExecutor) getDriver()).executeScript("window.scrollBy(0,-250)", "");
        ((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", startTrialBtn.getElement());
    }

    public final Element cardNumber = $("#credit-card-number");
    public final Element cardExpiredDate = $("#expiration");
    public final Element cardCVV = $("#cvv");
    public final Element cardPostalCode = $("#postal-code");

    public final Element user_subscription = $("#subscribe_for");
    // public final Element subscription_plan=$("#subscription_plan");
    public final Element subscription_plan = $("#plan_token");
    // public final Element selected_subscription=$("#subscribe_for
    // option[selected='selected']");

    public final Element terms_and_conditionsText = $("div.agree_checkbox");
    public final Element terms_and_conditions = $("#terms_and_conditions");
    public final Element iframe = $("#braintree-dropin-frame");
    public final Element iframeAddCardModal = $("#braintree-dropin-modal-frame");
    public final Element cardNumberInvalid = $(".card-label.credit-card-number-label.show-label.invalid");
    public final Element cardExpiredDateInvalid = $(".card-label.expiration-label.show-label.invalid");
    public final Element cardCvvInvalid = $(".card-label.cvv-label.show-label.invalid");
    public final Element cardPostalCodeInvalid = $(".card-label.postal-code-label.show-label.invalid");
    public final Element planName = $("select#plan_token");

    public final Element timelineTitle = $(By.xpath("//h2[contains(text(),'Add your payment information')]"));
    public final Element upsellContent = $(".large-8.medium-12.columns .panel");
    public final Element upsellContentTitle = $(".content-faq .more-feature h5");

    public final Element partialPaymentError = $(".large-12.columns.text-center h4");
    public final Element partialPaymentErrorContactUs = $(By.xpath("//h4//a[contains(text(),'Contact Us')]"));
    public final Element checkoutSignIn = $(".panel.promotional_content .reveal_login_from_grey_out");

    public final Element timeline_bar = $(".progress.small-centered.columns.small-6.round");
    public final Element countryDropdown = $("#s2id_user_details_country_code");
    public final Element countrySearch = $("div.select2-search input.select2-input:visible");
    public final Element countrySelect = $("ul.select2-results li:nth-of-type(1)");

    public final Element paymentErrorMsg = $(".payment_error_message");

    public final Element error_msg = $(".server-error-message");

    public final Element promocode_Value = $("input#promo_code_value");
    public final Element promocode_ApplyBtn = $("a[data-behavior='apply_promo_code']");
    public final Element promocode_Msg = $("form#payments_checkout_form div#promo_code_message");
    public final Element promocodemsg_displayBillingPrice = $("div#promo_code_message>span:first-child");
    public final Element promocodemsg_displayBillingDate = $("div#promo_code_message>span:last-child");
    public final Element promocode_ErrorMsg = $("form#payments_checkout_form div#promo_code_error");

    public void applyPromocode(String promoCode) throws Exception{

        waitForLoading();
        waitForRequestInit();
        Thread.sleep(2000);
        promocode_Value.sendKeys(promoCode);
        Thread.sleep(2000);
        promocode_ApplyBtn.click();
        promocode_ApplyBtn.waitUntilTextPresent("Clear");
    }

    public void applyInvalidPromocode(String promoCode) {
        promocode_Value.sendKeys(promoCode);
        promocode_ApplyBtn.click();
        promocode_ErrorMsg.waitUntilVisible();
    }

    public void clearPromocode() {
        promocode_ApplyBtn.click();
        promocode_ApplyBtn.waitUntilTextPresent("Apply");
    }

    public void selectCountry(String country) throws  Exception{
        final WebDriverException[] exception = new WebDriverException[1];
        try {
            countryDropdown.waitUntilVisible();
            countryDropdown.scrollAndFocus();
            Thread.sleep(2000);
            countryDropdown.click();
            countrySearch.waitUntilVisible();
            countrySearch.sendKeys(country + Keys.RETURN);
        } catch (WebDriverException e) {
            exception[0] = e;
                System.out.println("The Excpetion in selecting country is "+e);
                countryDropdown.click();
                countrySearch.waitUntilVisible();
                countrySearch.sendKeys(country + Keys.RETURN);
            }

    }
    /***
     * Input Card details based on key values
     * 
     * @param cardData
     */
    public void enterCardDetails(HashMap<String, String> cardData) throws  Exception{
        iframe.waitUntilSwitchToFrame();
        cardNumber.waitUntilVisible();
        cardNumber.sendKeys(cardData.get("Card_Number"));
        cardExpiredDate.sendKeys(cardData.get("Card_Exp"));
        cardCVV.sendKeys(cardData.get("Card_Cvv"));
        cardPostalCode.sendKeys(cardData.get("Card_Postal"));
        getDriver().switchTo().defaultContent();
        selectCountry(cardData.get("country"));
    }

    //new payment method

    public void enterCardDetailsnew(Map<String, String> cardData) throws  Exception{
        iframe.waitUntilSwitchToFrame();
        cardNumber.waitUntilVisible();
        cardNumber.sendKeys(cardData.get("card_number"));
        cardExpiredDate.sendKeys(cardData.get("card_exp"));
        cardCVV.sendKeys(cardData.get("card_cvv"));
        cardPostalCode.sendKeys(cardData.get("card_postal"));
        getDriver().switchTo().defaultContent();
        selectCountry(cardData.get("country"));
    }

    public void enterCardInformation(Map<String, String> purchaseDetails) {
    	 iframe.waitUntilSwitchToFrame();
    	 cardNumber.waitUntilVisible();
         cardNumber.sendKeys(purchaseDetails.get("card_number"));
         cardExpiredDate.sendKeys(purchaseDetails.get("expiration_date"));
         cardCVV.sendKeys(purchaseDetails.get("cvv"));
         cardPostalCode.sendKeys(purchaseDetails.get("postal_code"));
         getDriver().switchTo().defaultContent();
    }
    

    public void enterPaymentInformation(String cardNo, String expDate, String cvv, String postalCode, String country) throws  Exception{
    	iframe.waitUntilSwitchToFrame();
    	cardNumber.waitUntilVisible();
    	cardNumber.sendKeys(cardNo);
    	cardExpiredDate.sendKeys(expDate);
    	cardCVV.sendKeys(cvv);
    	cardPostalCode.sendKeys(postalCode);
    	getDriver().switchTo().defaultContent();
    	selectCountry(country);
    }

    public void payFromCheckout(String cardNo, String expDate, String cvv, String postalCode, String country, String planType) throws  Exception{
    	new Select(subscription_plan).selectByVisibleText(planType);
    	enterPaymentInformation(cardNo, expDate, cvv, postalCode, country);
    	acceptTerms();
    	payment_Button.click();
    	waitForLoading();
    }

    //new payment method
    public void payFromCheckoutNew(String cardNo, String expDate, String cvv, String postalCode, String country , String planName) throws  Exception{
        enterPaymentInformation(cardNo, expDate, cvv, postalCode, country);
        new Select(subscription_plan).selectByVisibleText(planName);
        acceptTerms();
        clickStartTrialButton();
        waitForLoading();
    }

    public void selectUserSubscription(String userRole) {
        Select selectRole = new Select(getDriver().findElement(By.id("subscribe_for")));
        selectRole.selectByValue(userRole);
    }

    public void selectPaymentPlanMVP(String plan) {
        Select selectPlan = new Select(getDriver().findElement(By.id("subscription_plan")));
        selectPlan.selectByVisibleText(plan);
    }

    public void selectPaymentPlan(String plan) {
        Select selectPlan = new Select(getDriver().findElement(By.id("plan_token")));
        selectPlan.selectByVisibleText(plan);
    }

    public void selectPaymentPlanNew(String plan) throws Exception{
        planName.selectByOption(plan);
        Thread.sleep(2000);
        waitForRequestInit();
    }

    public String getPaymentValue() {
        String payment = payment_Button.getAttribute("value");
        String[] paymentAmt = payment.split(" ");
        return paymentAmt[1];
    }

    public String getSubscriptionRole() {
        Select selectRole = new Select(getDriver().findElement(By.id("subscribe_for")));
        return selectRole.getFirstSelectedOption().getText().trim();
    }

    public String getSubscriptionPlan() {
        // Select selectPlan = new
        // Select(getDriver().findElement(By.id("subscription_plan")));
        Select selectPlan = new Select(getDriver().findElement(By.id("plan_token")));
        selectPlan.getFirstSelectedOption().getText();
        return selectPlan.getFirstSelectedOption().getText().trim();
    }

    public String getSubscriptionPlanMVP() {
        Select selectPlan = new Select(getDriver().findElement(By.id("subscription_plan")));
        selectPlan.getFirstSelectedOption().getText();
        return selectPlan.getFirstSelectedOption().getText().trim();
    }

    public void acceptTerms() {
        if (!terms_and_conditions.isSelected())
            terms_and_conditions.click();
    }

    public String getUpsellRole(String role) {
        String upsell = null;
        switch (role) {
        case "Plus":
            upsell = "Prime";
            break;
        case "Prime":
            upsell = "Elite";
            break;
        }
        return upsell;

    }

    public boolean getTimelineCurrentStage(int index) {
        boolean flag = false;
        if (getDriver()
                .findElement(By.cssSelector("span:nth-of-type(" + index + ")[class='meter secondary current_stage']"))
                .isDisplayed())
            flag = true;
        return flag;
    }

    public String[] getStageColor() {
        String[] colors = new String[3];
        for (int index = 1; index <= 3; index++) {
            if (getDriver()
                    .findElement(By.cssSelector(
                            ".progress.small-centered.columns.small-6.round span:nth-of-type(" + index + ")"))
                    .getCssValue("background-color").contentEquals("rgba(4, 148, 254, 1)")) {
                colors[index - 1] = "blue";
            } else if (getDriver()
                    .findElement(By.cssSelector(
                            ".progress.small-centered.columns.small-6.round span:nth-of-type(" + index + ")"))
                    .getCssValue("background-color").contentEquals("rgba(186, 188, 190, 1)")) {
                colors[index - 1] = "grey";
            }
        }
        return colors;
    }

    public void enterPaymentInformation(Map<String, String> purchaseDetails) throws  Exception{
        enterCardInformation(purchaseDetails);
        selectCountry(purchaseDetails.get("country"));
      }
    
    public final Element default_card_Info=$(".payment-method-item.card-label span.payment-method-description");

    public String getDefCardLast2Digit() {
       iframe.waitUntilSwitchToFrame();
       String last2Digit=default_card_Info.getText().substring(default_card_Info.getText().length()-2, default_card_Info.getText().length());
       getDriver().switchTo().defaultContent();
       return last2Digit;
       
    }

    public final Element change_payment_method=$("#choose-payment-method");
    public final Element add_payment_method=$(".add-payment-method-item span");
    public final Element add_new_payment_method=$(".add-payment-method-view button.payment-method-add");
    public final Element payment_btn_In_AddCard=$("#payments_checkout_form .payment_button");
   // public final Element add_card_form_modal=$(".add-payment-method-view.modal-frame-view");
    
    public void payViaNewPaymentProcess(Map<String, String> cardData) throws InterruptedException {
    	iframe.waitUntilSwitchToFrame();
    	change_payment_method.waitUntilClickable();
    	change_payment_method.click();
    	getDriver().switchTo().defaultContent();
    	iframeAddCardModal.waitUntilSwitchToFrame();
    	add_payment_method.waitUntilClickable();
    	add_payment_method.click();
    	getDriver().switchTo().defaultContent();
    	iframeAddCardModal.waitUntilSwitchToFrame();
    	loading.waitUntilInvisible();
    	getDriver().switchTo().defaultContent();
    	iframeAddCardModal.waitUntilSwitchToFrame();
    	addCard(cardData.get("card_number"),cardData.get("expiration_date"),cardData.get("cvv"),cardData.get("postal_code"));
    	add_new_payment_method.click();       
    	getDriver().switchTo().defaultContent();
    	getDriver().switchTo().defaultContent();
    	Thread.sleep(5000);
    	payment_btn_In_AddCard.waitUntilClickable();
    	payment_btn_In_AddCard.click();       
    }

	private void addCard(String cardNo, String expDate, String cvv, String postalCode) {		
		cardNumber.waitUntilVisible();
	    cardNumber.sendKeys(cardNo);
	    cardExpiredDate.sendKeys(expDate);
	    cardCVV.sendKeys(cvv);
	    cardPostalCode.sendKeys(postalCode);    	
	}
		


}
