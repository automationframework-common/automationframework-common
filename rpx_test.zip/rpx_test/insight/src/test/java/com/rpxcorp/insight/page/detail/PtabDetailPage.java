package com.rpxcorp.insight.page.detail;

import com.rpxcorp.insight.module.ListPanel;
import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

public class PtabDetailPage extends BaseDetailPage {

    public PtabDetailPage() {
        this.url = new PageUrl("ptabs/{ID}");
    }

    @Override
    public boolean at() {
        waitForPageLoad();
        return title.waitUntilVisible();
    }

    public final Element ptabPageUpgradePromoMessage = $("section#content div:contains('PTAB page is not included in your current subscription. Please')>a:contains('upgrade')");
    public final StaticContent metricsSection = $(".panel-metrics", (Configure<StaticContent>) dataForm ->
    {
    	dataForm.content("petitionerCount", ".metrics_card:contains(Petitioner) .count");
    	dataForm.content("patentOwnerCount", ".metrics_card:contains(Patent Owner) .count");
    	dataForm.content("challengedPatentCount", ".metrics_card:contains(Challenged Patent) .count");
    	dataForm.content("docketEntriesCount", ".metrics_card:contains(Docket Entries) .count");
    }
    		);

    /* CONTENT OF PTAB DETAIL PAGE * */
    public final Element title = $(".presenter-name-cls>span:first-child");//h1.presenter-name-cls>span[title]
    public final Element techCenter_Link = $(".block-name:contains('Tech Center')+div a[href]");
    public final Element petition_doc_link = $("a#view-petition");

    public final Element petition_status=$("#view-petition");
    public final StaticContent subtitle = $(".subtitle", (Configure<StaticContent>) dataForm ->
        {
            dataForm.content("Case_Number", "li:nth-child(1)");
            dataForm.content("Date_Filed", "li:contains(Filed)");
            dataForm.content("Institution_Decision_Date", "li:contains(Institution Decision)");
            dataForm.content("Last_Docket_Entry", "li:contains(Last Docket Entry)");
            dataForm.content("Final_Decision_Date", "li:contains(Final Decision)");
            dataForm.content("Termination_Date", "li:contains(Terminated)");

        }
    );
    public final Element Patent_Trail_And_Appeal_Board=$(".subtitle li a");
    public final StaticContent case_Detail = $(".panel.overview .content.overview-items", (Configure<StaticContent>) dataForm ->
        {
            dataForm.content("Status", ".block-header:contains('Status')");//.block-header:has(.block-name:contains('Status'))
            dataForm.content("Case_Type", ".block-header:contains('Case Type')");//.block-header:has(.block-name:contains('Case Type'))
            dataForm.content("Tech_Center", ".block-name:contains('Tech Center')+div a[href]");
            dataForm.content("Cause_of_Action", ".block-header:has(.block-name:contains('Cause of Action'))");
            //dataForm.content("Administrative_Patent_Judges", "li:contains(Administrative Patent Judges)");
            dataForm.content("Administrative_Judges", ".block-header:contains(Administrative Judges)");
            dataForm.content("Panel_Judges",".block-header:contains(Panel Judges)");
            dataForm.content("Expert", ".block-header:contains(Expert)");
            dataForm.content("Institution_Decision", ".block-header:contains('Institution Decision')");
            dataForm.content("Final_Decision", ".block-header:contains('Final Decision')");
            dataForm.content("fedcircuit_appeal" , ".block-header:contains('Federal Circuit Appeal')");
        }
    );

    public final Element petitionerCountStatsBar=$(".subtitle li a");

    public final Table challenge_table = $("table.patents-in-suit-table", (Configure<Table>) table ->
        {
            table.uniqueId("td a[href]:last-child");
            table.displayedRecords(".patents-in-suit-table tbody tr");
            table.viewAllLink(By.xpath("//a[text()='View All']"));
            table.viewLessLink(By.xpath("//a[text()='View Less']"));
        }
    );

    public final Element challenged_patent_ViewAsSearchResults=$("#challenged_patent a:contains('View as Search Results')");
    public final Element challenged_patent_Count=$(By.xpath("//h2[contains(text(),'Challenged Patent')]"));

    public final Table petition_table = $(".related_petitions_table", (Configure<Table>) table ->
        {
            table.uniqueId("td:nth-child(3) a[href]");
            table.viewAllLink(By.xpath("//div[@id='related_petitions_petitions']/a[text()='View All']"));
            table.viewLessLink(By.xpath("//div[@id='related_petitions_petitions']/a[text()='View Less']"));
            table.displayedRecords("#related_petitions_petitions tbody tr:not([style='display: none;'])");
            table.tdViewAllLink(By.cssSelector("td:nth-child(4)"));
        }
    );

    public final Table petitioners_table = $("#related_petitions_petitioners table",Table.class);

    public final Element petitioner_expand_Link=$("#related_petitions_petitioners div:nth-of-type(1) div.handle");
    public final Element petitioner_Link=$("#related_petitions_petitioners div:nth-of-type(1) div.handle>a");

    public final Element petitionerCount = $("#petitioner_container div.round-shape");
    public final Element patentOwnerCount = $("#patent_owner_container div.round-shape");
    public final Element realPartyInInterestCount = $("#real_party_in_interest_container>h2");
    public final Element privyCount = $("#privy_container>h2");

    public final Element petitionsaActiveTab=$("div#related-case-type dd.active"); ////dd[@class='active']/a

    public final Table petitionerParties = $("#petitioner_container", (Configure<Table>) table ->
    {
    	table.viewAllLink(By.xpath("//div[@id='petitioner_container']//a[text()='View All']"));
    	table.viewLessLink(By.xpath("//div[@id='petitioner_container']//a[text()='View Less']"));
    	table.uniqueId("ul li>a[href]:not(.counsel)");
    	table.column("ent_name", "ul li>a[href]:not(.counsel)");
    	table.column("counsel_details", "ul li>div:last-child");
    }
    		);

    public final Table patentOwnerParties = $("#patent_owner_container", (Configure<Table>) table ->
    {
    	table.viewAllLink(By.xpath("//div[@id='patent_owner_container']//a[text()='View All']"));
    	table.viewLessLink(By.xpath("//div[@id='patent_owner_container']//a[text()='View Less']"));
    	table.uniqueId("ul li>a[href]:not(.counsel)");
    	table.column("ent_name", "ul li>a[href]:not(.counsel)");
    	table.column("counsel_details", "ul li>div:last-child");
    }
    		);

    public final Table realPartyInInterestCounsel = $("#real_party_in_interest_container", (Configure<Table>) table ->
    {
    	table.viewAllLink(By.xpath("//div[@id='#real_party_in_interest_container']//a[text()='View All']"));
    	table.viewLessLink(By.xpath("//div[@id='#real_party_in_interest_container']//a[text()='View Less']"));
    	table.uniqueId("ul li>a[href]:not(.counsel)");
    	table.column("ent_name", "ul li>a[href]:not(.counsel)  ");
    	table.column("counsel_details", "ul li>div:last-child");
    }
    		);

    public final Table privyCounselParties = $("#privy_container", (Configure<Table>) table ->
    {
    	table.viewAllLink(By.xpath("//div[@id='#privy_container']//a[text()='View All']"));
    	table.viewLessLink(By.xpath("//div[@id='#privy_container']//a[text()='View Less']"));
    	table.uniqueId("ul li>a[href]:not(.counsel)");
    	table.column("ent_name", "ul li>a[href]:not(.counsel)");
    	table.column("counsel_details", "div.counsel-content");
    }
    		);

    public final Tabs relatedPetitionTabs = new Tabs(".tabs.related_petitions_tab");

    public void switchToTabInRelatedPetitions(String tabName) {
    	if(!petitionsaActiveTab.getText().contains(tabName.toUpperCase())) {
    		String tabElement=String.format("#related-case-type  dd:contains('%s')", tabName);
            $(tabElement).click();
            petitionsaActiveTab.waitUntilTextContains(tabName.toUpperCase());
    	}
    }

    public final Table patentTab_table = $("div#related_petitions_patents >div:nth-of-type(1) table", (Configure<Table>) table ->
        {

        }
    );

    public final Element patents_expand_Link=$("div#related_petitions_patents >div:nth-of-type(1) div.handle");
    public final Element patent_Link_In_PatentTab=$("div#related_petitions_patents >div:nth-of-type(1) div.handle>a");

    public final Element petitionersTabLink = $("a[href='#related_petitions_petitioners']");
    public final Element patentsTabLink = $("a[href='#related_petitions_patents']");
    public final Table partiesNPatentTable = $("div[id^=related_petitions_].active", (Configure<Table>) table ->
        {
            table.row("div.group.nested");
            table.uniqueId("div.handle>a");
            table.column("name", "div.handle>a");
            table.column("count", "div.handle li.result-count");
            table.subTable($("table.table_section", (Configure<Table>) subTable ->
                {
                    subTable.uniqueId("td:nth-child(2) a[href]");
                }));
        }
    );

    //DOCKET SECTION
    public final Element docket_entries = $("#ptab_documents", (Configure<ListPanel>) list ->
        {
            list.dataKey("tbody tr");
        }
    );

    public final Element docket_entries_Count=$("#docket_entries_sections+div.content .section-subtitle"); //"#ptab_documents_wrapper h2"
    public final Table docket_table = $("#ptab_documents", (Configure<Table>) table ->
        {
            table.uniqueId("td:nth-child(1)");
            table.column("filing_date","td:nth-child(1)");
            table.column("doc_data","td:nth-child(2)");
            table.viewAllLink(By.xpath("//table[@id='ptab_documents']/following-sibling::span/a[text()='View All']"));
            table.viewLessLink(By.xpath("//table[@id='ptab_documents']/following-sibling::span/a[text()='View Less']"));
            table.displayedRecords("#ptab_documents tbody tr:not([style='display: none;'])");
        }
    );



    public final Table docket_table_func = $("#ptab_documents", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(1)");
                table.viewAllLink(By.xpath("//table[@id='ptab_documents']/following-sibling::span/a[text()='View All']"));
                table.viewLessLink(By.xpath("//table[@id='ptab_documents']/following-sibling::span/a[text()='View Less']"));
                table.displayedRecords("#ptab_documents tbody tr:not([style='display: none;'])");
            }
    );

    public final Element documentNameColumn = $("#ptab_documents td.sorting_2>div.grouped_dockets>div:nth-child(3) a");

    public final Element exibhit_doc_link=$("#ptab_documents tr:has(td:nth-of-type(5):contains(Exhibit)) a");
    public final Element docket_Search_Input=$("#ptab_documents_filter input");

    public final Element campaignPanel = $(".ptab_lit_campaigns.panel");

    public void selectPetitionersTabLink() {
        if (petitionersTabLink.isDisplayed()) {
            petitionersTabLink.click();
            waitForPageLoad();
        }
    }

    public void selectPatentsTabLink() {
        if (patentsTabLink.isDisplayed()) {
            patentsTabLink.click();
            waitForPageLoad();
        }
    }

    public final Table Litigation_Campaigns = $("table.litigations_table", (Configure<Table>) table ->
        {
            table.uniqueId("td:nth-child(1) a[href]");
        }
    );

    public final Table Litigation_Cases = $("table.litigations_table", (Configure<Table>) table ->
        {
            table.uniqueId("td:nth-child(2) a[href]");
            table.viewAllLink(By.xpath("//*[@id='lit_container']//a[text()='View All']"));
            table.viewLessLink(By.xpath("//*[@id='lit_container']//a[text()='View Less']"));
            table.displayedRecords("table.litigations_table tbody tr:not([style*='none'])");
        }
    );

    public final Element all_cases = $(By.id("all-case-type"));
    public final Element active_cases = $(By.id("active-case-type"));
    public final Element inactive_cases = $(By.id("inactive-case-type"));


    public final Element campaignView = $("div.ptab_lit_campaigns .switch.small.apply_filter.active label[for='lit_view']");
    public final Element caseView = $("div.ptab_lit_campaigns .switch.small.apply_filter:not(.active) label[for='lit_view']");
    public void switchToNonCampaignView() {
        if (campaignView.isDisplayed()) {
            campaignView.click();
            waitForPageLoad();
            caseView.waitUntilVisible();
        }
    }

    public void filterAllCases() {
        if (all_cases.isDisplayed()) {
            all_cases.click();
            waitForPageLoad();
        }
    }

    public void filterActiveCases() {
        if (active_cases.isDisplayed()) {
            active_cases.click();
            waitForPageLoad();
        }
    }

    public void filterInActiveCases() {
        if (inactive_cases.isDisplayed()) {
            inactive_cases.click();
            waitForPageLoad();
        }
    }

    public final Element defendant_parent = $("#litigation-cases a[data-behavior = 'async_modal prevent_click_propagation']");

    // PETITIONER PANEL
    public final Element petitioner_panel = $("#petitioner_container ul li>a[href]:not(.counsel)");
    public final Element petitionerNpeTag = $("#petitioner_container span.npe_tag");

    // REAL PARTY IN INTEREST PANEL
    public final ListPanel realPartyInInterest = $("#real_party_in_interest_container ul", (Configure<ListPanel>) list -> {
                list.viewAllLink(By
                        .xpath("//*[@id='real_party_in_interest_container']//a[text()='View All']"));
                list.viewLessLink(By
                        .xpath("//*[@id='real_party_in_interest_container']//a[text()='View Less']"));
                list.link("#real_party_in_interest_container ul:not([style*='none']) li a");
            }
    );

    public final ListPanel petitionerRPI = $("#petitioner_rpi_container ul", (Configure<ListPanel>) list -> {
                list.viewAllLink(By
                        .xpath("//*[@id='petitioner_rpi_container']//a[text()='View All']"));
                list.viewLessLink(By
                        .xpath("//*[@id='petitioner_rpi_container']//a[text()='View Less']"));
                list.link("#petitioner_rpi_container ul:not([style*='none']) li a");
            }
    );


    public final ListPanel patentOwnerRPI = $("#patent_owner_rpi_container ul", (Configure<ListPanel>) list -> {
                list.viewAllLink(By
                        .xpath("//*[@id='patent_owner_rpi_container']//a[text()='View All']"));
                list.viewLessLink(By
                        .xpath("//*[@id='patent_owner_rpi_container']//a[text()='View Less']"));
                list.link("#patent_owner_rpi_container ul:not([style*='none']) li a");
            }
    );

    public final ListPanel realPartyInInterests = $("#real_party_in_interest_container", (Configure<ListPanel>) list -> {
                list.viewAllLink(By
                        .xpath("//*[@id='real_party_in_interest_container']//a[text()='View All']"));
                list.viewLessLink(By
                        .xpath("//*[@id='real_party_in_interest_container']//a[text()='View Less']"));
                list.dataKey("ul:not([style*='none']) li a");
            }
    );

    // PRIVY PANEL
    public final ListPanel privy = $("#privy_container ul", (Configure<ListPanel>) list ->
		{
            list.viewAllLink(By
					.xpath("//*[@id='privy_container']//a[text()='View All']"));
            list.viewLessLink(By
					.xpath("//*[@id='privy_container']//a[text()='View Less']"));
            list.link("#privy_container ul:not([style*='none']) li a");
		}
	);

	public final Element real_party_title=$("#real_party_in_interest_container ul>li>a[href*='/entity/']");
    public final Element petitioner_real_party_title=$("#petitioner_rpi_container ul>li>a[href*='/entity/']");
    public final Element patent_owner_real_party_title=$("#patent_owner_rpi_container ul>li>a[href*='/entity/']");
    public final Element privy_title=$("#privy_container #privy .right-heading-text");



    // PATENT OWNER PANEL
    public final Element patent_owner = new ListPanel("#patent_owner_container ul li>a[href]:not(.counsel)");
    public final Element patentOwnerNpeTag = $("#patent_owner_container span.npe_tag");
    public final Element patentOwner_Title=$("#patent_owner_container #patent_owner");
    public final Element likelyPatentOwner_tooltip=$("#patent_owner_container i");
    public final Element likelyPatentOwner_tooltip_Text=$("span.tooltip[style*='visibility: visible;']");
    public final ListPanel patent_owner_Panel=$("#patent_owner_container ul", (Configure<ListPanel>) list ->
        {
            list.viewAllLink(By.xpath("//*[@id='patent_owner_container']//a[text()='View All']"));
            list.viewLessLink(By.xpath("//*[@id='patent_owner_container']//a[text()='View Less']"));
            list.displayedRecords("#patent_owner_container ul:not([style*='none']) li");
            list.link("#patent_owner_container ul:not([style*='none']) li a");
        }
    );

    public final ListPanel petitioner_Panel=$("#petitioner_container ul", (Configure<ListPanel>) list ->
        {
            list.viewAllLink(By.xpath("//*[@id='petitioner_container']//a[text()='View All']"));
            list.viewLessLink(By.xpath("//*[@id='petitioner_container']//a[text()='View Less']"));
            list.displayedRecords("#petitioner_container ul:not([style*='none']) li");
            list.link("#petitioner_container ul:not([style*='none']) li a");
        }
    );

    //RELATED CAMPAIGN
    public final Element campaign_viewAsResults=$("#ptab_lit_campaigns a:contains('View as Search Results'):visible");
    //public final Element non_campaign_viewAsResults=$("#ptab_lit_campaigns a:contains('View as Search Results'):visible");

    public final Element caseType = $("div#ptab_lit_campaigns .choose-box select#cases_type");
    public void applyFilterForRelatedCampaign(String filterOption) {
        caseType.waitUntilVisible();
        caseType.selectByOption(filterOption);
        loading.waitUntilInvisible();
    }

//    public void applyFilterForRelatedCampaign(String id) {
//    	Element filter=$(By.id(id));
//    	if(!filter.isSelected()) {
//    		filter.click();
//    		loading.waitUntilInvisible();
//    		overlay_Loading.waitUntilNoElementPresent();
//    	}
//    }

    //Role Authorization for Alerts
    public final Element ptab_Events=$("input#PTAB_Events:not([class*='greyed-out'])");
    public final Element rpx_Reports_Events=$("input#RPX_Reports:not([class*='greyed-out'])");
    public final Element prior_art_Report_Event=$("input#alert_event__400:not([class*='greyed-out'])");
    public final Element event_Promotional_Msg=$(".events_promotional_msg a[href='/payments/options']");

    public  final Element related_patent_owner_btn = $("input#patent-owners");
    public  final Element related_camp_patent_family_btn = $("input#patent-family-members");

    public void select_related_petition_filter(String filter_name)
    {
        switch (filter_name)
        {
            case "patent_owner" :
                related_patent_owner_btn.select();
                break;
            case "camp_pat_family":
                related_camp_patent_family_btn.select();
                break;
        }
        waitForLoading();
    }


    
}
