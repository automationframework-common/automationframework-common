package com.rpxcorp.insight.page.search;

import com.rpxcorp.insight.module.FacetFilter;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.detail.BaseDetailPage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EntitySearchPage extends BaseDetailPage {

    public EntitySearchPage() {
        this.url = new PageUrl("advanced_search/search_entities");
        this.url.param("CURRENT SEARCH", "searchq");
        this.url.param("HEADER TYPE","header_search_type");
        this.url.param("MARKET SECTOR", "ent_market_sector_id[]");
        this.url.param("ENTITY TYPE", "ent_type_id[]");
        this.url.param("GROUPED", "grouped");
    }

    @Override
    public boolean at() {
        waitForPageLoad();
        return currentSearch.waitUntilVisible();
    }
    public final Element currentSearch = $(".refine_search textarea#searchq_revised");
    public final FacetFilter marketSector = $("Market Sector", FacetFilter.class);
    public final FacetFilter entityType = $("Entity Type", FacetFilter.class);

    public final Element npeFilter =$(".filters:has(>.title:contains('Entity Type')) li:contains('NPE'):not(.disabled-filter)");
    public final Element npeFilterDisabled =$(".filters:has(>.title:contains('Entity Type')) li:contains('NPE').disabled-filter a");
    public void clickNPEFilter(){
        entityType.showMore();
        if(npeFilterDisabled.isDisplayed()) {
            npeFilterDisabled.click();
            tooltip.waitUntilVisible();
        }
    }


    /* CONTENT OF ENTITY SEARCH PAGE * */
    public final Element goToAdvSearchLink_At_EntSearch=$("#affixed-table-header a.advanced_search_link[href*='/advanced_search?tab=entity']");
    public final Element npeTagAccordianHeader = $("div.handle span.npe_tag");
    public final Element login_share_link_btn = $("a[title='Login Share Link']");

    public final Element search_icon = $(".search i.icon-search");
    public final Element enity_results_count = $("#search_results_replaced_content .metrics_card div.content:contains('Entity Results') .count");
    public final Element ultimate_parent_count = $("h2.result-title>span.count:nth-child(2)");
    public final Element entityNameWithoutHyperLink = $(".plain-inner-title");
    public final Element entityNameWithHyperLink = $(".ent-title");
    public final Element tableGroupItem = $(".group-item");
    // Related Entity Text -Authorization
    public final Element relatedEntityCount = $("table.group_stats div:contains('Related Entities')>span.count_search_result_count");
    public final Table parentview_table = $(".search-results table.results", (Configure<Table>) table ->
        {
            table.column("ultimate_parent_name", "tr a.title");
            table.column("Related Entities", ".group_stats td:nth-child(2)");
            table.column("Plaintiff", ".group_stats td:nth-child(3)");
            table.column("Defendant", ".group_stats td:nth-child(4)");
            table.column("patent_asserted", ".group_stats td:nth-child(5)");
            table.column("search_result", ".result-count");
        }
    );

    public final Table parentview_entitySubTable = $(".search-results table.results div[id^='entity_display_group']" , Table.class);
    public final Element parentview_NPETagCount =  $(".search-results table.results span.npe_tag");


    public final Table parentview_table_forFacet = $(".search-results table.results", (Configure<Table>) table ->
        {
            table.column("ultimate_parent_name", "tr a.title");
            table.column("Related Entities", ".group_stats td:nth-child(2)");
            table.column("Plaintiff", ".group_stats td:nth-child(3)");
            table.column("Defendant", ".group_stats td:nth-child(4)");
            table.column("patent_asserted", ".group_stats td:nth-child(5)");
            table.uniqueId("div.handle a");
        }
    );

    public List<String> getUniqueIDs_nonGrouped() {
        return search_result_forFacet.getUniqueId_Values();
    }

    public List<String> getUniqueIDs_grouped() {
        return parentview_table_forFacet.getUniqueId_Values();
    }

    public final Table search_result = new Table(".search-results table.results");
    public final Table search_result_forFacet = $(".search-results table.results", (Configure<Table>) table ->
        {
            table.uniqueId(" a[href] ");
        }
    );
    public final Element parent_View_Switch = new Element("div.table-options li:nth-of-type(1) a.apply_filter");
    public final Element parent_View_Icon = new Element("div.table-options i.icon-users");

    public void switch_nonParent_View() {
        if (!parent_View_Icon.isDisplayed()) {
            parent_View_Switch.click();
            waitForPageLoad();
        }
    }

    public void enter_searchtext(String text) {
        search_textarea.clear();
        search_textarea.sendKeys(text);
        search_icon.click();
        waitForPageLoad();
    }

    public Map<String, Object> getAppliedFilters(){
        Map<String, Object> data = new HashMap<>();
        addIfNotEmpty(data,"current_search",currentSearch.getValue());
        addIfNotEmpty(data,"market_sector",marketSector.getSelectedFilter());
        addIfNotEmpty(data,"entity_type",entityType.getSelectedFilter());
        return data;
    }
    public final Element entGroupedViewSearchResults= $(".results .group a.ent-title");
}
