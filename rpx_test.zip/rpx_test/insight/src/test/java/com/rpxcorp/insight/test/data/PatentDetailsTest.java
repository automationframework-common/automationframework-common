package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.detail.PatentDetailPage;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.TableData;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.sql.ResultSet;
import java.util.Map;
@Authenticate(role = "MEMBER")
public class PatentDetailsTest extends BaseDataTest {
    PatentDetailPage patentDetailPage;
    String normalizedId;
    TableData tableData;
    Map<String, String> staticData;
    ResultSet resultSet;

    /* TEST CONFIGURATIONS */
    @Factory(dataProvider = "returnData")
    public PatentDetailsTest(String dataDescription, String patentId) {
        this.dataDescription = dataDescription;
        this.dataId = patentId;
        // Manipulating patent id to suite data id
        if(patentId.length() == 11)
        patentId = patentId.substring(2, patentId.length() - 2);
        else if(patentId.length() == 10)
        patentId = patentId.substring(2, patentId.length() - 1);
        else if(patentId.length() == 15)
            patentId = patentId.substring(2, patentId.length() - 2);
        else if(patentId.contains("RE") & !patentId.contains("RE"))
            patentId = "RE" + patentId;
        this.normalizedId = patentId;
    }

    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("PatentDetail");
    }

    
    @BeforeClass
    public void loadPage() {
        this.urlData.put("ID", dataId);
        this.dataUrl = patentDetailPage.getDeclaredUrl(urlData);
        to(patentDetailPage, urlData);        
    }

    /* TEST CASES */
    @Test(description = "Verify patent header details")
    public void Patent_Header_Details() throws Exception {
        staticData = patentDetailPage.header_info.getData();
        staticData.put("title", (String) patentDetailPage.detailPageTitle.getData());
        assertEquals(staticData, sqlProcessor.getResultData("PatentDetail.PAT_DETAILS", dataId), "title");
    }
    
    @Test(description = "Verify LCA button is displayed only for litigated patents")
    public void lcaButtonPresence() throws Exception{    	
    	assertEquals(patentDetailPage.lcaButton.isDisplayed(), sqlProcessor.getBoolean("PatentDetail.LCA_DATA_BUTTON_PRESENCE",dataId), "LCA button");
    }
    
    @Test(description = "Verify Data button is displayed only for litigated patents")
    public void dataButtonPresence() throws Exception{    	
    	assertEquals(patentDetailPage.dataButton.isDisplayed(), sqlProcessor.getBoolean("PatentDetail.LCA_DATA_BUTTON_PRESENCE",dataId), "Data button");
    }

    @Test(description = "Verify download patent link", priority = 1)
    public void downloadPatentLink() throws Exception {
    	assertEquals(patentDetailPage.getPatentLink(), sqlProcessor.getSinglResultValue("PatentDetail.DOWNLOAD_PATENT_LINK", dataId));
    }
    
    @Test(description = "Verify Overview Associated Cases Count", priority = 1)
    public void Overview_Associated_Litigation_Count() throws Exception {
        staticData = patentDetailPage.overview_panel.getData();
        assertEquals(staticData.get("associated_case"),
                sqlProcessor.getResultData("PatentDetail.CNT_ASSOCIATED_LITIGATION", normalizedId), "count");
    }  
    
    @Test(description = "Verify Overview Associated Defendant Count", priority = 2)
    public void Overview_Associated_Defendant_Count() throws Exception {
        assertEquals(staticData.get("associated_defendants"),
                sqlProcessor.getResultData("PatentDetail.CNT_ASSOCIATED_DEFEDANTS", normalizedId), "count");
    }

    @Test(description = "Verify Overview Accused Product Count", priority = 2)
    public void Overview_Accused_Product_Count() throws Exception {
        assertEquals(staticData.get("accused_products"),
                sqlProcessor.getResultData("PatentDetail.CNT_UNIQUE_ACCUSED_PRODS", dataId), "count");
    }

    @Test(description = "Verify Overview Forward Citation Count", priority = 2)
    public void Overview_Forward_Citation_Count() throws Exception {
        assertEquals(staticData.get("forward_citations"),
                sqlProcessor.getResultCount("PatentDetail.PAT_FORWD_CITATIONS_PATS", dataId));
    }

    @Test(description = "Verify petitions count in metrics section", priority = 2)
    public void overviewPetitionsCount() throws Exception {
    	assertEquals(staticData.get("petitions"),
    			sqlProcessor.getResultCount("PatentDetail.PETITIONS", dataId));  	
    }
    
    @Test(description = "Verify assignments count in metrics section", priority = 2)
    public void overviewAssignmentsCount() throws Exception {    	
    	assertEquals(staticData.get("assignments"),
    			sqlProcessor.getResultCount("PatentDetail.ASSIGNMENT_DETAILS", normalizedId));  	
    }
    
    @Test(description = "Verify Accused Product Count in accused product section")
    public void Accused_Product_Count() throws Exception {
        assertEquals(String.valueOf(patentDetailPage.accusedProductTitle.getIntData()),
                sqlProcessor.getResultData("PatentDetail.CNT_UNIQUE_ACCUSED_PRODS", dataId), "count");
    }

    @Test(description = "Verify Claim Count", priority = 19)
    public void Claim_Count() throws Exception {
        assertEquals(patentDetailPage.claimTitle.getData(),
                sqlProcessor.getResultData("PatentDetail.CNT_ALL_CLAIMS", dataId), "count");
    }

    @Test(description = "RPX-14918 || Verify All Litigations in Campaign View", priority = 1)
    public void All_Litigations_in_campaign_view() throws Exception {
        assertEquals(patentDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("PatentDetail.ALL_LITIGATION_CAMPAIGN", normalizedId), "campaign_name",
                "start_date", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Active Litigations in Campaign View", priority = 2)
    public void Active_Litigations_in_campaign_view() throws Exception {
        patentDetailPage.filterActiveCases();
        assertEquals(patentDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("PatentDetail.ACTIVE_LITIGATION_CAMPAIGN", normalizedId), "campaign_name",
                "start_date", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify InActive Litigations in Campaign View", priority = 3)
    public void InActive_Litigations_in_campaign_view() throws Exception {
        patentDetailPage.filterInActiveCases();
        assertEquals(patentDetailPage.litigation_table.getData(),
                sqlProcessor.getResultData("PatentDetail.INACTIVE_LITIGATION_CAMPAIGN", normalizedId), "campaign_name",
                "start_date", "termination_date", "jurisdiction");
    }

    @Test(description = "Verify Defendants in non campaign view", priority = 4)
    public void Defendants_in_non_campaign_view() throws Exception {
        patentDetailPage.changeCampaignView();
        patentDetailPage.selectDefendantTab();
        assertEquals(patentDetailPage.defendant_non_camp_table.getData(),
                sqlProcessor.getResultData("PatentDetail.NCV_DEFENDANT_TABLE", normalizedId));
    }

    @Test(description = "Verify Defendants Sub Table in non campaign view", priority = 5)
    public void Defendants_SubTable_in_non_campaign_view() throws Exception {
    	patentDetailPage.waitForLoading();
    	patentDetailPage.expandAlldefandant();
    	assertEquals(patentDetailPage.defendant_non_camp_table.getSubtableData(),
    			sqlProcessor.getResultData("PatentDetail.DEFENDANT_SUB_TABLE", normalizedId));
    }

    @Test(description = "Verify All Litigations in non campaign view", priority = 6)
    public void All_Litigations_in_non_campaign_view() throws Exception {
        assertEquals(patentDetailPage.litigation_non_camp_table.getData(),
                sqlProcessor.getResultData("PatentDetail.ALL_LITIGATION_NON_CAMP", normalizedId));
    }

    @Test(description = "Verify Active Litigations in non campaign view", priority = 7)
    public void Active_Litigations_in_non_campaign_view() throws Exception {
        patentDetailPage.filterActiveCases();
        assertEquals(patentDetailPage.litigation_non_camp_table.getData(),
                sqlProcessor.getResultData("PatentDetail.ACTIVE_LITIGATION_NON_CAMP", normalizedId));
    }

    @Test(description = "Verify InActive Litigations in non campaign view", priority = 8)
    public void InActive_Litigations_in_non_campaign_view() throws Exception {
        patentDetailPage.filterInActiveCases();
        assertEquals(patentDetailPage.litigation_non_camp_table.getData(),
                sqlProcessor.getResultData("PatentDetail.INACTIVE_LITIGATION_NON_CAMP", normalizedId));
    }

    @Test(description = "Verify 'Defendants' column in Accused Product", priority = 9)
    public void AccusedProduct_Defendants() throws Exception {
        tableData = patentDetailPage.accused_products_table.getData();
        resultSet = sqlProcessor.getResultData("PatentDetail.ACCUSED_PRODUCT_DETAILS", dataId);
        assertEquals(tableData, resultSet, "defendants");
    }

    @Test(description = "Verify 'Accused Products' column in Accused Product", priority = 10)
    public void AccusedProduct_accused_products() throws Exception {
        assertEquals(tableData, resultSet, "accused_products");
    }

    @Test(description = "Verify 'Litigation' column in Accused Product", priority = 11)
    public void AccusedProduct_case_number() throws Exception {
        assertEquals(tableData, resultSet, "litigation");
    }

    @Test(description = "Verify Assignments Count", priority = 12)
    public void Assignments_Count() throws Exception {
        resultSet = sqlProcessor.getResultData("PatentDetail.ASSIGNMENT_DETAILS", normalizedId);
        assertEquals(patentDetailPage.assignmentTitle.getText(), sqlProcessor.getResultCount(resultSet));
    }
    
    @Test(description = "RPX-13758 || Verify Assignments", priority = 20)
    public void assignmentTabInfo() throws Exception {
    	patentDetailPage.selectAssignmentViewTab();   	
    	assertEquals(patentDetailPage.assignmentInfo.getData(), 
        		sqlProcessor.getResultData("PatentDetail.ASSIGNMENT_DETAILS", normalizedId));   	
    }

    @Test(description = "Verify assets for each assignment", priority = 21)
    public void assetSetForEachAssignment() throws Exception {
    	patentDetailPage.selectAssignmentViewTab();
    	patentDetailPage.openAssetsList();
    	assertEquals(patentDetailPage.assetInfo.getData(),
        		sqlProcessor.getResultData("PatentDetail.ASSET_INFO", normalizedId));
    }
    
    @Test(description = "Verify reel/frame pdf link", priority = 22)
    public void verifyReelFramePdfLink() throws Exception {  
    	patentDetailPage.assignments.viewAll();
    	String param = patentDetailPage.getReelFrameValue();    	
    	assertEquals(patentDetailPage.getHrefFromreelFramePdf(), 
    			sqlProcessor.getSinglResultValue("PatentDetail.REEL_FRAME_PDF_LINK", param));    	
    }
    
    //@Test(description = "Verify total assets displayed in Reel/Frame modal", priority = 20)
    public void verifyTotalAssetsInReelFrame() throws Exception{
       	patentDetailPage.openReelFrame();    	
    	resultSet = sqlProcessor.getResultData("PatentDetail.REEL_FRAME_DETAILS",dataId);       	
    	assertEquals(patentDetailPage.totalAssetsCount.getIntData(), sqlProcessor.getResultCount(resultSet));	    	
    	assertEquals(patentDetailPage.reelFrameTable.getData(), resultSet);
    	patentDetailPage.closeReelFrame();
    }

    @Test(description = "Verify CurrentAssignee")
    public void Current_Asssignee() throws Exception {    	
        assertEquals(patentDetailPage.currentAssignee.getAllData(),
                sqlProcessor.getResultData("PatentDetail.CURR_ASSIGNEE", normalizedId));
    }

    @Test(description = "Verify SponsoringEntity")
    public void Sponsoring_Entity() throws Exception {
        assertEquals(patentDetailPage.sponsoringEntity.getAllData(),
                sqlProcessor.getResultData("PatentDetail.SPONSORING_ENTITY", normalizedId));
    }

    @Test(description = "Verify Inventors")
    public void KeyInventors() throws Exception {
        assertEquals(patentDetailPage.inventors.getAllData(),
                sqlProcessor.getResultData("PatentDetail.INVENTORS", normalizedId));
    }

    @Test(description = "Verify PrimaryExaminers")
    public void Primary_Examiners() throws Exception {
        assertEquals(patentDetailPage.primaryExaminers.getAllData(),
                sqlProcessor.getResultData("PatentDetail.PRIMARY_EXAMINER", normalizedId));
    }

    @Test(description = "Verify FamilyMembers Count", priority = 13)
    public void Family_Members_Count() throws Exception {
        resultSet = sqlProcessor.getResultData("PatentDetail.FAMILY_MEMBERS", normalizedId);
        assertEquals(patentDetailPage.familyMembers_title.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    @Test(description = "Verify FamilyMembers", priority = 14)
    public void Family_Members() throws Exception {
        assertEquals(patentDetailPage.familyMembers.getData(), resultSet);
    }

    @Test(description = "Verify Forward Citation", priority = 15)
    public void ForwardCitation() throws Exception {
        assertEquals(patentDetailPage.citiations_table.getData(),
                sqlProcessor.getResultData("PatentDetail.FORWARD_CTITATION", dataId));
    }

    @Test(description = "RPX-14573 || Verify Reference Cited", priority = 16)
    public void ReferenceCited() throws Exception {
        patentDetailPage.selectReference_cited_Tab();
        assertEquals(patentDetailPage.citiations_table.getData(),
                sqlProcessor.getResultData("PatentDetail.REFERENCE_CTITED", dataId));
    }

    @Test(description = "Verify 'Date Filed' column in Petitions", priority = 17)
    public void Petitions_DateFiled() throws Exception {
        assertEquals(patentDetailPage.petition_table.getData(),
                sqlProcessor.getResultData("PatentDetail.PETITIONS", dataId), "date_filed");
    }

    @Test(description = "Verify 'Case Name' column in Petitions", priority = 18)
    public void Petitions_CaseName() throws Exception {
        assertEquals(patentDetailPage.petition_table.getData(),
                sqlProcessor.getResultData("PatentDetail.PETITIONS", dataId), "case_name");
    }

    @Test(description = "Verify 'Case Number' column in Petitions", priority = 18)
    public void Petitions_CaseNumber() throws Exception {
        assertEquals(patentDetailPage.petition_table.getData(),
                sqlProcessor.getResultData("PatentDetail.PETITIONS", dataId), "case_number");
    }

    @Test(description = "Verify 'Status' column in Petitions", priority = 18)
    public void Petitions_Status() throws Exception {
        assertEquals(patentDetailPage.petition_table.getData(),
                sqlProcessor.getResultData("PatentDetail.PETITIONS", dataId), "status");
    }

    @Test(description = "Verify Claims data", priority = 19)
    public void Claims_Data() throws Exception {
    	patentDetailPage.expandAllclaims();
    	assertEquals(patentDetailPage.claimData.getData(), 
    			sqlProcessor.getResultData("PatentDetail.CLAIMS_DATA", dataId), "claims");   
    }   
    
    @Test(description = "Verify patent or applcation is displayed", priority = 19)
    public void patentOrApplication() throws Exception {  
    	assertEquals(patentDetailPage.patentCodesInformation.getData(), 
    			sqlProcessor.getResultData("PatentDetail.APPLICATION_OR_PATENT", dataId));    	
    }
    
    @Test(description = "Verify CAFC tag is displayed near the patent title")
    public void verifyCAFCTag() throws Exception {
    	assertEquals(patentDetailPage.getCAFCCallout(),
    			sqlProcessor.getSinglResultValue("PatentDetail.CAFC_TAG", dataId));
    }
}
