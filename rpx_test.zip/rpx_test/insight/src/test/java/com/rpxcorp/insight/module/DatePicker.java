package com.rpxcorp.insight.module;

import com.rpxcorp.testcore.element.Element;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DatePicker extends Element {

    public final Element datePicker = new Element("table.table-condensed:visible");
    public final Element datePickerMonth = new Element(".monthselect:visible");
    public final Element datePickerYear = new Element(".yearselect:visible");
    public final Element datePickerApplyBtn = new Element (".daterangepicker button.applyBtn:visible");

    public DatePicker(By locator) {
        super(locator);
    }

    public DatePicker(String selector) {
        super(selector);
    }
    public void selectDate(Object dateInput) throws Exception {
        selectDate((String) dateInput);
    }
    public void selectDate(String dateInput) throws Exception {
        if(dateInput !=null && !dateInput.isEmpty()) {
            DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
            Date date = dateFormat.parse(dateInput);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);

            click();
            datePicker.waitUntilVisible();

            Select year = new Select(datePickerYear);
            year.selectByVisibleText(Integer.toString(calendar.get(Calendar.YEAR)));

            Select month = new Select(datePickerMonth);
            month.selectByIndex(calendar.get(Calendar.MONTH));
//            new Element(
//                    By.xpath("//*[@class='table-condensed']//tbody//td[text()='" + calendar.get(Calendar.DAY_OF_MONTH) + "']"))
//                    .click();
            new Element(By.xpath("//div[contains(@class,'show-calendar') and contains(@style,'display: block')]//td[text()='" + calendar.get(Calendar.DAY_OF_MONTH) + "' and not(contains(@class,'off ends available'))]")).click();
            //datePicker.waitUntilInvisible();
//            datePickerApplyBtn.click();
        }
    }
}
