package com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.intelligence.MarketPlacePage;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.FileUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.File;
@Authenticate(role = "MEMBER")
public class AcquisitionOpportunitiesTest extends BaseFuncTest {

    MarketPlacePage marketAcquisitionPage;

    @BeforeClass
    public void loadPage() throws Exception {
        to(marketAcquisitionPage);
    }

    @Test(priority=1,groups="P2", description="Verify Acquisition download |RPX-12414")
    public void checkAcquisitionDownload() throws Exception {
    	// Delete file if any under tempDownloadPath
    	FileUtil.deleteFilesFromDirectory(new File(ConfigUtil.config().get("testOutputDir").toString()));
    	marketAcquisitionPage.download_Btn.click();
		FileUtil.waitUntilFileDownload(ConfigUtil.config().get("testOutputDir").toString(), 180000);
		File[] filesInDir = FileUtil.listAllFilesFromADirectory(ConfigUtil.config().get("testOutputDir").toString());
		System.out.println(filesInDir[0].getPath());
		Assert.assertTrue(filesInDir[0].getPath().contains("marketplace.xlsx"),
				"Acquisition xlsx document is not downloaded in Marketplace Page");

    }

}