package com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.DocketEntryPage;
import com.rpxcorp.insight.page.detail.*;
import com.rpxcorp.oldtest.page.DBData;
import com.rpxcorp.testcore.Authenticate;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.ArrayList;
import java.util.List;

@Authenticate(role = "MEMBER")
@Test(groups = "Venue")
public class ChineseVenuesTest extends BaseFuncTest {
    private ChineseVenueDetailPage chineseVenuePage;
    LitigationDetailPage litDetailsPage;
    EntityDetailPage entDetailsPage;
    PatentDetailPage patDetailsPage;
    JudgeDetailPage judgePage;
    DocketEntryPage docketPage;
    SoftAssert softAssert;
    String dataId, dataUrl;
    DBData db = null;
    String id = null;

    @BeforeClass
    public void navigateChineseVenuePage() throws Exception {
        db = new DBData();
    }

    @BeforeGroups(groups = "CHINESELITIGATION")
    public void venueLitigation() {
        to(chineseVenuePage, "1595291");
    }


    @Test(priority = 100, description = "RPX-14076: Chinese Judge Details Page - Part 2 - Stats", groups = {"P2", "CHINESELITIGATION"})
    public void verifySectionInVenuesPage() throws Exception {
        String title[] = {"Venue Profile","Litigations"};//"Judge Profile","Cases by Market Sector"
        chineseVenuePage.sectionTitle.waitUntilVisible();
        assertTrue(chineseVenuePage.metricsSection.isPresent(), "Metrics section is not present in the China Venues details page");
        ArrayList<String> sectionHeader = chineseVenuePage.sectionTitle.getAllData();
        assertTrue(sectionHeader.get(0).contains(title[0]),
                "Title of 'Profile section' didn't match, Actual: " + sectionHeader.get(0) + "Expected: " + title[0]);
        assertTrue(sectionHeader.get(1).contains(title[1]),
                "Title of 'Litigations section' didn't match, Actual: " + sectionHeader.get(1) + "Expected: " + title[1]);
        //assertTrue(chineseVenuePage.recentActivityHeader.getText().contains("Recent Activities"), "The Actual Recent Activities Title is: " + chineseVenuePage.recentActivityHeader.getText()+"But Expected to contain 'Recent Activities'");

    }

    @Test(priority = 101, description = "Verify Page Title is Equal with Venue Header", groups = {"P2", "CHINESELITIGATION"})
    public void verifyPageTitlewithVenueHeader() throws Exception{
        to(chineseVenuePage, db.getIDOfChineseVenue());
        Assert.assertTrue(chineseVenuePage.getPageTitle().contains(chineseVenuePage.pageTitle.getText()));
    }

    @Test(priority = 102, description = "Verify Metrics section count with Litigation Sections Count", groups = {"P2", "CHINESELITIGATION"})
    public void verifyMetricsSectionVsLitigationSectionCount(){
        to(chineseVenuePage, "1595291");
        chineseVenuePage.metricsSection.getElement("Inactive Cases").click();
        chineseVenuePage.overlay_Loading.waitUntilInvisible();
        chineseVenuePage.litigationCaseCount.waitUntilPresent();
        Assert.assertEquals(chineseVenuePage.metricsSection.getIntData("Inactive Cases"),Integer.parseInt(chineseVenuePage.litigationCaseCount.getText().replaceAll("[^0-9]","")));
    }

    @Test(priority = 103, description = "RPX-10073: The search keyword trim functionality is missing in Venues/Judges litigation search.", groups = {"P2", "CHINESELITIGATION"})
    public void verifyCaseNumberSearchFunctionality() throws Exception {
        to(chineseVenuePage, db.getIDOfChineseVenue());
        chineseVenuePage.litigation_Section.waitUntilVisible();
        String expectedRow = chineseVenuePage.litigation_Section.getRows()[1];
        String caseKey = chineseVenuePage.litigation_Section.getColumn(2).get(1);
        chineseVenuePage.searchInLitigationTable("    " + caseKey + "   ");
        chineseVenuePage.loading.waitUntilInvisible();
        Assert.assertEquals(chineseVenuePage.litigation_Section.getRows()[0], expectedRow,
                "Record of Search result didn't match");
    }

    @Test(priority = 104, description = "RPX-9946: Singular Plural Logic is missing in the Litigation section", groups = {"P3", "CHINESELITIGATION"})
    public void verifySingularPluralLogicInLitigationSection() throws Exception {
        to(chineseVenuePage, db.getIDOfChineseVenue());
        int litigationCount = 0;
        litigationCount = chineseVenuePage.LITIGATION_TABLE.getRows().length;
        if (litigationCount > 1) {
            Assert.assertTrue(chineseVenuePage.litigationCaseCount.getText().contains("Litigations"),
                    "Litigation text is shown");
        } else if (litigationCount == 1) {
            Assert.assertTrue(chineseVenuePage.litigationCaseCount.getText().contains("Litigation"),
                    "Litigations text is shown");
        }

    }

    @Test(priority = 105, description = "RPX-9972: Litigation Table default sort by Filed Date DESC", groups = {"P4", "CHINESELITIGATION","func_sorting"})
    public void checkLitigationDefaultSortForFiledDate() {
        chineseVenuePage.refresh();
        at(ChineseVenueDetailPage.class);
        assertColumnSort("date", "DESC", chineseVenuePage.LITIGATION_TABLE.getColumn("DATE FILED"));
    }

    @Test(priority = 106, groups = {"P2", "CHINESELITIGATION"}, dataProvider = "searchForCaseNameAndNumber", description = "RPX-10023:The case number search should be available in Judge and Venue Details Page's litigation section.")
    public void checkLitigationSearchForCaseNameAndNumber(String filter, String columnName,String searchInput) {
        to(chineseVenuePage,"1595292");
        chineseVenuePage.LITIGATION_TABLE.waitUntilVisible();
        chineseVenuePage.searchInLitigationTable(searchInput);
        chineseVenuePage.overlay_Loading.waitUntilInvisible();
        chineseVenuePage.LITIGATION_TABLE.waitUntilVisible();
        Assert.assertTrue(chineseVenuePage.LITIGATION_TABLE.getColumnLinkText(columnName).contains(searchInput), searchInput + " search is not working in Litigation Table");
    }

    @BeforeGroups(groups = "chineselitigation_sort")
    public void loadVenuesForSort() {
        to(chineseVenuePage, "1595368");
    }

    @Test(priority = 200, description = "Litigation Table Sort For All case Filter", groups = {"P4", "chineselitigation_sort","func_sorting"}, dataProvider = "litigationSectionTable")
    public void checkLitigationSort(String dataType, String sortType, String columnName)
            throws Exception {
        chineseVenuePage.LITIGATION_TABLE.sort(columnName);
        assertColumnSort(dataType, sortType, chineseVenuePage.LITIGATION_TABLE.getColumn(columnName));
    }

    @DataProvider(name = "searchForCaseNameAndNumber")
    public Object[][] searchDataForLitigation() {
        return new Object[][] {
                { "Inactive", "Case Name", "Jialiang Sun v. Xintai (Fujian) Technology Co., Ltd." },{ "Inactive", "Case Number", "CN-20-4073409" }
        };
    }

    @DataProvider(name = "litigationSectionTable")
    public Object[][] litigationSectionTable() {
        return new Object[][] { { "date", "ASC", "Date Filed" }, { "date", "DESC", "Date Filed" },
                { "string_only", "ASC", "Case Name" }, { "string_only", "DESC", "Case Name" },
                { "string", "ASC", "Case Number" }, { "string", "DESC", "Case Number" },
                { "date", "ASC", "Closed Date" }, { "date", "DESC", "Closed Date" }
        };
    }

    @BeforeGroups(groups = "venue_profile_statschart")
    public void profileStatsChart() {
        to(chineseVenuePage, "1595291");
    }


    @Test(priority = 300, groups = {"P2", "venue_profile_statschart"}, description = "RPX-14095 Chinese Venue Details Pages - Part 5 - Venue Profile")
    public void verifyOrderTabLegendText() throws Exception {

        List<String> legendList = chineseVenuePage.getLegendText();
        Assert.assertEquals(legendList.get(0), "Plaintiff Win", "Legend Text didn't match");
        Assert.assertEquals(legendList.get(1), "Mixed Outcome", "Legend Text didn't match");
        Assert.assertEquals(legendList.get(2), "Defendant Win", "Legend Text didn't match");
        Assert.assertEquals(legendList.get(3), "Awarded", "Legend Text didn't match");
        Assert.assertEquals(legendList.get(4), "Requested But Denied", "Legend Text didn't match");
        Assert.assertEquals(legendList.get(5), "Not Requested", "Legend Text didn't match");

    }

    @Test(priority = 301, groups = {"P3", "venue_profile_statschart"}, description = "RPX-14095 Chinese Venue Details Pages - Part 5 - Venue Profile")
    public void verifyOrderTabAxisText() throws Exception {

        List<String> axisList = chineseVenuePage.getXAxisLabelText();
        Assert.assertTrue(axisList.get(0).equalsIgnoreCase("OUTCOME TYPE"), "X Axis Text didn't match");
        Assert.assertTrue(axisList.get(1).equalsIgnoreCase("INJUNCTIONS ON PLAINTIFF WIN"), "X Axis Text didn't match");
        Assert.assertTrue(axisList.get(2).equalsIgnoreCase("APOLOGIES ON PLAINTIFF WIN"), "X Axis Text didn't match");
    }

    @Test(priority = 5, groups = {"P2", "venue_profile_statschart"}, description = "RPX-9845:Verify Bar chart visibility functionality")
    public void verifyBarChartVisibility() throws Exception {

        chineseVenuePage.enableOutcomeTypeGraphs("DISABLE ALL");
        Assert.assertEquals(chineseVenuePage.PlaintiffWinChart.getElement().getAttribute("visibility"), "hidden",
                "Grant chart is not hidden");
        Assert.assertEquals(chineseVenuePage.MixedOutcomeChart.getElement().getAttribute("visibility"), "hidden",
                "denied chart is not hidden");
        Assert.assertEquals(chineseVenuePage.DefendantWinChart.getElement().getAttribute("visibility"), "hidden",
                "Partial chart is not hidden");
        Assert.assertTrue(chineseVenuePage.barChart_1.isDisplayed());
        chineseVenuePage.enableOutcomeTypeGraphs("ENABLE ALL");
        Assert.assertFalse(chineseVenuePage.barChart_1.isDisplayed());
//        Assert.assertTrue(chineseVenuePage.PlaintiffWinChart.getElements().size() > 0, "Grant chart is hidden");
//        Assert.assertTrue(chineseVenuePage.MixedOutcomeChart.getElements().size() > 0, "Denied chart is hidden");
//        Assert.assertTrue(chineseVenuePage.DefendantWinChart.getElements().size() > 0, "Partial chart is hidden");

    }

}