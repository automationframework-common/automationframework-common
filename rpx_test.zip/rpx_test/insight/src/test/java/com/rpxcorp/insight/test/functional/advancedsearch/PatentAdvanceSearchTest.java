package com.rpxcorp.insight.test.functional.advancedsearch;

import com.rpxcorp.insight.module.AutoComplete;
import com.rpxcorp.insight.page.advance_search.AdvanceSearchPage;
import com.rpxcorp.insight.page.advance_search.AdvanceSearchPage.SEARCHTAB;
import com.rpxcorp.insight.page.advance_search.PatentAdvanceSearchPage;
import com.rpxcorp.insight.test.functional.BaseFuncTest;
import com.rpxcorp.testcore.Assert;
import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.Test;

@Authenticate(role = "MEMBER")
public class PatentAdvanceSearchTest extends BaseFuncTest{
    AdvanceSearchPage advanceSearchPage;
    PatentAdvanceSearchPage patentAdvanceSearchPage;

    @Test(priority = 1, groups ="P2", description = "verify patent title auto suggest with case insensitive search")
    public void verifyTitleAutoSuggest() throws Exception {
        navigateToPatentAdvanceSearch();
        patentAdvanceSearchPage.title.sendKeys("guide for winding");
        Assert.contains(patentAdvanceSearchPage.title.getDropDownValue(),"GUIDE FOR WINDING THREAD ON TRANSVERSE SPOOLS");
//                "Capital case appear in auto suggest");
        Assert.contains(patentAdvanceSearchPage.title.getDropDownValue(),"Guide for winding paper strips");
//                "Camel case appear in auto suggest");
    }

    @Test(priority = 2, groups ="P2", dataProvider="json",description = "verify patent and application number auto search with valid data")
    public void verifyPatNAppNumAutoSuggestWithValidData(String searchField,String searchValue, String expectedDropDown,String assertMessage) throws Exception {
        navigateToPatentAdvanceSearch();
        AutoComplete autoSuggestElem= (AutoComplete) patentAdvanceSearchPage.object(searchField);
        autoSuggestElem.sendKeys(searchValue);
        Assert.contains(autoSuggestElem.getDropDownValue(),expectedDropDown);
//                assertMessage);
    }

    @Test(priority = 3, groups ="P3", dataProvider="json",description = "verify patent and application number auto search with invalid data")
    public void verifyPatNAppNumAutoSuggestWithInValidData(String searchField,String searchValue, String assertMessage) throws Exception {
        navigateToPatentAdvanceSearch();
        AutoComplete autoSuggestElem= (AutoComplete) patentAdvanceSearchPage.object(searchField);
        autoSuggestElem.sendKeys(searchValue);
        patentAdvanceSearchPage.waitForRequestInit();
        Assert.isTrue(autoSuggestElem.dropdown.waitUntilInvisible(),
                assertMessage);
    }

    public void navigateToPatentAdvanceSearch(){
        to(advanceSearchPage);
        advanceSearchPage.searchFormTabLinks.selectExactTabName(SEARCHTAB.Patent);
        at(patentAdvanceSearchPage);
    }
}
