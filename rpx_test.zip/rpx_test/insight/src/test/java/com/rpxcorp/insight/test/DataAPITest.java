package com.rpxcorp.insight.test;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.rpxcorp.insight.test.data.BaseDataTest;
import com.rpxcorp.testcore.util.ExcelUtil;
import com.rpxcorp.testcore.util.SQLProcessor;
import com.rpxcorp.testcore.util.ConfigUtil;

public class DataAPITest extends BaseDataTest{

	SQLProcessor sqlProcessor = SQLProcessor.getInstance();
	SoftAssert softAssert;
	ExcelUtil testData = new ExcelUtil(ConfigUtil.config().get("testResourcesDir") + "/test_data/ApiTestData.xls");

	@Test(dataProvider = "getData")
	public void verifyApiData(Map<String, String> data) throws Exception{
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("from_date", data.get("from_date"));
		params.put("to_date", data.get("to_date"));		
		if(data.containsKey("duration")){		
			params.put("duration", data.get("duration"));
		}
		if(data.containsKey("t_interval")){		
			params.put("t_interval", data.get("t_interval"));
		}		

		String paramArray[] =  data.get("params").split(",");
		assertJson(sqlProcessor.getSingleValue(data.get("actual_api"), params, data.get("columnName"))
				, sqlProcessor.getSingleValue(data.get("expected_query"), params, data.get("columnName")), paramArray);
	}	

	@DataProvider
	public Object[][] getData() {
		return testData.getAllCoumnDataAsMap("data");
	}
	
	@Test(description = "Verify portfolio download", dataProvider = "getPortfolioData")
	public void verifyPortfolioDownload(String deal_id, String acq_id, String port_id) throws Exception {
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("acquisition_id", acq_id);
		params.put("portfolio_id", port_id);
		params.put("deal_id", deal_id);				
		assertResultSet(sqlProcessor.getResultData("DataAPI.ACT_PORTFOLIOs_DOWNLOAD", params),
				sqlProcessor.getResultData("DataAPI.EXP_PORTFOLIOs_DOWNLOAD", params));		
	}	
	
	@DataProvider
	public Object[][] getPortfolioData() {
		return new Object[][] {
				{ "1039403" , "2208", "9281" },									
				{ "1039618" , "2243", "9429" }
		};
	}	
	
	@Test(description = "Verify Patent Portfolio informations in dossier", dataProvider = "getRelatedEntId")
	public void verifyPatentInformation(String related_ent_id) throws Exception {
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_PATENT_INFORMATION_FOR_ENTITY", related_ent_id),
				sqlProcessor.getResultData("DataAPI.EXP_PATENT_INFORMATION_FOR_ENTITY", related_ent_id));
	}
	
	@Test(description = "Verify patent litigation informations in related patent", dataProvider = "getRelatedEntId")
	public void verifyPatentLitigationInformation(String related_ent_id) throws Exception {
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_PATENT_LITIGATION_INFORMATION_FOR_ENTITY", related_ent_id),
				sqlProcessor.getResultData("DataAPI.EXP_PATENT_LITIGATION_INFORMATION_FOR_ENTITY", related_ent_id));
	}
	
	@DataProvider
	public Object[][] getRelatedEntId() {
		return new Object[][]{
				{ "57466" }, {"1006020"}				
		};
	}	
	
	@Test(description = "Verify litigation history informations in dossier", dataProvider = "getDossierData")
	public void verifyLitigationHistoryDossier(String ent_id) throws Exception {
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_LITIGTAION_HISTORY_DOSSIER_BASE_QUERY", ent_id),
				sqlProcessor.getResultData("DataAPI.EXP_LITIGATION_HISTORY_VALUES_DOSSIER", ent_id));
	}
	
	@DataProvider
	public Object[][] getDossierData(){
		return new Object[][]{ {"431383"}
		};
	}
	
	@Test(description = "Verify petitions informations in dossier", dataProvider = "getPetitionData")
	public void verifyPetitionInformationDossier(String ent_id, String bool_value) throws Exception {
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("bool_value", bool_value);
		params.put("ent_id", ent_id);		
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_PETITIONS_SECTION_DOSSIER", params),
				sqlProcessor.getResultData("DataAPI.EXP_PETITIONS_SECTION_DOSSIER_PTAB_CASE_VALUES", params));
	}
	
	@DataProvider
	public Object[][] getPetitionData(){
		return new Object[][] { {"68790", "True"}, {"943494", "False"} };
	}
	
	@Test(description = "Verify petitions informations in dossier", dataProvider = "getPetitionJSONData")
	public void verifyPetitionJsonValuesDossier(String ent_id, String bool_value) throws Exception {
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("bool_value", bool_value);
		params.put("ent_id", ent_id);	
		String paramArray[] =  {"ultimate_parent_id", "ultimate_parent_name", "ent_id", "ent_name", "is_entity", "party_type_name"};
		assertJson(sqlProcessor.getSingleValue("DataAPI.ACT_PETITIONS_SECTION_JSON_DOSSIER", params, "ptab_petitioners"),
				sqlProcessor.getSingleValue("DataAPI.EXP_PETITIONS_SECTION_DOSSIER_PTAB_CASE_JSON_VALUES", params, "ptab_petitioners"), paramArray);		
		assertJson(sqlProcessor.getSingleValue("DataAPI.ACT_PETITIONS_SECTION_JSON_DOSSIER", params, "ptab_patent_owners"),
				sqlProcessor.getSingleValue("DataAPI.EXP_PETITIONS_SECTION_DOSSIER_PTAB_CASE_JSON_VALUES", params, "ptab_patent_owners"), paramArray);		
		assertJson(sqlProcessor.getSingleValue("DataAPI.ACT_PETITIONS_SECTION_JSON_DOSSIER", params, "ptab_real_party_in_interests"),
				sqlProcessor.getSingleValue("DataAPI.EXP_PETITIONS_SECTION_DOSSIER_PTAB_CASE_JSON_VALUES", params, "ptab_real_party_in_interests"), paramArray);
	}
	
	@DataProvider
	public Object[][] getPetitionJSONData(){
		return new Object[][] { {"68790", "True"} };
	}

	@Test(description = "Verify litigation fields in litigation data download", dataProvider = "getLitigationId")
	public void verifyLitigationFieldsInLitDownload(String lit_id) throws Exception {
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_LITIGATION_DETAIL_DOWNLOAD_LIT_FIELDS", lit_id),
				sqlProcessor.getResultData("DataAPI.EXP_LITIGATION_DETAIL_DOWNLOAD_LIT_FIELDS", lit_id));
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_LITIGATION_DETAIL_DOWNLOAD_PARTY_FIELDS", lit_id),
				sqlProcessor.getResultData("DataAPI.EXP_LITIGATION_DETAIL_DOWNLOAD_PARTY_FIELDS", lit_id));
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_LITIGATION_DETAIL_DOWNLOAD_PATENT_FIELDS", lit_id),
				sqlProcessor.getResultData("DataAPI.EXP_LITIGATION_DETAIL_DOWNLOAD_PATENT_FIELDS", lit_id));
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_LITIGATION_DETAIL_DOWNLOAD_COUNSEL_FIELDS", lit_id),
				sqlProcessor.getResultData("DataAPI.EXP_LITIGATION_DETAIL_DOWNLOAD_COUNSEL_FIELDS", lit_id));
	}

	@DataProvider
	public Object[][] getLitigationId() {
		return new Object[][]{
				 {"66145"}
		};
	}

	@Test(description = "Verify campaign fields in campagin data download", dataProvider = "getCampaignId")
	public void verifyCampaginFieldsInCampDownload(String campaign_id) throws Exception {
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_CAMPAIGN_DETAIL_DOWNLOAD_LIT_FIELDS", campaign_id),
				sqlProcessor.getResultData("DataAPI.EXP_CAMPAIGN_DETAIL_DOWNLOAD_LIT_FIELDS", campaign_id));
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_CAMPAIGN_DETAIL_DOWNLOAD_PATENT_FIELDS", campaign_id),
				sqlProcessor.getResultData("DataAPI.EXP_CAMPAIGN_DETAIL_DOWNLOAD_PATENT_FIELDS", campaign_id));
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_CAMPAIGN_DETAIL_DOWNLOAD_PLAINTIFF_COUNSEL_FIELDS", campaign_id),
				sqlProcessor.getResultData("DataAPI.EXP_CAMPAIGN_DETAIL_DOWNLOAD_PLAINTIFF_COUNSEL_FIELDS", campaign_id));
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_CAMPAIGN_DETAIL_DOWNLOAD_DEFENDANT_COUNSEL_FIELDS", campaign_id),
				sqlProcessor.getResultData("DataAPI.EXP_CAMPAIGN_DETAIL_DOWNLOAD_DEFENDANT_COUNSEL_FIELDS", campaign_id));
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_CAMPAIGN_DETAIL_DOWNLOAD_PARTY_FIELDS", campaign_id),
				sqlProcessor.getResultData("DataAPI.EXP_CAMPAIGN_DETAIL_DOWNLOAD_PARTY_FIELDS", campaign_id));
	}

	@DataProvider
	public Object[][] getCampaignId() {
		return new Object[][]{
				{"421"}
		};
	}

    @Test(description = "Verify Investigation fields in ITC data download", dataProvider = "getITCId")
    public void verifyINVFieldsInITCDownload(String itc_id) throws Exception {
        assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_ITC_DETAIL_DOWNLOAD_INV_FIELDS", itc_id),
                sqlProcessor.getResultData("DataAPI.EXP_ITC_DETAIL_DOWNLOAD_INV_FIELDS", itc_id));
        assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_ITC_DETAIL_DOWNLOAD_PARTY_COUNSEL_FIELDS", itc_id),
                sqlProcessor.getResultData("DataAPI.EXP_ITC_DETAIL_DOWNLOAD_PARTY_COUNSEL_FIELDS", itc_id));
        assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_ITC_DETAIL_DOWNLOAD_PATENT_FIELDS", itc_id),
                sqlProcessor.getResultData("DataAPI.EXP_ITC_DETAIL_DOWNLOAD_PATENT_FIELDS", itc_id));
    }

    @DataProvider
    public Object[][] getITCId() {
        return new Object[][]{
                {"1065"}
        };
    }

    @Test(description = "Verify Litigation fields in Patent data download", dataProvider = "getPatId")
    public void verifyLiFieldsInPatentDownload(String pat_id) throws Exception {
        assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_PAT_DETAIL_DOWNLOAD_LIT_FIELDS", pat_id),
                sqlProcessor.getResultData("DataAPI.EXP_PAT_DETAIL_DOWNLOAD_LIT_FIELDS", pat_id));
        assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_PAT_DETAIL_DOWNLOAD_PARTY_FIELDS", pat_id),
                sqlProcessor.getResultData("DataAPI.EXP_PAT_DETAIL_DOWNLOAD_PARTY_FIELDS", pat_id));
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_PAT_DETAIL_DOWNLOAD_PATENT_FIELDS", pat_id),
				sqlProcessor.getResultData("DataAPI.EXP_PAT_DETAIL_DOWNLOAD_PATENT_FIELDS", pat_id));
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_PAT_DETAIL_DOWNLOAD_COUNSEL_FIELDS", pat_id),
				sqlProcessor.getResultData("DataAPI.EXP_PAT_DETAIL_DOWNLOAD_COUNSEL_FIELDS", pat_id));
    }

    @DataProvider
    public Object[][] getPatId() {
        return new Object[][]{
                {"3198685"}
        };
    }

	@Test(description = "Verify Petition fields in PTAB data download", dataProvider = "getPTABId")
	public void verifyPetitionFieldsInPTABDownload(String ptab_id) throws Exception {
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_PTAB_DETAIL_DOWNLOAD_PETITION_FIELDS", ptab_id),
				sqlProcessor.getResultData("DataAPI.EXP_PTAB_DETAIL_DOWNLOAD_PETITION_FIELDS", ptab_id));
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_PTAB_DETAIL_DOWNLOAD_PARTY_FIELDS", ptab_id),
				sqlProcessor.getResultData("DataAPI.EXP_PTAB_DETAIL_DOWNLOAD_PARTY_FIELDS", ptab_id));
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_PTAB_DETAIL_DOWNLOAD_PATENT_FIELDS", ptab_id),
				sqlProcessor.getResultData("DataAPI.EXP_PTAB_DETAIL_DOWNLOAD_PATENT_FIELDS", ptab_id));
		assertResultSet(sqlProcessor. getResultData("DataAPI.ACT_PTAB_DETAIL_DOWNLOAD_COUNSEL_FIELDS", ptab_id),
				sqlProcessor.getResultData("DataAPI.EXP_PTAB_DETAIL_DOWNLOAD_COUNSEL_FIELDS", ptab_id));
	}

	@DataProvider
	public Object[][] getPTABId() {
		return new Object[][]{
				{"6442"}
		};
	}
}
