package com.rpxcorp.insight.page.error_page;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class MaximumDownloadsReachedPage extends BasePage {

    @Override
    public boolean at() {
        System.out.println(pageTitle.getText() + pageTitle);
        pageTitle.waitUntilVisible();
        return pageTitle.waitUntilTextPresent("Maximum Downloads Reached");
    }


    public final Element errorMessage = $("#content .panel p");
}
