package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.By;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class TierMatrixFeaturesPage extends BasePage {

	public TierMatrixFeaturesPage() {
		this.url = new PageUrl("admin/tier_matrices");
	}

	@Override
	public boolean at() {

		return addNewFeatureBtn.waitUntilVisible();
	}

	public final Element addNewFeatureBtn = $("a.button[href$='tier_matrices/new']");
	public final Element lastFeatureOrder= $("tr[data-id]:last-child td:nth-child(4)");
	public final Element viewLink =$(By.jquery("tr[data-id] td:nth-child(1):contains('{title_name}') a"));
	public final Element editLink =$(By.jquery("tr[data-id] td:nth-child(1):contains('{title_name}')~td:nth-child(6) a[href*=edit]"));
	public final Element deteleLink =$(By.jquery("tr[data-id] td:nth-child(1):contains('{title_name}')~td:nth-child(6) a[data-method='delete']"));

}
