package com.rpxcorp.insight.page.payment;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriverException;

import java.util.Map;

public class AddCreditPage extends BasePage {

    public AddCreditPage() {
        this.url = new PageUrl("payments/add_credit");
    }

    @Override
    public boolean at() {
        loading.waitUntilInvisible();
        documentCreditAmount.waitUntilVisible();
        return true;
    }

    public final Element paymentCheckoutForm = $("form[id='payments_checkout_form']");

    // CREDIT AMOUNT
    public final Element documentCreditAmount = $("#document_credit_amount");

    // PAYMENT INFORMATION
    public final Element creditCardNumber = $("#credit-card-number");
    public final Element expirationDate = $("#expiration");
    public final Element cvv = $("#cvv");
    public final Element postalCode = $("#postal-code");
    public final Element termsAndConditions = $("#terms_and_conditions");
    public final Element iframe = $("#braintree-dropin-frame");

    public final Element countryDropdown = $("#s2id_user_details_country_code a");
    public final Element countrySearch = $("#s2id_autogen1_search");
    public final Element countrySelect = $("ul.select2-results li:nth-of-type(1)");

    public void selectCountry(String country) throws  Exception{
        final WebDriverException[] exception = new WebDriverException[1];
        try {
            countryDropdown.waitUntilVisible();
            countryDropdown.scrollAndFocus();
            Thread.sleep(2000);
            countryDropdown.click();
            countrySearch.waitUntilVisible();
            countrySearch.sendKeys(country + Keys.RETURN);
        } catch (WebDriverException e) {
            exception[0] = e;
            System.out.println("The Excpetion in selecting country is "+e);
                countryDropdown.click();
                countrySearch.waitUntilVisible();
                countrySearch.sendKeys(country + Keys.RETURN);
            }

    }

    public void enterPaymentInformation(Map<String, String> paymentInfo) throws Exception{
        iframe.waitUntilSwitchToFrame();
        creditCardNumber.sendKeys(paymentInfo.get("card_number"));
        expirationDate.sendKeys(paymentInfo.get("expiration_date"));
        cvv.sendKeys(paymentInfo.get("cvv"));
        postalCode.sendKeys(paymentInfo.get("postal_code"));
        getDriver().switchTo().defaultContent();
        selectCountry(paymentInfo.get("country"));
    }

    public final Element payButton = $("input[class*='payment_button']");

    public void purchaseCredits(Map<String, String> purchaseDetails) throws  Exception{
        loading.waitUntilInvisible();
        paymentCheckoutForm.waitUntilVisible();
        documentCreditAmount.waitUntilVisible();
        documentCreditAmount.sendKeys(purchaseDetails.get("credit_amount"));
        enterPaymentInformation(purchaseDetails);
        termsAndConditions.click();
        payButton.click();
        loading.waitUntilInvisible();
    }

    public final Element paymentErrorMsg = $(".payment_error_message");

    public final Element timeline_bar = $(".progress.small-centered.columns.small-6.round");
}
