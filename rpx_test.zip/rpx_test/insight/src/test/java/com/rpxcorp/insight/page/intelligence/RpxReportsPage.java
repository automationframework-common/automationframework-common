package com.rpxcorp.insight.page.intelligence;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

public class RpxReportsPage extends BasePage {

    public RpxReportsPage() {
        this.url = new PageUrl("rpx_reports");
    }

    @Override
    public boolean at() {
        //assertPageTitle("RPX Reports");
        loading.waitUntilInvisible();
        Assert.assertEquals(title.getText(),"RPX Reports");
        return weeklynews_btn.waitUntilVisible();
    }

    public final Element title = $("div.report-header");
    public final Element weeklynews_btn = $("a[href='#weekly-newsletters']");
    public final Element quarterlyreports_btn = $("a[href='#quarterly-reports']");
    public final Element annualreports_btn = $("a[href='#annual-reports']");
    public final Element otherreports_btn = $("a[href='#other-reports']");
    public final Element monthlyreports_btn = $("a[href='#monthly-npe-reports']");

    //public final Element paeReport_btn = $(".button.pae_report");
    //public final Element paeSection = $(".top.row");

    public final Element rpx_weekly_newsletters = $("div#weekly_newsletters_rpx_reports a.weekly-newsletter-link");

    public void clickWeeklyReportsTab() {
        if (weeklynews_btn.isDisplayed()) {
            weeklynews_btn.click();
        }
        loading.waitUntilInvisible();
    }

    //RPX MONTHLY REPORTS
    public final Element npe_report_section_title = $(By.xpath("//div[@class='top row']/div/h5[text()='RPX Monthly NPE Reports']"));
    public final Element rpx_monthly_npeReports = $("#monthly-npe-reports .month-reports-npe span");//div[@class='panel']//a[contains(@href,'monthly_npe')]
    public final Element rpx_monthly_npeReportsPromoMsg = $("li#monthly-npe-reports a.subscribe_page_link.blocked-content-promo.trial:contains(Start with a Free Trial)");
    public final Element rpx_monthly_npeReportsElitePromoMsg = $("li#monthly-npe-reports a.subscribe_page_link.blocked-content-promo.trial:contains('Available with Elite subscription and above')");

    public void clickMonthlyNPEReportsTab() {
        loading.waitUntilInvisible();
        if (monthlyreports_btn.isDisplayed()) {
            monthlyreports_btn.click();
        }
    }

    public ArrayList<String> getLastSixMonthsData(String lastPublishedDate) throws Exception{
        DateTimeFormatter monthYearFormatter = DateTimeFormatter
                .ofPattern("yyyy MMM");

        SimpleDateFormat thisMonth = new SimpleDateFormat("MMM yyyy");
        Date datee = thisMonth.parse(lastPublishedDate);

        DateFormat destDf = new SimpleDateFormat("yyyy-MM");
        String asdfsdf = destDf.format(datee);

        YearMonth NPElastPublised = YearMonth.parse(asdfsdf.toString());
        YearMonth NPElastPublised_l = NPElastPublised.minusMonths(1);
        YearMonth NPElastPublised_2 = NPElastPublised.minusMonths(2);
        YearMonth NPElastPublised_3 = NPElastPublised.minusMonths(3);
        YearMonth NPElastPublised_4 = NPElastPublised.minusMonths(4);
        YearMonth NPElastPublised_5 = NPElastPublised.minusMonths(5);

        ArrayList<String> data = new ArrayList<String>();
        data.add(NPElastPublised.format(monthYearFormatter)+" Report");
        data.add(NPElastPublised_l.format(monthYearFormatter)+" Report");
        data.add(NPElastPublised_2.format(monthYearFormatter)+" Report");
        data.add(NPElastPublised_3.format(monthYearFormatter)+" Report");
        data.add(NPElastPublised_4.format(monthYearFormatter)+" Report");
        data.add(NPElastPublised_5.format(monthYearFormatter)+" Report");
        return(data);
    }

    public void expandSections(){
        $(".panel.year.panel-plus:visible").waitUntilVisible();
        JavascriptExecutor js = (JavascriptExecutor) getDriver();
        js.executeScript("$('.panel.year.panel-plus:visible').click();");
    }

    public ArrayList<String> getAllNpeReports() {
        return rpx_monthly_npeReports.getAllData();
    }

    // PAE REPORTS
    public final Element pae_2015Q4Report_btn = $(By.xpath("//span[text()='2015 Q4 Report']"));
    public final Element pae_2015Q3Report_btn = $(By.xpath("//span[text()='2015 Q3 Report']"));
    public final Element pae_2016Q2Report_btn = $(By.xpath("//span[text()='2016 Q2 Report']"));
    public final Element pae_2016Q1Report_btn = $(By.xpath("//span[text()='2016 Q1 Report']"));
    public final Element otherReportsdownload = $("div#other_reports_rpx_reports a[data-behavior='rpx_report_download_tracker']");

    // STANDARD ESENTIAL PATENT REPORTS
    public final Element stdEssentialPatentReport = $("div.other-reports-div div.columns h5:contains('Standard Essential Patents')");
    // PROGRAMMATIC NPE REPORT
    public final Element programmaticNpeReport = $(
            By.xpath("//*[@id='other_reports_rpx_reports']//h5[contains(text(),'Programmatic NPE Report:')]//parent::div//span[text()='Download PDF']"));

    // Intellectual Ventures Report
    public final Element intellectualVentures = $(
            By.xpath("//*[@id='other_reports_rpx_reports']//h5[contains(text(),'Intellectual Ventures:')]//parent::div//span[text()='Download PDF']"));

    // NPE Finance Report
    public final Element npeFinanceReports = $(
            By.xpath("//*[@id='other_reports_rpx_reports']//h5[contains(text(),'NPE Finance: An Overview')]//parent::div//span[text()='Download PDF']"));


    public void clickotherReportsTab() {
        if (otherreports_btn.isDisplayed()) {
            otherreports_btn.click();
        }
        loading.waitUntilInvisible();
    }

    public final Element rpx_otherReportsPromoMsg = $("li#other-reports div.subscription-promo-message a:contains('Start with a Free Trial')");
    public final Element rpx_otherReportsELitePromoMsg = $("li#other-reports div.subscription-promo-message a:contains('Available with Elite subscriptions and above')");

    // NPE 2015 LITIGATION, PATENT MARKETPLACE AND COST REPORT(ANNUAL REPORTS)
    public final Element npeCostReport2015 = $("#annual_reports_rpx_reports a:contains('2015')+div span:contains('NPE Litigation, Patent Marketplace, and NPE Cost Report')");

    // STANDARD REPORTS(ANNUAL REPORTS)
    public final Element rpx2014NpeCostReport = $("#annual_reports_rpx_reports a:contains('2014')+div span:contains('NPE Cost Report')");
    public final Element rpx2014NpeLitigationReport = $("#annual_reports_rpx_reports a:contains('2014')+div span:contains('NPE Litigation Report')");
    public final Element rpx2014PatentMarketplaceReport = $("#annual_reports_rpx_reports a:contains('2014')+div span:contains('Patent Marketplace Report')");

    public final Element rpx2013NpeLitigationReport = $("#annual_reports_rpx_reports a:contains('2013')+div span:contains('NPE Litigation Report')");

    public final Element rpx2012NpeActivityReport = $("#annual_reports_rpx_reports a:contains('2012')+div span:contains('NPE Activity Report')");
    public final Element rpx_annualReportsPromoMsg = $("li#annual-reports div.subscription-promo-message a:contains('Start with a Free Trial')");
    public final Element rpx_annualReportsElitePromoMsg = $("li#annual-reports div.subscription-promo-message a:contains('Available with Elite subscriptions and above')");

    public void clickAnnualReportsTab() {
        if (annualreports_btn.isDisplayed()) {
            annualreports_btn.click();
        }
        loading.waitUntilInvisible();
    }

    //Patent risk reduction report
    public final Element rpx_quarterlyReports = $("li.active div#quarterly_reports_rpx_reports");
    public final Element rpx_quarterly_npeReportsPromoMsg = $("li#quarterly-reports .subscription-promo-message:contains(Start with a Free Trial)");
    public final Element rpx_quarterly_npeReportsElitePromoMsg = $("li#quarterly-reports .subscription-promo-message:contains('Available with Elite subscriptions and above')");

    public void clickQuarterlyReportsTab() {
        if (quarterlyreports_btn.isDisplayed()) {
            quarterlyreports_btn.click();
        }
        loading.waitUntilInvisible();
    }

    public final Element quarterly_report_AbtSection = $("div#sidebar h2:contains(About)+p");
    public final Element quarterly_report_CurrentQuartTitle = $("div#quarterly_reports_rpx_reports div.columns.month span:visible");
    public final Element quarterly_report_CurrentQuartSumTitle = $("div#quarterly_reports_rpx_reports > div:nth-child(1) h5:nth-child(3)");
    public final Element quarterly_report_CurrentQuartSumContent = $("div#quarterly_reports_rpx_reports > div:nth-child(1) p:not(:empty)"); //div#quarterly_reports_rpx_reports > div:nth-child(1) h5:nth-child(2)+p


    //Current Quarter Risk reduction Reports
    public final Element quarterly_report_currentQuarPRRreport = $("#quarterly_reports_rpx_reports > div:nth-child(2) span:contains(Patent Risk Reduction Report)");
    public final Element quarterly_report_currentQuarAssetList = $("#quarterly_reports_rpx_reports > div:nth-child(2) span:contains(Asset List)");
    public final Element quarterly_report_currentQuarMembNotice = $("#quarterly_reports_rpx_reports > div:nth-child(2) span:contains(Member Notice)"); //ONly non-RPX member

    //Old Reports Title(HTML)
    public final Element quarterly_report_LastQuartTitle = $("div#quarterly_reports_rpx_reports>div.row div.panel:nth-child(2) div.row:visible:first-child>div.columns.month");//div#quarterly_reports_rpx_reports > div:nth-child(3) div.row:first-child h5
    public final Element quarterly_report_LastQuarPRRreport = $("div#quarterly_reports_rpx_reports>div.row div.panel:nth-child(2) div.row:visible:nth-child(2) a.quarter-reports-prr");
    public final Element quarterly_report_LastQuarAssetList = $("div#quarterly_reports_rpx_reports>div.row div.panel:nth-child(2) div.row:visible:nth-child(2) a.quarter-reports-assets");

    //About Section in Patent Risk Reduction Report Page
    public final String[] aboutContent = new String[]{
            "RPX periodically produces news and analysis as well as targeted " +
                    "research reports on the broader patent landscape for its clients. " +
                    "We welcome suggestions for topics that would be of particular interest to your company. " +
                    "Please email us at insight@rpxcorp.com."};




}
