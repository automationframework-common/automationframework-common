package com.rpxcorp.insight.page.account;

import org.openqa.selenium.By;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class ContactPage extends BasePage {

    public ContactPage() {
        this.url = new PageUrl("clients/my-rpx-contact");
    }

    @Override
    public boolean at() {
        assertPageTitle("Contact");
        return sendMessageBtn.waitUntilVisible();
    }

    public final Element sendMessageBtn = $(".button[value='Send Message']");
    public final Element yourRepresentativePanel = $("div[data-url*=contact-representative]");
    public final Element rpxContactInfoPanel =  $("div[data-url*=rpx-contact-information]");

    public final Element contactRPXSearchSupportHeader = $(".section-subtitle:contains('Contact the RPX Insight team')");
    public final Element contactRPXSearchSupportMsg = $("div.content-container p:contains(Use this form to send a message to the RPX Insight team. A copy of your message will also be sent to)");
    public final Element contactRPXSearchSupportPlaceholder = $("textarea[placeholder='Enter your message to send to the RPX Insight team']");
    public final Element contactRepresentativeHeader =$(".section-subtitle:contains(Contact)");
    public final Element contactRepresentativeMsg = $("div.content-container p:contains(A copy of your message will also be sent to you)");
    public final Element contactRepresentativePlaceholder = $("textarea[placeholder^='Enter your message to send to']");
}
