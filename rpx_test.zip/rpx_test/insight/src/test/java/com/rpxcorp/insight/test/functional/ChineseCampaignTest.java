package com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.LitigationDocumentPage;
import com.rpxcorp.insight.page.detail.*;
import com.rpxcorp.oldtest.page.DBData;
import com.rpxcorp.testcore.Authenticate;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.*;


@Authenticate(role = "MEMBER")
@Test(groups = "Campaign")
public class ChineseCampaignTest extends BaseFuncTest {

    DBData data = null;
    SoftAssert softAssert;
    ChineseLitigationDetailPage chineseLitigationDetailPage;
    CampaignDetailPage campaignDetailPage;
    LitigationDetailPage litigationDetailPage;
    EntityDetailPage entityDetailPage;
    ITCDetailPage itcDetailPage;
    PtabDetailPage ptabDetailPage;
    PatentDetailPage patentDetailsPage;
    EntityDetailPage entityPage;
    LitigationDocumentPage litigationDocumentPage;
    BaseDetailPage detailPage;

    public static ArrayList<String> actualAvailableList;
    public static ArrayList<String> actualSelectedList;

    @BeforeClass
    public void intializeTest() throws Exception {
        data = new DBData();
    }

    @BeforeGroups(groups = "DEFENDANT VIEW CHINESE")
    private void loadChineseOnlyDefendantTab() throws Exception {
        this.urlData.put("ID", data.getChineseOnlyCampId(true));
        to(campaignDetailPage, urlData);
        campaignDetailPage.campaignOverviewSection.waitUntilVisible();
        campaignDetailPage.defendantTab.click();
    }

    @BeforeGroups(groups = "CASE VIEW CHINESE")
    public void loadCaseViewTabWithAllCase() throws Exception {
        this.urlData.put("ID", data.getChineseOnlyCampId(true));
        to(campaignDetailPage, urlData);
        campaignDetailPage.campaignOverviewSection.waitUntilVisible();
        campaignDetailPage.caseViewTab.click();
    }

    @Test(priority = 100, groups = {"P2", "smoke"}, description = "Verify sections for Chinese campaigns with all cases")
    public void checkChineseOnlyCampaignSection() throws Exception {
        SoftAssert softAssert = new SoftAssert();
        to(campaignDetailPage, "4060869-huawei-technologies-co-ltd-101-282-367");
        softAssert.assertTrue(campaignDetailPage.overviewPanel.isPresent(), "Metrics section is not present in the Chinese only campaign details page");
        softAssert.assertTrue(campaignDetailPage.campaignOverviewSection.isPresent(), "Campaign Overview section is not present in the Chinese only campaign details page");
        softAssert.assertTrue(campaignDetailPage.campaignPatentSection.isPresent(), "Patent section is not present in the Chinese only campaign details page");
        softAssert.assertTrue(campaignDetailPage.plaintiff_table.isPresent(), "plaintiff section is not present in the Chinese only campaign details page");
        softAssert.assertFalse(campaignDetailPage.campPetition.isPresent(), "Petition section is present in the Chinese only campaign details page");
        softAssert.assertTrue(campaignDetailPage.reexamination_table.isPresent(), "Chinese PRB Reexaminations is not present in the Chinese only campaign details page");
        softAssert.assertTrue(campaignDetailPage.venueChinaMap.isPresent(),"The China Venues Map is not getting displayed in the Chinese only Campaign");
        softAssert.assertAll();
    }

    // TO DO get input from DB
    @Test(priority = 101,groups = {"P2"},description = "Verify Chinese Only campaign Header")
    public void checkChineseOnlyCampaignHeader() throws Exception {
        this.urlData.put("ID", "4018584");
        to(campaignDetailPage, urlData);
        assertTrue(campaignDetailPage.detailPageTitle.getText().contains("Beijing Yingde Qingda Technology Co., Ltd. (102,134,511)") , "The Campaign title does not contain 'Beijing Yingdeqing Big Technology Co. LTD (102,134,511)'");
        assertEquals(campaignDetailPage.campaignHeader.getData("CN"), "CN");
        assertEquals(campaignDetailPage.campaignHeader.getData("Status"), "Closed");
        Assert.assertTrue(campaignDetailPage.initiatedDate.getText().contains("Initiated"));
    }

    //Todo This TC is invalid now, since initiated date is available for chinese cases.
 /* @Test(priority = 1, description = "Verify Chinese Only Campaign 'Initiated Date' Field Should not be available if any cases in that campaign 'Data Filed' have 'N/A'")
    public void checkChineseOnlyIntiatedDateNotVisible() throws Exception {
        this.urlData.put("ID", "4017108");
        to(campaignDetailPage, urlData);
            Assert.assertFalse(campaignDetailPage.initiatedDate.isDisplayed());
    }*/

    @Test(priority = 102, groups = "P2", description = "Campaign Page - Metrics")
    public void checkChineseOnlyCampaignMetricsSection() throws Exception {
        this.urlData.put("ID", "4018785");
        to(campaignDetailPage, urlData);
        campaignDetailPage.caseViewTab.click();
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        Map<String, String> campaignMetrics = campaignDetailPage.overviewPanel.getData();
        campaignDetailPage.caseTable.viewAll();
        assertEquals(campaignMetrics.get("Case Count"), campaignDetailPage.caseTable.getColumn("Case Name").size());
        //assertEquals(campaignMetrics.get("Petitions Count"),
        //campaignDetailPage.petitionsPetitionTable.getColumn("Patent Number").size());
        campaignDetailPage.selectDefendantTab();
        assertEquals(campaignMetrics.get("Defendants Count"),
                campaignDetailPage.defendant_table.getColumn("Defendants").size());
        assertEquals(campaignMetrics.get("Patents Count"), campaignDetailPage.patentSectionTitle.getIntData());
        assertEquals(campaignMetrics.get("Defendants Terminated Count"),
                campaignDetailPage.getColumnCountWithValues());
        campaignDetailPage.timelineTab.click();
    }

    //Defendant View Chinese
    @Test(priority = 201,groups = {"P2", "DEFENDANT VIEW CHINESE"},description = "Verify 'Defendant Parent' Link in Defendent View Tab for Campaign details page")
    public void verifyChineseOnlyCampaignDefendentParentLinkTextForDefendentViewTab() throws Exception {

        campaignDetailPage.campaignOverviewSection.waitUntilVisible();
        campaignDetailPage.defendantTab.click();
        String defendantParentText = campaignDetailPage.defendantParentLink.getAttribute("href");// getColumnLinkText("Defendant
        Assert.assertTrue(campaignDetailPage.defendantTabitcCallout.getAttribute("href").contains("/litigation/china/"));
        withNewWindow(campaignDetailPage.defendantParentLink, () -> {
            at(entityDetailPage);
            System.out.println("Title " + getDriver().getTitle() + "available: " + defendantParentText);
            //Assert.assertEquals(getDriver().getTitle().contains(defendantParentText), true,
            //"Title of Page didn't match with defendant parent link text");
            Assert.assertTrue(getDriver().getCurrentUrl().contains(defendantParentText) , "The 'Chinese Entity URL' does not contain Defendent Parent Entity");

        });
    }

    @Test(priority = 202, groups = {"P2", "DEFENDANT VIEW CHINESE"},description = "Verify 'Defendants' Link in Defendent View Tab for Campaign details page")
    public void verifyChineseOnlyCampaignDefendentsLinkTextForDefendentViewTab() throws Exception {

        campaignDetailPage.campaignOverviewSection.waitUntilVisible();
        campaignDetailPage.defendantTab.click();
        String defendantsText = campaignDetailPage.defendant_table.getColumnLinkElem("Defendants").getAttribute("data-ot-content"); //
        withNewWindow(campaignDetailPage.defendant_table.getColumnLinkElem("Defendants"), () -> {
            at(entityPage);
            Assert.assertTrue(getDriver().getTitle().trim().contains(defendantsText.trim()));
        });
    }

    @Test(priority = 203,groups = {"P2", "DEFENDANT VIEW CHINESE"},description = "Verify 'Most Recent Case' Link in Defendent View Tab for Campaign details page")
    public void verifyChineseOnlyCampaignMostRecentCaseLinkTextForDefendentViewTab() throws Exception {

        campaignDetailPage.campaignOverviewSection.waitUntilVisible();
        campaignDetailPage.defendantTab.click();
        String mostRecentCaseText = campaignDetailPage.defendant_table.getColumnLinkText("Most Recent Case");
        withNewWindow(campaignDetailPage.defendant_table.getColumnLinkElem("Most Recent Case"), () -> {
            at(litigationDetailPage);  //TODO: Change to chinese litigation detail page
            Assert.assertTrue(getDriver().getCurrentUrl().contains("/litigation/china/") , "The 'Chinese Litigation URL' does not contain 'lit_ch'");
            Assert.assertEquals(litigationDetailPage.header_info.getData("docket_number"), mostRecentCaseText,
                    "Most Recent Case Text didn't match in Chinese litigation detail page text");

        });
    }

//    @Test(description = "Verify Chinese Only Defendant View Tab default sort order", groups = "DEFENDANT VIEW CHINESE")
//    public void verifyChineseOnlyDefendantViewTableDefaultSortOrder() throws Exception {
//        //loadCaseViewTab();
//        Assert.assertTrue(campaignDetailPage.defendant_table.getColumnHeaderElem("Start Date").getAttribute("class")
//                .contains("desc"), "Start Data field is not sorted as default in descending order");
//
//    }

    @Test(priority = 204,groups = {"P4", "DEFENDANT VIEW CHINESE","func_sorting"},description = "Validate Chinese Only Defendant tab in column sort order Campaign details page", dataProvider = "defendentviewsort")
    public void verifyChineseOnlySortFunctionalityInDefendentTab(String columnName, String sortType, String dataType) throws Exception {

//      loadChineseOnlyDefendantTab();
        campaignDetailPage.defendant_table.sort(columnName);
        List<String> columnSortValue = campaignDetailPage.defendant_table.getColumn(columnName);
        assertColumnSort(dataType, sortType, columnSortValue);

    }

    @DataProvider
    public Object[][] defendentviewsort() {
        return new Object[][] { { "Defendants", "asc", "non-date" }, { "Defendants", "desc", "non-date" },
                { "Defendant Parent", "asc", "non-date" }, { "Defendant Parent", "desc", "non-date" },
                { "Start Date", "asc", "date" }, { "Start Date", "desc", "date" },
                { "End Date", "asc", "date" }, { "End Date", "desc", "date" }};
    }

    @Test(priority = 205,groups = {"P2", "DEFENDANT VIEW CHINESE"},description = "Validate Chinese Only Defendant tab search functionality in Campaign details page")
    public void verifyChineseOnlySearchFunctionalityInDefendentTab() throws Exception {
        this.urlData.put("ID", "4020888");
        to(campaignDetailPage, urlData);
        campaignDetailPage.campaignOverviewSection.waitUntilVisible();
        campaignDetailPage.defendantTab.click();
        campaignDetailPage.defendant_table.waitUntilVisible();
        campaignDetailPage.defendantSearchBox.waitUntilClickable();
        String searchKey=campaignDetailPage.defendant_table.getColumn(2).get(1);
        System.out.println("SEARCH KEY"+searchKey);
        campaignDetailPage.defendantSearchBox.sendKeys(searchKey,
                Keys.ENTER);
        campaignDetailPage.defendant_table.waitUntilVisible();
        System.out.println("RESULTS ROW"+campaignDetailPage.defendant_table.getRows()[0]);
        Assert.assertTrue(campaignDetailPage.defendant_table.getRows()[0].contains(searchKey),
                "Search Key:"+searchKey+", Resulted row data:"+campaignDetailPage.defendant_table.getRows()[0]);
    }

    @Test(priority = 206,groups = {"P2", "DEFENDANT VIEW CHINESE"},description = "Verify Chinese Only sub table header text")
    public void verifyChineseOnlySubTableHeaderText() throws Exception {
        //loadDefendantTab();
        campaignDetailPage.defendant_table.expandSubTable();
        campaignDetailPage.defendant_table.subtable().waitUntilVisible();
        String expectedHeader[] = { "Date Filed", "Case Name", "Case Number", "Jurisdiction", "Termination Date" };
        List<String> actualHeaderList = new ArrayList<String>(Arrays.asList(campaignDetailPage.defendant_table.subtable().getHeaderData()));
        actualHeaderList.remove("Id");
        String actualHeader[] = actualHeaderList.toArray(new String[actualHeaderList.size()]);
        Assert.assertEquals(actualHeader, expectedHeader);
    }

    @Test(priority = 207,groups = {"P2", "DEFENDANT VIEW CHINESE"},description = "Chinese Only Case Number validation between table and  sub table")
    public void verifyChineseOnlyCaseNumberInTableAndSubTable() throws Exception {
        int defaultCount = 1;
        //loadDefendantTab();
        String mostRecentCase = campaignDetailPage.defendant_table.getColumn("Most Recent Case").get(0);
        if (mostRecentCase.contains("and")) {
            String[] defendantCountText = mostRecentCase.split("\\(");
            defaultCount = Integer.parseInt(defendantCountText[1].replaceAll("[^0-9]", "")) + 1;
        }
        campaignDetailPage.defendant_table.expandSubTable();
        campaignDetailPage.loading.waitUntilInvisible();
        campaignDetailPage.defendant_table.subtable().waitUntilVisible();
        Assert.assertEquals(campaignDetailPage.defendant_table.subtable().getColumn(2).size(), defaultCount,
                "Count of Case Number didn't match");
    }

    @Test(priority = 208,groups = {"P2", "DEFENDANT VIEW CHINESE"},description = "Verify Chinese Only Case View Tab table header")
    public void verifyChineseOnlyCaseViewTableHeaderText() throws Exception {
        //loadCaseViewTab();
        String expectedHeaderText[] = { "Date Filed", "Case Name", "Case Number", "Termination Date" };
        Assert.assertEquals(campaignDetailPage.caseTable.getHeaderData(), expectedHeaderText);
    }

    // TODO Need to validate termination Date
    @Test(priority = 209,groups = {"P2", "DEFENDANT VIEW CHINESE"},description = "Verify Chinese Only Case View Tab Table data")
    public void verifyChineseOnlyCaseViewTableData() throws Exception {
        //loadCaseViewTab();
        String caseName = campaignDetailPage.caseTable.getColumnText("Case Name");
        String caseNumber = campaignDetailPage.caseTable.getColumnText("Case Number");
        String filedDate = campaignDetailPage.caseTable.getColumnText("Date Filed");
        String terminationDate = campaignDetailPage.caseTable.getColumnText("Termination Date");

        withNewWindow(campaignDetailPage.caseTable.getColumnLinkElem("Case Name"), () -> {
            at(chineseLitigationDetailPage);
            Assert.assertEquals(chineseLitigationDetailPage.header_info.getData("docket_number"), caseNumber,
                    "case number text didn't match");
            Assert.assertTrue(getDriver().getTitle().contains(caseName), "case name text didn't match");
            Assert.assertEquals(chineseLitigationDetailPage.header_info.getData("filed_date").replace("Filed: ", ""), filedDate,
                    "Filed date text didn't match");

        });
    }


    //Case View Chinese
    @Test(priority = 301,groups = {"P4", "CASE VIEW CHINESE","func_sorting"},description = "Verify Chinese Only Case View Tab default sort order")
    public void verifyChineseOnlyCaseViewTableDefaultSortOrder() throws Exception {
        //loadCaseViewTab();
        Assert.assertTrue(campaignDetailPage.caseTable.getColumnHeaderElem("Date Filed").getAttribute("class")
                .contains("desc"), "Data field is not sorted in descending order");

    }

    @Test(priority = 302,groups = {"P4", "CASE VIEW CHINESE","func_sorting"},description = "Verify Case View Tab sort functionality", dataProvider = "caseviewsort")
    public void verifyChineseOnlyCaseViewTableSortFunctionality(String columnName, String sortType, String dataType) throws Exception {
        //loadCaseViewTab();
        campaignDetailPage.caseTable.sort(columnName);
        List<String> columnSortValue = campaignDetailPage.caseTable.getColumn(columnName);
        assertColumnSort(dataType, sortType, columnSortValue);
    }

    @DataProvider
    public Object[][] caseviewsort() {
        return new Object[][] { { "Date Filed", "asc", "date" }, { "Date Filed", "desc", "date" },
                { "Case Name", "asc", "non-date" }, { "Case Name", "desc", "non-date" },
                { "Case Number", "asc", "non-date" }, { "Case Number", "desc", "non-date" },
                { "Termination Date", "asc", "date" }, { "Termination Date", "desc", "date" }};
    }


    /** CHINESE CAMPAIGN - DEFENDANT TIMELINE **/

    @BeforeGroups(groups = "DEFENDANT TIMELINE CHINESE")
    public void loadDefendantTimeline() throws Exception {
        this.urlData.put("ID", "4034554");
        to(campaignDetailPage, urlData);
        campaignDetailPage.defendantsInTimelineChart.waitUntilVisible();
    }

    @Test(priority = 401, groups = {"P2", "DEFENDANT TIMELINE CHINESE"},description = "Verify default selected filter text in campaign overview section")
    public void checkChineseOnlyDefaultSelectedFilterOption() throws Exception {
        SoftAssert softAssert = new SoftAssert();
        softAssert.assertEquals(campaignDetailPage.defendant_Dropdown.getSelectedOption() ,"All");
        softAssert.assertEquals(campaignDetailPage.judgeOrCourt_Dropdown.getSelectedOption() ,"All");
        softAssert.assertEquals(campaignDetailPage.defendantStatus_Dropdown.getSelectedOption() ,"All");
        softAssert.assertEquals(campaignDetailPage.defendanteEvent_Dropdown.getSelectedOption() ,"All");
        softAssert.assertAll();
    }

    @Test(priority = 402, groups = {"P2", "DEFENDANT TIMELINE CHINESE"},description = "Verify campaign overview section tabs")
    public void checkCampaignOverviewTab() {
        SoftAssert softAssert = new SoftAssert();
        softAssert.assertEquals(campaignDetailPage.timelineTab.getText(), "Timeline",
                "Defendant timeline is not displayed");
        softAssert.assertEquals(campaignDetailPage.defendantTab.getText(), "Defendants",
                "Defendant view is not displayed");
        softAssert.assertEquals(campaignDetailPage.caseViewTab.getText(), "Cases", "Case View is not displayed");
        softAssert.assertEquals(campaignDetailPage.accusedProductTab.getText(), "Accused Products", "Accused Products is not displayed");
        softAssert.assertEquals(campaignDetailPage.patentGridTab.getText(), "Patent Grid", "Patent Grid is not displayed");
        softAssert.assertAll();
    }


    @Test(priority = 403, groups = {"P4", "DEFENDANT TIMELINE CHINESE","func_sorting"},description = "Validate Chinese Only campaign overview sorting for hight charts bar")
    public void verifyChineseOnlySortingForHighChartsBar() throws Exception {
        assertColumnSort("non-date", "DESC", campaignDetailPage.getxAxis());
    }

    //Todo Need to review this script-Always Pass
    @Test(priority = 404, groups = {"P3", "DEFENDANT TIMELINE CHINESE"}, description = "Validate Chinese Only defendant text display")
    public void checkChineseOnlyDefendantText() {
        String defendant = campaignDetailPage.defendantsInTimelineChart.getText();
        if (campaignDetailPage.defendantsInTimelineChart.getAttribute("title").length() > 20)
            assertTrue(defendant.matches(".*" + "..."), "Defendant name is not truncated");
    }

    @Test(priority = 405, groups = {"P3", "DEFENDANT TIMELINE CHINESE"},description = "Verify campaign overview section defendant filter functionality")
    public void checkChineseOnlyDefendantFilterFunctionality() throws Exception {

        int defendantCountBeforeFilter = campaignDetailPage.overviewCompany.getAllData().size();
        String companyName = campaignDetailPage.overviewCompany.getText();
        campaignDetailPage.applyDefendantFilter(companyName);
        assertEquals(campaignDetailPage.overviewCompany.getText(), companyName);
        int defendentCountAfterFilter = campaignDetailPage.overviewCompany.getAllData().size();
        Assert.assertEquals(defendentCountAfterFilter , 1 , "The Defendant displaying in defendant timeline Count is not matching after applied the defendant filter");
        campaignDetailPage.applyDefendantFilter("All");
        int defendentCountClearFilter = campaignDetailPage.overviewCompany.getAllData().size();
        Assert.assertEquals(defendantCountBeforeFilter , defendentCountClearFilter , "The Defendant displaying in defendant timeline Count is not matching after cleared the defendant filter");
    }



    //No petition section applicable for Chinese only campaign
//    @Test(description = "Verify petition section without data")
//    public void verifyChineseOnlyPetitionSectionWithNoData() throws Exception {
//        this.urlData.put("ID", data.getChineseOnlyCampId(true));
//        to(campaignDetailPage, urlData);
//        assertEquals(campaignDetailPage.campaignPetitionsWithoutData.getText(), "No related petitions found");
//        campaignDetailPage.loadPetitionerWithAccordionExpand();
//        assertEquals(campaignDetailPage.campaignPetitionersWithoutData.getText(), "No related petitioners found");
//        campaignDetailPage.loadPatentsWithAccordionExpand();
//        assertEquals(campaignDetailPage.campaignPatentsWithoutData.getText(), "No related patents found");
//
//    }

    // TODO input from DB and with no data
    @Test(priority = 501,description = "Verify Chinese Only plaintiff section", groups = "P2")
    public void verifyChineseOnlyPlaintiffSection() throws Exception {
        this.urlData.put("ID", "4021883");
        to(campaignDetailPage, urlData);
        assertEquals(campaignDetailPage.plaintiffCounselInfo.isPresent(), false);
        campaignDetailPage.plaintiffSectionShowAll.click();
        assertEquals(campaignDetailPage.plaintiffSectionShowAll.getText(), "Hide All Counsel");
        assertEquals(campaignDetailPage.plaintiffCounselInfo.isPresent(), true);
        campaignDetailPage.plaintiffSectionShowAll.click();
        assertEquals(campaignDetailPage.plaintiffCounselInfo.isPresent(), false);
        campaignDetailPage.plaintiffLinksCounselInfo.click();
        assertEquals(campaignDetailPage.plaintiffCounselInfo.isPresent(), true);
    }

    @Test(priority = 502,description = "Verify Chinese Only plaintiff section links", groups = "P3")
    public void verifyChineseOnlyPlaintiffLinks() throws Exception {
        this.urlData.put("ID", "4017108");
        to(campaignDetailPage, urlData);
        String plaintiff = campaignDetailPage.plaintiffLinks.getText();
        withNewWindow(campaignDetailPage.plaintiffLinks, () -> {
            at(entityDetailPage);
            String entityName = entityDetailPage.detailPageTitle.getText();
            Assert.assertEquals(plaintiff, entityName);
        });
        if (campaignDetailPage.plaintiffLinksSub.isPresent()) {
            String plaintiffsub = campaignDetailPage.plaintiffLinksSub.getText();
            withNewWindow(campaignDetailPage.plaintiffLinksSub, () -> {
                at(entityDetailPage);
                String entityName = entityDetailPage.detailPageTitle.getText();
                Assert.assertEquals(plaintiffsub, entityName);
            });
        }
    }

    //Todo Need to review this script
//    @Test(priority = 303, description = "Verify patent tile", groups = "patents")
//    public void verifyPatentTitle() throws Exception {
//        List<String> campYear = campaignDetailPage.timeLineYear.getAllData();
//        campaignDetailPage.patent_table.getColumnLinkElem("Title").click();
//        at(patentDetailsPage);
//        List<String> patYear = patentDetailsPage.timeLineYear.getAllData();
//        assertEquals(campYear, patYear);
//    }


    //Todo - Low priority Test Case
    //CAMPAIN TIMELINE VIEW FILTERS Todo - Test data should be change with more unique start date
/*    @Test(description="Verify defendant name search in Campaign TimeLine View | RPX-12729")
    public void checkChineseOnlyDefendantOrderAtTimeLineView() throws Exception {
        this.urlData.put("ID", "4001017");
        to(campaignDetailPage, urlData);
        campaignDetailPage.selectDefendantTab();
        List<String> defendantData=campaignDetailPage.defendantParent.getAllData();
        Collections.reverse(defendantData);
        campaignDetailPage.selectDefendantTimelineTab();
        campaignDetailPage.defendantsInTimelineChart.waitUntilVisible();
        assertEquals(campaignDetailPage.defendantsInTimelineChart.getAllData(),defendantData);
    }*/

    @Test(priority = 601,dataProvider="defendantNames", groups = "P2", description="Verify defendant name search in Campaign TimeLine View")
    public void checkChineseDefendantSearchAtDefendantTimeLineView(String campid ,String defendantName) throws Exception {
        to(campaignDetailPage, campid);
        campaignDetailPage.closeTimelinePopupModal();
        campaignDetailPage.clearFilters();
        campaignDetailPage.applyDefendantFilter(defendantName);
        campaignDetailPage.defendantsInTimelineChart.waitUntilVisible();
        assertEquals(campaignDetailPage.defendantsInTimelineChart.getText(),defendantName);
    }

    @DataProvider(name="defendantNames")
    public Object[][] getDefendantNames() {
        return new Object[][] {//Chinese Campaign Defendant CN involved
                {"49645" , "Zhongshan Tiantong Printer Consumables Co., Ltd."}, //Chinese Campaign Defendant involved in both LIT,PTAB and CAFC
                {"4014543" , "Junjun Zhou"},//Chinese Only Campaign Defendant
                {"814" , "Funai Electric Co., Ltd."},//Chinese Campaign Defendant ITC involved

        };
    }

    @Test(priority = 701,dataProvider="verifymodelContent", groups = "P2", description="Counsel|Verify Defendant Popup Case View counsel text for PTAB/ITC/DC cases|RPX-12334")
    public void checkChineseCampaignCounselLabelForCases(String campid ,String defendantName , String campaignType) {
        to(campaignDetailPage, campid);
        campaignDetailPage.closeTimelinePopupModal();
        campaignDetailPage.clearFilters();
        campaignDetailPage.applyDefendantFilter(defendantName);
        campaignDetailPage.timeLinechartBar.waitUntilVisible();
        campaignDetailPage.timeLinechartBar.click();
        campaignDetailPage.defendant_timeLine_Popup_CaseDetails.waitUntilVisible();
        if(campaignType=="chineseDefendant") {
            assertTrue(campaignDetailPage.counsel_LabelForCN.isDisplayed(), "Accused Products label should not be available for Chinese Cases in Defendant Pop up"); //CN as Defendant
        }else {assertTrue(campaignDetailPage.counsel_LabelForDC.isDisplayed(),"Lead Counsel label is not available for DC Cases in Defendant Pop up");
            assertTrue(campaignDetailPage.counsel_LabelForPTAB.isDisplayed(),"Counsel label is not available for PTAB Cases in Defendant Pop up");
            assertTrue(campaignDetailPage.counsel_LabelForITC.isDisplayed(),"General Counsel label is not available for ITC Cases in Defendant Pop up");}
        campaignDetailPage.closeTimelinePopupModal();
    }


    @DataProvider(name="verifymodelContent")
    public Object[][] verifyModelContent() {
        return new Object[][] {{"4000994" , "Ziben Cai" , "chineseDefendant"},//Chinese Defendant in Chinese Only Campaign
                {"421" , "Wangs Alliance Corporation" , "non-chineseDefendant"}, //non-Chinese Defendant in Chinese Campaign
                {"421" , "Central People's Government of The People's Republic of China" , "chineseDefendant"} //Chinese Defendant in Chinese Campaign
        };
    }

    @Test(priority = 801,dataProvider="chineseCampaignjudges",  groups = "P2", description="Verify Judge filter in Campaign TimeLine View for Chinese Campaign")
    public void checkChineseCampaignJudgeFilterAtTimeLineView(String campid,String judge,String expCaseNumbers[]) throws Exception {
        campaignDetailPage.closeTimelinePopupModal();
        to(campaignDetailPage, campid);
        campaignDetailPage.closeTimelinePopupModal();
        campaignDetailPage.clearFilters();
        campaignDetailPage.applyJudgeOrCourtFilter(judge);
        campaignDetailPage.timeLinechartBar.waitUntilVisible();
        campaignDetailPage.timeLinechartBar.click();
        campaignDetailPage.defendantTimelineModal.waitUntilVisible();
        for(String caseNumber:expCaseNumbers) {
            assertTrue(campaignDetailPage.getCaseDataOfDefendantTimeLineModal().contains(caseNumber),"Expected Case Number "+caseNumber+" is not available in defendant timeline popup for Judge Filter:"+judge);
        }
        campaignDetailPage.closeTimelinePopupModal();
    }

    @DataProvider(name="chineseCampaignjudges")
    public Object[][] getJudges() {
        return new Object[][] {
                //{"4067041" , "Hongbo Tang",new String[]{"CASE NUMBER: CN-20-4067041" ,"JUDGE: Hongbo Tang"}},//Jude involved in CN(Chinese Only Campaign)
                //{"4286"  , "Gregory M. Sleet",new String[]{"CASE NUMBER: 1:09-cv-00272","JUDGE: Gregory M. Sleet"}}, //Judge involved in Lit(Chinese Campaign)
                {"814"  , "William H. Alsup",new String[]{"CASE NUMBER: 3:11-cv-02439","JUDGE: William H. Alsup"}} //Judge involved in ITC(Chinese Campaign)
                //Todo Judge involved in PTAB(Chinese Campaign) - Include once ptab judge page introduced
        };
    }

    @Test(priority = 802,dataProvider="courts", groups = "P2", description="Verify Court filter in Campaign TimeLine View")
    public void checkCourtFilterAtTimeLineView(String campid,String court,String expCaseNumbers[]) throws Exception {
        to(campaignDetailPage, campid);
        campaignDetailPage.closeTimelinePopupModal();
        campaignDetailPage.clearFilters();
        //campaignDetailPage.applyDefendantStatusFilter("Active"); //Commented since chinese only does not have Active cases
        campaignDetailPage.applyJudgeOrCourtFilter(court);
        campaignDetailPage.timeLinechartBar.waitUntilVisible();
        campaignDetailPage.timeLinechartBar.click();
        campaignDetailPage.defendantTimelineModal.waitUntilVisible();
        for(String caseNumber:expCaseNumbers) {
            assertTrue(campaignDetailPage.getCaseDataOfDefendantTimeLineModal().contains(caseNumber),"Expected Case Number "+caseNumber+" is not available in defendant timeline popup for Judge Filter:"+court);
        }
    }

    @DataProvider(name="courts")
    public Object[][] getCourts() {
        return new Object[][] {
                {"4067041","Shanghai Intellectual Property Court",new String[]{"COURT: Shanghai Intellectual Property Court","CASE NUMBER: CN-20-4070507"}}, //Chinese Only Campaign - China court
                {"814","ITC",new String[]{"INVESTIGATION NUMBER: 337-TA-687"}} //Chinese Campaign - ITC cases involved

        };
    }

//    @Test(dataProvider="status",description="Verify defendant Status filter in TimeLine View")
//    public void checkDefendantStatusFilterInTimeLine(String status) throws Exception{
//        to(campaignDetailPage,"6029" /*"13972"*/);
//        campaignDetailPage.closeTimelinePopupModal();
//        campaignDetailPage.clearFilters();
//        int terminatedDefendants=Integer.valueOf(campaignDetailPage.overviewPanel.getData("Defendants Terminated Count"));
//        int totalDefendants=Integer.valueOf(campaignDetailPage.overviewPanel.getData("Defendants Count"));
//        int activeDefendants=totalDefendants-terminatedDefendants;
//        campaignDetailPage.applyDefendantStatusFilter(status);
//        campaignDetailPage.timeLinechartBar.waitUntilVisible();
//        int available_Timelines_Count=campaignDetailPage.timeLinechartBar.count();
//        verifyStatus(status,totalDefendants,activeDefendants,terminatedDefendants,available_Timelines_Count);
//    }
//
//    @DataProvider(name="status")
//    public Object[][] getStatus() {
//        return new Object[][] {{"Active"},{"Inactive"},{"All"}};
//    }


    //todo checkDefendantStatusFilterInTimeLine - pending

    @Test(priority = 803,dataProvider="eventsFilter", groups = "P2", description="Verify event filter in TimeLine View")
    public void checkChineseCampaignEventFilterInTimeLine(String campid,String eventName,List activemarker,List inactiveMarker,List defendantName) throws Exception{
        to(campaignDetailPage,campid);
        campaignDetailPage.clearFilters();
        campaignDetailPage.applyDefendantFilter(defendantName.get(0).toString());
        campaignDetailPage.applyDefendantEventFilter(eventName);
        Assert.assertEquals(campaignDetailPage.defendant_timeline_active_top_marker.getAllData(),activemarker);
        Assert.assertEquals(campaignDetailPage.defendant_timeline_inactive_top_marker.getAllData(),inactiveMarker);
        assertEquals(campaignDetailPage.timeLinechartBar.count(),1);
        Assert.assertEquals(campaignDetailPage.defendantsInTimelineChart.getAllData(),defendantName);
    }

    @DataProvider(name="eventsFilter")
    public Object[][] eventsFilterTimeLine() {
        return new Object[][] {
              {"4020538","Chinese Judgment",Arrays.asList(new String[]{"J-CN"}),Arrays.asList(new String[0]),Arrays.asList(new String[]{"Central People's Government of The People's Republic of China"})}, //Chinese Only Campaign - China court - Chinese Judgement
                {"421","Chinese Judgment",Arrays.asList(new String[]{"J-CN"}) , Arrays.asList(new String[0]),Arrays.asList(new String[]{"Central People's Government of The People's Republic of China"})}, //Chinese Campaign - China court - Chinese Judgement
              {"4300","Summary Judgment",Arrays.asList(new String[]{"SJ","SJ"}),Arrays.asList(new String[]{"C","D","D","D","J"}),Arrays.asList(new String[]{"CCL Industries Incorporated"})}, //Chinese Campaign - China court - Chinese Judgement
        };
    }

    @Test(priority = 804,dataProvider="markersTimeLine", groups = "P3",description="Verify Markers Select and Unselect in Campaign TimeLine")
    public void verifyChineseCampaignMarkerSelectNUnSelectInTimeLine(String campid,String markerFullName,String markerName,List inactiveMarker,List defendantName) throws Exception{
        to(campaignDetailPage,campid);
        campaignDetailPage.clearFilters();
        List<String> defaultMarkers = campaignDetailPage.defendant_timeline_active_top_marker.getAllData();
        int defaultBarCount = campaignDetailPage.timeLinechartBar.count();
        ArrayList<String> defaultDefendants = campaignDetailPage.defendants_timeline.getAllData();
        campaignDetailPage.defendant_timeline_top_marker.of(markerFullName).click();
        Assert.assertEquals(campaignDetailPage.defendant_timeline_active_top_marker.getAllData(), Arrays.asList(new String[]{markerName}));
        Assert.assertEquals(campaignDetailPage.defendant_timeline_inactive_top_marker.getAllData(),inactiveMarker);
        assertEquals(campaignDetailPage.timeLinechartBar.count(),1);
        Assert.assertEquals(campaignDetailPage.defendants_timeline.getAllData(),defendantName);

        campaignDetailPage.defendant_timeline_top_marker.of(markerFullName).click();
        assertEquals(campaignDetailPage.defendant_timeline_active_top_marker.getAllData(),defaultMarkers);
        assertEquals(campaignDetailPage.defendant_timeline_inactive_top_marker.count(),0);
        assertEquals(campaignDetailPage.timeLinechartBar.count(),defaultBarCount);
        assertEquals(campaignDetailPage.defendants_timeline.getAllData(),defaultDefendants);
    }
    @DataProvider(name="markersTimeLine")
    public Object[][] markersTimeLine() {
        return new Object[][] {
                {"4286","Chinese Judgment","J-CN",Arrays.asList(new String[0]),Arrays.asList(new String[]{"Central People's Government of The People's Republic of China"})}, //Chinese Campaign //J-CN
                {"4016826","Chinese Judgment","J-CN",Arrays.asList(new String[0]),Arrays.asList(new String[]{"Hongwei Li"})}, //Chinese Only Campaign //J-CN
        };
    }

    @Test(priority = 805,description="Verify Chinese Only Defendant timeline Marker tooltip verification", groups = "P3")
    public void verifyChineseOnlyTopMarkerTooltip() throws Exception{
        to(campaignDetailPage,"4023963");
        campaignDetailPage.clearFilters();
        campaignDetailPage.chineseJudgmentMarker.moveTo();
        campaignDetailPage.chineseJudgementTooltip.waitUntilVisible();
        assertEquals(campaignDetailPage.markerToolTipHeader.getText(),"Chinese Judgment");
        String toolTipDetail = campaignDetailPage.markerToolTipDetail.getText();
        Assert.assertTrue(toolTipDetail.contains("04/30/2014"),"The tool tip does not contain the correct date");
        Assert.assertTrue(toolTipDetail.contains("CN-13-RE203453-599860"),"The tool tip does not contain the correct case number");
        System.out.println(campaignDetailPage.markerToolTipCaseLink.getPartialLink());
        Assert.assertTrue(campaignDetailPage.markerToolTipCaseLink.getPartialLink().contains("litigation/china/4019852"));
        //assertEquals(campaignDetailPage.markerToolTipDocumentLink.getPartialLink(),"litigation_documents/12376984");  //todo need to validate litigation documents once introduced
    }

    @Test(priority = 806,dataProvider="chinese_judgement", groups = "P2", description="Verify Chinese Judgement event filter on campaign timeline")
    public void checkChineseJudgementEventFilterInTimeLine(String eventType,String marker) throws Exception{
        to(campaignDetailPage,"4015000");//4015591
        campaignDetailPage.clearFilters();
        campaignDetailPage.applyDefendantFilter("Foshan South Haitao Yu Aluminum Products Co. Ltd");
        campaignDetailPage.applyDefendantEventFilter(eventType);
        Set<String> hashsetList = new HashSet<String>(campaignDetailPage.defendant_timeline_active_top_marker.getAllData());
        Set<String> expSet=new HashSet<String>(new ArrayList<String>(Arrays.asList(marker)));
        com.rpxcorp.testcore.Assert.isEquals(hashsetList,expSet);
        checkMarkerToolTipDataForEventType(eventType);
    }

    @Test(priority = 807,dataProvider="chinese_judgement", groups = "P3", description="RPX-14050-Hide PDF document icon on campaign timeline tool tip if the corresponding document is not available")
    public void checkChineseOnlyPDFDocNotAvailableInTimelineMarkerTooltip(String eventType,String marker) throws Exception{
        to(campaignDetailPage,"4020916");//4015591
        campaignDetailPage.clearFilters();
        campaignDetailPage.moveToMarker(eventType);
        Assert.assertFalse(campaignDetailPage.markerToolTipDocumentLink.isDisplayed() , "PDF document icon is visible though the corresponding document is not available");
    }

    @DataProvider(name="chinese_judgement")
    public Object[][] getChinese_Judgement() {
        return new Object[][] {{"Chinese Judgment","J-CN"}};
    }
    private void checkMarkerToolTipDataForEventType(String eventType) throws Exception {
        SoftAssert softAssert = new SoftAssert();
        String eventName,caseKey;
        campaignDetailPage.moveToMarker(eventType);
        campaignDetailPage.markerToolTipHeader.waitUntilVisible();
        eventName=campaignDetailPage.markerToolTipHeader.getText();
        caseKey=campaignDetailPage.markerToolTipCaseLink.getText();
        //Check event name in tooltip
        Assert.assertEquals(eventName,eventType);

        //Check document load
        withNewWindow(campaignDetailPage.markerToolTipDocumentLink,() -> {
            softAssert.assertTrue(campaignDetailPage.getCurrentUrl().contains("lit_ch/rpx-intl-lits/CN/") , "Document URL is not pointed to lit_ch/rpx-intl-lits/CN/");
            softAssert.assertTrue(getDriver().getPageSource().contains("application/pdf"), "MIME media type pdf is not present");
        });
        softAssert.assertAll();
        campaignDetailPage.moveToMarker(eventType);
        campaignDetailPage.markerToolTipHeader.waitUntilVisible();
        //Check detail page redirection
        withNewWindow(campaignDetailPage.markerToolTipCaseLink,() -> {
            at(chineseLitigationDetailPage);
            Assert.assertEquals(chineseLitigationDetailPage.headerDetails.getData("case_no"),caseKey,"Redirection is not expected for casekey:"+caseKey+" as caseNumber:"+chineseLitigationDetailPage.headerDetails.getData("case_no")+" is not expected in detail page");
        });
    }
   /* private void moveToMarker(String eventType) {
        switch(eventType){
            case "Chinese Judgment":
                campaignDetailPage.chineseJudgmentMarker.moveTo(1,1);
                break;
        }
    }*/

    private void verifyStatus(String status, int totalDefendants,
                              int activeDefendants, int terminatedDefendants, int available_Timelines_Count) throws Exception {
        switch(status) {
            case "Active":
                assertEquals(campaignDetailPage.timeLinechartBar.getAttribute("fill"), "green",
                        "Active cases are not displayed in green");
                assertEquals(available_Timelines_Count,activeDefendants,"Expected active defendants as per Campaign Overview Metrics:"+activeDefendants+", Actual available defendants in Timeline when we set defendants status as"+status+" :"+campaignDetailPage.defendantsInTimelineChart.count());
                break;
            case "Inactive":
                assertEquals(campaignDetailPage.timeLinechartBar.getAttribute("fill"), "grey",
                        "Inactive cases are not displayed in grey");
                assertEquals(available_Timelines_Count,terminatedDefendants,"Expected Inactive defendants as per Campaign Overview Metrics:"+terminatedDefendants+", Actual available defendants in Timeline when we set defendants status as"+status+" :"+campaignDetailPage.defendantsInTimelineChart.count());
                break;
            case "All":
                assertEquals(available_Timelines_Count,totalDefendants,"Expected all defendants as per Campaign Overview Metrics:"+totalDefendants+", Actual available defendants in Timeline when we set defendants status as"+status+" :"+campaignDetailPage.defendantsInTimelineChart.count());
                break;
        }

    }
}
