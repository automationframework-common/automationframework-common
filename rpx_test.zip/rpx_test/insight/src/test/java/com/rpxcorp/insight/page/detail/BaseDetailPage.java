package com.rpxcorp.insight.page.detail;

import com.rpxcorp.insight.module.Highchart;
import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BaseDetailPage extends BasePage {


	@Override
	public boolean at() {
		rpx_Logo.waitUntilVisible();
		waitForPageLoad();
		return detailContent.waitUntilVisible();
	}
	public final Element search_textarea = $("#searchq_revised");
	public final Element detailPageTitle = $(".presenter-name-cls.detail-page-title:visible");//.detail-page-title span:nth-of-type(1)
	public final Element viewInAnalyst=$("li.inner-button:has(li:contains('Analyze')) a.button.fill");
	public final Element personalizedViewTab = $(".tabs.dashboard-header a:contains('Personalized View')");
	public final Element loginWelcomeMsg = $("a[class*='edit-dboard-btn']:visible"); //.dashboard .salutation:contains('Welcome')
	public final Element excelDetailsPageFieldSelection = $("#data_download_litigation_fields>div>span.plus-icon");
	public final Element excelSearchPageFieldSelection = $("#data_download_entity_fields>div");
	public final Element caseNumber = $(".subtitle li:first-child");
	public final Element caseNumberLit = $(".header-info.details>li:first-child");

	public String getCaseNumber() {
		String caseNo = null;
		if(caseNumber.isDisplayed()) {			
			caseNo = caseNumber.getText();
		} else if (caseNumberLit.isDisplayed()) {
			caseNo = caseNumberLit.getText();
		}
		return caseNo;
	}

	public final StaticContent header_info =$( ".header-info.details.subtitle",(Configure<StaticContent>) dataForm ->{
		dataForm.content("docket_number", "li:nth-child(1)");
		dataForm.content("filed_date", "li:contains(Filed)");
		dataForm.content("closed_date", "li:contains(Closed)");
		dataForm.content("latest_docket_entry", "li:contains(Latest Docket)");
	});


	public final Element news_title_Lnk=$(".orbit-container .news_title>a");
	public final Element newsUpgradeBtn = $(".orbit-slides-container div.text-center .view-more-button:contains('View full article')");
	public final Element fullnews_body = $("div.news_body");
	public final Element noFullnews_body = $("ul.orbit-slides-container li div.text-center");

	public final Element login_LNK=$(By.xpath("//*[@id='primary-nav']//a[text()='Login']"));
	public final Element detailContent = $("#content .detail");
	public final Element createAlertBtn = $("[data-track-action='create_alert']:visible");
	public final Element modifyAlertBtn = $("[data-track-action='view_alert'] li.alert-style:contains('Modify Alert'):visible");
	public final Element popUpMessage = $("#alert-modal p");
	public final Element popUpMessage_OkButtom = $("#alert-modal button");
	public final Element alert_dialog=$(".reveal-modal.xlarge.alerts_form.open form.alert_subscription");
	public final Element alert_div=$("div.reveal-modal-bg[style='display: block;']");
	public final Element close_alert_dialog=$(".reveal-modal.xlarge.alerts_form.open a.close-reveal-modal");
	public final Element login_Link=$("#primary-header #public_login_btn");
	public final Element flash_alert_div=$("div#flash_name");


    public final Element loginForm=$(".login-modal.open");
    public final Element loginForm_detailSection=$("#login-modal .detail-section:contains(' Experience the full potential of RPX Insight by subscribing today'):contains(Don't have an account?) a.orange-button:contains('RPX INSIGHT PLANS')");
    public final Element loginForm_close=$(".login-modal.open a.close-reveal-modal");

    public void closeLoginDialog() {
    	if(loginForm_detailSection.isDisplayed()) {
    		loginForm_close.click();    		
    	}
    }

	public final Element save_btn=$(By.xpath("//li//span[text()='Save']"));		
	public final Element un_save_btn=$(By.xpath("//li/a[contains(.,'Saved')]"));	

	public String getPopupMessage(){
		popUpMessage.waitUntilVisible();
		String message= popUpMessage.getText();
		popUpMessage_OkButtom.click();
		popUpMessage.waitUntilInvisible();
		return message;
	}

	public void open_AlertDialog() {
		if (!alert_div.isDisplayed()) {
			if (createAlertBtn.isDisplayed()) {
				createAlertBtn.click();
				waitForLoading();
				alert_dialog.waitUntilVisible();
			}
		}
	}
	
	public final Element lcaRequestResonseModal = $("#lca_request_response_modal");
	public final Element msgInLcaRequestResponseModal = $("#lca_request_response_modal div");
	public void closeLcaRequestResponseModal() {
		if(lcaRequestResonseModal.isDisplayed()) {
			$("#lca_request_response_modal a.close-reveal-modal").click();
			lcaRequestResonseModal.waitUntilInvisible();
		}
	}

	public final Element requestResponseModal = $("#request_response_modal");
	public final Element msgInRequestResponseModal = $("#request_response_modal div");
	public void closeRequestResponseModal() {
		if(requestResponseModal.isDisplayed()) {
			$("#request_response_modal a").click();
			requestResponseModal.waitUntilInvisible();
		}
	}	
	
	//ALERT BUTTON
	public void closeAlertDialog() {
		if(alert_dialog.isDisplayed())
		{	
			close_alert_dialog.waitUntilVisible();
			close_alert_dialog.click();
			alert_dialog.waitUntilInvisible();
		}
	}
	public void accessModifyAlert() {
		closeAlertDialog();
		modifyAlertBtn.waitUntilClickable();
		modifyAlertBtn.click();
		ajax_loading.waitUntilInvisible();
		alert_dialog.waitUntilVisible();
	}
	public void accessCreateAlert() {
		createAlertBtn.click();		
		alert_dialog.waitUntilVisible();
	}

	//DATA BUTTON
	public final Element searchDataButton = $(".action-button a.data_download_btn .download-icon+span:contains('Download')");
	public final Element dataButton = $(".right-resource-content div.columns:contains('Litigation Data')+div.columns:last-child() img.download-icon");
	public final Element disabled_DataBtn=$(".disabled.data_download_btn .download-icon+span");

	public final Element alertBtnPromoMsg = $(".qtip-content div:visible:contains('Alerts are not available for your current subscription level') a:contains('Upgrade')");
	public final Element alertBtnSignOnMsg = $(".qtip-content div:visible:contains('Please'):contains('to use this feature.') a:contains('sign in'):visible()");
	public void clickAndHoldDataDownloadBtn() {
		if(dataButton.isDisplayed()) {
			dataButton.moveTo();
			toolTip.waitUntilVisible();
		}		
	}

	public void clickAndHoldSearchDataDownloadBtn() {
		if(searchDataButton.isDisplayed()) {
			searchDataButton.moveTo();
			toolTip.waitUntilVisible();
		}
	}
	public final Element overviewAppealNoticeVisible = $("div.view-complaint-shape a[href*='litigation_documents']:visible");
	public final Element overviewPDFDownloadVisible = $("div.view-complaint-container>a[href$='pdf']:visible");
	public final Element overviewPDFDownload = $("div.view-complaint-shape>div.view-complaint-container>a");
	//public final Element overviewDownloadTooltip=$("div.data-btn:visible");
	public void clickAndHoldOverviewPDFDownload() throws Exception{
		if(overviewPDFDownload.isDisplayed()) {
			overviewPDFDownload.moveTo();
			Thread.sleep(2000);
		}
	}
	public final Element dataBtnTooltip=$("div.static_tooltip div.qtip-content div.data-btn");
	public final Element dataBtnComingSoonMsg = $(By.xpath("//div[@class='qtip-content']//div[contains(text(),'Data downloads coming soon')]"));
	public final Element dataBtnPromoMsg = $("div.qtip-content div.data-btn:contains('Data downloads are not available') a");
	public final Element dataBtnSignInMsg =$(".qtip-content:contains('Please'):contains('to use this feature.') a:contains('sign in'):visible()");
	public final Element dataBtnCustomiseMsg = $(".qtip-content div.data-btn:contains('Customize report and download in Excel')");
	public final Element Masked_campaign =$(".group_stats a.plain-title:contains('ITC CAMPAIGN (X,XXX,XXX)')");

	//Detail Page
	public void clickOnDataDownloadButton() {
		if(!disabled_DataBtn.isDisplayed()) {
		dataButton.click();
		waitForPageLoad();
		dataDownloadModal.waitUntilVisible();
		}
	}

	//Search Page
	public void clickOnDataDownloadButtonInSearchPage() {
		if(!disabled_DataBtn.isDisplayed()) {
			searchDataButton.click();
			waitForPageLoad();
			dataDownloadModal.waitUntilVisible();
		}
	}

	public final Element dataDownloadModal = $("#data_download_modal.open");
	public final Element dataDownloadModalContent = $("#data_download_modal .modal-content");
	public final Element dataDownloadModalClose = $("#data_download_modal .close-reveal-modal");
	public final Element facet_Undefined = $("a.filter-label>span:contains('Undefined')");//Need to delete Once facet comp. created

	public final Element selectall_Download=$("dd[id^=data_download_]>span:contains('Select all'):eq(0)");
	public void clickSelectAllLink(){
		selectall_Download.waitUntilPresent();
		selectall_Download.click();

	}
	public void openDataDownloadModal() {
		if(!dataDownloadModalContent.isDisplayed()) {
			dataButton.click();
			waitForLoading();
			dataDownloadModalContent.waitUntilVisible();
		}
	}
	public void openSearchDataDownloadModal() {
		if(!dataDownloadModalContent.isDisplayed()) {
			searchDataButton.click();
			waitForLoading();
			dataDownloadModalContent.waitUntilVisible();
		}
	}
	public final Element entitySearchCount = $("h2.result-title>span:first-child");
	public final Element activeDataAccordians = $("#data_download_modal dd.accordion-navigation.active>a");
	public final Element inactiveDataAccordians = $("#data_download_modal dd.accordion-navigation:not([class*='active'])>a");
	public final Element selectedFieldsInDataDownloadModal = $("#selected_fields_container div"); //div#selected_fields_container div.content.active > div"); //#selected_fields_container div
	public final Element clearAllInDataDownloadModal = $("#data_download_modal .modal-content a[class='align-left clear_all']");
	public final Element allDataAccordians=$("#data_download_modal dd a");
	public final Element dataReportAccordian = $(By.xpath(""));
	public void expandAccordianInDataBuilder(String fieldName) {
		if(!$("dl#available_fields_container dd.accordion-navigation:has(a:contains('" + fieldName + "'))").getAttribute("class").contains("active")) {
			$("dl#available_fields_container a:contains('" + fieldName + "')").click();
		}
	}

	public void selectFromAccordianInDataBuilder(String fieldName, String option) {
		expandAccordianInDataBuilder(fieldName);
		Element optionWithinFeild = $("div[data-group='" + fieldName + "'] div.field_items:contains('" + option + "') span");
		optionWithinFeild.click();
		optionWithinFeild.waitUntilInvisible();
	}



	public void selectAllOptionsFromAccordianInBuilder(String fieldName) {
		expandAccordianInDataBuilder(fieldName);
        Element selectAllOption = $("#available_fields_container dd.accordion-navigation:contains('" + fieldName + "')>span.select-group");
		selectAllOption.click();
		$("#available_fields_container dd.accordion-navigation:contains('" + fieldName + "') .empty_placeholder:contains('All fields are selected')").waitUntilPresent();
	}

	public void deselectFromSelectedFieldsInDataBuilder(String option) {
		Element selectedOption = $("div#selected_fields_container div.field_items:contains('"+ option +"')");//div[@id='selected_fields_container']/div[@class='field_items'][contains(text(),'" + option + "')]/i
		// 		selectedOption.waitUntilVisible();
		selectedOption.$(">i").click();
		selectedOption.waitUntilInvisible();
	}

	public List<String> getAllOptionsFromAccordianInDataBuilder(String fieldName) {
		List<String> refinedOptions = new ArrayList<>();
		expandAccordianInDataBuilder(fieldName);

		//List<String> options = $(By.xpath("//a[text()='" + fieldName + "']/../..//div[@class='field_items']")).getAllData();
        List<String> options = $("dd.accordion-navigation:contains('" + fieldName + "') div.field_items").getAllData();


		for(String option : options) {
			refinedOptions.add(option.replace("+", "").trim());
		}
		return refinedOptions;
	}

	public List<String> getAllOptionsFromSelectedFieldsInDataBuilder() {    	
		return selectedFieldsInDataDownloadModal.getAllData();
	}

	public final Element downloadBtnInDownloadModal = $("#data_download_modal .data-download");
	public final Element emailBtnInDownloadModal = $("#data_download_modal .data-email");

	public void closeDataDownloadModal() {
		if(dataDownloadModalContent.isDisplayed()) {    		
			dataDownloadModalClose.click();
			dataDownloadModalContent.waitUntilInvisible();
		}
	}

	public void emailFromDataModal() {
		emailBtnInDownloadModal.click();
		dataDownloadModalContent.waitUntilInvisible();
		alertMessage.waitUntilVisible();
	}
	public final Element titleInDownloadModal = $("#data_download_modal div.follow-title");

	//LCA BUTTON

	public final Element lcaButton = $(".right-resource-content>div.resource-content div.columns:contains('Litigation Campaign Assessment')+div.columns:last-child() img.download-icon");
	public final Element lcaBtnToolTip = $("div.static_tooltip .qtip-content");//.qtip-content div:visible:contains('Litigation Campaign')  //.qtip-content:has(a[data-lca-request-type='Campaign']) // div.static_tooltip .qtip-content:visible

	public final Element lcaBtnPromoMsg = $(".qtip-content div:visible:contains('Litigation Campaign Assessments are not available for your current subscription level') a:contains('Upgrade')");//".qtip-content div:visible:contains('Litigation Campaign Assessments are not available') a:contains('Upgrade')
	public final Element noLcaMsg = $(".qtip-content div:visible:contains('Litigation Campaign Assessment Not Available') a:contains('Request')"); //.qtip-content div:visible:contains('Litigation Campaign Assessment Not Available') a:contains('Request')
	public final Element lcaBtnSignOnMsg = $(".qtip-content>div>a:contains('sign in')");
	public void clickAndHoldLcaButton() {
		if(lcaButton.isDisplayed()) {
			lcaButton.moveTo();
			lcaBtnToolTip.waitUntilVisible();
		}
	}

	public void clickAndHoldLcaButtonMoreLCAButton() {
		if(lcaButton.isDisplayed()) {
			lcaButton.moveTo();
			moreLinkInLcaToolTip.waitUntilVisible();
		}
	}
	public final Element noLcaMsgInToolTip = $(".qtip-content span:last-child():contains('Litigation Campaign Assessment Not Available'):visible");
	public final Element requestLinkInLcaToolTip = $(".qtip-content .lca-btn a");
	public void requestLca() {
		requestLinkInLcaToolTip.waitUntilVisible();
		requestLinkInLcaToolTip.click();
		waitForPageLoad();		
	}
	public final Element msgInToolTipAfterRequest = $("#lca-update-request-link-single");
	public final Element contactUsInLcaToolTip = $("#lca-update-request-link-single a");
	public final Element reportNameInLcaToolTip = $("#qtip-0-content span:nth-of-type(1)");
	public final Element updateDateInLcaToolTip = $(By.xpath("//div[@id='qtip-0-content']//span[contains(text(), 'Last Updated')]"));
	public final Element moreLinkInLcaToolTip = $(".qtip-content div.lca-btn a:contains('More >>>')");
	
	public void openLCAModal() {
		if(!lcaReportModal.isDisplayed()) {
			clickAndHoldLcaButtonMoreLCAButton();
			moreLinkInLcaToolTip.click();
			lcaReportModal.waitUntilVisible();
		}
	}
	public final Element lcaReportModal = $("#lca_report_modal.open");
	public final Element lcaReportModalTitle = $("#lca_report_modal .modal-title");	
	
	public void requestAnUpdateFor(String documentName) {
		$("#lca_report_modal tr:contains('" + documentName + "') .lca_update_request a").click();
		waitForLoading();		
	}
	
	public Element downloadBtnLCAFor(String documentName) {
		return $("#lca_report_modal tr:contains('" + documentName + "') a.button.icon-button");				
	}
	
	public void requestLcaFor(String docName) {
		$("#lca_report_modal tr:contains('" + docName + "') .lca_update_request a[data-behavior='lca_report_request']").click();
		waitForLoading();
	}
	
	public void requestForLca() {
		$("#lca_report_modal tr .lca_update_request a[data-behavior='lca_report_request']").click();
		waitForLoading();
	}
	
	public void requestAnUpdateForFirstLca() {
		lcaReportModal.waitUntilVisible();
		$("#lca_report_modal tr .lca_update_request a").click();
		waitForLoading();
	}
	public String getUpdateStatusFor(String documentName) {
		return $("#lca_report_modal tr:contains('" + documentName + "') .lca_update_request").getText();
	}
	public final Element downloadInLcaModal = $("#lca_report_modal .button.icon-button");
	public void closeLCAModal() {
		if(lcaReportModal.isDisplayed()) {
			$("#lca_report_modal a.close-reveal-modal").click();
			lcaReportModal.waitUntilInvisible();
		}
	}
	
	public final Table lcaReportModal_Table = $(
			"#lca_report_modal table",
			(Configure<Table>) table -> {	
				table.lastPage("div.paging_will_paginate > span[class$='_end'] span:last-child"); //.paging_will_paginate ._end span:last-child
		        table.nextPage("div.paging_will_paginate > span[class$='_next paginate_button']"); //.paging_will_paginate ._next.paginate_button
			});


	//PRIOR ART BUTTON
	public final Element priorArtButton = $(".right-resource-content>div.resource-content div.columns:contains('Prior Art')+div.columns:last-child() img.download-icon");
	public final Element priorArtBtnToolTip = $(".qtip-content:visible");//.qtip-content .pa-btn:visible
	public final Element noPAMsg = $(".qtip-content .pa-btn span:contains('Prior Art Search Report Not Available')");
	public final Element rqPAMsg = $(".qtip-content .pa-btn span a:contains('Request a Prior Art Search')");
	public final Element rqBtnSignInMsg = $(".qtip-content a:contains('sign in'):visible");

	public void clickAndHoldPAButton() {
		if(priorArtButton.isDisplayed()) {
			priorArtButton.moveTo();
			priorArtBtnToolTip.waitUntilVisible();
		}
	}

	public final Element alertButton = $("ul.alert-container li.alert-style:contains('Alert')");
	public final Element alertBtnToolTip = $(".qtip-content div[class$='-btn']:visible");

	public void clickAndHoldAlertButton() {
		if(alertButton.isDisplayed()) {
			alertButton.moveTo();
			alertBtnToolTip.waitUntilVisible();
		}
	}

	public final Element priorArtButtonDisabled = $(By.xpath("//a[@class='button disabled']/span[text()='Prior Art']"));
	public void clickPAButton(){
		waitForLoading();
		if(priorArtButton.isDisplayed()&&priorArtButton.isEnabled()) {
			priorArtButton.click();
			waitForLoading();
			priorArtDialogTitle.waitUntilVisible();
		}
	}


	public final Element campaignNameInPATooltip = $(".qtip-content span a[href*='campaigns']");
	public final Element patentsInPATooltip = $(".qtip-content span a[href*='pat']");	
	public final Element updatedDateInPAToolTip = $(".qtip-content .pa-btn span:not([id])>span:contains('Last Updated')");
	public final Element moreLinkInPAToolTip = $(".qtip-content .pa-btn span a:contains('More')");

	//Locators for priorart search with elite and below users
	public final Element priorArtDialogTitle = $("#prior_art_contact_modal h5.section-title:contains('RPX Prior Art Search Services')");
	public final Element priorArtSearchEmail = $("#prior_art_contact_modal #email");
	public final Element priorArtSearchPhone = $("#prior_art_contact_modal #phone_number");
	public final Element priorArtSearchReferenceNumber = $("#prior_art_contact_modal #reference_number");
	public final Element priorArtSearchDescription = $("#prior_art_contact_modal #message");
	public final Element priorArtSearchSendButton = $("#prior_art_contact_modal .submit_btn");
	public final Element priorArtSubmitPromoMsg = $("#flash_modal .modal-container");

	public final Element priorArtReportModal = $("#prior_art_report_modal");
	public void openPriorArtReportModal() {
		if(!priorArtReportModal.isDisplayed()) {
			priorArtButton.click();
			priorArtReportModal.waitUntilVisible();
		}
	}
	public void closePriorArtReportModal() {
		if(priorArtReportModal.isDisplayed()) {
			$("#prior_art_report_modal .close-reveal-modal").click();
			priorArtReportModal.waitUntilInvisible();
		}
	}
	public final Element downloadBtnInPriorArtModal = $("#prior_art_report_modal .button");
	
	// SAVE BUTTON
	public final Element saveButton = $(".save-button li:contains('Pin'):visible");
	public final Element savedButton = $(".save-button.saved li:contains('Unpin'):visible");
	public final Element saveBtnTooltip=$(".qtip-content:visible");
	public final Element saveBtnSignInMsg = $(".qtip-content .save-btn:contains('sign in')");//.qtip-content .save-btn:visible:contains('sign in')
	public final Element saveBtnTooltipMsg = $(".qtip-content .save-btn:visible:contains('Save to dashboard')");//.qtip-content .save-btn:visible:contains('Save to dashboard')

	public void clickAndHoldSaveButton() {
		if (saveButton.isDisplayed()) {
			saveButton.moveTo();
			saveBtnTooltip.waitUntilVisible();
		}
	}

	
	//LITIGATION CAMPAIGN SECTION
	public final Element litigationCampaignPatentsTab = $("#lit-campaign a[href='#simple3']");
	public final Element patentsTableInLitCampaign=$(".related_patents_table tbody td:nth-of-type(1)");
	public void selectPatentTabInLitigationCampaign() { 
		waitForPageLoad();
		if (litigationCampaignPatentsTab.isDisplayed()) {
			litigationCampaignPatentsTab.click();
			waitForPageLoad();			
		}
	}
	
	//AUTHORIZATION FOR LITIGATIONS CAMPAIGN - PATENTS TAB - PTAB/ITC CALLOUT IN LIT/ITC PAGES
    public final Element litCampPatTabCallOuts = $(By.xpath("//table[@id='related_patents_table']//td/a/../..//span[contains(@class,'call_out')]"));
    
    public final Element litCampPatTabPtabCalloutForPtabPat = $(By.xpath("//table[@id='related_patents_table']//a[contains(@href,'US8525138B2')]/../..//span[@class='ptab_call_out span_left']"));
    public final Element litCampPatTabItcCalloutForPtabPat = $(By.xpath("//table[@id='related_patents_table']//a[contains(@href,'US8525138B2')]/../..//span[@class='itc_call_out span_left']"));
    
    public final Element litCampPatTabItcCalloutForItcPat = $(By.xpath("//table[@id='related_patents_table']//a[contains(@href,'US7765414B2')]/../..//span[@class='itc_call_out span_left']"));
    public final Element litCampPatTabPtabCalloutForItcPat = $(By.xpath("//table[@id='related_patents_table']//a[contains(@href,'US7765414B2')]/../..//span[@class='ptab_call_out span_left']"));
    
    public final Element litCampPatTabPtabItcCallouts = $(By.xpath("//table[@id='related_patents_table']//a[contains(@href,'US9048000B2')]"
    		+ "/../..//span[@class='ptab_call_out span_left']/../span[@class='itc_call_out span_left']")); 
    
    //AUTH - PATENTS IN SUIT ITC-PTAB CALLOUT
    public final Element itcCalloutInPatentInSuit = $("table.patents-in-suit-table td:nth-child(1) span.itc_call_out");
    public final Element ptabCalloutInPatentInSuit = $("table.patents-in-suit-table td:nth-child(1) span.ptab_call_out");
	public final Element toolTip=$(".qtip-content:visible");
	public final Element dataBtnToolTip=$("div.qtip-content div.data-btn:contains('Customize report and download in Excel')");    public final Element alert_Button=$("div.alert_button_div a span:contains('Alert')");
    public void clickAndHoldAlertBtn() {
		if(alert_Button.isDisplayed()) {
			alert_Button.moveTo();
			toolTip.waitUntilVisible();
		}		
	}
    
    // ADVANCED TIMELINE
    public final Element defendantTimeline = $(".highcharts-series rect:nth-of-type(1)");
    public final Element defendantTimelineModal = $("#async_modal.open");
    public final String chartXAxis="#render_campaign_overview_chart .highcharts-series.highcharts-tracker>rect";
    public final Element defendant_Dropdown=$("#overview_chart #defendant_name_filter");
    public final Element lawFirm_Dropdown=$("#overview_chart #lawfirm_name_filter");
    public final Element judgeOrCourt_Dropdown=$("#overview_chart #judge_or_venue_name_filter");
    public final Element court_Dropdown=$("#overview_chart #court_name_filter");
    public final Element judgeVenueDropdownValues = $("#judge_or_venue_name_filter option");
    public final Element defendantDropdownValues = $("#defendant_name_filter option:not([value='All'])");
    public final Element defendantStatus_Dropdown=$("#overview_chart #defendant_status_filter");
	public final Element defendanteEvent_Dropdown=$("#overview_chart #document_type_filter");
    public final Element defendant_timeLine_Popup_CaseDetails=$("#async_modal.open div.cases");
	public final Element defendant_timeline_active_top_marker=$("div.highcharts-label:has(span[style*='color: rgb(255, 255, 255)']>div.marker-text>span)");
	public final Element defendant_timeline_inactive_top_marker=$("div.highcharts-label:has(span[style*='color: rgb(92, 92, 92)']>div.marker-text>span)");
	public final Element defendant_timeline_top_marker=$(".highcharts-container g.highcharts-label:has(title:contains('{value}'))");
    public final Element timeLinechartBar=$(chartXAxis);
	public final Element test=$(".highcharts-axis-labels.highcharts-xaxis-labels>span");
	public final Element summaryJudgementMarker=$("#render_campaign_overview_chart .highcharts-markers path[fill='#f4d02d']");
	public final Element summaryJudgementTooltip=$(".campaign-timeline-tooltip.sj");
	public final Element chineseJudgmentMarker=$("#render_campaign_overview_chart .highcharts-markers path[fill='#f25600']");
	public final Element chineseJudgementTooltip=$(".campaign-timeline-tooltip.j-cn");
	public final Element noticeOfAppealTooltip=$(".campaign-timeline-tooltip");
	public final Element noticeOfAppealMarker=$("#render_campaign_overview_chart .highcharts-markers path[fill='#7f43a5']");
	public final Element markerToolTipDetail=$(".campaign-timeline-tooltip .marker-tooltip-details-col:nth-child(1)");
	public final Element decisionDateTooltip=$(".campaign-timeline-tooltip");
	public final Element decisionDateMarker=$("#render_campaign_overview_chart .highcharts-markers path[fill='#58759A']");

	public final Element markerToolTipHeader=$(".campaign-timeline-tooltip span");
	public final Element markerToolTipCaseLink=$(".campaign-timeline-tooltip .marker-tooltip-details-col a");
	public final Element markerToolTipDocumentLink=$(".campaign-timeline-tooltip .marker-tooltip-document-col a:visible");
	
	public final Element complaint_marker=$(".highcharts-tracker path[fill='#76c5ff']");
	public final Element dismissal_marker=$(".highcharts-tracker path[fill='#fd9d4a']");
	public final Element dismissal_Topmarker=$("[className=campaign-top-marker] path[fill='#c23d1e']");
	public final Element itcComplaint_marker=$(".highcharts-tracker path[fill='#2f6766']");
	public final Element defendantTimelinetab = $(".tabs a[href='#overview_chart']");
	public final Element defendantsInTimelineChart=$(".highcharts-axis-labels.highcharts-xaxis-labels span.has-tip");//.highcharts-axis-labels.highcharts-xaxis-labels span:not([class='has-tip']) span:not([class='cafc_call_out'])
	//public final Element defendantsInTimeline=$(".highcharts-axis-labels.highcharts-xaxis-labels span[class='has-tip']");
	public final Element counsel_LabelForITC=$(".modal-content .cases div:contains(GENERAL COUNSEL):contains(INVESTIGATION NUMBER):visible");
	public final Element counsel_LabelForPTAB=$(".modal-content .cases div:contains(NAME OF PETITIONER):contains(COUNSEL):contains(CASE NUMBER):visible");
	public final Element counsel_LabelForDC=$(".modal-content .cases div:contains(LEAD COUNSEL):contains(CASE NUMBER):contains(ACCUSED PRODUCTS):visible");
	public final Element counsel_LabelForCN=$(".modal-content .cases div:contains(LEAD COUNSEL):contains(CASE NUMBER):visible:not(div:contains(ACCUSED PRODUCTS))");
	public final Element defendants_timeline=	$(".highcharts-axis-labels.highcharts-xaxis-labels>span");
	public final Element defendantParent=$("#campaign_defendants tbody>tr>td:nth-of-type(1) span a[data-nested-tableurl*='defendant_parent']");
	
	public void selectDefendantTimelineTab() {
        if (defendantTimelinetab.isDisplayed()) {
        	defendantTimelinetab.click();
            waitForPageLoad();
            defendant_Dropdown.waitUntilVisible();
            judgeOrCourt_Dropdown.waitUntilVisible();
        }
    }
	
    public void applyDefendantFilter(String defendantName) {
    	defendant_Dropdown.waitUntilVisible();
    	defendant_Dropdown.selectByOption(defendantName);
    }
    
    public void applyJudgeOrCourtFilter(String judgeOrCourtName) {
    	judgeOrCourt_Dropdown.waitUntilVisible();
    	judgeOrCourt_Dropdown.selectByOption(judgeOrCourtName);
    }
    
    public void applyDefendantStatusFilter(String defendantStatus) {
    	defendantStatus_Dropdown.waitUntilVisible();
    	defendantStatus_Dropdown.selectByOption(defendantStatus);
    }
	public void applyDefendantEventFilter(String eventType) {
		defendanteEvent_Dropdown.waitUntilVisible();
		defendanteEvent_Dropdown.selectByOption(eventType);
	}
    
    public List<String> getCaseDataOfDefendantTimeLineModal() {    
    	defendant_timeLine_Popup_CaseDetails.waitUntilVisible();
    	return Arrays.asList(Arrays.stream(defendant_timeLine_Popup_CaseDetails.getText().split("\n")).map(String::trim).toArray(String[]::new));
    }
    
    public void closeTimelinePopupModal() {
    	if(defendantTimelineModal.$("a.close-reveal-modal").isDisplayed()) {
    		defendantTimelineModal.$("a.close-reveal-modal").click();
    		defendantTimelineModal.waitUntilInvisible();
    	}
    }

	public final Element accusedProductsTabLink = $("#lit-campaign a[href='#simple4']");
	public void selectAccusedProductTab() {
		if (accusedProductsTabLink.isDisplayed()) {
			accusedProductsTabLink.click();
			waitForPageLoad();
		}
	}

	public void clearFilters() {
		applyDefendantFilter("All");
		applyJudgeOrCourtFilter("All");
		applyDefendantStatusFilter("All");
		applyDefendantEventFilter("All");
	}
	
	public final Highchart defendantListInDefendantTimeline = $("div#render_campaign_overview_chart", (Configure<Highchart>) chart ->
		{
			chart.axisLabels("defendant_list", ".highcharts-xaxis-labels span");
			chart.graphBars("g.highcharts-tracker rect");
			chart.uniqueId("div>a;a:nth-of-type(3)");
			chart.column("defendant_info", "div");
			chart.table("div.cases");
		}		
	);	

	public void clickOnDefendantTimeline() {
		defendantTimeline.click();
		defendantTimelineModal.waitUntilVisible();
		ajax_loading.waitUntilInvisible();
	}

	public final Element showAllCouncelExpandLink = $("a.arrow.counsel.active.secondary.collapsed");

	public void expandCounselInfo() throws Exception{
		if (showAllCouncelExpandLink.isDisplayed()) {
			JavascriptExecutor js = (JavascriptExecutor) getDriver();
			js.executeScript("$('a.arrow.counsel.active.secondary').click()", "");
			showAllCouncelExpandLink.waitUntilInvisible();
			Thread.sleep(20000);
		}
		loading.waitUntilInvisible();
	}

	//Role Auth CAFC related locators
	public final Element signInUpgradePromoMessage = $("div#lit-campaign div.active div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element cafcTagInSearchTitle = $("span.cafc-tag");
	public final Element npeTagInSearchTitle = $("span.npe_tag");
	public final Element scTagInSearchTitle = $("span.sc-tag");
	public final Element cafcTagInTitle = $("div.header-name span.cafc-tag");
	public final Element patentInSuitCAFCTag  = $("#patents_in_suit .cafc_call_out");
	public final Element litCampaignTimelineCAFCTag = $("#overview_chart .cafc_call_out");
	public final Element litCampaignDefendantCAFCTag = $("#campaign_defendants .cafc_call_out");
	public final Element litCampaignPatentCAFCTag = $("#related_patents_table_wrapper .cafc_call_out");
	public final Element PatentInSuitCAFCTag = $(".patents-in-suit-table .cafc_call_out");//itcPatentInSuitCAFCTag
	public final Element litSearchSignInPromoMessage = $(".reveal_login_from_grey_out");
	public final Element litSearchLearnMorePromoMessage = $(".results td a");

	//Role Auth CN related locators
	public final Element chineseCampaignPageUpgradePromoMessage = $("section#content div.subscription-promo-message a:contains('Start with a Free Trial')");
	public final Element CNTagInTitle = $("div.header-name span.cn-tag");

	// AUTHORIZATION PATENT IN SUITE
	public final Element patentInformationWithoutData = $("#patents_in_suit span:contains('Patents have not yet been matched')");

	public final Element patentInformation_Petition_PromoMsg= $("div#petitions div.subscription-promo-message a:contains('Start with a Free Trial')");
	//public final Element patentInformationSignOnMsg = $(By.xpath(
			//"//*[@class='handle']/h2[contains(text(),'Patent Information')]/../following-sibling::*[@class='content']//div[@class='content active']//a[text()='sign in']"));
	public final Element patentInformation_Petition_Tab_SignOnMsg=$("div#petitions div.subscription-promo-message a:contains('Sign In')");

	//RoleAuthorization Litigation Campaign
	public final Element litigationCampaign = $("div#lit-campaign");


	/** Fed Circuit Detail Page **/
	public final Element panelOverview = $(".panel.overview");
	public final Element defendantWithCounselInfo = $("#defendants_container .counsel-content>.counsel-party");
	public final Element plaintiffWithCounselInfo = $("#plaintiff_container .counsel-content>.counsel-party");
	public final Element otherPartiesWithCounselInfo = $(".other_parties .counsel-content>.counsel-party");

	public final Element overviewCaseType = $("div.overview div.block-name:contains('Case Type')+div");
	//PATENT-IN-SUITE
	public final Element patentInformationPromoMsg=$("div#patent_information+div.content div.subscription-promo-message a:contains('Start with a Free Trial'):visible");
	public final Element patentInformationSignOnMsg = $("div#patent_information+div.content div.subscription-promo-message a.signin:contains('Sign In') ~ span:contains('or') ~ a.blocked-content-promo.trial:contains('Start with a Free Trial'):visible()");
	public final Element patentInformationSignOnPromo = $("div#patent_information+div.content div.subscription-promo-message a.signin:contains('Sign In'):visible()");
	//LITIGATION CAMPAIGN SECTION
	public final Element litigationCampaignTimelinePromoMsg=$("div#lit-campaign div.subscription-promo-message a:contains('Start with a Free Trial')");
	public final Element litigationCampaignTimelineSignOnMsg = $("div#lit-campaign div.subscription-promo-message a:contains('Sign In')");
	public final Element litigationCampaignAccusedProdPromoMsg = $("div#simple4 div.subscription-promo-message a:contains('Start with a Free Trial')");
	public final Element litigationCampaignNoAccusedProduct = $("div#simple4 span:contains('No accused products found')");
	public final Element litigationCampaignAccusedProdsignin = $("div#simple4 div.subscription-promo-message a:contains('Sign In')");
	//ACCUSED PRODUCT SECTION
	public final Element accusedProductPromoMsg = $("div#accused_products div.subscription-promo-message a:contains('Start with a Free Trial')");
	public final Element accusedProductPromoSignin = $("div#accused_products div.subscription-promo-message a.signin:contains('Sign In') ~ span:contains('or') ~ a.blocked-content-promo.trial:contains('Start with a Free Trial')");
	//DOCKET ENTRIES SECTION
	public final Element docketEntriesPromoMsg = $("div#docket_entries_sections + div.content div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element docketEntriesSignOnMsg = $("div#docket_entries_sections + div.content div.subscription-promo-message:contains('Sign In')");
	//COUNSEL REPRESENTATION
	public final Element plaintiffCounselRepPromoMsg = $("#plaintiff_container ul>li div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element plaintiffCounselSignOnMsg= $("#plaintiff_container ul>li div.subscription-promo-message a.signin:contains('Sign In') ~ span:contains('or') ~ a.blocked-content-promo.trial:contains('Start with a Free Trial'):visible()");
	public final Element defendantCounselRepPromoMsg = $("#defendants_container ul>li div.subscription-promo-message:contains(Start with a Free Trial)");
	public final Element defendantCounselSignOnMsg = $("#defendants_container ul>li div.subscription-promo-message a.signin:contains('Sign In') ~ span:contains('or') ~ a.blocked-content-promo.trial:contains('Start with a Free Trial'):visible()");

	/** PTAB Detail Page **/
	public final Element overviewExpert = $("div.overview div.block-name:contains('Expert')+div");
	public final Element overviewInstDecion= $("div.overview div.block-name:contains('Institution Decision')+div");
	public final Element overviewStatus = $("div.overview div.block-name:contains('Status')+div");
	public final Element relatedPtabPetitionsPromoMsg = $("div#ptab_related_petitions div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element relatedPtabPetitionsSignOnMsg = $("div#ptab_related_petitions div.subscription-promo-message:contains('Sign In')");


	public final Element relatedPetitionsPromoMsg = $("div#related_petitions div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element relatedPetitionsSignOnMsg = $("div#related_petitions div.subscription-promo-message:contains('Sign In')");
	public final Element relatedCampaignsPromoMsg = $("div#ptab_lit_campaigns div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element relatedCampaignsSignOnMsg = $("div#ptab_lit_campaigns div.subscription-promo-message:contains('Sign In')");
	public final Element claimAnalyticsPromoMsg = $("div#claim-analytics div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element claimAnalyticsSignOnMsg = $("div#claim-analytics div.subscription-promo-message:contains('Sign In')");
	public final Element challengedPatentPromoMsg = $("div#challenged_patent+div.content div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element challengedPatentSignOnMsg = $("div#challenged_patent+div.content div.subscription-promo-message:contains('Sign In')");
	public final Element petitionerWithCounselInfo = $("#petitioner_container .counsel-content>.counsel-party");
	public final Element patOwnerWithCounselInfo = $("#petitioner_container .counsel-content>.counsel-party");
	public final Element petitionertCounselRepPromoMsg = $("div#petitioner_container div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element petitionerCounselSignOnMsg = $("div#petitioner_container div.subscription-promo-message:contains('Sign In')");
	public final Element patOwnerCounselRepPromoMsg = $("div#patent_owner_container div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element patOwnerCounselSignOnMsg = $("div#patent_owner_container div.subscription-promo-message:contains('Sign In')");
	public final Element complainantCounselRepPromoMsg = $("div#complainants div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element complainantCounselSignOnMsg = $("div#complainants div.subscription-promo-message:contains('Sign In'):visible()");
	public final Element respondentsCounselRepPromoMsg = $("div#respondents div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element respondentsCounselSignOnMsg = $("div#respondents div.subscription-promo-message:contains('Sign In'):visible()");

	//Judges Page
	public final Element techCenterrecentActivitiesPromoMsg = $("#recent_activity .subscription-promo-message:contains('Start with a Free Trial')");
	public final Element techCenterrecentActivitiesSignOnMsg = $("#recent_activity .subscription-promo-message:contains('Sign In')");
	public final Element techCenterrecentActivityContent = $("#recent_activity:has(h2:contains('Recent Activities'))>ul:visible");
	public final Element marketSectorPromoMsg = $(".cases-by-market-sector:has(h2:contains(Cases by Market Sector)+div div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element marketSectorSignOnMsg = $(".cases-by-market-sector:has(h2:contains(Cases by Market Sector)+div div.subscription-promo-message:contains('Sign In'))");
	public final Element recentActivityPromoMsg = $("div#recent_activity:has(h2:contains('Recent Activities')+div div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element recentActivitySignOnMsg = $("div#recent_activity:has(h2:contains('Recent Activities')+div div.subscription-promo-message:contains:('Sign In'))");


	public final Element outcomeSignOnMsg = $(".handle:has(h5:contains('Outcome'))+div.content div.subscription-promo-message:contains('Sign In')");
	public final Element outcomePromoMsg = $(".handle:has(h5:contains('Outcome'))+div.content div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element disabledChineseEnglishVeiw = $("#chinese_toggle_tooltip > label[for='chn_eng_toggle disabled']");
	//PTAB tech center page R_493
	public final Element petitionsPromoMsg = $("#litigations_section div.subscription-promo-message:contains('Start with a Free Trial')");
	public final Element petitionsSignOnMsg = $("#litigations_section div.subscription-promo-message:contains('Sign In')");

	public final Element overviewDownloadSignOnMsg = $("div.qtip-content:has(div.data-btn:contains('Please'):contains('to use this feature')>a:contains('sign in'))"); //--todo need to change the promo message
	public final Element chineseOverviewDownloadPromoMsg = $("div.qtip-content>div.data-btn:contains('Judgment documents are not included in your current subscription level. Please') a:contains('Upgrade')");
	public final Element ptabsOverviewDownloadPromoMsg = $("div.qtip-content:has(div.data-btn:contains('Petition documents are not included in your current subscription level. Please')>a:contains('Upgrade'))");
	public final Element itcOverviewDownloadPromoMsg = $("div.qtip-content:has(div.data-btn:contains('Complaint documents are not included in your current subscription level Please ')>a:contains('Upgrade'))");
	public final Element claimAnalyticssankeyDiagram = $("div#claim_analytics_overview>div[data-behavior='ptab_outcome_sankey']");
	public final Element recentActivityContent = $("div.activity:has(h2:contains('Recent Activities'))>ul:visible");
	public final Element claimAnalyticssankeyDiagramPromomsg = $("#claim-analytics a.subscribe_page_link.blocked-content-promo.trial:contains('Start with a Free Trial')"); //--todo need to change the promo message
	public final Element claimAnalyticssankeyDiagramSignInmsg = $("#claim-analytics div.subscription-promo-message a:contains('Sign In')"); //--todo need to change the promo message

	public void moveToMarker(String eventType) {
		switch(eventType){
			case "Chinese Judgment":
				chineseJudgmentMarker.scrollAndFocus();
				chineseJudgmentMarker.moveTo();//moveTo(1,1)
				break;

		}
	}


}