package com.rpxcorp.insight.page;

import com.rpxcorp.testcore.element.Element;

public class OldSignInPage extends BasePage {

    @Override
    public boolean at() {
        return staticsearchsignin.waitUntilVisible();
    }

    public final Element staticsearchsignin = $(".anonymous.page_blocked a.reveal_login_from_grey_out");

}
