package com.rpxcorp.insight.test.functional;

import com.google.gson.JsonObject;
import com.rpxcorp.insight.page.LoginPage.ROLES;
import com.rpxcorp.insight.page.visual_analytics.CostAnalyticsMethodologyPage;
import com.rpxcorp.insight.page.visual_analytics.CostAnalyticsOverviewPage;
import com.rpxcorp.insight.page.visual_analytics.CostAnalyticsPage;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.Map;


public class CostAnalyticsTest extends BaseFuncTest {

	JsonObject dashboardTestData;
	CostAnalyticsPage costAnalyticsPage;
	CostAnalyticsOverviewPage costAnalyticsOverview;
	CostAnalyticsMethodologyPage costAnalyticsMethodology;

	@BeforeClass(alwaysRun=true)
	public void setupTest() throws Exception {
		loginAs(ROLES.MEMBER);	
		to(costAnalyticsPage);
		dashboardTestData = getJsonTestData("CostAnalytics.json");
	}
	
	@BeforeGroups(groups = { "P3", "legal_resolution_cost_proportion", "resolution_cost_with_xaxis", "patent_product_cost_chart", "settlement_cost_by_termination_year" })
	public void selectLitigationCostAnalyticsTab() {
		costAnalyticsPage.searchPanelTabs.select("Litigation Cost Analytics");
	}



	/** SETTLEMENT COST BY TERMINATION YEAR TEST **/
	@Test(priority = 1, groups ={"P3", "settlement_cost_by_termination_year"}, description = "Verify settlement cost by termination year graph")
	public void verifySettlementCostByTerminationYearChart() throws Exception {
		assertEquals(costAnalyticsPage.settlementCostByTerminationYearTitle.getText().trim(), "Settlement or Judgment Cost by Termination Year ($000s)", "Graph title");
		assertTrue(costAnalyticsPage.settlementCostByTerminationYearChart.isDisplayed(), "Graph is not displayed");
		assertTrue(costAnalyticsPage.settlementCostByTerminationYearLegendImage.isDisplayed(),"Settlement or Judgment Cost by Termination Year Legend is not displayed");
		costAnalyticsPage.settlementCostByTerminationYearTooltip.clickAndHold();
		assertTrue(costAnalyticsPage.settlementCostByTerminationYearTooltipContent.isDisplayed(),"Tooltip doesnt have content");
	}

	
	@Test(priority = 2, groups ={"P3", "legal_resolution_cost_proportion"}, dataProvider = "sliderRangeData",
			description = "verify chart in Proportion of Legal and Resolution Cost by Total Case Cost")
	public void verifyChartInProportionCostByTotalCaseCost(String range, int xOffset, int yOffset) throws InterruptedException {
		costAnalyticsPage.proportionCostByTotalCaseCostSlider.dragAndDropBy(xOffset, yOffset);
		costAnalyticsPage.waitForLoading();
		assertTrue(costAnalyticsPage.proportionCostByTotalCaseCostChart.isTrackerDisplayed("legal_cost"), "Legal Cost is not displayed in the pie chart");
		assertTrue(costAnalyticsPage.proportionCostByTotalCaseCostChart.isTrackerDisplayed("settlement_judgment_cost"), "Settlement Cost is not displayed in the pie chart");
	}
	@DataProvider
	public Object[][] sliderRangeData() {
		return new Object[][] {
				{ "<$10K", 0, 0 },
				{ "$10K-100K", 85, 0 },
				{ "$100K-1M", 85, 0 },
				{ "$1M-10M", 85, 0 },
				{ "$10M-50M ", 85, 0 },
				{ ">$50M", 85, 0 }
		};
	}
	
	/** PROPORTION OF LEGAL AND RESOLUTION COST BY TOTAL CASE COST TESTS **/
	@Test(priority = 3, groups ={"P3", "legal_resolution_cost_proportion"},
			description = "Verify title and tool tip content for Proportion of Legal and Resolution Cost by Total Case Cost graph")
	public void verifyProportionOfLegalAndResolutionCostTitleAndTooltip() throws Exception {
		assertEquals(costAnalyticsPage.proportionCostByTotalCaseCostTitle.getText().trim(), "Proportion of Legal and Resolution Cost by Total Case Cost",
				"Proportion of Legal and Resolution Cost title");
		costAnalyticsPage.proportionCostByTotalCaseCostTooltip.clickAndHold();
		assertTrue(costAnalyticsPage.proportionCostByTotalCaseCostTooltip.isDisplayed(),"Tooltip doesnt have content");
	}

	//** RESOLUTION COST TYPE CHART TESTS **//*
	@Test(priority = 4, groups ={"P3", "resolution_cost_with_xaxis"}, dataProvider = "resolutionData",
			description = "Verify resolution cost type chart for combination of x-axis values")
	public void verifyResolutionCostTypeWithXAxisCombination(String resolutionCostType, String xAxis) throws Exception {
		String expTitle = "";
		if(resolutionCostType.equals("Mean, excl. cases >$10M"))
			expTitle = "Mean Resolution Cost by " + xAxis + ", Excluding Cases > $10M ($M)";
		else 
			expTitle = resolutionCostType + " Resolution Cost by " + xAxis + " ($M)";

		costAnalyticsPage.selectResolutionCostAndXAxisValues(resolutionCostType, xAxis);

		assertEquals(costAnalyticsPage.resolutionCostTypeChartTitle.getText().trim(), expTitle, "Graph title");
		assertTrue(costAnalyticsPage.resolutionCostTypeChart.isDisplayed(), "Graph is not displayed");
	}
	@DataProvider
	public Object[][] resolutionData() {
		return new Object[][] {
				{ "Mean", "Defendant Revenue" },
				{ "Mean", "Filing Venue" },
				{ "Mean", "Latest Venue" },
				{ "Mean", "Length of Suit" },
				{ "Mean", "Number of Patents-in-Suit" },
				{ "Mean", "Sector" },
				{ "Mean, excl. cases >$10M", "Defendant Revenue" },
				{ "Mean, excl. cases >$10M", "Filing Venue" },
				{ "Mean, excl. cases >$10M", "Latest Venue" },
				{ "Mean, excl. cases >$10M", "Length of Suit" },
				{ "Mean, excl. cases >$10M", "Number of Patents-in-Suit" },
				{ "Mean, excl. cases >$10M", "Sector" },
				{ "Median", "Defendant Revenue" },
				{ "Median", "Filing Venue" },
				{ "Median", "Latest Venue" },
				{ "Median", "Length of Suit" },
				{ "Median", "Number of Patents-in-Suit" },
				{ "Median", "Sector" }
		};
	}

	@Test(priority = 5, groups ={"P3", "resolution_cost_with_xaxis"}, description = "Verify resolution cost type chart tooltip")
	public void verifyResolutionCostTypeWithXAxisCombinationTooltip() throws Exception {
		costAnalyticsPage.resolutionCostTypeChartTooltip.waitUntilVisible();
		costAnalyticsPage.resolutionCostTypeChartTooltip.clickAndHold();
		assertTrue(costAnalyticsPage.resolutionCostTypeChartTooltipContent.isDisplayed(),"Tooltip doesnt have content");
	}

	//** MEAN RESOLUTION COSTS FOR SUITS THAT END AT A GIVEN STAGE TESTS **//
	@BeforeGroups(groups = "mean_resolution_end_at_given_stage")
	public void loadMeanResolutionEndsAtStageData() {	
		selectLitigationCostAnalyticsTab();
		this.testData = dashboardTestData.getAsJsonObject("MEAN_COST_END_AT_A_STAGE");
	}

	@Test(priority = 6, groups ={"P3","mean_resolution_end_at_given_stage"}, description = "Verify title in mean resolution costs for suits that end a given stage graph")
	public void verifyMeanResolutionCostsThatEndAtGivenStageTitleAndTooltip() throws Exception {
		costAnalyticsPage.meanResolutionChartEndAtGivenStageTitle.waitUntilVisible();
		assertEquals(costAnalyticsPage.meanResolutionChartEndAtGivenStageTitle.getText().trim(), "Mean Resolution Costs for Suits That End at a Given Stage ($M)",
				"Title for mean resolution costs for suits that end a given stage graph");
		costAnalyticsPage.meanResolutionChartEndAtGivenStageTooltip.clickAndHold();
		costAnalyticsPage.meanResolutionChartEndAtGivenStageTooltipContent.waitUntilVisible();
		assertTrue(costAnalyticsPage.meanResolutionChartEndAtGivenStageTooltipContent.isDisplayed(),"Tooltip doesnt have content");
	}

	@Test(priority = 7, groups ={"P3","mean_resolution_end_at_given_stage"}, dataProvider = "meanResolutionGraphData",
			description = "Verify filters in mean resolution costs for suits that end a given stage graph")
	public void verifyFiltersInMeanResolutionCostsThatEndAtGivenStage(String dataKey, boolean legalMarker, boolean settleMarker, boolean noDataMarker) 
			throws Exception {
		Map<String, String> testData = dataAsMap(dataKey);
		costAnalyticsPage.meanResolutionChartEndAtGivenStage.waitUntilVisible();
		costAnalyticsPage.meanResolutionChartEndAtGivenStage.filter(testData);
		assertMeanResolutionChartTrackers(costAnalyticsPage.meanResolutionChartEndAtGivenStage.getTrackerStatus(), legalMarker, settleMarker, noDataMarker);
	}

	//** MEAN RESOLUTION COSTS FOR SUITS THAT REACHED AT LEAST A GIVEN STAGE TESTS **//
	@BeforeGroups(groups = "mean_resolution_reached_at_given_stage")
	public void loadMeanResolutionReachedAtStageData() {	
		selectLitigationCostAnalyticsTab();
		this.testData = dashboardTestData.getAsJsonObject("MEAN_COST_REACHED_AT_A_STAGE");
	}	

	@Test(priority = 8, groups ={"P3", "mean_resolution_reached_at_given_stage"}, description = "Verify title in mean resolution costs for suits that reached at least a given stage graph")
	public void verifyMeanResolutionCostsThatReachedAtGivenStageTitleAndTooltip() throws Exception {
		costAnalyticsPage.meanResolutionChartReachedAtGivenStageTitle.waitUntilVisible();
		assertEquals(costAnalyticsPage.meanResolutionChartReachedAtGivenStageTitle.getText().trim(), "Mean Resolution Costs for Suits That Reached at Least the Given Stage ($M)",
				"Title for mean resolution costs for suits that reached atleast a given stage graph");
		costAnalyticsPage.meanResolutionChartReachedAtGivenStageTooltip.clickAndHold();
		costAnalyticsPage.meanResolutionChartReachedAtGivenStageTooltipContent.waitUntilVisible();
		assertTrue(costAnalyticsPage.meanResolutionChartReachedAtGivenStageTooltipContent.isDisplayed(),"Tooltip doesnt have content");
		to(costAnalyticsPage);
		selectLitigationCostAnalyticsTab();
	}

	@Test(priority = 9, groups ={"P3", "mean_resolution_reached_at_given_stage"}, dataProvider = "meanResolutionGraphData",
			description = "Verify filters in mean resolution costs for suits that reached at least a given stage graph")
	public void verifyFiltersInMeanResolutionCostsThatReachedAtGivenStage(String dataKey, boolean legalMarker, boolean settleMarker, boolean noDataMarker) 
			throws Exception {
		Map<String, String> testData = dataAsMap(dataKey);		
		costAnalyticsPage.meanResolutionChartReachedAtGivenStage.waitUntilVisible();
		costAnalyticsPage.meanResolutionChartReachedAtGivenStage.filter(testData);
		assertMeanResolutionChartTrackers(costAnalyticsPage.meanResolutionChartReachedAtGivenStage.getTrackerStatus(), legalMarker, settleMarker, noDataMarker);
	}

	@DataProvider
	public Object[][] meanResolutionGraphData() {
		return new Object[][] { 
				//{"NONE", false, false, true},
				{"LEGAL_ONLY", true, false, false}, 
				{"SETLLEMENT JUDGMENT_ONLY", false, true, false}, 
				{"LEGAL_SETLLEMENT JUDGMENT", true, true, false} 
		};
	}

	//** PATENT PRODUCT RESOLUTION COST TESTS **//
	@Test(priority = 10, groups ={"P3", "patent_product_cost_chart"}, dataProvider = "patentProductResolutionChartData",
			description = "Verify patent and product resolution cost chart")
	public void verifyPatentAndProductResolutionCostChart(String costType, String categoryType, String category, String secondaryCategory) throws Exception {
		costAnalyticsPage.selectPatentProductResolutionOptions(costType, categoryType, category, secondaryCategory);

		assertEquals(costAnalyticsPage.patentProductResolutionTitle.getText().trim(), costType + " Cost Per Case by " + categoryType + " Category ($000s)", "Graph title");
		assertTrue(costAnalyticsPage.patentProductResolutionChart.isDisplayed(), "Graph is not displayed");
	}
	@DataProvider
	public Object[][] patentProductResolutionChartData() {
		return new Object[][] {
				{"Legal", "Patent", "All", "All"}, {"Legal", "Patent", "Communications", "All"}, {"Legal", "Patent", "Communications", "Messaging and Collaboration"},
				{"Legal", "Patent", "Communications", "VoIP"}, {"Legal", "Patent", "Communications", "Wireless"}, {"Legal", "Patent", "Communications", "Wireline"},
				{"Legal", "Patent", "Hardware", "All"}, {"Legal", "Patent", "Hardware", "Audiovisual"}, {"Legal", "Patent", "Hardware", "Automotive"}, 
				{"Legal", "Patent", "Hardware", "Computer/PC"}, {"Legal", "Patent", "Hardware", "Computer Peripherals"}, {"Legal", "Patent", "Hardware", "Computer/Server"}, 
				{"Legal", "Patent", "Hardware", "Consumer Products"}, {"Legal", "Patent", "Hardware", "Displays/TVs"}, {"Legal", "Patent", "Hardware", "Gaming Platforms"}, 
				{"Legal", "Patent", "Hardware", "Handset"}, {"Legal", "Patent", "Hardware", "Imaging"}, {"Legal", "Patent", "Hardware", "LBS"}, 
				{"Legal", "Patent", "Hardware", "Power"}, {"Legal", "Patent", "Hardware", "Printers/MFPs"}, {"Legal", "Patent", "Hardware", "Sanner, Copier, and Fax"}, {"Legal", "Patent", "Hardware", "Smartcards"}, 
				{"Legal", "Patent", "Hardware", "Storage"}, {"Legal", "Patent", "Hardware", "Telephony"}, {"Legal", "Patent", "Hardware", "Wireless"}, 
				{"Legal", "Patent", "Networking", "All"}, {"Legal", "Patent", "Networking", "Application and Content Delivery"}, {"Legal", "Patent", "Networking", "Cable"},
				{"Legal", "Patent", "Networking", "Cellular"}, {"Legal", "Patent", "Networking", "DSL"}, {"Legal", "Patent", "Networking", "NICs"},
				{"Legal", "Patent", "Networking", "Security"}, {"Legal", "Patent", "Networking", "Surveillance/Monitoring"},
				{"Legal", "Patent", "Networking", "Switch/Router and Gateways"}, {"Legal", "Patent", "Networking", "Systems/Network Management"}, {"Legal", "Patent", "Networking", "VoIP"},
				{"Legal", "Patent", "Networking", "Wireless"}, {"Legal", "Patent", "Semiconductors", "All"}, {"Legal", "Patent", "Semiconductors", "Communications"}, 
				{"Legal", "Patent", "Semiconductors", "Displays/TVs"}, {"Legal", "Patent", "Semiconductors", "Fabrication/Packaging/A&T"}, {"Legal", "Patent", "Semiconductors", "Imaging/Sensors"}, 
				{"Legal", "Patent", "Semiconductors", "Logic"}, {"Legal", "Patent", "Semiconductors", "Memory"}, {"Legal", "Patent", "Semiconductors", "Power"}, 
				{"Legal", "Patent", "Semiconductors", "RF/Component"}, {"Legal", "Patent", "Services", "All"}, {"Legal", "Patent", "Services", "Cloud"}, 
				{"Legal", "Patent", "Services", "Content"}, {"Legal", "Patent", "Services", "Ecommerce"}, {"Legal", "Patent", "Services", "Finance"}, 
				{"Legal", "Patent", "Software", "All"}, {"Legal", "Patent", "Software", "Application"}, {"Legal", "Patent", "Software", "Ecommerce"}, 
				{"Legal", "Patent", "Software", "Enterprise"}, {"Legal", "Patent", "Software", "Gaming"}, {"Legal", "Patent", "Software", "LBS"}, 
				{"Legal", "Patent", "Software", "Media Content and Distribution"}, {"Legal", "Patent", "Software", "Printers/MFPs"},
				{"Legal", "Patent", "Software", "Productivity"}, {"Legal", "Patent", "Software", "Search and Advertising"}, {"Legal", "Patent", "Software", "Security"}, 
				{"Legal", "Patent", "Software", "Storage"}, {"Legal", "Patent", "Software", "Systems/Network Management"}, {"Legal", "Patent", "Software", "Web"},
				{"Legal", "Accused Product", "All", "All"}, {"Legal", "Accused Product", "Communications", "All"}, {"Legal", "Accused Product", "Communications", "Messaging and Collaboration"},
				{"Legal", "Accused Product", "Communications", "VoIP"}, {"Legal", "Accused Product", "Communications", "Wireless"}, {"Legal", "Accused Product", "Communications", "Wireline"},								
				{"Legal", "Accused Product", "Hardware", "All"}, {"Legal", "Accused Product", "Hardware", "Audiovisual"}, {"Legal", "Accused Product", "Hardware", "Automotive"}, 				
				{"Legal", "Accused Product", "Hardware", "Computer/PC"}, {"Legal", "Accused Product", "Hardware", "Computer Peripherals"}, {"Legal", "Accused Product", "Hardware", "Computer/Server"}, 
				{"Legal", "Accused Product", "Hardware", "Consumer Products"}, {"Legal", "Accused Product", "Hardware", "Displays/TVs"}, {"Legal", "Accused Product", "Hardware", "Gaming Platforms"}, 
				{"Legal", "Accused Product", "Hardware", "Handset"}, {"Legal", "Accused Product", "Hardware", "Imaging"}, {"Legal", "Accused Product", "Hardware", "LBS"}, 
				{"Legal", "Accused Product", "Hardware", "Printers/MFPs"}, {"Legal", "Accused Product", "Hardware", "Storage"}, {"Legal", "Accused Product", "Hardware", "Telephony"},
				{"Legal", "Accused Product", "Networking", "All"}, {"Legal", "Accused Product", "Networking", "Application and Content Delivery"},
				{"Legal", "Accused Product", "Networking", "Security"}, {"Legal", "Accused Product", "Networking", "Surveillance/Monitoring"},
				{"Legal", "Accused Product", "Networking", "Switch/Router and Gateways"}, {"Legal", "Accused Product", "Networking", "Systems/Network Management"}, {"Legal", "Accused Product", "Networking", "VoIP"},
				{"Legal", "Accused Product", "Networking", "Wireless"},	{"Legal", "Accused Product", "Semiconductors", "All"}, {"Legal", "Accused Product", "Semiconductors", "Fabrication/Packaging/A&T"}, {"Legal", "Accused Product", "Semiconductors", "Imaging/Sensors"},
				{"Legal", "Accused Product", "Semiconductors", "Logic"}, {"Legal", "Accused Product", "Semiconductors", "Memory"}, {"Legal", "Accused Product", "Semiconductors", "Power"}, 
				{"Legal", "Accused Product", "Semiconductors", "RF/Component"},	{"Legal", "Accused Product", "Services", "All"}, {"Legal", "Accused Product", "Services", "Cloud"}, 
				{"Legal", "Accused Product", "Services", "Content"}, {"Legal", "Accused Product", "Services", "Ecommerce"}, {"Legal", "Accused Product", "Services", "Finance"}, 
				{"Legal", "Accused Product", "Software", "All"}, {"Legal", "Accused Product", "Software", "Application"}, {"Legal", "Accused Product", "Software", "Ecommerce"}, 
				{"Legal", "Accused Product", "Software", "Enterprise"}, {"Legal", "Accused Product", "Software", "Gaming"}, {"Legal", "Accused Product", "Software", "LBS"}, 
				{"Legal", "Accused Product", "Software", "Media Content and Distribution"}, {"Legal", "Accused Product", "Software", "Platform/OS"},
				{"Legal", "Accused Product", "Software", "Productivity"}, {"Legal", "Accused Product", "Software", "Search and Advertising"}, {"Legal", "Accused Product", "Software", "Security"}, 
				{"Legal", "Accused Product", "Software", "Storage"}, {"Legal", "Accused Product", "Software", "Systems/Network Management"}, {"Legal", "Accused Product", "Software", "Web"},
				{"Settlement or Judgment", "Patent", "All", "All"}, {"Settlement or Judgment", "Patent", "Communications", "All"}, {"Settlement or Judgment", "Patent", "Communications", "Messaging and Collaboration"},
				{"Settlement or Judgment", "Patent", "Communications", "VoIP"}, {"Settlement or Judgment", "Patent", "Communications", "Wireless"}, {"Settlement or Judgment", "Patent", "Communications", "Wireline"},				
				{"Settlement or Judgment", "Patent", "Hardware", "All"}, {"Settlement or Judgment", "Patent", "Hardware", "Audiovisual"}, {"Settlement or Judgment", "Patent", "Hardware", "Automotive"}, 
				{"Settlement or Judgment", "Patent", "Hardware", "Computer/PC"}, {"Settlement or Judgment", "Patent", "Hardware", "Computer Peripherals"}, {"Settlement or Judgment", "Patent", "Hardware", "Computer/Server"}, 
				{"Settlement or Judgment", "Patent", "Hardware", "Consumer Products"}, {"Settlement or Judgment", "Patent", "Hardware", "Displays/TVs"}, {"Settlement or Judgment", "Patent", "Hardware", "Gaming Platforms"}, 
				{"Settlement or Judgment", "Patent", "Hardware", "Handset"}, {"Settlement or Judgment", "Patent", "Hardware", "Imaging"}, {"Settlement or Judgment", "Patent", "Hardware", "LBS"}, 
				{"Settlement or Judgment", "Patent", "Hardware", "Power"}, {"Settlement or Judgment", "Patent", "Hardware", "Printers/MFPs"}, {"Settlement or Judgment", "Patent", "Hardware", "Sanner, Copier, and Fax"}, 
				{"Settlement or Judgment", "Patent", "Hardware", "Smartcards"}, {"Settlement or Judgment", "Patent", "Hardware", "Storage"}, {"Settlement or Judgment", "Patent", "Hardware", "Telephony"},
				{"Settlement or Judgment", "Patent", "Hardware", "Wireless"}, {"Settlement or Judgment", "Patent", "Networking", "All"}, {"Settlement or Judgment", "Patent", "Networking", "Application and Content Delivery"}, 
				{"Settlement or Judgment", "Patent", "Networking", "Cable"}, {"Settlement or Judgment", "Patent", "Networking", "Cellular"}, {"Settlement or Judgment", "Patent", "Networking", "DSL"}, 
				{"Settlement or Judgment", "Patent", "Networking", "NICs"}, {"Settlement or Judgment", "Patent", "Networking", "Security"}, {"Settlement or Judgment", "Patent", "Networking", "Surveillance/Monitoring"},
				{"Settlement or Judgment", "Patent", "Networking", "Switch/Router and Gateways"}, {"Settlement or Judgment", "Patent", "Networking", "Systems/Network Management"}, {"Settlement or Judgment", "Patent", "Networking", "VoIP"},
				{"Settlement or Judgment", "Patent", "Networking", "Wireless"},	{"Settlement or Judgment", "Patent", "Semiconductors", "All"}, {"Settlement or Judgment", "Patent", "Semiconductors", "Communications"}, 
				{"Settlement or Judgment", "Patent", "Semiconductors", "Displays/TVs"}, {"Settlement or Judgment", "Patent", "Semiconductors", "Fabrication/Packaging/A&T"}, {"Settlement or Judgment", "Patent", "Semiconductors", "Imaging/Sensors"}, 
				{"Settlement or Judgment", "Patent", "Semiconductors", "Logic"}, {"Settlement or Judgment", "Patent", "Semiconductors", "Memory"}, {"Settlement or Judgment", "Patent", "Semiconductors", "Power"}, 
				{"Settlement or Judgment", "Patent", "Semiconductors", "RF/Component"},	{"Settlement or Judgment", "Patent", "Services", "All"}, {"Settlement or Judgment", "Patent", "Services", "Cloud"}, 
				{"Settlement or Judgment", "Patent", "Services", "Content"}, {"Settlement or Judgment", "Patent", "Services", "Ecommerce"}, {"Settlement or Judgment", "Patent", "Services", "Finance"}, 
				{"Settlement or Judgment", "Patent", "Software", "All"}, {"Settlement or Judgment", "Patent", "Software", "Application"}, {"Settlement or Judgment", "Patent", "Software", "Ecommerce"}, 
				{"Settlement or Judgment", "Patent", "Software", "Enterprise"}, {"Settlement or Judgment", "Patent", "Software", "Gaming"}, {"Settlement or Judgment", "Patent", "Software", "LBS"}, 
				{"Settlement or Judgment", "Patent", "Software", "Media Content and Distribution"}, {"Settlement or Judgment", "Patent", "Software", "Printers/MFPs"},
				{"Settlement or Judgment", "Patent", "Software", "Productivity"}, {"Settlement or Judgment", "Patent", "Software", "Search and Advertising"}, {"Settlement or Judgment", "Patent", "Software", "Security"}, 
				{"Settlement or Judgment", "Patent", "Software", "Storage"}, {"Settlement or Judgment", "Patent", "Software", "Systems/Network Management"}, {"Settlement or Judgment", "Patent", "Software", "Web"},
				{"Settlement or Judgment", "Accused Product", "All", "All"}, {"Settlement or Judgment", "Accused Product", "Communications", "All"}, {"Settlement or Judgment", "Accused Product", "Communications", "Messaging and Collaboration"},
				{"Settlement or Judgment", "Accused Product", "Communications", "VoIP"}, {"Settlement or Judgment", "Accused Product", "Communications", "Wireless"}, {"Settlement or Judgment", "Accused Product", "Communications", "Wireline"},				
				{"Settlement or Judgment", "Accused Product", "Hardware", "All"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Audiovisual"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Automotive"}, 
				{"Settlement or Judgment", "Accused Product", "Hardware", "Computer/PC"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Computer Peripherals"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Computer/Server"}, 
				{"Settlement or Judgment", "Accused Product", "Hardware", "Consumer Products"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Displays/TVs"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Gaming Platforms"}, 
				{"Settlement or Judgment", "Accused Product", "Hardware", "Handset"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Imaging"}, {"Settlement or Judgment", "Accused Product", "Hardware", "LBS"}, 
				{"Settlement or Judgment", "Accused Product", "Hardware", "Printers/MFPs"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Storage"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Telephony"},
				{"Settlement or Judgment", "Accused Product", "Networking", "All"}, {"Settlement or Judgment", "Accused Product", "Networking", "Application and Content Delivery"},
				{"Settlement or Judgment", "Accused Product", "Networking", "Security"}, {"Settlement or Judgment", "Accused Product", "Networking", "Surveillance/Monitoring"},
				{"Settlement or Judgment", "Accused Product", "Networking", "Switch/Router and Gateways"}, {"Settlement or Judgment", "Accused Product", "Networking", "Systems/Network Management"}, {"Settlement or Judgment", "Accused Product", "Networking", "VoIP"},
				{"Settlement or Judgment", "Accused Product", "Networking", "Wireless"}, {"Settlement or Judgment", "Accused Product", "Semiconductors", "All"}, {"Settlement or Judgment", "Accused Product", "Semiconductors", "Fabrication/Packaging/A&T"}, {"Settlement or Judgment", "Accused Product", "Semiconductors", "Imaging/Sensors"},
				{"Settlement or Judgment", "Accused Product", "Semiconductors", "Logic"}, {"Settlement or Judgment", "Accused Product", "Semiconductors", "Memory"}, {"Settlement or Judgment", "Accused Product", "Semiconductors", "Power"}, 
				{"Settlement or Judgment", "Accused Product", "Semiconductors", "RF/Component"}, {"Settlement or Judgment", "Accused Product", "Services", "All"}, {"Settlement or Judgment", "Accused Product", "Services", "Cloud"}, 
				{"Settlement or Judgment", "Accused Product", "Services", "Content"}, {"Settlement or Judgment", "Accused Product", "Services", "Ecommerce"}, {"Settlement or Judgment", "Accused Product", "Services", "Finance"}, 
				{"Settlement or Judgment", "Accused Product", "Software", "All"}, {"Settlement or Judgment", "Accused Product", "Software", "Application"}, {"Settlement or Judgment", "Accused Product", "Software", "Ecommerce"}, 
				{"Settlement or Judgment", "Accused Product", "Software", "Enterprise"}, {"Settlement or Judgment", "Accused Product", "Software", "Gaming"}, {"Settlement or Judgment", "Accused Product", "Software", "LBS"}, 
				{"Settlement or Judgment", "Accused Product", "Software", "Media Content and Distribution"}, {"Settlement or Judgment", "Accused Product", "Software", "Platform/OS"},
				{"Settlement or Judgment", "Accused Product", "Software", "Productivity"}, {"Settlement or Judgment", "Accused Product", "Software", "Search and Advertising"}, {"Settlement or Judgment", "Accused Product", "Software", "Security"}, 
				{"Settlement or Judgment", "Accused Product", "Software", "Storage"}, {"Settlement or Judgment", "Accused Product", "Software", "Systems/Network Management"}, {"Settlement or Judgment", "Accused Product", "Software", "Web"},
				{"Total", "Patent", "All", "All"}, {"Total", "Patent", "Communications", "All"}, {"Total", "Patent", "Communications", "Messaging and Collaboration"},
				{"Total", "Patent", "Communications", "VoIP"}, {"Total", "Patent", "Communications", "Wireless"}, {"Total", "Patent", "Communications", "Wireline"},				
				{"Total", "Patent", "Hardware", "All"}, {"Total", "Patent", "Hardware", "Audiovisual"}, {"Total", "Patent", "Hardware", "Automotive"}, 
				{"Total", "Patent", "Hardware", "Computer/PC"}, {"Total", "Patent", "Hardware", "Computer Peripherals"}, {"Total", "Patent", "Hardware", "Computer/Server"}, 
				{"Total", "Patent", "Hardware", "Consumer Products"}, {"Total", "Patent", "Hardware", "Displays/TVs"}, {"Total", "Patent", "Hardware", "Gaming Platforms"}, 
				{"Total", "Patent", "Hardware", "Handset"}, {"Total", "Patent", "Hardware", "Imaging"}, {"Total", "Patent", "Hardware", "LBS"}, 
				{"Total", "Patent", "Hardware", "Power"}, {"Total", "Patent", "Hardware", "Printers/MFPs"}, {"Total", "Patent", "Hardware", "Sanner, Copier, and Fax"}, 
				{"Total", "Patent", "Hardware", "Smartcards"}, {"Total", "Patent", "Hardware", "Storage"}, {"Total", "Patent", "Hardware", "Telephony"}, 
				{"Total", "Patent", "Hardware", "Wireless"}, {"Total", "Patent", "Networking", "All"}, {"Total", "Patent", "Networking", "Application and Content Delivery"}, 
				{"Total", "Patent", "Networking", "Cable"}, {"Total", "Patent", "Networking", "Cellular"}, {"Total", "Patent", "Networking", "DSL"}, 
				{"Total", "Patent", "Networking", "NICs"}, {"Total", "Patent", "Networking", "Security"}, {"Total", "Patent", "Networking", "Surveillance/Monitoring"},
				{"Total", "Patent", "Networking", "Switch/Router and Gateways"}, {"Total", "Patent", "Networking", "Systems/Network Management"}, {"Total", "Patent", "Networking", "VoIP"},
				{"Total", "Patent", "Networking", "Wireless"}, {"Total", "Patent", "Semiconductors", "All"}, {"Total", "Patent", "Semiconductors", "Communications"}, 
				{"Total", "Patent", "Semiconductors", "Displays/TVs"}, {"Total", "Patent", "Semiconductors", "Fabrication/Packaging/A&T"}, {"Total", "Patent", "Semiconductors", "Imaging/Sensors"}, 
				{"Total", "Patent", "Semiconductors", "Logic"}, {"Total", "Patent", "Semiconductors", "Memory"}, {"Total", "Patent", "Semiconductors", "Power"}, 
				{"Total", "Patent", "Semiconductors", "RF/Component"}, {"Total", "Patent", "Services", "All"}, {"Total", "Patent", "Services", "Cloud"}, 
				{"Total", "Patent", "Services", "Content"}, {"Total", "Patent", "Services", "Ecommerce"}, {"Total", "Patent", "Services", "Finance"}, 
				{"Total", "Patent", "Software", "All"}, {"Total", "Patent", "Software", "Application"}, {"Total", "Patent", "Software", "Ecommerce"}, 
				{"Total", "Patent", "Software", "Enterprise"}, {"Total", "Patent", "Software", "Gaming"}, {"Total", "Patent", "Software", "LBS"}, 
				{"Total", "Patent", "Software", "Media Content and Distribution"}, {"Total", "Patent", "Software", "Printers/MFPs"},
				{"Total", "Patent", "Software", "Productivity"}, {"Total", "Patent", "Software", "Search and Advertising"}, {"Total", "Patent", "Software", "Security"}, 
				{"Total", "Patent", "Software", "Storage"}, {"Total", "Patent", "Software", "Systems/Network Management"}, {"Total", "Patent", "Software", "Web"},
				{"Total", "Accused Product", "All", "All"}, {"Total", "Accused Product", "Communications", "All"}, {"Total", "Accused Product", "Communications", "Messaging and Collaboration"},
				{"Total", "Accused Product", "Communications", "VoIP"}, {"Total", "Accused Product", "Communications", "Wireless"}, {"Total", "Accused Product", "Communications", "Wireline"},				
				{"Total", "Accused Product", "Hardware", "All"}, {"Total", "Accused Product", "Hardware", "Audiovisual"}, {"Total", "Accused Product", "Hardware", "Automotive"}, 
				{"Total", "Accused Product", "Hardware", "Computer/PC"}, {"Total", "Accused Product", "Hardware", "Computer Peripherals"}, {"Total", "Accused Product", "Hardware", "Computer/Server"}, 
				{"Total", "Accused Product", "Hardware", "Consumer Products"}, {"Total", "Accused Product", "Hardware", "Displays/TVs"}, {"Total", "Accused Product", "Hardware", "Gaming Platforms"}, 
				{"Total", "Accused Product", "Hardware", "Handset"}, {"Total", "Accused Product", "Hardware", "Imaging"}, {"Total", "Accused Product", "Hardware", "LBS"}, 
				{"Total", "Accused Product", "Hardware", "Printers/MFPs"}, {"Total", "Accused Product", "Hardware", "Storage"}, {"Total", "Accused Product", "Hardware", "Telephony"},
				{"Total", "Accused Product", "Networking", "All"}, {"Total", "Accused Product", "Networking", "Application and Content Delivery"},
				{"Total", "Accused Product", "Networking", "Security"}, {"Total", "Accused Product", "Networking", "Surveillance/Monitoring"},
				{"Total", "Accused Product", "Networking", "Switch/Router and Gateways"}, {"Total", "Accused Product", "Networking", "Systems/Network Management"}, {"Total", "Accused Product", "Networking", "VoIP"},
				{"Total", "Accused Product", "Networking", "Wireless"},	{"Total", "Accused Product", "Semiconductors", "All"}, {"Total", "Accused Product", "Semiconductors", "Fabrication/Packaging/A&T"}, {"Total", "Accused Product", "Semiconductors", "Imaging/Sensors"},
				{"Total", "Accused Product", "Semiconductors", "Logic"}, {"Total", "Accused Product", "Semiconductors", "Memory"}, {"Total", "Accused Product", "Semiconductors", "Power"}, 
				{"Total", "Accused Product", "Semiconductors", "RF/Component"},	{"Total", "Accused Product", "Services", "All"}, {"Total", "Accused Product", "Services", "Cloud"}, 
				{"Total", "Accused Product", "Services", "Content"}, {"Total", "Accused Product", "Services", "Ecommerce"}, {"Total", "Accused Product", "Services", "Finance"}, 
				{"Total", "Accused Product", "Software", "All"}, {"Total", "Accused Product", "Software", "Application"}, {"Total", "Accused Product", "Software", "Ecommerce"}, 
				{"Total", "Accused Product", "Software", "Enterprise"}, {"Total", "Accused Product", "Software", "Gaming"}, {"Total", "Accused Product", "Software", "LBS"}, 
				{"Total", "Accused Product", "Software", "Media Content and Distribution"}, {"Total", "Accused Product", "Software", "Platform/OS"},
				{"Total", "Accused Product", "Software", "Productivity"}, {"Total", "Accused Product", "Software", "Search and Advertising"}, {"Total", "Accused Product", "Software", "Security"}, 
				{"Total", "Accused Product", "Software", "Storage"}, {"Total", "Accused Product", "Software", "Systems/Network Management"}, {"Total", "Accused Product", "Software", "Web"}				
		};
	}

	@Test(priority = 11, groups ={"P3", "patent_product_cost_chart"}, description = "Verify patent and product resolution cost chart tooltip")
	public void verifyPatentAndProductResolutionCostChartTooltip() throws Exception {
		costAnalyticsPage.patentProductResolutionTooltip.waitUntilVisible();
		costAnalyticsPage.patentProductResolutionTooltip.clickAndHold();
		costAnalyticsPage.patentProductResolutionTooltipContent.waitUntilVisible();
		assertTrue(costAnalyticsPage.patentProductResolutionTooltipContent.isDisplayed(),"Tooltip doesnt have content");
	}
	
	@Test(priority=12,groups ={"P3", "patent_product_cost_chart"},description="Verify About section in Litigation Cost Analytics")
	public void verifyAboutSectionAtCostAnalytics() throws Exception {
		SoftAssert softAssert=new SoftAssert();
		costAnalyticsPage.cost_analytics_about_section.waitUntilVisible();
		softAssert.assertEquals(costAnalyticsPage.cost_analytics_about_section.getText(),"Cost Analytics");
		softAssert.assertTrue(costAnalyticsPage.cost_analytics_about_content.isDisplayed(),"About section content is not displayed");
		Thread.sleep(10000);
		withNewWindow(costAnalyticsPage.cost_analytics_about_overview,  () -> {
			at(costAnalyticsOverview);
		});
		
		withNewWindow(costAnalyticsPage.cost_analytics_about_methodology,  () -> {
			at(costAnalyticsMethodology);
			
		});
	}
	//** PTAB COST ANALYTICS TESTS **//
	@BeforeGroups(groups = {"P3", "ratio_of_costs_per_ptab", "petition_costs_by_outcome", "petition_costs_by_stage" })
	public void loadPTABCostAnalyticsTab() {
		costAnalyticsPage.searchPanelTabs.select("PTAB Cost Analytics");
	}

	//** RATIO OF COSTS PER PTAB PETITION TESTS **//*
	@Test(priority = 12, groups = {"P3", "ratio_of_costs_per_ptab"}, description = "Verify Ratio of Costs Per PTAB petition graph")
	public void verifyRatioOfCostsPerPtabPetitionGraph() throws Exception {
		assertEquals(costAnalyticsPage.ratioOfCostsPerPtabPetitionTitle.getText().trim(), "Ratio of Costs Per PTAB Petition", "Graph title");
		costAnalyticsPage.ratioOfCostsperPtabPetitionTooltip.clickAndHold();
		assertTrue(costAnalyticsPage.ratioOfCostsperPtabPetitionTooltipContent.isDisplayed(),"Tooltip doesnt have content");
		assertTrue(costAnalyticsPage.ratioOfCostsperPtabPetitionChart.isDisplayed(), "Graph is not displayed");
	}

	//** PTAB PETITION COSTS BY OUTCOME TESTS **//*
	@Test(priority = 13, groups = {"P3", "petition_costs_by_outcome"}, dataProvider = "costTypeDataForOutcomeGraph", description = "Verify Petition Costs by Outcome graph")
	public void verifyPetitionCostsByOutcomeGraph(String costType) throws Exception {		
		costAnalyticsPage.petitionCostsByOutcomeCostTypeRadio.selectValue(costType);

		assertEquals(costAnalyticsPage.petitionCostsByOutcomeTitle.getText().trim(), "PTAB Petition Costs by Outcome ($000s)", "Graph title");
		assertTrue(costAnalyticsPage.petitionCostsByOutcomeChart.isDisplayed(), "Graph is not displayed");
	}
	@DataProvider
	public Object[][] costTypeDataForOutcomeGraph() {
		return new Object[][] {
				{ "cluster" },
				{ "petition" }
		};
	}

	@Test(priority = 14, groups ={"P3", "petition_costs_by_outcome"}, description = "Verify Petition Costs by Outcome graph tooltip")
	public void verifyPetitionCostsByOutcomeGraphTooltip() throws Exception {
		costAnalyticsPage.petitionCostsByOutcomeTooltip.clickAndHold();
		Thread.sleep(2000);
		assertTrue(costAnalyticsPage.petitionCostsByOutcomeTooltipContent.isDisplayed(),"Tooltip doesnt have content");
	}

	//** CUMULATIVE PTAB PETITION COSTS BY STAGE TESTS **//*
	@Test(priority = 15, groups = {"P3", "petition_costs_by_stage"}, dataProvider = "costTypeDataForStageGraph", description = "Verify Petition Costs by Stage graph")
	public void verifyPetitionCostsbyStageGraph(String costType) throws Exception {		
		costAnalyticsPage.petitionCostsByStageCostTypeRadio.selectValue(costType);

		assertEquals(costAnalyticsPage.petitionCostsByStageTitle.getText().trim(), "Cumulative PTAB Petition Cost by Stage ($000s)", "Graph title");
		assertTrue(costAnalyticsPage.petitionCostsByStageChart.isDisplayed(), "Graph is not displayed");
	}
	@DataProvider
	public Object[][] costTypeDataForStageGraph() {
		return new Object[][] {
				{ "Per Petition" },
				{ "Per Cluster" }				
		};
	}

	@Test(priority = 16, groups = {"P3", "petition_costs_by_stage"}, description = "Verify Petition Costs by Stage graph tooltip")
	public void verifyPetitionCostsbyStageGraphTooltip() throws Exception {
		costAnalyticsPage.petitionCostsByStageTooltip.waitUntilVisible();
		costAnalyticsPage.petitionCostsByStageTooltip.clickAndHold();
		costAnalyticsPage.petitionCostsByStageTooltipContent.waitUntilVisible();
		assertTrue(costAnalyticsPage.petitionCostsByStageTooltipContent.isDisplayed(),"Tooltip doesnt have content");
	}
	
//	@Test(priority=17,groups = "petition_costs_by_stage",description="Verify About section in PTAB Cost Analytics")
//	public void verifyAboutSectionAtPTABCostAnalytics() throws Exception {
//		SoftAssert softAssert=new SoftAssert();
//		costAnalyticsPage.ptab_cost_analytics_about_section.waitUntilVisible();
//		softAssert.assertEquals(costAnalyticsPage.ptab_cost_analytics_about_section.getText(),"About Cost Analytics");
//		softAssert.assertTrue(costAnalyticsPage.ptab_cost_analytics_about_content.isDisplayed(),"About section content is not displayed");
//		withNewWindow(costAnalyticsPage.ptab_cost_analytics_about_overview,  () -> {
//			at(costAnalyticsOverview);
//		});
//
//		withNewWindow(costAnalyticsPage.ptab_cost_analytics_about_methodology,  () -> {
//			at(costAnalyticsMethodology);
//		});
//	}
	
//	@Test(priority=18,description="Verify Litigation Cost Analytics and Ptab Cost analytics links navigation at Overview Page")
//	public void checkCostAnalyticsLinksAtOverviewPage() throws Exception {
//		to(costAnalyticsOverview);
//		withNewWindow(costAnalyticsOverview.litigation_Cost_Analytics_Lnk,  () -> {
//			at(costAnalyticsPage);
//			Assert.assertEquals(costAnalyticsPage.searchPanelTabs.getActiveTabName(),"LITIGATION COST ANALYTICS");
//		});
//
//		withNewWindow(costAnalyticsOverview.ptab_Cost_Analytics_Lnk,  () -> {
//			at(costAnalyticsPage);
//			Assert.assertEquals(costAnalyticsPage.searchPanelTabs.getActiveTabName(),"PTAB COST ANALYTICS");
//		});
//	}
	
//	@Test(priority=18,description="Verify Litigation Cost Analytics and Ptab Cost analytics links navigation at Methodology Page")
//	public void checkCostAnalyticsLinksAtMethodologyPage() throws Exception {
//		to(costAnalyticsMethodology);
//		withNewWindow(costAnalyticsMethodology.litigation_Cost_Analytics_Lnk,  () -> {
//			at(costAnalyticsPage);
//			Assert.assertEquals(costAnalyticsPage.searchPanelTabs.getActiveTabName(),"LITIGATION COST ANALYTICS");
//		});
//
//		withNewWindow(costAnalyticsMethodology.ptab_Cost_Analytics_Lnk,  () -> {
//			at(costAnalyticsPage);
//			Assert.assertEquals(costAnalyticsPage.searchPanelTabs.getActiveTabName(),"PTAB COST ANALYTICS");
//		});
//	}
	
	private void assertMeanResolutionChartTrackers(Map<String, Boolean> actualStatus, boolean expLegalMarker, boolean expSettleMarker, boolean expNoDataStatus) 
			throws Exception {
		assertEquals(actualStatus.get("legal_cost"), expLegalMarker, "Legal data in graph");
		assertEquals(actualStatus.get("settlement_judgment_cost"), expSettleMarker, "Settlement or Judgment data in graph");
		assertEquals(actualStatus.get("no_data"), expNoDataStatus, "No data in graph");
	}	
}
