package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class PrivatePolicyPage extends BasePage {

    public PrivatePolicyPage() {
        this.url = new PageUrl("company/privacy-policy");
    }

    @Override
    public boolean at() {
        assertPageTitle("Privacy Policy");
        return effective_date.waitUntilVisible();
    }

    public final Element effective_date = $(".panel h5");

}
