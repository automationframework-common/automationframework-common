package com.rpxcorp.insight.page.account;

import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.By;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;

import java.util.HashMap;
import java.util.Map;

public class TierMatrixFeaturesViewPage extends BasePage {

	public TierMatrixFeaturesViewPage() {
		this.url = new PageUrl("admin/tier_matrices/{ID}");
	}

	@Override
	public boolean at() {

		return title.waitUntilVisible();
	}

	public final Element title = $(By.jquery("h5:contains('Feature information')"));
	public final Element learnMoreLink = $(By.jquery("a:contains('Learn More')"));
	public final StaticContent feature_info = $(By.jquery("h5:contains('Feature information')+table"), (Configure<StaticContent>) dataForm ->{
			dataForm.content("title","td:nth-child(1):contains(Title)+td");
			dataForm.content("tooltip_header","td:nth-child(1):contains(Tooltip header)+td");
			dataForm.content("tooltip_text","td:nth-child(1):contains(Tooltip text)+td");
//			dataForm.content("learnmore","td:nth-child(1):contains(Learn more link)+td");
			dataForm.content("feature_order","td:nth-child(1):contains(Feature order)+td");
	});
	public final StaticContent subscription_info = $(By.jquery("h5:contains('User subscription information')+table"), (Configure<StaticContent>) dataForm ->{
			dataForm.content("basic_available","td:nth-child(1):contains(Basic)+td");
			dataForm.content("basic_displaytext","td:nth-child(1):contains(Basic)+td+td");
			dataForm.content("plus_available","td:nth-child(1):contains(Plus)+td");
			dataForm.content("plus_displaytext","td:nth-child(1):contains(Plus)+td+td");
			dataForm.content("prime_available","td:nth-child(1):contains(Prime)+td");
			dataForm.content("prime_displaytext","td:nth-child(1):contains(Prime)+td+td");
			dataForm.content("elite_available","td:nth-child(1):contains(Elite)+td");
			dataForm.content("elite_displaytext","td:nth-child(1):contains(Elite)+td+td");
			dataForm.content("member_available","td:nth-child(1):contains(Member)+td");
			dataForm.content("member_displaytext","td:nth-child(1):contains(Member)+td+td");
	});

	public Map<String, String> getAllData(){
		Map<String, String> actualData = new HashMap<>();
		actualData.put("learnmore",learnMoreLink.getPartialLink().replace("/features#",""));
		actualData.putAll(feature_info.getData());
		actualData.putAll(subscription_info.getData());
		return actualData;
	}


}
