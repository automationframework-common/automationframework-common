package com.rpxcorp.insight.page.detail;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;

public class RpxPerspectivePage extends Page {

    public RpxPerspectivePage() {
        this.url = new PageUrl("rpx_perspectives");
    }

    @Override
    public boolean at() {
        return title.waitUntilVisible();
    }

    public final Element title = $(".columns h1");

}
