package com.rpxcorp.insight.page.detail;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;

public class NewsDetailPage extends Page {

    public NewsDetailPage() {
        this.url = new PageUrl("news/{ID}");
    }

    @Override
    public boolean at() {
        return related_newsheader.waitUntilVisible();
    }

    public final Element title = $("section#content h1");
    public final Element news_paragraph=$("#full_news_listing p:nth-of-type(1)");
    public final Element news_second_paragraph=$("#full_news_listing p:nth-of-type(2)");
    public final Element news_date=$("#full_news_listing .date");
    public final Element news_category=$("#full_news_listing .categories");
    public final Element related_newsheader=$("#recent_activity h2");
    public final Element related_news=$("#recent_activity li a");
    public final Element upgrade_PromoMsg=$("#full_news_listing a[href='/subscribe']");
    //public final Element loginrequired_PromoMsg=$("p:contains('Access to the full article is currently available to RPX members only.')");
    public final Element accessToFullArticlePromMsg = $("div:contains('Access to the full article is currently available to RPX members only.')");
    public final Element viewFullArticlePromMsg = $("#full_news_listing .view-more-button:contains('View full article with free 30-day trial'):contains('($79/month thereafter)')");
    public final Element muchMore=$("#full_news_listing a[href='/subscribe']:contains('much more')");
    public final Element upgradeItemList=$("#full_news_listing .list-items-for-upgrade li");
}
