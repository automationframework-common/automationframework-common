package com.rpxcorp.insight.page.search;

import com.rpxcorp.insight.page.detail.BaseDetailPage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class JudgesSearchPage extends BaseDetailPage{

    public JudgesSearchPage() {
        this.url = new PageUrl("advanced_search/search_judges");
    }

    @Override
    public boolean at() {
        waitForPageLoad();
        return currentSearch.waitUntilVisible();
    }

    public final Element judges_result_count = $("div.search-judges .count-info p");

    public int returnJudgesCount() throws Exception{
        int judgesCount=0;
        String[] countString = judges_result_count.getText().split("of");
        judgesCount = Integer.parseInt((countString[1]).replaceAll("[\\D]", "").trim());
        return judgesCount;
    }

}


