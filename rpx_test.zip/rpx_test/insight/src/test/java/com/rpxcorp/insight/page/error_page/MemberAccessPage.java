package com.rpxcorp.insight.page.error_page;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class MemberAccessPage extends BasePage {

    @Override
    public boolean at() {
        pageTitle.waitUntilVisible();
        newsArticles_restiction_msg.waitUntilVisible();
        return pageTitle.waitUntilTextPresent("Members Access");//("Members Access");
    }
    
    public final Element newsArticles_restiction_msg=$(".panel p");//.panel p a[href='mailto:insight@rpxcorp.com']
        }
