package com.rpxcorp.insight.page.features;

import com.rpxcorp.insight.module.Tabs;
import org.openqa.selenium.By;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class RoleFeaturesPage extends BasePage {
	
	public RoleFeaturesPage() {
        this.url = new PageUrl("features");
    }

	@Override
	public boolean at() {
		waitForLoading();
		return membershipFeaturesPanel.isDisplayed();
	}
	
	public final Element membershipFeaturesPanel = $("#membership_features .panel");
	public final Element listedOptions = $(".tab-title>a");
	public final Element contentTitle = $(".content.active h2");
	public final Element learnMoreLink_InAdvAlertTooltip=$(By.xpath("//span[@class='tooltip tip-right shown']//a[text()='Learn More']"));

	public final Tabs featureTabs = new Tabs("div#membership_features li.tab-title");
	public void clickFeature(String featureTitle) throws InterruptedException {

		$(By.xpath(".//*[@id='membership_features']//li/a[text()='" + featureTitle + "']")).scrollAndFocus();
		featureTabs.select(featureTitle);
		waitForLoading();		
		Thread.sleep(500);
	}
	
	public final Element contactUs_Lnk=$(By.xpath("//div[@class='insight-contact-us' and contains(text(),'For any')]/a[@href='mailto:insight@rpxcorp.com?subject=RPX Insight Feature Question']"));
	public final Element privacy_PolicyLink=$("#primary-footer .nav a[href*='terms-of-service']");
	public final Element features_InTopMenu=$(By.xpath("//*[@id='primary-nav']//a[text()='Features']"));
	public final Element page_Header_Title=$(".feature-heading");
}
