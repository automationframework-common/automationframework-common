package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.visual_analytics.CustomSectorAnalyticsPage;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.util.SQLProcessor;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

@Authenticate(role = "MEMBER")
public class CustomSectorAnalyticsTest extends BaseDataTest{
	CustomSectorAnalyticsPage marketAnalyticsPage;
	SQLProcessor sqlProcessor = SQLProcessor.getInstance();

	@BeforeClass
	public void loadPage() {
		this.dataDescription = "Market Sector Analytics";		
		to(marketAnalyticsPage);		
	}

	@BeforeGroups(groups = "lit_analytics")
	public void selectLitigationAnalyticsTab() {
		to(marketAnalyticsPage);
		marketAnalyticsPage.customSectorTabs.select("Litigations");
		marketAnalyticsPage.waitForLoading();
	}	

	@Test(priority = 1, groups = "lit_analytics", dataProvider = "getCampaignType", description = "Verify total defendants added in campaigns for all market sector")
	public void verifyDefendantsInCampaign(String campaignType, String fromDate, String toDate, String duration, String interval, String query, String labelvalue) throws SQLException, Exception {
		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("campaign_Type", campaignType);
		queryParams.put("from_date", fromDate);
		queryParams.put("to_date", toDate);
		queryParams.put("duration", duration);
		queryParams.put("t_interval", interval);

		marketAnalyticsPage.selectCampaignTypeYAxisValue(campaignType);

		marketAnalyticsPage.campaignDefendantTypeChart.getLabelElement("operating_company").waitUntilVisible();		

		assertEquals(marketAnalyticsPage.campaignDefendantTypeChart.getChartData("year", labelvalue), 
				sqlProcessor.getResultDataAsMultiMap(sqlProcessor.getResultData("MarketSectorAnalytics." + query, queryParams), "year", labelvalue));			
	}

	@DataProvider
	public Object[][] getCampaignType() {
		return new Object[][] { {"Total Defendants Added in Campaigns", "2017-01-01", "2017-12-31", "year", "1 year", "DEFENDANTS_NPE", "npe"} , 
				{"Total Defendants Added in Campaigns", "2017-01-01", "2017-12-31", "year", "1 year", "DEFENDANTS_OC", "operating_company"} ,
				{"Total Defendants Added in Campaigns", "2017-01-01", "2017-12-31", "year", "1 year", "DEFENDANTS_TOTAL", "total_count"} ,
				{"Unique Defendants Added in Campaigns", "2017-01-01", "2017-12-31", "year", "1 year", "UINIQUE_DEFENDANTS_NPE", "npe"},
				{"Unique Defendants Added in Campaigns", "2017-01-01", "2017-12-31", "year", "1 year", "UINIQUE_DEFENDANTS_OC", "operating_company"}, 
				{"Unique Defendants Added in Campaigns", "2017-01-01", "2017-12-31", "year", "1 year", "UINIQUE_DEFENDANTS_TOTAL", "total_count"}, 
				{"New Campaigns Filed", "2017-01-01", "2017-12-31", "year", "1 year", "NEW_CAMPAIGNS_NPE", "npe"},
				{"New Campaigns Filed", "2017-01-01", "2017-12-31", "year", "1 year", "NEW_CAMPAIGNS_OC", "operating_company"},
				{"New Campaigns Filed", "2017-01-01", "2017-12-31", "year", "1 year", "NEW_CAMPAIGNS_TOTAL", "total_count"}								
		};
	}
	
	//@Test(groups = "lit_analytics", dataProvider = "getVenuesData", description = "Verify total venues filed for year based on case type", priority = 2)
	public void verifyVenuesInCases(String from_date, String to_date, String condition, String top10_type, String case_type, String rank_type) throws SQLException, Exception {	
		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("from_date", from_date);
		queryParams.put("to_date", to_date);
		queryParams.put("condition", condition);
		
		marketAnalyticsPage.selectTop10CasesTypeInVenues(top10_type);
		marketAnalyticsPage.selectCasesTypeInVenues(case_type);	
		marketAnalyticsPage.rankByCaseType.click();
		
		ResultSet rs = sqlProcessor.getResultData("MarketSectorAnalytics.VENUES_IN_INFRINGEMENT_BY_CASES_BASE_QUERY", queryParams);
		assertEquals(marketAnalyticsPage.venuesInfringementAndDjCases.getChartData("npe_oc_court"),
				sqlProcessor.getResultDataAsMultiMap(rs, "court"));		
	}
	
	@DataProvider
	public Object[][] getVenuesData() {
		return new Object[][] {{"2010-01-01", "current_date", "npe_count", "Venues in Infringement Cases", "NPE", "Cases" }, 
								{"2010-01-01", "current_date", "op_count", "Venues in Infringement Cases", "Operating Company", "Cases"} 	
		};
	}

	@BeforeGroups(groups = "ptab_analytics")
	public void selectPTABAnalyticsTab() {
		to(marketAnalyticsPage);
		marketAnalyticsPage.customSectorTabs.select("PTAB");
		marketAnalyticsPage.waitForLoading();
	}

	@Test(groups = "ptab_analytics", dataProvider = "getPetitionData", description = "Verify total ptab cases count based on case type", priority = 3)
	public void verifyPTABCaseCount(String petition_type, String case_type, String db_case, String db_party, String queryKeys) throws SQLException, Exception {	
		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("party_type", db_party);
		queryParams.put("case_type", db_case);

		marketAnalyticsPage.selectTopPetitionsBasedOnCaseType(petition_type, case_type);		

		ResultSet rs = sqlProcessor.getResultData("MarketSectorAnalytics." + queryKeys, queryParams);
		assertEquals(marketAnalyticsPage.petitionCountBasedOnCaseType.getChartData("company"),
				sqlProcessor.getResultDataAsMultiMap(rs, "company", "npe_oc_count", "npe_oc_total"));
	}

	@DataProvider
	public Object[][] getPetitionData() {
		return new Object[][] {{"IPR Petitioners", "NPE", "IPR", "Petitioner", "TOP_10_NPE_PETITIONERS"}, 
				{"IPR Petitioners", "Operating Company", "IPR", "Petitioner", "TOP_10_OPERATING_COMPANY_PETITIONERS"}, 
				{"IPR Patent Owners", "NPE", "IPR", "Patent Owner", "TOP_10_NPE_PATENT_OWNERS"}, 
				{"IPR Patent Owners", "Operating Company", "IPR", "Patent Owner", "TOP_10_OPERATING_PATENT_OWNERS"},	
				{"CBM Petitioners", "NPE", "CBM", "Petitioner", "TOP_10_NPE_PETITIONERS"}, 
				{"CBM Petitioners", "Operating Company", "CBM", "Petitioner", "TOP_10_OPERATING_COMPANY_PETITIONERS"},
				{"CBM Patent Owners", "NPE", "CBM", "Patent Owner", "TOP_10_NPE_PATENT_OWNERS"}, 
				{"CBM Patent Owners", "Operating Company", "CBM", "Patent Owner", "TOP_10_OPERATING_PATENT_OWNERS"}							
		};
	}
	
	@Test(groups = "ptab_analytics", dataProvider = "getPetitionFiledData", description = "Verify total petitions filed for year based on case type", priority = 4)
	public void verifyPetitionsFiled(String from_date, String case_type, String petition_type, String query_Key) throws SQLException, Exception {	
		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("from_date", from_date);
		queryParams.put("case_type", case_type);
		
		marketAnalyticsPage.selectPetitionsTypeFiledForYear(petition_type);	
		
		ResultSet rs = sqlProcessor.getResultData("MarketSectorAnalytics." + query_Key , queryParams);
		assertEquals(marketAnalyticsPage.petitionFiled.getChartData("year"),
				sqlProcessor.getResultDataAsMultiMap(rs, "year", "total", "npe", "oc"));		
	}
	
	@DataProvider
	public Object[][] getPetitionFiledData() {
		return new Object[][] {{"2017-01-01", "IPR", "IPR Petitions Filed", "PETITIONS_FILED_FOR_YEARS"}, 
								{"2017-01-01", "CBM", "CBM Petitions Filed", "PETITIONS_FILED_FOR_YEARS"},
								{"2017-01-01", "IPR", "Unique Patents in IPR Petitions", "UNIQUE_PATENTS_IN_PETITIONS_FILED_FOR_YEARS"}, 
								{"2017-01-01", "CBM", "Unique Patents in CBM Petitions", "UNIQUE_PATENTS_IN_PETITIONS_FILED_FOR_YEARS"}		
		};
	}	
	
	@BeforeGroups(groups = "patentsAnalytics")
	public void selectPatentAnalyticsTab() {
		to(marketAnalyticsPage);
		marketAnalyticsPage.customSectorTabs.select("Patents");
		marketAnalyticsPage.waitForLoading();
	}
	
	@Test(groups = "patentsAnalytics", dataProvider = "getFilersGranteesData", description = "Verify top 10 filers and grantees of patents", priority = 7)
	public void verifyFilersGranteesOfPatents(String patent_type, String from_date, String to_date, String db_from_date, 
			String db_to_date, String query_key, String cpc_description, String market_sector) throws SQLException, Exception {
		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("from_date", db_from_date);
		queryParams.put("to_date", db_to_date);
		queryParams.put("cpc_description", cpc_description);
		queryParams.put("market_sector", market_sector);
		
		marketAnalyticsPage.selectCustomMarketSectorTypes(market_sector);
		marketAnalyticsPage.selectFromToDate(from_date, to_date);
		marketAnalyticsPage.customSectorTabs.select("Patents");
		marketAnalyticsPage.selectPatentTypeFilersGrantees(patent_type);
		
		ResultSet rs = sqlProcessor.getResultData("MarketSectorAnalytics." + query_key, queryParams);
		assertEquals(marketAnalyticsPage.patentsTop10FilersGrantees.axisLabelValues("ent_name"),
				sqlProcessor.getResultDataAsMultiMap(rs, "ent_name", "total"));		
	}
		
	@DataProvider
	public Object[][] getFilersGranteesData() {
		return new Object[][] {{"Filers", "01/01/2017", "01/31/2017", "2017-01-01", "2017-01-31", "FILERS_WITH_DATE_AND_CPC_FILTER", "A01D", "Testing"}, 	
							    {"Grantees", "01/15/2017", "01/30/2017", "2017-01-15", "2017-01-30", "GRANTEES_WITH_DATE_FILTER", "A01D", "Testing"},
								 {"Assignees of Patents Offered for Sale", "03/01/2017", "03/15/2017", "2017-03-01", "2017-03-15", "ASSIGNEES_OF_PATENTS_WITH_DATE_FILTER"},
								  {"Brokers of Patents Offered for Sale", "03/15/2017", "03/30/2017", "2017-03-15", "2017-03-30", "BROKERS_OF_PATENTS_WITH_DATE_FILTER"}							      
		};
	}
	 
	@Test(groups = "ptab_analytics", dataProvider = "getAgeLengthPatentData", description = "Verify age, length, petition, institution, final decision of petitions", priority = 8)
	public void verifyAgeLengthOfPatents(String status_type, String from_date, String to_date, String db_from_date, String db_to_date, String query_key) throws Exception {
		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("from_date", db_from_date);
		queryParams.put("to_date", db_to_date);
		
		marketAnalyticsPage.selectFromToDate(from_date, to_date);
		marketAnalyticsPage.customSectorTabs.select("PTAB");
		marketAnalyticsPage.selectAgeLengthOfPatent(status_type);
		
		ResultSet rs = sqlProcessor.getResultData("MarketSectorAnalytics." + query_key, queryParams);		
		assertEquals(marketAnalyticsPage.ageOfChallengedPatent.getChartData("year", "npe", "oc", "total"),
				sqlProcessor.getResultDataAsMultiMap(rs, "year", "npe", "oc", "total"));	
	}
	
	@DataProvider
	public Object[][] getAgeLengthPatentData() {
		return new Object[][] {{"Age of Challenged Patent", "01/01/2015", "01/15/2015", "2015-01-01", "2015-01-15", "AGE_OF_CHALLENGED_PATENT"}							    							      
		};
	}
}
