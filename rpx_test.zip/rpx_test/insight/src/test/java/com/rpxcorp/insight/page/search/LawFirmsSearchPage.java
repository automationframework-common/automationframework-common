package com.rpxcorp.insight.page.search;

import com.rpxcorp.insight.page.detail.BaseDetailPage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class LawFirmsSearchPage extends BaseDetailPage{

    public LawFirmsSearchPage() {
        this.url = new PageUrl("advanced_search/search_lawfirms");
    }

    @Override
    public boolean at() {
        waitForPageLoad();
        return currentSearch.waitUntilVisible();
    }

    public final Element lawfirm_result_count = $("div.search-lawfirms .count-info p");

    public int returnLawfirmsCount() throws Exception{
        int judgesCount=0;
        String[] countString = lawfirm_result_count.getText().split("of");
        judgesCount = Integer.parseInt((countString[1]).replaceAll("[\\D]", "").trim());
        return judgesCount;
    }

}


