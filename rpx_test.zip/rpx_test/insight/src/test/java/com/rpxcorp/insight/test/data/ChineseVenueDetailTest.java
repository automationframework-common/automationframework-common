package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.detail.ChineseVenueDetailPage;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.TableData;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.util.Map;

@Authenticate(role = "MEMBER")
@Test(groups = "Venue")
public class ChineseVenueDetailTest extends BaseDataTest{

    ChineseVenueDetailPage chineseVenueDetailPage;
    TableData tableData;
    Map<String, String> staticData;

    /* TEST CONFIGURATIONS */
    @Factory(dataProvider = "returnData")
    public ChineseVenueDetailTest(String dataDescription, String chJudId) throws Exception {
        this.dataDescription = dataDescription;
        this.dataId = getPageId(chJudId);
    }

    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("ChineseVenueDetail");
    }

    @BeforeClass
    public void loadPage() {
        this.urlData.put("ID", dataId);
        this.dataUrl = chineseVenueDetailPage.getDeclaredUrl(urlData);
        to(chineseVenueDetailPage, urlData);
    }
    @Test(description = "Verify Title")
    public void verifyTitle() throws Exception {
        assertEquals(chineseVenueDetailPage.pageTitle.getData(),
                sqlProcessor.getSinglResultValue("ChineseVenueDetail.TITLE", dataId));
    }

    @Test(description = "Verify inactive cases in Stats bar")
    public void verifyInactiveCasesCountInStats() throws Exception {
        assertEquals(chineseVenueDetailPage.metricsSection.getData("Inactive Cases"),
                sqlProcessor.getResultCount("ChineseVenueDetail.LITIGATIONS_INACTIVE", dataId));
    }

    @Test(description = "Verify count at Litigation section")
    public void verifyCaseCountAtLitigationSection() throws Exception {
        chineseVenueDetailPage.litigationCasesCount.waitUntilVisible();
        assertEquals(chineseVenueDetailPage.litigationCasesCount.getIntData(),
                sqlProcessor.getResultCount("ChineseVenueDetail.LITIGATIONS_ALL", dataId));
    }

    @Test(description = "Verify cases data in Litigaton section")
    public void verifyInactiveCases() throws Exception {
        assertEquals(chineseVenueDetailPage.LITIGATION_TABLE.getData(),
                sqlProcessor.getResultData("ChineseVenueDetail.LITIGATIONS_ALL", dataId));
    }

    /*@Test(description = "RPX-14930 | Verify Cases By Market Sector data in Litigaton section | RPX-14670")
    public void verifyCasesByMarketSector() throws Exception {
        assertEquals(chineseVenueDetailPage.cases_By_Market_Sector.getData(),
                sqlProcessor.getResultData("ChineseVenueDetail.CASES_BY_MARKET_SECTOR", dataId));
    }*/

    @Test(description = "Verify Venue Profile Outcome")
    public void verifyVenueOutCome() throws Exception{
        assertEquals(chineseVenueDetailPage.venue_Profile_Outcome.getData(),
                sqlProcessor.getResultData("ChineseVenueDetail.PROFILE_OUTCOME", dataId));
    }

    @Test(description = "Verify Venue Profile INJUNCTIONS_ON_PLAINTIFF_WIN")
    public void verifyVenueProfileInjunctions() throws Exception{
        assertEquals(chineseVenueDetailPage.venue_Profile_Injunctions.getData(),
                sqlProcessor.getResultData("ChineseVenueDetail.INJUNCTIONS_ON_PLAINTIFF_WIN", dataId));
    }

    @Test(description = "Verify Venue Profile APOLOGIES_ON_PLAINTIFF_WIN")
    public void verifyVenueProfileApologies() throws Exception{
        assertEquals(chineseVenueDetailPage.venue_Profile_Apologies.getData(),
                sqlProcessor.getResultData("ChineseVenueDetail.APOLOGIES_ON_PLAINTIFF_WIN", dataId));
    }
}
