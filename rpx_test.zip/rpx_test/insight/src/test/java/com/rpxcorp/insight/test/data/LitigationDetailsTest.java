package com.rpxcorp.insight.test.data;

import java.sql.ResultSet;
import java.util.Map;

import com.rpxcorp.testcore.Authenticate;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import com.rpxcorp.insight.page.detail.LitigationDetailPage;
import com.rpxcorp.testcore.TableData;
@Authenticate(role = "MEMBER")
@Test(groups = {"Lits","DistrictCourt"})
public class LitigationDetailsTest extends BaseDataTest {
    LitigationDetailPage litigationDetailPage;
    TableData tableData;
    Map<String, String> staticData;
    ResultSet resultSet, accusedProducts;

    /* TEST CONFIGURATIONS */
    @Factory(dataProvider = "returnData")
    public LitigationDetailsTest(String dataDescription, String litId) throws Exception {
        this.dataDescription = dataDescription;
        this.dataId = getPageId(litId);
    }

    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("LitigationDetail");
    }

    @BeforeClass
    public void loadPage() {
        this.urlData.put("ID", dataId);
        this.dataUrl = litigationDetailPage.getDeclaredUrl(urlData);
        to(litigationDetailPage, urlData);
    }



    @Test(description = "Verify Header Details")
    public void Header_Detail() throws Exception {
        assertEquals(litigationDetailPage.header_info.getData(),
                sqlProcessor.getResultData("LitigationDetail.HEADER_DETAILS", dataId));
    }

   /*
    @Test(description = "Verify Header Details")
    public void Header_Detail() throws Exception {
        staticData = litigationDetailPage.header_info.getData();
        staticData.put("title", (String) litigationDetailPage.title.getData());
        assertEquals(staticData, sqlProcessor.getResultData("LitigationDetail.HEADER_DETAILS", dataId));
    }*/

    @Test(description = "Verify Overview Details")
    public void Overview_Detail() throws Exception {
        assertEquals(litigationDetailPage.overview_panel.getData(),
                sqlProcessor.getResultData("LitigationDetail.OVERVIEW_DETAILS", dataId));
    }

    @Test(description = "Verify the latest complaint is displayed in view complaint")
    public void latestComplaintDocument() throws Exception {
        assertEquals(litigationDetailPage.getComplaintNumber(),
                sqlProcessor.getSinglResultValue("LitigationDetail.COMPLAINT_FILED_DOCUMENT_ID", dataId));
    }

    @Test(description = "Verify campaign status")
    public void Campaign_Status() throws Exception {
        assertEquals(litigationDetailPage.campaign_status.getData(),
                sqlProcessor.getResultData("LitigationDetail.CAMP_STATUS", dataId), "status");
    }

    @Test(description = "Verify Plaintiff count", priority = 1)
    public void Plaintiff_Count() throws Exception {
        resultSet = sqlProcessor.getResultData("LitigationDetail.PLAINTIFF_COUNSEL_INFO", dataId);
        assertEquals(litigationDetailPage.plaitiff_count.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    @Test(description = "Verify Plaintiff details and Counsel Information", priority = 2)
    public void Plaintiff_Detail_Counsel_Information() throws Exception {
        assertEquals(litigationDetailPage.PLAINTIFF_PARTIES.getData(), resultSet);
    }

    @Test(description = "Verify Defendant count", priority = 3)
    public void Defendant_Count() throws Exception {
        resultSet = sqlProcessor.getResultData("LitigationDetail.DEFENDANT_COUNT", dataId);
        assertEquals(litigationDetailPage.defendant_count.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    @Test(description = "Verify Defendant details and Counsel Information", priority = 4)
    public void Defendant_Detail_Counsel_Information() throws Exception {
        assertEquals(litigationDetailPage.DEFENDANT_PARTIES.getData(),
                sqlProcessor.getResultData("LitigationDetail.DEFENDANT_COUNSEL_INFO", dataId));
    }

    @Test(description = "Verify Other Parties count", priority = 5)
    public void Other_Parties_Count() throws Exception {
        resultSet = sqlProcessor.getResultData("LitigationDetail.OTHERS_COUNSEL_INFO", dataId);
        assertEquals(litigationDetailPage.other_parties_count.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    @Test(description = "RPX-10223 || Verify Other Parties details and Counsel Information", priority = 6)
    public void Other_Parties_Detail_Counsel_Information() throws Exception {
        assertEquals(litigationDetailPage.OTHER_PARTIES.getData(), resultSet);
    }

    @Test(description = "Verify Accused Product count", priority = 5)
    public void Accused_Product_Count() throws Exception {
        accusedProducts = sqlProcessor.getResultData("LitigationDetail.ACCUSED_PRODUCT_INFO", dataId);
        assertEquals(litigationDetailPage.accused_product_count.getIntData(),
                sqlProcessor.getResultCount(accusedProducts));
    }

    @Test(description = "Verify Accused Product Information", priority = 6)
    public void Accused_Product_Information() throws Exception {
        assertEquals(litigationDetailPage.accused_product_section.getData(), accusedProducts);
    }

    @Test(description = "Verify Patents In Suit count", priority = 7)
    public void Patents_In_Suit_Count() throws Exception {
        resultSet = sqlProcessor.getResultData("LitigationDetail.PATS_IN_SUIT", dataId);
        assertEquals(litigationDetailPage.patent_in_suitTabLink.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    @Test(description = "Verify Patents in Suit in Patent Information Section", priority = 8)
    public void Patents_In_Suit() throws Exception {
        assertEquals(litigationDetailPage.PATENT_TABLE.getData(), resultSet);
    }

    @Test(description = "Verify Petitions count", priority = 9)
    public void Petitions_Count() throws Exception {
        resultSet = sqlProcessor.getResultData("LitigationDetail.PETITIONS", dataId);
        assertEquals(litigationDetailPage.petitionTabLink.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    @Test(description = "Verify Petitions in Patent Information Section", priority = 10)
    public void Petitions() throws Exception {
        assertEquals(litigationDetailPage.PETITION_TABLE.getData(), resultSet);
    }

    @Test(description = "Verify Case Count in Litigation Campaign Section", priority = 11)
    public void Case_Count_in_Litigation_Campaign() throws Exception {
        resultSet = sqlProcessor.getResultData("LitigationDetail.CAMPAIGN_REL_LITS_COUNT", dataId);
        assertEquals(litigationDetailPage.caseTabLink.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    @Test(description = "Verify Cases in Litigation Campaign Section", priority = 12)
    public void Litigation_Campaign_Case() throws Exception {
        resultSet = sqlProcessor.getResultData("LitigationDetail.CAMPAIGN_REL_LITS", dataId);
        assertEquals(litigationDetailPage.litigation_cases.getData(), resultSet, "date_filed", "case_name",
                "case_number", "termination_date");
    }

    @Test(description = "Verify Patent Count in Litigation Campaign Section", priority = 13)
    public void Patent_Count_in_Litigation_Campaign() throws Exception {
        resultSet = sqlProcessor.getResultData("LitigationDetail.CAMPAIGN_REL_PATS", dataId);
        assertEquals(litigationDetailPage.patentsTabLink.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    @Test(description = "Verify Patents in Litigation Campaign Section", priority = 14)
    public void Litigation_Campaign_Patents() throws Exception {
        litigationDetailPage.selectPatentTab();
        assertEquals(litigationDetailPage.patentInLitigationCampaign.getData(), resultSet);
    }

    @Test(description = "Verify Accused Products in Litigation Campaign Section", priority = 15)
    public void Litigation_Campaign_Accused_Products() throws Exception {
        litigationDetailPage.selectAccusedProductTab();
        assertEquals(litigationDetailPage.patent_accused_table.getData(),
                sqlProcessor.getResultData("LitigationDetail.CAMPAIGN_ACCUSEDPRODUCTS", dataId));
    }

    @Test(description = "Verify Defendant Count in Litigation Campaign Section", priority = 16)
    public void Defendant_Count_in_Litigation_Campaign() throws Exception {
        resultSet = sqlProcessor.getResultData("LitigationDetail.CAMPAIGN_DEFENDANTS", dataId);
        assertEquals(litigationDetailPage.defendantsTabLink.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    @Test(description = "Verify Defendants in Litigation Campaign Section", priority = 17)
    public void Defendants_in_Litigation_Campaign() throws Exception {
        litigationDetailPage.selectDefendantTab();
        assertEquals(litigationDetailPage.defendant_table.getData(), resultSet);
    }

    @Test(description = "Verify Defendants Sub Table in Litigation Campaign Section", priority = 18)
    public void Defendants_SubTable_in_Litigation_Campaign() throws Exception {
        litigationDetailPage.expandAlldefandant();
        assertEquals(litigationDetailPage.defendant_table.getSubtableData(),
                sqlProcessor.getResultData("LitigationDetail.CAMPAIGN_DEFENDANTS_SUBTABLE", dataId));
    }

    @Test(description = "Verify days in litigation count in stats", priority = 1)
    public void daysInLitigationCount() throws Exception {
        staticData = litigationDetailPage.metricsSection.getData();
        assertEquals(staticData.get("dayInLitCount"),
                sqlProcessor.getSingleValue(sqlProcessor.getResultData("LitigationDetail.DAYS_IN_LITIGATION", dataId), "days_in_litigation"));
    }

    @Test(description = "Verify plaintiff count in stats", priority = 1)
    public void plaintiffCount() throws Exception {
        assertEquals(staticData.get("plaintiffCount"),
                sqlProcessor.getResultCount(sqlProcessor.getResultData("LitigationDetail.PLAINTIFF_STATS_COUNT", dataId)));
    }

    @Test(description = "Verify defendant count in stats", priority = 1)
    public void defendantCount() throws Exception {
        assertEquals(staticData.get("defendantCount"),
                sqlProcessor.getResultCount(sqlProcessor.getResultData("LitigationDetail.DEFENDANT_COUNT", dataId)));
    }

    @Test(description = "Verify patent in suit product count in stats", priority = 1)
    public void patentInSuitCount() throws Exception {
        assertEquals(staticData.get("patentInSuitCount"),
                sqlProcessor.getResultCount(sqlProcessor.getResultData("LitigationDetail.PATS_IN_SUIT", dataId)));
    }

    @Test(description = "Verify docket entry count in stats", priority = 1)
    public void docketEntriesCount() throws Exception {
        assertEquals(staticData.get("docketEntriesCount"),
                sqlProcessor.getResultCount(sqlProcessor.getResultData("LitigationDetail.DOCKETS_CNT", dataId)));
    }

    @Test(description = "Verify accused product count in stats", priority = 1)
    public void accusedProductCount() throws Exception {
        accusedProducts = sqlProcessor.getResultData("LitigationDetail.ACCUSED_PRODUCT_INFO", dataId);
        assertEquals(litigationDetailPage.metricsSection.getData("accusedProductCount"),
                sqlProcessor.getResultCount(accusedProducts));
    }

    @Test(description = "Verify Docket Entries Count", priority = 19)
    public void Docket_Entries_Count() throws Exception {
        resultSet = sqlProcessor.getResultData("LitigationDetail.DOCKETS_CNT", dataId);
        assertEquals(litigationDetailPage.docket_entries_count.getIntData(), sqlProcessor.getResultCount(resultSet));
    }

    // TODO: will take it later with pagination
    @Test(description = "Litigation Docket Entries", priority = 20)
    public void DocketEntries() throws Exception {
        litigationDetailPage.docket_entries.viewAll();
        assertEquals(litigationDetailPage.docket_entries.getData(),
                sqlProcessor.getResultData("LitigationDetail.DOCENTRIES_IN_LIT", dataId));
    }
}