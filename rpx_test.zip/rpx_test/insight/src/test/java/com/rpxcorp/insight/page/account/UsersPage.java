package com.rpxcorp.insight.page.account;

import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.detail.BaseDetailPage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class UsersPage extends BaseDetailPage {

    public UsersPage() {
        this.url = new PageUrl("admin/users");
    }

    @Override
    public boolean at() {
        return userList_Table.waitUntilVisible();
    }

    public final Element email_field = $(By.id("q_email_cont"));
    public final Element filter_button = $("#user_search > input[value='Filter']");
    public final Element createBulkUser_Btn = $(".button[href*=bulk_users]");
    public final Element create_newUser=$("a[href='/admin/users/new']");

    public final Table userList_Table = $(".large-9.columns table", (Configure<Table>) table ->
        {
            table.uniqueId("td:nth-child(1) a");
        }
    );

    public final Element userList_userCount = $("div[data-target-list]>h4");


    public final Element userRole = $("div#s2id_q_user_roles_id_eq a");
    public final Element userRoleInput = $("input#s2id_autogen2_search");
    public final Element userRoleAutoList = $("ul#select2-results-2 li:nth-of-type(1)");
    public final Element userEditButton = $(By.xpath("//*[@id='users_list']//td/a[text()='Edit']"));
    public final Element userNameLink=$("#users_list tr>td> span >a");

    public final Element auto_member_table_click = $("#users_list td a");

    public void searchUserByMemberRole(){
        email_field.sendKeys("auto_member@rpxcorp.com");
        filter_button.click();
        auto_member_table_click.click();
    }


    public void searchUserByEmail(String mailId) {
        email_field.sendKeys(mailId);
        filter_button.click();
    }

    public void searchUserByRole(String roleName) {
        userRole.click();
        userRoleInput.waitUntilVisible();
        userRoleInput.sendKeys(roleName);
        userRoleAutoList.waitUntilVisible();
        userRoleAutoList.click();
        filter_button.click();
        userList_Table.waitUntilVisible();
    }

    public void clickOnNameLinkBasedOnRole(String role) {
        String xpath = String.format("//*[@id='users_list']//td[text()='%s']/../td/span/a", role);
        WebElement name_lnk = $(By.xpath(xpath));
        name_lnk.click();
    }
    
    public void selectFilter(String filterName) {
    	String jquery=String.format("div.checkboxes:has(label:contains(%s)) input[type=checkbox]", filterName);
    	if(!$(jquery).isSelected()) {
    		$(jquery).click();
    		$(jquery).waitUntilElementSelected();
    	}
    }
    
    public String getUserRoleFromResultsTable() {
    	userList_Table.waitUntilVisible();
    	return $("#users_list>tr>td:nth-of-type(4)").getText();
    }


}
