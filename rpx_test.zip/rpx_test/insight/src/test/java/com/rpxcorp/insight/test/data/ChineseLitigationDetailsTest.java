package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.detail.ChineseLitigationDetailPage;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.TableData;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

@Authenticate(role = "MEMBER")
@Test(groups = {"Lits","China"})
public class ChineseLitigationDetailsTest extends BaseDataTest {

    ChineseLitigationDetailPage chineseLitigationDetailPage;
    TableData tableData;
    Map<String, String> staticData;

    /* TEST CONFIGURATIONS */
    @Factory(dataProvider = "returnData")
    public ChineseLitigationDetailsTest(String dataDescription, String chLitId) throws Exception {
        this.dataDescription = dataDescription;
        this.dataId = getPageId(chLitId);
    }

    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("ChineseLitigationDetail");
    }

    @BeforeClass
    public void loadPage() {
        this.urlData.put("ID", dataId);
        this.dataUrl = chineseLitigationDetailPage.getDeclaredUrl(urlData);
        to(chineseLitigationDetailPage, urlData);
    }

    @Test(description = "Verify Title")
    public void verifyTitle() throws Exception {
        assertEquals(chineseLitigationDetailPage.title.getData(),
                sqlProcessor.getSinglResultValue("ChineseLitigationDetail.TITLE", dataId));
    }

    @Test(description = "Verify Header Details")
    public void headerDetails() throws Exception {
        assertEquals(chineseLitigationDetailPage.headerDetails.getData(),
                sqlProcessor.getResultData("ChineseLitigationDetail.HEADER_DETAILS", dataId));
    }

    @Test(description = "RPX-14284 || Verify days in litigation count in stats", priority = 1)
    public void daysInLitigationCount() throws Exception {
        staticData = chineseLitigationDetailPage.metricsSection.getData();
        assertEquals(staticData.get("dayInLitCount"),
                sqlProcessor.getSinglResultValue("ChineseLitigationDetail.DAYS_IN_LITIGATION", dataId));
    }

    @Test(description = "Verify plaintiff count in stats", priority = 1)
    public void plaintiffCount() throws Exception {
        assertEquals(staticData.get("plaintiffCount"),
                sqlProcessor.getSinglResultValue("ChineseLitigationDetail.PLAINTIFF_COUNT", dataId));
    }

    @Test(description = "Verify defendant count in stats", priority = 1)
    public void defendantCount() throws Exception {
        assertEquals(staticData.get("defendantCount"),
                sqlProcessor.getSinglResultValue("ChineseLitigationDetail.DEFENDANT_COUNT", dataId));
    }

    @Test(description = "Verify patent in suit product count in stats", priority = 1)
    public void patentInSuitCount() throws Exception {
        assertEquals(staticData.get("patentInSuitCount"),
                sqlProcessor.getSinglResultValue("ChineseLitigationDetail.PATENT_IN_SUIT_COUNT", dataId));
    }

    @Test(description = "Verify patent in suit in patent information section", priority = 1)
    public void patentInSuitInformation() throws Exception {
        assertEquals(chineseLitigationDetailPage.patentInSuit.getData(),
                sqlProcessor. getResultData("ChineseLitigationDetail.PATENT_IN_SUIT_INFORMATION", dataId));
    }

    @Test(description = "Verify plaintiff parties", priority = 1)
    public void plaintiffParties() throws Exception {
        assertEquals(chineseLitigationDetailPage.plaintiffPartiesContent.getData(),
                sqlProcessor.getResultData("ChineseLitigationDetail.PLAINTIFF_PARTIES", dataId));
    }

    @Test(description = "Verify defendant parties", priority = 1)
    public void defendantParties() throws Exception {
        assertEquals(chineseLitigationDetailPage.defendantPartiesContent.getData(),
                sqlProcessor.getResultData("ChineseLitigationDetail.DEFENDANT_PARTIES", dataId));
    }

    @Test(description = "Verify plaintiff counsel informations", priority = 1)
    public void plaintiffCounselInformation() throws Exception {
        assertEquals(chineseLitigationDetailPage.plaintiffCounselPartiesContent.getData(),
                sqlProcessor.getResultData("ChineseLitigationDetail.PLAINTIFF_COUNSEL", dataId));
    }

    @Test(description = "Verify defendant counsel informations", priority = 1)
    public void defendantCounselInformation() throws Exception {
        assertEquals(chineseLitigationDetailPage.defendantCounselPartiesContent.getData(),
                sqlProcessor.getResultData("ChineseLitigationDetail.DEFENDANT_COUNSEL", dataId));
    }

    @Test(description = "Verify case type", priority = 1)
    public void caseType() throws Exception {
        assertEquals(chineseLitigationDetailPage.overviewContent.getData("caseType"),
                sqlProcessor.getSingleValue(sqlProcessor.getResultData("ChineseLitigationDetail.OVERVIEW_SECTION", dataId), "case_type"));
    }

    @Test(description = "Verify court", priority = 1)
    public void courtName() throws Exception {
        assertEquals(chineseLitigationDetailPage.overviewContent.getData("court"),
                sqlProcessor.getSingleValue(sqlProcessor.getResultData("ChineseLitigationDetail.OVERVIEW_SECTION", dataId), "court"));
    }

    @Test(description = "Verify judge", priority = 1)
    public void judgeName() throws Exception {
        assertEquals(chineseLitigationDetailPage.overviewContent.getData("judge"),
                sqlProcessor.getResultData("ChineseLitigationDetail.OVERVIEW_SECTION", dataId), "judge");
    }

/*
    @Test(description = "Verify market sector", priority = 1)
    public void marketSector() throws Exception {
        assertEquals(chineseLitigationDetailPage.overviewContent.getData("marketSector"),
                sqlProcessor.getSingleValue(sqlProcessor.getResultData("ChineseLitigationDetail.OVERVIEW_SECTION", dataId), "market_sector"));
    }
*/

    @Test(description = "Verify court attitude", priority = 1)
    public void courtAttitude() throws Exception {
        assertEquals(chineseLitigationDetailPage.courtAttitudeValue(),
                sqlProcessor.getSingleValue(sqlProcessor.getResultData("ChineseLitigationDetail.OVERVIEW_SECTION", dataId), "court_attitude"));
    }

    @Test(description = "Verify dispute level", priority = 1)
    public void disputeLevel() throws Exception {
        assertEquals(chineseLitigationDetailPage.overviewContent.getData("disputeLevel"),
                sqlProcessor.getSingleValue(sqlProcessor.getResultData("ChineseLitigationDetail.OVERVIEW_SECTION", dataId), "dispute_level"));
    }

    @Test(description = "Verify first instance outcome", priority = 2)
    public void firstInstanceOutcome() throws Exception {
        if(chineseLitigationDetailPage.firstInstanceOutomeContent.isDisplayed()) {
            assertEquals(chineseLitigationDetailPage.firstInstanceOutomeContent.getData(),
                    sqlProcessor.getResultData("ChineseLitigationDetail.FIRST_INSTANCE_OUTCOME", dataId));
        } else {
            assertEquals(0,sqlProcessor.getResultCount("ChineseLitigationDetail.FIRST_INSTANCE_OUTCOME", dataId));
        }
    }

    @Test(description = "Verify second instance outcome", priority = 2)
    public void secondInstanceOutome() throws Exception {
        Map<String, String> map = new HashMap<>();
        if(chineseLitigationDetailPage.secondInstanceOutomeContent.isDisplayed()) {
            assertEquals(chineseLitigationDetailPage.secondInstanceOutomeContent.getData(),
                    sqlProcessor.getResultData("ChineseLitigationDetail.SECOND_INSTANCE_OUTCOME", dataId));
        } else {
            assertEquals(0,sqlProcessor.getResultCount("ChineseLitigationDetail.SECOND_INSTANCE_OUTCOME", dataId));
        }
    }

    @Test(description = "Verify judgement document URL", priority = 2)
    public void judgementDocumentUrl() throws Exception {
        assertEquals(chineseLitigationDetailPage.getJudgementDocumentNumber(),
               sqlProcessor.getSinglResultValue("ChineseLitigationDetail.ENGLISH_JUDGEMENT",dataId));
        chineseLitigationDetailPage.changeChineseToggle();
        assertEquals(chineseLitigationDetailPage.getJudgementDocumentNumber(),
               sqlProcessor.getSinglResultValue("ChineseLitigationDetail.CHINESE_JUDGEMENT",dataId));
        chineseLitigationDetailPage.changeChineseToggle();
    }
}
