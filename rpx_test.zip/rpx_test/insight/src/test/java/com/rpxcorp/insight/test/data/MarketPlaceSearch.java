package com.rpxcorp.insight.test.data;

import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.search.MarketPlaceSearchPage;
@Authenticate(role = "MEMBER")
public class MarketPlaceSearch extends BaseDataTest {
    MarketPlaceSearchPage marketPlaceSearchPage;
    String marketPlaceSearchText;
    Table tableData;
    Map<String, String> staticData;
    ResultSet resultSet;

    @Factory(dataProvider = "returnData")
    public MarketPlaceSearch(String dataDescription, String searchText) {
        this.dataDescription = dataDescription;
        this.dataId = searchText;
        this.marketPlaceSearchText = searchText;
    }

    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("MarketPlaceSearch");
    }

    @BeforeClass
    public void loadPage() {
        this.urlData.put("CURRENT SEARCH", dataId);
        this.dataUrl = marketPlaceSearchPage.getDeclaredUrl(urlData);
        to(marketPlaceSearchPage, urlData);
    }

    @Test(description = "Verify number of Acquisitions After Search")
    public void check_Acquisition_Count() throws Exception {
        List<String> ids = marketPlaceSearchPage.search_result_header_data.getUniqueId_Values();
        assertEquals(marketPlaceSearchPage.acquisition_opportunities_count.getData(),
                sqlProcessor.getResultData("MarketPlaceSearch.ACQUISITION_COUNT", ids));
    }

    @Test(description = "Verify Acquisition Portfolio Details After Search")
    public void check_Acquisition_Portfolio_Details() throws Exception {
        List<String> ids = marketPlaceSearchPage.search_result_header_data.getUniqueId_Values();
        assertEquals(marketPlaceSearchPage.search_result_header_data.getData(),
                sqlProcessor.getResultData("MarketPlaceSearch.ACQUISITION_DETAILS", ids));
    }

    @Test(description = "Verify Acquisition Patent Related Details After Search")
    public void check_Acquisition_Patent_Details() throws Exception {
        List<String> ids = marketPlaceSearchPage.search_result_header_data.getUniqueId_Values();
        assertEquals(marketPlaceSearchPage.search_result_patents.getData(),
                sqlProcessor.getResultData("MarketPlaceSearch.ACQUISITION_PATENT_DETAILS", ids));
    }

    @Test(description = "Verify Stage Facet After Search")
    public void check_Stage_Facet() throws Exception {
        resultSet = sqlProcessor.getResultData("MarketPlaceSearch.STAGE", dataId);
        assertEquals(marketPlaceSearchPage.stage.getData(), resultSet);
    }

    @Test(description = "Verify Technology Area Facet After Search")
    public void check_Technology_Area_Facet() throws Exception {
        resultSet = sqlProcessor.getResultData("MarketPlaceSearch.TECH_AREA", dataId);
        assertEquals(marketPlaceSearchPage.tech_Area.getData(), resultSet);
    }

    @Test(description = "Verify Current Assigner After Search")
    public void check_Current_Assignee_Facet() throws Exception {
        resultSet = sqlProcessor.getResultData("MarketPlaceSearch.CURRENT_ASSIGNEE", dataId);
        assertEquals(marketPlaceSearchPage.tech_Area.getData(), resultSet);
    }

    @Test(description = "Verify Original Assignee Facet After Search")
    public void check_Original_Assignee_Facet() throws Exception {
        resultSet = sqlProcessor.getResultData("MarketPlaceSearch.ORIGINAL_ASSIGNEE", dataId);
        assertEquals(marketPlaceSearchPage.tech_Area.getData(), resultSet);
    }

    @Test(description = "Verify Claim Charts Facet After Search")
    public void check_Claim_Charts_Facet() throws Exception {
        resultSet = sqlProcessor.getResultData("MarketPlaceSearch.CLAIM_CHARTS", dataId);
        assertEquals(marketPlaceSearchPage.tech_Area.getData(), resultSet);
    }

    @Test(description = "Verify Litigated Facet After Search")
    public void check_Litigated_Facet() throws Exception {
        resultSet = sqlProcessor.getResultData("MarketPlaceSearch.LITIGATED", dataId);
        assertEquals(marketPlaceSearchPage.tech_Area.getData(), resultSet);
    }

}
