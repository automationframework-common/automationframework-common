package com.rpxcorp.insight.page.detail;

import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

public class ChinesePRBDetailPage extends BaseDetailPage {
    public ChinesePRBDetailPage() {
        this.url = new PageUrl("/china/prb/{ID}");
    }

    @Override
    public boolean at() {
        detailPageTitle.waitUntilVisible();
        loading.waitUntilNoElementPresent();
        return waitForLoading();
    }
    public Element panel_requester_Count = $(".panel.plaintiff .round-shape");
    public Element panel_patentOwner_Count = $(".panel.defendants .round-shape");
    public final Element decision_doc_link = $(".panel.overview span.view-complaint-text:visible");

    public Element daysInLitigationCount = $(".details_page_metrics ul li:nth-child(3) span.count");
    public final Element judgementUnavailableBtn = $(".panel.overview a.download:contains('Judgement Unavailable')");
    public final StaticContent metricsSection = $(".panel-metrics", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("requesterCount", "div.columns div.metrics_card:contains(Requester) div.count");
                dataForm.content("patentOwnerCount", "div.columns div.metrics_card:contains(Patent Owner) div.count");
                dataForm.content("daysInLitigationCount", "div.columns div.metrics_card:contains(Days In Litigation) div.count");
            }
    );
    public final Element requesterSectionLink = $("#plaintiff_container li a:not([class])");
    public final Element patentownerSectionLink = $("#defendants_container li a:not([class])");
    public final StaticContent OutomeContent = $("#outcome ul.instance-details", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("legal_basis", "div.columns:nth-child(1):contains(Legal Basis)");
                dataForm.content("decision_point", "div.columns:nth-child(2):contains(Damages Awarded)");
                dataForm.content("outcome", "div.columns:nth-child(3):contains(Injunction Claimed)");
            }
    );
    /* CONTENT OF PRB CASE DETAIL PAGE * */
    //public final Element techCenter_Link = $(By.xpath("//div[text()='Tech Center']/../a"));
    public final Element reexamination_type=$("div.left_section ul.case-details.left_side>li");
    public final Element court=$("div.overview-item.right_section ul.case-details.right_side>li>div.title:contains('Court')");



    public final StaticContent overview_panel = $("div.overview-items", (Configure<StaticContent>) dataForm ->
    {
        dataForm.content("chiefJudge", "div.block-name:contains('Chief Judge'):visible+div a");
        dataForm.content("collegiateTeamLeader", "div.block-name:contains('Collegiate Team Leader'):visible+div a");
        dataForm.content("participant", "div.block-name:contains('Participant'):visible+div a");

    }
    );
        public final StaticContent subheading = $("ul.header-info.details", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("Decision_Number", "li:contains(Decision:)");
                dataForm.content("Commission", "li:contains(Commission)");
                dataForm.content("Authorization_Date", "li:contains(Authorization date)");
                dataForm.content("Last_Docket_Entry", "li:contains(Decision date)");
            }
    );
    //public final Element Patent_Trail_And_Appeal_Board=$(".subtitle li a");
    public final StaticContent case_Detail = $(".overview-item", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("reexamination_type", "ul.case-details.left_side>li:nth-child(1)");
                dataForm.content("court", "ul.case-details.right_side>li:nth-child(1)");
                dataForm.content("chiefJudge", "ul.case-details.right_side>li:nth-child(2) a[href]");
                dataForm.content("collegiateTeamLeader", "ul.case-details.right_side>li:nth-child(3) a[href]");
                dataForm.content("participant", "ul.case-details.right_side>li:nth-child(4) a[href]");
            }
    );
    public final Table PATENT_TABLE = $("table.patents-in-suit-table", (Configure<Table>) table ->
            {
                //table.uniqueId("td a[href]:last-child");
                table.displayedRecords(".patents-in-suit-table tbody tr");
                table.viewAllLink(By.xpath("//a[text()='View All']"));
                table.viewLessLink(By.xpath("//a[text()='View Less']"));
            }
    );
    public final Element noPatentInSuitMsg = $("#patents_in_suit span");
    public final Element PatentInformation=$(By.xpath("//h2[contains(text(),'Patent Information')]"));
    public final Element judgementURL = $("a.download");

    public String getJudgementDocumentNumber(){
        String documentNumber = "";
        if(judgementURL.isDisplayed()) {
            documentNumber = judgementURL.getAttribute("href").split("rpxcorp.com/")[1];
        }
        return documentNumber;
    }
    public final Element chineseEnglishToggleButton = $("#chn_eng_toggle");
    public final Element chnEngToggle = $("input#chn_eng_toggle");
    public final Element chineseView = $("div#plaintiff_container div.chn_toggle:visible");
    public final Element englishView = $("div#plaintiff_container div.en_toggle:visible");

    public void changeChineseToggle() {
        chineseEnglishToggleButton.click();
    }
    public void switch_Englishtoogle_view() {
        if (!englishView.isDisplayed()) {
            chnEngToggle.click();
            waitForPageLoad();
        }
    }
    public final Element caseTabLink = $("#lit-campaign a[href='#simple1']");

    public void PRB_selectCasesTab() {
        if (caseTabLink.isDisplayed()) {
            caseTabLink.click();
            waitForPageLoad();
        }
    }
    public final Table PRB_litigation_cases = $(".litigations_table", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(3)");
                table.viewAllLink(By.xpath("//div[contains(@id, 'simple1')]//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[contains(@id, 'simple1')]//a[text()='View Less']"));
                table.displayedRecords(".litigations_table tbody tr:not([style*='none'])");
            }
    );
    public final Element casenum_column =$("th:contains('Date Filed')");
    public final Tabs PRB_litigationCampaignTabs = new Tabs("#lit-campaign dl");
    public final Element noDefendantsNotes = $("#lit-campaign #simple2 .note");
    public final Table PRB_defendant_table = $("#campaign_defendants", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(1)>a:last-child");
                table.viewAllLink(".campaign_defendants a.view-all");
                table.viewLessLink(By.xpath("//div[@id='simple2']//a[text()='View Less']"));
                table.row("table#campaign_defendants>tbody>tr[role='row']");
                table.subTable($(".nested_inner_table", (Configure<Table>) subTable ->
                {
                    subTable.uniqueId("td:nth-child(3) a[href]");
                }));
                table.expandSubTableLink(".open.cursor-pointer");
                table.displayedRecords("#campaign_defendants tbody tr:not([style*='none'])");
            }
    );

    public final Element litigationSearchBox = $(".dataTables_filter div.search_text_container>input[type='text']");
    public void defendantSearch(String searchTerm) {
        litigationSearchBox.sendKeys(searchTerm);
        waitForLoading();
    }
    public final Element noDataInDefendantTable = $("#campaign_defendants .dataTables_empty");
    public final Element PRBCampDefendantMostRecentCaseLink = $("#campaign_defendants tbody td:nth-of-type(3) a");
    public final Element PRBcaseNameLinkInLitCampDefTabSubTable = $("#campaign_defendants tr.case_details td.docket-number");
    public final Element noPatentsInLitCamp = $("#simple3 span");
    public final Table PRB_camp_patent_table = $("#related_patents_table_wrapper", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(2) a[href]");
                table.viewAllLink(By.xpath("//div[contains(@id, 'simple3')]//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[contains(@id, 'simple3')]//a[text()='View Less']"));
                table.displayedRecords("#related_patents_table_wrapper tbody tr:not([style*='none'])");
            }
    );
    public final Element litCampViewAsSearchResults = $("#litigation_campaign_section a:contains('View as search results')");
    public final Element no_accused_products = $("#simple4 span:contains('No accused products found')");
    public final Table PRB_camp_accused_table = $("#related_accused_products_table", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(2) a[href]");
                table.viewAllLink(By.xpath("//div[contains(@id, 'simple4')]//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[contains(@id, 'simple4')]//a[text()='View Less']"));
                table.displayedRecords("#related_accused_products_table tbody tr:not([style*='none'])");
            }
    );
    public void selectDefendantTab() {
        if (PRBdefendantsTabLink.isDisplayed()) {
            PRBdefendantsTabLink.click();
            waitForSectionLoading();
        }
    }
    public final Element PRBdefendantsTabLink = $("#lit-campaign a[href='#simple2']");
    public final Element campLinkInLitCampSection = $("#litigation_campaign_section a[href*='campaign']");
    public final Element notimeLinechartBar = $("div.highcharts-container  tspan:contains('No data to display')");
    public final Element timeLinechart = $("div.highcharts-container");

    public final Table requester = $(".panel.plaintiff", (Configure<Table>) table ->
            {
                table.viewAllLink(By.xpath("//div[@id='plaintiff_container']//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[@id='plaintiff_container']//a[text()='View Less']"));
                table.displayedRecords(".panel.plaintiff ul>li a[href*='/ent/']:visible()");
                table.uniqueId("ul>li a:nth-of-type(1):visible()");
                table.column("ent_name", "ul>li a:nth-of-type(1):visible()");
            }
    );

    public final Table patentOwner = $(".panel.defendants", (Configure<Table>) table ->
            {
                table.viewAllLink(By.xpath("//div[@id='defendants_container']//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[@id='defendants_container']//a[text()='View Less']"));
                table.displayedRecords(".panel.defendants ul>li a[href*='/ent/']:visible()");
                table.uniqueId("ul>li a:nth-of-type(1):visible()");
                table.column("ent_name", "ul>li a:nth-of-type(1):visible()");
            }
    );

}
