package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.module.CheckList;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class AlertAnnouncementPage extends BasePage {

    public AlertAnnouncementPage() {
        this.url = new PageUrl("admin/alert_announcements");
    }

    @Override
    public boolean at() {
        return page_title.waitUntilVisible();
    }
    public final Element page_title = $("div>h5:contains('Announcements')");
    public final Element previewMail=$("a[data-behavior='preview_outreach_email']");
    public final Element editRecipients=$("a[data-behavior='edit_outreach_email']");
    public final Element sendMail_Btn=$("a[data-behavior='outreach_email_send_email']");
    public final Element recipents_UserGroup=$(".outreach-email-user-groups");
    public final Element recipents_Roles=$(".outreach-email-user-roles");
    public final Element mailSent_Date =$(".outreach-emails-table td:nth-child(3)");
    public final Element previewModal_Subject=$("#outreach_email_preview_modal.open input");
    public final Element previewModal_Body=$("#outreach_email_preview_modal.open .outreach-email-content-body");
    public final Element editModal_DoneBtn=$("#outreach_email_edit_modal.open input[value='Done']");
    public final Element editModal_CloseBtn=$("#outreach_email_edit_modal.open .close-reveal-modal");
    public final CheckList editModal_UserGroupList= $("#outreach_email_edit_modal.open .user-group-options",CheckList.class);
    public final CheckList editModal_RoleList= $("#outreach_email_edit_modal.open .user-role-options",CheckList.class);

    public void accessPreviewMail() {
        previewMail.click();
        previewModal_Body.waitUntilVisible();
    }

    public void accessEditRecipients() {
        editRecipients.click();
        editModal_DoneBtn.waitUntilVisible();
   }
    public void saveEditRecipients() {
        editModal_DoneBtn.click();
        editModal_DoneBtn.waitUntilInvisible();
        sendMail_Btn.waitUntilVisible();
    }

    public void closeEditRecipients() {
        editModal_CloseBtn.click();
        editModal_DoneBtn.waitUntilInvisible();
    }

    public void sendMail() {
        sendMail_Btn.click();
        acceptAlert();
//        sendMail_Btn.waitUntilInvisible();
        mailSent_Date.waitUntilTextContains(",");
    }
}
