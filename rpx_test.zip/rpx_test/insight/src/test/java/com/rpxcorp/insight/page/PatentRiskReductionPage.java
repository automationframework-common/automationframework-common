package com.rpxcorp.insight.page;

import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;

public class PatentRiskReductionPage extends Page{

	public PatentRiskReductionPage() {
		this.url = new PageUrl("patent_risk_reduction_report");
	}

	@Override
	public boolean at() {
		return patentRiskTitle.waitUntilVisible();
	}

	public final Element patentRiskTitle = $(".large-12>h1");
	public final Element patentRiskAboutSec =$("div#sidebar .panel > p");
	public final Tabs patentRiskPanelTabs = new Tabs(".panel .tabs");
	public final Element acquiflowLink = $("#def-acquisitions a[href*='acquiflow.internapp']");

	//About Section in Patent Risk Reduction Report Page
	public final String[] aboutContent=new String[] {
			"The patent risk reduction quarterly report summarizes RPX activity over the past quarter, including " +
			"defensive portfolio acquisitions, portfolio divestitures, " +
			"IPR petitions filed, litigation campaign assessments published, " +
			"and prior art search reports published. If you have questions about the report, " +
			"please contact riskreductionreport@rpxcorp.com."};

	public void clickDefensiveAcquisitions(){
		patentRiskPanelTabs.select("DEFENSIVE ACQUISITIONS");
	}
}
