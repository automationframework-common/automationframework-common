package com.rpxcorp.insight.api;

import java.util.HashMap;
import java.util.List;
import org.apache.commons.lang3.StringUtils;

import com.rpxcorp.testcore.driver.APICache;

public class VisualAnalyticsAPI extends APICache {

	@SuppressWarnings("unchecked")
	public String searchAPI(List<String> defendant_ids, List<String> plaintiff_ids) throws Exception {
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("defendant_ids", StringUtils.join(defendant_ids).replaceAll("\\[(.*?)\\]", "$1"));
		params.put("plaintiff_ids",StringUtils.join(plaintiff_ids).replaceAll("\\[(.*?)\\]", "$1"));
		params.put("size-by","numberOfDefendants");
		params.put("color-by","camp_ult_def_ent_name_ss");
		params.put("y-axis","camp_jurisdiction_type_ss");
		HashMap<String, String> header = new HashMap<String, String>();
		header.put("X-CSRF-Token",getAPIInstance().getCSRF_Token("/analytics"));
		return getAPIInstance().post("/analytics/search", params,header);
	}	
}
