package com.rpxcorp.insight.page.search;

import com.rpxcorp.insight.module.Facet;
import com.rpxcorp.insight.module.FacetFilter;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.detail.BaseDetailPage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class PatentSearchPage extends BaseDetailPage {

    public PatentSearchPage() {
        this.url = new PageUrl("advanced_search/search_patents") {
            {
                param("CURRENT SEARCH", "searchq");
                param("CURRENT_ASSIGNEE", "facet_current_assignee[]");
                param("ORIGINAL_ASSIGNEE", "facet_original_assignee[]");
                param("DOCUMENT TYPE", "is_application[]");
                param("LINKED DISTRICT COURT CASES", "&litigation_id[]");
                param("LINKED ITC CASES", "itc_id[]");
                param("JURIDICTION", "jurisdiction_types[]");
                param("EST_PRIORITY FROM DATE", "from_priority_date");
                param("EST_PRIORITY TO DATE", "to_priority_date");
                param("FILING FROM DATE", "from_filing_date");
                param("FILING TO DATE", "to_filing_date");
                param("PUBLICATION FROM DATE", "from_publication_date");
                param("PUBLICATION TO DATE", "to_publication_date");
                param("ISSUE FROM DATE", "from_grant_date");
                param("ISSUE TO DATE", "to_grant_date");
                param("GROUPED", "grouped");
            }
        };
    }

    @Override
    public boolean at() {
        waitForPageLoad();
        waitForLoading();
        return current_search.waitUntilVisible();
    }

    /* CONTENT OF PATENT SEARCH PAGE * */
    public final Element litigated_facet_showmore =$("div#sidebar form.advanced_search_refine section.filters.uncollapsed div.title:contains('Litigated') div[data-behavior='expand_facets'] a:contains('Show More')");
    public final Facet litigated_facet = new Facet("div#sidebar form.advanced_search_refine section.filters:has(div:contains('Litigated'))");
    public final Element patent_results_count = $("div#search_results_replaced_content .metrics_card a:contains(Patent Result) .count");
    public final Element patent_families_count = $("h2.result-title>span.count:nth-child(2)");
    public final Element currentSearch = $("#searchq_revised");
    public final FacetFilter documentType = $("Document Type", FacetFilter.class);
    public final FacetFilter executionDate = $("Assignment Execution Date", FacetFilter.class);
    public final FacetFilter filingDate = $("Filing Date", FacetFilter.class);
    public final FacetFilter publicationDate = $("Publication Date", FacetFilter.class);
    public final FacetFilter issueDate = $("Issue Date", FacetFilter.class);

    public final Element login_share_link_btn = $("a[title='Login Share Link']");
    public final Facet current_search = new Facet("section.filters:nth-of-type(1)");
    public final Element rpxReportfacet=$(By.xpath("//div[@class='title']//div[normalize-space(text())='RPX Reports']"));
    public final Table family_table = $(".search-results table.results", (Configure<Table>) table ->
        {
            table.column("Family Title", "tr a.title");
            table.column("US Patents", ".group_stats td:nth-child(3)");
            table.column("US Applications", ".group_stats td:nth-child(4)");
            table.column("Search Result", ".result-count");
        }
    );
    
    public final Element non_family_table_pats =$(".search-results table.results td:nth-of-type(2)");
    public final Table search_result = new Table(".search-results table.results");

    public final Element disabled_PTAB_filter=$(By.xpath("//li[@class='disabled-filter']//span[text()='PTAB']"));
    public final Element disabled_ITC_filter=$(By.xpath("//li[@class='disabled-filter']//span[text()='ITC']"));
    
    public final Element enabled_PTAB_filter=$(By.xpath("//li[@data-behavior='link_to_facet_positive_filter']//span[text()='PTAB']"));
    public final Element enabled_ITC_filter=$(By.xpath("//li[@data-behavior='link_to_facet_positive_filter']//span[text()='ITC']"));
    public final Element familyView_Btn=$(".button-group a i.icon-cross");
    public void nonFamilyView() {
    	if(familyView_Btn.isDisplayed()) {
    		familyView_Btn.click();
    		familyView_Btn.waitUntilInvisible();
    	}
    }
    
    public final Element goToAdvSearchLink_At_PatSearch=$("#affixed-table-header a.advanced_search_link[href*='/advanced_search?tab=patent']");
    public final Element currentAssigneeLnk=$(".results .content tbody>tr>td:nth-of-type(4)");
    public final Element nonCampView_currentAssigneeLnk=$(".results tbody>tr>td:nth-of-type(4)");

    public final Facet currentAssigneeShowMore = $("a[data-facet-group='Current Assignee']",Facet.class);
    public final Facet originalAssigneeShowMore = $("a[data-facet-group='Original Assignee']",Facet.class);

    public Map<String, Object> getAppliedFilters(){
        Map<String, Object> data = new HashMap<>();
        addIfNotEmpty(data,"current_search",currentSearch.getValue());
        addIfNotEmpty(data,"document_type",documentType.getSelectedFilter());
        addIfNotEmpty(data,"execution_date",executionDate.getSelectedFilter());
        addIfNotEmpty(data,"filling_date",filingDate.getAppliedDates());
        addIfNotEmpty(data,"publication_date",publicationDate.getAppliedDates());
        addIfNotEmpty(data,"issue_date",issueDate.getAppliedDates());
        return data;
    }
    public final Element patGroupedViewResults = $(".search-patents .group a.lit_doc");
}


