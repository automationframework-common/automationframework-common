package com.rpxcorp.insight.page.intelligence;

import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;

public class NPE_ProfilePage extends BasePage {

    public NPE_ProfilePage() {
        this.url = new PageUrl("intelligence/npe_profiles");
    }

    @Override
    public boolean at() {
        assertPageTitle("NPE Profiles");
        return NPE_table.waitUntilVisible();
    }

    /* CONTENT OF NPE PROFILE PAGE * */
    public final Element pageTitle = $("h1");
    public final Element searchTextBox = $("#data_table_filter input");
    public final Element noDataMessage = $(".dataTables_empty");
    public final Element npeName = $(".large-8 tbody a");
    public final Table NPE_table = $("#data_table", (Configure<Table>) table ->
        {
            table.uniqueId("td a[href]");
           table.nextPage("div.paging_will_paginate:nth-of-type(1) span.data_table_next");
           table.lastPage("div.paging_will_paginate:nth-of-type(1) span.data_table_end span:last-child");
        }
    );

}
