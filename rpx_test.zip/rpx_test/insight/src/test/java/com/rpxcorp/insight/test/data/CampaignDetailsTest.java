package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.detail.CampaignDetailPage;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.TableData;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Authenticate(role = "MEMBER")
@Test(groups = "Campaign")
public class CampaignDetailsTest extends BaseDataTest {
	CampaignDetailPage campaignDetailPage;
	TableData litigationTableData, petitionTableData, defendantTableData;
	ResultSet litigation, petition, defendant, patent;
	Map<String, String> overviewData;

	/* TEST CONFIGURATIONS */
	@Factory(dataProvider = "returnData")
	public CampaignDetailsTest(String dataDescription, String campId) {
		this.dataDescription = dataDescription;
		this.dataId = campId;
	}

	@DataProvider
	public static Object[][] returnData() throws Exception {
		return getTestData("CampaignDetail");
	}

	@BeforeClass
	public void loadPage() {
		this.urlData.put("ID", dataId);
		this.dataUrl = campaignDetailPage.getDeclaredUrl(urlData);
		to(campaignDetailPage, urlData);
	}

	@Test(description = "Verify Title")
	public void Campaign_Title() throws Exception {
		assertEquals(campaignDetailPage.detailPageTitle.getData(), sqlProcessor.getResultData("CampaignDetail.TITLE", dataId),
				"title");
	}

	@Test(description = "Verify Status")
	public void Campaign_Status() throws Exception {
		assertEquals(campaignDetailPage.status.getData(), sqlProcessor.getResultData("CampaignDetail.STATUS", dataId),
				"status");
	}

	@Test(description = "Verify Defendant terminated Count | RPX-11645", priority = 2)
	public void Defendants_Terminated_Count() throws Exception {
		overviewData = campaignDetailPage.overviewPanel.getData();
		assertEquals(overviewData.get("Defendants Terminated Count"),
				sqlProcessor.getResultData("CampaignDetail.CNT_DEFENDANT_TERMINATED", dataId), "count");
	}

	@Test(description = "Verify Petitions Count", priority = 2)
	public void Petitions_Count() throws Exception {
		petition = sqlProcessor.getResultData("CampaignDetail.PETITIONS_TABLE", dataId);
		int count = sqlProcessor.getResultCount(petition);
		if(count>0) {
				campaignDetailPage.overviewPanel.waitUntilVisible();
                assertEquals(overviewData.get("Petitions Count"),count);
            } else{
                assertEquals(count, 0);
            }
        }

	@Test(description = "Verify Patents Count", priority = 2)
	public void Patents_Count() throws Exception {
		patent = sqlProcessor.getResultData("CampaignDetail.PATENT_TABLE", dataId);
		assertEquals(overviewData.get("Patents Count"), sqlProcessor.getResultCount(patent));
	}

	@Test(description = "Verify Defendants Count", priority = 2)
	public void Defendants_Count() throws Exception {
		defendant = sqlProcessor.getResultData("CampaignDetail.DEFENDANT_TABLE_DATA", dataId);
		assertEquals(campaignDetailPage.overviewPanel.getData("Defendants Count"),
				sqlProcessor.getResultCount("CampaignDetail.DEFENDANT_TABLE_DATA", dataId));
	}

	@Test(description = "Verify Case Count", priority = 2)
	public void Case_View() throws Exception {
		assertEquals(campaignDetailPage.overviewPanel.getData("Case Count"),
				sqlProcessor.getResultCount("CampaignDetail.CASES_IN_CAMPAIGN_COUNT", dataId));
	}

	@Test(description = "Verify 'Defendant Parent' column in Defendant Table ", priority = 3)
	public void Defendants_Table() throws Exception {		
		defendant = sqlProcessor.getResultData("CampaignDetail.DEFENDANT_TABLE_DATA", dataId);
		campaignDetailPage.selectDefendantTab();
		defendantTableData = (TableData) campaignDetailPage.defendant_table.getData();
		assertEquals(defendantTableData, defendant, "defendant_parent");
	}

	@Test(description = "Verify 'Defendants' column in Defendant Table", priority = 4)
	public void Defendant_Defendants() throws Exception {
		assertEquals(defendantTableData, defendant, "defendants");
	}

	@Test(description = "Verify 'Most Recent Case' column in Defendant Table", priority = 4)
	public void Defendant_Most_Recent_Case() throws Exception {
		assertEquals(defendantTableData, defendant, "most_recent_case");
	}

	@Test(description = "Verify 'Start Date' column in Defendant Table", priority = 4)
	public void Defendant_Start_Date() throws Exception {
		assertEquals(defendantTableData, defendant, "start_date");
	}

	@Test(description = "RPX-14564 || Verify 'End Date' column in Defendant Table", priority = 4)
	public void Defendant_End_Date() throws Exception {
		assertEquals(defendantTableData, defendant, "end_date");
	}

	@Test(description = "Defendants Sub Table", priority = 5)
	public void Defendants_SubTable() throws Exception {
		campaignDetailPage.selectDefendantTab();
		assertEquals(campaignDetailPage.defendant_table.getSubtableData(),
				sqlProcessor.getResultData("CampaignDetail.DEFENDANT_SUB_TABLE", dataId));
	}

	@Test(description = "Verify 'Date Filed' column in Campaign Case View Table", priority = 6)
	public void Case_View_Date_Filed() throws Exception {
		litigation = sqlProcessor.getResultData("CampaignDetail.CASE_VIEW", dataId);
		campaignDetailPage.caseViewInCampaignOverview();
        litigationTableData = (TableData) campaignDetailPage.case_table.getData();
		assertEquals(litigationTableData, litigation, "date_filed");
	}

	@Test(description = "Campaign Case View - Case Name", priority = 7)
	public void Case_View_Case_Name() throws Exception {
		assertEquals(litigationTableData, litigation, "case_name");
	}

	@Test(description = "Campaign Case View - Case Number", priority = 7)
	public void Case_View_Case_Number() throws Exception {
		assertEquals(litigationTableData, litigation, "case_number");
	}

	@Test(description = "Campaign Case Termination Date", priority = 7)
	public void Case_View_Termination_Date() throws Exception {
		assertEquals(litigationTableData, litigation, "termination_date");
	}

	@Test(description = "Verify Patent Table", priority = 8)
	public void Patent_Table() throws Exception {
		assertEquals(campaignDetailPage.patent_table.getData(), patent, "patent", "title", "est_priority_date");
	}

	@Test(description = "Petitions - Date Filed", priority = 9)
	public void Petitions_Date_Filed() throws Exception {
		petitionTableData = (TableData) campaignDetailPage.petitions_table.getData();
		assertEquals(petitionTableData, petition, "date_filed");
	}

	@Test(description = "Petitions - Patent Number", priority = 10)
	public void Petitions_Patent_Number() throws Exception {
		assertEquals(petitionTableData, petition, "patent_number");
	}

	@Test(description = "Petitions - Case Number", priority = 10)
	public void Petitions_Case_Number() throws Exception {
		assertEquals(petitionTableData, petition, "case_number");
	}

	@Test(description = "Petitions - Petitioners", priority = 10)
	public void Petitions_Petitioners() throws Exception {
		assertEquals(petitionTableData, petition, "petitioners");
	}

	@Test(description = "Petitions - Status", priority = 10)
	public void Petitions_Status() throws Exception {
		assertEquals(petitionTableData, petition, "status");
	}

	@Test(description = "Petitions - Institution Decision Date", priority = 10)
	public void Petitions_Institution_Decision_Date() throws Exception {
		assertEquals(petitionTableData, petition, "institution_decision_date");
	}

	@Test(description = "Plaintiff Counsel Information")
	public void Plaintiff_Counsel_Information() throws Exception {
		campaignDetailPage.expandCounselInfo();
		assertEquals(campaignDetailPage.plaintiff_table.getData(),
				sqlProcessor.getResultData("CampaignDetail.PLAINTIFF_DETAILS", dataId));
	}

	@Test(description = "Campaign Petitions - Petitioner", priority = 11)
	public void Campaign_Petitions_Petitioner() throws Exception {
		campaignDetailPage.loadPetitionerWithAccordionExpand();
		assertEquals(campaignDetailPage.petitionerTable.getSubtableData(),
				sqlProcessor.getResultData("CampaignDetail.PETITONER_TABLE", dataId));

	}

	@Test(description = "Campaign Petitions - Patents", priority = 12)
	public void Campaign_Petitions_Patents() throws Exception {
		campaignDetailPage.loadPatentsWithAccordionExpand();
		assertEquals(campaignDetailPage.petitionPatentTable.getSubtableData(),
				sqlProcessor.getResultData("CampaignDetail.PETITION_PATENTS_TABLE", dataId));

	}

	@Test(description = "Verify NPE flag", priority = 13)
	public void npe_flag() throws Exception {
		assertEquals(campaignDetailPage.campaignHeader.getData("NPE"),
				sqlProcessor.getResultData("CampaignDetail.NPE_FLAG", dataId), "Name");

	}

	@Test(description = "Verify PTAB flag", priority = 14)
	public void ptab_flag() throws Exception {
		assertEquals(campaignDetailPage.campaignHeader.getData("PTAB"),
				sqlProcessor.getResultData("CampaignDetail.PTAB_FLAG", dataId), "Ptab");
	}

	@Test(description = "Verify ITC flag", priority = 15)
	public void itc_flag() throws Exception {
		assertEquals(campaignDetailPage.campaignHeader.getData("ITC"),
				sqlProcessor.getResultData("CampaignDetail.ITC_FLAG", dataId), "Itc");
	}

	@Test(description = "Verify Campaign Status", priority = 16)
	public void status_flag() throws Exception {
		assertEquals(campaignDetailPage.campaignHeader.getData("Status"),
				sqlProcessor.getResultData("CampaignDetail.STATUS_FLAG", dataId), "status");
	}

	@Test(description = "Verify Initiated Date", priority = 17)
	public void initiated_date() throws Exception {
		assertEquals(campaignDetailPage.getInitiatedDate(),
				sqlProcessor.getResultData("CampaignDetail.INITIATED_DATE", dataId), "Date");
	}
	
	@Test(description = "Verify plaintiff parties") 
	public void plaitiffParties() throws Exception {
		assertEquals(campaignDetailPage.getPlaintiffParties(), 
				sqlProcessor.getResultData("CampaignDetail.PLAINTIFF_PARTIES", dataId));
	}

	@Test(description = "Plaintiff Counsel Count")
	public void Plaintiff_Counsel_Count() throws Exception {
		assertEquals(campaignDetailPage.counsel_count.getData(),
				sqlProcessor.getResultData("CampaignDetail.COUNSEL_COUNT", dataId), "counsel_count");
	}

	@Test(description ="Accused Product Table")
	public void accued_product_table()throws Exception{
		campaignDetailPage.selectAccusedProductsTab();
		assertEquals(campaignDetailPage.accusedProductTable.getData(),
				sqlProcessor.getResultData("campaignDetail.ACCUSED_PRODCUT_TABLE",dataId));
	}

/*  @Test(description =  "Defendant Timeline | Verify the displayed defendant information within Defendant Timeline tab", priority = 20)
	public void defendantTimelinemodal() throws Exception{	
		campaignDetailPage.selectDefendantTimelineTab();
		assertEquals(campaignDetailPage.defendantListInDefendantTimeline.getBarModalData(),	
				sqlProcessor.getResultData("CampaignDetail.TIMELINE_BAR_DEFENDANT_INFORMATIONS", dataId));
	}	*/
	
	@Test(description =  "Defendant Timeline | Verify judge and venue dropdown list in Defendant Timeline tab", priority = 21)
	public void judgeVenueDropdownList() throws Exception{	
		campaignDetailPage.selectDefendantTimelineTab();
		assertEquals(campaignDetailPage.judgeVenueDropdownValues.getAllData(),
				sqlProcessor.getTableAsList("CampaignDetail.JUDGE_VENUE_LISTS", dataId));
	}  
	
	@Test(description =  "Defendant Timeline | Verify defendant list in Defendant Timeline tab", priority = 22)
	public void defendantDropdownList() throws Exception{	
		campaignDetailPage.selectDefendantTimelineTab();	
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("id", dataId);			
		assertEquals(campaignDetailPage.defendantDropdownValues.getAllData(), 
				new ArrayList<String>(Arrays.asList(sqlProcessor.getListValue("CampaignDetail.DEFENDANT_TABLE_DATA", params, "defendant_parent"))));
	}
	
/*	@Test(description =  "Patent Grid | Verify patent grid against each defendant", priority = 23)
	public void patentGridTab() throws Exception{	
		//campaignDetailPage.selectPatentGridTab();
		campaignDetailPage.campaignOverviewTabs.select("Patent Grid");
		assertEquals(campaignDetailPage.getPatentGridData(), 
				   sqlProcessor.getResultDataAsMap(sqlProcessor.getResultData( "CampaignDetail.DEFENDANT_PATENT", dataId), "unique_id", "patents")); 			
	}*/
}
