package com.rpxcorp.insight.page.insurance;

import org.openqa.selenium.By;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;

public class InsuranceSignUpPage extends BasePage {

    public InsuranceSignUpPage() {
        this.url = new PageUrl("insurance/applicants");
    }

    @Override
    public boolean at() {
        pageTitle.waitUntilVisible();
        content.waitUntilVisible();
        return pageTitle.waitUntilTextPresent("RPX Insurance");
    }
    
    public final Element content=$(By.xpath("//p[contains(text(),'Thank you for your interest in RPX Insurance Services. For additional information, please contact your salesperson or send a message to')]//a[@href='mailto:insuranceservices@rpxcorp.com']"));


    public final Element signup_btn = $(".insurance-signup-login #signup-btn");
    public final Element alreadyUserLoginLink = $(By.xpath("//*[@id='content']//h5/a[contains(text(),'already')]"));
    public final Element insuranceLoginModal = $("#insurance-login-modal.open");
    public final Element login_id = $("#insurance-login-modal input#user_email");
    public final Element password = $("#insurance-login-modal input#user_password");
    public final Element company = $("#insurance-login-modal input#user_extended_user_detail_attributes_company");
    public final Element login_btn = $("#insurance-login-modal input[value='Login Now']");
    public final Element iframe = $(".sso-iframe-content.panel #insurance_iframe ");

    public void clickOnAlreadyUserLogin() {
        alreadyUserLoginLink.waitUntilVisible();
        alreadyUserLoginLink.click();
    }

    public void loginAsVCExistingUser(String userId, String pswd, String companyInfo) {
        insuranceLoginModal.waitUntilVisible();
        login_id.sendKeys(userId);
        password.sendKeys(pswd);
        company.sendKeys(companyInfo);
        login_btn.click();
    }

}
