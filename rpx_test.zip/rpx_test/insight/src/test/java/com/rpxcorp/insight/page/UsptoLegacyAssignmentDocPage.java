package com.rpxcorp.insight.page;

import com.rpxcorp.testcore.element.Element;

public class UsptoLegacyAssignmentDocPage extends BasePage {

	@Override
	public boolean at() {
		return embedPDF.waitUntilVisible();
	}

	public final Element embedPDF = $("[type='application/pdf']");
}
