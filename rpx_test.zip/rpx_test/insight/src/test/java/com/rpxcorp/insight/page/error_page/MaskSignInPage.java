package com.rpxcorp.insight.page.error_page;

import org.openqa.selenium.By;

        import com.rpxcorp.insight.page.BasePage;
        import com.rpxcorp.testcore.element.Element;

public class MaskSignInPage extends BasePage {

    @Override
    public boolean at() {
        MaskSignIn.waitUntilVisible();
        return false;
    }

    public final Element MaskSignIn = $(".subscription-promo-message-container-mask+div.subscription-promo-message:contains('Sign In')");
}
