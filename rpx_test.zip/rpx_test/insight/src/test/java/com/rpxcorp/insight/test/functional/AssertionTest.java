/**
 * 
 */
package com.rpxcorp.insight.test.functional;

import com.rpxcorp.testcore.Authenticate;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.rpxcorp.insight.page.detail.AssertionDetailPage;

@Authenticate(role = "MEMBER")
public class AssertionTest extends BaseFuncTest {
    AssertionDetailPage assertionDetail;

    @Test(priority = 2, groups = "P3", description = "RPX-10157:Document Credit - Secure access for s3 document URLs")
    public void checkAssertionDocumentDownload() throws Exception {
        this.urlData.put("ID", "371");
        to(assertionDetail, urlData);
        withNewWindow(assertionDetail.documentDownload, () -> {
            Assert.assertTrue(getDriver().getPageSource().contains("application/pdf"), "PDF document is not loaded");
            Assert.assertFalse(getDriver().getCurrentUrl().contains("s3"), "PDF document URL doesnt show S3 bucket");
            Assert.assertTrue(getDriver().getCurrentUrl().contains("/assertion/"),
                    "URL is not navigated to /assertion/");
        });
    }

}
