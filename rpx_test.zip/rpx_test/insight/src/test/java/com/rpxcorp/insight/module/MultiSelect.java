package com.rpxcorp.insight.module;

import com.rpxcorp.testcore.element.Element;

import java.util.ArrayList;

public class MultiSelect extends Element {

    Element input = new Element(".select2-choices:visible>.select2-search-field>input");
    public MultiSelect(String selector) {
        super(selector);
    }

    private void filterAndselect(String value){
        if (value != null && !value.isEmpty() ) {
            input.sendKeys(value);
            Element resultValue = new Element(".select2-drop:visible>ul>li.select2-result:contains(\\\"" + value + "\\\")");
            resultValue.waitUntilVisible();
            resultValue.click();
        }
    }
    public void typeAndselect(String value){
       filterAndselect(value);
    }

    public ArrayList<String> getAllResults() {
        click();
        waitForDOM();
        input.waitUntilVisible();
        return new Element(".select2-drop:visible>ul>li.select2-result").getAllData();
    }
    
}
