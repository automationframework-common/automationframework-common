package com.rpxcorp.insight.page.advance_search;

import com.rpxcorp.insight.module.AutoComplete;
import com.rpxcorp.insight.module.DatePicker;
import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class AdvanceSearchPage extends BasePage {

    public AdvanceSearchPage() {
        this.url = new PageUrl("advanced_search");
    }

    @Override
    public boolean at() {
        return submitButton.waitUntilVisible();
    }
    public enum SEARCHTAB {
        Patent_Litigation,Entity,Patent,Marketplace,Portfolio
    }
    public final Tabs searchFormTabLinks = $(".adv-search-bar ul.tabs li",Tabs.class);
    public final Tabs searchFormTab = $(".adv-search-bar ul.tabs",Tabs.class);
    public final Element submitButton = $(".active input[name='commit']");
    public final Element clearFields=$(".active .clear_fields");

    //Used in Role Auth
    public final Element marketPlaceTab = $(".marketplace_link");
    public final Element portfolioTab = $(".portfolio_link");

    //locators for Patent Litigation Tab
    public final Element headerLabel = $("#litigations_search_form .pd-section>.section-heading");

    //locators for marketplace tab
    public final Element marketPlace = $(".marketplace_link");
    public final AutoComplete portfolioName = $("#marketplaceTab #name", AutoComplete.class);
    public final AutoComplete seller = $("#marketplaceTab #seller", AutoComplete.class);
    public final Element title = $("#marketplaces_search_form #title");
    public final Element abstractTextBox = $("#marketplaces_search_form #abstract");
    public final Element claims = $("#marketplaces_search_form #claims");
    public final Element patentNumber = $("#marketplaces_search_form #patnum");
    public final Element inventorName = $("#marketplaces_search_form #inventor");
    public final Element legalStatus = $("#marketplaces_search_form #legal_status");
    public final Element applicationNumber = $("#marketplaces_search_form #appnum");
    public final DatePicker intake_date_From_Date=new DatePicker("#mp_from_intake_date");
    public final DatePicker intake_date_To_Date=new DatePicker("#mp_to_intake_date");
    public final DatePicker bid_deadline_From_Date=new DatePicker("#mp_from_bid_deadline");
    public final DatePicker bid_deadline_To_Date=new DatePicker("#mp_to_bid_deadline");
    public final DatePicker est_priority_date_From_Date=new DatePicker("#mp_from_est_priority_date");
    public final DatePicker est_priority_date_To_Date=new DatePicker("#mp_to_est_priority_date");
    public final Element marketSector = $(".marketplace-market-sectors");
    public final Element stage = $(".marketplace-stages");
    public final Element status_active=$("#marketplaces_status_active");
    public final Element has_been_litigated=$("#marketplaces_is_litigated_true");
    public final Element claim_charts_available=$("#marketplaces_claim_charts_available");
    public final Element technology_area_selectall=$("div.section:has(.section-heading:contains('Technology Area')) span.select-box a:visible()");
    public final Element patentType = $("#is_application_true");
    public final DatePicker published_date_From_Date=new DatePicker("#mp_from_publication_date");
    public final DatePicker granted_date_From_Date=new DatePicker("#mp_from_grant_date");

    public final Element currentAssignee = $("#marketplaces_search_form #current_assignee");
    public final Element allAssignee = $("#marketplaces_search_form #all_assignee");
    public final Element originalAssignee = $("#marketplaces_search_form #original_assignee");

    public void clickMarketplaceTab(){
        if(marketPlaceTab.isDisplayed())
        {
            marketPlaceTab.click();
            loading.waitUntilNoElementPresent();
        }
    }

    //locators for portfolio tab
    public final AutoComplete portfolio_portfolioName = $("#portfolios_search_form #name", AutoComplete.class);
    public final AutoComplete portfolio_title = $("#portfolios_search_form #title",AutoComplete.class);
    public final Element portfolio_abstractTextBox = $("#portfolios_search_form #abstract");
    public final Element portfolio_claims = $("#portfolios_search_form #claims");
    public final AutoComplete portfolio_assetNumber = $("#portfolios_search_form #asset_number",AutoComplete.class);
    public final Element portfolio_inventorName = $("#portfolios_search_form #inventor");
    public final DatePicker acquisition_date_From_Date=new DatePicker("#portfolios_search_form #from_deal_acquisition_date");
    public final DatePicker acquisition_date_To_Date=new DatePicker("#portfolios_search_form #to_deal_acquisition_date");
    public final DatePicker portfolio_est_priority_date_From_Date=new DatePicker("#portfolios_search_form #from_priority_date");
    public final DatePicker portfolio_est_priority_date_To_Date=new DatePicker("#portfolios_search_form #to_priority_date");
    public final Element portfolio_has_been_litigated = $("#portfolios_is_litigated_true");
    public final Element portfolio_marketsector=$(".portfolio-market-sectors");
    public final Element portfolio_technology_area_selectall=$("div.section:has(.section-heading:contains('Technology Area')) span.select-box a:visible()");
    public final Element portfolio_legal_status=$(".portfolio-patent-statuses");

    public final Element portfolio_currentAssignee = $("#current_assignee_str");
    public final Element portfolio_allAssignee = $("#all_assignee_str");
    public final Element portfolio_originalAssignee = $("#original_assignee_str");

    public final DatePicker portfolio_published_date_From_Date=new DatePicker( "#from_pf_publication_date");
    public final DatePicker portfolio_issued_date_From_Date=new DatePicker("#from_pf_grant_date");

    public void clickPortfolioTab(){
        if(portfolioTab.isDisplayed())
        {
            portfolioTab.click();
            loading.waitUntilNoElementPresent();

        }
    }
}
