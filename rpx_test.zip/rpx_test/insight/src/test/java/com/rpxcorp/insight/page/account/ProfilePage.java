package com.rpxcorp.insight.page.account;

import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

public class ProfilePage extends BasePage {

	public ProfilePage() {
		this.url = new PageUrl("user/edit");
	}

	@Override
	public boolean at() {
		return profile_panel.waitUntilVisible();
	}

	public final Element profile_panel = $("#panel_profile");
	public final Element update_today = $(".right[href='/payments/options']");
	public final Element sub_startDate = $(By.xpath("//th/text() [normalize-space() ='Subscription Start Date:']/../../td"));
	//public final Element company_list = $("#id");


	public final Element account_SettingsTab = $("a:contains('Account Settings')");
	public final Element subscriptionFlashMsg = $(".cancel_subscription_flash");






	public final StaticContent profile = $("#user_profile_attributes_table", (Configure<StaticContent>) dataForm ->
			{
				dataForm.content("first_name", " td.first_name");
				dataForm.content("last_name", " td.last_name");
				dataForm.content("email", " td.email");
				dataForm.content("company", " td.company");
				dataForm.content("Profile Type", " th:contains(Subscription Type:)+td");
				dataForm.content("start_date", " th:contains(Subscription Start Date:)+td");
				dataForm.content("end_renewal_date", " th:contains(Subscription End Date:)+td");
			}
	);

/*	public final StaticContent profile_info = $("table#user_profile_attributes_table", (Configure<StaticContent>) dataForm ->
			{
				dataForm.content("first_name", " .first_name"); //tr:nth-of-type(1) td
				dataForm.content("last_name", " .last_name"); //tr:nth-of-type(2) td
				dataForm.content("email", " .email"); //tr:nth-of-type(3) td
				dataForm.content("company", ".company"); //Company (OR) Account
				dataForm.content("subscription_type", " th:contains(Subscription Type:)+td");
				dataForm.content("trial_start_date", "th:contains(Trial Start Date:)+td");       // will display only user in trial period
				dataForm.content("billing_start_date", "th:contains(Billing Start Date:)+td");    // will display only user in trial period
				dataForm.content("trial_expiry_date", "th:contains(Trial Expiration Date:)+td"); // will display only user subscription is cancelled in trial period
				dataForm.content("nontrial_billing_date", "th:contains(Billing Date:):not(th:contains(Next))+td"); // will display only user in non-trial period
				dataForm.content("nontrial_nextbillingdate", "th:contains(Next Billing Date:)+td"); // will display only user in non-trial period
				dataForm.content("nontrial_subscription_enddate", "th:contains(Subscription End Date:)+td"); // will display only user cancel subscription in non-trial period
				dataForm.content("auto_renew_checkbox" , "th:contains(Auto Renew:)+td>form>input#user_subscription_auto_renew");

			}
	);*/

}
