package com.rpxcorp.insight.test.data;

import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.rpxcorp.insight.page.search.EntitySearchPage;
@Authenticate(role = "MEMBER")
public class EntitySearch extends BaseDataTest {

    EntitySearchPage entitySearchPage;
    String searchText = "";
    Map<String, String> staticData;
    ResultSet resultSet;

    @BeforeClass
    public void loadPage() {
        this.urlData.put("CURRENT SEARCH", searchText);
        this.dataUrl = entitySearchPage.getDeclaredUrl(urlData);
        to(entitySearchPage, urlData);
    }

    @Test(description = "Verify count of NPEs after NPE filter is set to true", priority = 1)
    public void isNPE_True_Count() throws Exception {
        entitySearchPage.enter_searchtext("is_npe:true");
        entitySearchPage.switch_nonParent_View();
        assertEquals(entitySearchPage.enity_results_count.getIntData(),
                sqlProcessor.getResultCount("EntitySearch.ISNPE_TRUE_COUNT"));
    }

    @Test(description = "Verify the Entities after is_NPE set as True", priority = 2)
    public void isNPE_True() throws Exception {
        List<String> ids = entitySearchPage.search_result.getUniqueId_Values();
        assertEquals(entitySearchPage.search_result.getData(),
                sqlProcessor.getResultData("EntitySearch.ISNPE_TRUE_VALUES", ids), "name");
    }

    @Test(description = "Verify count of NPEs after NPE filter is set to true", priority = 3)
    public void isNPE_False_Count() throws Exception {
        entitySearchPage.enter_searchtext("is_npe:false");
        entitySearchPage.switch_nonParent_View();
        assertEquals(entitySearchPage.enity_results_count.getIntData(),
                sqlProcessor.getResultCount("EntitySearch.ISNPE_FALSE_COUNT"));
    }

    @Test(description = "Verify the Entities after is_NPE set as False", priority = 4)
    public void isNPE_False() throws Exception {
        List<String> ids = entitySearchPage.search_result.getUniqueId_Values();
        assertEquals(entitySearchPage.search_result.getData(),
                sqlProcessor.getResultData("EntitySearch.ISNPE_FALSE_VALUES", ids), "name");
    }

    @Test(description = "Verify the Ultimate Parent count after is_ultimate_parent set True", priority = 5)
    public void isUltimate_True_Count() throws Exception {
        entitySearchPage.enter_searchtext("is_ult_parent:true");
        entitySearchPage.switch_nonParent_View();
        assertEquals(entitySearchPage.enity_results_count.getIntData(),
                sqlProcessor.getResultCount("EntitySearch.IS_ULTIMATE_TRUE_COUNT"));
    }

    @Test(description = "Verify the Ultimate Parent Entites after is_ultimate_parent set True", priority = 6)
    public void isUltimate_True_Values() throws Exception {
        List<String> ids = entitySearchPage.search_result.getUniqueId_Values();
        assertEquals(entitySearchPage.search_result.getData(),
                sqlProcessor.getResultData("EntitySearch.IS_ULTIMATE_TRUE_VALUES", ids), "name");
    }

    @Test(description = "Verify the Ultimate Parent count after is_ultimate_parent set True", priority = 7)
    public void isUltimate_False_Count() throws Exception {
        entitySearchPage.enter_searchtext("is_ult_parent:false");
        entitySearchPage.switch_nonParent_View();
        assertEquals(entitySearchPage.enity_results_count.getIntData(),
                sqlProcessor.getResultCount("EntitySearch.IS_ULTIMATE_FALSE_COUNT"));
    }

    @Test(description = "Verify the Ultimate Parent Entites after is_ultimate_parent set True", priority = 8)
    public void isUltimate_False_Values() throws Exception {
        List<String> ids = entitySearchPage.search_result.getUniqueId_Values();
        assertEquals(entitySearchPage.search_result.getData(),
                sqlProcessor.getResultData("EntitySearch.IS_ULTIMATE_FALSE_VALUES", ids), "name");
    }

    @Test(description = "Verify the Entities in Market Sector", priority = 9)
    public void entities_Market_Sector_Count() throws Exception {
        entitySearchPage.enter_searchtext("market_sector:Undefined");
        entitySearchPage.switch_nonParent_View();
        List<String> ids = entitySearchPage.search_result.getUniqueId_Values();
        assertEquals(entitySearchPage.enity_results_count.getIntData(),
                sqlProcessor.getResultCount("EntitySearch.MARKET_SECTOR_COUNT"));
    }

    @Test(description = "Verify the Entities in Market Sector Values", priority = 10)
    public void entities_Market_Sector_Values() throws Exception {
        List<String> ids = entitySearchPage.search_result.getUniqueId_Values();
        assertEquals(entitySearchPage.search_result.getData(),
                sqlProcessor.getResultData("EntitySearch.MARKET_SECTOR_VALUES", ids), "name");
    }

    @Test(description = "Verify the Entities Count in Company Type", priority = 11)
    public void entities_Company_Type_Count() throws Exception {
        this.urlData.put("ENTITY TYPE", "1");
        to(entitySearchPage, urlData);
        this.dataUrl = entitySearchPage.getDeclaredUrl(urlData);
        entitySearchPage.switch_nonParent_View();
        assertEquals(entitySearchPage.enity_results_count.getIntData(),
                sqlProcessor.getResultCount("EntitySearch.ENTITY_TYPE_COUNT"));
    }

    @Test(description = "Verify the Entities Values in Company Type", priority = 12)
    public void entities_Company_Type_Values() throws Exception {
        List<String> ids = entitySearchPage.search_result.getUniqueId_Values();
        assertEquals(entitySearchPage.search_result.getData(),
                sqlProcessor.getResultData("EntitySearch.ENTITY_TYPE_VALUES", ids), "name");
    }
}
