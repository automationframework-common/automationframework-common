package com.rpxcorp.insight.page.search;

import com.rpxcorp.insight.module.Facet;
import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.insight.page.detail.BaseDetailPage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

import java.util.List;

public class LitigationSearchPage extends BaseDetailPage {

	public LitigationSearchPage() {
		this.url = new PageUrl("advanced_search/search_litigations") {
			{
				param("CURRENT SEARCH", "searchq");
				param("PLAINTIFF", "plaintiff_ultimate_parent_ent_id[]");
				param("DEFENDANT", "defendant_ultimate_parent_ent_id[]");
				param("MARKET SECTOR", "market_sector_id[]");
				param("PATENTS-IN-SUIT", "patent_id[]");
				param("CASE STATUS", "is_open[]");
				param("CASE STAGE", "stage_id[]");
				param("CASE TYPE", "case_type[]");
				param("JURIDICTION", "jurisdiction_type[]");
				param("FROM DATE", "from_filed_date");
				param("TO DATE", "to_filed_date");
				param("GROUPED", "grouped");
			}
		};
	}

	@Override
	public boolean at() {
		waitForPageLoad();
		overlay_Loading.waitUntilInvisible();
		return current_search.waitUntilVisible();
	}

	/* CONTENT OF LITIGATION SEARCH PAGE * */
	public final Element ptabCalloutInAccordion = $("tr[data-target-id*='litigation_display_group'] .ptab-tag");
	public final Element itcCalloutInAccordion = $("tr[data-target-id*='litigation_display_group'] .itc-tag");
	public final Element login_share_link_btn = $("a[title='Login Share Link']");
	public final Facet current_search = new Facet("section.filters:nth-of-type(1)");
	public final Facet case_type_causeofaction_facet = new Facet("div#fixed_facet_search section.filters:contains(Case Type (Cause of Action))");
	public final Element campaign_count = $("div#search_results_replaced_content .metrics_card a:contains(Campaign) .count");
	public final Element campaign_name_link = $(".group_stats a.plain-title");
	public final Element search_icon = $(".search i.icon-search");
	public final Element defendant_Tab = $("a[data-url*='view_type=defendants']");
	public final Element lawyers_Tab = $("a[data-url*='view_type=lawyers']");
	public final Element lawfirms_Tab = $("a[data-url*='view_type=law_firms']");
	public final Element patent_Tab = $("a[data-url*='view_type=patents']");
	public final Tabs litSearchTab = $(".search-litigations div#litigation_display_group0 .tabs", Tabs.class);
	public final Element viewTypeNonGrp = $("select[class*='select_view_type']");
	public final Element rpxReportfacet = $(By.xpath("//div[@class='title']//div[normalize-space(text())='RPX Reports']"));
	public final Element defendant_view_grp = $(
			By.xpath("//div[@class='view_type_container']//li[text()='DEFENDANT']"));
	public final Element lawyer_view_grp = $(By.xpath("//div[@class='view_type_container']//li[text()='LAWYER']"));
	public final Element lawfirm_view_grp = $(By.xpath("//div[@class='view_type_container']//li[text()='LAW FIRM']"));
	public final Element patent_view_grp = $("div.view_type_container li:contains('PATENT')");
	public final Element lawyer_view_non_group = $(By.xpath("//select[@class='select_view_type']/option[text()='Lawyers']"));
	public final Element lawfirm_view_non_group = $(By.xpath("//select[@class='select_view_type']/option[text()='Lawyers']"));
	public final Element patent_litigations_count = $("h2.result-title>span.count:nth-child(2)");
	public final Element PTAB_Petition_count = $("h2.result-title>span.count:nth-child(3)");
	public final Element ITC_invetigation_count = $("h2.result-title>span.count:nth-child(4)");

	public final Element no_group_patent_lit_count = $("h2.result-title>span.count:nth-child(1)");
	public final Element no_group_PTAB_Petition_count = $("h2.result-title>span.count:nth-child(2)");
	public final Element no_group_ITC_invetigation_count = $("h2.result-title>span.count:nth-child(3)");
	public final Element nonGroupedResults = $(".results tbody tr");
	public final Element case_name_in_campaign = $(
			".dataTables_scrollBody .campaign_litigations_table tbody>tr>td:nth-of-type(2)");
	public final Table campaign_table = $(".search-litigations table.results", (Configure<Table>) table ->
			{
				table.column("Campaign Name", "a.litigation_campaign_name");
				// table.column("Date", ".start-date");
				table.column("Status", "td:nth-child(5)");
				// table.column("Defendant Parents", ".group_stats td:nth-child(4)");
				table.column("Cases", ".group_stats td:nth-child(5)");
				table.column("Search Result", ".result-count");
				table.column("Jurisdiction", ".group_stats td:nth-child(4)");
				// sub_field("Plaintiff Link", ".plaintiff-link");
				// sub_field("Tags", ".ptab-tag");
			}
	);

	public final Table campaign_table_forSearch = $(".search-litigations table.results", (Configure<Table>) table ->
			{
				table.column("campaign_name", "a.litigation_campaign_name");
				table.column("Date", ".start-date");
				table.column("status", ".group_stats td:nth-child(3)");
				table.column("defendant_parents", ".group_stats td:nth-child(4)");
				table.column("cases", ".group_stats td:nth-child(5)");
				table.uniqueId("div.handle a.litigation_campaign_name");
			}
	);

	public final Table litigation_camp_table = $(".campaign_litigations_table", (Configure<Table>) table ->
			{
				table.column("case_name", ".campaign_litigations_table tbody>tr>td:nth-of-type(2)");
			}
	);
	public final Table search_result_forSearch = $("table.results", (Configure<Table>) table ->
			{
				table.uniqueId(" a[href] ");
			}
	);
	public final Table search_result = $("table.results", (Configure<Table>) table ->
			{
				table.column("case#", "table.results tbody>tr td:nth-of-type(3)");
			}
	);

	public final Table patent_camp_table = $(".campaign_lawfirms_table.dataTable", (Configure<Table>) table ->
			{
				table.column("PriorityDate", "tbody>tr td:nth-of-type(1)");
			}
	);

	public final Table defendant_table = $(".campaign_defendants_table", (Configure<Table>) table ->
			{
				table.activationlink("li[data-url*='view_type=defendants']");
			}
	);
	public final Table lawyer_table = $(".campaign_lawyers_table", (Configure<Table>) table ->
			{
				table.activationlink("li[data-url*='view_type=lawyers']");
			}
	);
	public final Table lawfirm_table = $(".campaign_lawfirms_table", (Configure<Table>) table ->
			{
				table.activationlink("li[data-url*='view_type=law_firms']");
			}
	);

	public final Table patent_table = $(".campaign_lawfirms_table", (Configure<Table>) table ->
			{
				table.activationlink("li[data-url*='view_type=patents']");
			}
	);


	public final Table defendantGrouped = new Table(".dataTables_scroll");
	public final Element defParentLinkDefGrpView = $(".campaign_defendants_table tbody td:first-child a[href*='ent']");
	public final Element defLinkDefGrpView = $(".campaign_defendants_table tbody td:nth-of-type(2) a");
	public final Element mostRecentCaseDefGrpView = $(".campaign_defendants_table tbody td:nth-of-type(3) a");

	public final Table lawFirmGrouped = new Table(".dataTables_scroll");
	public final Table lawyerGrouped = new Table(".dataTables_scroll");
	public final Element noDataMsgInGroupedView = $(".panel.failed_msg");

	public final Element disabledDefLinkInGrpView = $("a[class='disabled_view_type view_type_title']:contains('DEFENDANT')");
	public final Element disabledLawyerLinkinGrpView = $("a[class='disabled_view_type view_type_title']:contains('LAWYER')");
	public final Element disabledLawfirmLinkInGrpView = $("a[class='disabled_view_type view_type_title']:contains('LAW FIRM')");

	public final Table patent_in_suite_table = new Table(".patents-in-suit-table");

	public void enter_searchtext(String text) {
		search_textarea.clear();
		search_textarea.sendKeys(text);
		search_icon.click();
		waitForPageLoad();
	}

	public final Element campaignViewSwitch = $(".entities-switch input#campaign_view_swi");

	public void switch_ungrouped_view() {
		if(campaignViewSwitch.isSelected()){
			campaignViewSwitch.click();
			waitForLoading();
		}
	}

	public void switch_grouped_view() {
		if (!campaignViewSwitch.isSelected()) {
			campaignViewSwitch.click();
			waitForPageLoad();
		}
	}

	public List<String> getUniqueIDs_nonGrouped() {
		return search_result_forSearch.getUniqueId_Values();
	}

	public List<String> getUniqueIDs_grouped() {
		return campaign_table_forSearch.getUniqueId_Values();
	}

	public String[] getCaseKeyText() {
		String searchText = search_textarea.getText();
		String[] caseKeyResults = searchText.replaceAll("\\(|\\)", "").replaceAll("case_key_texts:", "")
				.replaceAll(" ", "").split("OR");
		return caseKeyResults;

	}

	public void selectFromGroupedView(String type) {
		if (type.equalsIgnoreCase("defendant"))
			selectDefendantView();
		else if (type.equalsIgnoreCase("lawyer"))
			selectLawyerView();
		else if (type.equalsIgnoreCase("lawfirm"))
			selectLawFirmView();
	}

	public void selectDefendantView() {
		loading.waitUntilInvisible();
		if (!litSearchTab.getActiveTabName().equalsIgnoreCase("DEFENDANT")) {
			litSearchTab.select("DEFENDANT");
			//loading.waitUntilInvisible();
			overlay_Loading.waitUntilInvisible();
		}
	}

	public void selectLawyerView() {
		loading.waitUntilInvisible();
		if (!litSearchTab.getActiveTabName().equalsIgnoreCase("LAWYER")) {
			litSearchTab.select("LAWYER");
			overlay_Loading.waitUntilInvisible();
		}
	}

	public void selectLawFirmView() {
		if (!litSearchTab.getActiveTabName().equalsIgnoreCase("LAW FIRM")) {
			litSearchTab.select("LAW FIRM");
			loading.waitUntilInvisible();
			overlay_Loading.waitUntilInvisible();
		}
	}

	public void selectPatentTabInSearchResult() {
		loading.waitUntilInvisible();
		if (!litSearchTab.getActiveTabName().equalsIgnoreCase("PATENT")) {
			litSearchTab.select("PATENT");
			overlay_Loading.waitUntilInvisible();
		}
	}

	// DEFENDANT MODAL
	public final Element defendatParentLink = $("div>a[href*='/lit_campaign_defendants/']");
	public final Element defendantModal = $("#async_modal table");
	public final Element openSubtable = $(".open.cursor-pointer");

	public void openDefendantModal() {
		if(defendatParentLink.isDisplayed()) {
			defendatParentLink.click();
			defendantModal.waitUntilVisible();
		}
	}

	public final Element defendantSubtable = $(".case_details table.nested_inner_table");

	public void openDefendantModalAndExpandSubtable() {
		openDefendantModal();
		if(openSubtable.isDisplayed()) {
			openSubtable.click();
			defendantSubtable.waitUntilVisible();
		}
	}

	// AUTHORIZATION
	public final Element grpView_PrmoMsg = $("div.qtip-content:contains('Search result pivoting is not included'):visible()");
	public final Element lawyerGrpView_pc = $(By.xpath("//li[@data-behavior='static_tooltip'][text()='LAWYER']"));
	public final Element lawfirmGrpView_pc = $(By.xpath("//li[@data-behavior='static_tooltip'][text()='LAW FIRM']"));
	public final Element patentGrpView_pc = $("li[data-behavior='static_tooltip']:contains('PATENT')");

	public final Element viewTypeNonGrp_pc = $("button[class*='view_type'][data-behavior='button_tooltip']");
	public final Element itcMostRecentCaseMasked = $(By
			.xpath("//table[contains(@class,'campaign_defendants_table')]//tbody/tr[1]/td[3]//a[text()='337-TA-000']"));
	public final Element itcMostRecentCase = $(By.xpath(
			"//table[contains(@class,'campaign_defendants_table')]//tbody/tr[1]/td[3]//a[not(text()='337-TA-000')]"));

	public final Element defSubtableItcCaseName_Login = $(
			By.xpath("//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[2]/a[text()='sign in']"));
	public final Element defSubtableItcCaseNoMasked = $("table.nested_inner_table tbody>tr:nth-of-type(1)>td:nth-child(4)>a:contains(337-TA-000)"); //$(By.xpath("//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[3]/a[text()='337-TA-000']"));
	public final Element defSubtableItcCaseNo = $(By.xpath("//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[4]/a[not(text()='337-TA-000')]"));
	public final Element defSubtableItcCaseNameLink = $("table.nested_inner_table tbody>tr:nth-of-type(1)>td:nth-child(3):has(a.case_details):visible()"); //$(By.xpath("//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[2]/a[contains(@href,'/itc/')]"));

	// LITIGATION SEARCH RESULTS GROUPED

	public final Element campLitTableItcCaseName = $(
			By.xpath("//table[@class='campaign_litigations_table']//tbody/tr[1]/td[2]/a[contains(@href,'/usitc/')]"));
	public final Element campLitTableCaseName_Login = $(
			By.xpath("//table[@class='campaign_litigations_table']//tbody/tr[1]/td[2]/a[text()='sign in']"));
	public final Element non_campLitTableCaseName_Login = $(
			By.xpath("//table//tbody/tr[1]/td[2]/a[text()='sign in']"));
	public final Element campLitTableItcCaseName_Masked = $(By.xpath(
			"//table[@class='campaign_litigations_table']//tbody/tr[1]/td[2][contains(text(),'ITC access not available')]/a[text()='Learn More']"));
	public final Element non_CampLitTableItcCaseName_Masked = $(By.xpath(
			"//table//tbody/tr[1]/td[2][contains(text(),'ITC access not available')]/a[text()='Learn More']"));
	public final Element campLitTableCaseNo = $(
			By.xpath("//table[@class='campaign_litigations_table']//tbody/tr[1]/td[3][not(a)]"));
	public final Element campLitTableItcCaseNo_Masked = $(
			By.xpath("//table[@class='campaign_litigations_table']//tbody/tr[1]/td[3]/a[text()='337-TA-000']"));

	public final Element campLitTablePtabCaseName = $(
			By.xpath("//table[@class='campaign_litigations_table']//tbody/tr[1]/td[2]/a[contains(@href,'/ptab/')]"));
	public final Element campLitTablePtabCaseName_Masked = $(By.xpath(
			"//table[@class='campaign_litigations_table']//tbody/tr[1]/td[2][contains(text(),'PTAB access not available')]/a[text()='Learn More']"));

	public final Element campLitTablePtabJurisdiction_Masked = $(By
			.xpath("//table[@class='campaign_litigations_table']//tbody/tr[1]/td[4][text()='PTAB Tech Center: 2600']"));
	public final Element non_campLitTablePtabJurisdiction_Masked = $(By
			.xpath("//table//tbody/tr[1]/td[4][text()='PTAB Tech Center: 2600']"));

	// LITIGATION SEARCH RESULTS NON GROUPED

	public final Element caseViewTableItcCaseName = $(".results tbody tr:nth-child(1) td>a[href*='/usitc/']");
	public final Element caseViewTableCaseName_Login = $(
			By.xpath("//table[@class='results']//tbody/tr[1]/td[2]/a[text()='sign in']"));
	public final Element caseViewTableItcCaseName_Masked = $(By.xpath(
			"//table[@class='results']//tbody/tr[1]/td[2][contains(text(),'ITC access not available')]/a[text()='Learn More']"));
	public final Element caseViewTableCaseNo = $(By.xpath("//table[contains(@class,'results')]//tbody/tr[1]/td[3][not(a)]"));

	public final Element caseViewTablePtabCaseName = $(
			".search-litigations table.results tbody a[href*='/ptab/']");
	public final Element caseViewTablePtabJurisdictionNo_Masked = $(By.xpath("//table[@class='results']//tbody/tr[1]/td[4][contains(text(),'PTAB Tech Center:')]"));



	public final Facet jurisdiction_facet = new Facet("div#sidebar form.advanced_search_refine section.filters");

	//Role Auth
	public final Element districtCourt = $(":has(div:contains('JURISDICTION') li:has(span:contains('District Court')) span a");
	public void clickjurisdictionFacet(){
		jurisdiction_facet.click();
	}

	//public final Facet jurisdiction_facet = new Facet("section.filters:nth-of-type(9)");

	//ROLE AUTH
	public final Element disabled_grouped_view_Btn=$("div.entities-switch input[disabled='disabled']+label");


	public final Element signOn_PromoMsg=$("a.reveal_login_from_grey_out");
	public final Element goToAdvSearchLink_At_LitSearch=$("#affixed-table-header a.advanced_search_link[href*='/advanced_search?tab=patent_litigation']");
	public final Element litSearchNoncampaignView=$("div.search-litigations a.lit-title");
	public final Element courtLnk=$(".grouped_results tbody>tr>td:nth-of-type(4)>a");
	public final Element non_CampaignView_CourtLnk=$(".search-litigations table.results tbody>tr>td:nth-of-type(4)>a");

	public final Element results = $(".results");
	public final Element caseTitle = $(".results td a");
	public final Element toolTip = $("search-hover");
	public final Element selectViewTypeInLitSearchNonGroupedView = $(".select_view_type");	
	public final Element patentViewTableHeader = $(".results.campaign_lawfirms_table th[class*='priority_date']");
	public final Element campLitTableFileDate = $(By.xpath("//div[@id=\"litigation_display_group2\"]//td[1]"));
	public final Element campLitTableStatus = $(By.xpath("//div[@id=\"litigation_display_group2\"]//td[5]"));

	public final StaticContent ptabTooltipContent = $(".details.itc", (Configure<StaticContent>) dataForm ->
	{
		dataForm.content("status", "li:contains(Status) .detail-value");
		dataForm.content("filed_date", "li:contains(Filed) .detail-value");
		dataForm.content("institution_date", "li:contains(Institution) .detail-value");
		dataForm.content("case_type", "li:contains(Case) .detail-value");	    	
	}
			);	

	public final StaticContent litTooltipContent = $(".patent-litigation .content", (Configure<StaticContent>) dataForm ->
	{
		dataForm.content("case_title", "h1 a");
		dataForm.content("filed_date", "li:contains(Filed) .detail-value");
		dataForm.content("closed_date", "li:contains(Closed) .detail-value");
		dataForm.content("case_type", "li:contains(Case) .detail-value");	
		dataForm.content("court", "li:contains(Court) .detail-value");
		dataForm.content("patent_in_suit", "li:contains(Suit) .detail-value");
	}
			);
	public final Element litGroupedViewSearchResults= $(".results .group a.lit-title");
}
