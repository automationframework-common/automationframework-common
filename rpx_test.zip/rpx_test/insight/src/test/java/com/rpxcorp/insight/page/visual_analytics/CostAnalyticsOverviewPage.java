package com.rpxcorp.insight.page.visual_analytics;

import org.openqa.selenium.By;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class CostAnalyticsOverviewPage extends BasePage {

	public CostAnalyticsOverviewPage() {
		this.url = new PageUrl("analytics/costoverview");
	}

	@Override
	public boolean at() {
		loading.waitUntilInvisible();
		return title.waitUntilVisible();
	}

	public final Element title = $(By.xpath("//h1[contains(text(),'Overview')]"));
	public final Element litigation_Cost_Analytics_Lnk=$(By.xpath("//h1/span/a[text()='LITIGATION COST ANALYTICS']"));
	public final Element ptab_Cost_Analytics_Lnk=$(By.xpath("//h1/span/a[text()='PTAB COST ANALYTICS']"));
		
}
