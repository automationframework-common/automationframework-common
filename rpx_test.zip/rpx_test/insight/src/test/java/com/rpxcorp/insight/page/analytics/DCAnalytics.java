package com.rpxcorp.insight.page.analytics;

import com.rpxcorp.insight.module.*;
import com.rpxcorp.insight.module.MultiSelectCheckBox;
import com.rpxcorp.insight.page.detail.BaseDetailPage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;

public class DCAnalytics extends BaseDetailPage {

    public DCAnalytics() {
        this.url = new PageUrl("/analytics/district_court"){
            {
                param("CourtState", "court_state_ss[]"); //Litigation -> District -> Texas
                param("CaseStatus", "case_status_detail_ss[]"); //Litigation -> District -> Texas
                param("CampaignName", "campaign_name_ss[]"); //Litigation -> District
                param("MarketSector", "market_sector_ids[]"); //Litigation -> Market Sector
                param("AccusedProducts", "accused_products[]"); //Litigation -> Accused Products
                param("CaseAppealed","is_case_cafc_appealed_bs[]"); //Litigation Events -> Case Appealed
                param("KeyEvents","key_events_sm[]"); //Litigation Events -> Key Events
                param("ChallengedPTAB","is_challenged_in_ptab_bs[]"); //Litigation Events -> Challenged in PTAB
                param("Outcomes", "outcomes[]"); //Litigation Events -> Case Outcome -> Infringement
                param("MotionType", "motion_subtypes_sm[]"); //Litigation Events -> Motion -> Motion Type
                param("AppealOutcome", "appeal_outcome_sm[]"); //Litigation Events -> Appeal Outcome
                param("EventBasisAppeal", "appeal_event_sm[]"); //Litigation Events -> Event Basis For Appeal
                param("PatentNumber", "patnum[]"); //Patent -> Patent Number
                param("PatentSEP", "is_seps_tag_bs[]"); //Patent -> Patent Declared as SEP
                param("Judge", "judge_name[]"); //Judge -> Judge
                param("party_Plain_Or_Def","party_plain_or_def[]");//Party -> Plaintiff or Defendant
                param("otherParty","other_party[]");//Party -> Other Party
                param("Rep. Defendant","lawfirm_defendant[]"); //LawFirm -> Representing Plaintiff
            }

        };
    }

    @Override
    public boolean at() {
        loading.waitUntilNoElementPresent();
        waitForPageLoad();
        return dcPageTitle.getText().equals("District Court Analytics");
    }

    public final Tabs mainTabs= new Tabs("section.dc-analytics ul.tabs");

    public final StaticContent metricsSection = $(".panel-metrics", (Configure<StaticContent>) dataForm ->
    {
        dataForm.content("plaintiffCount", ".metrics_card:contains(Cases) .count");
        dataForm.content("defendantCount", ".metrics_card:contains(Campaigns) .count");
        dataForm.content("accusedProductCount", ".metrics_card:contains(Plaintiffs) .count");
        dataForm.content("patentInSuitCount", ".metrics_card:contains(Defendants) .count");
        dataForm.content("docketEntriesCount", ".metrics_card:contains(Patents) .count");
    });

    public final Element dcPageTitle = $(".dc-analytics .section-title:visible()");
    public final Tabs litigationCampaignTabs = new Tabs("#district-court-analytics-analytics .page-tabs li");
    //General
    public final Element generalViewDropdown = $("select#rate");
    public final Element generalTotalCampaignDef = $(".tile .litigation-filed-chart .highcharts-series-group");
    public final Element generalLitMarketSector = $("section[data-behavior='district_court_lits_market_sector'] .highcharts-series-group");

    //Venue
    public final Element litFiledByVenue = $("select#venu_view");
    public final Element litFiledByVenueOverTime = $("select#venu_time_view");
    //public final Element VenueOutcome = $("select#outcome_type");
    public final MultiSelectCheckBox venueOutcome = $("#top-venue-outcome-container .dropdown-container",MultiSelectCheckBox.class);
    public final Element outcomedropdown = $("#top-venue-outcome-container button:contains(Save)");
    public final Element venueLitFiledByVenue = $(".tile .litigation-filed-venu-container .highcharts-series-group rect");
    public final Element venueLitOverTime = $(".tile .litigation-filed-venu-time-container .highcharts-series-group path.highcharts-point");
    public final Element topVenuesByOutcome_Events = $(".tile .top-venue-outcome-container-events .highcharts-series-group");
    public final Element topVenuesByOutcome_Duration=$(".tile .top-venue-outcome-container-duration .highcharts-series-group");
    //Party

    public final Element partyTopPlaintiffsDdown = $("select#party_plaintiff_view");
    public final Element partyTopDefendantsDdown = $("select#party_defendants_view");
    public final Element partyOutcomeType = $("select#party_type");
    public final MultiSelectCheckBox partyOutcome = $("#top-party-outcome-container .dropdown-container",MultiSelectCheckBox.class);
    public final Element partyTopPlaintiffs = $(".tile .litigation-filed-venu-container .highcharts-series-group");//section[data-behavior='district_court_top_parties'] .litigation-filed-venu-container .highcharts-series:nth-child(1)
    public final Element partyTopDefendants= $(".tile .party-top-defendants-container .highcharts-series-group");//section[data-behavior='district_court_top_parties'] .party-top-defendants-container .highcharts-series:nth-child(1)
    public final Element partyEvents= $(".tile .top-party-outcome-container-events .highcharts-series-group");
    public final Element partyDuration= $(".tile .top-party-outcome-container-duration .highcharts-series-group");


    //LawFirm
    public final Element lawfirmTopPlaintiffsDdown = $("select#lawfirm_plaintiff_view");
    public final Element lawfirmTopDefendantsDdown = $("select#lawfirm_defendants_view");
    public final Element lawfirmOutcomeType = $("select#party_type");
    //public final Element lawfirmoutcome= $("select#outcome_type");

    public final Element lawFirmTopPlaintiffs = $(".tile .litigation-filed-venu-container .highcharts-series-group");
    public final Element lawFirmTopDefendants= $(".tile .party-top-defendants-container .highcharts-series-group");
    public final Element lawFirmEvents= $(".tile .top-lawfirm-outcome-container-events .highcharts-series-group");
    public final Element lawFirmDuration= $(".tile .top-lawfirm-outcome-container-duration .highcharts-series-group");
    public final MultiSelectCheckBox lawfirmoutcome = $("#top-lawfirm-outcome-container .dropdown-container",MultiSelectCheckBox.class);

    //Judge
    public final Element topJudgesMotionOutcomesDdown = $("select#judge_motion_outcome_view");
    //public final Element topJudgesOutcomeType = $("select#outcome_type");
    public final MultiSelectCheckBox topJudgesOutcomeType = $("#top-judges-by-outcome-container .dropdown-container",MultiSelectCheckBox.class);
    public final Element judgeTopJudgesByCases = $(".tile .most-active-judges-container .highcharts-series-group rect");
    public final Element judgeTopJudgesByOutcomes= $(".tile .judges-by-motion-outcome-container .highcharts-series-group rect");
    public final Element topJudgeEvents= $(".tile .top-judges-by-outcome-container-events .highcharts-series-group");
    public final Element topJudgeDuration= $(".tile .top-judges-by-outcome-container-duration .highcharts-series-group");

    //Outcome
    public final Element defendantOutcomesSankey = $("#district-court-analytics-analytics div.outcomes-container .labelGroup rect:visible()");
    public final Element defendantOutcomesBarChart= $(".tile .outcomes-container .highcharts-series-group rect");
    public final Element outcomeDuration= $(".tile .outcome-duration-container .highcharts-series-group");
    public final Element outcomeByYear = $(".tile .outcome-by-year-container .highcharts-series-group");
    public void outcomeSwitchChart(String tabName){
        Element activeTab = $("#outcomes_switch li.active a");
        if(!activeTab.getText().toUpperCase().contains(tabName.toUpperCase())){
            String customCSS = String.format("#outcomes_switch li>a:contains('%s')", tabName);
            Element requiredTab = $(customCSS);
            requiredTab.click();
        }
    }

    //Motions
    public final Element motionOutcomes = $("#district-court-analytics-analytics div.motion-container .highcharts-series-group");
    public final Element motionduration= $("#district-court-analytics-analytics div.motion-container path.highcharts-boxplot-whisker");
    public void motionChartSwitch(String tabName){
        Element activeTab = $("#motion_output_type_switch li.active a");
        if(!activeTab.getText().toUpperCase().contains(tabName.toUpperCase())){
            String customCSS = String.format("#motion_output_type_switch li>a:contains('%s')", tabName);
            Element requiredTab = $(customCSS);
            requiredTab.click();
            waitForLoading();
        }
    }
    public void motionPartySwitch(String tabName){
        Element activeTab = $("#motion_party_type_switch li.active a");
        if(!activeTab.getText().toUpperCase().contains(tabName.toUpperCase())){
            String customCSS = String.format("#motion_party_type_switch li>a:contains('%s')", tabName);
            Element requiredTab = $(customCSS);
            requiredTab.click();
            waitForLoading();
        }
    }

    //Appeal
    public final Element appealOverTimeDdown = $("select#appeal_view");
    public final Element appealsOverTime = $(".tile .litigation-filed-chart .highcharts-series-group");
    public final Element appealissuesBasisAppeal = $(".tile .issue-basis-chart rect");
    public final Element appealeventBasisAppeal = $(".tile .event-basis-chart rect");
    public final Element appealingParty = $(".tile .appealing-party-chart path.highcharts-point");
    public final Element appealOutcomes = $(".tile .appeal-outcomes-chart path.highcharts-point");
    public void motionPeriodSwitch(String tabName){
        Element activeTab = $(".period-switcher.switch li.active a");
        if(!activeTab.getText().toUpperCase().contains(tabName.toUpperCase())){
            String customCSS = String.format(".period-switcher.switch li>a:contains('%s')", tabName);
            Element requiredTab = $(customCSS);
            requiredTab.click();
            waitForLoading();
        }
    }

    //CompareTab
    public final Element compType = $("select#comparison_type");
    public final Element compareBtn = $("a#compare-submit-btn");
    public void clickCompareButton(){
        compareBtn.click();
        waitForLoading();
    }

    public final MultiSelect comparisionEdit = $(".content.party-content .select2-container",MultiSelect.class);
    public final Element totalCasesFiledChart = $(".header-section:contains(Total Cases Filed)+div.body-section>div#total-cases-compare-chart .highcharts-container");
    public final Element outcomeChart = $(".header-section:contains(Outcome)+div.body-section>div#outcome-compare-chart .highcharts-container");
    public final Element motionsChart = $(".header-section:contains(Motions)+div.body-section>div#motions-compare-chart .highcharts-container");
    public final Element topPlaintiffChart = $(".header-section:contains(Top Plaintiffs)+div.body-section>div#top-plaintiffs-compare-chart .highcharts-container");
    public final Element topDefendantChart = $(".header-section:contains(Top Defendants)+div.body-section>div#top-defendants-compare-chart .highcharts-container");
    public final Element topLawfirmPlaintiffChart = $(".header-section:contains(Representing Plaintiffs)+div.body-section>div#top-lawfirm-plaintiffs-compare-chart .highcharts-container");
    public final Element topLawfirmDefendantsChart = $(".header-section:contains(Representing Defendants)+div.body-section>div#top-lawfirm-defendants-compare-chart .highcharts-container");
    public final Element topVenuesChart = $(".header-section:contains(Top Venues)+div.body-section>div#top-venues-compare-chart .highcharts-container");


    public void compareTabSelectDefendants(String comparision) throws Exception{
        if(comparision != null && !comparision.trim().isEmpty()){
            String comparisions[] = comparision.split(":");
            for(String com : comparisions){
                System.out.println("Comparisions Text"+com);
                comparisionEdit.typeAndselect(com);
            }
        }

    }
    public final Element filterExpCollToggle = $("section.dc-analytics .filter-container .filter:has(.header-section:contains('Litigation Events'))");
    public void expandFacet(String filterHeaderName) throws  Exception{
            Element  leftFilter = $("section.dc-analytics .filter-container .filter:has(.header-section:contains('"+filterHeaderName+"'):visible())");
        if(!leftFilter.getElement().getAttribute("class").contains("uncollapsed")){
            System.out.println("collapse clicked");
            leftFilter.$("div.toggle-icon:visible()").click();
            leftFilter.$(".filter-body:visible()").waitUntilVisible();
            Thread.sleep(1000);
        }
    }
    public final Facet facetHeader = new Facet("section.dc-analytics .filter-container .parent.header-section>header");
    public Facet facetSubHeader(String subHeader) {
        return new Facet("section.dc-analytics .filter-container .parent.header-section:contains('" + subHeader + "') ~ div.filter-body .header-section>header");
    }

    public Facet facetSubHeaderSearchType(String subHeader) {
        return new Facet("section.dc-analytics .filter-container .parent.header-section:contains('" + subHeader + "') ~ div.filter-body .search-container>label");
    }

    //sub-header

    //    public List<String> getFacetFilterHeaders() {
//        List<String> timelineData = new ArrayList<String>();
//        List<WebElement> options = facetFilterHeaders.getElements();
//        for (WebElement opt : options)
//            timelineData.add(opt.getText());
//        return timelineData;
//    }



public final Element filterCheckedValues = $("div.filter-body input[checked]");
    public final Element filterTextBoxValues = $(  "div.filter-body .select2-search-choice>div");
    public ArrayList<String> getLeftSideAppliedFilterValues(){
        ArrayList<String> selectedFilterValue1 =new ArrayList<String>();
        ArrayList<String> selectedFilterValue2 = new ArrayList<String>();
        if(filterCheckedValues.isPresent()){
            for (WebElement element : filterCheckedValues.getElements()) {
                selectedFilterValue1.add(element.getAttribute("value"));
            }
        }
        if(filterTextBoxValues.isPresent()){
            selectedFilterValue2 = filterTextBoxValues.getAllData();
        }
        selectedFilterValue1.addAll(selectedFilterValue2);
        return selectedFilterValue1;
    }

    public final Table caseList = $(".ptab_analytics_cases ", (Configure<Table>) table ->
            {
                table.uniqueId(" td:nth-child(3) a[href] ");
                table.displayedRecords(".ptab_analytics_cases tbody tr:not([style*='none'])");
            }//
    );

    public final Table patentList = $(".ptab_analytics_patents", (Configure<Table>) table ->
            {
                table.uniqueId(" td:nth-child(1) a[href] ");
                table.displayedRecords(".ptab_analytics_patents tbody tr:not([style*='none'])");
            }//
    );



}
