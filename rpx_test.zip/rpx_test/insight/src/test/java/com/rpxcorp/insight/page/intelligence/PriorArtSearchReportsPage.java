package com.rpxcorp.insight.page.intelligence;

import com.rpxcorp.insight.module.SelectBox;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

import com.rpxcorp.insight.module.AutoComplete;
import com.rpxcorp.insight.module.DatePicker;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.ConfigUtil;

public class PriorArtSearchReportsPage extends BasePage {

	public PriorArtSearchReportsPage() {
		this.url = new PageUrl("rpxpriorartsearchreports");
	}

	@Override
	public boolean at() {
		loading.waitUntilInvisible();
		assertPageTitle("Prior Art Search Reports");
		return report_table.waitUntilVisible();
	}
	public void openPriorArtDropdown() {
		if (!downloadButton.isDisplayed()) {
			downloadpriorreportBtnInTable.click();
			downloadButton.waitUntilVisible();
		}
	}
	public final Element deleteButton=$("#priort_art_search_result table tbody tr:first-child>td ul li a:contains('Delete')");
	public final Element editreport_btn=$("#priort_art_search_result table tbody tr:first-child>td ul li a:contains('Edit')");

	public final Element downloadButton = $("#priort_art_search_result table tbody tr:first-child>td>a.button");
	public final Element downloadpriorreportBtnInTable = $("table.dataTable tbody tr:nth-child(1) td>a.button:contains('Download')");

	public final Element addreport_btn = $(".prior-title ul.portfolio-search-actions li>a.report span.add-report");
	public final Element assetNumbers=$("#async_modal.open .selected_new_report_patnums a");
	public final Element closeIcon_ReportDialog=$("#async_modal.open a.close-reveal-modal");
	
	public final Element addReportModal = $("#async_modal.open");
	public final SelectBox reportTitle = $("#s2id_campaign_id", SelectBox.class);
	public final AutoComplete assetNumber = $("#prior_art_pats_autocomplete", AutoComplete.class);
	public final DatePicker updatedDate = new DatePicker("#publication_date");
	public final Element fileUpload = $("#prior_art_uploads");
	public final Element createReportButton = $("#async_modal.open input.button");
	public final Element updateReportButton = $("#async_modal.open input[value='Update Report']");

	public final Element searchBox = $(".dataTables_filter> label >input");
	public final Table report_table = new Table(".dataTables_wrapper table");
	public final Element patents=$("a.lit_doc");
	public final Element downloadReportButton=$("#priort_art_search_result a[data-behavior='prior_art_report_gtm']:visible");
	public final Element emptyTable = $(".dataTables_empty");
	public final Element alreadyUploadedFileText=$(By.xpath("//*[@id='async_modal']//div/text()[contains(.,'Already uploaded file:')]"));
	
	// Prior Art Reports TABLE
    public final Table prioArtreport_table = $(".clickable-rows", (Configure<Table>) table ->
        {
           table.nextPage("div.paging_will_paginate > span[class$='_next paginate_button']"); //.paging_will_paginate .DataTables_Table_0_next.paginate_button
           table.lastPage("div.paging_will_paginate > span[class$='_end'] span:last-child"); //.paging_will_paginate .DataTables_Table_0_end>span:last-child
        }
    );
	public void search(String searchText) {
		searchBox.sendKeys(searchText);
		waitForLoading();
	}

	public void addPriorArt(String report_title, String asset_number, String date, String fileName) throws Exception {    	
		openPriorArtAddModal();
		setDataInReportModal(report_title, asset_number, date, fileName);
		Thread.sleep(2000);
		createReportButton.waitUntilVisible();
		createReportButton.click();
		addReportModal.waitUntilInvisible();
	} 
	
	public void editPriorArt(String report_title, String asset_number, String date, String fileName,boolean is_clearAsset) throws Exception {    	
		openEditPriorArtAddModal();
		if(is_clearAsset) {
			clearAssets();
		}
		setDataInReportModal(report_title, asset_number, date, fileName);
		updateReportButton.click();
		addReportModal.waitUntilInvisible();
	} 

	public void deleteReport(String searchTerm) {
		search(searchTerm);		
		while(!(emptyTable.isDisplayed())) {			
			deleteButton.click();
			acceptAlert();
			alertMessage.waitUntilVisible();
			search(searchTerm);				
		}
	}

	public void addPriorArtReport(String report_title, String asset_number, String date, String fileName) throws Exception {
		search(report_title);		
		if(emptyTable.isDisplayed()) {			
			addPriorArt(report_title, asset_number, date, fileName);
		}
	}
	
	public void editPriorArtReport(String report_title,String new_report_title, String new_asset_number, String new_date, String new_fileName,boolean is_clearAsset) throws Exception {
		search(report_title);
		editPriorArt(new_report_title, new_asset_number, new_date, new_fileName,is_clearAsset);
		
	}

	public void addMultiplePriorArts(int maxReportCount, String report_title, String asset_number, String date, String fileName) throws Exception {
		deleteReport(report_title);
		for(int j=0;j<maxReportCount;j++) {			
			addPriorArt(report_title, asset_number, date, fileName);			
		}
	}
	
	public void editMultiplePriorArts(int maxReportCount, String report_title,String new_report_title, String new_asset_number, String new_date, String new_fileName,boolean is_clearAsset) throws Exception {
		deleteReport(new_report_title);
		search(report_title);			
		for(int j=0;j<maxReportCount;j++) {
			editPriorArt(new_report_title, new_asset_number, new_date, new_fileName,is_clearAsset);
			search(report_title);		
		}	
	}
	
	public void openPriorArtAddModal() {
		addreport_btn.waitUntilVisible();
		addreport_btn.click();
		reportTitle.waitUntilVisible();
	}
	
	public void openEditPriorArtAddModal() {
		editreport_btn.waitUntilVisible();
		editreport_btn.click();
		reportTitle.waitUntilVisible();
	}

	public void setDataInReportModal(String report_title, String asset_number, String date, String fileName) throws Exception {
			reportTitle.typeAndselect(report_title);
			assetNumber.select(asset_number);
			updatedDate.selectDate(date);
			fileUpload.sendKeys(ConfigUtil.config().get("testResourcesDir").toString() + "/test_data/" + fileName);
	}
	
	public void clearAssets() {
		if(assetNumbers.size()>0) {
			for(int i=0;i<assetNumbers.size();i++) {
				assetNumbers.getElements().get(i).click();
			}
		}
	}
	
	public void close_dialog() {
		if(addReportModal.isDisplayed()) {
			closeIcon_ReportDialog.click();
			addReportModal.waitUntilInvisible();
		}
	}
}
