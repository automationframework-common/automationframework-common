package com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.LoginPage.ROLES;
import com.rpxcorp.insight.page.account.AdminAccountPage;
import com.rpxcorp.insight.page.account.RpxAccountEditPage;
import com.rpxcorp.insight.page.account.UserEditPage;
import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
@Authenticate(role = "ADMIN")
public class AdminAccountsTest extends BaseFuncTest {

    AdminAccountPage adminAccount;
    UserEditPage userEditpage;
    RpxAccountEditPage rpxAccEditPage;
    String emailId="test_acc.ba6f4fe1@mailosaur.io";

    @BeforeClass
    public void navigateToAccountsPage() {
    	to(adminAccount);
    }

    @Test(dataProvider = "searchField", priority = 1, groups="P3", description = "RPX-9564 Check all search fields")
    public void checkSearchField(String input, String searchField, String columnName) throws Exception {
        adminAccount.enterSearchText(input, searchField);
        adminAccount.filterButton.click();
        adminAccount.loading.waitUntilInvisible();
        assertEquals(adminAccount.accountsTable.getColumn(columnName).get(0).toLowerCase(), input.toLowerCase());
    }

    @DataProvider(name = "searchField")
    public Object[][] getSearchField() {
        return new Object[][] { { "Google LLC", "name_cont", "Name" },
                { "Google", "display_name_cont", "Display Name" }
        };
    }
    
    @Test(priority = 2, groups="P3", description = "Verify Start Date filter")
    public void verifyStartDateFilter() throws Exception {
    	String dateInput = "12/20/2012";
    	adminAccount.clearFilters();
    	adminAccount.startDate.selectDate(dateInput);
        adminAccount.filterButton.click();
        List<String> dates=adminAccount.accountsTable.getColumn("Start Date");
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        Date inputDate=sdf.parse(dateInput);
        for(String date:dates) {
        	Date outputStartDate=sdf.parse(date);
        	if(inputDate.equals(outputStartDate) || outputStartDate.after(inputDate)){
        		assertTrue(true,"Start Date column data"+date+" is not equal or greater than input date "+dateInput);
        	}
        	else {
        		assertTrue(false,"Start Date column data"+date+" is not equal or greater than input date "+dateInput);
        	}
        }
    }
    
    @Test(priority = 3, groups="P3", description = "Verify End Date filter")
    public void verifyEndDateFilter() throws Exception {
    	String dateInput = "07/11/2011";
    	adminAccount.clearFilters();
        adminAccount.endDate.waitUntilClickable();
    	adminAccount.endDate.selectDate(dateInput);
        adminAccount.filterButton.click();
        assertTrue(adminAccount.accountsTable.getColumn("End Date").contains(dateInput),
                "Actual " + adminAccount.accountsTable.getColumn("End Date").get(0) + "Expected " + dateInput);
    }

    @Test(dataProvider = "accountTypeFilter", priority = 3, groups="P3", description = "RPX-12567|RPX-9564 Check all account type filters")
    public void checkAccountTypeFilter(String inputOption, String output) throws Exception {        
    	adminAccount.clearFilters();
    	adminAccount.account_Type.selectByOption(inputOption);
        Thread.sleep(2000);
        adminAccount.filterButton.click();
        adminAccount.loading.waitUntilInvisible();
        Thread.sleep(2000);
        adminAccount.accountsTable.getColumnLinkElem("Name").click();
        adminAccount.editAccountDetails.waitUntilVisible();
        assertEquals(adminAccount.accountType.getText(), output);
        adminAccount.navigateBack();
    }

    @DataProvider(name = "accountTypeFilter")
    public Object[][] getAccountTypeFilter() {
        return new Object[][] { { "Member", "Member" }, { "Prospect", "Prospect" } , { "NPE_Law_Firm", "NPE_Law_Firm" }, { "Insurance_Broker", "Insurance_Broker"} };
    }

    @Test(dataProvider = "activeTypeFilter", priority = 4, groups="P3", description = "RPX-9564 Check all active type filters")
    public void checkActiveTypeFilter(String searchField, boolean expected) throws Exception {
        adminAccount.clickSearchFilter(searchField);
        Thread.sleep(2000);
        adminAccount.filterButton.click();
        adminAccount.loading.waitUntilInvisible();
        Thread.sleep(2000);
        adminAccount.accountsTable.getColumnLinkElem("Name").click();
        adminAccount.editAccountDetails.waitUntilVisible();
        assertEquals(adminAccount.isActive.isPresent(), expected);
        adminAccount.navigateBack();
    }

    @DataProvider(name = "activeTypeFilter")
    public Object[][] getActiveTypeFilter() {
        return new Object[][] { { "active_true", true }, { "active_false", false } };
    }

    @Test(priority = 5, groups="P3", description = "Check edit page")
    public void checkAccountsEditPage() throws Exception {
        adminAccount.accountsTable.getColumnLinkElem("Name").waitUntilVisible();
        adminAccount.accountsTable.getColumnLinkElem("Name").click();
        adminAccount.editAccountDetails.waitUntilVisible();
        ArrayList<String> headerList = adminAccount.editHeaderList.getAllData();
        ArrayList<String> currentHeaderList = adminAccount.currentUsersHeaderList.getAllData();
        assertEquals(headerList.toArray(new String[headerList.size()]), adminAccount.headerList);
        assertEquals(currentHeaderList.toArray(new String[currentHeaderList.size()]), adminAccount.currentUsersColumn);
    }
    
    @BeforeGroups(groups="changeAccountStatus")
    public void disableAccount() throws Exception {
        String accountName = "Apple Inc.";
    	createUser(emailId, ROLES.BASIC);   
    	updateAccountForUser(accountName);
    	changeActiveStateForAccount(accountName,false);
    	to(homePage);
    }
    
    @Test(priority=6,groups={"P3","changeAccountStatus"},description="Verify login should not work for disabled account mapped user | RPX-12590")
    public void checkLoginForDisabledAccUser() throws InterruptedException {
    	logout();
    	at(loginPage);
    	loginPage.login(emailId, "Welcome@1", false);
    	at(loginPage);    	
    }
    
    @AfterGroups(groups="changeAccountStatus")
    public void activateAccount() {
        String accountName = "RPX Consulting";
    	loginAs(ROLES.ADMIN);
    	changeActiveStateForAccount(accountName,true);
    }
    
    
    public void updateAccountForUser(String accountName) throws Exception {
    	//Update User Account
    	to(userEditpage,getUserId(emailId));
    	userEditpage.userAccounts.typeAndselect(accountName);//Macronix
    	userEditpage.saveUser_btn.click();
    	at(userViewPage);
    }
    
    public void changeActiveStateForAccount(String accountName , boolean isActive) {
    	//Disable or Enable Account
    	to(adminAccount);
    	adminAccount.goToEditAccountPage(accountName);
    	at(rpxAccEditPage);
    	rpxAccEditPage.activateAccount(isActive);
    	rpxAccEditPage.saveChanges();
    }
}
