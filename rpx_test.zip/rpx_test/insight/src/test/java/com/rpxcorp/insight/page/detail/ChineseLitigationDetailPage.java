package com.rpxcorp.insight.page.detail;

import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

public class ChineseLitigationDetailPage extends BaseDetailPage {

    @Override
    public boolean at() {
        loading.waitUntilNoElementPresent();
        waitForPageLoad();
        return title.waitUntilVisible();
    }

    public ChineseLitigationDetailPage() {
        this.url = new PageUrl("litigation/china/{ID}");
    }

    public final Element title = $(".detail-page-title>span:first-child");
    public final Element viewJudgement_btn = $("div#judgement_url>a");

    public final Element judgementUnavailableBtn = $("div#judgement_url>a:contains('Judgement Unavailable')");
    public final Element statsDaysInLitigation = $("div.metrics_card  a[href='#'] .count");

    public final Element patentInfoViewAsSearch = $("div#patent_information a.view-as-search");

    public void selectCasesTab() {
        if (caseTabLink.isDisplayed()) {
            caseTabLink.click();
            waitForPageLoad();
        }
    }

    public final StaticContent headerDetails = $(".header-info", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("case_no", "li:nth-of-type(1)");
                dataForm.content("filed_date", "li:contains(Filed)");
                dataForm.content("closed_date", "li:contains(Closed)");
            }
    );

//    public final StaticContent patentInSuitContent = $("#patents_in_suit", (Configure<StaticContent>) dataForm ->
//            {
//                dataForm.content("patent", "tbody td:nth-of-type(1)");
//                dataForm.content("title", "tbody td:nth-of-type(2)");
//                dataForm.content("est_priority_date", "tbody td:nth-of-type(3)");
//            }
//    );

    public final Element noPatentInSuitMsg = $("#patents_in_suit span");
    public final Table patentInSuit = $("table.patents-in-suit-table", (Configure<Table>) table ->
            {
                table.row("table.patents-in-suit-table tboby tr");
                table.uniqueId("td:nth-of-type(1)");
                table.viewAllLink(By.xpath("//*[@id='dockets_wrapper']//a[text()='View All']"));
                table.viewLessLink(By.xpath("//*[@id='dockets_wrapper']//a[text()='View Less']"));
                table.displayedRecords("#dockets_wrapper tbody>tr, #dockets_wrapper>div:not([style*='none']) tbody>tr");
            }
    );

    public final Tabs litigationCampaignTabs = new Tabs("#lit-campaign dl");

    public final Table litigation_cases = $("table.litigations_table", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(3)");
                table.viewAllLink(By.xpath("//div[contains(@id, 'simple1')]//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[contains(@id, 'simple1')]//a[text()='View Less']"));
                table.displayedRecords(".litigations_table tbody tr:not([style*='none'])");
            }
    );

    public final Element caseNameLinkInLitCampDefTabSubTable = $("#campaign_defendants .nested_inner_table td:nth-of-type(3) a");
    public final Element caseNoLinkInLitCampDefTabSubTable = $("#campaign_defendants .nested_inner_table td:nth-of-type(4) a");
    public final Element litCampDefendantMostRecentCaseLink = $("#campaign_defendants tbody td:nth-of-type(3) a");
    public final Element noDataInDefendantTable = $("#campaign_defendants .dataTables_empty");
    public final Element caseTabLink = $("#lit-campaign a[href='#simple1']");

    public void defendantSearch(String searchTerm) {
        defendantSearchBox.sendKeys(searchTerm);
        waitForLoading();
    }
    public final Element defendantSearchBox = $(".dataTables_filter div.search_text_container>input[type='text']");
    public final Element litCampViewAsSearchResults = $("div[data-url*='related_cases'] .view-as-search");
    public final Element noPatentsInLitCamp = $("#simple3 span");
    public final Table camp_patent_table = $("#related_patents_table_wrapper", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(2) a[href]");
                table.viewAllLink(By.xpath("//div[contains(@id, 'simple3')]//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[contains(@id, 'simple3')]//a[text()='View Less']"));
                table.displayedRecords("#related_patents_table_wrapper tbody tr:not([style*='none'])");
            }
    );

    public final Table defendant_table = $("#campaign_defendants", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(1)>a:last-child");
                table.viewAllLink(".campaign_defendants a.view-all");
                table.viewLessLink(By.xpath("//div[@id='simple2']//a[text()='View Less']"));
                table.row("table#campaign_defendants>tbody>tr[role='row']");
                table.subTable($(".nested_inner_table", (Configure<Table>) subTable ->
                {
                    subTable.uniqueId("td:nth-child(2) a[href]");
                }));
                table.expandSubTableLink(".open.cursor-pointer");
                table.displayedRecords("#campaign_defendants tbody tr:not([style*='none'])");
            }
    );



    //PATENT INFORMATION
    //PATENT-IN-SUIT
    public Element patent_in_suite_HeaderCount = $("div#patents_in_suit>h4:contains('Patent')");
    public final Table PATENT_TABLE = $(".patents-in-suit-table ", (Configure<Table>) table ->
            {
                table.uniqueId(" .lit_doc ");
                table.viewAllLink(By.xpath("//div[@id='patents_in_suit']//span/a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[@id='patents_in_suit']//span/a[text()='View Less']"));
                table.displayedRecords(".patents-in-suit-table tbody tr:not([style*='none'])");
            }
    );

    public final StaticContent metricsSection = $("#metric-statistics", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("plaintiffCount", ".metrics_card a[href='#plaintiff'] .count");
                dataForm.content("defendantCount", ".metrics_card a[href='#defendants'] .count");
                dataForm.content("patentInSuitCount", ".metrics_card a[href='#patent_information'] .count");
                dataForm.content("dayInLitCount", ".metrics_card .count");
            }
    );

    public final StaticContent patentInSuitContent = $("#patents_in_suit", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("patent", "tbody td:nth-of-type(1)");
                dataForm.content("title", "tbody td:nth-of-type(2)");
                dataForm.content("est_priority_date", "tbody td:nth-of-type(3)");
            }
    );

    public final Table chinese_litigation_table = $("table.patents-in-suit-table", (Configure<Table>) table ->
            {

            }
    );

    public final Element patentInfoTitle = $("#patent_information");
    public final Element viewInRPXAnalyst = $("#view-in-analyst");
    public final Element viewAsSearchResults = $("#patent_information a:nth-of-type(2)");
    public final Element patentsInSuit = $("#patents_in_suit h4");

    public final Table plaintiffPartiesContent = $("#plaintiff_container", (Configure<Table>) table ->
            {
                table.uniqueId("ul>li>.en_toggle>a");
                table.column("ent_name", "ul>li>.en_toggle>a");
            }
    );

    public final Table defendantPartiesContent = $("#defendants_container", (Configure<Table>) table ->
            {
                table.uniqueId("ul>li>.en_toggle>a");
                table.column("ent_name", "ul>li>.en_toggle>a");
            }
    );

    public final Table plaintiffCounselPartiesContent = $("#plaintiff_container", (Configure<Table>) table ->
            {
                table.uniqueId("ul>li>.en_toggle>a");
                table.column("counsel_details", "ul li div:last-child:not(.hide)");
            }
    );

    public final Table defendantCounselPartiesContent = $("#defendants_container", (Configure<Table>) table ->
            {
                table.uniqueId("ul>li>.en_toggle>a");
                table.column("counsel_details", "ul li div:last-child:not(.hide)");
            }
    );

    public final StaticContent  overviewContent = $("#overview", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("caseType", "li:contains(Case)");
                dataForm.content("court", ".right_side li:nth-of-type(1):contains(Court)");
                dataForm.content("marketSector", "li:contains(Market)");
                dataForm.content("judge", "li.en_toggle a");
                dataForm.content("courtAttitude", "li:contains(Attitude)");
                dataForm.content("disputeLevel", "li:contains(Dispute)");
                dataForm.content("damagesAwarded", "li:contains(Awarded)");
                dataForm.content("damagesClaimed", "li:contains(Claimed)");
            }
    );

    public String courtAttitudeValue() {
        if(overviewContent.getData().containsKey("courtAttitude")) {
            return overviewContent.getData("courtAttitude");
        }

        return "";
    }

    public final StaticContent firstInstanceOutomeContent = $("#outcome>div:nth-of-type(1)", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("damages_claimed", "li:contains(Damages Claimed)");
                dataForm.content("damages_awarded", "li:contains(Damages Awarded)");
                dataForm.content("injunction_claimed", "li:contains(Injunction Claimed)");
                dataForm.content("injunction_awarded", "li:contains(Injunction Awarded)");
                dataForm.content("cost_claimed", "li:contains(Cost Claimed)");
                dataForm.content("cost_awarded", "li:contains(Cost Awarded)");
                dataForm.content("apology_claimed", "li:contains(Apology Claimed)");
                dataForm.content("apology_awarded", "li:contains(Apology Awarded)");
                dataForm.content("first_outcome", "li:contains(Outcome)");
            }
    );

    public final StaticContent secondInstanceOutomeContent = $("#outcome>div:nth-of-type(2)", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("damage_awarded", "li:contains(Damages Awarded)");
                dataForm.content("injunction_awarded", "li:contains(Injunction Awarded)");
                dataForm.content("cost_awarded", "li:contains(Cost Awarded)");
                dataForm.content("apology_awarded", "li:contains(Apology Awarded)");
                dataForm.content("second_outcome", "li:contains(Outcome)");
            }
    );

    public Element plaitiff_count = $("#plaintiff div.round-shape span");
    public Element defendant_count = $("#defendants div.round-shape span");
    public Element other_parties_count = $("#other_parties_container .round-shape span");
    public final Table PLAINTIFF_PARTIES = $("#plaintiff_container", (Configure<Table>) table ->
            {
                table.viewAllLink(By.xpath("//div[@id='plaintiff_container']//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[@id='plaintiff_container']//a[text()='View Less']"));
                table.displayedRecords("#plaintiff_container ul:not([style*='none']) li>a:not([class])");
                table.uniqueId("li a[href]:nth-child(1)");
                table.column("ent_name", "li a[href]:nth-child(1)");
                table.column("counsel_details", "div.counsel-content");
            }
    );
    public final Element plaintiffSectionLink = $("#plaintiff_container li a:not([class])");
    public final Element counselInfoArrowInPlaintiffSection = $("#plaintiff_container li a[class*=arrow]");
    public final Element counselContentInPlaintiffSection = $("#plaintiff_container li .counsel-content");
    public final Element showAllCounselInPlaintiffSection = $(By.xpath("//div[@id='plaintiff_container']//a[text()='Show All Counsel']"));
    public final Element hideAllCounelInPlaintiffSection = $(By.xpath("//div[@id='plaintiff_container']//a[text()='Hide All Counsel']"));

    public final Table DEFENDANT_PARTIES = $("#defendants_container", (Configure<Table>) table ->
            {
                table.viewAllLink(By.xpath("//div[@id='defendants_container']//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[@id='defendants_container']//a[text()='View Less']"));
                table.displayedRecords("#defendants_container ul:not([style*='none']) li>a:not([class])");
                table.uniqueId("li a[href]:nth-child(1)");
                table.column("ent_name", "li a[href]:nth-child(1)");
                table.column("counsel_details", "div.counsel-content");
            }
    );


    public final Element defendantSectionLink = $("#defendants_container li a:not([class])");
    public final Element counselInfoArrowInDefendantSection = $("#defendants_container li a[class*=arrow]");
    public final Element counselContentInDefendantSection = $("#defendants_container li .counsel-content");
    public final Element hideAllCounelInDefendantSection = $("div#defendants_container a:contains('Hide All Counsel')");
    public final Element defendants_showAllCounsel = $("div#defendants_container a:contains('Show All Counsel')");

    public final Table OTHER_PARTIES = $("#other_parties_container", (Configure<Table>) table ->
            {
                table.viewAllLink(By.xpath("//div[@id='other_parties_container']//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[@id='other_parties_container']//a[text()='View Less']"));
                table.displayedRecords("#other_parties_container ul:not([style*='none']) li>a:not([class])");
                table.uniqueId("li a[href]:nth-child(1)");
                table.column("ent_name", "li a[href]:nth-child(1)");
                table.column("counsel_details", "div.counsel-content");
            }
    );

    public final Element judgementURL = $("#judgement_url a:not([class*=hide])");

    public String getJudgementDocumentNumber(){
        String documentNumber = "";
        if(judgementURL.isDisplayed()) {
            documentNumber = judgementURL.getAttribute("href").split("rpxcorp.com/")[1];
        }
        return documentNumber;
    }

    public final Element chineseEnglishToggleButton = $("#chn_eng_toggle");

    public void changeChineseToggle() {
        chineseEnglishToggleButton.click();
    }

    public final StaticContent header_info =$( ".header-info.details",(Configure<StaticContent>) dataForm ->{
        dataForm.content("docket_number", "li:nth-child(1)");
        dataForm.content("filed_date", "li:contains(Filed)");
        dataForm.content("closed_date", "li:contains(Closed)");
        dataForm.content("latest_docket_entry", "li:contains(Latest Docket)");
    });


    public final Element chineseLitigationCampaign = $("div#lit-campaign");


    public final Element chnEngToggle = $("input#chn_eng_toggle");
    public final Element chineseView = $("div#plaintiff_container div.chn_toggle:visible");
    public final Element englishView = $("div#plaintiff_container div.en_toggle:visible");

    public final Element chineseLitProcessLearnMoreLink = $("div.panel h5:contains('Chinese Litigation Process')+p>a");
    public final Element chineseLitPageUpgradePromoMessage = $("section#content div:contains('Start with a Free Trial')");

    public void switch_Englishtoogle_view() {
        if (!englishView.isDisplayed()) {
            chnEngToggle.click();
            waitForPageLoad();
        }
    }
}
