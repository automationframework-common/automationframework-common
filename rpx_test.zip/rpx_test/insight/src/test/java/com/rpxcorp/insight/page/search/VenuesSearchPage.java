package com.rpxcorp.insight.page.search;

import com.rpxcorp.insight.page.detail.BaseDetailPage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class VenuesSearchPage extends BaseDetailPage{

    public VenuesSearchPage() {
        this.url = new PageUrl("advanced_search/search_venues");
    }

    @Override
    public boolean at() {
        waitForPageLoad();
        return currentSearch.waitUntilVisible();
    }

    public final Element venue_result_count = $("div.search-venues .count-info p");

    public int returnVenuesCount() throws Exception{
        int judgesCount=0;
        String[] countString = venue_result_count.getText().split("of");
        judgesCount = Integer.parseInt((countString[1]).replaceAll("[\\D]", "").trim());
        return judgesCount;
    }

}


