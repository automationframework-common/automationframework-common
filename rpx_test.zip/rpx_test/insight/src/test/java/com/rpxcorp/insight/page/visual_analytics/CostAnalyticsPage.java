package com.rpxcorp.insight.page.visual_analytics;

import com.rpxcorp.insight.module.Highchart;
import com.rpxcorp.insight.module.ListPanel;
import com.rpxcorp.insight.module.Radio;
import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

public class CostAnalyticsPage extends BasePage {

	public CostAnalyticsPage() {
		this.url = new PageUrl("analytics/cost");
	}

	@Override
	public boolean at() {
		loading.waitUntilInvisible();
		contentLoading.waitUntilInvisible();
		return searchPanelTabs.waitUntilVisible();
	}



	public final Element dropDown_Results = $("div#select2-drop ul");

	public final ListPanel Jurisdiction = $("div.medium-4.columns:nth-of-type(1) ul", (Configure<ListPanel>) list ->
		{
			list.dataKey(" label");
		}
	);
	public final ListPanel CaseType = $("ul.columnized li", (Configure<ListPanel>) list ->
		{
			list.dataKey(" label");
		}
	);

	public final Tabs searchPanelTabs = new Tabs("div.columns.down-tabs .tabs");
	public final Element costAnalyticsContent = $("#cost_analytics_content h3");
	public final Element costAnalyticsPromo = $(By.xpath("//div[@id='cost_analytics_content']"
			+ "//p[contains(text(), 'Cost analytics is only available to companies that have participated in a survey of NPE-related costs')]/a"));
	public final Element ptabCostAnalyticsPromo = $(By.xpath("//div[@id='ptab_cost_analytics_content']"
			+ "//p[contains(text(), 'Cost analytics is only available to companies that have participated in a survey of NPE-related costs')]/a"));
	public final Element analyzeButton = $("input[value='Analyze']");
	public void openPartyResearchTab() {
		searchPanelTabs.select("PARTY RESEARCH");
	}

	public void openLitigationCostAnalyticsTab() {
		searchPanelTabs.select("Litigation Cost Analytics");
		aboutCostAnalyticsSection.waitUntilVisible();
	}

	public void openPtabCostAnalyticsTab() {
		searchPanelTabs.select("PTAB Cost Analytics");
        aboutPTABCostAnalyticsSection.waitUntilVisible();
	}

	/** COST ANALYTICS TAB CONTENT **/
	/** LITIGATION COST ANALYTICS **/
	public final Element settlementCostByTerminationYearPromo=$(".header-chart:contains('Settlement or Judgment Cost by Termination Year')+div .cost_chart_promo_holder");
	public final Element proportionCostByTotalCaseCostPromo=$(".header-chart:contains('Proportion of Legal and Resolution Cost by Total Case Cost')+div .cost_chart_promo_holder");
	public final Element meanResolutionCostTypeChartPromo=$(".header-chart:contains('Mean Resolution Cost by Defendant Revenue')+div .cost_chart_promo_holder");
	public final Element meanResolutionChartEndAtGivenStagePromo=$(".header-chart:contains('Mean Resolution Costs for Suits That End at a Given Stage')+div .cost_chart_promo_holder");
	public final Element meanResolutionChartReachedAtGivenStagePromo=$(".header-chart:contains('Mean Resolution Costs for Suits That Reached at Least the Given Stage')+div .cost_chart_promo_holder");
	public final Element legalCostPerCaseByPatentCategoryPromo=$(".header-chart:contains('Legal Cost Per Case by Patent Category ')+div .cost_chart_promo_holder");

	public final Element aboutCostAnalyticsSection =$("div.analytics-sub-header .about_content p:not(:empty)");
	public final Element settlementCostByTerminationYearTitle = $(By.xpath("//div[contains(@class,'settlement_by_year_chart')]/../../../../../div//h3"));
	public final Element settlementCostByTerminationYearTooltip = $(By.xpath("//div[contains(@class,'settlement_by_year_chart')]/../../../../../div//i[contains(@class,'tooltip-help')]"));
	public final Element settlementCostByTerminationYearTooltipContent = $("div.qtip-content p");
	public final Element settlementCostByTerminationYearLegendImage = $(".settlement_by_year_chart .highcharts-legend-item img");
	public final Highchart settlementCostByTerminationYearChart = $(".settlement_by_year_chart", (Configure<Highchart>) chart ->
		{
			chart.axisLabels("terminated_year", "svg g[class*='highcharts-xaxis-labels']:nth-of-type(19) text");
			chart.axisLabels("litigation_count", "svg g[class*='highcharts-xaxis-labels']:nth-of-type(20) text");
			chart.axisLabels("percentile_25", "svg g[class*='highcharts-xaxis-labels']:nth-of-type(22) text");
			chart.axisLabels("percentile_50", "svg g[class*='highcharts-xaxis-labels']:nth-of-type(23) text");
			chart.axisLabels("percentile_75", "svg g[class*='highcharts-xaxis-labels']:nth-of-type(24) text");
			chart.axisLabels("percentile_90", "svg g[class*='highcharts-xaxis-labels']:nth-of-type(25) text");
			chart.graphBars(".highcharts-tracker");
			chart.toolTipContent(".highcharts-tooltip span");
		}
	);

	public final Element proportionCostByTotalCaseCostSlider = $(".range-slider-handle");
	public final Element proportionCostByTotalCaseCostTitle = $("div.left-sector.panel-space-left h3.left-right-padded  span:contains('Proportion of Legal and Resolution Cost by Total Case Cost')");
	//public final Element proportionCostByTotalCaseCostTooltip = $(By.xpath("//div[@class='proportion-range-slider-container']/../../../../div//i"));
	public final Element proportionCostByTotalCaseCostTooltip = $("div.left-sector.panel-space-left h3.left-right-padded>i:not([data-hasqtip=\"30\"])");
	public final Element proportionCostByTotalCaseCostTooltipCotent = $(".qtip-fixed.qtip-focus p");
	public final Highchart proportionCostByTotalCaseCostChart = $(".stagewise_proportional_chart", (Configure<Highchart>) chart ->
		{
			chart.trackers("legal_cost", ".highcharts-series-group g[class*='highcharts-tracker'] path[fill='#0494FE']");
			chart.trackers("settlement_judgment_cost", ".highcharts-series-group g[class*='highcharts-tracker'] path[fill='#93CEFA']");
		}
	);

	public final Element resolutionCostTypeChartTitle = $(By.xpath("//div[@class='mean-median-resolution-cost-chart']/../../../../../..//h3"));
	public final Element resolutionCostTypeChartTooltip = $(By.xpath("//div[@class='mean-median-resolution-cost-chart']/../../../../../..//i"));
	public final Element resolutionCostTypeChartTooltipContent = $(".qtip-fixed.qtip-focus p");
	public final Element resolutionCostTypeDropdown = $(".mean-median-selection-container #mean_median_chart_cost_type");
	public final Element resolutionCostTypeXAxis = $(".mean-median-selection-container #mean_median_chart_xaxis_type");
	public void selectResolutionCostAndXAxisValues(String resolutionCostType, String xAxis) {
		resolutionCostTypeDropdown.selectByOption(resolutionCostType);
		resolutionCostTypeXAxis.selectByOption(xAxis);
	}
	public final Highchart resolutionCostTypeChart = $(".mean-median-resolution-cost-chart", (Configure<Highchart>) chart ->
		{
			chart.axisLabels("bin_group", "svg g:nth-of-type(12) text");
			chart.axisLabels("litigation_count", "svg g:nth-of-type(13) text");
			chart.dataLabels("mean_total_cost", "svg g:nth-of-type(8) text");
			chart.dataLabels("settlement_cost", ".highcharts-data-labels.highcharts-series-0 g text");
			chart.dataLabels("legal_cost", ".highcharts-data-labels.highcharts-series-1 g text");
		}
	);
	public final Highchart resolutionCostTypeChartMedian = $(".mean-median-resolution-cost-chart", (Configure<Highchart>) chart ->
		{
			chart.axisLabels("bin_group", "svg g:nth-of-type(11) text");
			chart.axisLabels("litigation_count", "svg g:nth-of-type(12) text");
			chart.dataLabels("median_total_cost", "g[class*='highcharts-stack-labels']:nth-of-type(8) text");
		}
	);

	public final Element meanResolutionChartEndAtGivenStageTitle = $(By.xpath("//div[contains(@class,'stagewise_mean_chart')][@data-chart-type='column']/../../../../..//h3"));
	public final Element meanResolutionChartEndAtGivenStageTooltip = $(By.xpath("//div[contains(@class,'stagewise_mean_chart')][@data-chart-type='column']/../../../../..//i"));
	public final Element meanResolutionChartEndAtGivenStageTooltipContent = $(".qtip-fixed.qtip-focus p");
	public final Highchart meanResolutionChartEndAtGivenStage = $("div[class*='stagewise_mean_chart'][data-chart-type='column']", (Configure<Highchart>) chart ->
		{
			chart.trackers("legal_cost", "g.highcharts-series-group>g[class*='highcharts-series-0']:not([visibility='hidden']"); //Added highcharts-column-series
			chart.trackers("settlement_judgment_cost", "g.highcharts-series-group>g[class*='highcharts-series-1']:not([visibility='hidden']");
			chart.trackers("no_data", "g.highcharts-label.highcharts-no-data");//
		}
	);


	public final Element meanResolutionChartReachedAtGivenStageTitle = $(By.xpath("//div[contains(@class,'stagewise_mean_chart')][@data-chart-type='area']/../../../../..//h3"));
	public final Element meanResolutionChartReachedAtGivenStageTooltip = $(By.xpath("//div[contains(@class,'stagewise_mean_chart')][@data-chart-type='area']/../../../../..//i"));
	public final Element meanResolutionChartReachedAtGivenStageTooltipContent = $(".qtip-fixed.qtip-focus p");

	public final Highchart meanResolutionChartReachedAtGivenStage = $("div[class*='stagewise_mean_chart'][data-chart-type='area']", (Configure<Highchart>) chart ->
		{
			chart.trackers("legal_cost", ".highcharts-series-group g[class*='highcharts-series-1']:not([visibility='hidden']");
			chart.trackers("settlement_judgment_cost", ".highcharts-series-group g[class*='highcharts-series-0']:not([visibility='hidden']");
			chart.trackers("no_data", "g[class='highcharts-no-data']");
		}
	);

	public final Element patentProductResolutionTitle = $("div.ent_lit_search:has(div.patent-and-product-resolution-cost-chart) h3>span");
	public final Element patentProductResolutionTooltip = $("div.ent_lit_search:has(div.patent-and-product-resolution-cost-chart) h3 i");
	public final Element patentProductResolutionTooltipContent = $("div.cost-analytics-tooltip p");   //.qtip-fixed.qtip-focus p"
	public final Element patentProductResolutionCostTypeOptions = $(".patent-product-selection-container div:nth-of-type(1) select");
	public final Element patentProductResolutionCategoryTypeOptions = $(".patent-product-selection-container div:nth-of-type(2) select");
	public final Element patentProductResolutionCategoryOptions = $(".patent-product-selection-container div:nth-of-type(3) select");
	public final Element patentProductResolutionSecondaryCategoryOptions = $(".patent-product-selection-container div:nth-of-type(4) select");
	public void selectPatentProductResolutionOptions(String costType, String categoryType, String category, String secondaryCategory) {
		patentProductResolutionCostTypeOptions.selectByOption(costType);
		patentProductResolutionCategoryTypeOptions.selectByOption(categoryType);
		patentProductResolutionCategoryOptions.selectByOption(category);
		patentProductResolutionSecondaryCategoryOptions.selectByOption(secondaryCategory);
	}
	public final Highchart patentProductResolutionChart = $(".patent-and-product-resolution-cost-chart", (Configure<Highchart>) chart ->
		{
			chart.axisLabels("overall_cmpy_count", "svg g[class*='highcharts-xaxis-labels']:nth-of-type(21) text");
			chart.axisLabels("company_count", "svg g[class*='highcharts-xaxis-labels']:nth-of-type(22) text");
			chart.axisLabels("litigation_count", "svg g[class*='highcharts-xaxis-labels']:nth-of-type(23) text");
			chart.axisLabels("mean", "svg g[class*='highcharts-xaxis-labels']:nth-of-type(24) text");
			chart.axisLabels("legal_percentile_25", "svg g[class*='highcharts-xaxis-labels']:nth-of-type(25) text");
			chart.axisLabels("legal_percentile_50", "svg g[class*='highcharts-xaxis-labels']:nth-of-type(26) text");
			chart.axisLabels("legal_percentile_75", "svg g[class*='highcharts-xaxis-labels']:nth-of-type(27) text");
			chart.axisLabels("legal_percentile_90", "svg g[class*='highcharts-xaxis-labels']:nth-of-type(28) text");
			chart.graphBars(".highcharts-tracker");
			chart.toolTipContent(".highcharts-tooltip text tspan:not([style])");
		}
	);

	/** PTAB COST ANALYTICS **/
    public final Element ratioOfCostsPerPtabPetitionPromo=$(".header-chart:contains('Ratio of Costs Per PTAB Petition')+div .cost_chart_promo_holder");
    public final Element petitionCostsByOutcomePromo=$(".header-chart:contains('Cumulative PTAB Petition Cost by Stage')+div .cost_chart_promo_holder");
    public final Element petitionCostsByStagePromo=$(".header-chart:contains('PTAB Petition Costs by Outcome')+div .cost_chart_promo_holder");

    public final Element aboutPTABCostAnalyticsSection =$("div.analytics-sub-header .about_content p:not(:empty)");
	public final Element ratioOfCostsPerPtabPetitionTitle = $(By.xpath("//div[contains(@class, 'cost_per_petition_chart')]/../../../../..//h3"));
	public final Element ratioOfCostsperPtabPetitionTooltip = $(By.xpath("//div[contains(@class, 'cost_per_petition_chart')]/../../../../..//i"));
	public final Element ratioOfCostsperPtabPetitionTooltipContent = $(".qtip-fixed.qtip-focus p");
	public final Highchart ratioOfCostsperPtabPetitionChart = $(".cost_per_petition_chart", (Configure<Highchart>) chart ->
		{
			chart.dataLabels("counsel", ".highcharts-data-labels.highcharts-series-0 g:nth-of-type(1) text");
			chart.dataLabels("expert", ".highcharts-data-labels.highcharts-series-0 g:nth-of-type(2) text");
			chart.dataLabels("filing", ".highcharts-data-labels.highcharts-series-0 g:nth-of-type(3) text");
		}    	
	);

	public final Element petitionCostsByOutcomeTitle = $(By.xpath("//div[contains(@class, 'cost_by_outcome_chart')]/../../../../..//h3"));
	public final Element petitionCostsByOutcomeTooltip = $(By.xpath("//div[contains(@class, 'cost_by_outcome_chart')]/../../../../..//i"));
	public final Element petitionCostsByOutcomeTooltipContent = $(".qtip-fixed.qtip-focus p");
	public final Radio petitionCostsByOutcomeCostTypeRadio = new Radio(".cost_by_outcome_chart");
	public final Highchart petitionCostsByOutcomeChart = $(".cost_by_outcome_chart", (Configure<Highchart>) chart ->
		{
			chart.axisLabels("final_outcome", ".highcharts-axis-labels.highcharts-xaxis-labels>span>center");
			chart.axisLabels("litigation_count", "#cost_per_outcome_chart>div>svg>g:nth-of-type(10) text");
			chart.dataLabels("avg_cost", ".highcharts-data-labels g");
		}
	);

	public final Element petitionCostsByStageTitle = $(By.xpath("//div[contains(@class, 'cumulative-ptab-costs-by-sector-chart')]/../../../../..//h3"));
	public final Element petitionCostsByStageTooltip = $(By.xpath("//div[contains(@class, 'cumulative-ptab-costs-by-sector-chart')]/../../../../..//i"));
	public final Element petitionCostsByStageTooltipContent = $(".qtip-fixed.qtip-focus p");
	public final Radio petitionCostsByStageCostTypeRadio = new Radio(".cumulative-ptab-cost-type-selection-container");
	public final Highchart petitionCostsByStageChart = $(".cumulative-ptab-costs-by-sector-chart", (Configure<Highchart>) chart ->
		{
			chart.axisLabels("status", "svg>g[class*='highcharts-axis-labels']:nth-of-type(11) text");
			chart.axisLabels("litigation_count", "svg>g[class*='highcharts-axis-labels']:nth-of-type(12) text");
			chart.dataLabels("ten_percentile", "svg>g[class*='highcharts-data-labels']:nth-of-type(9)>g:nth-child(6) ~ g text");
			chart.dataLabels("fifty_percentile", "svg>g[class*='highcharts-data-labels']:nth-of-type(8)>g text");
			chart.dataLabels("ninety_percentile", "svg>g[class*='highcharts-data-labels']:nth-of-type(9)>g:nth-child(-n+6) text");
		}
	);
	
	public final Element cost_analytics_about_section=$(".detail-page-title>span.section-title");
	public final Element cost_analytics_about_content=$(".analytics-sub-header div.about_content p:visible");
	public final Element cost_analytics_about_overview=$(".analytics-sub-header p>a:contains('OVERVIEW'):visible");
	public final Element cost_analytics_about_methodology=$(".analytics-sub-header p>a:contains('METHODOLOGY'):visible");
	
	public final Element ptab_cost_analytics_about_section=$(By.xpath("//div[@id='ptab_cost_analytics_content']//div[contains(@class, 'hide-for-small-only')]//div[@class='cost_analytics_about']//h2/span"));
	public final Element ptab_cost_analytics_about_content=$(By.xpath("//div[@id='ptab_cost_analytics_content']//div[contains(@class, 'hide-for-small-only')]//div[@class='cost_analytics_about']//p/span"));
	public final Element ptab_cost_analytics_about_overview=$(By.xpath("//div[@id='ptab_cost_analytics_content']//div[contains(@class, 'hide-for-small-only')]//div[@class='cost_analytics_about']//a[text()='OVERVIEW']"));
	public final Element ptab_cost_analytics_about_methodology=$(By.xpath("//div[@id='ptab_cost_analytics_content']//div[contains(@class, 'hide-for-small-only')]//div[@class='cost_analytics_about']//a[text()='METHODOLOGY']"));
	
	//Promotional Message for Basic to Prime
	public final Element partyTab_PromoMsg=$(".logged_in.page_blocked.analytics:contains('Party research is not included in your current subscription. Please') a[href='/subscribe']");
	public final Element partyTab_SignInPromoMsg=$(".anonymous.page_blocked:contains('to see additional information') a.reveal_login_from_grey_out");
}
