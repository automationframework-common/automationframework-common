package com.rpxcorp.insight.module;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.rpxcorp.testcore.util.Configure;
import org.jsoup.Jsoup;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.rpxcorp.insight.page.detail.CampaignDetailPage;
import com.rpxcorp.testcore.TableData;
import com.rpxcorp.testcore.element.Element;

public class Highchart extends Element {

	Map<String, String> highchartTrackers = new HashMap<String, String>(); 
	Map<String, String> labelMap = new HashMap<String, String>();
	Map<String, String> axisLabelMap = new HashMap<String, String>();
	Element barSelectorElem;
	Element toolTipContentElem;
	String modalUniqueId;
	String tableLocator;
	List<String> modalHeader = new ArrayList<String>();
	List<String> modalColumns = new ArrayList<String>();

	private final String legendItemSelector = "g[class^='highcharts-legend-item']:contains(%s)>rect";

	public Highchart(String locator) {
		super(locator);
	}

	public void trackers(String legendName, String markerSelector) {
		this.highchartTrackers.put(legendName, markerSelector);
	}

	public void dataLabels(String labelName, String labelValue) {		
		this.labelMap.put(labelName, labelValue);
	}

	public void axisLabels(String labelName, String labelLocator) {	
		this.axisLabelMap.put(labelName, labelLocator);		
	}

	public void graphBars(String barSelector){
		this.barSelectorElem = $(barSelector);
	}	

	public void table(String tableSelector){
		this.tableLocator = tableSelector;
	}

	public void toolTipContent(String toolTipContentSelector){
		this.toolTipContentElem = $(toolTipContentSelector);
	}

	public Element getLabelElement(String labelKey) {
		return $(labelMap.get(labelKey));
	}

	public void uniqueId(String uniqueId) {
		this.modalUniqueId = uniqueId;
	}

	public void column(String key, String value) {
		this.modalHeader.add(key);
		this.modalColumns.add(value);
	}

	public void selectLegend(String legendName) {
		if(isLegendSelected(legendName) == false) 
			$(String.format(legendItemSelector, legendName)).click();
	}

	public void deselectLegend(String legendName) {
		if(isLegendSelected(legendName) == true)
			$(String.format(legendItemSelector, legendName)).click();
	}

	public void toggleLegend(String legendName, String option) {
		if(option.equalsIgnoreCase("/"))
			selectLegend(legendName);
		else if (option.equalsIgnoreCase("x"))
			deselectLegend(legendName);
	}

	public boolean isLegendSelected(String legendName) {
		String legendIconColor = $(String.format(legendItemSelector, legendName)).getAttribute("fill");
		if(!legendIconColor.equals("#cccccc"))
			return true;

		return false;
	}

	public boolean isTrackerDisplayed(String trackerName) {
		return $(this.highchartTrackers.get(trackerName)).isDisplayed();
	}

	public void filter(Map<String, String> filterData) {
		for (Map.Entry<String, String> entry : filterData.entrySet()) {
			toggleLegend(entry.getKey(), entry.getValue());
		}
	}

	public Map<String, Boolean> getTrackerStatus() {
		Map<String, Boolean> trackerStatus = new HashMap<>();

		for (Map.Entry<String, String> entry : highchartTrackers.entrySet()) {			
			trackerStatus.put(entry.getKey(), $(entry.getValue()).isDisplayed());
		}
		return trackerStatus;
	}

	public int getLabelValue(String labelName){
		return $(labelMap.get(labelName)).getIntData();
	}

	public HashMap<String, String> getTooltipData(String keyAxisName) {
		HashMap<String, String> toolTipMap = new HashMap<>();
		List<WebElement> axisElements = $(axisLabelMap.get(keyAxisName)).getElements();

		for(int axisElemCount = 1; axisElemCount <= axisElements.size(); axisElemCount++) {			
			this.barSelectorElem.$("g:nth-of-type(" + axisElemCount + ")").waitUntilVisible();
			this.barSelectorElem.$("g:nth-of-type(" + axisElemCount + ") path:not([fill='none'])").clickAndHold();
			List<WebElement> tooltipContents = this.toolTipContentElem.getElements();			

			StringBuffer tooltipText = new StringBuffer();
			for(WebElement tooltipContent: tooltipContents){
				tooltipText.append(tooltipContent.getText().replaceAll("\\r", "").replaceAll("\\n", " ").replace(",", ""));
				tooltipText.append(" ");
			}			
			toolTipMap.put(axisElements.get(axisElemCount - 1).getText(), tooltipText.toString().trim());
		}		
		return toolTipMap;		
	}

	public HashMap<String, Map<String, String>> axisLabelValues(String keyAxisName) {
		HashMap<String, Map<String, String>> axisLabelMapValue = new HashMap<String, Map<String, String>>();
		List<WebElement> axisElements = $(axisLabelMap.get(keyAxisName)).getElements();

		if(axisLabelMap.size() > 1) {
			for(int axisElemCount = 1; axisElemCount <= axisElements.size(); axisElemCount++) {
				String keyElement = axisElements.get(axisElemCount - 1).getText(); 	
				
				if(keyElement.trim().contains("�"))
					keyElement = Jsoup.parse(axisElements.get(axisElemCount-1).getAttribute("outerHTML")).select("title").text();
				
				Map<String, String> valueMap = new HashMap<String, String>();
				for (Map.Entry<String, String> entry : axisLabelMap.entrySet()) {						
					if(!entry.getKey().equals(keyAxisName)) {				    	
						valueMap.put(entry.getKey(), $(entry.getValue() + ":nth-of-type(" + axisElemCount + ")").getText().replace(",", ""));
					}
				}				
				axisLabelMapValue.put(keyElement, valueMap);
			}
		}		
		return axisLabelMapValue;
	}

	public HashMap<String, Map<String, String>> getChartData(String keyAxisName) {
		HashMap<String, Map<String, String>> axisLabelMapValue = new HashMap<String, Map<String, String>>();

		if(axisLabelMap.size() >= 1) {
			List<WebElement> axisElements = $(axisLabelMap.get(keyAxisName)).getElements();
			for(int axisElemCount = 1; axisElemCount <= axisElements.size(); axisElemCount++) {	
				String key =  axisElements.get(axisElemCount-1).getText().replaceAll("\\r", "").replaceAll("\\n", "").replace(" ", ""); 	
				if(key.trim().contains("�"))
					key = Jsoup.parse(axisElements.get(axisElemCount-1).getAttribute("outerHTML")).select("title").text().replace(" ", "");			

				Map<String, String> valueMap = new HashMap<String, String>();
				for (Map.Entry<String, String> entry : axisLabelMap.entrySet()) {				   
					if(!entry.getKey().equals(keyAxisName)) {
						valueMap.put(entry.getKey(), $(entry.getValue() + ":nth-of-type(" + axisElemCount + ")").getText());
					}
				}	
				for (Map.Entry<String, String> entry : labelMap.entrySet()) {					
					List<WebElement> labelElements = $(entry.getValue()).getElements();					
					valueMap.put(entry.getKey(), Jsoup.parse(labelElements.get(axisElemCount - 1).getAttribute("outerHTML")).text().replace(",", ""));
				}
				axisLabelMapValue.put(key, valueMap);				
			}
		}				
		return axisLabelMapValue;
	}

	public HashMap<String, Map<String, String>> getChartData(String keyAxisName, String... values) {
		HashMap<String, Map<String, String>> axisLabelMapValue = new HashMap<String, Map<String, String>>();

		if(axisLabelMap.size() >= 1) {
			List<WebElement> axisElements = $(axisLabelMap.get(keyAxisName)).getElements();
			for(int axisElemCount = 1; axisElemCount <= axisElements.size(); axisElemCount++) {	
				String key =  axisElements.get(axisElemCount-1).getText().replaceAll("\\r", "").replaceAll("\\n", "").replace(" ", ""); 	
				if(key.trim().contains("�"))
					key = Jsoup.parse(axisElements.get(axisElemCount-1).getAttribute("outerHTML")).select("title").text().replace(" ", "");			

				Map<String, String> valueMap = new HashMap<String, String>();
				for (Map.Entry<String, String> entry : axisLabelMap.entrySet()) {				   
					if(!entry.getKey().equals(keyAxisName)) {
						valueMap.put(entry.getKey(), $(entry.getValue() + ":nth-of-type(" + axisElemCount + ")").getText().replace(",", ""));
					}
				}

				for(int valueCnt = 0; valueCnt < values.length; valueCnt++) {
					List<WebElement> labelElements = $(labelMap.get(values[valueCnt])).getElements();					
					valueMap.put(values[valueCnt], Jsoup.parse(labelElements.get(axisElemCount - 1).getAttribute("outerHTML")).text().replace(",", ""));					
				}
				axisLabelMapValue.put(key, valueMap);					
			}
		}		
		return axisLabelMapValue;
	}

	public List<String> getAxisLableValues (String keyAxisName){
		List<WebElement> axisElements = $(axisLabelMap.get(keyAxisName)).getElements();
		List<String> axisLabelValues = new ArrayList<>();
		for(int axisElemCount = 0; axisElemCount < axisElements.size(); axisElemCount++){			
			axisLabelValues.add(axisElements.get(axisElemCount).getText());			
		}		
		return axisLabelValues;		
	}

	public Map<String, String> getDataLabels() {
		Map<String, String> data = new HashMap<>();		
		for (Map.Entry<String, String> entry : labelMap.entrySet()) {			
			data.put(entry.getKey(), $(entry.getValue()).getText());
		}
		return data;
	}

	
	public TableData getBarModalData() throws InterruptedException {			
		TableData tableData = new TableData();	
		List<WebElement> barElements = barSelectorElem.getElements();		
		for (int barElementCount=0; barElementCount<barElements.size(); barElementCount++) {			
		    barElements.get(barElementCount).click();			
			new Element(By.cssSelector(".blockUI.blockOverlay")).waitUntilInvisible();
			
			Element modalContent = new Element(By.cssSelector("div.cases"));
			modalContent.waitUntilVisible();

			Table modalTable = new Table(tableLocator);
			modalTable.uniqueId(modalUniqueId);
			modalTable.column(modalHeader, modalColumns);

			tableData.addAll(modalTable.getData());			

			new Element(By.cssSelector("#async_modal .close-reveal-modal")).click();
			modalContent.waitUntilInvisible();	
			barElements = barSelectorElem.getElements();	
		}	
		return tableData;
	}
}
