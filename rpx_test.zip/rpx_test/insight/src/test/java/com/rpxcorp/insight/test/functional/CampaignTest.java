package com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.AnalystSearchPage;
import com.rpxcorp.insight.page.LitigationDocumentPage;
import com.rpxcorp.insight.page.detail.*;
import com.rpxcorp.oldtest.page.DBData;
import com.rpxcorp.testcore.Authenticate;
import org.apache.solr.client.solrj.SolrServerException;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

import java.net.MalformedURLException;
import java.util.*;


@Authenticate(role = "MEMBER")
@Test(groups = "Campaign")
public class CampaignTest extends BaseFuncTest {

    DBData data = null;
    SoftAssert softAssert;
    CampaignDetailPage campaignDetailPage;
    FedCircuitDetailPage fedCircuitDetailPage;
    LitigationDetailPage litigationDetailPage;
    EntityDetailPage entityDetailPage;
    ITCDetailPage itcDetailPage;
    PtabDetailPage ptabDetailPage;
    PatentDetailPage patentDetailsPage;
    EntityDetailPage entityPage;
    LitigationDocumentPage litigationDocumentPage;
    BaseDetailPage baseDetailPage;
    ChinesePRBDetailPage chinesePRBDetailPage;
    ReexaminationDetailPage reexaminationDetailPage;

    private String dataDownloadFileName = "";

    public static ArrayList<String> actualAvailableList;
    public static ArrayList<String> actualSelectedList;

    @BeforeClass
    public void intializeTest() throws Exception {
        data = new DBData();
    }

    @BeforeGroups(groups = "DEFENDANT VIEW")
    private void loadDefendantTab() throws Exception {
        this.urlData.put("ID", data.getCampIdWithAllCases(false));
        to(campaignDetailPage, urlData);
        campaignDetailPage.campaignOverviewSection.waitUntilVisible();
        campaignDetailPage.campaignOverviewTabs.select("Defendant");
    }

    @BeforeGroups(groups = "CASE VIEW")
    public void loadCaseViewTab() throws Exception {
        this.urlData.put("ID", data.getCampIdWithAllCases(false));
        to(campaignDetailPage, urlData);
        campaignDetailPage.campaignOverviewSection.waitUntilVisible();
        campaignDetailPage.campaignOverviewTabs.select("Case");
    }

    @BeforeGroups(groups = "CASE VIEW TRUE")
    public void loadCaseViewTabWithAllCase() throws Exception {
        this.urlData.put("ID", data.getCampIdWithAllCases(true));
        to(campaignDetailPage, urlData);
        campaignDetailPage.campaignOverviewSection.waitUntilVisible();
        campaignDetailPage.campaignOverviewTabs.select("Case");
    }

    @BeforeGroups(groups = "petitions")
    public void loadCampaignWithPetitions() throws Exception {
        this.urlData.put("ID", data.getCampIdWithAllCases(false));
        to(campaignDetailPage, urlData);
        campaignDetailPage.campaignOverviewSection.waitUntilVisible();

    }

    @BeforeGroups(groups = "camp_petitioners")
    public void loadCampaignWithPetitioners() throws Exception {
        this.urlData.put("ID", "12666");
        to(campaignDetailPage, urlData);
        campaignDetailPage.campaignOverviewSection.waitUntilVisible();
        campaignDetailPage.loadPetitionerWithAccordionExpand();
    }

    @BeforeGroups(groups = "patents")
    public void loadCampaignWithPatents() throws Exception {
        this.urlData.put("ID", data.getCampIdWithAllCases(false));
        to(campaignDetailPage, urlData);
        campaignDetailPage.campaignOverviewSection.waitUntilVisible();
        campaignDetailPage.loadPatentsWithAccordionExpand();
    }

    @BeforeGroups(groups = "patents_in_camp")
    public void loadPatentsCampaign() throws Exception {
        this.urlData.put("ID", data.getCampIdWithAllCases(false));
        to(campaignDetailPage, urlData);
        campaignDetailPage.campaignOverviewSection.waitUntilVisible();
        campaignDetailPage.patent_table.expandSubTable();
    }

    @BeforeGroups(groups = "defendant_timeline")
    public void loadDefendantTimeline() throws Exception {
        this.urlData.put("ID", "1754");
        to(campaignDetailPage, urlData);
        campaignDetailPage.defendantsInTimelineChart.waitUntilVisible();
    }

    @Test(priority = 1, groups = {"P2", "smoke"}, description = "Verify all sections in Federal Circuit details page")
    public void verifyAllSectionsInCampignDetailsPage() throws Exception {
        SoftAssert softAssert = new SoftAssert();
        to(campaignDetailPage, "421");//191
        softAssert.assertTrue(campaignDetailPage.detailPageTitle.isPresent(), "Title is not present in the campaign details page");
        softAssert.assertTrue(campaignDetailPage.overviewPanel.isPresent(), "Metrics section is not present in the campaign details page");
        softAssert.assertTrue(campaignDetailPage.campaignOverviewSection.isPresent(), "Campaign Overview section is not present in the Chinese only campaign details page");
        softAssert.assertTrue(campaignDetailPage.campaignPatentSection.isPresent(), "Patent section is not present in the Chinese only campaign details page");
        softAssert.assertTrue(campaignDetailPage.plaintiff_table.isPresent(), "plaintiff section is not present in the Chinese only campaign details page");
        softAssert.assertTrue(campaignDetailPage.petitions_table.isPresent(), "Petition section is not present in the Chinese only campaign details page");
        softAssert.assertTrue(campaignDetailPage.venueUSMap.isPresent(), "The US Venues Map is not getting displayed in the Chinese only Campaign");
        softAssert.assertTrue(campaignDetailPage.venueChinaMap.isPresent(),"The China Venues Map is not getting displayed in the Chinese only Campaign");
        softAssert.assertAll();
    }

    // TO DO get input from DB
    @Test(priority = 2, description = "Verify campaign Header", groups = {"P2", "DEFENDANT VIEW"})
    public void checkCampaignHeader() throws Exception {
        this.urlData.put("ID", "5241");
        to(campaignDetailPage, urlData);
        assertEquals(campaignDetailPage.campaignHeader.getData("NPE"), "NPE");
        assertEquals(campaignDetailPage.campaignHeader.getData("PTAB"), "PTAB");
        assertEquals(campaignDetailPage.campaignHeader.getData("ITC"), "ITC");
        assertEquals(campaignDetailPage.campaignHeader.getData("CAFC"), "CAFC");
        assertEquals(campaignDetailPage.campaignHeader.getData("Status"), "Open");
        Assert.assertTrue(campaignDetailPage.initiatedDate.getText().contains("Initiated"));
    }

    @Test(priority = 3, groups = "P2", description = "RPX-8385 ITC - Campaign Page - Metrics")
    public void checkCampaignMetricsSectionWithOtherSections() throws Exception {
        this.urlData.put("ID", "8629");
        to(campaignDetailPage, urlData);
        campaignDetailPage.caseViewTab.click();
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        Map<String, String> campaignMetrics = campaignDetailPage.overviewPanel.getData();
        campaignDetailPage.caseTable.viewAll();
        assertEquals(campaignMetrics.get("Case Count"), campaignDetailPage.caseTable.getColumn("Case Name").size());
        assertEquals(campaignMetrics.get("Petitions Count"), campaignDetailPage.petitionsPetitionTable.getColumn("Patent Number").size());
        campaignDetailPage.selectDefendantTab();
        assertEquals(campaignMetrics.get("Defendants Count"), campaignDetailPage.defendant_table.getColumn("Defendants").size());
        assertEquals(campaignMetrics.get("Patents Count"), campaignDetailPage.patentSectionTitle.getIntData());
        assertEquals(campaignMetrics.get("Defendants Terminated Count"), campaignDetailPage.getColumnCountWithValues());
        campaignDetailPage.timelineTab.click();
    }

    /**
     * LCA REPORT MODAL TESTS
     *
     * @throws Exception
     **/
    @BeforeGroups(groups = "view_lca")
    public void loadCampaignWithLCA() throws Exception {
        urlData.put("ID", data.getCampaignIdWithoutLCA(true));
        to(campaignDetailPage, urlData);
        System.out.println(campaignDetailPage.getCurrentUrl());
        campaignDetailPage.clickAndHoldLcaButton();
        campaignDetailPage.lcaRequest_link.click();
        campaignDetailPage.lcaReportModal.waitUntilVisible();
        campaignDetailPage.lcaReport_title.waitUntilVisible();
    }

    @Test(priority = 11, groups = {"P2", "view_lca"}, description = "Verify title in LCA report modal")
    public void verifyLCAReportModalTitle() throws Exception {
        assertEquals(campaignDetailPage.lcaReport_title.getText(), "Litigation Campaign Assessments",
                "LCA reports modal title is not as expected");
    }

    @Test(priority = 12, groups = {"P2", "view_lca"}, description = "RPX-10157 Verify download report in LCA report modal and validated url doesnt have s3")
    public void verifyDownloadInLCAReportModal() throws Exception {
        withNewWindow(campaignDetailPage.lcaReportDownload, () -> {
            Assert.assertFalse(getDriver().getCurrentUrl().contains("s3.amazonaws.com"),
                    "S3 URL is generated and it is displayed");
            Assert.assertTrue(getDriver().getPageSource().contains("application/pdf"), "PDF document is not loaded");
            Assert.assertTrue(getDriver().getCurrentUrl().contains("/lca_reports"),
                    "URL is not navigated to /lca_reports");
        });
    }

    @Test(priority = 13, groups = {"P4", "view_lca", "func_sorting"}, description = "Verify default sort in LCA report modal")
    public void verfiyDefaultSortInLCAReportModal() {
        assertColumnSort("date", "desc", campaignDetailPage.lcaReportTable.getColumn("Updated Date"));
    }

    @Test(priority = 14, dataProvider = "lcaReportSortData", groups = {"P4", "view_lca", "func_sorting"}, description = "Verify sorting in LCA report modal")
    public void verifySortingInLCAReportModal(String columnName, String sortType, String dataType) throws Exception {
        campaignDetailPage.lcaReportTable.sort(columnName);
        assertColumnSort(dataType, sortType, campaignDetailPage.lcaReportTable.getColumn(columnName));
    }

    @DataProvider
    public Object[][] lcaReportSortData() {
        return new Object[][]{{"Document", "asc", "non-date"}, {"Document", "desc", "non-date"},
                {"Updated Date", "asc", "date"}, {"Updated Date", "desc", "date"}};
    }

    @Test(priority = 15, groups = {"P2", "view_lca"}, description = "Verify LCA report modal close")
    public void verifyLCAReportModalClose() {
        campaignDetailPage.lcaReportModal_close.click();
        Assert.assertTrue(campaignDetailPage.lcaReportModal.waitUntilInvisible(),
                "LCA report modal is not closed properly");
    }

    @AfterGroups(groups = "view_lca")
    public void closeLCADialog() {
        if (campaignDetailPage.lcaReportModal_close.isDisplayed()) {
            campaignDetailPage.lcaReportModal_close.click();
            campaignDetailPage.lcaReportModal.waitUntilInvisible();
        }
    }

    @Test(description = "Validate Defendant tab in column link Campaign details page", groups = {"P2", "DEFENDANT VIEW"})
    public void verifyCampaignDefendantTabLinkText() throws Exception {
        boolean campaignSection;

        this.urlData.put("ID", data.getCampIdWithAllCases(true));
        to(campaignDetailPage, urlData);
        campaignDetailPage.campaignOverviewSection.waitUntilVisible();
        campaignDetailPage.defendantTab.click();
        campaignSection = campaignDetailPage.campaignOverviewSection.isDisplayed();
        if (campaignSection == true) {
            campaignDetailPage.defendantTab.click();
            campaignDetailPage.defendant_table.waitUntilClickable();
            String defendantParentText = campaignDetailPage.defendantParentLink.getText();// getColumnLinkText("Defendant
            // Parent");
            String defendantsText = campaignDetailPage.defendant_table.getColumnLinkElem("Defendants").getText();
            String mostRecentCaseText = campaignDetailPage.defendant_table.getColumnLinkText("Most Recent Case");
            assertEquals(true, campaignDetailPage.defandantTabItcCallout.isDisplayed(),
                    "ITC callout is not displayed in defendant tab");
            Assert.assertTrue(campaignDetailPage.defendantTabitcCallout.getAttribute("href").contains("/usitc/"));
            withNewWindow(campaignDetailPage.defendant_table.getColumnLinkElem("Defendants"), () -> {
                at(entityPage);
                Assert.assertTrue(getDriver().getTitle().trim().contains(defendantsText.trim()));
            });
            campaignDetailPage.defendant_table.waitUntilVisible();
            withNewWindow(campaignDetailPage.defendant_table.getColumnLinkElem("Most Recent Case"), () -> {
                if (getDriver().getCurrentUrl().contains("lit")) {
                    at(litigationDetailPage);
                    Assert.assertEquals(litigationDetailPage.header_info.getData("docket_number"), mostRecentCaseText,
                            "Most Recent Case Text didn't match in litigation detail page text");
                } else {
                    at(itcDetailPage);
                    Assert.assertEquals(itcDetailPage.subTitle.getText(), mostRecentCaseText,
                            "Most Recent Case Text didn't match in litigation detail page text");
                }
            });
            campaignDetailPage.defendant_table.waitUntilClickable();
            withNewWindow(campaignDetailPage.defendantParentLink, () -> {
                at(entityDetailPage);
                System.out.println("Title" + getDriver().getTitle() + "available: " + defendantParentText);
                Assert.assertEquals(getDriver().getTitle().contains(defendantParentText), true,
                        "Title of Page didn't match with defendant parent link text");

            });
        }
    }

    @Test(description = "Validate Defendant tab in column sort order Campaign details page", groups = {"P4", "DEFENDANT VIEW", "func_sorting"})
    public void verifySortFunctionalityInDefendentTab() throws Exception {
        loadDefendantTab();

        campaignDetailPage.defendant_table.sort("Defendants");
        List<String> defendantsTabAscSortValue = campaignDetailPage.defendant_table.getColumn("Defendants");
        assertColumnSort("non-date", "asc", defendantsTabAscSortValue);

        campaignDetailPage.defendant_table.sort("Defendants");
        List<String> defendantsTabDscSortValue = campaignDetailPage.defendant_table.getColumn("Defendants");
        assertColumnSort("non-date", "desc", defendantsTabDscSortValue);

        campaignDetailPage.defendant_table.sort("Defendant Parent");
        List<String> defendantParentAscSortValue = campaignDetailPage.defendantParent.getAllData();
        assertColumnSort("non-date", "asc", defendantParentAscSortValue);

        campaignDetailPage.defendant_table.sort("Defendant Parent");
        List<String> defendantParentDscSortValue = campaignDetailPage.defendantParent.getAllData();
        assertColumnSort("non-date", "desc", defendantParentDscSortValue);

        campaignDetailPage.defendant_table.sort("Start Date");
        List<String> startDateAscSortValue = campaignDetailPage.defendant_table.getColumn("Start Date");
        assertColumnSort("date", "asc", startDateAscSortValue);

        campaignDetailPage.defendant_table.sort("Start Date");
        List<String> startDateDscSortValue = campaignDetailPage.defendant_table.getColumn("Start Date");
        assertColumnSort("date", "desc", startDateDscSortValue);

        campaignDetailPage.defendant_table.sort("End Date");
        List<String> endDateAscSortValue = campaignDetailPage.defendant_table.getColumn("End Date");
        assertColumnSort("date", "asc", endDateAscSortValue);

        campaignDetailPage.defendant_table.sort("End Date");
        List<String> endDateDscSortValue = campaignDetailPage.defendant_table.getColumn("End Date");
        assertColumnSort("date", "desc", endDateDscSortValue);
    }

    @Test(groups = {"P4", "DEFENDANT VIEW", "func_sorting"}, description = "Verify default sort in LCA report modal")
    public void verfiyDefaultSortInDefendantTab() {

        assertColumnSort("date", "desc", campaignDetailPage.defendant_table.getColumn("Start Date"));
    }

    @Test(description = "Validate Defendant tab search functionality in Campaign details page", groups = "DEFENDANT VIEW")
    public void verifySearchFunctionalityInDefendentTab() throws Exception {
        this.urlData.put("ID", "13942");
        to(campaignDetailPage, urlData);
        campaignDetailPage.campaignOverviewSection.waitUntilVisible();
        campaignDetailPage.campaignOverviewTabs.select("Defendant");
        campaignDetailPage.defendant_table.waitUntilVisible();
        campaignDetailPage.defendantSearchBox.waitUntilClickable();
        String searchKey = campaignDetailPage.defendant_table.getColumn(2).get(1);
        System.out.println("SEARCH KEY" + searchKey);
        campaignDetailPage.defendantSearchBox.sendKeys(searchKey,
                Keys.ENTER);
        campaignDetailPage.defendant_table.waitUntilVisible();
        System.out.println("RESULTS ROW" + campaignDetailPage.defendant_table.getRows()[0]);
        Assert.assertTrue(campaignDetailPage.defendant_table.getRows()[0].contains(searchKey),
                "Search Key:" + searchKey + ", Resulted row data:" + campaignDetailPage.defendant_table.getRows()[0]);
    }

    @Test(description = "Verify sub table header text", groups = {"P2", "DEFENDANT VIEW"})
    public void verifySubTableHeaderText() throws Exception {
        loadDefendantTab();
        campaignDetailPage.defendant_table.expandSubTable();
        campaignDetailPage.defendant_table.subtable().waitUntilVisible();
        String expectedHeader[] = {"Date Filed", "Case Name", "Case Number", "Jurisdiction", "Termination Date"};
        List<String> actualHeaderList = new ArrayList<String>(Arrays.asList(campaignDetailPage.defendant_table.subtable().getHeaderData()));
        actualHeaderList.remove("Id");
        String actualHeader[] = actualHeaderList.toArray(new String[actualHeaderList.size()]);
        Assert.assertEquals(actualHeader, expectedHeader);
    }

    @Test(description = "Case Number validation between table and  sub table", groups = {"P2", "DEFENDANT VIEW"})
    public void verifyCaseNumberInTableAndSubTable() throws Exception {
        int defaultCount = 1;
        loadDefendantTab();
        String mostRecentCase = campaignDetailPage.defendant_table.getColumn("Most Recent Case").get(0);
        if (mostRecentCase.contains("( and")) {
            String[] defendantCountText = mostRecentCase.split("\\( and");
            defaultCount = Integer.parseInt(defendantCountText[1].replaceAll("[\\D]", ""))+1;
        }
        campaignDetailPage.defendant_table.expandSubTable();
        campaignDetailPage.loading.waitUntilInvisible();
        campaignDetailPage.defendant_table.subtable().waitUntilVisible();
        Assert.assertEquals(campaignDetailPage.defendant_table.subtable().getColumn(2).size(), defaultCount,
                "Count of Case Number didn't match");
    }

    @Test(description = "Verify Case View Tab table header", groups = {"P2", "CASE VIEW"})
    public void verifyCaseViewTableHeaderText() throws Exception {
        loadCaseViewTab();
        String expectedHeaderText[] = {"Date Filed", "Case Name", "Case Number", "Termination Date"};
        Assert.assertEquals(campaignDetailPage.caseTable.getHeaderData(), expectedHeaderText);
    }

    @Test(description = "Verify Case View Tab table header", groups = {"P3", "CASE VIEW"})
    public void verifyAllCaseViewTableHeaderText() throws Exception {
        String expectedHeaderText[] = {"Date Filed", "Case Name", "Case Number", "Termination Date"};
        loadCaseViewTabWithAllCase();
        Assert.assertEquals(campaignDetailPage.caseTable.getHeaderData(), expectedHeaderText);
    }

    @Test(description = "Verify Case View Tab default sort order", groups = {"P4", "CASE VIEW", "func_sorting"})
    public void verifyCaseViewTableDefaultSortOrder() throws Exception {
        loadCaseViewTab();
        Assert.assertTrue(campaignDetailPage.caseTable.getColumnHeaderElem("Date Filed").getAttribute("class")
                .contains("desc"), "Data field is not sorted in descending order");
    }

    @Test(description = "Verify Case View Tab default sort order", groups = {"P4", "CASE VIEW TRUE", "func_sorting"})
    public void verifyAllCaseViewTableDefaultSortOrder() throws Exception {
        loadCaseViewTabWithAllCase();
        Assert.assertTrue(campaignDetailPage.caseTable.getColumnHeaderElem("Date Filed").getAttribute("class")
                .contains("desc"), "Data field is not sorted in descending order");
    }

    @Test(description = "Verify Case View Tab sort functionality", groups = {"P4", "CASE VIEW", "func_sorting"})
    public void verifyCaseViewTableSortFunctionality() throws Exception {
        loadCaseViewTab();
        campaignDetailPage.caseTable.sort(1);
        List<String> dateFieldAscSortOrder = campaignDetailPage.caseTable.getColumn(0);
        assertColumnSort("date", "asc", dateFieldAscSortOrder);

        campaignDetailPage.caseTable.sort(1);
        List<String> dateFieldDscSortOrder = campaignDetailPage.caseTable.getColumn(0);
        assertColumnSort("date", "desc", dateFieldDscSortOrder);

        campaignDetailPage.caseTable.sort(2);
        List<String> caseNameAscSortOrder = campaignDetailPage.caseTable.getColumn(1);
        assertColumnSort("non-date", "asc", caseNameAscSortOrder);

        campaignDetailPage.caseTable.sort(2);
        List<String> caseNameDscSortOrder = campaignDetailPage.caseTable.getColumn(1);
        assertColumnSort("non-date", "desc", caseNameDscSortOrder);

        campaignDetailPage.caseTable.sort(3);
        List<String> caseNumberAscSortOrder = campaignDetailPage.caseTable.getColumn(2);
        assertColumnSort("string", "asc", caseNumberAscSortOrder);

        campaignDetailPage.caseTable.sort(3);
        List<String> caseNumberDscSortOrder = campaignDetailPage.caseTable.getColumn(2);
        assertColumnSort("string", "desc", caseNumberDscSortOrder);

        campaignDetailPage.caseTable.sort(4);
        List<String> terminationDateAscSortOrder = campaignDetailPage.caseTable.getColumn(3);
        assertColumnSort("date", "asc", terminationDateAscSortOrder);

        campaignDetailPage.caseTable.sort(4);
        List<String> terminationDateDscSortOrder = campaignDetailPage.caseTable.getColumn(3);
        assertColumnSort("date", "desc", terminationDateDscSortOrder);

    }

    @Test(description = "Verify Case View Tab sort functionality", groups = {"P4", "CASE VIEW TRUE", "func_sorting"})
    public void verifyAllCaseViewTableSortFunctionality() throws Exception {
        loadCaseViewTabWithAllCase();
        campaignDetailPage.caseTable.sort(1);
        List<String> newdateFieldAscSortOrder = campaignDetailPage.caseTable.getColumn(0);
        assertColumnSort("date", "asc", newdateFieldAscSortOrder);

        campaignDetailPage.caseTable.sort(1);
        List<String> newdateFieldDscSortOrder = campaignDetailPage.caseTable.getColumn(0);
        assertColumnSort("date", "desc", newdateFieldDscSortOrder);

        campaignDetailPage.caseTable.sort(2);
        List<String> newcaseNameAscSortOrder = campaignDetailPage.caseTable.getColumn(1);
        assertColumnSort("non-date", "asc", newcaseNameAscSortOrder);

        campaignDetailPage.caseTable.sort(2);
        List<String> newcaseNameDscSortOrder = campaignDetailPage.caseTable.getColumn(1);
        assertColumnSort("non-date", "desc", newcaseNameDscSortOrder);

        campaignDetailPage.caseTable.sort(3);
        List<String> newcaseNumberAscSortOrder = campaignDetailPage.caseTable.getColumn(2);
        assertColumnSort("non-date", "asc", newcaseNumberAscSortOrder);

        campaignDetailPage.caseTable.sort(3);
        List<String> newcaseNumberDscSortOrder = campaignDetailPage.caseTable.getColumn(2);
        assertColumnSort("non-date", "desc", newcaseNumberDscSortOrder);

        campaignDetailPage.caseTable.sort(4);
        List<String> newterminationDateAscSortOrder = campaignDetailPage.caseTable.getColumn(3);
        assertColumnSort("non-date", "asc", newterminationDateAscSortOrder);

        campaignDetailPage.caseTable.sort(4);
        List<String> newterminationDateDscSortOrder = campaignDetailPage.caseTable.getColumn(3);
        assertColumnSort("non-date", "desc", newterminationDateDscSortOrder);

    }


    @Test(description = "Verify Case View Tab Table data", groups = {"P2", "CASE VIEW"})
    public void verifyCaseViewTableData() throws Exception {
        loadCaseViewTab();
        String caseName = campaignDetailPage.caseTable.getColumn(1).get(0);
        String caseNumber = campaignDetailPage.caseTable.getColumn(2).get(0);
        String filedDate = campaignDetailPage.caseTable.getColumn(0).get(0);

        withNewWindow(campaignDetailPage.caseTable.getColumnLinkElem("Case Name"), () -> {
            if (getDriver().getCurrentUrl().contains("litigation") || getDriver().getCurrentUrl().contains("federal_circuit")) {
                at(baseDetailPage);
                Assert.assertEquals(baseDetailPage.header_info.getData("docket_number"), caseNumber,
                        "case number text didn't match");
                Assert.assertTrue(getDriver().getTitle().contains(caseName), "case name text didn't match");
                Assert.assertEquals(baseDetailPage.header_info.getData("filed_date").replace("Filed: ", ""), filedDate,
                        "Filed date text didn't match");
            } else {
                at(itcDetailPage);
                Assert.assertEquals(itcDetailPage.subTitle.getText(), caseNumber, "case number text didn't match");
                Assert.assertTrue(getDriver().getTitle().contains(caseName), "case name text didn't match");
                Assert.assertEquals(itcDetailPage.filedDate.getText().replace("Filed: ", ""), filedDate,
                        "Filed date text didn't match");
            }
        });
    }

    @Test(description = "Verify Case View Tab Table data", groups = {"P3", "CASE VIEW TRUE"})
    public void verifyAllCaseViewTableData() throws Exception {
        loadCaseViewTabWithAllCase();
        String newcaseName = campaignDetailPage.caseTable.getColumn(1).get(0);
        String newcaseNumber = campaignDetailPage.caseTable.getColumn(2).get(0);
        String newfiledDate = campaignDetailPage.caseTable.getColumn(0).get(0);

        withNewWindow(campaignDetailPage.caseTable.getColumnLinkElem("Case Name"), () -> {
            if (getDriver().getCurrentUrl().contains("litigation")) {
                at(litigationDetailPage);
                Assert.assertEquals(litigationDetailPage.header_info.getData("docket_number"), newcaseNumber,
                        "case number text didn't match");
                Assert.assertTrue(getDriver().getTitle().contains(newcaseName), "case name text didn't match");
                Assert.assertEquals(litigationDetailPage.header_info.getData("filed_date").replace("Filed: ", ""), newfiledDate,
                        "Filed date text didn't match");
            } else if (getDriver().getCurrentUrl().contains("federal_circuit")) {
                at(fedCircuitDetailPage);
                Assert.assertEquals(fedCircuitDetailPage.header_info.getData("docket_number"), newcaseNumber,
                        "case number text didn't match");
                Assert.assertTrue(getDriver().getTitle().contains(newcaseName), "case name text didn't match");
                Assert.assertEquals(fedCircuitDetailPage.header_info.getData("filed_date").replace("Filed: ", ""), newfiledDate,
                        "Filed date text didn't match");
            } else {
                at(itcDetailPage);
                Assert.assertEquals(itcDetailPage.subTitle.getText(), newcaseNumber, "case number text didn't match");
                Assert.assertTrue(getDriver().getTitle().contains(newcaseName), "case name text didn't match");
                Assert.assertEquals(itcDetailPage.filedDate.getText().replace("Filed: ", ""), newfiledDate,
                        "Filed date text didn't match");
            }

        });
    }

    @Test(description = "Verify Campaign Name and ITC case name is same for single ITC Campaign", groups = "P3")
    public void checkCampaignNameForITCWithoutComp() throws Exception {
        System.out.println(data.getItcIdForComplainant(false));
        urlData.put("ID", data.getItcIdForComplainant(false));
        to(itcDetailPage, urlData);
        String itcTitle = itcDetailPage.itcTitle.getText();
        withNewWindow(itcDetailPage.litCampaignLink, () -> {
            at(campaignDetailPage);
            Assert.assertTrue(campaignDetailPage.detailPageTitle.getText().contains(itcTitle),
                    "ITC Case Name and Campaign Name are not same ITC Name:" + itcTitle + ",Campaign Name:" + campaignDetailPage.detailPageTitle.getText());
        });
    }

    //Todo - Low priority Test Case
/*    @Test(description="RPX-14593-Export campaign timeline")
    public void verifyExportCampaignTimeLine() throws Exception {

        FileUtil.deleteFilesFromDirectory(new File(ConfigUtil.config().get("testOutputDir").toString()));
        to(campaignDetailPage, "1741");
        campaignDetailPage.exportBtn.click();
        waitForActiveWindow(1);
        Thread.sleep(10000);
        FileUtil.waitUntilFileDownload(ConfigUtil.config().get("testOutputDir").toString(), 60000);
        File[] filesInDir = FileUtil.listAllFilesFromADirectory(ConfigUtil.config().get("testOutputDir").toString());
        assertTrue(filesInDir.length == 1, "File does not exist after download");
        dataDownloadFileName = filesInDir[0].getName();
    }*/

    /**
     * @throws MalformedURLException
     * @throws SolrServerException
     */
    @Test(description = "RPX-9475 Validate the campaign name for ITC without complainant", groups = "P3")
    public void checkITCCampaigns() throws MalformedURLException, SolrServerException {
        String campID = null;
        List<String> itcCampaigns, campaignId = new ArrayList<>();
        campID = "1000829";
        this.urlData.put("ID", campID);
        to(campaignDetailPage, urlData);
        Assert.assertTrue(campaignDetailPage.itcTag.isDisplayed());
        Assert.assertTrue(campaignDetailPage.initiatedDate.isDisplayed());
        Assert.assertTrue(campaignDetailPage.overviewPanel.isDisplayed());
        Assert.assertTrue(campaignDetailPage.campaignOverviewSection.isDisplayed());
        Assert.assertTrue(campaignDetailPage.plantiffCounselTitle.isDisplayed());
        Assert.assertTrue(campaignDetailPage.campaignPatentWithNoData.isDisplayed());
        Assert.assertTrue(campaignDetailPage.campPetition.isDisplayed());
        Assert.assertFalse(campaignDetailPage.venueUSMap.isDisplayed());

    }

    /**
     * @throws Exception
     */
    @Test(description = "RPX-9383 ITC - Campaign Page - Patents-in-Campaign section", groups = "P2")
    public void checkItcCalloutinCampPagePatSec() throws Exception {
        String[] patentNumber = data.getCampWithItc();
        this.urlData.put("ID", patentNumber[0]);
        to(campaignDetailPage, urlData);
        Assert.assertTrue(campaignDetailPage.campaignPatentSection.isDisplayed());
        if (campaignDetailPage.viewAllVisible.isDisplayed()) {
            campaignDetailPage.patent_table.viewAllLink().waitUntilClickable();
            campaignDetailPage.patent_table.viewAllLink().click();
        }
        List<String> patentNbr = campaignDetailPage.patent_table.getColumn(0);
        List<String> newPatentNbr = new ArrayList<>();
        for (String string : patentNbr) {
            newPatentNbr.add(string.replace(",", "").replace(" ", ""));
        }
        Assert.assertTrue(newPatentNbr.contains(patentNumber[1].concat(patentNumber[1])));
    }

    @Test(priority = 501, groups = {"P2", "petitions"})
    public void verifyPetitionsSection() {
        campaignDetailPage.campaignPetitionSection.click();
        Assert.assertEquals(true, campaignDetailPage.campPetitionCollapsed.isPresent());
        Assert.assertEquals(false, campaignDetailPage.petitionPatentTable.isDisplayed());
        campaignDetailPage.campaignPetitionSection.click();
    }

    @Test(priority = 502, groups = {"P2", "petitions"}, description = "Verify header in petitions table")
    public void verifyPetitionsTableHeader() throws Exception {
        String expHeader[] = {"Date Filed", "Patent Number", "Case Number", "Petitioners", "Status",
                "Institution Decision Date"};
        assertEquals(campaignDetailPage.petitiontable.getHeaderData(), expHeader);
    }

    // TODO REFACTOR THE TEST DATA - CAMPAIGN WITH MORE THAN 7 PETITIONS
    @Test(priority = 503, groups = {"P3", "petitions"}, description = "Verify view less for petitions")
    public void verifyViewLessAndViewAllInPetitions() throws Exception {
        softAssert = new SoftAssert();
        to(campaignDetailPage, "1627");
        int defaultRecords = campaignDetailPage.petitiontable.displayedRecords().getElements().size();
        assertEquals(defaultRecords, 7, "7 records are not displaying as default");
        campaignDetailPage.petitiontable.viewAll();
        int recordsAfterViewAll = campaignDetailPage.petitiontable.displayedRecords().getElements().size();
        Assert.assertTrue(recordsAfterViewAll > defaultRecords,
                "Records displaying after clicking 'view All' shouldn't less then or equal to default record count(7)");
        campaignDetailPage.petitiontable.viewLess();
        defaultRecords = campaignDetailPage.petitiontable.displayedRecords().getElements().size();
        assertEquals(defaultRecords, 7, "7 records are not displayed after view less");
    }

    @Test(priority = 504, groups = {"P2", "petitions"}, description = "Verify case number link for petitions")
    public void verifyCaseLinkInPetitions() throws Exception {
        String caseNumber = campaignDetailPage.petitiontable.getColumnLinkText("Case Number");
        withNewWindow(campaignDetailPage.petitiontable.getColumnLinkElem("Case Number"), () -> {
            at(ptabDetailPage);
            String caseNumberDetailsPage = ptabDetailPage.subtitle.getData("Case_Number");
            Assert.assertEquals(caseNumberDetailsPage, caseNumber);
        });
    }

    @Test(priority = 505, groups = {"P2", "petitions"}, description = "Verify patent number link for petitions")
    public void verifyPatentNumberInPetitions() throws Exception {
        String patentNumber = campaignDetailPage.petitiontable.getColumnLinkText("Patent Number");
        withNewWindow(campaignDetailPage.petitiontable.getColumnLinkElem("Patent Number"), () -> {
            at(patentDetailsPage);
            String patentNumberDetailsPage = patentDetailsPage.header_info.getData("patent_number");
            Assert.assertEquals(patentNumberDetailsPage, patentNumber);
        });
    }

    @Test(priority = 506, groups = {"P2", "petitions"}, description = "Verify petitioners link for petitions")
    public void verifyPetitionersInPetitions() throws Exception {
        String Petitioners = campaignDetailPage.petitiontable.getColumnLinkText("Petitioners");
        withNewWindow(campaignDetailPage.petitiontable.getColumnLinkElem("Petitioners"), () -> {
            at(entityDetailPage);
            String entityName = entityDetailPage.detailPageTitle.getText();
            Assert.assertEquals(entityName, Petitioners);
        });
    }

    @Test(priority = 507, groups = {"P4", "petitions", "func_sorting"}, description = "Verify default sort for petitions")
    public void verifyDefaultSortInPetitions() {
        assertColumnSort("date", "desc", campaignDetailPage.petitiontable.getColumn("Date Filed"));
    }

    @Test(priority = 508, groups = {"P4", "petitions", "func_sorting"}, dataProvider = "petitionsSortData", description = "Verify sorting for petitions")
    public void verifySortingInPetitions(String columnName, String sortType, String dataType) throws Exception {
        campaignDetailPage.petitiontable.sort(columnName);
        assertColumnSort(dataType, sortType, campaignDetailPage.petitiontable.getColumn(columnName));
    }

    @DataProvider
    public Object[][] petitionsSortData() {
        return new Object[][]{{"Date Filed", "asc", "date"}, {"Patent Number", "asc", "non-date"},
                {"Patent Number", "desc", "non-date"}, {"Case Number", "asc", "non-date"},
                {"Case Number", "desc", "non-date"}, {"Petitioners", "asc", "non-date"},
                {"Petitioners", "desc", "non-date"}, {"Status", "asc", "non-date"},
                {"Status", "desc", "non-date"}, {"Institution Decision Date", "asc", "date"},
                {"Institution Decision Date", "desc", "date"}};
    }

    @Test(priority = 551, groups = {"P4", "camp_petitioners", "func_sorting"}, dataProvider = "petitionersSortData", description = "Verify sorting for petitioners")
    public void verifySortingInPetitioners(String columnName, String sortType, String dataType) throws Exception {
        campaignDetailPage.loadPetitionerWithAccordionExpand();
        campaignDetailPage.petitionersTable.sort(columnName);
        assertColumnSort(dataType, sortType, campaignDetailPage.petitionersTable.getColumn(columnName));
    }

    @Test(priority = 552, groups = {"P2", "camp_petitioners"}, description = "Verify petitioners tab accordion expansion")
    public void verifyPetitionersAccordionExpand() throws Exception {
        campaignDetailPage.loadPetitionerWithAccordionExpand();
        int accordionCount = campaignDetailPage.petitionersAccordionCount.getIntData();
        assertEquals(campaignDetailPage.petitionersTable.getRows().length, accordionCount);
        String accordionHeader = campaignDetailPage.petitionersAccordionHeader.getText();
        withNewWindow(campaignDetailPage.petitionersAccordionHeader, () -> {
            at(entityDetailPage);
            String entityName = entityDetailPage.detailPageTitle.getText();
            Assert.assertEquals(accordionHeader, entityName);
        });
    }

    @Test(priority = 552, groups = {"P2", "camp_petitioners"}, description = "Verify header in petitioners table")
    public void verifyPetitionersTableHeader() throws Exception {
        campaignDetailPage.loadPetitionerWithAccordionExpand();
        String expHeader[] = {"Date Filed", "Case Number", "Case Name", "Status"};
        assertEquals(campaignDetailPage.petitionersTable.getHeaderData(), expHeader);
    }

    @Test(priority = 553, groups = {"P2", "camp_petitioners"}, description = "Verify case number link for petitioners")
    public void verifyCaseNumberLinkInPetitioners() throws Exception {
        campaignDetailPage.loadPetitionerWithAccordionExpand();
        String caseNumber = campaignDetailPage.petitionersTable.getColumnLinkText("Case Number");
        withNewWindow(campaignDetailPage.petitionersTable.getColumnLinkElem("Case Number"), () -> {
            at(ptabDetailPage);
            String caseNumberDetailsPage = ptabDetailPage.subtitle.getData("Case_Number");
            Assert.assertEquals(caseNumberDetailsPage, caseNumber);
        });
    }

    @Test(priority = 554, groups = {"P2", "camp_petitioners"}, description = "Verify case name link for petitioners")
    public void verifyCaseNameLinkInPetitioners() throws Exception {
        campaignDetailPage.loadPetitionerWithAccordionExpand();
        String caseName = campaignDetailPage.petitionersTable.getColumnLinkText("Case Name");
        withNewWindow(campaignDetailPage.petitionersTable.getColumnLinkElem("Case Name"), () -> {
            at(ptabDetailPage);
            String caseNumberDetailsPage = ptabDetailPage.title.getText();
            Assert.assertTrue(caseNumberDetailsPage.contains(caseName));
        });
    }

    @Test(priority = 555, groups = {"P4", "camp_petitioners", "func_sorting"}, description = "Verify default sort for petitioners")
    public void verifyDefaultSortInPetitioners() {
        campaignDetailPage.loadPetitionerWithAccordionExpand();
        assertColumnSort("date", "desc", campaignDetailPage.petitionersTable.getColumn("Date Filed"));
    }

    @DataProvider
    public Object[][] petitionersSortData() {
        return new Object[][]{{"Date Filed", "asc", "date"}, {"Case Number", "asc", "non-date"},
                {"Case Number", "desc", "non-date"}, {"Case Name", "asc", "non-date"},
                {"Case Name", "desc", "non-date"}, {"Status", "asc", "non-date"},
                {"Status", "desc", "non-date"}};
    }

    @Test(priority = 581, groups = {"P4", "patents", "func_sorting"}, dataProvider = "patentsSortData", description = "Verify sorting for patents")
    public void verifySortingInPatents(String columnName, String sortType, String dataType) throws Exception {
        campaignDetailPage.loadPatentsWithAccordionExpand();
        campaignDetailPage.patentsTable.sort(columnName);
        assertColumnSort(dataType, sortType, campaignDetailPage.patentsTable.getColumn(columnName));
    }

    @Test(priority = 576, groups = {"P2", "patents"}, description = "Verify patents tab accordion expansion")
    public void verifyPatentsAccordionExpand() throws Exception {
        campaignDetailPage.loadPatentsWithAccordionExpand();
        int accordionCount = campaignDetailPage.patentsAccordionCount.getIntData();
        assertEquals(campaignDetailPage.patentsTable.getRows().length, accordionCount);
        String accordionHeader = campaignDetailPage.patentsAccordionHeader.getText();
        withNewWindow(campaignDetailPage.patentsAccordionHeader, () -> {
            at(patentDetailsPage);
            String patentNumberDetailsPage = patentDetailsPage.header_info.getData("patent_number");
            Assert.assertEquals(accordionHeader, patentNumberDetailsPage);
        });
    }

    @Test(priority = 577, groups = {"P2", "patents"}, description = "Verify header in patents table")
    public void verifyPatentsTableHeader() throws Exception {
        campaignDetailPage.loadPatentsWithAccordionExpand();
        String expHeader[] = {"Date Filed", "Case Number", "Case Name", "Status"};
        assertEquals(campaignDetailPage.patentsTable.getHeaderData(), expHeader);
    }

    @Test(priority = 578, groups = {"P2", "patents"}, description = "Verify case number link for patents")
    public void verifyCaseNumberLinkInPatents() throws Exception {
        campaignDetailPage.loadPatentsWithAccordionExpand();
        String caseNumber = campaignDetailPage.patentsTable.getColumnLinkText("Case Number");
        withNewWindow(campaignDetailPage.patentsTable.getColumnLinkElem("Case Number"), () -> {
            at(ptabDetailPage);
            String caseNumberDetailsPage = ptabDetailPage.subtitle.getData("Case_Number");
            Assert.assertEquals(caseNumberDetailsPage, caseNumber);
        });
    }

    @Test(priority = 579, groups = {"P2", "patents"}, description = "Verify case name link for patents")
    public void verifyCaseNameLinkInPatents() throws Exception {
        campaignDetailPage.loadPatentsWithAccordionExpand();
        String caseName = campaignDetailPage.patentsTable.getColumnLinkText("Case Name");
        withNewWindow(campaignDetailPage.patentsTable.getColumnLinkElem("Case Name"), () -> {
            at(ptabDetailPage);
            String caseNumberDetailsPage = ptabDetailPage.title.getText();
            Assert.assertTrue(caseNumberDetailsPage.contains(caseName));
        });
    }

    @Test(priority = 580, groups = {"P4", "patents", "func_sorting"}, description = "Verify default sort for patents")
    public void verifyDefaultSortInPatents() {
        campaignDetailPage.loadPatentsWithAccordionExpand();
        assertColumnSort("date", "desc", campaignDetailPage.patentsTable.getColumn("Date Filed"));
    }

    @Test(priority = 509, groups = {"P3", "petitions"}, description = "Verify petition section without data")
    public void verifyPetitionSectionWithNoData() throws Exception {
        this.urlData.put("ID", data.getCampIdWithAllCases(true));
        to(campaignDetailPage, urlData);
        assertEquals(campaignDetailPage.campaignPetitionsWithoutData.getText(), "No related petitions found");
        campaignDetailPage.loadPetitionerWithAccordionExpand();
        assertEquals(campaignDetailPage.campaignPetitionersWithoutData.getText(), "No related petitioners found");
        campaignDetailPage.loadPatentsWithAccordionExpand();
        assertEquals(campaignDetailPage.campaignPatentsWithoutData.getText(), "No related patents found");

    }

    @DataProvider
    public Object[][] patentsSortData() {
        return new Object[][]{{"Date Filed", "asc", "date"}, {"Case Number", "asc", "string"},
                {"Case Number", "desc", "string"}, {"Case Name", "asc", "non-date"},
                {"Case Name", "desc", "non-date"}, {"Status", "asc", "non-date"},
                {"Status", "desc", "non-date"}};
    }

    // TO DO need to add ITC alone campaigns, input from DB
    // TO DO Enable this test after fixing the issue in getting count
    // @Test(priority=450, description="Verify venue section",
    // dataProvider="venues")
/*
    public void verifyVenuesSection(String id, String itcCases) throws Exception {
        this.urlData.put("ID", id);
        to(campaignDetailPage, urlData);
        int caseCountinVenue = campaignDetailPage.getTotalCasesCountInVenuesMap();
        int casesinCampign = campaignDetailPage.overviewPanel.getIntData("Case Count");
        if (itcCases == "false")
            assertEquals(casesinCampign, caseCountinVenue);
        if (itcCases == "true")
            // TODO get itc case count from data and subtract it from cases. then
            // verify equals
            Assert.assertTrue(casesinCampign > caseCountinVenue);
    }
*/

    @DataProvider
    public Object[][] venues() {
        return new Object[][]{{"35227", "false"}, {"5978", "true"}};
    }

    // TODO input from DB and with no data
    @Test(priority = 201, description = "Verify plaintiff section", groups = "P2")
    public void verifyPlaintiffSection() throws Exception {
        this.urlData.put("ID", "34878");
        to(campaignDetailPage, urlData);
        assertEquals(campaignDetailPage.plaintiffCounselInfo.isPresent(), false);
        campaignDetailPage.plaintiffSectionShowAll.click();
        assertEquals(campaignDetailPage.plaintiffSectionShowAll.getText(), "Hide All Counsel");
        assertEquals(campaignDetailPage.plaintiffCounselInfo.isPresent(), true);
        campaignDetailPage.plaintiffSectionShowAll.click();
        assertEquals(campaignDetailPage.plaintiffCounselInfo.isPresent(), false);
        campaignDetailPage.plaintiffLinksCounselInfo.click();
        assertEquals(campaignDetailPage.plaintiffCounselInfo.isPresent(), true);
    }

    @Test(priority = 202, description = "Verify plaintiff section links", groups = "P2")
    public void verifyPlaintiffLinks() throws Exception {
        this.urlData.put("ID", "34878");
        to(campaignDetailPage, urlData);
        String plaintiff = campaignDetailPage.plaintiffLinks.getText();
        withNewWindow(campaignDetailPage.plaintiffLinks, () -> {
            at(entityDetailPage);
            String entityName = entityDetailPage.detailPageTitle.getText();
            Assert.assertEquals(plaintiff, entityName);
        });
        if (campaignDetailPage.plaintiffLinksSub.isPresent()) {
            String plaintiffsub = campaignDetailPage.plaintiffLinksSub.getText();
            withNewWindow(campaignDetailPage.plaintiffLinksSub, () -> {
                at(entityDetailPage);
                String entityName = entityDetailPage.detailPageTitle.getText();
                Assert.assertEquals(plaintiffsub, entityName);
            });
        }
    }

    //Todo Need to review this script
    @Test(priority = 303, description = "Verify patent tile", groups = {"P2", "patents"})
    public void verifyPatentTitle() throws Exception {
        List<String> campYear = campaignDetailPage.timeLineYear.getAllData();
        campaignDetailPage.patent_table.getColumnLinkElem("Title").click();
        at(patentDetailsPage);
        List<String> patYear = patentDetailsPage.timeLineYear.getAllData();
        assertEquals(campYear, patYear);
    }


    @Test(priority = 101, description = "Verify campaign overview section tabs", groups = {"P2", "defendant_timeline"})
    public void checkCampaignOverviewTab() {
        SoftAssert softAssert = new SoftAssert();
        softAssert.assertEquals(campaignDetailPage.timelineTab.getText(), "Timeline",
                "Defendant timeline is not displayed");
        softAssert.assertEquals(campaignDetailPage.defendantTab.getText(), "Defendants",
                "Defendant view is not displayed");
        softAssert.assertEquals(campaignDetailPage.caseViewTab.getText(), "Cases", "Case View is not displayed");
        softAssert.assertEquals(campaignDetailPage.accusedProductTab.getText(), "Accused Products", "Accused Products is not displayed");
        softAssert.assertEquals(campaignDetailPage.patentGridTab.getText(), "Patent Grid", "Patent Grid is not displayed");
        softAssert.assertAll();
    }

    @Test(priority = 102, description = "Validate campaign overview sorting for hight charts bar", groups = {"P4", "defendant_timeline", "func_sorting"})
    public void verifySortingForHighChartsBar() throws Exception {
        assertColumnSort("non-date", "DESC", campaignDetailPage.getxAxis());
    }

    //Todo Need to review this script-Always Pass
    @Test(priority = 104, description = "Validate defendant text display", groups = {"P2", "defendant_timeline"})
    public void checkDefendantText() {
        String defendant = campaignDetailPage.defendantsInTimelineChart.getText();
        if (campaignDetailPage.defendantsInTimelineChart.getAttribute("title").length() > 20)
            assertTrue(defendant.matches(".*" + "..."), "Defendant name is not truncated");
    }

    @Test(priority = 105, description = "Verify campaign overview section search functionality", groups = {"P2", "defendant_timeline"})
    public void checkDefaultSelectedFilterOption() throws Exception {
        SoftAssert softAssert = new SoftAssert();
        softAssert.assertEquals(campaignDetailPage.defendant_Dropdown.getSelectedOption(), "All");
        softAssert.assertEquals(campaignDetailPage.judgeOrCourt_Dropdown.getSelectedOption(), "All");
        softAssert.assertEquals(campaignDetailPage.defendantStatus_Dropdown.getSelectedOption(), "All");
        softAssert.assertEquals(campaignDetailPage.defendanteEvent_Dropdown.getSelectedOption(), "All");
        softAssert.assertAll();
    }

    @Test(priority = 107, description = "Verify campaign overview section defendant filter functionality", groups = {"P2", "defendant_timeline"})
    public void checkDefendantFilterFunctionality() throws Exception {
        int defendantCountBeforeFilter = campaignDetailPage.overviewCompany.getAllData().size();
        String companyName = campaignDetailPage.overviewCompany.getText();
        campaignDetailPage.applyDefendantFilter(companyName);
        assertEquals(campaignDetailPage.overviewCompany.getText(), companyName);
        int defendentCountAfterFilter = campaignDetailPage.overviewCompany.getAllData().size();
        Assert.assertEquals(defendentCountAfterFilter, 1, "The Defendant displaying in defendant timeline Count is not matching after applied the defendant filter");
        campaignDetailPage.applyDefendantFilter("All");
        int defendentCountClearFilter = campaignDetailPage.overviewCompany.getAllData().size();
        Assert.assertEquals(defendantCountBeforeFilter, defendentCountClearFilter, "The Defendant displaying in defendant timeline Count is not matching after cleared the defendant filter");

    }

    //ACCUSED PRODUCTS TESTS
    @BeforeGroups(groups = "accused_products")
    public void gotoCampaignWithAccusedProducts() {
        urlData.put("ID", "266");
        to(campaignDetailPage, urlData);
    }

    @Test(priority = 601, groups = {"P2", "accused_products"}, description = "Verify accused products table header")
    public void verifyAccusedProductsTableHeader() throws Exception {
        campaignDetailPage.selectAccusedProductsTab();
        String[] expHeader = {"Date Filed", "Defendants", "Accused Products"};
        assertEquals(campaignDetailPage.accusedProductTable.getHeaderData(), expHeader, "Accused Products table header");
    }

    @Test(priority = 602, groups = {"P3", "accused_products"}, description = "Verify view less in accused products table")
    public void verifyViewLessInAssigneesTable() {
        softAssert = new SoftAssert();
        campaignDetailPage.selectAccusedProductsTab();
        campaignDetailPage.accusedProductTable.viewAll();
        int recordsBeforeViewLess = campaignDetailPage.accusedProductTable.displayedRecords().getElements().size();
        campaignDetailPage.accusedProductTable.viewLess();
        int recordsAfterViewLess = campaignDetailPage.accusedProductTable.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsAfterViewLess == 7, "7 records are not displayed after view less");
        softAssert.assertTrue(recordsBeforeViewLess > recordsAfterViewLess, "Records displayed after view less is not less than records before view less");
        softAssert.assertAll();
    }

    @Test(priority = 603, groups = {"P3", "accused_products"}, description = "Verify view all in accused products table")
    public void verifyViewAllInAssigneesTable() {
        softAssert = new SoftAssert();
        campaignDetailPage.selectAccusedProductsTab();
        int recordsBeforeViewAll = campaignDetailPage.accusedProductTable.displayedRecords().getElements().size();
        campaignDetailPage.accusedProductTable.viewAll();
        int recordsAfterViewAll = campaignDetailPage.accusedProductTable.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsBeforeViewAll == 7, "7 records are not displayed before view all");
        softAssert.assertTrue(recordsAfterViewAll > recordsBeforeViewAll, "Records displayed after view all is not greater than records before view all");
        softAssert.assertAll();
    }

    @Test(priority = 604, groups = {"P2", "accused_products"}, description = "Verify defendants link from accused products table")
    public void verifyDefendatLinkInAccusedProducts() throws Exception {
        campaignDetailPage.selectAccusedProductsTab();
        withNewWindow(campaignDetailPage.defendantLinkInAccusedProducts, () -> {
            Assert.assertTrue(getDriver().getCurrentUrl().contains("/entity/"),"Clicking the Defendant link in Accused Products section is not correctly navigated to the Entity page");
            at(entityDetailPage);
                        });
        at(campaignDetailPage);
    }

    @Test(priority = 605, groups = {"P4", "accused_products", "func_sorting"}, description = "Verify default sort in accused products table")
    public void verifyDefaultSortInAccusedProducts() {
        campaignDetailPage.selectAccusedProductsTab();
        assertColumnSort("date", "desc", campaignDetailPage.accusedProductTable.getColumn("Date Filed"));
    }

    @Test(priority = 606, groups = {"P4", "accused_products", "func_sorting"}, dataProvider = "accusedProductsSortData", description = "Verify sorting in accused products table")
    public void verifySortingInAccusedProducts(String columnName, String sortType, String dataType) throws Exception {
        campaignDetailPage.selectAccusedProductsTab();
        campaignDetailPage.accusedProductTable.sort(columnName);
        assertColumnSort(dataType, sortType, campaignDetailPage.accusedProductTable.getColumn(columnName));
    }

    @DataProvider
    public Object[][] accusedProductsSortData() {
        return new Object[][]{{"Date Filed", "asc", "date"}, {"Date Filed", "desc", "date"},
                {"Defendants", "asc", "string"}, {"Defendants", "desc", "string"},
                {"Accused Products", "asc", "string"}, {"Accused Products", "desc", "string"}};
    }

    @Test(priority = 607, groups = {"P3", "accused_products"}, description = "Verify message displayed in campaigns without accused products")
    public void verifyMessageWithoutAccusedProducts() throws Exception {
        this.urlData.put("ID", "595");
        to(campaignDetailPage, urlData);
        campaignDetailPage.selectAccusedProductsTab();
        assertEquals(campaignDetailPage.noAccusedProductsMsg.getText(), "No accused products found", "Message for accused products without records");
    }

    //CAMPAIN TIMELINE VIEW FILTERS
//    @Test(priority = 650, description = "Verify defendant name search in Campaign TimeLine View | RPX-12729")
//    public void checkDefendantOrderAtTimeLineView() throws Exception {
//        this.urlData.put("ID", "1544");
//        to(campaignDetailPage, urlData);
//        campaignDetailPage.selectDefendantTab();
//        List<String> defendantData = campaignDetailPage.defendantParent.getAllData();
//        Collections.reverse(defendantData);
//        campaignDetailPage.selectDefendantTimelineTab();
//        campaignDetailPage.defendantsInTimelineChart.waitUntilVisible();
//        assertEquals(campaignDetailPage.defendantsInTimelineChart.getAllData(), defendantData);
//    }

    @Test(priority = 651, dataProvider = "defendantNames", groups = "P2", description = "Verify defendant name search in Campaign TimeLine View")
    public void checkDefendantSearchAtDefendantTimeLineView(String defendantName) throws Exception {
        this.urlData.put("ID", "58871");
        to(campaignDetailPage, urlData);
        campaignDetailPage.applyDefendantFilter(defendantName);
        campaignDetailPage.defendantsInTimelineChart.waitUntilVisible();
        assertEquals(campaignDetailPage.defendantsInTimelineChart.getText(), defendantName);
    }

    @DataProvider(name = "defendantNames")
    public Object[][] getDefendantNames() {
        return new Object[][]{{"ZTE Corporation"},//Defendant involved in both LIT and ITC
                {"Cisco Systems, Inc."}, //Defendant involved in both LIT,PTAB and CAFC
                {"LG Corporation"},//Defendant involved in both LIT,ITC,PTAB and CAFC
                {"Bandwidth, Inc."}//Defendant involved only in LIT
                //{"HP Hood LLC"} //Defendant involved only in LIT
        };
    }


    @Test(priority = 652, groups = "P3", description = "Counsel|Verify Defendant Popup Case View counsel text for PTAB/ITC/DC cases|RPX-12334")
    public void checkCounselLabelForCases() {
        to(campaignDetailPage, "13972");
        campaignDetailPage.applyDefendantFilter("Comcast Corporation");
        campaignDetailPage.timeLinechartBar.waitUntilVisible();
        campaignDetailPage.timeLinechartBar.click();
        campaignDetailPage.defendant_timeLine_Popup_CaseDetails.waitUntilVisible();
        assertTrue(campaignDetailPage.counsel_LabelForDC.isDisplayed(), "Lead Counsel label is not available for DC Cases in Defendant Pop up");
        assertTrue(campaignDetailPage.counsel_LabelForPTAB.isDisplayed(), "Counsel label is not available for PTAB Cases in Defendant Pop up");
        assertTrue(campaignDetailPage.counsel_LabelForITC.isDisplayed(), "General Counsel label is not available for ITC Cases in Defendant Pop up");
        campaignDetailPage.closeTimelinePopupModal();
    }

    @Test(priority = 653, dataProvider = "judges", groups = "P2", description = "Verify Judge filter in Campaign TimeLine View")
    public void checkJudgeFilterAtTimeLineView(String judge, String expCaseNumbers[]) throws Exception {
        to(campaignDetailPage, "67901-uniloc-usa-inc-6-580-422");
        campaignDetailPage.closeTimelinePopupModal();
        campaignDetailPage.applyJudgeOrCourtFilter(judge);
        campaignDetailPage.timeLinechartBar.waitUntilVisible();
        campaignDetailPage.timeLinechartBar.click();
        campaignDetailPage.defendantTimelineModal.waitUntilVisible();
        for (String caseNumber : expCaseNumbers) {
            assertTrue(campaignDetailPage.getCaseDataOfDefendantTimeLineModal().contains(caseNumber), "Expected Case Number " + caseNumber + " is not available in defendant timeline popup for Judge Filter:" + judge);
        }
        campaignDetailPage.closeTimelinePopupModal();
    }

    @DataProvider(name = "judges")
    public Object[][] getJudges() {
        return new Object[][]{
                //{"David Shaw", new String[]{"INVESTIGATION NUMBER: 337-TA-892", "JUDGE: David Shaw"}},//Judge involved in both ITC
                {"William H. Alsup", new String[]{"CASE NUMBER: 2:17-cv-00455", "JUDGE: William H. Alsup"}} //Judge involved in LIT
        };
    }

    @Test(priority = 654, groups = "P2", dataProvider = "courts", description = "Verify Court filter in Campaign TimeLine View")
    public void checkCourtFilterAtTimeLineView(String court, String expCaseNumbers[]) throws Exception {
        to(campaignDetailPage, "13972");
        campaignDetailPage.closeTimelinePopupModal();
        campaignDetailPage.clearFilters();
        campaignDetailPage.applyDefendantStatusFilter("Active");
        campaignDetailPage.applyJudgeOrCourtFilter(court);
        campaignDetailPage.timeLinechartBar.waitUntilVisible();
        campaignDetailPage.timeLinechartBar.click();
        campaignDetailPage.defendantTimelineModal.waitUntilVisible();
        for (String caseNumber : expCaseNumbers) {
            assertTrue(campaignDetailPage.getCaseDataOfDefendantTimeLineModal().contains(caseNumber), "Expected Case Number " + caseNumber + " is not available in defendant timeline popup for Judge Filter:" + court);
        }


    }

    @DataProvider(name = "courts")
    public Object[][] getCourts() {
        return new Object[][]{
                {"ITC", new String[]{"INVESTIGATION NUMBER: 337-TA-1041"}}, //Court involved in ITC
                {"Texas Eastern", new String[]{"COURT: Eastern District of Texas", "CASE NUMBER: 2:16-cv-01362"}} //Court involved in LIT
        };
    }

    @Test(priority = 655, groups = "P2", dataProvider = "status", description = "Verify defendant Status filter in TimeLine View")
    public void checkDefendantStatusFilterInTimeLine(String status) throws Exception {
        to(campaignDetailPage, "6029" /*"13972"*/);
        campaignDetailPage.closeTimelinePopupModal();
        campaignDetailPage.clearFilters();
        int terminatedDefendants = Integer.valueOf(campaignDetailPage.overviewPanel.getData("Defendants Terminated Count"));
        int totalDefendants = Integer.valueOf(campaignDetailPage.overviewPanel.getData("Defendants Count"));
        int activeDefendants = totalDefendants - terminatedDefendants;
        campaignDetailPage.applyDefendantStatusFilter(status);
        campaignDetailPage.timeLinechartBar.waitUntilVisible();
        int available_Timelines_Count = campaignDetailPage.timeLinechartBar.count();
        verifyStatus(status, totalDefendants, activeDefendants, terminatedDefendants, available_Timelines_Count);
    }

    @DataProvider(name = "status")
    public Object[][] getStatus() {
        return new Object[][]{{"Active"}, {"Inactive"}, {"All"}};
    }

    @Test(priority = 656, groups = "P2", description = "Verify event filter in TimeLine View")
    public void checkEventFilterInTimeLine() throws Exception {
        to(campaignDetailPage, "6029");
        campaignDetailPage.clearFilters();
        campaignDetailPage.applyDefendantFilter("HP Hood LLC");
        campaignDetailPage.applyDefendantEventFilter("Summary Judgment");
        //com.rpxcorp.testcore.Assert.isEquals(campaignDetailPage.defendant_timeline_active_top_marker.getAllData(),new String[]{"SJ", "SJ"});
        //com.rpxcorp.testcore.Assert.isEquals(campaignDetailPage.defendant_timeline_inactive_top_marker.getAllData(),new String[]{"C","C"});
        Assert.assertEquals(campaignDetailPage.defendant_timeline_active_top_marker.getAllData(), Arrays.asList(new String[]{"SJ"}));
        //Assert.assertEquals(campaignDetailPage.defendant_timeline_inactive_top_marker.getAllData(),Arrays.asList(new String[]{"C"}));
        assertEquals(campaignDetailPage.timeLinechartBar.count(), 1);
        Assert.assertEquals(campaignDetailPage.defendantsInTimelineChart.getAllData(), Arrays.asList(new String[]{"HP Hood LLC"}));
    }

    @Test(priority = 657, groups = "P3")
    public void verifyMarkerSelectNUnSelectInTimeLine() throws Exception {
        campaignDetailPage.clearFilters();
        List<String> defaultMarkers = campaignDetailPage.defendant_timeline_active_top_marker.getAllData();
        int defaultBarCount = campaignDetailPage.timeLinechartBar.count();
        ArrayList<String> defaultDefendants = campaignDetailPage.defendants_timeline.getAllData();
        campaignDetailPage.defendant_timeline_top_marker.of("PTAB Institution Decision").click();
        campaignDetailPage.defendant_timeline_top_marker.of("PTAB Institution Decision").scrollAndFocus();
        com.rpxcorp.testcore.Assert.isEquals(campaignDetailPage.defendant_timeline_active_top_marker.getAllData(), new String[]{"PID"});
        com.rpxcorp.testcore.Assert.isEquals(campaignDetailPage.defendant_timeline_inactive_top_marker.getAllData(), new String[]{"C", "PP", "PA", "PT"});
        assertEquals(campaignDetailPage.timeLinechartBar.count(), 1);
        com.rpxcorp.testcore.Assert.isEquals(campaignDetailPage.defendants_timeline.getAllData(), new String[]{"GEA Group AG"});

        campaignDetailPage.defendant_timeline_top_marker.of("PTAB Institution Decision").click();
        assertEquals(campaignDetailPage.defendant_timeline_active_top_marker.getAllData(), defaultMarkers);
        assertEquals(campaignDetailPage.defendant_timeline_inactive_top_marker.count(), 0);
        assertEquals(campaignDetailPage.timeLinechartBar.count(), defaultBarCount);
        assertEquals(campaignDetailPage.defendants_timeline.getAllData(), defaultDefendants);
    }

    @Test(priority = 658, groups = "P3", description = "Verify Defendant timeline Marker tooltip verification")
    public void verifyTopMarkerTooltip() throws Exception {
        campaignDetailPage.clearFilters();
        campaignDetailPage.summaryJudgementMarker.moveTo();
        campaignDetailPage.summaryJudgementTooltip.waitUntilVisible();
        assertEquals(campaignDetailPage.markerToolTipHeader.getText(), "Summary Judgment");
        String toolTipDetail = campaignDetailPage.markerToolTipDetail.getText();
        Assert.assertTrue(toolTipDetail.contains("03/29/2013"), "The tool tip does not contain the correct date");
        Assert.assertTrue(toolTipDetail.contains("1:12-cv-00211"), "The tool tip does not contain the correct case nummber");
        System.out.println(campaignDetailPage.markerToolTipCaseLink.getPartialLink());
        System.out.println(campaignDetailPage.markerToolTipDocumentLink.getPartialLink());
        Assert.assertTrue(campaignDetailPage.markerToolTipCaseLink.getPartialLink().contains("lit/35711"));
        Assert.assertTrue(campaignDetailPage.markerToolTipDocumentLink.getPartialLink().contains("litigation_documents/9977335"));
    }

    @Test(priority = 659, groups = "P2", dataProvider = "complaints_dismissals", description = "Verify Complaints and dismissals event filter on campaign timeline|RPX-12672")
    public void checkComplaint_Dismissals_EventFilterInTimeLine(String eventType, String marker) throws Exception {
        if (eventType.contentEquals("Dismissal")) {
            to(campaignDetailPage, "12186");
        } else {
            to(campaignDetailPage, "9531"); //1544
        }
        campaignDetailPage.clearFilters();
        campaignDetailPage.applyDefendantEventFilter(eventType);
        Set<String> hashsetList = new HashSet<String>(campaignDetailPage.defendant_timeline_active_top_marker.getAllData());
        Set<String> expSet = new HashSet<String>(new ArrayList<String>(Arrays.asList(marker)));
        com.rpxcorp.testcore.Assert.isEquals(hashsetList, expSet);
        checkMarkerToolTipDataForEventType(eventType);
    }

    @Test(priority = 960, groups = "P2", description = "View in Analyst | View in Analyst link has to redirect to analyst search and related patent has to be displayed | RPX-12946")
    @Authenticate(role = "ANALYST")
    public void verifyViewInAnalystLink() throws Exception {
        to(campaignDetailPage, "2621");
        assertEquals(campaignDetailPage.viewInAnalyst.getLink(),
                getConfig("ANALYST_BASE_URL") + "/#/search_results?pgq=campaign_names__fq7%3A7%2522DDB%2520Technologies%2520LLC%2520%25285%252C189%252C630%2529%253A2621%2522");
        withNewWindow(campaignDetailPage.viewInAnalyst, () -> {
            AnalystSearchPage analystSearchPage = at(AnalystSearchPage.class);
            analystSearchPage.pageTitle.waitUntilTextPresent("Search Results");
            System.out.println(analystSearchPage.patentCount.getIntData());
            assertTrue(analystSearchPage.patentCount.getIntData() >= 1, "No patent found in analyst");
            com.rpxcorp.testcore.Assert.isEquals(analystSearchPage.getCurrentUrl(), getConfig("ANALYST_BASE_URL") + "/#/search_results?gcs=grid&pgq=campaign_names__fq7:7%2522DDB%2520Technologies%2520LLC%2520%25285%252C189%252C630%2529%253A2621%2522");
        });
    }

    //--TODO CAFC callout is missing for federal circuit event in campaign detail page. Enable this script once the issue is fixed
/*    @Test(description = "RPX-13203 Federal circuit events not visible in campaign timeline")
    public void verifyFederalCircuitInCampaignEvent(){
        to(campaignDetailPage,"1436");
        assertTrue(campaignDetailPage.federalCircuit.isDisplayed(),"Federal Circuit in the Event drop-down is not displayed");
        assertTrue(campaignDetailPage.federalCircuitOpinion.isDisplayed(),"Federal Circuit Opinion in the Event drop-down is not displayed");
        if(campaignDetailPage.federalCircuit.isDisplayed()){
            campaignDetailPage.federalCircuit.click();
            int cafcLabelNameCount = campaignDetailPage.xAxisLabelName.getAllData().size();
            int cafcCallOutCount = campaignDetailPage.cafcTagCallOut.getAllData().size();
            assertTrue(cafcLabelNameCount==cafcCallOutCount,"CAFC tag is not displayed for all the labels");
        }
    }*/


    private void checkMarkerToolTipDataForEventType(String eventType) throws Exception {
        String eventName, caseKey;
        moveToMarker(eventType);
        campaignDetailPage.markerToolTipHeader.waitUntilVisible();
        eventName = campaignDetailPage.markerToolTipHeader.getText();
        //caseKey=campaignDetailPage.markerToolTipCaseLink.getText();
        //Check event name in tooltip
        Assert.assertEquals(eventName, eventType);
        //Check document load
        withNewWindow(campaignDetailPage.markerToolTipDocumentLink, () -> {
            at(litigationDocumentPage);
        });
        moveToMarker(eventType);
        campaignDetailPage.markerToolTipHeader.waitUntilVisible();
        caseKey = campaignDetailPage.markerToolTipCaseLink.getText();
        //Check detail page redirection
        withNewWindow(campaignDetailPage.markerToolTipCaseLink, () -> {
            if (!eventType.equalsIgnoreCase("ITC Complaint")) {
                at(litigationDetailPage);
                Assert.assertEquals(litigationDetailPage.docketNumberText.getText(), caseKey, "Redirection is not expected for casekey:" + caseKey + " as caseNumber:" + litigationDetailPage.docketNumberText.getText() + " is not expected in detail page");
            } else {
                at(itcDetailPage);
                Assert.assertEquals(itcDetailPage.getCaseNumber(), caseKey, "Redirection is not expected for casekey:" + caseKey + " as caseNumber:" + baseDetailPage.caseNumber.getText() + " is not expected in detail page");
            }
        });
    }

    private void moveToMarker(String eventType) {
        switch (eventType) {
            case "Complaint":
                campaignDetailPage.complaint_marker.moveTo();
                break;
            case "Dismissal":
                campaignDetailPage.dismissal_marker.waitUntilVisible();
                campaignDetailPage.dismissal_marker.moveTo();
                break;
            case "ITC Complaint":
                campaignDetailPage.itcComplaint_marker.moveTo();
                break;
        }
    }

    @DataProvider(name = "complaints_dismissals")
    public Object[][] getComplaints_Dismissals() {
        return new Object[][]{{"Complaint", "C"}, {"Dismissal", "D"}, {"ITC Complaint", "ITC"}};
    }

    private void verifyStatus(String status, int totalDefendants,
                              int activeDefendants, int terminatedDefendants, int available_Timelines_Count) throws Exception {
        switch (status) {
            case "Active":
                assertEquals(campaignDetailPage.timeLinechartBar.getAttribute("fill"), "#8ddf92", //This code denotes green
                        "Active cases are not displayed in green");
                assertEquals(available_Timelines_Count, activeDefendants, "Expected active defendants as per Campaign Overview Metrics:" + activeDefendants + ", Actual available defendants in Timeline when we set defendants status as" + status + " :" + campaignDetailPage.defendantsInTimelineChart.count());
                break;
            case "Inactive":
                assertEquals(campaignDetailPage.timeLinechartBar.getAttribute("fill"), "#76c5ff",  //This code denotes grey
                        "Inactive cases are not displayed in grey");
                assertEquals(available_Timelines_Count, terminatedDefendants, "Expected Inactive defendants as per Campaign Overview Metrics:" + terminatedDefendants + ", Actual available defendants in Timeline when we set defendants status as" + status + " :" + campaignDetailPage.defendantsInTimelineChart.count());
                break;
            case "All":
                assertEquals(available_Timelines_Count, totalDefendants, "Expected all defendants as per Campaign Overview Metrics:" + totalDefendants + ", Actual available defendants in Timeline when we set defendants status as" + status + " :" + campaignDetailPage.defendantsInTimelineChart.count());
                break;
        }

    }
//US Reexamination section started
int defaultDisplayUSReexamRecordCount;

    @BeforeGroups(groups = "campaign_USreexam_section")
    public void load_USReexamination_section() {
        // Entity with more than 10 records in Petition Tab of Petitions section
        urlData.put("ID", "1420-intellectual-ventures-ii-llc-5-500-819");
        to(campaignDetailPage, urlData);
        campaignDetailPage.usreexamination_table.waitUntilVisible();
        defaultDisplayUSReexamRecordCount = 47;//implemented default 7 records to display
    }

    //PETITIONS TAB TEST CASES - START
    @Test(priority = 470, groups = {"P3", "campaign_USreexam_section"}, description = "Verify View All and View Less functionality of reexamination tab in PRB reexamination section")
    public void check_ViewAll_ViewLess_campaign_usreexaminationTab() throws Exception {
        campaignDetailPage.usReexam.select("Reexaminations");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        assertEquals(campaignDetailPage.usreexamination_table.displayedRecords().count(), defaultDisplayUSReexamRecordCount, "Expected Default displayed records:" + defaultDisplayUSReexamRecordCount + " ,Actual Default displayed records" + campaignDetailPage.usreexamination_table.displayedRecords().count());
        campaignDetailPage.usreexamination_table.viewAll();
        assertTrue(campaignDetailPage.usreexamination_table.displayedRecords().count() > defaultDisplayUSReexamRecordCount, "View All is not displayed all records for Petition Tab in Petitions section");
        campaignDetailPage.usreexamination_table.viewLess();
        assertTrue(campaignDetailPage.usreexamination_table.displayedRecords().count() == defaultDisplayUSReexamRecordCount, "View Less is not reset to default displayed records for Petition Tab in Petitions section");
    }

    @Test(priority = 471, groups = {"P4", "campaign_USreexam_section", "func_sorting"}, description = "Verify Reexamination table Decision date default DESC sorting in PRB Reexamination section")
    public void checkTableDefaultSortForuscampaign_reexaminationTab() throws Exception {
        campaignDetailPage.usReexam.select("Reexaminations");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        assertColumnSort("date", "DESC", campaignDetailPage.usreexamination_table.getColumn("Filing Date"));
    }

    @DataProvider(name = "usreexaminationTableColumnsData")
    public Object[][] getusreexaminationTableColumnsData() {
        return new Object[][]{
                {"Filing Date", "date", "ASC"},
                {"Filing Date", "date", "DESC"},
                {"Patent Number", "string", "ASC"},
                {"Patent Number", "string", "DESC"},
                {"Control Number", "string", "ASC"},
                {"Control Number", "string", "DESC"},
                {"Patent Owner", "string", "ASC"},
                {"Patent Owner", "string", "DESC"},
                {"Requester", "string", "ASC"},
                {"Requester", "string", "DESC"},
                {"Issue Date", "string", "ASC"},
                {"Issue Date", "string", "DESC"},
        };
    }

    @Test(priority = 472, dataProvider = "usreexaminationTableColumnsData", groups = {"P4", "campaign_USreexam_section", "func_sorting"}, description = "Verify reexamination table sorting in PRB Reexamination section")
    public void checkTableSortForcampaign_USReexaminationTab(String columnName, String dataType, String sortType) throws Exception {
        campaignDetailPage.usReexam.select("Reexaminations");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        campaignDetailPage.usreexamination_table.viewAll();
        campaignDetailPage.usreexamination_table.sort(columnName);
        assertColumnSort(dataType, sortType, campaignDetailPage.usreexamination_table.getColumn(columnName));
    }

    @Test(priority = 473, dataProvider = "usreexaminationColumn", groups = {"P2", "campaign_USreexam_section"}, description = "Verify Reexaminaion table Decision Number link redirection in PRB Reexaminaion section")
    public void checkDecisionNumberLinkRedirectionForcampaign_usreexaminaionsTab(String columnName) throws Exception {
        String control_number;
        load_USReexamination_section();
        campaignDetailPage.selectTabInusReexaminationSection("Reexamination");
        control_number = campaignDetailPage.usreexamination_table.getColumnLinkElem("Control Number").getText();
        withNewWindow(campaignDetailPage.usreexamination_table.getColumnLinkElem(columnName), () -> {
            at(reexaminationDetailPage);
            Assert.assertTrue(reexaminationDetailPage.reexam_subtitle.getData("controlNumber").contains(control_number));
        });
    }

    @DataProvider(name = "usreexaminationColumn")
    public Object[][] getusreexaminationColumnColumnData() {
        return new Object[][]{
                {"Control Number"},
        };
    }

    //Reexamination TAB TEST CASES - END//
    //Requesters TAB TEST CASES - START
    @Test(priority = 474, groups = {"P2", "campaign_USreexam_section"}, description = "Verify Entity redirection at Requester Tab")
    public void checkEntityRedirectionForuscampaign_RequesterTab() throws Exception {
        String prb_ent_name;
        campaignDetailPage.usReexam.select("Requester");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        campaignDetailPage.usreexamentLinkAtRequesterTab.waitUntilClickable();
        prb_ent_name = campaignDetailPage.usreexamentLinkAtRequesterTab.getText();
        campaignDetailPage.usreexamentLinkAtRequesterTab.click();
        at(entityDetailPage);
        assertEquals(entityDetailPage.detailPageTitle.getText(), prb_ent_name, "Entity Name is not expected at redirected Entity details page");
        entityDetailPage.navigateBack();
    }

    @Test(priority = 475, groups = {"P2", "campaign_USreexam_section"}, description = "Verify Requester Metrics at Parties Tab")
    public void checkRequesterMetricsForcampaign_USRequesterTab() throws Exception {
        int ReexamRequesterMetrics;
        campaignDetailPage.usReexam.select("Requester");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        ReexamRequesterMetrics = campaignDetailPage.usreexamMetricsForRequester.getIntData();
        campaignDetailPage.usreexamrequesterTable.expandSubTable();
        assertEquals(campaignDetailPage.usreexamrequesterTable.subtable().displayedRecords().count(), ReexamRequesterMetrics, "Requester Metrics count is not expected ");
    }

    @Test(priority = 476, groups = {"P4", "campaign_usreexam_section", "func_sorting"}, description = "Verify default sort for sub table at Requester Tab")
    public void checkDefaultSortForuscampaign_RequesterSubTable() {
        campaignDetailPage.usReexam.select("Requester");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        campaignDetailPage.usreexamrequesterTable.expandSubTable();
        campaignDetailPage.usreexamrequesterTable.subtable().waitUntilVisible();
        assertColumnSort("date", "DESC", campaignDetailPage.usreexamrequesterTable.subtable().getColumn("Filing Date"));
    }


    @Test(priority = 477, dataProvider = "usReexamrequesterSubTableColumnData", groups = {"P4", "campaign_USreexam_section", "func_sorting"}, description = "Verify sort for sub table at Requester Tab")
    public void checkSortForcampaign_usreexamRequesterSubTable(String columnName, String dataType, String sortType) throws Exception {
        campaignDetailPage.usReexam.select("Requester");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        campaignDetailPage.usreexamrequesterTable.expandSubTable();
        campaignDetailPage.usreexamrequesterTable.subtable().waitUntilVisible();
        campaignDetailPage.usreexamrequesterTable.subtable().sort(columnName);
        assertColumnSort(dataType, sortType, campaignDetailPage.usreexamrequesterTable.subtable().getColumn(columnName));
    }

    @Test(priority = 478, dataProvider = "usReexamrequesterSubTableColumn", groups = {"P2", "campaign_USreexam_section"}, description = "Verify Decision Number and Case Name at Requester Tab")
    public void check_CaseNumber_CaseName_LinkRedirectionForcampaign_usreexamRequesterSubTable(String columnName) throws Exception {
        String control_number;
        campaignDetailPage.usReexam.select("Requester");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        campaignDetailPage.usreexamrequesterTable.expandSubTable();
        campaignDetailPage.usreexamrequesterTable.subtable().waitUntilVisible();
        campaignDetailPage.loading.waitUntilInvisible();
        control_number = campaignDetailPage.usreexamrequesterTable.subtable().getColumnLinkText("Control Number");
        campaignDetailPage.usreexamrequesterTable.subtable().getColumnLinkElem(columnName).click();
        at(reexaminationDetailPage);
        assertEquals(reexaminationDetailPage.reexam_subtitle.getData("controlNumber"), control_number);
        load_USReexamination_section();
    }

    // Requester TAB IN Reexamination SECTION - COMPLETED

    //PATENTS TAB IN Reexamination SECTION - STARTED
    @Test(priority = 479, groups = {"P2", "campaign_USreexam_section"}, description = "Verify Reexamination Metrics at Patents Tab")
    public void checkUSReexaminationMetricsForcampaign_PatentsTab() throws Exception {
        int USReexaminationPatentMetrics;
        campaignDetailPage.usReexam.select("Patent");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        USReexaminationPatentMetrics = campaignDetailPage.usreexamMetricsForPatent.getIntData();
        campaignDetailPage.usreexamPatentTable.expandSubTable();
        assertEquals(campaignDetailPage.usreexamPatentTable.subtable().displayedRecords().count(), USReexaminationPatentMetrics, "Patent Metrics count is not expected ");
    }

    @Test(priority = 480, groups = {"P2", "campaign_USreexam_section", "func_sorting"}, description = "Verify default sort for sub table at Parties Tab")
    public void checkDefaultSortForcampaign_USReexamPatentsSubTable() {
        campaignDetailPage.usreexamPatentTable.expandSubTable();
        campaignDetailPage.usreexamPatentTable.subtable().waitUntilVisible();
        assertColumnSort("date", "DESC", campaignDetailPage.usreexamPatentTable.subtable().getColumn("Filing Date"));
    }

    @Test(priority = 481, groups = {"P4", "campaign_usreexam_section", "func_sorting"}, dataProvider = "usReexamrequesterSubTableColumnData", description = "Verify sort for sub table at Patents Tab")
    public void checkSortForcampaign_USReexamPatentsSubTable(String columnName, String dataType, String sortType) throws Exception {
        campaignDetailPage.selectTabInusReexaminationSection("Patents");
        campaignDetailPage.usreexamPatentTable.expandSubTable();
        campaignDetailPage.usreexamPatentTable.subtable().waitUntilVisible();
        campaignDetailPage.usreexamPatentTable.subtable().sort(columnName);
        assertColumnSort(dataType, sortType, campaignDetailPage.usreexamPatentTable.subtable().getColumn(columnName));
    }

    @DataProvider(name = "usReexamrequesterSubTableColumnData")
    public Object[][] getUSReexamRequesterSubTableColumnData() {
        return new Object[][]{
                {"Filing Date", "date", "ASC"},
                {"Filing Date", "date", "DESC"},
                {"Control Number", "string", "ASC"},
                {"Control Number", "string", "DESC"},
                {"Case Name", "string", "ASC"},
                {"Case Name", "string", "DESC"}

        };
    }

    @Test(priority = 500, dataProvider = "usreexamPatentSubTableColumn", groups = {"P2", "campaign_USreexam_section"}, description = "Verify Decision Number and Case Name at Patents Tab")
    public void check_CaseNumber_CaseName_LinkRedirectionForcampaign_USReexamPatentsSubTable(String columnName) throws Exception {
        String control_number;
        campaignDetailPage.usReexam.select("Patent");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        campaignDetailPage.usreexamPatentTable.expandSubTable();
        campaignDetailPage.usreexamPatentTable.subtable().waitUntilVisible();
        campaignDetailPage.loading.waitUntilInvisible();
        control_number = campaignDetailPage.usreexamPatentTable.subtable().getColumnLinkText("Control Number");
        withNewWindow(campaignDetailPage.usreexamPatentTable.subtable().getColumnLinkElem(columnName), () -> {
            at(reexaminationDetailPage);
            com.rpxcorp.testcore.Assert.isEquals(reexaminationDetailPage.reexam_subtitle.getData("controlNumber"), control_number);
        });
        load_USReexamination_section();
    }

    @DataProvider(name = "usreexamrequesterSubTableColumn")
    public Object[][] getUSReexamRequesterSubTableColumn() {
        return new Object[][]{{"Control Number"},
                {"Case Name"}};
    }
    @DataProvider(name = "usreexamPatentSubTableColumn")
    public Object[][] getUSReexamPatentSubTableColumn() {
        return new Object[][]{{"Control Number"},
                {"Case Name"}};
    }

    //PRB Reexamination section ended
    //US Reexamination section end

    int defaultDisplayPRBRecordCount;

    // PRB Reexamination section started
    @BeforeGroups(groups = "campaign_reexam_section")
    public void load_Reexamination_section() {
        // Entity with more than 10 records in Petition Tab of Petitions section
        urlData.put("ID", "191");
        to(campaignDetailPage, urlData);
        campaignDetailPage.reexamination_table.waitUntilVisible();
        defaultDisplayPRBRecordCount = 7;//implemented default 7 records to display
    }

    //PETITIONS TAB TEST CASES - START
    @Test(priority = 482, groups = {"P3", "campaign_reexam_section"}, description = "Verify View All and View Less functionality of reexamination tab in PRB reexamination section")
    public void check_ViewAll_ViewLess_campaign_reexaminationTab() throws Exception {
        campaignDetailPage.prbReexam.select("Reexaminations");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        assertEquals(campaignDetailPage.reexamination_table.displayedRecords().count(), defaultDisplayPRBRecordCount, "Expected Default displayed records:" + defaultDisplayPRBRecordCount + " ,Actual Default displayed records" + campaignDetailPage.reexamination_table.displayedRecords().count());
        campaignDetailPage.reexamination_table.viewAll();
        assertTrue(campaignDetailPage.reexamination_table.displayedRecords().count() > defaultDisplayPRBRecordCount, "View All is not displayed all records for Petition Tab in Petitions section");
        campaignDetailPage.reexamination_table.viewLess();
        assertTrue(campaignDetailPage.reexamination_table.displayedRecords().count() == defaultDisplayPRBRecordCount, "View Less is not reset to default displayed records for Petition Tab in Petitions section");
    }

    @Test(priority = 483, groups = {"P4", "campaign_reexam_section", "func_sorting"}, description = "Verify Reexamination table Decision date default DESC sorting in PRB Reexamination section")
    public void checkTableDefaultSortForcampaign_reexaminationTab() throws Exception {
        campaignDetailPage.prbReexam.select("Reexaminations");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        assertColumnSort("date", "DESC", campaignDetailPage.reexamination_table.getColumn("Decision Date"));
    }

    @DataProvider(name = "reexaminationTableColumnsData")
    public Object[][] getreexaminationTableColumnsData() {
        return new Object[][]{
                {"Decision Date", "date", "ASC"},
                {"Decision Date", "date", "DESC"},
                {"Decision Number", "string", "ASC"},
                {"Decision Number", "string", "DESC"},
                {"Patent Number", "string", "ASC"},
                {"Patent Number", "string", "DESC"},
                {"Reexamination Type", "string", "ASC"},
                {"Reexamination Type", "string", "DESC"},
                {"Requester", "string", "ASC"},
                {"Requester", "string", "DESC"},
        };
    }

    @Test(priority = 484, dataProvider = "reexaminationTableColumnsData", groups = {"P4", "campaign_reexam_section", "func_sorting"}, description = "Verify reexamination table sorting in PRB Reexamination section")
    public void checkTableSortForcampaign_ReexaminationTab(String columnName, String dataType, String sortType) throws Exception {
        campaignDetailPage.prbReexam.select("Reexaminations");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        campaignDetailPage.reexamination_table.viewAll();
        campaignDetailPage.reexamination_table.sort(columnName);
        assertColumnSort(dataType, sortType, campaignDetailPage.reexamination_table.getColumn(columnName));
    }

    @Test(priority = 485, dataProvider = "reexaminationColumn", groups = {"P2", "campaign_reexam_section"}, description = "Verify Reexaminaion table Decision Number link redirection in PRB Reexaminaion section")
    public void checkDecisionNumberLinkRedirectionForcampaign_reexaminaionsTab(String columnName) throws Exception {
        String decision_number;
        load_Reexamination_section();
        campaignDetailPage.selectTabInPRBReexaminationSection("Reexaminations");
        decision_number = campaignDetailPage.reexamination_table.getColumnLinkElem("Decision Number").getText();
        withNewWindow(campaignDetailPage.reexamination_table.getColumnLinkElem(columnName), () -> {
            at(chinesePRBDetailPage);
            Assert.assertTrue(chinesePRBDetailPage.subheading.getData("Decision_Number").contains(decision_number));
        });
    }

    @DataProvider(name = "reexaminationColumn")
    public Object[][] getreexaminationColumnColumnData() {
        return new Object[][]{
                {"Decision Number"},
        };
    }

    //Reexamination TAB TEST CASES - END//
    //Requesters TAB TEST CASES - START
    @Test(priority = 486, groups = {"P2", "campaign_reexam_section"}, description = "Verify Entity redirection at Requester Tab")
    public void checkEntityRedirectionForcampaign_RequesterTab() throws Exception {
        String prb_ent_name;
        campaignDetailPage.prbReexam.select("Requesters");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        campaignDetailPage.entLinkAtRequesterTab.waitUntilClickable();
        prb_ent_name = campaignDetailPage.entLinkAtRequesterTab.getText();
        campaignDetailPage.entLinkAtRequesterTab.click();
        at(entityDetailPage);
        assertEquals(entityDetailPage.detailPageTitle.getText(), prb_ent_name, "Entity Name is not expected at redirected Entity details page");
        entityDetailPage.navigateBack();
    }

    @Test(priority = 487, groups = {"P2", "campaign_reexam_section"}, description = "Verify Requester Metrics at Parties Tab")
    public void checkRequesterMetricsForcampaign_RequesterTab() throws Exception {
        int RequesterMetrics;
        campaignDetailPage.prbReexam.select("Requester");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        RequesterMetrics = campaignDetailPage.ReexaminationMetricsForRequester.getIntData();
        campaignDetailPage.requesterNPatentTable.expandSubTable();
        assertEquals(campaignDetailPage.requesterNPatentTable.subtable().displayedRecords().count(), RequesterMetrics, "Requester Metrics count is not expected for Entity:" + campaignDetailPage.entLinkAtRequesterTab.getText());
    }

    @Test(priority = 488, groups = {"P4", "campaign_reexam_section", "func_sorting"}, description = "Verify default sort for sub table at Requester Tab")
    public void checkDefaultSortForcampaign_RequesterSubTable() {
        campaignDetailPage.prbReexam.select("Requester");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        campaignDetailPage.requesterTable.expandSubTable();
        campaignDetailPage.requesterTable.subtable().waitUntilVisible();
        assertColumnSort("date", "DESC", campaignDetailPage.requesterTable.subtable().getColumn("Decision Date"));
    }


    @Test(priority = 489, dataProvider = "requesterSubTableColumnData", groups = {"P4", "campaign_reexam_section", "func_sorting"}, description = "Verify sort for sub table at Requester Tab")
    public void checkSortForcampaign_RequesterSubTable(String columnName, String dataType, String sortType) throws Exception {
        campaignDetailPage.prbReexam.select("Requester");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        campaignDetailPage.requesterTable.expandSubTable();
        campaignDetailPage.requesterTable.subtable().waitUntilVisible();
        campaignDetailPage.requesterTable.subtable().sort(columnName);
        assertColumnSort(dataType, sortType, campaignDetailPage.requesterTable.subtable().getColumn(columnName));
    }

    @Test(priority = 490, dataProvider = "requesterSubTableColumn", groups = {"P2", "campaign_reexam_section"}, description = "Verify Decision Number and Case Name at Requester Tab")
    public void check_CaseNumber_CaseName_LinkRedirectionForcampaign_RequesterSubTable(String columnName) throws Exception {
        String decision_number;
        campaignDetailPage.prbReexam.select("Requester");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        campaignDetailPage.requesterTable.expandSubTable();
        campaignDetailPage.requesterTable.subtable().waitUntilVisible();
        campaignDetailPage.loading.waitUntilInvisible();
        decision_number = "Decision: " + campaignDetailPage.requesterTable.subtable().getColumnLinkText("Decision Number");
        campaignDetailPage.requesterTable.subtable().getColumnLinkElem(columnName).click();
        at(chinesePRBDetailPage);
        assertEquals(chinesePRBDetailPage.subheading.getData("Decision_Number"), decision_number);
        load_Reexamination_section();
    }

    // Requester TAB IN Reexamination SECTION - COMPLETED

    //PATENTS TAB IN Reexamination SECTION - STARTED
    @Test(priority = 491, groups = {"P2", "campaign_reexam_section"}, description = "Verify Reexamination Metrics at Patents Tab")
    public void checkReexaminationMetricsForcampaign_PatentsTab() throws Exception {
        int ReexaminationMetrics;
        load_Reexamination_section();
        campaignDetailPage.prbReexam.select("Patents");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        campaignDetailPage.reexaminationMetricsForRequester.waitUntilVisible();
        ReexaminationMetrics = campaignDetailPage.reexaminationMetricsForRequester.getIntData();
        campaignDetailPage.requesterNPatentTable.expandSubTable();
        assertEquals(campaignDetailPage.requesterNPatentTable.subtable().displayedRecords().count(), ReexaminationMetrics, "Reexamination Metrics count is not expected for Patent:" + campaignDetailPage.PRBpatListAtPatentTab.getText());
    }

    @Test(priority = 492, groups = {"P4", "campaign_reexam_section", "func_sorting"}, description = "Verify default sort for sub table at Parties Tab")
    public void checkDefaultSortForcampaign_PRBPatentsSubTable() {
        campaignDetailPage.requesterNPatentTable.expandSubTable();
        campaignDetailPage.requesterNPatentTable.subtable().waitUntilVisible();
        assertColumnSort("date", "DESC", campaignDetailPage.requesterNPatentTable.subtable().getColumn("Decision Date"));
    }

    @Test(priority = 493, groups = {"P4", "campaign_reexam_section", "func_sorting"}, dataProvider = "requesterSubTableColumnData", description = "Verify sort for sub table at Patents Tab")
    public void checkSortForcampaign_PRBPatentsSubTable(String columnName, String dataType, String sortType) throws Exception {
        campaignDetailPage.selectTabInPRBReexaminationSection("Patents");
        campaignDetailPage.requesterNPatentTable.expandSubTable();
        campaignDetailPage.requesterNPatentTable.subtable().waitUntilVisible();
        campaignDetailPage.requesterNPatentTable.subtable().sort(columnName);
        assertColumnSort(dataType, sortType, campaignDetailPage.requesterNPatentTable.subtable().getColumn(columnName));
    }

    @DataProvider(name = "requesterSubTableColumnData")
    public Object[][] getRequesterSubTableColumnData() {
        return new Object[][]{
                {"Decision Date", "date", "ASC"},
                {"Decision Date", "date", "DESC"},
                {"Decision Number", "string", "ASC"},
                {"Decision Number", "string", "DESC"},
                {"Case Name", "string", "ASC"},
                {"Case Name", "string", "DESC"},
                {"Reexamination Type", "string", "ASC"},
                {"Reexamination Type", "string", "DESC"}
        };
    }

    @Test(priority = 494, dataProvider = "requesterSubTableColumn", groups = {"P2", "campaign_reexam_section"}, description = "Verify Decision Number and Case Name at Patents Tab")
    public void check_CaseNumber_CaseName_LinkRedirectionForcampaign_PRBPatentsSubTable(String columnName) throws Exception {
        String decision_number;
        campaignDetailPage.prbReexam.select("Patents");
        campaignDetailPage.overlay_Loading.waitUntilInvisible();
        campaignDetailPage.requesterNPatentTable.expandSubTable();
        campaignDetailPage.requesterNPatentTable.subtable().waitUntilVisible();
        campaignDetailPage.loading.waitUntilInvisible();
        decision_number = "Decision: " + campaignDetailPage.requesterNPatentTable.subtable().getColumnLinkElem("Decision Number").getText();
        campaignDetailPage.requesterNPatentTable.subtable().getColumnLinkElem(columnName).click();
        at(chinesePRBDetailPage);
        assertEquals(chinesePRBDetailPage.subheading.getData("Decision_Number"), decision_number);
        load_Reexamination_section();
    }

    @DataProvider(name = "requesterSubTableColumn")
    public Object[][] getRequesterSubTableColumn() {
        return new Object[][]{{"Decision Number"},
                {"Case Name"}};
    }


    //PRB Reexamination section ended
}
