package com.rpxcorp.insight.page.my_portal;

import org.openqa.selenium.JavascriptExecutor;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class ClientListPage extends BasePage {

    public ClientListPage() {
        this.url = new PageUrl("clients");
    }

    @Override
    public boolean at() {
        assertPageTitle("RPX Client List");
        return client_list.waitUntilVisible();
    }

    public final Element client_list = $("ul.client-list.small-block-grid-3>li");
    public final Element clients_under_marketsector_type=$(".client-list.categorized li");
    public final Element expand_link=$("div.group.collapsed div.handle");
    
    public void expandAllMarketSectorAccord() {
    	if(expand_link.isDisplayed()) {
    		JavascriptExecutor js = (JavascriptExecutor) getDriver();
            js.executeScript("$(\"div.group.collapsed div.handle\").click();");
    		loading.waitUntilInvisible();
    	}
    }

}
