package com.rpxcorp.insight.test.data;

import java.sql.ResultSet;
import java.sql.SQLException;
import com.rpxcorp.insight.page.HomePage;
import com.rpxcorp.insight.test.data.BaseDataTest;
import com.rpxcorp.testcore.Authenticate;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.rpxcorp.testcore.util.SQLProcessor;

@Authenticate(role = "MEMBER")
public class DashboardTest extends BaseDataTest{	

	HomePage homePage;
	SQLProcessor sqlProcessor = SQLProcessor.getInstance();

	@BeforeClass
	public void loadPageWait() {
		at(homePage);
	} 		

	@Test(description = "Verify new campaigns filed for a year") 
	public void newCampaignsFiled() throws SQLException, Exception {	
		ResultSet result = sqlProcessor.getResultData("Dashboard.NEW_CAMPAIGNS_FILED");
		assertEquals(homePage.newCampaignsFiled.getChartData("filedYear"), 
				sqlProcessor.getResultDataAsMultiMap(result, "year", "npe", "operating", "total"));
	}

	@Test(description = "Verify new ptab petitions filed for a year") 
	public void newPtabPetitionsFiled() throws SQLException, Exception {		
		ResultSet result = sqlProcessor.getResultData("Dashboard.PTAB_PETITIONS_FILED");
		assertEquals(homePage.newPtabPetitionsFiled.getChartData("filedYear"), 
				sqlProcessor.getResultDataAsMultiMap(result, "year", "npe", "operating", "total"));
	}

	@Test(description = "Verify unique defendants in campaigns for a year") 
	public void uniqueDefendantsInCampaigns() throws SQLException, Exception {	
		ResultSet result = sqlProcessor.getResultData("Dashboard.UNIQUE_DEFENDANTS_IN_CAMPAIGNS");
		assertEquals(homePage.uniqueDefendantsInCampaigns.getChartData("filedYear"), 
				sqlProcessor.getResultDataAsMultiMap(result, "year", "npe", "operating", "total"));
	}

	@Test(description = "Verify defendants added in campaigns for a year") 
	public void defendantsAddedInCampaigns() throws SQLException, Exception {	
		ResultSet result = sqlProcessor.getResultData("Dashboard.DEFENDANTS_ADDED_IN_CAMPAIGNS");
		assertEquals(homePage.defendantsAddedInCampaigns.getChartData("filedYear"), 
				sqlProcessor.getResultDataAsMultiMap(result, "year", "npe", "operating", "total"));
	}

	@Test(description = "Verify defendants added in campaigns for a year") 
	public void newCasesFiledDonutChart() throws SQLException, Exception {				
		assertEquals(homePage.newCasesFiledDonutChart.getDataLabels(), 
				sqlProcessor.getResultData("Dashboard.NEW_CASES_FILED_IN_DONUT_CHART"));		
	}

	@Test(description = "Verify RPX reports added for past one week") 
	public void rpxReportsFromPastOneWeek() throws SQLException, Exception {
		assertEquals(homePage.priorArtAndLcaReports.getData(), 
				sqlProcessor.getResultData("Dashboard.RPX_REPORTS_FROM_PAST_ONE_WEEK"));		
	}

	@Test(description = "Verify news articles added for past one week") 
	public void newsArticlesFromPastOneWeek() throws SQLException, Exception {
		assertEquals(homePage.newsArticlesForPastOneWeek.getData(), 
				sqlProcessor.getResultData("Dashboard.NEWS_ARTICLES_FROM_PAST_ONE_WEEK"));		
	}

	@Test(description = "Verify recent acquisitions by RPX for past one month")
	public void recentAcquisitionsFromPastOneMonth() throws SQLException, Exception {
		assertEquals(homePage.recentAcquisitionsForPastOneMonth.getData(),
				sqlProcessor.getResultData("Dashboard.RECENT_ACQUISITIONS_FROM_PAST_ONE_MONTH"));
	}
}