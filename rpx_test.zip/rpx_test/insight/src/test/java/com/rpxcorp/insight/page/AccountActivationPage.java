package com.rpxcorp.insight.page;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class AccountActivationPage extends BasePage {

    @Override
    public boolean at() {
        return activationPanel.waitUntilVisible();
    }

    public AccountActivationPage() {
        this.url = new PageUrl("activate/{ID}");
    }

    public final Element activationPanel = $("#activation");
    public final Element errors = $("#activation .errors");
    public final Element password = $("#password");
    public final Element confirmPassword = $("#password_confirmation");
    public final Element setPasswordBtn = $("input[value='Set Password']");

    public void setPassword(String accountPassword) {
        password.waitUntilVisible();
        password.sendKeys(accountPassword);
        confirmPassword.sendKeys(accountPassword);
        setPasswordBtn.click();
    }
}
