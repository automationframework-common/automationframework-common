package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class RelevantEventsSearchPage extends BasePage {

    public RelevantEventsSearchPage() {
        this.url = new PageUrl("admin/relevant_events/search") {
            {
                param("USER_EMAIL", "email");
                param("MAIL_SENT_DATE", "send_date");
                param("MAIL_DELIVERY_FREQUENCY", "delivery_frequency");
            }
        };
    }

    @Override
    public boolean at() {
        return email_content.waitUntilVisible();
    }

    /* CONTENT OF ENTITY DETAIL PAGE * */
    public final Element email_content = $("body table[width='600']>tbody>tr");

}
