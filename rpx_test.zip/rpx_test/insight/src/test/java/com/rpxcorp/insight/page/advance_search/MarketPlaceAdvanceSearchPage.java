package com.rpxcorp.insight.page.advance_search;

import java.util.Map;

import com.rpxcorp.insight.module.AutoComplete;
import com.rpxcorp.insight.module.CheckList;
import com.rpxcorp.insight.module.DatePicker;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import org.openqa.selenium.JavascriptExecutor;

public class MarketPlaceAdvanceSearchPage extends AdvanceSearchPage {

    public MarketPlaceAdvanceSearchPage() {
        this.url = new PageUrl("advanced_search#marketplaceTab");
    }

    //locators added for MarketPlaceAdvanceSearchPage are available in the AdvanceSearchPage.
    public final Element submitButton = $(".active input[name='commit']");

    @Override
    public boolean at() {
        return abstractTextBox.waitUntilVisible();
    }

    /**
     * Search for data in Market Place Section
     * 
     * @param data
     */
    public void search(Map<String, String> data) {
        portfolioName.sendKeys(data.get("Portfolio Name"));
        seller.sendKeys(data.get("Seller"));
        abstractTextBox.sendKeys(data.get("Abstract TextBox"));
        claims.sendKeys(data.get("Claims"));
        patentNumber.sendKeys(data.get("Patent Number"));
        inventorName.sendKeys(data.get("Inventor Name"));
        legalStatus.sendKeys(data.get("Legal Status"));
        applicationNumber.sendKeys(data.get("Application Number"));
        currentAssignee.sendKeys(data.get("Current Assignee"));
        allAssignee.sendKeys(data.get("All Assignee"));
        originalAssignee.sendKeys(data.get("Original Assignee"));
        JavascriptExecutor js = (JavascriptExecutor) getDriver();
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        submitButton.click();
    }


}

