	package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.detail.PtabDetailPage;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.TableData;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.sql.ResultSet;
import java.util.Map;
@Authenticate(role = "MEMBER")
@Test(groups = {"Lits","PTAB"})
public class PtabDetailsTest extends BaseDataTest {
    PtabDetailPage ptabDetailPage;
    TableData tableData;
    Map<String, String> staticData;
    ResultSet resultSet;

    @Factory(dataProvider = "returnData")
    public PtabDetailsTest(String dataDescription, String ptabId) throws Exception {
        dataId = getPageId(ptabId);
        this.dataDescription = dataDescription;
    }

    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("PtabDetail");
    }

    @BeforeClass
    public void loadPage() {   		
        urlData.put("ID", dataId);
        this.dataUrl = ptabDetailPage.getDeclaredUrl(urlData);
        to(ptabDetailPage, urlData);
    }
   @Test(description = "Verify Challenged Patent Table")
    public void Challenged_Patent_Table() throws Exception {
        assertEquals(ptabDetailPage.challenge_table.getData(),
                sqlProcessor.getResultData("PtabDetail.CHALLENGED_PATENT_TABLE", dataId));
    }

    @Test(description = "Verify Petitioner")
    public void Petitioner() throws Exception {     	
        assertEquals(ptabDetailPage.petitioner_panel.getAllData(),
                sqlProcessor.getResultData("PtabDetail.PETITIONER", dataId));
    }

    @Test(description = "Verify Patent Owner")
    public void Patent_Owner() throws Exception {
        assertEquals(ptabDetailPage.patent_owner.getAllData(),
                sqlProcessor.getResultData("PtabDetail.PATENT_OWNER", dataId));
    }
    
    @Test(description = "Verify Real Party In Interest")
    public void realPartyInInterest() throws Exception {
    	if(ptabDetailPage.realPartyInInterests.isDisplayed()){
    		ptabDetailPage.realPartyInInterests.viewAll();
    		assertEquals(ptabDetailPage.realPartyInInterests.getData(),
    				sqlProcessor.getResultData("PtabDetail.REAL_PARTY_IN_INTEREST", dataId));
    	}
    }

    @Test(description = "Verify Privy")
    public void privy() throws Exception {
    	if(ptabDetailPage.privy.isDisplayed()){
    		assertEquals(ptabDetailPage.privy.getData(),
    				sqlProcessor.getResultData("PtabDetail.PRIVY", dataId));
    	}
    }
    
    @Test(description = "Verify Title")
    public void Title() throws Exception {
        assertEquals(ptabDetailPage.title.getData(), sqlProcessor.getResultData("PtabDetail.TITLE", dataId),
                "title");
    }
    
    @Test(description = "Verify Latest Docket Entry", priority = 1)
    public void Latest_Docket_Entry() throws Exception {
        staticData = ptabDetailPage.subtitle.getData();
        resultSet = sqlProcessor.getResultData("PtabDetail.HEADER_DETAILS", dataId);
        assertEquals(staticData.get("Last_Docket_Entry"),
                sqlProcessor.getResultData("PtabDetail.LATEST_DOCKET_ENTRY_DATE", dataId), "Latest_Docket_Entry");
    }

    @Test(description = "Verify Case Number", priority = 2)
    public void Case_Number() throws Exception {
        assertEquals(staticData.get("Case_Number"), resultSet, "Case_Number");
    }

    @Test(description = "Verify Date Filed", priority = 3)
    public void Date_Filed() throws Exception {
        assertEquals(staticData.get("Date_Filed"), resultSet, "Date_Filed");
    }

    @Test(description = "Verify Institution Decision Date", priority = 3)
    public void Institution_Decision_Date() throws Exception {
        assertEquals(ptabDetailPage.subtitle.getData("Institution_Decision_Date"),
    	        sqlProcessor.getResultData("PtabDetail.HEADER_DETAILS", dataId), "Institution_Decision_Date");        		
    }

    @Test(description = "Verify Final Decision Date", priority = 3)
    public void finalDecisionDate() throws Exception {
        assertEquals(ptabDetailPage.subtitle.getData("Final_Decision_Date"),  
        		sqlProcessor.getResultData("PtabDetail.PTAB_DECISION_DATES_AND_OUTCOMES", dataId), "final_decision_date");
    }
    
    @Test(description = "Verify Termination Date", priority = 3)
    public void terminationDate() throws Exception {
        assertEquals(ptabDetailPage.subtitle.getData("Termination_Date"),
        		sqlProcessor.getResultData("PtabDetail.PTAB_DECISION_DATES_AND_OUTCOMES", dataId), "termination_date");
    }
    
    @Test(description = "Verify Case Status and Notice Of Appeal", priority = 3)
    public void StatusAndNoticeOfAppeal() throws Exception {
        staticData = ptabDetailPage.case_Detail.getData();
        assertEquals(staticData.get("Status"), resultSet, "Status");
        assertEquals(staticData.get("fedcircuit_appeal"), sqlProcessor.getResultData("PtabDetail.NOTICE_OF_APPEAL",dataId),"fedcircuit_appeal");
    }

    @Test(description = "Verify Case Type", priority = 4)
    public void Case_Type() throws Exception {
        assertEquals(staticData.get("Case_Type"), sqlProcessor.getResultData("PtabDetail.PTAB_CASE_TYPE", dataId),
                "case_type");
    }

    @Test(description = "Verify Tech Center", priority = 4)
    public void Tech_Center() throws Exception {
        assertEquals(ptabDetailPage.case_Detail.getData("Tech_Center"),
                sqlProcessor.getResultData("PtabDetail.TECH_CENTER_DATA", dataId), "Tech_Center");
    }

    @Test(description = "Verify Cause Of Action", priority = 4)
    public void causeOfAction() throws Exception {
        assertEquals(ptabDetailPage.case_Detail.getData("Cause_of_Action"),
                sqlProcessor.getResultData("PtabDetail.HEADER_DETAILS", dataId), "Cause_of_action");
    }

    @Test(description = "Verify Administrative Patent Judges", priority = 4)
    public void administrativePatentJudges() throws Exception{
      	assertEquals(ptabDetailPage.case_Detail.getData("Administrative_Patent_Judges"), 
    			sqlProcessor.getResultData("PtabDetail.PTAB_JUDGE_EXPERT_INFO", dataId), "administrative_patent_judges");
    }
    
    @Test(description = "Verify Experts", priority = 4)
    public void experts() throws Exception{
    	assertEquals(ptabDetailPage.case_Detail.getData("Expert"), 
    			sqlProcessor.getResultData("PtabDetail.PTAB_JUDGE_EXPERT_INFO", dataId), "expert");    	
    }
    
    @Test(description = "Verify Institution Decision Outcome", priority = 4)
    public void institutionDecisionOutcome() throws Exception {
        assertEquals(ptabDetailPage.case_Detail.getData("Institution_Decision"),
        		sqlProcessor.getResultData("PtabDetail.PTAB_DECISION_DATES_AND_OUTCOMES", dataId), "institution_decision_outcome");
    }
    
    @Test(description = "Verify Final Decision Outcome", priority = 4)
    public void finalDecisionOutcome() throws Exception {
        assertEquals(ptabDetailPage.case_Detail.getData("Final_Decision"),
        		sqlProcessor.getResultData("PtabDetail.PTAB_DECISION_DATES_AND_OUTCOMES", dataId), "final_decision_outcome");
    }

    @Test(description = "Verify Peitions Table",dataProvider = "related_petitions",priority = 5)
    public void RelatedPetitions_PetitionsTab(String dbQuery,String filterName) throws Exception {
        ptabDetailPage.select_related_petition_filter(filterName);
        tableData = ptabDetailPage.petition_table.getData();
        resultSet = sqlProcessor.getResultData(dbQuery, dataId);
        assertEquals(tableData, resultSet);
    }

    @DataProvider(name="related_petitions")
    public Object[][] getData(){
        return new Object[][]{{"PtabDetail.CAMP_RELATED_PETITIONS_PATENT_FAMILY","camp_pat_family"},{"PtabDetail.RELATED_PETITIONS_PATENT_OWNER","patent_owner"}};
    }

    @Test(description = "Verify Petitioner Name and count in Petitioners Section", priority = 7,dataProvider = "related_petitioner")
    public void Petitioners_Name(String query,String filter) throws Exception {
        ptabDetailPage.select_related_petition_filter(filter);
        ptabDetailPage.selectPetitionersTabLink();
        tableData = ptabDetailPage.partiesNPatentTable.getData();
        resultSet = sqlProcessor.getResultData(query, dataId);
        assertEquals(tableData, resultSet, "name");
        assertEquals(tableData, resultSet, "count");
    }

    @DataProvider(name="related_petitioner")
    public Object[][] getPetitionerData(){
        return new Object[][]{{"PtabDetail.CAMP_RELATED_PETITIONERS_INFO_PATENT_FAMILY","camp_pat_family"},{"PtabDetail.RELATED_PETITIONERS_INFO_PATENT_OWNER","patent_owner"}};
    }


    @Test(description = "Verify Data in Petitioners Sub Table ", priority = 9,dataProvider = "related_petitioners_cases")
    public void Petitioners_SubTable_DateFiled(String query,String filter) throws Exception {
        ptabDetailPage.select_related_petition_filter(filter);
        ptabDetailPage.selectPetitionersTabLink();
        tableData = ptabDetailPage.partiesNPatentTable.getSubtableData();
        resultSet = sqlProcessor.getResultData(query, dataId);
        assertEquals(tableData, resultSet);
        //RELATED_PETITIONERS_SUBTABLE
    }

    @DataProvider(name="related_petitioners_cases")
    public Object[][] getPetitioners_Cases_Data(){
        return new Object[][]{{"PtabDetail.CAMP_RELATED_PETITIONERS_SUBTABLE_PATENT_FAMILY","camp_pat_family"},{"PtabDetail.RELATED_PETITIONERS_SUBTABLE_PATENT_OWNER","patent_owner"}};
    }
    @Test(description = "Verify Petition Count in Patents Section", priority = 11,dataProvider = "related_patent_cases_cnt")
    public void Patents_PetitionCount(String query,String filter) throws Exception {
        ptabDetailPage.select_related_petition_filter(filter);
        ptabDetailPage.selectPatentsTabLink();
        assertEquals(ptabDetailPage.partiesNPatentTable.getData(),
                sqlProcessor.getResultData(query, dataId), "count");
    }

    @DataProvider(name="related_patent_cases_cnt")
    public Object[][] getPatent_Cases_Count(){
        return new Object[][]{{"PtabDetail.CAMP_RELATED_PATENT_CASES_CNT_PATENT_FAMILY","camp_pat_family"},{"PtabDetail.CAMP_RELATED_PATENT_CASES_CNT_PATENT_OWNER","patent_owner"}};
    }

    @Test(description = "Verify Data in Patents Sub Table ", priority = 12,dataProvider = "related_patent_cases")
    public void Patents_SubTable_DateFiled(String query,String filter) throws Exception {
        ptabDetailPage.select_related_petition_filter(filter);
        ptabDetailPage.selectPatentsTabLink();
        tableData = ptabDetailPage.partiesNPatentTable.getSubtableData();
        resultSet = sqlProcessor.getResultData(query, dataId);
        assertEquals(tableData, resultSet);
    }

    @DataProvider(name="related_patent_cases")
    public Object[][] getPatent_Cases(){
        return new Object[][]{{"PtabDetail.RELATED_PATENTS_SUBTABLE_PATENT_FAMILY","camp_pat_family"},{"PtabDetail.RELATED_PATENTS_SUBTABLE_PATENT_OWNER","patent_owner"}};
    }

    @Test(description = "Verify Docket_Entries", priority = 14)
    public void Docket_Entries() throws Exception {
        assertEquals(ptabDetailPage.docket_table.getData(),
                sqlProcessor.getResultData("PtabDetail.DOCKET_ENTRIES", dataId));
    }

    @Test(description = "Verify All Litigations in Campaign View", priority = 15)
    public void All_Litigations_in_Campaign_View() throws Exception {
        assertEquals(ptabDetailPage.Litigation_Campaigns.getData(),
                sqlProcessor.getResultData("PtabDetail.ALL_LITIGATION_CAMPAIGN", dataId), "campaign_name", "start_date",
                "most_recent_case", "termination_date", "case_type");
    }

    @Test(description = "Verify Active Litigations in Campaign View", priority = 16)
    public void Active_Litigations_in_Campaign_View() throws Exception {
        ptabDetailPage.filterActiveCases();
        assertEquals(ptabDetailPage.Litigation_Campaigns.getData(),
                sqlProcessor.getResultData("PtabDetail.ACTIVE_LITIGATION_CAMPAIGN", dataId), "campaign_name",
                "start_date", "most_recent_case", "termination_date", "case_type");
    }

    @Test(description = "Verify InActive Litigations in Campaign View", priority = 17)
    public void InActive_Litigations_in_Campaign_View() throws Exception {
        ptabDetailPage.filterInActiveCases();
        assertEquals(ptabDetailPage.Litigation_Campaigns.getData(),
                sqlProcessor.getResultData("PtabDetail.INACTIVE_LITIGATION_CAMPAIGN", dataId), "campaign_name",
                "start_date", "most_recent_case", "termination_date", "case_type");
    }

    @Test(description = "Verify All Litigations in non campaign view", priority = 18)
    public void All_Litigations_in_non_campaign_view() throws Exception {
        ptabDetailPage.switchToNonCampaignView();
        assertEquals(ptabDetailPage.Litigation_Cases.getData(),
                sqlProcessor.getResultData("PtabDetail.ALL_LITIGATION_NON_CAMP", dataId), "date_filed", "case_name",
                "docket_number", "termination_date");
    }

    @Test(description = "Verify Active Litigations in non campaign view", priority = 19)
    public void Active_Litigations_in_non_campaign_view() throws Exception {
        ptabDetailPage.filterActiveCases();
        assertEquals(ptabDetailPage.Litigation_Cases.getData(),
                sqlProcessor.getResultData("PtabDetail.ACTIVE_LITIGATION_NON_CAMP", dataId), "date_filed", "case_name",
                "docket_number", "termination_date");
    }

    @Test(description = "Verify InActive Litigations in non campaign view", priority = 20)
    public void InActive_Litigations_in_non_campaign_view() throws Exception {
        ptabDetailPage.filterInActiveCases();
        assertEquals(ptabDetailPage.Litigation_Cases.getData(),
                sqlProcessor.getResultData("PtabDetail.INACTIVE_LITIGATION_NON_CAMP", dataId), "date_filed",
                "case_name", "docket_number", "termination_date");
    }

    @Test(description = "Verify defendant parents", priority = 15)
    public void defendant_parents() throws Exception {
        resultSet = sqlProcessor.getResultData("PtabDetail.DEFEDANT_PARENTS", dataId);
        assertEquals(ptabDetailPage.defendant_parent.getIntData(), sqlProcessor.getResultCount(resultSet));
    }
    
    @Test(description = "Petitioner|Verify petitioner count", priority = 1)
    public void petitionerCount() throws Exception {
    	assertEquals(ptabDetailPage.petitionerCount.getIntData(), 
    			sqlProcessor.getResultCount("PtabDetail.PETITIONER_COUNSEL_INFO", dataId));
    }
    
    @Test(description = "Petitioner|Verify petitioner counsel information", priority = 1)
    public void petitionerCounselInformation() throws Exception {    	
    	 assertEquals(ptabDetailPage.petitionerParties.getData(), 
    			 sqlProcessor.getResultData("PtabDetail.PETITIONER_COUNSEL_INFO", dataId));
    }
    
    @Test(description = "Patent Owner|Verify patent owner count", priority = 1)
    public void patentOwnerCount() throws Exception { 
    	assertEquals(ptabDetailPage.patentOwnerCount.getIntData(),
    			sqlProcessor.getResultCount("PtabDetail.PATENT_OWNER_COUNSEL_INFO", dataId));
    }
    
    @Test(description = "Patent Owner|Verify patent owner counsel information", priority = 1)
    public void patentOwnerCounselInformation() throws Exception {    	
    	 assertEquals(ptabDetailPage.patentOwnerParties.getData(), 
    			 sqlProcessor.getResultData("PtabDetail.PATENT_OWNER_COUNSEL_INFO", dataId));
    }

    @Test(description = "Real Party in Interest|Verify real party in interest count", priority = 1)
    public void realPartyInInterestCount() throws Exception { 
    	assertEquals(ptabDetailPage.realPartyInInterestCount.getIntData(),
    			sqlProcessor.getResultCount("PtabDetail.REAL_PARTY_IN_INTEREST_COUNSEL_INFO", dataId));
    }
    
    @Test(description = "Real Party in Interest|Verify real party in interest counsel information", priority = 1)
    public void realPartyInInterestCounselInformation() throws Exception {    	
    	 assertEquals(ptabDetailPage.realPartyInInterestCounsel.getData(), 
    			 sqlProcessor.getResultData("PtabDetail.REAL_PARTY_IN_INTEREST_COUNSEL_INFO", dataId));
    }
    
    @Test(description = "Privy|Verify privy counsel information", priority = 1)
    public void privyCount() throws Exception {    	
    	 assertEquals(ptabDetailPage.privyCount.getIntData(), 
    			 sqlProcessor.getResultCount("PtabDetail.PRIVY_COUNSEL_INFO", dataId));
    }
    
    @Test(description = "Privy|Verify privy counsel information", priority = 1)
    public void privyCounselInformation() throws Exception {    	
    	 assertEquals(ptabDetailPage.privyCounselParties.getData(), 
    			 sqlProcessor.getResultData("PtabDetail.PRIVY_COUNSEL_INFO", dataId));
    }
}
