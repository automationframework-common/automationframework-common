package com.rpxcorp.insight.page;

import com.rpxcorp.testcore.element.Element;

public class RpxCorporationSitePage extends BasePage {

    public final Element servicesContent = $(".services");

    @Override
    public boolean at() {
        return servicesContent.isDisplayed();
    }
}
