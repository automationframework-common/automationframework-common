package com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.detail.*;
import com.rpxcorp.insight.page.search.PatentSearchPage;
import com.rpxcorp.testcore.Authenticate;
import org.testng.Assert;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Authenticate(role = "MEMBER")
@Test(groups = {"Lits", "PRB"})
public class ChinesePRBDetailTest extends BaseFuncTest {
    ChinesePRBDetailPage chinesePRBDetailPage;
    EntityDetailPage entityDetailPage;
    PatentDetailPage patentDetailPage;
    PatentSearchPage patentSearchPage;
    BaseDetailPage baseDetailPage;
    SoftAssert softAssert = new SoftAssert();
    private int defaultLinkCount;
    AliasesDetailPage aliasesDetailPage;
    CampaignDetailPage campaignDetailPage;
    ChinesePRBJudgeDetailPage chinesePRBJudgeDetailPage;


    /**
     * SMOKE TESTS
     **/
    @Test(priority = 1, groups = "smoke", description = "Verify all sections in Litigation details page")
    public void verifyAllSectionsInChinesePRBDetailsPage() throws Exception {
        softAssert = new SoftAssert();
        this.urlData.put("ID", "5175942");//5058100
        to(chinesePRBDetailPage, urlData);
        softAssert.assertTrue(chinesePRBDetailPage.detailPageTitle.isDisplayed());
        softAssert.assertTrue(chinesePRBDetailPage.metricsSection.isDisplayed());
        softAssert.assertTrue(chinesePRBDetailPage.overview_panel.isDisplayed());
        softAssert.assertTrue(chinesePRBDetailPage.PATENT_TABLE.isDisplayed());
        softAssert.assertTrue(chinesePRBDetailPage.patentOwner.isDisplayed());
        softAssert.assertTrue(chinesePRBDetailPage.requester.isDisplayed());
        softAssert.assertAll();
    }

    /**
     * OVERVIEW SECTION TESTS
     **/
    @Test(priority = 1, groups = "P3", description = "Verify Decision Document for chinese PRB")
    public void verifyJudgementDocForChineseLitWithJudgement() throws Exception {
        softAssert = new SoftAssert();
        this.urlData.put("ID", "5001331");
        to(chinesePRBDetailPage, urlData);
        withNewWindow(chinesePRBDetailPage.decision_doc_link, () -> {
            softAssert.assertTrue(getDriver().getCurrentUrl().contains("/china/prb/rpx-intl-lits/"),
                    "Document URL is not pointed to '/china/prb/rpx-intl-lits/'");
            softAssert.assertTrue(getDriver().getPageSource().contains("application/pdf"), "MIME media type pdf is not present");
        });
        softAssert.assertAll();
    }

    /*@Test(priority = 2, description = "Verify decision unavailable for litigation without complaint")
    public void verifyJudgementUnavailableForPRBWithoutJudgement() {
        this.urlData.put("ID", "5048279");
        to(chinesePRBDetailPage, urlData);
        assertTrue(chinesePRBDetailPage.judgementUnavailableBtn.isDisplayed(), "Decision Unavailable button is not displayed for litigation without complaint");
    }*/
    // OVERVIEW SECTION
    @BeforeGroups(groups = "overviewsection")
    public void overview() {
        urlData.put("ID", "5035973");
        to(chinesePRBDetailPage, urlData);

    }

    @Test(priority = 2, groups = {"P2", "overviewsection"}, description = "Verify chief judge link redirection")
    public void checkChiefJudgeRedirection() throws Exception {
        this.urlData.put("ID", "5036952");
        to(chinesePRBDetailPage, urlData);

        withNewWindow(chinesePRBDetailPage.overview_panel.getElement("chiefJudge"), () -> {
            at(chinesePRBJudgeDetailPage);
        });
    }

    @Test(priority = 2, groups = {"P2", "overviewsection"}, description = "Verify Collegiate Team Leader link redirection")
    public void checkCollegiateTechCentreRedirection() throws Exception {
        this.urlData.put("ID", "5035973");
        to(chinesePRBDetailPage, urlData);
        withNewWindow(chinesePRBDetailPage.overview_panel.getElement("collegiateTeamLeader"), () -> {
            at(chinesePRBJudgeDetailPage);
        });
    }

    @Test(priority = 2, groups = {"P2", "overviewsection"}, description = "Verify Participant link redirection")
    public void checkParticipantRedirection() throws Exception {
        this.urlData.put("ID", "5035973");
        to(chinesePRBDetailPage, urlData);
        withNewWindow(chinesePRBDetailPage.overview_panel.getElement("participant"), () -> {
            at(chinesePRBJudgeDetailPage);
        });
    }

    @Test(priority = 3, groups = "P2", description = "Verify Chinese PRB metrics")
    public void verifyLitStaticsVsSectionsStatistics() {
        softAssert = new SoftAssert();
        to(chinesePRBDetailPage, 5035973);
        softAssert.assertEquals(chinesePRBDetailPage.metricsSection.getIntData("requesterCount"), chinesePRBDetailPage.panel_requester_Count.getIntData(), "The Metrics Section in 'Requester' count is not matching with Requester Section Statistics");
        softAssert.assertEquals(chinesePRBDetailPage.metricsSection.getIntData("patentOwnerCount"), chinesePRBDetailPage.panel_patentOwner_Count.getIntData(), "The Metrics Section in 'Patent Owner' count is not matching with Patent Owner Section Statistics");
        softAssert.assertTrue(chinesePRBDetailPage.metricsSection.getElement("daysInLitigationCount").isDisplayed(), "The Days in Litigation Count is not displayed in the metrics section");
        softAssert.assertAll();
    }

    @BeforeGroups(groups = "cn_prb_with_requester")
    public void loadLitWithRequester() {
        this.urlData.put("ID", "5035973");//5035973
        to(chinesePRBDetailPage, urlData);
    }

    @Test(priority = 4, groups = {"P2", "cn_prb_with_requester"}, description = "Verify Chinese PRB Requester link navigation")
    public void verifyRequesterLinkFromRequesterSection() throws Exception {
        softAssert = new SoftAssert();
        chinesePRBDetailPage.requesterSectionLink.waitUntilVisible();
        String entityFromRequester = chinesePRBDetailPage.requesterSectionLink.getText().toLowerCase();
        withNewWindow(chinesePRBDetailPage.requesterSectionLink, () -> {
            at(entityDetailPage);
            String entityNameFromDetails = entityDetailPage.detailPageTitle.getText().toLowerCase();
            softAssert.assertEquals(entityNameFromDetails, entityFromRequester, "Entity Link navigation is not as expected");
        });
        softAssert.assertAll();
    }

    @BeforeGroups(groups = "cn_prb_with_defendants")
    public void loadLitWithDefendant() {
        this.urlData.put("ID", "5035973");//5035973
        to(chinesePRBDetailPage, urlData);
    }

    @Test(priority = 7, groups = {"P2", "cn_prb_with_patentowner"}, description = "Verify Chinese PRB Patent Qwner link navigation")
    public void verifyDefLinkFromPatentOwnerSection() throws Exception {
        chinesePRBDetailPage.patentownerSectionLink.waitUntilVisible();
        String entityFromDef = chinesePRBDetailPage.patentownerSectionLink.getText().toLowerCase();

        withNewWindow(chinesePRBDetailPage.patentownerSectionLink, () -> {
            at(entityDetailPage);
            String entityNameFromDetails = entityDetailPage.detailPageTitle.getText().toLowerCase();
            softAssert.assertEquals(entityNameFromDetails, entityFromDef, "Entity Link navigation is not as expected");
        });
    }

    /**
     * PATENT-IN-SUIT TESTS
     **/
    @BeforeGroups(groups = "PRB_patent_in_suit")
    public void gotoLitWithPatentInfo() {
        this.urlData.put("ID", "5035973");
        to(chinesePRBDetailPage, urlData);
        chinesePRBDetailPage.PATENT_TABLE.waitUntilVisible();
    }

    @Test(priority = 10, groups = {"P2", "PRB_patent_in_suit"}, description = "Verify Patent-In-Suit table header")
    public void verifyPatentInSuitTableHeader() throws Exception {
        String expPatentsInSuitHeader[] = {"Patent #", "Title", "Est. Priority Date"};
        chinesePRBDetailPage.PATENT_TABLE.waitUntilVisible();
        assertEquals(chinesePRBDetailPage.PATENT_TABLE.getHeaderData(), expPatentsInSuitHeader, "Patent In Suit table header is not as expected");
    }

    @DataProvider
    public Object[][] patentInSuitSortData() {
        return new Object[][]{{"Patent #", "asc", "string"}, {"Patent #", "desc", "string"},
                {"Title", "asc", "string"}, {"Title", "desc", "string"},
                {"Est. Priority Date", "asc", "date"}, {"Est. Priority Date", "desc", "date"}};
    }

    /*@Test(priority = 16, groups = "PRB_patent_in_suit", description = "Verify message for PRB without patent in patent in suit")
    public void verifyMessageInPatentInSuitPRBWithoutRecords() throws Exception {
        this.urlData.put("ID", "5007482");
        to(chinesePRBDetailPage, urlData);
        chinesePRBDetailPage.noPatentInSuitMsg.waitUntilVisible();
        assertEquals(chinesePRBDetailPage.noPatentInSuitMsg.getText(), "Patents have not yet been matched", "Message for patent in suit without records");
    }*/

    /**
     * LITIGATION CAMPAIGN - CASES TAB TESTS
     **/
    @BeforeGroups(groups = "PRB_lit_with_cases_in_lit_camp")
    public void PRBloadLitWithCasesInLitCamp() {
        this.urlData.put("ID", "5013564");
        to(chinesePRBDetailPage, urlData);
        chinesePRBDetailPage.PRB_selectCasesTab();
        chinesePRBDetailPage.PRB_litigation_cases.waitUntilVisible();
    }

    @Test(priority = 351, groups = {"P2", "PRB_lit_with_cases_in_lit_camp"}, description = "verify Litigation Campaign - Cases Table header")
    public void verifyHeaderInPRBLitCampCasesTab() throws Exception {
        String expHeader[] = {"Date Filed", "Case Name", "Case Number", "Termination Date", "Jurisdiction"};
        chinesePRBDetailPage.PRB_litigation_cases.waitUntilVisible();
        assertEquals(chinesePRBDetailPage.PRB_litigation_cases.getHeaderData(), expHeader, "Litigation Campaign - Cases Tab header");
    }

    @Test(priority = 352, groups = {"P3", "PRB_lit_wicheckDefendantStatusFilterInPRBTimeLineth_cases_in_lit_camp"}, description = "Verify Litigation Campaign - Cases table view less")
    public void verifyViewLessInPRBLitCampCasesTab() {
        softAssert = new SoftAssert();
        chinesePRBDetailPage.PRB_litigation_cases.viewAll();
        int recordsBeforeViewLess = chinesePRBDetailPage.PRB_litigation_cases.displayedRecords().getElements().size();
        chinesePRBDetailPage.PRB_litigation_cases.viewLess();
        int recordsAfterViewLess = chinesePRBDetailPage.PRB_litigation_cases.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsAfterViewLess == 7, "7 records are not displayed after view less, records displayed after view less: " + recordsAfterViewLess);
        softAssert.assertTrue(recordsBeforeViewLess > recordsAfterViewLess, "Records displayed after view less is not less than records before view less, "
                + "Records before view less: " + recordsBeforeViewLess + " Records after view less: " + recordsAfterViewLess);
        softAssert.assertAll();
    }

    @Test(priority = 353, groups = {"P3", "PRB_lit_with_cases_in_lit_camp"}, description = "Verify Litigation Campaign - Cases table view all")
    public void verifyViewAllInLitCampCasesTab() {
        softAssert = new SoftAssert();
        int recordsBeforeViewAll = chinesePRBDetailPage.PRB_litigation_cases.displayedRecords().getElements().size();
        chinesePRBDetailPage.PRB_litigation_cases.viewAll();
        int recordsAfterViewAll = chinesePRBDetailPage.PRB_litigation_cases.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsBeforeViewAll == 7, "7 records are not displayed before view all, records displayed after view all: " + recordsAfterViewAll);
        softAssert.assertTrue(recordsAfterViewAll > recordsBeforeViewAll, "Records displayed after view all is not greater than records before view all, "
                + " Records before view all: " + recordsBeforeViewAll + " Records after view all: " + recordsAfterViewAll);
        softAssert.assertAll();
    }

    @Test(priority = 354, groups = {"P4", "PRB_lit_with_cases_in_lit_camp", "func_sorting"}, description = "Verify default sort in Litigation Campaign - Cases tab")
    public void verifyDefaultSortInPRBLitCampCasesTab() {
        assertColumnSort("date", "desc", chinesePRBDetailPage.PRB_litigation_cases.getColumn("Date Filed"));
    }

    @Test(priority = 355, groups = {"P4","PRB_lit_with_cases_in_lit_camp", "func_sorting"}, dataProvider = "PRBlitCampCasesSortData", description = "Verify sorting in Litigation Campaign - Cases tab")
    public void verifySortingInPRBLitCampCasesTab(String columnName, String sortType, String dataType) throws Exception {
        chinesePRBDetailPage.PRB_litigation_cases.sort(columnName);
        assertColumnSort(dataType, sortType, chinesePRBDetailPage.PRB_litigation_cases.getColumn(columnName));
    }

    @DataProvider
    public Object[][] PRBlitCampCasesSortData() {
        return new Object[][]{
                {"Date Filed", "asc", "date"}, {"Date Filed", "desc", "date"},
                {"Case Name", "asc", "string"}, {"Case Name", "desc", "string"},
                {"Case Number", "asc", "string"}, {"Case Number", "desc", "string"},
                {"Termination Date", "asc", "date"}, {"Termination Date", "desc", "date"},
                {"Jurisdiction", "asc", "string"}, {"Jurisdiction", "desc", "string"}
        };
    }

    @Test(priority = 356, groups = "P2", dataProvider = "PRBCampCaseLinks", description = "Verify Case Name link navigation from Litigation Campaign - Cases tab [RPX-16194]")
    public void verifyCaseNameLinksFromPRBCampCasesTab(String type, String PRBId) throws Exception {
        this.urlData.put("ID", PRBId);
        to(chinesePRBDetailPage, urlData);
        chinesePRBDetailPage.PRB_selectCasesTab();
        chinesePRBDetailPage.PRB_litigation_cases.waitUntilVisible();
        chinesePRBDetailPage.casenum_column.click();
        String caseNameInTable = chinesePRBDetailPage.PRB_litigation_cases.getFirstlinkFromColumn(2).getText().toLowerCase();
        chinesePRBDetailPage.PRB_litigation_cases.waitUntilVisible();
        withNewWindow(chinesePRBDetailPage.PRB_litigation_cases.getFirstlinkFromColumn(2), () -> {
            at(baseDetailPage);
            String titleInDetailsPage = baseDetailPage.detailPageTitle.getText().toLowerCase().replace("prb", "").trim();
            Assert.assertEquals(titleInDetailsPage, caseNameInTable, "Case Name in Litigation Campaign Cases tab and its corresponding detail page are not same");
        });
        }

    @DataProvider
    public Object[][] PRBCampCaseLinks() {
        return new Object[][]{
                {"PRB_case_as_first_record", "5130936"}
        };
    }

    /**
     * LITIGATION CAMPAIGN - DEFENDANT TAB TESTS
     **/
    @BeforeGroups(groups = "PRB_lit_without_defendants")
    public void loadLitWithoutDefendants() {
        this.urlData.put("ID", "5048279");
        to(chinesePRBDetailPage, urlData);
        chinesePRBDetailPage.PRB_litigationCampaignTabs.waitUntilVisible();
        chinesePRBDetailPage.PRB_litigationCampaignTabs.select("Defendants");
    }

    /* @Test(priority = 801, groups = "lit_without_defendants", description  = "Verify message displayed for litigations without defendant")
     public void verifyMessageForLitigationsWithoutDefedants() throws Exception {
         assertEquals(chinesePRBDetailPage.noDefendantsNotes.getText(), "No Defendants Entries have been identified.", "No defendants message");
     }*/
    @BeforeGroups(groups = "PRB_with_defendants_tab")
    public void PRB_loadLitWithDefendants() {
        this.urlData.put("ID", "5048279");
        to(chinesePRBDetailPage, urlData);
        chinesePRBDetailPage.PRB_litigationCampaignTabs.waitUntilVisible();
        chinesePRBDetailPage.PRB_litigationCampaignTabs.select("Defendant");
    }

    @Test(priority = 802, groups = {"P2", "PRB_with_defendants_tab"}, description = "Verify litigation campaign - defendant view table header")
    public void verifyPRBCampPRBDefendantsTableColumn() throws Exception {
        String expHeaders[] = {"Defendant Parent", "Defendants", "Most Recent Case", "Start Date", "End Date"};
        chinesePRBDetailPage.PRB_defendant_table.waitUntilVisible();
        assertEquals(chinesePRBDetailPage.PRB_defendant_table.getHeaderData(), expHeaders, "Litigation campaign - defendant table headers");
    }

    @Test(priority = 803, groups = {"P3", "PRB_with_defendants_tab"}, description = "Verify view less in Litigation Campaign - Defendant table")
    public void verifyPRBCampDefendantTabViewLess() {
        softAssert = new SoftAssert();
        chinesePRBDetailPage.PRB_defendant_table.waitUntilVisible();
        chinesePRBDetailPage.PRB_defendant_table.viewAll();
        int recordsBeforeViewLess = chinesePRBDetailPage.PRB_defendant_table.displayedRecords().getElements().size();
        chinesePRBDetailPage.PRB_defendant_table.viewLess();
        int recordsAfterViewLess = chinesePRBDetailPage.PRB_defendant_table.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsAfterViewLess == 10, "10 records are not displayed after view less");
        softAssert.assertTrue(recordsBeforeViewLess > recordsAfterViewLess, "Records displayed after view less is not less than records before view less");
        softAssert.assertAll();
    }

    @Test(priority = 804, groups = {"P3", "PRB_with_defendants_tab"}, description = "Verify view all in Litigation Campaign - Defendant table")
    public void verifyPRBCampDefendantTabViewAll() {
        softAssert = new SoftAssert();
        chinesePRBDetailPage.PRB_defendant_table.waitUntilVisible();
        int recordsBeforeViewAll = chinesePRBDetailPage.PRB_defendant_table.displayedRecords().getElements().size();
        chinesePRBDetailPage.PRB_defendant_table.viewAll();
        int recordsAfterViewAll = chinesePRBDetailPage.PRB_defendant_table.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsBeforeViewAll == 10, "10 records are not displayed before view all");
        softAssert.assertTrue(recordsAfterViewAll > recordsBeforeViewAll, "Records displayed after view all is not greater than records before view all");
        softAssert.assertAll();
    }

    @Test(priority = 805, groups = {"P2", "PRB_with_defendants_tab"}, description = "Verify Defendant Parent link in Litigation Campaign - Defendant table")
    public void verifyPRBCampDefendantTabDefParentLink() throws Exception {
        softAssert = new SoftAssert();
        chinesePRBDetailPage.PRB_defendant_table.waitUntilVisible();
        //String defParentLinkFromTable = litigationDetailPage.litCampDefendantTabDefParentLink.getText().toLowerCase();
        String defParentLinkFromTable = chinesePRBDetailPage.PRB_defendant_table.getFirstlinkFromColumn(1).getText().toLowerCase();//Defendent Parent Column
        withNewWindow(chinesePRBDetailPage.PRB_defendant_table.getFirstlinkFromColumn(1), () -> {
            at(entityDetailPage);
            String entTitleFromDetails = entityDetailPage.detailPageTitle.getText().toLowerCase();
            softAssert.assertEquals(entTitleFromDetails, defParentLinkFromTable, "Defendant Parent link text and corresponding entity details page title not matched");
        });
        softAssert.assertAll();
    }

    @Test(priority = 806, groups = {"P2", "PRB_with_defendants_tab"}, description = "Verify Defendants link in Litigation Campaign - Defendant table")
    public void verifyPRBCampDefendantTabDefendantsLink() throws Exception {
        softAssert = new SoftAssert();
        chinesePRBDetailPage.PRB_defendant_table.waitUntilVisible();
        String defLinkFromTable = chinesePRBDetailPage.PRB_defendant_table.getColumnLinkElem("Defendants").getAttribute("data-ot-content").toLowerCase();//Defendent Column
        withNewWindow(chinesePRBDetailPage.PRB_defendant_table.getColumnLinkElem("Defendants"), () -> {
            at(entityDetailPage);
            String entTitleFromDetails = entityDetailPage.detailPageTitle.getText().toUpperCase().toLowerCase();
            softAssert.assertEquals(entTitleFromDetails, defLinkFromTable, "Defendants link text and corresponding entity details page title not matched");
        });
        softAssert.assertAll();
    }

    @Test(priority = 807,groups = {"P4", "PRB_with_defendants_tab", "func_sorting"}, description = "Verify default sort in Litigation Campaign - Defendant table")
    public void verifyPRBCampDefendantTabDefaultSort() {
        assertColumnSort("date", "desc", chinesePRBDetailPage.PRB_defendant_table.getColumn("Start Date"));
    }

    @Test(priority = 808, groups = {"P4", "PRB_with_defendants_tab", "func_sorting"}, dataProvider = "PRB_defendantSortData", description = "Verify sorting in Litigation Campaign - Defendant table")
    public void verifyPRBCampDefendantTabSorting(String columnName, String sortType, String dataType) throws Exception {
        chinesePRBDetailPage.PRB_defendant_table.sort(columnName);
        assertColumnSort(dataType, sortType, chinesePRBDetailPage.PRB_defendant_table.getColumn(columnName));
    }

    @DataProvider
    public Object[][] PRB_defendantSortData() {
        return new Object[][]{
                {"Defendant Parent", "asc", "string"}, {"Defendant Parent", "desc", "string"},
                {"Defendants", "asc", "string"}, {"Defendants", "desc", "string"},
                {"Start Date", "asc", "date"}, {"Start Date", "desc", "date"},
                {"End Date", "asc", "date"}, {"End Date", "desc", "date"}
        };
    }

    @Test(priority = 809, dataProvider = "PRB_defendantSearchData", groups = {"P2", "PRB_with_defendants_tab"}, description = "Verify search in Litigation Campaign - Defendant table")
    public void verifyPRBCampDefendantTabSearch(String searchTerm) {
        chinesePRBDetailPage.defendantSearch(searchTerm);
        for (String actualRowValue : chinesePRBDetailPage.PRB_defendant_table.getRows()) {
            Assert.assertTrue(actualRowValue.contains(searchTerm), "Search term not retrieved in results, Search term: " + searchTerm +
                    " Actual value in table: " + actualRowValue);
        }
    }

    @DataProvider
    public Object[][] PRB_defendantSearchData() {
        return new Object[][]{
                {"Hetero Drugs Limited"},
                {"Ascent Pharmaceuticals Inc."},
                {"1:18-cv-00855"},
                {"04/01/2019"}
        };
    }

    @Test(priority = 810, dataProvider = "invalidDefendantSearchData", groups = {"P3", "PRB_with_defendants_tab"},
            description = "Verify invalid search in Litigation Campaign - Defendant table")
    public void verifyPRBCampDefendantTabInvalidSearch(String searchTerm) throws Exception {
        chinesePRBDetailPage.defendantSearch(searchTerm);
        assertEquals(chinesePRBDetailPage.noDataInDefendantTable.getText(), "No matching records found", "Message for invalid search not as expected");
    }

    @DataProvider
    public Object[][] invalidDefendantSearchData() {
        return new Object[][]{{"***INVALID ENTRY DATA***"}};
    }

    @Test(priority = 811, groups = "P3", dataProvider = "PRBCampDefTabMostRecentCaseData", description = "Verify most recent case link in Litigation Campaign - Defendant table")
    public void verifyPRBCampDefendantTabMostRecentCaseLink(String type, String litId) throws Exception {
        softAssert = new SoftAssert();
        this.urlData.put("ID", litId);
        to(chinesePRBDetailPage, urlData);
        chinesePRBDetailPage.PRB_litigationCampaignTabs.waitUntilVisible();
        chinesePRBDetailPage.PRB_litigationCampaignTabs.select("Defendants");
        chinesePRBDetailPage.PRBCampDefendantMostRecentCaseLink.waitUntilVisible();
        String mostRecentCaseLinkFromTable = chinesePRBDetailPage.PRBCampDefendantMostRecentCaseLink.getText().toLowerCase();
        withNewWindow(chinesePRBDetailPage.PRBCampDefendantMostRecentCaseLink, () -> {
            at(baseDetailPage);
            String titleFromDetailsPage = baseDetailPage.getCaseNumber().toLowerCase();
            softAssert.assertEquals(titleFromDetailsPage, mostRecentCaseLinkFromTable, "Most Recent Case link text and corresponding details page title not matched");
        });
        softAssert.assertAll();
    }

    @DataProvider
    public Object[][] PRBCampDefTabMostRecentCaseData() {
        return new Object[][]{
                {"CN as most recent case", "5011915"},
                {"CN with PRB as most recent case", "5014477"}
        };
    }

    @BeforeGroups(groups = "PRB_with_defendants_subtable")
    public void loadLitigationWithDefendantSubTable() {
        this.urlData.put("ID", "5014477");
        to(chinesePRBDetailPage, urlData);
        chinesePRBDetailPage.PRB_litigationCampaignTabs.waitUntilVisible();
        chinesePRBDetailPage.PRB_litigationCampaignTabs.select("Defendants");
    }

    @Test(priority = 812, groups = {"P2", "PRB_with_defendants_tab"}, description = "Verify Litigation Campaign section tabs")
    public void checkPRBLitCampaignTab() {
        softAssert = new SoftAssert();
        softAssert.assertTrue(chinesePRBDetailPage.PRB_litigationCampaignTabs.getText().toString().contains("Timeline"),
                "TIMELINE tab is not displayed in litigation campaign section");
        softAssert.assertTrue(chinesePRBDetailPage.PRB_litigationCampaignTabs.getText().toString().contains("Cases"),
                "Cases tab is not displayed in litigation campaign section");
        softAssert.assertTrue(chinesePRBDetailPage.PRB_litigationCampaignTabs.getText().toString().contains("Defendants"),
                "Defendants tab is displayed in litigation campaign section");
        softAssert.assertTrue(chinesePRBDetailPage.PRB_litigationCampaignTabs.getText().toString().contains("Patents"),
                "Patents tab is displayed in litigation campaign section");
        softAssert.assertTrue(chinesePRBDetailPage.PRB_litigationCampaignTabs.getText().toString().contains("Accused Products"),
                "Accused Products tab is displayed in litigation campaign section");
        softAssert.assertTrue(chinesePRBDetailPage.PRB_litigationCampaignTabs.getText().toString().contains("Patent Grid"),
                "patent Grid tab is displayed in litigation campaign section");
        softAssert.assertAll();

    }

    @Test(priority = 812, groups = {"P2", "PRB_with_defendants_tab"}, description = "Verify Litigation Campaign - sub table header")
    public void verifyPRBCampDefendantsSubTableColumn() throws Exception {
        String expHeader[] = {"Date Filed", "Case Name", "Case Number", "Jurisdiction", "Termination Date"};
        chinesePRBDetailPage.PRB_defendant_table.expandSubTable();
        chinesePRBDetailPage.PRB_defendant_table.subtable().waitUntilVisible();
        List<String> actualHeaderList = new ArrayList<String>(Arrays.asList(chinesePRBDetailPage.PRB_defendant_table.subtable().getHeaderData()));
        actualHeaderList.remove("Id");
        String actualHeader[] = actualHeaderList.toArray(new String[actualHeaderList.size()]);
        assertEquals(actualHeader, expHeader, "Defendant sub table header is not as expected");
    }

    @Test(priority = 813, groups = {"P4","PRB_with_defendants_subtable", "func_sorting"}, description = "Verify default sort in Litigation Campaign - Defendant sub table")
    public void verifyPRBCampDefendantTabSubTableDefaultSort() {
        chinesePRBDetailPage.PRB_defendant_table.expandSubTable();
        chinesePRBDetailPage.PRB_defendant_table.subtable().waitUntilVisible();
        assertColumnSort("date", "desc", chinesePRBDetailPage.PRB_defendant_table.subtable().getColumn("Date Filed"));
    }

    @Test(priority = 814, groups = {"P4","PRB_with_defendants_subtable", "func_sorting"}, dataProvider = "PRBdefendantSubTableSortData",
            description = "Verify sorting in Litigation Campaign - Defendant sub table")
    public void verifyLitCampDefendantTabSubTableSorting(String columnName, String sortType, String dataType) throws Exception {
        chinesePRBDetailPage.PRB_defendant_table.expandSubTable();
        chinesePRBDetailPage.PRB_defendant_table.subtable().waitUntilVisible();
        chinesePRBDetailPage.PRB_defendant_table.subtable().sort(columnName);
        assertColumnSort(dataType, sortType, chinesePRBDetailPage.PRB_defendant_table.subtable().getColumn(columnName));
    }

    @DataProvider
    public Object[][] PRBdefendantSubTableSortData() {
        return new Object[][]{
                {"Date Filed", "asc", "date"}, {"Date Filed", "desc", "date"},
                {"Case Name", "asc", "string"}, {"Case Name", "desc", "string"},
                {"Case Number", "asc", "string"}, {"Case Number", "desc", "string"},
                {"Termination Date", "asc", "date"}, {"Termination Date", "desc", "date"}
        };
    }

    @Test(priority = 815, groups = "P2", dataProvider = "PRB_defendantSubTableCaseNameData", description = "Verify case name link from Litigation Campaign - Defendant sub table")
    public void verifyCaseNameLinkFromPRBCampDefendantSubTable(String type, String PRBId) throws Exception {
        softAssert = new SoftAssert();
        to(chinesePRBDetailPage, "5037653");
        chinesePRBDetailPage.PRB_litigationCampaignTabs.waitUntilVisible();
        chinesePRBDetailPage.PRB_litigationCampaignTabs.select("Defendant");
        chinesePRBDetailPage.PRB_defendant_table.expandSubTable();
        chinesePRBDetailPage.PRBcaseNameLinkInLitCampDefTabSubTable.waitUntilVisible();
        String caseNameFromSubTable = chinesePRBDetailPage.PRBcaseNameLinkInLitCampDefTabSubTable.getText().toLowerCase();
        withNewWindow(chinesePRBDetailPage.PRBcaseNameLinkInLitCampDefTabSubTable, () -> {
            at(baseDetailPage);
            String titleFromDetails = baseDetailPage.detailPageTitle.getText().toLowerCase();
            softAssert.assertEquals(titleFromDetails, caseNameFromSubTable, "Case name link text and corresponding details page title not matched");
        });
        softAssert.assertAll();
    }

    @Test(priority = 816, groups = "P2", dataProvider = "PRB_defendantSubTableCaseNameData", description = "Verify case number link from Litigation Campaign - Defendant sub table")
    public void verifyPRBCampDefendantTabSubTableCaseNoLink(String type, String PRBId) throws Exception {
        softAssert = new SoftAssert();
        to(chinesePRBDetailPage, "5136761-apple-trading-company-limited-v-beijing-zhongke-zixin-technology-company-limited-of-135");
        //to(chinesePRBDetailPage, urlData);
        chinesePRBDetailPage.PRB_litigationCampaignTabs.waitUntilVisible();
        chinesePRBDetailPage.PRB_litigationCampaignTabs.select("Defendant");

        chinesePRBDetailPage.PRB_defendant_table.expandSubTable();
        chinesePRBDetailPage.PRBcaseNameLinkInLitCampDefTabSubTable.waitUntilVisible();
        String caseNoFromSubTable = chinesePRBDetailPage.PRBcaseNameLinkInLitCampDefTabSubTable.getText().toLowerCase();
        withNewWindow(chinesePRBDetailPage.PRBcaseNameLinkInLitCampDefTabSubTable, () -> {
            at(baseDetailPage);
            String caseNoFromDetails = baseDetailPage.getCaseNumber().toLowerCase();
            softAssert.assertEquals(caseNoFromDetails, caseNoFromSubTable, "Case number link text and corresponding case number in details page not matched");
        });
        softAssert.assertAll();
    }

    @DataProvider
    public Object[][] PRB_defendantSubTableCaseNameData() {
        return new Object[][]{
                {"CN as first case in sub table", "4034722-yuan-desheng-plastic-electronics-v-zhengzhou-jinshui-district-xinyang-mobile-phone-shop"}
        };
    }

    /**
     * LITIGATION CAMPAIGN - PATENTS TAB TESTS
     **/
    /*@Test(priority = 851, description = "Verify message displayed for litigation without patents in litigation campaign section")
    public void verifyMessageInLitCampPatentsTabWithNoPatents() throws Exception {
        this.urlData.put("ID", "wiedce-4315");
        to(chinesePRBDetailPage, urlData);
        chinesePRBDetailPage.PRB_litigationCampaignTabs.waitUntilVisible();
        chinesePRBDetailPage.PRB_litigationCampaignTabs.select("Patents");
        assertEquals(chinesePRBDetailPage.noPatentsInLitCamp.getText(), "No patents found", "Message for no patents in a litigation");
    }*/
    @BeforeGroups(groups = "lit_with_patents_in_PRB_camp")
    public void PRBloadLitWithPatentsInLitCamp() {
        this.urlData.put("ID", "5013564");
        to(chinesePRBDetailPage, urlData);
        chinesePRBDetailPage.PRB_litigationCampaignTabs.waitUntilVisible();
        chinesePRBDetailPage.PRB_litigationCampaignTabs.select("Patents");
    }

    @Test(priority = 852, groups = {"P2", "lit_with_patents_in_PRB_camp"}, description = "Verify table header in litigation campaign - patents tab")
    public void verifyPRBCampPatentsTabTableHeader() throws Exception {
        String expHeader[] = {"Patent #", "Title", "Current Assignee", "Original Assignee", "Est. Priority Date", "Issue Date"};
        chinesePRBDetailPage.PRB_camp_patent_table.waitUntilVisible();
        assertEquals(chinesePRBDetailPage.PRB_camp_patent_table.getHeaderData(), expHeader, "Table header");
    }

    @Test(priority = 854, groups = {"P3", "lit_with_patents_in_PRB_camp"}, description = "Verify view less in litigation campaign - patents tab")
    public void verifyViewLessInLitCampPatentsTab() {
        softAssert = new SoftAssert();
        chinesePRBDetailPage.PRB_camp_patent_table.waitUntilVisible();
        chinesePRBDetailPage.PRB_camp_patent_table.viewAll();
        int recordsBeforeViewLess = chinesePRBDetailPage.PRB_camp_patent_table.displayedRecords().getElements().size();
        chinesePRBDetailPage.PRB_camp_patent_table.viewLess();
        int recordsAfterViewLess = chinesePRBDetailPage.PRB_camp_patent_table.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsAfterViewLess == 7, "7 records are not displayed after view less, records displayed after view less: " + recordsAfterViewLess);
        softAssert.assertTrue(recordsBeforeViewLess > recordsAfterViewLess, "Records displayed after view less is not less than records before view less, "
                + "Records before view less: " + recordsBeforeViewLess + " Records after view less: " + recordsAfterViewLess);
        softAssert.assertAll();
    }

    @Test(priority = 855, groups = {"P3","lit_with_patents_in_PRB_camp"}, description = "Verify view all in litigation campaign - patents tab")
    public void verifyViewAllInPRBCampPatentsTab() {
        softAssert = new SoftAssert();
        int recordsBeforeViewAll = chinesePRBDetailPage.PRB_camp_patent_table.displayedRecords().getElements().size();
        chinesePRBDetailPage.PRB_camp_patent_table.viewAll();
        int recordsAfterViewAll = chinesePRBDetailPage.PRB_camp_patent_table.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsBeforeViewAll == 7, "7 records are not displayed before view all, records displayed after view all: " + recordsAfterViewAll);
        softAssert.assertTrue(recordsAfterViewAll > recordsBeforeViewAll, "Records displayed after view all is not greater than records before view all, "
                + " Records before view all: " + recordsBeforeViewAll + " Records after view all: " + recordsAfterViewAll);
        softAssert.assertAll();
    }

    @Test(priority = 856, groups = {"P4", "lit_with_patents_in_PRB_camp"}, description = "Verify default sort in Litigation Campaign - Patents tab")
    public void verifyDefaultSortInPRBCampPatentsTab() {
        assertColumnSort("date", "desc", chinesePRBDetailPage.PRB_camp_patent_table.getColumn("Est. Priority Date"));
    }

    @Test(priority = 857, groups = {"P4","lit_with_patents_in_PRB_camp", "func_sorting"}, dataProvider = "litCampPRBPatentsSortData", description = "Verify sorting in Litigation Campaign - Patents tab")
    public void verifySortingInLitCampPatentsTab(String columnName, String sortType, String dataType) throws Exception {
        to(chinesePRBDetailPage, "5013564", false);
        at(chinesePRBDetailPage);
        chinesePRBDetailPage.PRB_litigationCampaignTabs.waitUntilVisible();
        chinesePRBDetailPage.PRB_litigationCampaignTabs.select("Patents");
        chinesePRBDetailPage.PRB_camp_patent_table.sort(columnName);
        assertColumnSort(dataType, sortType, chinesePRBDetailPage.PRB_camp_patent_table.getColumn(columnName));
    }

    @DataProvider
    public Object[][] litCampPRBPatentsSortData() {
        return new Object[][]{
                {"Patent #", "asc", "string"}, {"Patent #", "desc", "string"},
                {"Title", "asc", "string"}, {"Title", "desc", "string"},
                {"Est. Priority Date", "asc", "date"}, {"Est. Priority Date", "desc", "date"}
        };
    }

    @Test(priority = 858, groups = {"P2", "lit_with_patents_in_PRB_camp"}, description = "Verify View As Search in Litigation Campaign - Patents tab")
    public void verifyViewAsSearchInPRBCampPatentsTab() throws Exception {
        softAssert = new SoftAssert();
        List<String> patentColumnInTable = chinesePRBDetailPage.PRB_camp_patent_table.getColumn("Patent #");
        Collections.sort(patentColumnInTable);
        withNewWindow(chinesePRBDetailPage.litCampViewAsSearchResults, () -> {
            at(patentSearchPage);
            List<String> searchResultsPatents = patentSearchPage.search_result.getColumn("Patent #");
            Collections.sort(searchResultsPatents);
            softAssert.assertEquals(searchResultsPatents, patentColumnInTable, "Patents doesn't match, Patents in litigation details lit campaign: " + patentColumnInTable.toString()
                    + " Patents in search results: " + searchResultsPatents);
        });
        softAssert.assertAll();
    }

    /**
     * LITIGATION CAMPAIGN - ACCUSED PRODUCTS TAB
     **/
    @Test(priority = 876, groups = "P3", description = "Verify message in Litigation Campaign - Accused Products tab for litigation without accused products")
    public void verifyPRBCampAccusedProductsWithoutAccusedProducts() throws Exception {
        this.urlData.put("ID", "5024668");
        to(chinesePRBDetailPage, urlData);
        chinesePRBDetailPage.PRB_litigationCampaignTabs.waitUntilVisible();
        chinesePRBDetailPage.PRB_litigationCampaignTabs.select("Accused Products");

        assertEquals(chinesePRBDetailPage.no_accused_products.getText(), "No accused products found", "No Accused products message");
    }

    @BeforeGroups(groups = "lit_accused_products_PRB_camp")
    public void loadPRBWithAccusedProducts() {
        this.urlData.put("ID", "5013564");
        to(chinesePRBDetailPage, urlData);
        chinesePRBDetailPage.PRB_litigationCampaignTabs.waitUntilVisible();
        chinesePRBDetailPage.PRB_litigationCampaignTabs.select("Accused Products");
    }

    @Test(priority = 877, groups = {"P3", "lit_accused_products_PRB_camp"}, description = "Verify Litigation Campaign - Accused products tab table header")
    public void verifyPRBCampAccusedProductsTableHeader() throws Exception {
        String expheader[] = {"Date Filed", "Defendants", "Case Number", "Accused Products"};
        chinesePRBDetailPage.PRB_camp_accused_table.waitUntilVisible();
        assertEquals(chinesePRBDetailPage.PRB_camp_accused_table.getHeaderData(), expheader, "Litigation campaign - accused products table header");
    }

    @Test(priority = 878, groups = {"P2","lit_accused_productscheckAffiliatesViewAllLinkAndCount_PRB_camp"}, description = "Verify Defendants link from Litigation Campaign - Accused products tab")
    public void verifyDefendantslinkInPRBCampAccusedProductsTab() throws Exception {
        String defendantTitleFromtable = chinesePRBDetailPage.PRB_camp_accused_table.getFirstlinkFromColumn(2).getText().toLowerCase();
        withNewWindow(chinesePRBDetailPage.PRB_camp_accused_table.getFirstlinkFromColumn(2), () -> {
            at(entityDetailPage);
            //String entityNameFromDetails = entityDetailPage.detailPageTitle.getText().toLowerCase();
            //Assert.assertEquals(entityNameFromDetails.toLowerCase(), defendantTitleFromtable.toLowerCase(), "Entity Link navigation is not as expected");
        });
    }

    @Test(priority = 879, groups = {"P3", "lit_accused_products_PRB_camp"}, description = "Verify View Less in Litigation Campaign - Accused products tab")
    public void verifyViewLessInPRBCampAccusedProductsTab() throws InterruptedException {
        softAssert = new SoftAssert();
        chinesePRBDetailPage.PRB_camp_accused_table.waitUntilVisible();
        chinesePRBDetailPage.PRB_camp_accused_table.viewAll();
        int recordsBeforeViewLess = chinesePRBDetailPage.PRB_camp_accused_table.displayedRecords().getElements().size();
        chinesePRBDetailPage.PRB_camp_accused_table.viewLess();
        int recordsAfterViewLess = chinesePRBDetailPage.PRB_camp_accused_table.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsAfterViewLess == 7, "7 records are not displayed after view less, records displayed after view less: " + recordsAfterViewLess);
        softAssert.assertTrue(recordsBeforeViewLess > recordsAfterViewLess, "Records displayed after view less is not less than records before view less, "
                + "Records before view less: " + recordsBeforeViewLess + " Records after view less: " + recordsAfterViewLess);
        softAssert.assertAll();
    }

    @Test(priority = 880, groups = {"P3","lit_accused_products_PRB_camp"}, description = "Verify View All in Litigation Campaign - Accused products tab")
    public void verifyViewAllInLitCampAccusedProductsTab() {
        softAssert = new SoftAssert();
        int recordsBeforeViewAll = chinesePRBDetailPage.PRB_camp_accused_table.displayedRecords().getElements().size();
        chinesePRBDetailPage.PRB_camp_accused_table.viewAll();
        int recordsAfterViewAll = chinesePRBDetailPage.PRB_camp_accused_table.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsBeforeViewAll == 7, "7 records are not displayed before view all, records displayed after view all: " + recordsAfterViewAll);
        softAssert.assertTrue(recordsAfterViewAll > recordsBeforeViewAll, "Records displayed after view all is not greater than records before view all, "
                + " Records before view all: " + recordsBeforeViewAll + " Records after view all: " + recordsAfterViewAll);
        softAssert.assertAll();
    }

    @Test(priority = 881, groups = {"P4","lit_accused_products_PRB_camp", "func_sorting"}, description = "Verify Default Sort in Litigation Campaign - Accused Products")
    public void verifyDefaultSortInPRBCampAccusedProductsTab() {
        assertColumnSort("date", "desc", chinesePRBDetailPage.PRB_camp_accused_table.getColumn("Date Filed"));
    }

    @Test(priority = 882, groups = {"P4","lit_accused_products_PRB_camp", "func_sorting"}, dataProvider = "PRBCampAccusedProductsSortData",
            description = "Verify Sorting in Litigation Campaign - Accused Products")
    public void verifySortingInPRBCampAccusedProductsTab(String columnName, String sortType, String dataType) throws Exception {
        chinesePRBDetailPage.PRB_camp_accused_table.sort(columnName);
        assertColumnSort(dataType, sortType, chinesePRBDetailPage.PRB_camp_accused_table.getColumn(columnName));
    }

    @DataProvider
    public Object[][] PRBCampAccusedProductsSortData() {
        return new Object[][]{
                {"Defendants", "asc", "string"}, {"Defendants", "desc", "string"},
                {"Accused Products", "asc", "string"}, {"Accused Products", "desc", "string"},
                {"Date Filed", "asc", "date"}, {"Date Filed", "desc", "date"}
        };
    }

    //ADV TIMELINE VIEW FILTERS - --todo Low Priority TC
    //@Test(priority = 950, description = "Verify defendant name search in Campaign TimeLine View | RPX-12729")
//    public void checkDefendantOrderAtPRBTimeLineView() throws Exception {
//        this.urlData.put("ID", "5032037");
//        to(chinesePRBDetailPage, urlData);
//        chinesePRBDetailPage.selectDefendantTab();
//        List<String> defendantData = chinesePRBDetailPage.defendantParent.getAllData();
//        Collections.reverse(defendantData);
//        chinesePRBDetailPage.selectDefendantTimelineTab();
//        chinesePRBDetailPage.defendantsInTimelineChart.waitUntilVisible();
//        assertEquals(chinesePRBDetailPage.defendantsInTimelineChart.getAllData(), defendantData);
//    }

    @Test(priority = 951, groups = "P2", dataProvider = "defendantNames", description = "Verify defendant name search in Campaign TimeLine View")
    public void checkDefendantSearchAtPRBTimeLineView(String litId, String defendantName) throws Exception {
        softAssert = new SoftAssert();
        this.urlData.put("ID", litId);
        to(chinesePRBDetailPage, urlData);
        chinesePRBDetailPage.applyDefendantFilter(defendantName);
        chinesePRBDetailPage.defendantsInTimelineChart.waitUntilVisible();
        assertEquals(chinesePRBDetailPage.defendantsInTimelineChart.getText(), defendantName);
    }

    @DataProvider(name = "defendantNames")
    public Object[][] getDefendantNames() {
        return new Object[][]{{"5013564", "ZTE Corporation"},//Defendant involved in both PTAB and PRB
                {"5112641", "Huawei Investment & Holding Co., Ltd."}, //Defendant involved in both CN and PRB

        };
    }

    @Test(priority = 955, groups = "P2", dataProvider = "status", description = "Verify defendant Status filter in TimeLine View")
    public void checkDefendantStatusFilterInPRBTimeLine(String status) throws Exception {
        to(chinesePRBDetailPage, "5013564" /*"13972"*/);
        chinesePRBDetailPage.closeTimelinePopupModal();
        chinesePRBDetailPage.clearFilters();
        String campURL = chinesePRBDetailPage.campLinkInLitCampSection.getAttribute("href");
        chinesePRBDetailPage.navigateTo(campURL);
        at(campaignDetailPage);
        int terminatedDefendants = Integer.valueOf(campaignDetailPage.overviewPanel.getData("Defendants Terminated Count"));
        int totalDefendants = Integer.valueOf(campaignDetailPage.overviewPanel.getData("Defendants Count"));
        int activeDefendants = totalDefendants - terminatedDefendants;
        to(chinesePRBDetailPage, "5013564");
        chinesePRBDetailPage.applyDefendantStatusFilter(status);
        chinesePRBDetailPage.timeLinechart.waitUntilVisible();
        int available_Timelines_Count = chinesePRBDetailPage.timeLinechartBar.count();
        verifyStatus(status, totalDefendants, activeDefendants, terminatedDefendants, available_Timelines_Count);
    }

    @DataProvider(name = "status")
    public Object[][] getStatus() {
        return new Object[][]{{"Active"}, {"Inactive"}, {"All"}};
    }

    private void verifyStatus(String status, int totalDefendants,
                              int activeDefendants, int terminatedDefendants, int available_Timelines_Count) throws Exception {
        switch (status) {
            case "Active":
                softAssert.assertTrue(chinesePRBDetailPage.notimeLinechartBar.isDisplayed());
                break;
            case "Inactive":
                assertEquals(chinesePRBDetailPage.timeLinechartBar.getAttribute("fill"), "#76c5ff",
                        "Inactive cases are not displayed in grey");
                assertEquals(available_Timelines_Count, terminatedDefendants, "Expected Inactive defendants as per Campaign Overview Metrics:" + terminatedDefendants + ", Actual available defendants in Timeline when we set defendants status as" + status + " :" + chinesePRBDetailPage.defendantsInTimelineChart.count());
                break;
            case "All":
                assertEquals(available_Timelines_Count, totalDefendants, "Expected all defendants as per Campaign Overview Metrics:" + totalDefendants + ", Actual available defendants in Timeline when we set defendants status as" + status + " :" + chinesePRBDetailPage.defendantsInTimelineChart.count());
                break;
        }

    }

    @Test(groups = "P2", description = "Show PRB Decsision date on campaign timeline")
    public void verifyNoticeOfAppealInEventFilterPRBTimeLine() throws Exception {
        to(chinesePRBDetailPage, "5013564");
        chinesePRBDetailPage.clearFilters();
        chinesePRBDetailPage.applyDefendantEventFilter("Decision Date");
        com.rpxcorp.testcore.Assert.isEquals(chinesePRBDetailPage.defendant_timeline_active_top_marker.getAllData(), new String[]{"DD"});
        com.rpxcorp.testcore.Assert.isEquals(chinesePRBDetailPage.defendant_timeline_inactive_top_marker.getAllData(), new String[]{"C", "D", "PP", "PID", "M"});
        assertEquals(chinesePRBDetailPage.timeLinechartBar.count(), 1);
    }

    @Test(groups = "P2", description = "Show PRB Decsision date on campaign timeline")
    public void verifyPRBNoticeOfAppealTooltip() throws Exception {
        to(chinesePRBDetailPage, "5013564");
        chinesePRBDetailPage.clearFilters();
        chinesePRBDetailPage.decisionDateMarker.moveTo();
        chinesePRBDetailPage.decisionDateTooltip.waitUntilVisible();
        assertEquals(chinesePRBDetailPage.markerToolTipHeader.getText(), "Decision Date");
        String toolTipDetail = chinesePRBDetailPage.markerToolTipDetail.getText();
        assertTrue(toolTipDetail.contains("12/08/2015"), "Expected value is not displayed");
        assertTrue(toolTipDetail.contains("27742"), "Expected value is not displayed");
    }
}