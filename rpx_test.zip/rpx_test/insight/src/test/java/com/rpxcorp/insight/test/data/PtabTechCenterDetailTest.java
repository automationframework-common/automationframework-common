package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.detail.PtabJudgeDetailPage;
import com.rpxcorp.insight.page.detail.PtabTechCenterPage;
import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

@Authenticate(role = "MEMBER")
public class PtabTechCenterDetailTest extends BaseDataTest{

    PtabTechCenterPage ptabTechCenterPage;

    /* TEST CONFIGURATIONS */
    @Factory(dataProvider = "returnData")
    public PtabTechCenterDetailTest(String dataDescription, String ptabJudId) {
        this.dataDescription = dataDescription;
        this.dataId = ptabJudId;
    }

    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("PtabTechCenterdetail");
    }

    @BeforeClass
    public void loadPage() {
        this.urlData.put("ID", dataId);
        this.dataUrl = ptabTechCenterPage.getDeclaredUrl(urlData);
        to(ptabTechCenterPage, urlData);
    }

  //  @Test(description = "Verify Title", priority = 1)
    public void verifyTitle() throws Exception {
        assertEquals(ptabTechCenterPage.detailPageTitle.getData(),
                sqlProcessor.getSinglResultValue("PtabTechCenterdetail.TITLE", dataId));
    }

    @Test(description = "Verify Stats bar counts", priority = 1)
    public void verifyStatsBar() throws Exception {
        assertEquals(ptabTechCenterPage.techCenterStats.getData(),
                sqlProcessor.getResultData("PtabTechCenterdetail.STATS_DETAILS", dataId));
    }

    @Test(description = "Verify petitions information in petition table",dataProvider = "petitionsSortData",priority = 2)
    public void verifyPetitionsTable(String filter,String query) throws Exception {
        ptabTechCenterPage.petitionsTable.waitUntilVisible();
        ptabTechCenterPage.petitionCostsByStageCostTypeRadio.selectById(filter);
        ptabTechCenterPage.waitForLoading();
        assertEquals(ptabTechCenterPage.petitionsTable.getData(),
                sqlProcessor.getResultData(query, dataId));
    }

    @DataProvider
    public Object[][] petitionsSortData() {
        return new Object[][] {
                                { "active-case-type", "PtabTechCenterdetail.PETITIONS_ACTIVE"},
                                { "all-case-type", "PtabTechCenterdetail.PETITIONS_ALL" },
                                { "inactive-case-type", "PtabTechCenterdetail.PETITIONS_IN_ACTIVE"}
     };
    }

    @Test(description = "Verify Recent Activities", priority = 3)
    public void Recent_Activity() throws Exception {
        assertEquals(ptabTechCenterPage.recentActivity.getData(),
                sqlProcessor.getResultData("PtabTechCenterdetail.RECENT_ACTIVITY", dataId));
    }

}
