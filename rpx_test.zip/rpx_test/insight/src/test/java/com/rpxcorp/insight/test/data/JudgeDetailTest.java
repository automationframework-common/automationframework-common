package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.detail.JudgeDetailPage;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.TableData;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
@Authenticate(role = "MEMBER")
public class JudgeDetailTest extends BaseDataTest {
    JudgeDetailPage judgeDetailsPage;
    TableData tableData;
    Map<String, String> staticData;
    HashMap<String, TableData> subData = new HashMap<String, TableData>();
    ResultSet resultSet;

    @Factory(dataProvider = "returnData")
    public JudgeDetailTest(String dataDescription, String judgeID) {
        this.dataId = judgeID;
        this.dataDescription = dataDescription;
    }

    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("JudgeDetail");
    }

    @BeforeClass
    public void loadPage() {
        urlData.put("ID", dataId);
        this.dataUrl = judgeDetailsPage.getDeclaredUrl(urlData);
        to(judgeDetailsPage, urlData);
    }

    @Test(description = "Verify Title", priority = 1)
    public void Verify_Title() throws Exception {
        assertEquals(judgeDetailsPage.pageTitle.getData(), sqlProcessor.getResultData("JudgeDetail.TITLE", dataId),
                "title");
    }

    @Test(description = "Verify Active Cases associated to Judge", priority = 2)
    public void Verify_Active_Cases() throws Exception {
        staticData = judgeDetailsPage.judge_Detail.getData();
        assertEquals(staticData.get("Active Case"),
                sqlProcessor.getResultCount("JudgeDetail.LITIGATIONS_ACTIVE", dataId), "active_cases");

    }

    @Test(description = "Verify InActive cases associated to Judge", priority = 3)
    public void Verify_InActive_Cases() throws Exception {
        assertEquals(staticData.get("Inactive Case"),
                sqlProcessor.getResultCount("JudgeDetail.LITIGATIONS_INACTIVE", dataId), "inactive_cases");
    }

    @Test(description = "Verify Average cases per year for the Judge", priority = 4)
    public void Verify_Average_Cases_Per_Year() throws Exception {
        assertEquals(staticData.get("Average Cases per Year"),
                sqlProcessor.getResultData("JudgeDetail.AVERAGE_CASES_PER_YEAR", dataId), "average_cases_per_year");
    }

    @Test(description = "Verify Average case length for the Judge", priority = 5)
    public void Verify_Average_Case_Length() throws Exception {
        assertEquals(staticData.get("Average Case Length"),
                sqlProcessor.getResultData("JudgeDetail.AVERAGE_CASE_LENGTH", dataId),
                "average_length_of_case_in_days");
    }

    @Test(description = "Verify Cases by Market Sector section", priority = 6)
    public void Verfiy_Cases_By_Market_Sector() throws Exception {
        assertEquals(judgeDetailsPage.cases_By_Market_Sector.getData(),
                sqlProcessor.getResultData("JudgeDetail.CASES_BY_MARKET_SECTOR", dataId));
    }

    @Test(description = "Verify Litigation Section for All Cases", priority = 7)
    public void Verify_Litigation_Section_All() throws Exception {
        assertEquals(judgeDetailsPage.litigation_Section.getData(),
                sqlProcessor.getResultData("JudgeDetail.LITIGATIONS_ALL", dataId));
    }

    @Test(description = "Verify Litigation Section for Active Cases", priority = 8)
    public void Verify_Litigation_Section_Active() throws Exception {
        judgeDetailsPage.click_active_filter_lits();
        assertEquals(judgeDetailsPage.litigation_Section.getData(),
                sqlProcessor.getResultData("JudgeDetail.LITIGATIONS_ACTIVE", dataId));
    }

    @Test(description = "Verify Litigation Section for Inactive Cases", priority = 9)
    public void Verify_Litigation_Section_InActive() throws Exception {
        judgeDetailsPage.click_inactive_filter_lits();
        assertEquals(judgeDetailsPage.litigation_Section.getData(),
                sqlProcessor.getResultData("JudgeDetail.LITIGATIONS_INACTIVE", dataId));
    }

    @Test(description = "Verify Orders Outcome table", priority = 9)
    public void orders_outcome() throws Exception {
        assertEquals(judgeDetailsPage.ORDERS_OUTCOME.getData(),
                sqlProcessor.getResultData("JudgeDetail.ORDER_OUTCOME", dataId));
    }

    @Test(description = "Verify Order Table - ", dataProvider = "orderText", priority = 10)
    public void Verify_Orders(String orderType, String outcome, String query) throws Exception {
        judgeDetailsPage.viewOrdersTable(orderType, outcome);
        TableData orders_table = judgeDetailsPage.judge_orders_table.getData();
        subData.put(orderType + "_" + outcome, judgeDetailsPage.judge_orders_table.getPopupSubtableData());
        judgeDetailsPage.closePopup();       
        assertEquals(orders_table, sqlProcessor.getResultData("JudgeDetail.ORDER_" + query, dataId));
        assertEquals(subData.get(orderType + "_" + outcome),
                sqlProcessor.getResultData("JudgeDetail.ORDERS_SUBTABLE_" + query, dataId));
    }

    //@Test(description = "Verify Order Sub Table - ", dataProvider = "orderText", priority = 11)
    public void Verify_Orders_Sub_Table(String orderType, String outcome, String query) throws Exception {
        assertEquals(subData.get(orderType + "_" + outcome),
                sqlProcessor.getResultData("JudgeDetail.ORDERS_SUBTABLE_" + query, dataId));
    }

    //@Test(description = "Verify Verdicts Table- ", dataProvider = "verdictText", priority = 12)
    public void Verify_Verdicts(String verdictType, String query) throws Exception {
        judgeDetailsPage.clickOnVerdictOutcome(verdictType);
        TableData orders_table = judgeDetailsPage.judge_verdicts_table.getData();
        judgeDetailsPage.closeVerdictPopup();
        assertEquals(orders_table, sqlProcessor.getResultData("JudgeDetail.VERDICTS_" + query, dataId));
    }

    // @Test(description = "Verify Verdicts Sub Table -",
    // dataProvider="verdictText", priority = 13)
    public void Verify_Verdicts_Sub_Table(String verdictType, String query) throws Exception {
        assertEquals(subData.get(verdictType),
                sqlProcessor.getResultData("JudgeDetail.VERDICTS_SUBTABLE_" + query, dataId));
    }

    @DataProvider(name = "orderText")
    public Object[][] orderText() {
        return new Object[][] { { "Preliminary Injunction", "", "Preliminary_Injunction" }, { "Preliminary Injunction", "Granted", "Preliminary_Injunction_GRANTED" },
                { "Preliminary Injunction", "Denied", "Preliminary_Injunction_DENIED" }, { "Preliminary Injunction", "Partial", "Preliminary_Injunction_PARTIAL" },
                { "Permanent Injunction", "", "Permanent_Injunction" }, { "Permanent Injunction", "Granted", "Permanent_Injunction_GRANTED" }, { "Permanent Injunction", "Denied", "Permanent_Injunction_DENIED" },
                { "Permanent Injunction", "Partial", "Permanent_Injunction_PARTIAL" }, { "Summary judgment", "", "SUMMARY_JUDGEMENT" },
                { "Summary judgment", "Granted", "SUMMARY_JUDGEMENT_GRANTED" },
                { "Summary judgment", "Denied", "SUMMARY_JUDGEMENT_DENIED" },
                { "Summary judgment", "Partial", "SUMMARY_JUDGEMENT_PARTIAL" }, { "JMOL", "", "JMOL" },
                { "JMOL", "Granted", "JMOL_GRANTED" }, { "JMOL", "Denied", "JMOL_DENIED" },
                { "JMOL", "Partial", "JMOL_PARTIAL" } };
    }

    @DataProvider(name = "verdictText")
    public Object[][] verdictText() {
        return new Object[][] { { "PLAINTIFF PATENTEE", "PLAINTIFF_PATENTEE" },
                { "PLAINTIFF NON PATENTEE", "PLAINTIFF_NON_PATENTEE" }, { "DEFENDANT PATENTEE", "DEFENDANT_PATENTEE" },
                { "UNAVAILABLE", "UNAVAILABLE" } };
    }

    @Test(description = "Verify Recent Activities", priority = 14)
    public void Recent_Activity() throws Exception {
        assertEquals(judgeDetailsPage.recentActivity.getData(),
                sqlProcessor.getResultData("JudgeDetail.RECENT_ACTIVITY", dataId));
    }
}