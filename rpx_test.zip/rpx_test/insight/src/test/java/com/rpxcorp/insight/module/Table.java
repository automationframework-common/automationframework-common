package com.rpxcorp.insight.module;

import com.rpxcorp.testcore.TableData;
import com.rpxcorp.testcore.element.Element;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Table extends Element {
    Element activationlink;
    Element viewAllLink;
    Element viewMoreLink;
    Element firstPage;
    Element nextPage;
    Element lastPage;
    Element previous;
    Element next;
    Element selectedPage;
    Element displayedRecords;
    Element hiddenRecords;
    Element viewLesslink;
    Element tdViewAllLink;
    String uniqueId;
    List<String> header = new ArrayList<String>();
    String rowSelector;
    List<String> columns = new ArrayList<String>();
    Table subTable;
    String expandSubTableLink;
    StringBuffer subTableHtml = new StringBuffer();
	private String subtableSelectorString;

    public Table(By locator) {
        super(locator);
    }

    public Table(String selector) {
        super(selector);
    }

	public void activationlink(String selector) {
        this.activationlink = new Element(selector);
    }

    public void expandSubTableLink(String expandSubTableLink) {
        this.expandSubTableLink = expandSubTableLink;
    }

    public void viewAllLink(String selector) {
        this.viewAllLink = new Element(selector);
    }

    public void viewAllLink(By by) {
        this.viewAllLink = new Element(by);
    }

    public Element viewAllLink() {
        return this.viewAllLink;
    }
    
    public void viewMoreLink(String selector) {
        this.viewMoreLink = new Element(selector);
    }

    public void viewMoreLink(By by) {
        this.viewMoreLink = new Element(by);
    }

    public Element viewMoreLink() {
        return this.viewMoreLink;
    }

    public void viewLessLink(By by) {
        this.viewLesslink = new Element(by);
    }
    
    public void viewLessLink(String selector) {
        this.viewLesslink = new Element(selector);
    }
    
    public void tdViewAllLink(By by) {
        this.tdViewAllLink = new Element(by);
    }
    public Element viewLessLink() {
        return this.viewLesslink;
    }

    public void displayedRecords(String selector) {
        this.displayedRecords = new Element(selector);
    }

    public Element displayedRecords() {
        return displayedRecords;
    }

    public void hiddenRecords(String selector) {
        this.hiddenRecords = new Element(selector);
    }

    public Element hiddenRecords() {
        return hiddenRecords;
    }

    public void uniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    public void row(String rowSelector) {
        this.rowSelector = rowSelector;
    }

    public void column(String key, String value) {
        this.header.add(key);
        this.columns.add(value);
    }

    public void column(List<String> keyList, List<String> valueList) {
        this.header = keyList;
        this.columns = valueList;
    }
    
    public Element columnLink(String columnName) {
        String columnSelector = columns.get(header.indexOf(columnName));
        if (!columnSelector.endsWith("a")) {
            columnSelector = columnSelector + " a";
        }
        return new Element(columnSelector);
    }
    
    public Element tdCssWithViewAllLink(String columnName, Table table) {    	
    	viewAll();    	
        int noOfRows=tdViewAllLink.count();
		for (int i = 1; i <= noOfRows; i++) {			
			if (table.$("tr:nth-of-type("+i+") "+tdViewAllLink.getSelectorString()+" a.view-all").isDisplayed()){
				 return new Element(table.$("tr:nth-of-type("+i+") "+tdViewAllLink.getSelectorString()).getSelectorString().trim());		 
			}
		}
		return null;
    }
    
    public Element getFirstlinkFromColumn(int columnIndex) {    	
    	return $("tbody td:nth-of-type(" + columnIndex + ") a:not([class*='span_left'])");
    }
    
    public void prevoius(String selector) {
        this.previous = new Element(selector);
    }

    public void next(String selector) {
        this.next = new Element(selector);
    }

    public void selectedPage(String selector) {
        this.selectedPage = new Element(selector);
    }

    public void firstPage(String selector) {
        this.firstPage = new Element(selector);
    }

    public void nextPage(String selector) {
        this.nextPage = new Element(selector);
    }

    public void lastPage(String selector) {
        this.lastPage = new Element(selector);
    }

    public void subTable(Table table) {
        this.subTable = table;
        this.subtableSelectorString=subTable.getSelectorString();
        table.updateSelector(this.getSelectorString()+" "+subtableSelectorString);
    }

	public Table subtable() {
        return this.subTable;
    }
    
    public Element prevoius() {
        return this.previous;
    }

    public Element next() {
        return this.next;
    }

    public TableData getData() {
        return getData(-1);
    }

    public List<String> getUniqueId_Values() {
        return getUniqueId_Values(-1);
    }

    public TableData getData(int rowCount) {
        if (activationlink != null) {
            if (isPresent() == false) {
                activationlink.click();
                loading();
            }
        }
        if (viewAllLink != null) {
            viewAll();
        }
        TableType table = getTableType();
        switch (table) {
        case CUSTOM:
            return getCustomTableData(rowCount);
        case NODATA:
            subTableHtml.setLength(0);
            return new TableData();
        case PAGINATED:
            return getPaginatedTableData(table);
        default:
            Document doc = table.getDoc(getInnerHtml());
            Elements headerElement = doc.select(table.getHeaderSelector());
            Elements rowElements = doc.select(table.getRowSelector());
            subTableHtml.setLength(0);
            if (uniqueId != null) {
                if (uniqueId.contains("data-nested-tableurl")) {
                    headerElement.get(0).addClass("Placeholder");
                    headerElement.get(0).append("<span class=\"group_header_text\">Placeholder</span>");
                }
            }
            if (subTable != null) {
                expandSubTable();
                subTableHtml.append(table.getDoc(getInnerHtml()));
            }
            return new TableData(getHeader(headerElement), getBodyData(headerElement, rowElements, rowCount));
        }
    }

    // TODO ENHANCE FOR CUSTOM AND SCROLLED SUB TABLE TYPE
    public TableData getPaginatedTableData(TableType table) {
        Document doc = table.getDoc(getInnerHtml());
        HashMap<String, String[]> data = new HashMap<String, String[]>();
        Elements headerElement = doc.select(table.getHeaderSelector());
        if (uniqueId != null) {
            if (uniqueId.contains("data-nested-tableurl")) {
                headerElement.get(0).addClass("Placeholder");
                headerElement.get(0).append("<span class=\"group_header_text\">Placeholder</span>");
            }
        }
        StringBuffer tableHtml = new StringBuffer();
        subTableHtml.setLength(0);
        int size = Integer.parseInt(lastPage.getText());
        for (int i = 0; i < size; i++) {
            tableHtml.append(table.getDoc(getInnerHtml()));
            if (subTable != null) {
                expandSubTable();
                subTableHtml.append(table.getDoc(getInnerHtml()));
            }
            nextPage.click();
            loading();
        }
        doc = Jsoup.parse(tableHtml.toString());
        if (rowSelector == null) {
            rowSelector = table.getRowSelector();
        }
        Elements rowElements = doc.select(rowSelector);
        data.putAll(getBodyData(headerElement, rowElements, -1));
        return new TableData(getHeader(headerElement), data);
    }

    // Added method to get Subtable Element for Paginated HTML Page converted to
    // a String buffer
    public TableData getPopupSubtableData() {
        TableData tabledata = new TableData();
        if (subTableHtml.toString().contains("nested_inner_table")) {
            TableType table = getTableType();
            Document doc = (subTableHtml.length() == 0) ? table.getDoc(getInnerHtml())
                    : table.getDoc(subTableHtml.toString());
            HashMap<String, String[]> subTableData = new HashMap<String, String[]>();
            if (uniqueId.contains("data-nested-tableurl"))
                rowSelector = "tr:has(.nested_inner_table)";
            else if (rowSelector == null)
                rowSelector = "table>tbody>tr[class]";
            Elements tableElements = doc.select(rowSelector);
            Elements parentRowElements = new Elements();
            for (org.jsoup.nodes.Element e : tableElements) {
                parentRowElements.add(e.previousElementSibling());
            }
            if (parentRowElements.size() > 0) {
                Elements subData = doc.select(this.subtableSelectorString);
                Elements subHeader = subData.get(0).select("th");
                for (int row = 0; row < parentRowElements.size(); row++) {
                    String key = (uniqueId == null) ? Integer.toString(row)
                            : getUniqueId(parentRowElements.get(row), uniqueId);
                    Elements rowElements = subData.get(row).select("tbody>tr");
                    subTableData.putAll(subTable.getBodyData(subHeader, rowElements, -1, key));
                }
                tabledata.setHeader(getHeader(subHeader));
                tabledata.setData(subTableData);
            }
        }
        rowSelector = null;
        return tabledata;
    }

    // TODO Enhance to support custom and scrolled sub table type
    public TableData getSubtableData() {
        TableData tabledata = new TableData();
        if (isPresent() == true) {
            TableType table = getTableType();
            Document doc = table.getDoc(getInnerHtml());
            HashMap<String, String[]> data = new HashMap<String, String[]>();
            if (rowSelector == null)
                rowSelector = "table>tbody>tr[class]";
            Elements parentRowElements = doc.select(rowSelector);
            if (parentRowElements.size() > 0) {
                Elements subTableData = doc.select(this.subtableSelectorString);
                Elements headerElement = subTableData.get(0).select("th");
                for (int row = 0; row < parentRowElements.size(); row++) {
                    String key = (uniqueId == null) ? Integer.toString(row)
                            : getUniqueId(parentRowElements.get(row), uniqueId);
                    Elements rowElements = subTableData.get(row).select("tbody>tr");
                    data.putAll(subTable.getBodyData(headerElement, rowElements, -1, key));
                }
                tabledata.setHeader(getHeader(headerElement));
                tabledata.setData(data);
            }
        }
        return tabledata;
    }

    public TableData getCustomTableData(int rowCount) {
    	Document doc = Jsoup.parse(getInnerHtml());
    	HashMap<String, String[]> data = new HashMap<String, String[]>(); 
    	
    	 Elements uniqueIds = null;
    	 if (uniqueId != null && !uniqueId.contains(";")) {
    		 uniqueIds = doc.select(uniqueId);
    	 }
    	for (int col = 0; col < header.size(); col++) {
            String colSelector = columns.get(col);
            String condition=null;
            if(colSelector.contains("|")){
                String[] colSelectors = colSelector.split("\\|", 2);
                colSelector=colSelectors[0];
                condition=colSelectors[1];
            }
    		Elements elements = doc.select(colSelector.trim());
    		int rowSize = (rowCount <= elements.size()) && rowCount != -1 ? rowCount : elements.size();
    		for (int row = 0; row < rowSize; row++) {  
    			String key = "";
    			if(uniqueId!=null) {
                    if (uniqueId.contains(";")) {
                        key = (uniqueId == null) ? Integer.toString(row) : getUniqueId(elements.get(row), uniqueId);
                    } else {
                        key = (uniqueIds == null) ? Integer.toString(row) : getUniqueId(uniqueIds.get(row));
                    }
                }else {
                    key=Integer.toString(row);
                }
                String value="";
                org.jsoup.nodes.Element element = elements.get(row);
                if(condition !=null){
                    String[] conditions = condition.split("\\?", 2);
                    String[] values=conditions[1].split(":",2);
                    int trueIndex = element.select(conditions[0]).size() > 0 ? 0 : 1;
                    if(!values[trueIndex].contains("text()")){
                        value=values[trueIndex];
                    }else {
                        value=normalizeHtmlcode(element.text());
                    }
                }else{
                    value=normalizeHtmlcode(element.text());
                }

    			if (data.containsKey(key)) {
    				data.get(key)[col] = value;
    			} else {
    				String[] newData = new String[header.size()];
    				newData[0] = value;
    				data.put(key, newData);
    			}
    		}
    	}
    	return new TableData(header.toArray(new String[header.size()]), data);
    }

    private String getUniqueId(org.jsoup.nodes.Element rowElement) {

        if (uniqueId.contains("data-nested-tableurl")) {
            String href = rowElement.attr("data-nested-tableurl");
            if (!(href == null || href.isEmpty())) {
                Pattern pattern = Pattern.compile("\\?(.*?)\\&");
                Matcher matcher = pattern.matcher(href);
                if (matcher.find()) {
                    href = matcher.group(0).replaceAll("\\D+", "");
                }
                return href;
            }
            return normalizeHtmlcode(rowElement.text());
        } else {
            String href = rowElement.attr("href");
            if (!(href == null || href.isEmpty())) {
                return href.replaceFirst(".*/((\\d+)|(\\w+(-\\d\\d+)?)|(\\w+))(-|\\?|).*", "$1");
            }
            if(rowElement.text().contains(",")) {
                return normalizeHtmlcode(rowElement.text().replaceAll("[,;\\s]", ""));
            }
            return normalizeHtmlcode(rowElement.text());
        }
    }

    public List<String> getUniqueId_Values(int rowCount) {
        Document doc = Jsoup.parse(getInnerHtml());
        Elements uniqueIds = null;
        if (uniqueId != null) {
            uniqueIds = doc.select(uniqueId);
        }
        int rowSize = (rowCount <= uniqueIds.size()) && rowCount != -1 ? rowCount : uniqueIds.size();
        List<String> data = new ArrayList<String>();
        for (int row = 0; row < rowSize; row++) {
            data.add(getUniqueId(uniqueIds.get(row)));
        }
        return data;
    }

    private String normalizeHtmlcode(String value) {
        value = value.replaceAll("\u201c", "\"");
        value = value.replaceAll("\u201d", "\"");
        value = value.replaceAll("\u00A9", " ");
        return value = value.replaceAll("[^\\x00-\\x7F]", " ");
    }

    private String getUniqueId(org.jsoup.nodes.Element rowElement, String uniqueId) {
        String[] uniqueIds = uniqueId.split(";");
        String key = "";
        for (String unique_id : uniqueIds) {
            if (rowElement.select(unique_id.trim()).size() == 0)
                throw new Error("Not able to find Unique id element for locator '"+unique_id+"' in the below html \n"+rowElement.html());
            key = key + getUniqueId(rowElement.select(unique_id.trim()).get(0));

        }
        return key;
    }

    private String[] getHeader(Elements headerElement) {
        ArrayList<String> header = new ArrayList<String>();
        for (int i = 0; i < headerElement.size(); i++) {
            String value = normalizeHtmlcode(headerElement.get(i).text());
            if (!value.replaceAll(" ", "").trim().isEmpty()) {
                value = value.replaceAll("[^a-zA-Z0-9 ]+", "").toLowerCase();
                value = value.trim().replaceAll(" ", "_");
                header.add(value);
            }
        }
        return header.toArray(new String[header.size()]);
    }

    public String[] getHeaderData() {
        TableType table = getTableType();
        Document doc = table.getDoc(getInnerHtml());
        Elements headerElement = doc.select(table.getHeaderSelector());
        ArrayList<String> header = new ArrayList<String>();
        for (int i = 0; i < headerElement.size(); i++) {
            String value = normalizeHtmlcode(headerElement.get(i).text());
            if (!value.replaceAll(" ", "").trim().isEmpty())
                header.add(value);
        }
        return header.toArray(new String[header.size()]);
    }

    private int getColumnIndex(String columnName, Elements headerElement) {
        for (int i = 0; i < headerElement.size(); i++) {
            if (normalizeHtmlcode(headerElement.get(i).text()).toUpperCase().startsWith(columnName.toUpperCase()))
                return i;
        }
        return -1;
    }

    public int getColumnIndex(String columnName, String selector) {    	
        ArrayList<String> headerElement = new Element(getSelectorString() + " th").getAllData();
        for (int i = 0; i < headerElement.size(); i++) {
            if (normalizeHtmlcode(headerElement.get(i)).toUpperCase().startsWith(columnName.toUpperCase()))
                return i + 1;
        }
        return -1;
    }

    private HashMap<String, String[]> getBodyData(Elements headerElement, Elements rowElements, int rowCount) {
        return getBodyData(headerElement, rowElements, rowCount, null);
    }

    private HashMap<String, String[]> getBodyData(Elements headerElement, Elements rowElements, int rowCount,
            String keyPrefix) {
        if (rowElements.select("td[rowspan]").size() > 0) {
            return getGroupedBodyData(headerElement, rowElements, rowCount, keyPrefix);
        } else {
            return getRegularBodyData(headerElement, rowElements, rowCount, keyPrefix);
        }
    }

    private HashMap<String, String[]> getRegularBodyData(Elements headerElement, Elements rowElements, int rowCount,
            String keyPrefix) {
        HashMap<String, String[]> data = new HashMap<String, String[]>();
        int rowSize = (rowCount <= rowElements.size()) && rowCount != -1 ? rowCount : rowElements.size();
        for (int row = 0; row < rowSize; row++) {
            String key = (uniqueId == null) ? Integer.toString(row) : getUniqueId(rowElements.get(row), uniqueId);
            if (keyPrefix != null)
                key = keyPrefix + "_" + key;
            data.put(key, getRowData(row, headerElement.size(), rowElements));
        }
        return data;
    }

    private String[] getRowData(int row, int colSize, Elements rowElements) {
        String[] rowData = new String[colSize];
        int col = 0;
        for (org.jsoup.nodes.Element colElement : rowElements.get(row).children()) {
            Elements anchors = colElement.select("a");
            Elements onclick_tooltip_content = colElement.select("span span.blue");
            if (anchors.size() < 1) {
                rowData[col] = normalizeHtmlcode(colElement.text());
            } else if (onclick_tooltip_content.size() >= 1) {
                for (org.jsoup.nodes.Element element : onclick_tooltip_content) {
                    Document doc = Jsoup.parse(element.attr("data-ot-content"));
                    rowData[col] = normalizeHtmlcode(doc.select("div.main-body ul li").text());
                }
            } else {
                String dataValue = "";
                for (org.jsoup.nodes.Element element : anchors) {
                    dataValue = dataValue + ";" + element.text();
                }
                rowData[col] = normalizeHtmlcode(dataValue.substring(1));
            }
            col++;
        }
        return rowData;
    }

    private List<String> getColumnData(int columnIndex, Elements rowElements) {
        List<String> colData = new ArrayList<String>();        
        for (org.jsoup.nodes.Element rowElement : rowElements) {
            colData.add(normalizeHtmlcode(rowElement.child(columnIndex).text()));
        }
        return colData;
    }

    public List<String> getDistinctColumnData(String columnName) {
        Set<String> uniqueData = new HashSet<String>(getColumn(columnName));
        List<String> uniqueColumnData = new ArrayList<String>(uniqueData);
        Collections.sort(uniqueColumnData);
        return uniqueColumnData;
    }

    private HashMap<String, String[]> getGroupedBodyData(Elements headerElement, Elements rowElements, int rowCount,
            String keyPrefix) {
        HashMap<String, String[]> data = new HashMap<String, String[]>();
        int rowSize = (rowCount <= rowElements.size()) && rowCount != -1 ? rowCount : rowElements.size();
        HashMap<Integer, String> groupedColValue = new HashMap<Integer, String>();
        HashMap<Integer, Integer> groupedColSpan = new HashMap<Integer, Integer>();
        for (int row = 0; row < rowSize; row++) {
            String[] rowData = new String[headerElement.size()];
            Elements colElements = rowElements.get(row).children();
            int insertedCount = 0;
            for (int col = 0; col < rowData.length; col++) {
                String colVal;
                if (groupedColSpan.containsKey(col)) {
                    Integer spanCount = groupedColSpan.get(col);
                    colVal = groupedColValue.get(col);
                    insertedCount++;
                    spanCount--;
                    if (spanCount == 1) {
                        groupedColSpan.remove(col);
                        groupedColValue.remove(col);
                    } else {
                        groupedColSpan.put(col, spanCount);
                    }
                } else {
                    colVal = colElements.get(col - insertedCount).text();
                    // assert rowspan details
                    String rowspan = colElements.get(col - insertedCount).attr("rowspan");
                    if (!(rowspan == null || rowspan.isEmpty() || rowspan.equals("1"))) {
                        groupedColSpan.put(col, Integer.parseInt(rowspan));
                        groupedColValue.put(col, colVal);
                    }
                }
                rowData[col] = normalizeHtmlcode(colVal);
            }
            String key = (uniqueId == null) ? Integer.toString(row) : getUniqueId(rowElements.get(row), uniqueId);
            if (keyPrefix != null)
                key = keyPrefix + "_" + key;
            data.put(key, rowData);
        }
        return data;
    }

    private TableType getTableType() {
        if (isPresent() == true) {
            if (columns.size() > 0) {
                return TableType.CUSTOM;
            } else if (new Element(By.cssSelector(".dataTables_scroll")).isPresent()) {

                return TableType.SCROLLED;
            } else if (nextPage != null) {
                if (nextPage.isPresent())
                    return TableType.PAGINATED;
                else
                    return TableType.DEFAULT;
            } else {
                return TableType.DEFAULT;
            }
        }
        return TableType.NODATA;
    }

    // Temporary Implementation for sorting and also for sub child element
    // handling
    // TODO Need to add proper solution
    public void sort(int col) {
        new Element(getSelectorString() + " th:nth-child(" + col + ")").click();
    }

    public void sort(String columnName) throws Exception {
    	
        int index = getColumnIndex(columnName, getSelectorString());
        if (index == -1)
            throw new Exception("Column '" + columnName + "' not found");
        new Element(getSelectorString() + " th:nth-of-type(" + index + ")").click();
        loading();
    }
    
    public void sortColumn(String columnName) throws Exception {
    	
        int index = getColumnIndex(columnName, getSelectorString());
        if (index == -1)
            throw new Exception("Column '" + columnName + "' not found");
        new Element(getSelectorString() + " th:nth-of-type(" + index + ") a").click();
        loading();
    }

    public void sort(String columnName, String sortType) {
        String actualSortClass, expSortClass;
        if (sortType.equalsIgnoreCase("desc"))
            expSortClass = "down";
        else
            expSortClass = "up";

        int columnIndex = getColumnIndex(columnName, getSelectorString());
        actualSortClass = new Element(getSelectorString() + " th:nth-of-type(" + columnIndex + ") i")
                .getAttribute("class");
        if (!actualSortClass.contains(sortType) || !(actualSortClass.contains(expSortClass))) {
            for (int count = 1; count <= 2; count++) {
                new Element(getSelectorString() + " th:nth-of-type(" + getColumnIndex(columnName, getSelectorString())
                        + ")").click();
                loading();
                actualSortClass = new Element(getSelectorString() + " th:nth-of-type(" + columnIndex + ") i")
                        .getAttribute("class");
                if (actualSortClass.contains(sortType) || (actualSortClass.contains(expSortClass)))
                    break;
            }
        }
    }

    public Element getColumnLinkElem(String columnName) {
        return new Element(
                getSelectorString() + " td:nth-of-type(" + getColumnIndex(columnName, getSelectorString()) + ") a");
    }

    public Element getColumnHeaderElem(String columnName) {
        return new Element(
                getSelectorString() + " tr:nth-of-type(" + getColumnIndex(columnName, getSelectorString()) + ") th");
    }

    public String getColumnText(String columnName) {
        return new Element(
                getSelectorString() + " td:nth-of-type(" + getColumnIndex(columnName, getSelectorString()) + ")")
                .getText();
    }

    public String getColumnLinkText(String columnName) {
        return new Element(
                getSelectorString() + " td:nth-of-type(" + getColumnIndex(columnName, getSelectorString()) + ") a")
                        .getText();
    }

    public String getAttributeFromColumnLink(String columnName, String attributeName) {
        return new Element(
                getSelectorString() + " td:nth-of-type(" + getColumnIndex(columnName, getSelectorString()) + ") a")
                        .getAttribute(attributeName);
    }

    // Temporary Implementation for get row record
    // TODO make it generic
    public String[] getRows() {
        TableType table = getTableType();
        Document doc = table.getDoc(getInnerHtml());
        Elements rowElements = doc.select(table.getRowSelector());
        String[] data = new String[rowElements.size()];
        for (int i = 0; i < data.length; i++) {
            data[i] = normalizeHtmlcode(rowElements.get(i).text());
        }
        return data;
    }

    public List<String> getColumn(int columnIndex) {
        TableType table = getTableType();        
        Document doc = table.getDoc(getInnerHtml());
        Elements rowElements = doc.select(table.getRowSelector());
        return getColumnData(columnIndex, rowElements);
    }

    public List<String> getColumn(String columnName) {    	
        TableType table = getTableType();        
        Document doc = table.getDoc(getInnerHtml());
        switch (table) {
        case PAGINATED:
            return getColumnDataForAllPages(columnName);
        case CUSTOM:
            return getCustomColumnData(columnName, doc);
        default: {        	
            Elements rowElements = doc.select(table.getRowSelector());
            Elements headerElement = doc.select(table.getHeaderSelector());
            return getColumnData(getColumnIndex(columnName, headerElement), rowElements);
        }
        }
    }

    public List<String> getCustomColumnData(String columnName, Document doc) {
        List<String> colData = new ArrayList<String>();
        Elements colElements = doc.select(columns.get(header.indexOf(columnName)));
        for (org.jsoup.nodes.Element colElement : colElements) {
            colData.add(normalizeHtmlcode(colElement.text()));
        }
        return colData;
    }

    public String[] getUniqueIds() {
        TableType table = getTableType();
        Document doc = table.getDoc(getInnerHtml());
        Elements rowElements = doc.select(table.getRowSelector());
        String[] uniqueIds = new String[rowElements.size()];
        int row = 0;
        for (org.jsoup.nodes.Element element : rowElements) {
            uniqueIds[row] = getUniqueId(element, uniqueId);
            row++;
        }
        return uniqueIds;
    }

    /**
     * Read column data from all rows in all Pages of Table
     * 
     * @param columnName
     * @return
     * @author Prasanna
     */
    public List<String> getColumnDataForAllPages(String columnName) {
        TableType table = getTableType();
        Document doc = table.getDoc(getInnerHtml());
        Elements rowElements = null;
        Elements headerElement = doc.select(table.getHeaderSelector());
        int columnIndex = getColumnIndex(columnName, headerElement);
        List<String> colData = new ArrayList<String>();
        int size = Integer.parseInt(lastPage.getText());
        for (int i = 0; i < size; i++) {
            doc = table.getDoc(getInnerHtml());
            rowElements = doc.select(table.getRowSelector());
            for (org.jsoup.nodes.Element rowElement : rowElements) {
                colData.add(normalizeHtmlcode(rowElement.child(columnIndex).text()));
            }
            if(i!=size-1)
            nextPage.click();
            loading();

        }

        return colData;

    }

    /**
     * @author pusulurip
     */
    public void expandSubTable() {
    	try{
    	    if (!subTable.isDisplayed()) {
                JavascriptExecutor js = (JavascriptExecutor) getDriver();
                js.executeScript("$('" + expandSubTableLink + "').click();");
                loading();
                // subTable.waitUntilVisible();
            }
        }catch(Exception e) {
            System.out.println("Exception is" + e);
        }
    }

    public void viewAll() {
        if (viewAllLink != null) {
            if (viewAllLink.isDisplayed()) {
                viewAllLink.click();
                loading();
                waitForRequestInit();
                if (viewLesslink != null)
                    getWait().until(ExpectedConditions.elementToBeClickable(viewLesslink));
                //viewLesslink.waitUntilVisible();
            }
        }
    }

//    waitForRequestInit();
//    if (viewLesslink != null)
//    viewLesslink.waitUntilVisible(); // ToDo Add ViewLess CSS in
//    // all Tables

    public void viewLess() {
        if (viewLesslink.isDisplayed()) {
            viewLesslink.click();
            loading();
            waitForRequestInit();
            if (viewAllLink != null)
                getWait().until(ExpectedConditions.elementToBeClickable(viewAllLink));
        }
    }

    public void loading() {
        new Element(By.cssSelector(".blockUI.blockOverlay")).waitUntilInvisible();
        new Element(By.cssSelector(".blockUI.blockMsg.blockElement>img")).waitUntilNoElementPresent();
        new Element(By.cssSelector(".cms_content_loading")).waitUntilNoElementPresent();
    }

    public void clickOnNextInPagination() {
        this.next.click();
        loading();
    }

    public void clickOnPreviousInPagination() {
        this.previous.click();
        loading();
    }

    public void clickOnLastPageInPagination() {
        this.lastPage.click();
        loading();
    }

    public void clickOnFirstPageInPagination() {
        this.firstPage.click();
        loading();
    }

    public int getSelectedPageInPagination() {
        return this.selectedPage.getIntData();
    }

    public boolean isViewAllDisplayed() {
        return this.viewAllLink.isDisplayed();
    }

    public boolean isViewLessDisplayed() {
        return this.viewLesslink.isDisplayed();
    }

	public boolean waitforRow(String uniqueId) {
		TableType table = getTableType();
		boolean status = false;
		switch (table) {
		case PAGINATED:
			StringBuffer tableHtml = new StringBuffer();
			subTableHtml.setLength(0);
			int size = Integer.parseInt(lastPage.getText());
			for (int i = 0; i < size; i++) {
				tableHtml.append(table.getDoc(getInnerHtml()));
				JavascriptExecutor js = (JavascriptExecutor) getDriver();
				String jscript ="var element=$(\"" + table.getRowSelector() + ":has(" + this.uniqueId + "[href*=" + uniqueId + "])" + "\");" + "if(element.size() >0) {" + "return $(element.get(0)).is(':visible()')} else{" + "return false;" + "}";
				status = (boolean) js.executeScript(jscript);
				if (status == true) {
					break;
				}
				nextPage.click();
				loading();
			}
			return status;
		default:
	        return $(table.getRowSelector() + ":has(" + this.uniqueId + "[href*=" + uniqueId + "])").waitUntilVisible();
		}
	}

    public boolean waitForTextRow(String uniqueId) {
        TableType table = getTableType();
        return $(table.getRowSelector() + ":has(" + this.uniqueId + ":contains(" + uniqueId + "))").waitUntilVisible();
    }

    public void editRow(String uniqueId) {
        TableType table = getTableType();
        $(table.getRowSelector() + ":has(" + this.uniqueId + "[href*=" + uniqueId + "]) a[oldtitle='Edit']").click();
    }

    public void editTextRow(String uniqueId) {
        TableType table = getTableType();
        $(table.getRowSelector() + ":has(" + this.uniqueId + ":contains(" + uniqueId + ")) a[oldtitle='Edit']").click();
    }

    public void deleteRow(String uniqueId) {
        TableType table = getTableType();
        $(table.getRowSelector() + ":has(" + this.uniqueId + "[href*=" + uniqueId + "]) a[oldtitle='Delete']").click();

    }

    public void deleteTextRow(String uniqueId) {
        TableType table = getTableType();
        $(table.getRowSelector() + ":has(" + this.uniqueId + ":contains(" + uniqueId + ")) a[oldtitle='Delete']").click();

    }
}

enum TableType {
    CUSTOM, NODATA, DEFAULT("th", "tbody>tr", "", "<table>", "</table>"), PAGINATED("th", "tbody>tr", "", "<table>",
            "</table>"), SCROLLED(".dataTables_scrollHead th", ".dataTables_scrollBody tbody>tr", ".dataTables_scroll",
                    "", "");

    private String headerSelector = null;
    private String rowSelector = null;
    private String docSelector = "";
    private String docPrefix = "";
    private String docSufix = "";

    private TableType() {

    }

    private TableType(String headerSelector, String rowSelector, String docSelector, String docPrefix,
            String docSufix) {
        this.headerSelector = headerSelector;
        this.rowSelector = rowSelector;
        this.docPrefix = docPrefix;
        this.docSufix = docSufix;
    }

    public Document getDoc(String innerHtml) {
        return Jsoup.parse(docPrefix + innerHtml + docSufix);
    }

    public String getHeaderSelector() {
        return headerSelector;
    }

    public String getDocSelector() {
        return this.docSelector;
    }

    public String  getRowSelector() {
        return rowSelector;
    }

}
