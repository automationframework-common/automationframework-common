package com.rpxcorp.insight.page.advance_search;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;

public class AdvanceSearchHelpPage extends Page {

    public AdvanceSearchHelpPage() {
        this.url = new PageUrl("advanced_search/faq");
    }

    @Override
    public boolean at() {
        return faqs_list.waitUntilVisible();
    }

    public final Element faqs_list = $(".section_index");

}
