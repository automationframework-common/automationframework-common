package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.detail.ReexaminationDetailPage;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.TableData;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.sql.ResultSet;
import java.util.Map;

@Authenticate(role = "MEMBER")
@Test(groups = {"Lits","DistrictCourt"})
public class ReexaminationDetailTest extends BaseDataTest {
    ReexaminationDetailPage reexaminationDetailPage;
    TableData tableData;
    Map<String, String> staticData;
    ResultSet resultSet, accusedProducts;

    /* TEST CONFIGURATIONS */
    @Factory(dataProvider = "returnData")
    public ReexaminationDetailTest(String dataDescription, String litId) throws Exception {
        this.dataDescription = dataDescription;
        this.dataId = getPageId(litId);
    }

    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("ReexaminationDetail");
    }

    @BeforeClass
    public void loadPage() {
        this.urlData.put("ID", dataId);
        this.dataUrl = reexaminationDetailPage.getDeclaredUrl(urlData);
        to(reexaminationDetailPage, urlData);
    }

    @Test(description = "Verify Header Details")
    public void Header_Detail() throws Exception {
        assertEquals(reexaminationDetailPage.header_info.getData(),
                sqlProcessor.getResultData("ReexaminationDetail.HEADER_DETAILS", dataId));
    }

    @Test(description = "Verify Patent Owner Count")
    public void VerifyPatentOwnerMetricsCount() throws Exception {
        resultSet = sqlProcessor.getResultData("ReexaminationDetail.PATENT_OWNER_COUNT", dataId);
        assertEquals(reexaminationDetailPage.metricsSection.getIntData("patentownerCount"), sqlProcessor.getResultCount(resultSet));
    }

    @Test(description = "Verify Requester Count")
    public void VerifyRequesterMetricsCount() throws Exception {
        resultSet = sqlProcessor.getResultData("ReexaminationDetail.PATENT_OWNER_COUNT", dataId);
        assertEquals(reexaminationDetailPage.metricsSection.getIntData("patentownerCount"), sqlProcessor.getResultCount(resultSet));
    }

}