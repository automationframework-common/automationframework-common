package com.rpxcorp.insight.page.detail;

import com.rpxcorp.insight.module.ListPanel;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.insight.page.LoginPage.ROLES;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

public class SupremeCourtDetailPage extends BaseDetailPage {

    public SupremeCourtDetailPage() {
        this.url = new PageUrl("supreme-court/{ID}");
    }

    @Override
    public boolean at() {
        loading.waitUntilNoElementPresent();
        waitForPageLoad();
        return detailPageTitle.waitUntilVisible();
    }

    public final Tabs sectionTabs = $("#supreme-court-tab-container dl.tabs dd", Tabs.class);

    public final Element logo = $("#logo");
    //public final Element subTitle = $(".small-12.columns li:nth-child(1)");
    //public final Element filedDate = $(".small-12.columns li:nth-child(2)");
    public final Element share_link_btn = $("a[title='Share Link']");
    public final Element login_share_link_btn = $("a[title='Login Share Link']");
    public final Element viewComplaint_btn = $(By.xpath("//*[@id='content']//a[text()='View Complaint']"));
    public final Element alertMsg = $("#info .alert-box.sticky-alert");
    public final Element create_alert_btn = $("[data-track-action='create_alert']");
    public final Element create_alert_btn_Anonymous = $("ul.button-group a.disabled");
    public final Element alertDialog = $("#alert-modal .button");
    public final Element hourlyAlertRadioBtn = $("#alert-modal #alert_delivery_hourly");
    public final Element hourlyStaticToolTip = $("li[data-behavior='static_tooltip']");
    public final Element closeIconAlertsDialog = $("#alert-modal a.close-reveal-modal");
    public final Element ravelLink = $(".panel.overview .ravel_judge_link a");
    public final Element viewComplaintLink = $(".view-complaint-container .view-complaint-text");
    public final Element plaintiff_OutcomeStatus = $("#plaintiff_container .status");
    public final Element defendant_OutcomeStatus = $("#defendants_container .status");

    public String getComplaintNumber() {
        String complaintNumber = "";
        if (viewComplaintLink.isDisplayed()) {
            String url = viewComplaintLink.getAttribute("href");
            complaintNumber = url.substring(url.lastIndexOf('/') + 1).trim();
        }
        return complaintNumber;
    }

    public final Element complaintUnavailableBtn = $(".overview span:contains('Complaint Unavailable')");

    public void loadAlertModal() {
        if (create_alert_btn.isDisplayed()) {
            create_alert_btn.click();
            alertDialog.waitUntilVisible();
        }
    }

    public final StaticContent metricsSection = $(".panel-metrics", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("plaintiffCount", ".metrics_card:contains(Petitioner) .count");
                dataForm.content("defendantCount", ".metrics_card:contains(Respondent) .count");
                dataForm.content("accusedProductCount", ".metrics_card:contains(Patent in Suit) .count");
                dataForm.content("patentInSuitCount", ".metrics_card:contains(Docket Entries) .count");
                dataForm.content("docketEntriesCount", ".metrics_card:contains(Days In Litigation) .count");
            }
    );
    public final Element save_to_dashboard_btn = $(".button.save_litigation");
    public final Element news_title = $(".news_title");
    public final Element doc_unavailibity_notify_btn = $("#docket_entries .icon-cross.red");
    // added for role test temporally
    public final Element caseType_static = $("div.overview-items div.block-name:contains('Case Type')");
    public final Element courtBetaTag = $(
            ".small-8.columns.content .small-6.columns:nth-child(2) li:nth-child(1) .title.beta-feature");
    public final Element judgeBetaTag = $(
            ".small-8.columns.content .small-6.columns:nth-child(2) li:nth-child(2) .title.beta-feature");
    public final Element courtHyperLink = $(".small-6.columns:nth-child(2) .case-details li:nth-child(1) a");
    public final Element judgeHyperLink = $(".small-6.columns:nth-child(2) .case-details li:nth-child(2) a");
    public final Element courtWithoutHyperLink = $(".small-6.columns:nth-child(2) .case-details li:nth-child(1)");
    public final Element judgeWithoutHyperLink = $(".small-6.columns:nth-child(2) .case-details li:nth-child(2)");
    public final Element docketNumberText = $(".header-info.details li:nth-child(1)");
    public final Element docBlasterGreenTick = $(".icon-checkmark.green.float-right");
    public final Element docBlasterRedCross = $(".icon-cross.red");
    public final Element docBlasterDocType = $(".lit_doc_type");
    public final Element docBlasterUpload = $("#docket_entries .lit_doc_request");
    public final Element docBlasterUploadPopupDropDown = $("#lit_doc_request_document_type_id");
    public final Element docBlasterUploadPopupDropDownOptions = $(
            "#lit_doc_request_document_type_id option:not([value=''])");
    public final Element docBlasterPopupSubmit = $(".button.primary.float-right");
    public final Element docRequestSuccessMsg = $("#doc_status>p");
    public final Element docUploadPopupClose = $("#async_modal>.close-reveal-modal");
    public final Element docUploadPopup = $("#async_modal");
    public final Element docUploadCancel = $(".button.secondary.cancel.close-reveal-modal.float-right");
    public String[] docTypes_array = {"AO120", "Alice order", "Amended complaint", "Answer", "Appeal outcome", "Arbitration",
            "Claim Construction brief filed", "Claim Construction hearing", "Complaint", "Corporate disclosure",
            "Damages", "Daubert order", "Default judgment", "Dismissal", "Judgment", "Judgment as a matter of law",
            "Markman", "Motion to dismiss filed", "Motion to dismiss hearing", "Motion to dismiss order",
            "Motion to stay brief filed", "Motion to stay hearing", "Motion to transfer brief filed",
            "Motion to transfer hearing", "Notice of appeal", "Other", "Preliminary injunction", "Reexamination",
            "Rule 26 scheduling conference", "Settlement", "Stay", "Summary Judgment brief filed",
            "Summary Judgment hearing", "Summary judgment", "Transfers", "Trial", "Verdict",
            "Voluntary Dismissal with Prejudice", "Voluntary Dismissal without Prejudice"};

    public Element fedCircuitAppeal = $(".overview.panel .block-header:contains(Federal Circuit Appeal) a");
    public final StaticContent overview_panel = $(".overview.panel", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("case_type", ".block-header:contains(Case) .block-value");
                dataForm.content("market_sector", ".block-header:contains(Market) .block-value");
                dataForm.content("cause", ".block-header:contains(Cause) .block-value");
                dataForm.content("assigned_judge", ".block-header:contains(Assigned) .block-value a");
                dataForm.content("referred_judge", ".block-header:contains(Referred) .block-value a");
                dataForm.content("previous_presiding", ".overview.panel .block-header:contains(Previously)");
                dataForm.content("court", ".block-header:contains(Court) .block-value");
                dataForm.content("severance_from", ".block-header:contains(severance from) ul a");
                dataForm.content("transferred_to", ".block-header:contains(transferred to) ul a");
                dataForm.content("fedcircuit_appeal", ".block-header:contains(Federal Circuit Appeal)");
            }
    );

    public final Element transferredFromLink = $(".overview.panel .block-header:contains(transferred from) a");
    public final Element transferredToLink = $(".overview.panel .block-header:contains(transferred to) a");

    public final Element campaign_status = $("h5.section-title span.status");
    public Element plaitiff_count = $("#plaintiff_container div.round-shape");
    public Element plaitiff_npe_tag = $("#plaintiff_container .npe_tag");
    public Element defendant_count = $("#defendants_container div.round-shape");
    public Element other_parties_count = $("#other_parties_container div.round-shape");
    public final Table PLAINTIFF_PARTIES = $("#plaintiff_container", (Configure<Table>) table ->
            {
                table.viewAllLink("#plaintiff_container a.view-all:contains('View All')");
                table.viewLessLink("#plaintiff_container a.view-all:contains('View Less')");
                table.displayedRecords("#plaintiff_container ul:not([style*='none']) li>a:not([class])");
                table.uniqueId("ul>li>a:nth-of-type(1)");
                table.column("ent_name", "ul>li>a:nth-of-type(1)");
                table.column("counsel_details", "ul li>div:last-child");
            }
    );
    public final Element plaintiffSectionLink = $("#plaintiff_container li a:not([class])");
    public final Element counselInfoArrowInPlaintiffSection = $("#plaintiff_container li a[class*=arrow]");
    public final Element counselContentInPlaintiffSection = $("#plaintiff_container li .counsel-content");
    public final Element showAllCounselInPlaintiffSection = $(By.xpath("//div[@id='plaintiff_container']//a[text()='Show All Counsel']"));
    public final Element hideAllCounelInPlaintiffSection = $(By.xpath("//div[@id='plaintiff_container']//a[text()='Hide All Counsel']"));
    public final Element plaintiff_showAllCounsel = $("div#plaintiff_container a:contains('Show All Counsel')");

    public final Table DEFENDANT_PARTIES = $("#defendants_container", (Configure<Table>) table ->
            {
                table.viewAllLink(By.xpath("//div[@id='defendants_container']//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[@id='defendants_container']//a[text()='View Less']"));
                table.displayedRecords("#defendants_container ul:not([style*='none']) li>a:not([class])");
                table.uniqueId("ul>li>a:nth-of-type(1)");
                table.column("ent_name", "ul>li>a:nth-of-type(1)");
                table.column("counsel_details", "ul li>div:last-child");
            }
    );
    public final Element defendantSectionLink = $("#defendants_container li a:not([class])");
    public final Element counselInfoArrowInDefendantSection = $("#defendants_container li a[class*=arrow]");
    public final Element counselContentInDefendantSection = $("#defendants_container li .counsel-content");
    public final Element hideAllCounelInDefendantSection = $("div#defendants_container a:contains('Hide All Counsel')");
    public final Element defendants_showAllCounsel = $("div#defendants_container a:contains('Show All Counsel')");

    public final Table OTHER_PARTIES = $("#other_parties_container", (Configure<Table>) table ->
            {
                table.viewAllLink(By.xpath("//div[@id='other_parties_container']//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[@id='other_parties_container']//a[text()='View Less']"));
                table.displayedRecords("#other_parties_container ul:not([style*='none']) li>a:not([class])");
                table.uniqueId("ul>li>a:nth-of-type(1)");
                table.column("ent_name", "ul>li>a:nth-of-type(1)");
                table.column("counsel_details", "ul li>div:last-child");
            }
    );
    public final Element mediatorLinkOtherParties = $(By.xpath(
            "//div[@id='other_parties_container']//div[text()='mediator']/../a[not(contains(@class, 'counsel'))]"));
    public final Element otherPartiesLink = $("#other_parties_container li>a:not([class])");
    public final Element counselInfoArrowInOtherPartiesSection = $("#other_parties_container li a[class*=arrow]");
    public final Element counselContentInOtherPartiesSection = $("#other_parties_container li .counsel-content");
    public final Element hideAllCounelInOtherPartiesSection = $(By.xpath("//div[@id='other_parties_container']//a[text()='Hide All Counsel']"));
    public final Element showAllCounelInOtherPartiesSection = $(By.xpath("//div[@id='other_parties_container']//a[text()='Show All Counsel']"));

    //PATENT INFORMATION
    //PATENT-IN-SUIT
    public Element patent_in_suitTabLink = $("a[href='#patents_in_suit']");
    public Element patent_in_suite = $("#patents_in_suit");
    public final Table PATENT_TABLE = $(".patents-in-suit-table ", (Configure<Table>) table ->
            {
                table.uniqueId(" .lit_doc ");
                table.viewAllLink(By.xpath("//div[@id='patents_in_suit']//span/a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[@id='patents_in_suit']//span/a[text()='View Less']"));
                table.displayedRecords(".patents-in-suit-table tbody tr:not([style*='none'])");
            }
    );
    public final Element titleLinkPatentInSuit = $(".patents-in-suit-table tbody td a[class='lit_doc']");
    public final Element patentInfoViewAsSearch = $("div#patent_information a[href*='search_patents']");
    public final Element noPatentInSuitMsg = $("#patents_in_suit span");

    //PETITION
    public Element petitionTabLink = $("a[href='#petitions']");
    public Element petitions = $("#petitions");
    public final Table PETITION_TABLE = $(".lit_petitions_table ", (Configure<Table>) table ->
            {
                table.activationlink("a[href='#petitions']");
                table.uniqueId(" td:nth-child(3) a[href] ");
                table.viewAllLink("#petitions span>a:contains('View All'):visible");//div[contains(@class, 'petitions')]//span/a[text()='View All']
                table.viewLessLink("#petitions span>a:contains('View Less'):visible"); //By.xpath("//div[contains(@class, 'petitions')]//a[text()='View Less']")
                table.displayedRecords("#petitions tbody tr:not([style*='none'])");
            }//
    );
    public final Element noPetitionsMsg = $("#petitions>span");
    public final ListPanel petitionerTablePetitionerColumn = $(".lit_petitions_table tbody td:nth-of-type(4)", (Configure<ListPanel>) list ->
            {
                list.displayedRecords(".lit_petitions_table ul:not([style*='none']) li a");
                list.viewAllLink(By.xpath("//div[contains(@class, 'petitions')]//tbody//td[4]/span/a[text()='View All']"));
                list.viewLessLink(By.xpath("//div[contains(@class, 'petitions')]//tbody//td[4]/span/a[text()='View Less']"));
            }
    );
    public final Element itcCalloutPatentInSuit = $(".patents-in-suit-table td span[class='itc_call_out']");
    public final Element ptabCalloutPatentInSuit = $(".patents-in-suit-table td span[class='ptab_call_out']");
    public final Element itcPtabCalloutPatentInSuit = $(".patents-in-suit-table td span[class='ptab_call_out']+span[class='itc_call_out']");

    public final Tabs litigationCampaignTabs = new Tabs("#lit-campaign dl");
    public final Element caseTabLink = $("#lit-campaign a[href='#simple1']");
    public final Element defendantsTabLink = $("#lit-campaign a[href='#simple2']");
    public final Element patentsTabLink = $("#lit-campaign a[href='#simple3']");
    public final Element accusedProductsTabTable = $("#lit-campaign #related_accused_products_table");
    public final Element accusedProductsTabLink = $("#lit-campaign a[href='#simple4']");
    public final Element no_accused_products = $("#simple4 span:contains('No accused products found')");
    public final Table patent_accused_table = $("#lit-campaign div.active table", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(2) a[href]");
            }
    );
    public final Table patentInLitigationCampaign = $("#lit-campaign div.active table", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(1)");
            }
    );
    public final Table litigation_cases = $(".litigations_table", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(3)");
                table.viewAllLink(By.xpath("//div[contains(@id, 'simple1')]//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[contains(@id, 'simple1')]//a[text()='View Less']"));
                table.displayedRecords(".litigations_table tbody tr:not([style*='none'])");
            }
    );
    public final Table defendant_table = $("#campaign_defendants", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(1)>a:last-child");
                table.viewAllLink(".campaign_defendants a.view-all");
                table.viewLessLink(By.xpath("//div[@id='simple2']//a[text()='View Less']"));
                table.row("table#campaign_defendants>tbody>tr[role='row']");
                table.subTable($(".nested_inner_table", (Configure<Table>) subTable ->
                {
                    subTable.uniqueId("td:nth-child(3) a[href]");
                }));
                table.expandSubTableLink(".open.cursor-pointer");
                table.displayedRecords("#campaign_defendants tbody tr:not([style*='none'])");
            }
    );
    public final Element noDataInDefendantTable = $("#campaign_defendants .dataTables_empty");
    //public final Element litCampDefendantTabDefParentLink = $("#campaign_defendants tbody tr td:nth-of-type(1) a");
    public final Element litCampDefendantTabDefLink = $("#campaign_defendants tbody td:nth-of-type(2) a");
    public final Element litCampDefendantMostRecentCaseLink = $("#campaign_defendants tbody td:nth-of-type(3) a");
    public final Element noDefendantsNotes = $("#lit-campaign #simple2 .note");
    public final Element defendantSearchBox = $(".dataTables_filter div.search_text_container>input[type='text']");

    public void defendantSearch(String searchTerm) {
        defendantSearchBox.sendKeys(searchTerm);
        waitForLoading();
    }

    public final Element caseNameLinkInLitCampDefTabSubTable = $("#campaign_defendants .nested_inner_table td:nth-of-type(3) a");
    public final Element caseNoLinkInLitCampDefTabSubTable = $("#campaign_defendants .nested_inner_table td:nth-of-type(4) a");
    public final Element campLinkInLitCampSection = $("#litigation_campaign_section a[href*='campaign']");
    public final Element litigation_Section_PromoMsg = $("#lit-campaign div.active div.subscription-promo-message:contains('Start with a Free Trial')");
    public final Element litigation_section_SignOnMsg = $("#lit-campaign div.active div.subscription-promo-message:contains('Sign In')");

    public final Table camp_patent_table = $("#related_patents_table_wrapper", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(2) a[href]");
                table.viewAllLink(By.xpath("//div[contains(@id, 'simple3')]//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[contains(@id, 'simple3')]//a[text()='View Less']"));
                table.displayedRecords("#related_patents_table_wrapper tbody tr:not([style*='none'])");
            }
    );
    public final Element noPatentsInLitCamp = $("#simple3 span");
    public final Element litCampViewAsSearchResults = $("div[data-url*='related_cases'] .view-link a:contains('View as search results')");

    public final Table camp_accused_table = $("#related_accused_products_table", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(2) a[href]");
                table.viewAllLink(By.xpath("//div[contains(@id, 'simple4')]//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[contains(@id, 'simple4')]//a[text()='View Less']"));
                table.displayedRecords("#related_accused_products_table tbody tr:not([style*='none'])");
            }
    );

    //DOCKET SECTION
    public final Element docket_entries_list = $("#docket_entries", (Configure<ListPanel>) list ->
            {
                list.dataKey("tbody tr");
            }
    );

    //DOCKET ENTRIES
    public final Element docket_entries_count = $("#dockets_wrapper h5.section-subtitle");
    public final Table docket_entries = $("#docket_entries", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(1)");
                table.column("filing_date", "td:nth-child(1)");
                table.column("doc_data", "td:nth-child(2)");
                table.nextPage("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:last-child");
                table.lastPage("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:nth-last-child(2)");
                table.viewAllLink(By.xpath("//*[@id='dockets_wrapper']//a[text()='View All']"));
                table.viewLessLink(By.xpath("//*[@id='dockets_wrapper']//a[text()='View Less']"));
                table.displayedRecords("#dockets_wrapper tbody>tr, #dockets_wrapper>div:not([style*='none']) tbody>tr");
            }
    );

    public final Table docket_entries_func = $("#docket_entries", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(1)");
                table.nextPage("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:last-child");
                table.lastPage("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:nth-last-child(2)");
                table.viewAllLink(By.xpath("//*[@id='dockets_wrapper']//a[text()='View All']"));
                table.viewLessLink(By.xpath("//*[@id='dockets_wrapper']//a[text()='View Less']"));
                table.displayedRecords("#dockets_wrapper tbody>tr, #dockets_wrapper>div:not([style*='none']) tbody>tr");
            }
    );

    public final Table docket_entriess = $("#docket_entries", (Configure<Table>) table ->
            {
                table.viewAllLink(By.xpath("//*[@id='dockets_wrapper']//a[text()='View All']"));
                table.viewLessLink(By.xpath("//*[@id='dockets_wrapper']//a[text()='View Less']"));
                table.uniqueId("td:nth-of-type(1) a[class='document'][href]");
                table.displayedRecords("#dockets_wrapper tbody>tr, #dockets_wrapper>div:not([style*='none']) tbody>tr");
                table.column("Date Filed", " tbody tr td:nth-child(1)");
                table.nextPage("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:last-child");
                table.lastPage("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:nth-last-child(2)");
            }
    );


//    public final StaticContent docket_entriess = $("table#docket_entries", (Configure<StaticContent>) dataForm ->
//    {
//        dataForm.content("displayedRecords", "#dockets_wrapper tbody>tr, #dockets_wrapper>div:not([style*='none']) tbody>tr");
//        dataForm.content("nextPage", "#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:last-child");
//        dataForm.content("lastPage", "#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:nth-last-child(2)");
//        dataForm.content("Date Filed"," tbody tr td:nth-child(1)");
//    } );

    public final Element docketEntriesViewAllLink = $("#dockets_wrapper a:contains('View All')");
    public final Element docketEntriesViewLessLink = $("#dockets_wrapper a:contains('View Less')");
    public final Element docketEntriesClearBtn = $("#dockets_wrapper span.search_action_container a#clear_docket_form");
    public final Element docketEntrySearchBtn = $("#dockets_wrapper div.search_container span.search_action_container input[name='commit']");
    public final Element docketEntriesSearchBox = $("#dockets_wrapper input#docket_entry_text");

    public void docketEntriesSearch(String searchText) {
        if (!docketEntriesClearBtn.isDisplayed()) {
            searchDocketEntries(searchText);
        } else {
            docketEntriesClearBtn.click();
            loading.waitUntilInvisible();
            docketEntriesClearBtn.waitUntilInvisible();
            searchDocketEntries(searchText);
        }
    }

    public void searchDocketEntries(String searchKey) {
        docketEntriesSearchBox.sendKeys(searchKey);
        docketEntrySearchBtn.click();
        loading.waitUntilInvisible();
    }

    public final Element noResultDocketSearch = $("#dockets_wrapper .large-12.columns>div.pd-16 span");

    public void docketEntriesClear() {
        docketEntriesClearBtn.click();
        waitForLoading();
    }

    public final Element docketEntriesNote = $("div.note");

    // DOCKET ENTRIES CONFIRMATION MODAL
    public final Element confirmationModal = $(
            By.xpath("//div[@id='doc_download_modal']//h2[text()='Document Credit Confirmation']"));
    public final Element confirmationModalClose = $("#doc_download_modal a[class='close-reveal-modal']");
    public final Element confirmationModalCancel = $(".download_modal button[name='cancel']");
    public final Element confirmDebitBtn = $(".button.download_link");

    // DOCKET ENTRIES INSUFFICIENT MODAL
    public final Element insufficientModal = $(
            By.xpath("//div[@id='doc_download_modal']//h2[text()='Insufficient Credit']"));
    public final Element insufficientModalClose = $("#doc_download_modal a[class='close-reveal-modal']");
    public final Element insufficientModalCancel = $(".button.secondary.cancel.close-reveal-modal");
    public final Element purchaseMoreCreditBtn = $(".button.text-transform");
    public final Element availableCredit = $(".available_credit");
    public final Element documentCost = $(".small-3.columns.doc_cost");

    // DOCKET ENTRIES DOWNLOAD LINKS
    public final Element docketDocuments = $("#dockets_wrapper .document");
    public final Element thirdPartyComplaintDocument = $(
            By.xpath("//span[@class='lit_doc_type'][text()='3rd Party Complaint']/../a"));
    public final Element complaintDocument = $(By.xpath("//span[@class='lit_doc_type'][text()='complaint']/../a"));
    public final Element amendedComplaintDocument = $(
            By.xpath("//span[@class='lit_doc_type'][text()='amended complaint']/../a"));

    public final Element stickyAlert = $(By.xpath("//div[@class='alert-box sticky-alert']"));

    public Element docketEntry(String docketNumber) {
        return $("a[class='document'][data-doc-url*='" + docketNumber + "']");
    }

    // FOR LIT wawdce-190582
    public final Element documentHighCost = $("#docket_entries a[data-doc-url='/litigation_documents/12790928/doc_info']");
    public final Element documentLessCost = $(By.xpath("//*[@id='docket_entries']/tbody//a[text()='16']"));

    public final Element priorArtReport = $("[data-behavior='prior_art_report_gtm']");
    public final Element accused_product_count = $("div[data-url$='accused_products'] .round-shape");
    public final Element accused_product_section = $("div[data-url$='accused_products']", (Configure<ListPanel>) list ->
            {
                list.viewAllLink(".panel.force_word_break .view-all");
                list.dataKey(" li ");
            }
    );
    public final Element accused_product_panel = $("#accused_products div.accused_product_style");
    //public final Element accused_product_panel_promo = $("div#accused_products div.subscription_promo_message:contains('Accused products are not included in your current subscription level. Please')>a[href='/subscribe']");
    //public final Element accused_product_panel_promo_signin = $("div#accused_products div.subscription_promo_message:contains('Please'):contains('to see additional information.')>a.reveal_login_from_grey_out");

    public final Element savedLitigtionBtn = $("button.save_litigation.saved>span");

    public void selectDefendantTab() {
        if (defendantsTabLink.isDisplayed()) {
            defendantsTabLink.click();
            waitForSectionLoading();
        }
    }

    public void selectCasesTab() {
        if (caseTabLink.isDisplayed()) {
            caseTabLink.click();
            waitForPageLoad();
        }
    }

    public void selectAccusedProductTab() {
        if (accusedProductsTabLink.isDisplayed()) {
            accusedProductsTabLink.click();
            waitForPageLoad();
        }
    }

    public void selectPatentTab() {
        if (patentsTabLink.isDisplayed()) {
            patentsTabLink.click();
            waitForPageLoad();
        }
    }

    public void expandAlldefandant() {
        if (defendant_table.isDisplayed()) {
            if (!defendant_table.subtable().isDisplayed()) {
                defendant_table.viewAll();
                $(".campaign_defendants .open.cursor-pointer:not([style=\"display: inline-block;\"])").getElements().forEach(element -> {
                    element.click();
                    waitForSectionLoading();
                });

            }
        }
    }

    public void selectPetitionTab() {
        if (petitionTabLink.isDisplayed()) {
            petitionTabLink.click();
            waitForPageLoad();
        }
    }

    public String[] docTypes = {"AO120", "Amended complaint", "Answer", "Appeal outcome", "Arbitration",
            "Claim Construction brief filed", "Claim Construction hearing", "Complaint", "Corporate disclosure",
            "Damages", "Daubert order", "Default judgment", "Dismissal", "Final Decision",
            "Institution Decision", "Judgment", "Judgment as a matter of law",
            "Markman", "Motion to dismiss filed", "Motion to dismiss hearing", "Motion to dismiss order",
            "Motion to stay brief filed", "Motion to stay hearing", "Motion to transfer brief filed",
            "Motion to transfer hearing", "Notice of appeal", "Other", "Patent Owner Mandatory Notice", "Petition", "Preliminary injunction", "Reexamination",
            "Rule 26 scheduling conference", "Settlement", "Stay", "Summary Judgment brief filed",
            "Summary Judgment hearing", "Summary judgment", "Termination", "Transfers", "Trial", "Verdict",
            "Voluntary Dismissal with Prejudice", "Voluntary Dismissal without Prejudice"};

    /**
     * Is Judge Beta Tag present
     *
     * @return
     */
    public boolean isJudgeBetaTagPresent() {
        return judgeBetaTag.isDisplayed();
    }

    /**
     * Is Court/Venue Beta Tag present
     *
     * @return
     */
    public boolean isCourtBetaTagPresent() {
        return courtBetaTag.isDisplayed();
    }

    /**
     * Get All Court Hyper Link data
     *
     * @return
     */
    public ArrayList<String> getCourtHyperLink() {
        return courtHyperLink.getAllData();
    }

    /**
     * Get All Judge Hyper Link data
     *
     * @return
     */
    public ArrayList<String> getJudgeHyperLink() {
        return judgeHyperLink.getAllData();
    }

    /**
     * Get All Court Name
     *
     * @return
     */
    public ArrayList<String> getCourtWithoutHyperLink() {
        return courtWithoutHyperLink.getAllData();
    }

    /**
     * Get All Judge Name
     *
     * @return
     */
    public ArrayList<String> getJudgeWithoutHyperLink() {
        return judgeWithoutHyperLink.getAllData();
    }

    public ArrayList<String> getOptionFromDocType() {
        docBlasterUploadPopupDropDown.click();
        docBlasterUploadPopupDropDownOptions.waitUntilVisible();
        ArrayList<String> dataList = new ArrayList<String>();
        dataList = docBlasterUploadPopupDropDownOptions.getAllData();
        return dataList;
    }

    public int getRowIndexforDocBlasterUpload() {
        int i = 1;
        List<WebElement> docElements = getDriver().findElements(By.cssSelector("#docket_entries tbody tr"));
        for (i = 1; i <= docElements.size(); i++) {
            if (getDriver()
                    .findElements(By.cssSelector(
                            "#docket_entries tbody tr:nth-of-type(" + i + ") .lit_doc_request"))
                    .size() != 0)
                break;
        }

        return i;
    }

    public WebElement getDocBlasterUploadedStatus(int index) {
        return getDriver()
                .findElement(By.cssSelector("#docket_entries tbody tr:nth-of-type(" + index + ") .lit_doc_type"));
    }

    public boolean getDocBlasterStatus(int index) {
        if (getDriver().findElements(By.cssSelector("#docket_entries tbody tr:nth-of-type(" + index + ") .lit_doc_request")).size() == 0)
            return true;
        return false;
    }

    @SuppressWarnings("incomplete-switch")
    public List<Object> checkHourlyAlerts(ROLES role) {
        List<Object> checkList = new ArrayList<Object>();
        switch (role) {
            case EXTERNAL_MEMBER:
                checkList.add(!(hourlyAlertRadioBtn.isDisplayed()));
                checkList.add("Hourly Alerts Option is displayed in Create Alert Dialog");
                break;
            case BASIC:
                checkList.add(!(hourlyAlertRadioBtn.isSelected()) && hourlyStaticToolTip.getAttribute("data-ot-content")
                        .contains("Hourly alerts are not included in your current subscription."));
                checkList.add("Hourly Alerts Option is not displayed in Create Alert Dialog");
                break;
        }
        return checkList;
    }

    public void saveToDashBoard() {
        save_to_dashboard_btn.click();
        savedLitigtionBtn.waitUntilVisible();
    }

    public void cancelSavedDashboard() {
        savedLitigtionBtn.click();
        acceptAlert();
    }

    // AUTHORIZATION

    public final Element itcMostRecentCase = $(By.xpath(
            "//table[contains(@class,'campaign_defendants_table')]//tbody/tr[1]/td[3]//a[not(text()='337-TA-000')]"));
    public final Element firstSubtableOpen = $("tr:nth-of-type(1) .open.cursor-pointer");
    public final Element firstSubtableClose = $("tr:nth-of-type(1) .close.cursor-pointer");
    public final Element defendantSubtable = $(".case_details table.nested_inner_table");

    public void openDefendantSubtable() {
        if (!defendant_table.isDisplayed()) {
            selectDefendantTab();
        }
        if (firstSubtableOpen.isDisplayed()) {
            firstSubtableOpen.click();
            defendantSubtable.waitUntilVisible();
        }
    }


    public final Element defSubtableItcCaseName_Login = $(
            By.xpath("//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[2]/a[text()='sign in']"));
    public final Element defSubtableItcTermDateEmpty = $("table.nested_inner_table tbody>tr:nth-of-type(1)>td:nth-child(5):empty"); //$(By.xpath("//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[4][not(text())]"));//
    public final Element defSubtableItcCaseNameLink = $("table.nested_inner_table tbody>tr:nth-of-type(1)>td:nth-child(3):has(a.case_details)"); //$(By.xpath("//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[2]/a[contains(@href,'/itc/')]"));
    public final Element defSubtableItcCaseNo = $("table#DataTables_Table_2 tbody>tr:nth-of-type(1)>td:nth-child(4)"); //$(By.xpath("//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[2]/a[contains(@href,'/itc/')]"));

    public void viewCasesInLitigationCampaign() {
        if (!caseTabLink.getAttribute("class").contains("active")) {
            caseTabLink.click();

        }
    }

    public final Element litigation_SignOnMsg = $(By.xpath("//*[@class='panel overview-entity']/following-sibling::div[1]//h4[text()[contains(.,'to see additional information')]]"));
    public final Element litigation_PromotionalMsg = $(By.xpath("//*[@class='panel overview-entity']/following-sibling::div[1]//h4[text()[contains(.,'This Content is not included in your current subscription')]]"));

    public final Element itcCaseNameLinkLitCampCases = $(By.xpath(
            "//div[@id='simple1']//table//td/a[contains(text(),'337-TA')]/../preceding-sibling::td[1]/a[contains(@href,'/usitc/')]"));
    public final Element itcCaseNameLitCampCases_Login = $(By.xpath(
            "//div[@id='simple1']//table//td/a[contains(text(),'337-TA')]/../preceding-sibling::td[1]/a[text()='sign in']"));

    // AUTHORIZATION DEFENDANT
    public final Element defendantWithNoCounsel = $("#defendants_container span:contains('No representation listed')");

    public final Element defendantPromotionalLnk_without_FF = $(By.xpath(
            "//*[@id='defendants_container']//h4[contains(text(),'Counsel Information is not included in your current subscription')]"));
    public final Element defendantCounselLogIn_without_FF = $(
            By.xpath("//*[@id='defendants_container']//a[text()='sign in']"));
    // AUTHORIZATION PLAINTIFF
    public final Element plaintiffWithNoCounsel = $("#plaintiff_container span:contains('No representation listed')");

    public final Element plaintiffPromotionalLnk_without_FF = $(By.xpath(
            "//*[@id='plaintiff_container']//h4[contains(text(),'Counsel Information is not included in your current subscription')]"));
    public final Element plaintiffCounselLogIn_without_FF = $(
            By.xpath("//*[@id='plaintiff_container']//a[text()='sign in']"));

    // AUTHORIZATION OTHER PARTIES    
    public final Element otherPartiesWithNoCounsel = $("#other_parties_container span:contains('No representation listed')");
    public final Element otherPartiesWithCounselInfo = $("#other_parties_container .counsel-content>.counsel-party");
    public final Element otherPartiesPromotionalLnk = $("div#other_parties_container ul:not([style*='display: none;'])>li:nth-child(1) div.subscription-promo-message:contains('Start with a Free Trial')");
    public final Element otherPartiesCounselSignOnMsg = $("div#other_parties_container ul:not([style*='display: none;'])>li:nth-child(1) div.subscription-promo-message a.signin:contains('Sign In') ~ span:contains('or') ~ a.blocked-content-promo.trial:contains('Start with a Free Trial')");


    // ALERTS ELEMENTS AND METHODS
    public final Element alert_createAlert_Btn = $(By.xpath("//*[@id='lit_alert_form' and @value='Create Alert']"));
    public final Element alert_Cancel_Btn = $(By.xpath("//button[text()='Cancel']"));
    public final Element alert_Delete_Btn = $(By.xpath("//input[@value='Delete Alert']"));
    public final Element alert_SaveUpdates_Btn = $(By.xpath("//input[@value='Save Updates']"));
    public final Element alert_close_icon = $(".open a.close-reveal-modal");
    public final Element alert_Dialog_Title = $("#alert-modal-new.open h2");
    public final Element alert_Step1_Title = $(By.xpath(
            "//*/h4[text()[normalize-space(.)='What case events do I want to be alerted on?']]/span[text()='Step 1:']"));
    public final Element alert_Step2_Title = $(By.xpath(
            "//*/h4[text()[normalize-space(.)='How often do I want to receive this alert?']]/span[text()='Step 2:']"));
    public final Element alert_CaseEvents = $(By.xpath("//div[@class='new_alert_events']//input"));
    public final Element alert_CaseEvents_text = $(By.xpath("//div[@class='new_alert_events']//input/.."));
    public final Element alert_SelectAll_KeyEvents = $(By.xpath("//span[text()='Select All Key Events']/../input"));
    public final Element alert_Continue_btn = $(".open span.alert_continue");
    public final Element alert_Back_Btn = $(".open span.alert_back");
    public final Element alert_Hourly_Radio_Btn = $(".open #alert_delivery_hourly");
    public final Element alert_Daily_Radio_Btn = $(".open #alert_delivery_daily");
    public final Element alert_Weekly_Radio_Btn = $(".open #alert_delivery_weekly");
    public final Element alert_Selected_Frequency = $(".alert-frequency-container input[checked]+span");
    public final Element litModifyAlert_Btn = $(By.xpath("//span[contains(text(),'Modify Alert')]"));
    public final Element litCreateAlert_Btn = $(By.xpath("//span[contains(text(),'Create Alert')]"));
    public final Element alert_case_event_error = $("div.errors");

    /**
     * Click on Litigation Create Alert button
     */
    public void clickOnLitCreateAlertBtn() {
        if (!alert_Dialog_Title.isDisplayed()) {
            litCreateAlert_Btn.click();
            loading.waitUntilInvisible();
            alert_Dialog_Title.waitUntilVisible();
        }
    }

    /**
     * Click on Litigation Modify Alert button
     */
    public void clickOnLitModifyAlertBtn() {
        litModifyAlert_Btn.waitUntilClickable();
        litModifyAlert_Btn.click();
        alert_Dialog_Title.waitUntilVisible();
    }

    /**
     * Close Alert Dialog if its open
     */
    public void closeAlertDialog() {
        if (alert_close_icon.isDisplayed()) {
            alert_close_icon.click();
            alert_Dialog_Title.waitUntilInvisible();
        }
    }

    /**
     * Get all selected Case Events if isSelected=true Get all Case Events which
     * are not selected if isSelected=false
     *
     * @param isSelected
     * @return List<String> options
     */
    public List<String> getCaseEventsInAlertDialog(boolean isSelected) {
        List<String> selectedOptions = new ArrayList<String>();
        List<String> deSelectedOptions = new ArrayList<String>();
        for (int i = 0; i < alert_CaseEvents.getElements().size(); i++) {
            if (alert_CaseEvents.getElements().get(i).isSelected()) {
                selectedOptions.add(alert_CaseEvents_text.getElements().get(i).getText().replaceAll("\n", "").trim());
            } else {
                deSelectedOptions.add(alert_CaseEvents_text.getElements().get(i).getText().replaceAll("\n", "").trim());
            }
        }
        if (isSelected) {
            return selectedOptions;
        } else {
            return deSelectedOptions;
        }

    }

    /**
     * Select All Case Events if isSelectAll=true Uncheck select All Case Events
     * if isSelectAll=false
     *
     * @param isSelectAll true/false
     */
    public void selectAllCaseEventsInAlertDialog(boolean isSelectAll) {
        alert_SelectAll_KeyEvents.waitUntilVisible();
        if (isSelectAll) {
            if (!alert_SelectAll_KeyEvents.isSelected()) {
                alert_SelectAll_KeyEvents.click();
            }
        }
        if (isSelectAll == false) {
            if (!alert_SelectAll_KeyEvents.isSelected()) {
                alert_SelectAll_KeyEvents.click();
                alert_SelectAll_KeyEvents.click();
            } else {
                alert_SelectAll_KeyEvents.click();
            }
        }
    }

    /**
     * Click On Create Alert Button in Alert Dialog
     */
    public void clickOnCreateAlertBtnInAlert() {
        alert_createAlert_Btn.waitUntilVisible();
        alert_createAlert_Btn.click();
    }

    /**
     * Click On Continue Button in Alert Dialog
     */
    public void clickOnContinueBtnInAlert() {
        alert_Continue_btn.waitUntilVisible();
        alert_Continue_btn.click();
    }

    /**
     * Click On Back Button in Alert Dialog
     */
    public void clickOnBackBtnInAlert() {
        alert_Back_Btn.waitUntilVisible();
        alert_Back_Btn.click();
        alert_Continue_btn.waitUntilVisible();
    }

    /**
     * Click On Save Updates Button in Alert Dialog
     */
    public void clickOnSaveUpdatesBtnInAlert() {
        alert_SaveUpdates_Btn.waitUntilVisible();
        alert_SaveUpdates_Btn.click();
        alert_Dialog_Title.waitUntilInvisible();
        litModifyAlert_Btn.waitUntilVisible();
    }

    /**
     * Click On Cancel Button in Alert Dialog
     */
    public void clickOnCancelInAlertDialog() {
        alert_Cancel_Btn.click();
        alert_Dialog_Title.waitUntilInvisible();
    }

    /**
     * Click On Delete Button in Alert Dialog
     */
    public void deletAlert() {
        alert_Delete_Btn.click();
        acceptAlert();
        alert_Dialog_Title.waitUntilInvisible();
        litCreateAlert_Btn.waitUntilVisible();
    }

    /**
     * Select Alert Frequency based on Text Name Ex:Weekly
     *
     * @param alertFrequencyText
     */
    public void selectAlertFrequencyInAlertDialog(String alertFrequencyText) {
        String xpath = String.format(
                "//div[@class='small-6 columns alert-frequency-container']//span[text()='%s']/../input",
                alertFrequencyText);
        Element alertFrequency = $(By.xpath(xpath));
        alertFrequency.waitUntilVisible();
        alertFrequency.click();
    }

    /**
     * Return selected Alert Frequency
     *
     * @return
     */
    public String getSelectedAlertFrequencyOptionInAlertDialog() {
        if (alert_Continue_btn.isDisplayed()) {
            clickOnContinueBtnInAlert();
        }
        return alert_Selected_Frequency.getText();
    }

    /**
     * Select Case Type Event based on Case Name and boolean condition
     *
     * @param caseTypeEventName
     * @param isSelect
     */
    public void selectCaseTypeEventInAlertDialog(String caseTypeEventName, boolean isSelect) {
        String xpath = String.format("//*/text()[normalize-space(.)='%s']/../input", caseTypeEventName);
        Element caseTypeEvent = $(By.xpath(xpath));
        if (!caseTypeEvent.isSelected() && isSelect == true) {
            caseTypeEvent.click();
        }
        if (caseTypeEvent.isSelected() == true && isSelect == false) {
            caseTypeEvent.click();
        }
    }

    /**
     * @param alertOptions
     * @return selected options from Case Type Events and Frequency in Alert
     * Dialog
     */
    public HashMap<String, String> getAlertOptionsSelectionStatus(HashMap<String, String> alertOptions) {
        HashMap<String, String> optionsStatus = new HashMap<String, String>();
        for (Entry<String, String> entry : alertOptions.entrySet()) {
            if (!entry.getKey().equalsIgnoreCase("Frequency")) {
                String xpath_caseTypeEvent = String.format("//*/text()[normalize-space(.)='%s']/../input",
                        entry.getKey());
                Element caseTypeEvent = $(By.xpath(xpath_caseTypeEvent));
                if (caseTypeEvent.isSelected()) {
                    optionsStatus.put(entry.getKey(), "Yes");
                } else {
                    optionsStatus.put(entry.getKey(), "No");
                }

            } else {
                optionsStatus.put(entry.getKey(), getSelectedAlertFrequencyOptionInAlertDialog());
            }

        }

        return optionsStatus;

    }

    /**
     * Select Case Type Event and Frequency option based on HashMap Data
     *
     * @param alertOptions
     */
    public void selectAlertCaseTypeAndFrequencyEvents(HashMap<String, String> alertOptions) {
        boolean isSelect = false;
        for (Entry<String, String> entry : alertOptions.entrySet()) {
            if (entry.getKey().equalsIgnoreCase("Frequency")) {
                if (alert_Continue_btn.isDisplayed()) {
                    clickOnContinueBtnInAlert();
                }
                selectAlertFrequencyInAlertDialog(entry.getValue());
            } else {
                if (alert_Back_Btn.isDisplayed()) {
                    clickOnBackBtnInAlert();
                }
                if (entry.getValue().equalsIgnoreCase("Yes")) {
                    isSelect = true;
                } else {
                    isSelect = false;
                }
                selectCaseTypeEventInAlertDialog(entry.getKey(), isSelect);
            }
        }
    }

    /**
     * Create Alert based on passed hashmap data
     *
     * @param alertOptions
     */
    public void createLitAlert(HashMap<String, String> alertOptions) {
        clickOnLitCreateAlertBtn();
        selectAlertCaseTypeAndFrequencyEvents(alertOptions);
        clickOnCreateAlertBtnInAlert();
        litModifyAlert_Btn.waitUntilVisible();
    }

    /**
     * Modify Alert based on passed hashmap data
     *
     * @param alertOptions
     */
    public void updateLitAlert(HashMap<String, String> alertOptions) {
        clickOnLitModifyAlertBtn();
        selectAlertCaseTypeAndFrequencyEvents(alertOptions);
        clickOnSaveUpdatesBtnInAlert();
        litModifyAlert_Btn.waitUntilVisible();
    }

    //Role Authorization for Alerts
    public final Element dc_Events = $(".alert_subscription input#District_Court_Events:not([class*='greyed-out']):visible()");
    public final Element rpx_Reports_Events = $("input#RPX_Reports:not([class*='greyed-out'])");
    public final Element prior_art_Report_Event = $("input#alert_event__400:not([class*='greyed-out'])");
    public final Element alert_Btn_SignInMsg = $("#alerts_controls_holder a[data-ot-content*='sign in']");
    public final Element event_Promotional_Msg = $(".events_promotional_msg a[href='/payments/options']");

    public final Element docket_SignOnMsg = $(By.xpath("//h2[contains(text(),'Docket Entries')]/../..//div[contains(text(),'Please')]"));

}
