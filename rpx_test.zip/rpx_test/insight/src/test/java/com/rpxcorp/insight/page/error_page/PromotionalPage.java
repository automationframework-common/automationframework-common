package com.rpxcorp.insight.page.error_page;

import org.openqa.selenium.By;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class PromotionalPage extends BasePage {

    @Override
    public boolean at() {
        upgrade.waitUntilVisible();
        return false;
    }

    public final Element upgrade = $("div.subscription-promo-message:contains('Start with a Free Trial')");
}
