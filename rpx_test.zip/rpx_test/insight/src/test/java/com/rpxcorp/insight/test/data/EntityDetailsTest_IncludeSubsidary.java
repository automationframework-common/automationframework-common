package com.rpxcorp.insight.test.data;

import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import com.rpxcorp.insight.page.detail.EntityDetailPage;
import com.rpxcorp.testcore.TableData;
@Test(groups = "Entity")
@Authenticate(role = "MEMBER")
public class EntityDetailsTest_IncludeSubsidary extends BaseDataTest {

    EntityDetailPage entityDetailPage;
    TableData litigationTableData, petitionTableData;
    String subsidiaries = "";

    /* TEST CONFIGURATIONS */
    @Factory(dataProvider = "returnData")
    public EntityDetailsTest_IncludeSubsidary(String dataDescription, String entityId) {
        this.dataId = entityId;
        this.dataDescription = dataDescription;
    }

    @BeforeClass
    public void loadPage() throws Exception {
        urlData.put("ID", dataId);
        String sub = getDataIdasString(sqlProcessor.getResultData("EntityDetail.SUBSIDARYLIST", dataId));
        if (sub.isEmpty())
            subsidiaries = dataId;
        else
            subsidiaries = dataId + "," + sub;
        this.dataUrl = entityDetailPage.getDeclaredUrl(urlData);
        to(entityDetailPage, urlData);
    }

    /* TEST CASES */
    @Test(description = "Verify entity name", priority = 1)
    public void Entity_Name() throws Exception {
        assertEquals(entityDetailPage.detailPageTitle.getData(),
                sqlProcessor.getResultData("EntityDetail.ENTITY_NAME", dataId), "name");
    }

    @Test(description = "Verify subsidary list", priority = 2)
    public void SubsidiaryList() throws Exception {
        assertEquals(entityDetailPage.subsidariesList.getData(),
                sqlProcessor.getResultData("EntityDetail.SUBSIDARYLIST", dataId));
    }

    @Test(description = "Verify Subsidiary Count", priority = 3)
    public void Subsidiary_Count() throws Exception {
        assertEquals(entityDetailPage.subsidariesCount.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.SUBSIDARYLIST", dataId));
    }

    @Test(description = "Verify Overview Cases Count", priority = 1)
    public void Overview_Count() throws Exception {
        assertEquals(entityDetailPage.overview_panel.getData(),
                sqlProcessor.getResultData("EntityDetail.OVERVIEW_COUNT", subsidiaries));
    }

    @Test(description = "Verify All Patent Count", priority = 6)
    public void All_Patents_Count() throws Exception {
        assertEquals(entityDetailPage.patentCount.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.PATENT_ALL", dataId));
    }

    @Test(description = "Verify Patent Plaintiff Count", priority = 7)
    public void Patent_as_Plaintiff_Count() throws Exception {
        assertEquals(entityDetailPage.patentPlaintiffTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.PATENT_PLAINTIFF", dataId));
    }

    @Test(description = "Verify Patent Defendant Count", priority = 8)
    public void Patent_as_Defendant_Count() throws Exception {
        assertEquals(entityDetailPage.patentDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.PATENT_DEFENDANT", dataId));
    }

    @Test(description = "Veify 'Date filed' column in Patent Owner Table", priority = 19)
    public void PatentOwnerTable_DateFiled() throws Exception {
        petitionTableData = (TableData) entityDetailPage.petition_table.getData();
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PATENTOWNER_INC_SUB", dataId),
                "date_filed");
    }

    @Test(description = "Veify 'Patent Number' column in Patent Owner Table", priority = 20)
    public void PatentOwnerTable_PatentNumber() throws Exception {
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PATENTOWNER_INC_SUB", dataId),
                "patent_number");
    }

    @Test(description = "Veify 'Case Number' column in Patent Owner Table", priority = 20)
    public void PatentOwnerTable_CaseNumber() throws Exception {
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PATENTOWNER_INC_SUB", dataId),
                "case_number");
    }

    @Test(description = "Verify 'Status' column in Patent Owner Table", priority = 20)
    public void PatentOwnerTable_Status() throws Exception {
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PATENTOWNER_INC_SUB", dataId),
                "status");
    }

    @Test(description = "Verify 'Institution Decision Date' column in Patent Owner Table", priority = 20)
    public void PatentOwnerTable_InstitutionDecisionDate() throws Exception {
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PATENTOWNER_INC_SUB", dataId),
                "institution_decision_date");
    }

    @Test(description = "Verify 'Date filed' column in Petitioner Table", priority = 21)
    public void PetitionerTable_DateFiled() throws Exception {
        entityDetailPage.filterPetitioner();
        petitionTableData = (TableData) entityDetailPage.petition_table.getData();
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PETITIONER_INC_SUB", dataId),
                "date_filed");
    }

    @Test(description = "Verify 'Patent Number' column in Petitioner Table", priority = 22)
    public void PetitionerTable_PatentNumber() throws Exception {
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PETITIONER_INC_SUB", dataId),
                "patent_number");
    }

    @Test(description = "Verify 'Case Number' column in Petitioner Table", priority = 22)
    public void PetitionerTable_CaseNumber() throws Exception {
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PETITIONER_INC_SUB", dataId),
                "case_number");
    }

    @Test(description = "Verify 'Status' column in Petitioner Table", priority = 22)
    public void PetitionerTable_Status() throws Exception {
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PETITIONER_INC_SUB", dataId),
                "status");
    }

    @Test(description = "Verify 'Institution Decision Date' column in Petitioner Table", priority = 22)
    public void PetitionerTable_InstitutionDecisionDate() throws Exception {
        assertEquals(petitionTableData, sqlProcessor.getResultData("EntityDetail.PTAB_PETITIONER_INC_SUB", dataId),
                "institution_decision_date");
    }

    @Test(description = "Verify Patent Owner Table in Parties view", priority = 23)
    public void PatentOwnerTable_in_parties_view() throws Exception {
        entityDetailPage.filterPatentOwner();
        entityDetailPage.selectPartiesTab();
        assertEquals(entityDetailPage.partiesNPatentTable.getSubtableData(),
                sqlProcessor.getResultData("EntityDetail.PTAB_PARTIES_PATENTOWNER_INC_SUB", dataId));
    }

    @Test(description = "Verify Petitioner Table in Parties view", priority = 24)
    public void PetitionerTable_in_parties_view() throws Exception {
        entityDetailPage.filterPetitioner();
        assertEquals(entityDetailPage.partiesNPatentTable.getSubtableData(),
                sqlProcessor.getResultData("EntityDetail.PTAB_PARTIES_PETITIONERS_INC_SUB", dataId));
    }

    @Test(description = "Verify Patent Patent Owner Table in Patent view", priority = 25)
    public void PatentOwnerTable_in_patent_view() throws Exception {
        entityDetailPage.filterPatentOwner();
        entityDetailPage.selectPatentsTab();
        assertEquals(entityDetailPage.partiesNPatentTable.getSubtableData(),
                sqlProcessor.getResultData("EntityDetail.PTAB_PATENT_PATENTOWNER_INC_SUB", dataId));
    }

    @Test(description = "Verify Petitioner Table in Patent view", priority = 26)
    public void PetitionerTable_in_patent_view() throws Exception {
        entityDetailPage.filterPetitioner();
        assertEquals(entityDetailPage.partiesNPatentTable.getSubtableData(),
                sqlProcessor.getResultData("EntityDetail.PTAB_PATENT_PETITIONERS_INC_SUB", dataId));
    }

    @Test(description = "Verify All Litigation Count in campaign view", priority = 9)
    public void All_Litations_Count_in_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ALL_CASES", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Litigation Plaintiff Count in campaign view", priority = 10, enabled = false)
    public void Litigation_as_Plaintiff_Count_in_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_PLAINTIFF_CASES", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Litigation Defendant Count in campaign view", priority = 11, enabled = false)
    public void Litigation_as_Defendant_Count_in_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_DEFENDANT_CASES", subsidiaries));
    }

    @Test(description = "Verify All Active Litigation Count in campaign view", priority = 12)
    public void ACTIVE_Litigation_Count_in_campaign_view() throws Exception {
        entityDetailPage.filterActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_CASES", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Active Litigation as Plaintiff Count in campaign view", priority = 13, enabled = false)
    public void Active_Litigation_as_Plaintiff_Count_in_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_PLAINTIFF_CASES", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Active Litigation as Defendant Count in campaign view", priority = 14, enabled = false)
    public void Active_Litigation_Defendant_Count_in_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_DEFENDANT_CASES", subsidiaries));
    }

    @Test(description = "Verify All Inactive Litigation Count in campaign view", priority = 15)
    public void INACTIVE_Litigation_Count_in_campaign_view() throws Exception {
        entityDetailPage.filterInActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_CASES", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Inactive Litigation as Plaintiff Count in campaign view", priority = 16, enabled = false)
    public void Inactive_Litigation_as_Plaintiff_Count_in_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_PLAINTIFF_CASES", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Inactive Litigation as Defendant Count in campaign view", priority = 17, enabled = false)
    public void Inactive_Litigation_as_Defendant_Count_in_campaign_view() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_DEFENDANT_CASES", subsidiaries));
    }

    @Test(description = "Veify All Litigation Count in non campaign view", priority = 18)
    public void All_Litigations_Count_in_noncampaign_view() throws Exception {
        entityDetailPage.changeCampaignView();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.ALL_CASES", subsidiaries));
    }

    @Test(description = "Verify All Litigation Count in campaign view NPE", priority = 30)
    public void All_Litations_Count_in_campaign_view_NPE() throws Exception {
        entityDetailPage.changeCampaignView();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ALL_CASES_NPE", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Litigation Plaintiff Count in campaign view NPE", priority = 31, enabled = false)
    public void Litigation_as_Plaintiff_Count_in_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_PLAINTIFF_CASES_NPE", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Litigation Defendant Count in campaign view NPE", priority = 32, enabled = false)
    public void Litigation_as_Defendant_Count_in_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_DEFENDANT_CASES_NPE", subsidiaries));
    }

    @Test(description = "Verify All Active Litigation Count in campaign view NPE", priority = 33)
    public void ACTIVE_Litigation_Count_in_campaign_view_NPE() throws Exception {
        entityDetailPage.filterActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_CASES_NPE", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Active Litigation as Plaintiff Count in campaign view NPE", priority = 34, enabled = false)
    public void Active_Litigation_as_Plaintiff_Count_in_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_PLAINTIFF_CASES_NPE", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Active Litigation as Defendant Count in campaign view NPE", priority = 35, enabled = false)
    public void Active_Litigation_Defendant_Count_in_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_DEFENDANT_CASES_NPE", subsidiaries));
    }

    @Test(description = "Verify All Inactive Litigation Count in campaign view NPE", priority = 36)
    public void INACTIVE_Litigation_Count_in_campaign_view_NPE() throws Exception {
        entityDetailPage.filterInActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_CASES_NPE", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Inactive Litigation as Plaintiff Count in campaign view NPE", priority = 37, enabled = false)
    public void Inactive_Litigation_as_Plaintiff_Count_in_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_PLAINTIFF_CASES_NPE", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Inactive Litigation as Defendant Count in campaign view NPE", priority = 38, enabled = false)
    public void Inactive_Litigation_as_Defendant_Count_in_campaign_view_NPE() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_DEFENDANT_CASES_NPE", subsidiaries));
    }

    @Test(description = "Veify All Litigation Count in non campaign view NPE", priority = 49)
    public void All_Litigations_Count_in_noncampaign_view_NPE() throws Exception {
        entityDetailPage.filterNPE();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.ALL_CASES_NPE", subsidiaries));
    }

    @Test(description = "Verify All Litigation Count in campaign view Others", priority = 39)
    public void All_Litations_Count_in_campaign_view_Others() throws Exception {
        entityDetailPage.filterOthers();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ALL_CASES_OTHERS", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Litigation Plaintiff Count in campaign view Others", priority = 40, enabled = false)
    public void Litigation_as_Plaintiff_Count_in_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_PLAINTIFF_CASES_OTHERS", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Litigation Defendant Count in campaign view Others", priority = 41, enabled = false)
    public void Litigation_as_Defendant_Count_in_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_DEFENDANT_CASES_OTHERS", subsidiaries));
    }

    @Test(description = "Verify All Active Litigation Count in campaign view Others", priority = 42)
    public void ACTIVE_Litigation_Count_in_campaign_view_Others() throws Exception {
        entityDetailPage.filterActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_CASES_OTHERS", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Active Litigation as Plaintiff Count in campaign view Others", priority = 43, enabled = false)
    public void Active_Litigation_as_Plaintiff_Count_in_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_PLAINTIFF_CASES_OTHERS", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Active Litigation as Defendant Count in campaign view Others", priority = 44, enabled = false)
    public void Active_Litigation_Defendant_Count_in_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_ACTIVE_DEFENDANT_CASES_OTHERS", subsidiaries));
    }

    @Test(description = "Verify All Inactive Litigation Count in campaign view Others", priority = 45)
    public void INACTIVE_Litigation_Count_in_campaign_view_Others() throws Exception {
        entityDetailPage.filterInActiveCases();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_CASES_OTHERS", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Inactive Litigation as Plaintiff Count in campaign view Others", priority = 46, enabled = false)
    public void Inactive_Litigation_as_Plaintiff_Count_in_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litPlaintiffCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_PLAINTIFF_CASES_OTHERS", subsidiaries));
    }

    // TODO Enable below test, Once DS-1063 is done
    @Test(description = "Verify Inactive Litigation as Defendant Count in campaign view Others", priority = 47, enabled = false)
    public void Inactive_Litigation_as_Defendant_Count_in_campaign_view_Others() throws Exception {
        assertEquals(entityDetailPage.litDefendantTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.CAMP_INACTIVE_DEFENDANT_CASES_OTHERS", subsidiaries));
    }

    @Test(description = "Veify All Litigation Count in non campaign view Others", priority = 48)
    public void All_Litigations_Count_in_noncampaign_view_Others() throws Exception {
        entityDetailPage.changeCampaignView();
        entityDetailPage.filterOthers();
        assertEquals(entityDetailPage.litAllCasesTabLink.getIntData(),
                sqlProcessor.getResultCount("EntityDetail.ALL_CASES_OTHERS", subsidiaries));
    }

}
