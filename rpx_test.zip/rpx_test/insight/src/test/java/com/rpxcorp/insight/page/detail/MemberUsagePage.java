package com.rpxcorp.insight.page.detail;

import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import org.openqa.selenium.Keys;

public class MemberUsagePage extends BaseDetailPage {

    public MemberUsagePage() {
        this.url = new PageUrl("admin/metrics/member_scoreboard");
    }

    // WAIT FOR ITC DETAIL PAGE
    @Override
    public boolean at() {
        waitForLoading();
        return summaryHeader.waitUntilVisible();
    }

    public final Element summaryHeader = $(".summary_header");
    public final Tabs tabTitle = $(".tabs.top-tab-ul>.tab-title",Tabs.class);
    public void selectTabTitle(String tabName){
        tabTitle.select(tabName);
        waitForLoading();
    }
    public final Element activeTabTitle = $(".tabs.top-tab-ul>.tab-title.active");
    public final Element insightSummaryCards = $("div.insight_summary_cards>.cards-row div.container .header");
    public final Element contentSummaryCards = $("div.content_summary_cards>.cards-row div.container .header");
    public final Element memberReqSummaryCards = $("div.member_requests_summary_cards>.cards-row div.container .header");
    public final Element PQISummaryCards = $("div.pqi_summary_cards>.cards-row div.container .header");

    public final Element insightSummaryCardsContent = $("div.insight_summary_cards>.cards-row");

    public final Element test=$("div.member-select div.filter-dropdown-column:has(label:contains('Owner'))");

    public final Element ownerFilterArrow=$("div.member-select div.filter-dropdown-column:has(label:contains('Owner')) div.select2-container>a>span.select2-arrow");
    public final Element filterInput=$("div.select2-drop-active input:visible");
    public void selectOwnerFilter(String ownerName) throws  Exception{
        Thread.sleep(2000);
        ownerFilterArrow.click();
        filterInput.waitUntilVisible();
        filterInput.sendKeys(ownerName+ Keys.ENTER);
        Thread.sleep(2000);
        waitForLoading();
    }

    public final Element memberFilterArrow=$("div.member-select div.filter-dropdown-column:has(label:contains('Member')) div.select2-container>a>span.select2-arrow");
    public void selectMemberFilter(String memberName) throws  Exception{
        Thread.sleep(2000);
        memberFilterArrow.click();
        filterInput.waitUntilVisible();
        filterInput.sendKeys(memberName+ Keys.ENTER);
        Thread.sleep(2000);
        waitForLoading();
    }

    public final Element periodIcon = $("div#date-range-selector img");
    public void selectDateRangeFilter(String dateRange) throws  Exception {
        periodIcon.click();
        $("div.daterangepicker .ranges ul>li:contains('"+dateRange+"')").waitUntilVisible();
        $("div.daterangepicker .ranges ul>li:contains('"+dateRange+"')").click();
        Thread.sleep(2000);
        waitForLoading();

    }

    public final Tabs summaryCards = $(".tabs.top-tab-ul>.tab-title",Tabs.class);

    public void clickSummaryCards(String headerName){
        $("div.header-row:has(div:contains('"+headerName+"')):visible").click();
        waitForLoading();
    }


    public final Element memberDetailsHeader = $("div.summary_member_details_column .container .header_val");


}

