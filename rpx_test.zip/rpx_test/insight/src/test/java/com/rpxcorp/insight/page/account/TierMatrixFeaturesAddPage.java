package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

import java.util.Map;

public class TierMatrixFeaturesAddPage extends BasePage {

	public TierMatrixFeaturesAddPage() {
		this.url = new PageUrl("admin/tier_matrices/new");
	}

	@Override
	public boolean at() {

		return saveBtn.waitUntilVisible();
	}

	public final Element titleTextBox = $("#tier_matrix_title");
	public final Element toolTipHeaderTextBox = $("#tier_matrix_tooltip_header");
	public final Element toolTipTextBox = $("#tier_matrix_tooltip_text");
	public final Element learnMoreTextBox = $("#tier_matrix_learn_more_link");
	public final Element featureOrderTextBox = $("#tier_matrix_feature_order");

	public final Element basicAvailableCheckBox = $("#tier_matrix_tier_matrix_subscriptions_attributes_0_available");
	public final Element basicDisplayTextBox = $("#tier_matrix_tier_matrix_subscriptions_attributes_0_display_text");
	public final Element plusAvailableCheckBox = $("#tier_matrix_tier_matrix_subscriptions_attributes_1_available");
	public final Element plusDisplayTextBox = $("#tier_matrix_tier_matrix_subscriptions_attributes_1_display_text");
	public final Element primeAvailableCheckBox = $("#tier_matrix_tier_matrix_subscriptions_attributes_2_available");
	public final Element primeDisplayTextBox = $("#tier_matrix_tier_matrix_subscriptions_attributes_2_display_text");
	public final Element eliteAvailableCheckBox = $("#tier_matrix_tier_matrix_subscriptions_attributes_3_available");
	public final Element eliteDisplayTextBox = $("#tier_matrix_tier_matrix_subscriptions_attributes_3_display_text");
	public final Element memberAvailableCheckBox = $("#tier_matrix_tier_matrix_subscriptions_attributes_4_available");
	public final Element memberDisplayTextBox = $("#tier_matrix_tier_matrix_subscriptions_attributes_4_display_text");
	public final Element saveBtn = $("[name=save_tier_matrix_changes]");


	public void addFeature(Map<String, String> data) {
		titleTextBox.sendKeys(data.get("title"));
		toolTipHeaderTextBox.sendKeys(data.get("tooltip_header"));
		toolTipTextBox.sendKeys(data.get("tooltip_text"));
		learnMoreTextBox.sendKeys(data.get("learnmore"));
		basicDisplayTextBox.sendKeys(data.get("basic_displaytext"));
		plusDisplayTextBox.sendKeys(data.get("plus_displaytext"));
		primeDisplayTextBox.sendKeys(data.get("prime_displaytext"));
		eliteDisplayTextBox.sendKeys(data.get("elite_displaytext"));
		memberDisplayTextBox.sendKeys(data.get("member_displaytext"));
		if(data.get("basic_available") !=null & data.get("basic_available").equalsIgnoreCase("yes")) {
			basicAvailableCheckBox.click();
		}
		if(data.get("plus_available") !=null & data.get("plus_available").equalsIgnoreCase("yes")) {
			plusAvailableCheckBox.click();
		}
		if(data.get("prime_available") !=null & data.get("prime_available").equalsIgnoreCase("yes")) {
			primeAvailableCheckBox.click();
		}
		if(data.get("elite_available") !=null & data.get("elite_available").equalsIgnoreCase("yes")) {
			eliteAvailableCheckBox.click();
		}
		if(data.get("member_available") !=null & data.get("member_available").equalsIgnoreCase("yes")) {
			memberAvailableCheckBox.click();
		}
		saveBtn.click();
	}
}
