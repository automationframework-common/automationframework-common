package com.rpxcorp.insight.page;

import com.rpxcorp.testcore.element.Element;
import org.openqa.selenium.By;

public class StaticSignInPage extends BasePage {

    @Override
    public boolean at() {
        return signInPanel.waitUntilVisible();
    }

    public final Element signInPanel = $("div.subscription-promo-message a:contains('Sign In')");

}
