/**
 * 
 */
package com.rpxcorp.insight.page.detail;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

/**
 * @author gandhimathia
 *
 */
public class AssertionDetailPage extends BasePage {
    public AssertionDetailPage() {
        this.url = new PageUrl("assertions/{ID}");
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.rpxcorp.insight.page.BasePage#at()
     */
    @Override
    public boolean at() {
        // TODO Auto-generated method stub
        waitForPageLoad();
        return false;
    }

    public final Element documentDownload = $("#assertion_overview .large-12.columns .details_value a");

}
