package com.rpxcorp.insight.page.detail;

import com.rpxcorp.insight.module.ListPanel;
import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

import java.util.List;

public class AcquisitionDetailPage extends BaseDetailPage {

        public AcquisitionDetailPage() {
        this.url = new PageUrl("acquisitions/{ID}");
    }

    @Override
    public boolean at() {
        detailPageTitle.waitUntilVisible();
        waitForPageLoad();
        return timeline_chart.waitUntilVisible();
    }

    /* CONTENT OF Acquisition DETAIL PAGE * */
    public final StaticContent header_info = $(".header-info.subtitle", (Configure<StaticContent>) dataForm ->
        {
            dataForm.content("received_date", "li:contains(Received)");
            dataForm.content("priority", "li:contains(Priority)");
            dataForm.content("stage", "li:contains(Stage)");
        }
    );

    public final StaticContent overview_status = $(".panel-metrics", (Configure<StaticContent>) dataForm ->
        {
            dataForm.content("us_patents", ".metrics_card:contains(US Patents) .count");
            dataForm.content("int_patents", ".metrics_card:contains(International Patents) .count");
            dataForm.content("us_applications", ".metrics_card:contains(US Applications) .count");
            dataForm.content("int_applications", ".metrics_card:contains(International Applications) .count");
        }
    );
    public final StaticContent acquition_detail = $(".names", (Configure<StaticContent>) dataForm ->
        {
            dataForm.content("bid_deadline", "strong:contains(Bid)+span");
            dataForm.content("analyst_name", "strong:contains(Analysis)+span");
            dataForm.content("owner_name", "strong:contains(Lead)+span");
        }
    );
    public final Element timeline_chart = $(".highcharts-container");
    public final Element assignees_name = $(".current-assignee-title span");
    public final Element assignee_statistics=$("#current_assignee h8.patent-title");
    public final Element sellerBroker_statistics=$("#seller_broker_information h8.patent-title");

    public final Table assignee_table = $(".assignee-table", (Configure<Table>) table ->
        {
            table.uniqueId("td:nth-child(1)");
            table.displayedRecords(".assignee-table tbody tr:not([style*='none'])");
            table.viewAllLink(By.xpath("//div[@id='current_assignee']//a[contains(text(),'View All')]"));
			table.viewLessLink(By.xpath("//div[@id='current_assignee']//a[contains(text(),'View Less')]"));
        }
    );

    public final Table assignmentsTable = $("#assignments .assignments-table", (Configure<Table>) table ->
		{
			table.uniqueId("td>a");
			table.displayedRecords(".assignments-table tbody tr:not([style*='none'])");
			table.viewAllLink(By.xpath("//div[@id='assignments']//a[contains(text(),'View All')]"));
			table.viewLessLink(By.xpath("//div[@id='assignments']//a[contains(text(),'View Less')]"));
		}
	);

    public final Table representative_claims = $("#representative_claim_records", (Configure<Table>) table ->
        {
            table.uniqueId("p:nth-child(odd)>a");
            table.column("patent_number", "p:nth-child(odd)>a");
            table.column("description", " p:nth-child(even)");
            table.viewAllLink(By.xpath("//div[@id='#representative_claim_records']//a[contains(text(),'View All')]"));
            table.viewLessLink(By.xpath("//div[@id='#representative_claim_records']//a[contains(text(),'View Less')]"));
        }
    );
    public final Table seller_broker_info = $("#seller_broker_information", (Configure<Table>) table ->
        {
            table.uniqueId("td:nth-child(1)");
            table.displayedRecords("#seller_broker_information tbody tr:not([style*='none'])");
            table.viewAllLink(By.xpath("//div[@id='seller_broker_information']//a[contains(text(),'View All')]"));
            table.viewLessLink(By.xpath("//div[@id='seller_broker_information']//a[contains(text(),'View Less')]"));
        }
    );
    public final Element document_section = $("#documents .panel>p");
    public final Element document_section_table = $(".acq-documents-table tbody td:nth-of-type(1)");
    public final Element sellerMaterial_document_title = $(
            "#documents .panel table tr:nth-of-type(1)>td:nth-of-type(1)");
    public final Element sellerMaterial_document_link = $(
            "#documents .panel table tr:nth-of-type(1)>td:nth-of-type(3) a");

    public final Table patent_information = $(".patents-table", (Configure<Table>) table ->
            table.uniqueId("td:nth-child(3)>a")
    );
    public final Element tags = $("#tags", (Configure<ListPanel>) list ->
            list.dataKey("li")
    );


    public String getDocumentData() {
        if(document_section_table.isDisplayed())
            return document_section_table.getText();

        return document_section.getText();
    }
	public int getSoldPortfolios(List<String> soldData) {
		int row=0;
		for(String sold:soldData) {
			if(sold.equalsIgnoreCase("YES")) {
				row++;
			}
		}

		return row;
	}

    public Object getAssignees(){
        if(assignees_name.isDisplayed())
            return assignees_name.getData();
        else
            return "";
    }

}
