package com.rpxcorp.insight.test.functional;

import java.util.ArrayList;
import java.util.List;

import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.Test;

import com.rpxcorp.insight.page.account.AdminAlertEventsPage;
@Authenticate(role = "ADMIN")
public class AdminAlertEventsTest extends BaseFuncTest{
	
	AdminAlertEventsPage adminAlertEventsPage;

	@Test(priority=1,groups="P3", description="Verify Event Name Facet Filter")
	public void checkEventNameFacetFilter() throws Exception {		
		List<String> expectedEvent=new ArrayList<String>();
		expectedEvent.add("New Patent Assignment");
		to(adminAlertEventsPage);
		adminAlertEventsPage.event_name.selectOptionFromSearchResultsFacetSection("Event Name", "New Patent Assignment");
		adminAlertEventsPage.loading.waitUntilInvisible();
		assertEquals(adminAlertEventsPage.getDistinctCaseEventTypesFromResults(),expectedEvent);
	}
	
	@Test(priority=2,groups="P3", description="Verify Event Type Facet Filter")
	public void checkEventTypeFacetFilter() throws Exception {		
		List<String> expectedEventTitle=new ArrayList<String>();
		expectedEventTitle.add("Prior Art");
		to(adminAlertEventsPage);
		adminAlertEventsPage.event_type.selectOptionFromSearchResultsFacetSection("Type", "Prior_art");
		adminAlertEventsPage.loading.waitUntilInvisible();
		assertEquals(adminAlertEventsPage.getDistinctEventTitlesFromResults(),expectedEventTitle);
	}
}
