package com.rpxcorp.insight.page.search;

import com.rpxcorp.insight.module.Facet;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;

public class AllSearchPage extends BasePage {
    public AllSearchPage() {
        this.url = new PageUrl("advanced_search/search_all") {
            {
                param("GROUPED", "grouped");
                param("CURRENT_SEARCH", "searchq");
                param("HEADER_TYPE","header_search_type");
                param("SEARCH_ALL_PATH","search_all_path");
                param("TAB_PATH","tab_path");
            }
        };
    }

    public final Element showMore = $("#search_results_replaced_content span.show-more:visible()");
    public final Element showLess = $("#search_results_replaced_content span.show-more:visible()");
    public void clickShowMoreLinkInAllSearchResultsPage(){
        showMore.waitUntilVisible();
        if(!showLess.isDisplayed()){
            showMore.click();
            showLess.waitUntilVisible();
        }

    }

    @Override
    public boolean at() {
        waitForPageLoad();
        return current_search.waitUntilVisible();
    }

    /* CONTENT OF ALL SEARCH PAGE * */
    public final Element login_share_link_btn = $("a[title='Login Share Link']");
    public final Facet current_search = new Facet("section.filters:nth-of-type(1)");
    public final Element enity_results_count = $("#all_search_entities .result-title>span.count:nth-child(1)");
    public final Element ultimate_parent_count = $("#all_search_entities .result-title>span.count:nth-child(2)");
    public final Table entity_table = $("#all_search_entities table.results", (Configure<Table>) table ->
        {
            table.column("Ultimate Parent Name", "tr a.title");
            table.column("Subsidaries", ".group_stats td:nth-child(2)");
            table.column("Plaintiff", ".group_stats td:nth-child(3)");
            table.column("Defendant", ".group_stats td:nth-child(4)");
            table.column("Patent Asserted", ".group_stats td:nth-child(5)");
            table.column("Search Result", ".result-count");
        }
    );

    public final Element campaign_count = $("#all_search_litigations .result-title>span.count:nth-child(1)");
    public final Element patent_litigations_count = $("#all_search_litigations .result-title>span.count:nth-child(2)");
    public final Element PTAB_Petition_count = $("#all_search_litigations .result-title>span.count:nth-child(3)");
    public final Element ITC_invetigation_count = $("#all_search_litigations .result-title>span.count:nth-child(4)");
    public final Table litigation_table = $("#all_search_litigations table.results", (Configure<Table>) table ->
        {
            table.column("Campaign Name", "a.litigation_campaign_name");
            table.column("Cases", ".group_stats td:nth-child(5)");
            table.column("Search Result", ".result-count");
        }
    );

    public final Element patent_results_count = $("#all_search_patents .result-title>span.count:nth-child(1)");
    public final Element patent_families_count = $("#all_search_patents .result-title>span.count:nth-child(2)");
    public final Table patent_table = $("#all_search_litigations table.results", (Configure<Table>) table ->
        {
            table.column("Family Title", "tr a.title");
            table.column("US Patents", ".group_stats td:nth-child(3)");
            table.column("US Applications", ".group_stats td:nth-child(4)");
            table.column("Search Result", ".result-count");
        }
    );

    public final Element acquisition_opportunities_count = $("#search_results_replaced_content a.marketplaces_count");
    public final Table marketplace_result = $("#all_search_marketplaces table.results", (Configure<Table>) table ->
        {
            table.column("Porttfolio Name", "tr a.title");
            table.column("US Patents", ".group_stats td:nth-child(4)");
            table.column("Patents", ".result-count");
        }
    );

    public final Element patents_count = $("#all_search_portfolios h2>span.count:nth-child(1)");
    public final Element portfolios_count = $("#search_results_replaced_content a.portfolios_count");
    public final Table portfolio_result = $("#all_search_portfolios table.results", (Configure<Table>) table ->
        {
            table.column("Porttfolio Name", "tr a.title");
            table.column("Assets", ".group_stats td:nth-child(3)");
            table.column("Patents", ".result-count");
        }
    );

    public final Element news_count = $("#search_results_replaced_content a.news_count");
    public final Table news_table = $(".articles_list", (Configure<Table>) table ->
        {
            table.column("News Title", ".panel h5");
            table.column("Date", ".panel .date");
        }
    );
  //ROLE AUTH
  public final Element disabled_Lit_grouped_view_Btn=$(".group_switch input[disabled='disabled']+label");
}
