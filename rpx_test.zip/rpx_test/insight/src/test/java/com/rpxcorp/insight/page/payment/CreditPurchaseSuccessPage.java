package com.rpxcorp.insight.page.payment;

import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class CreditPurchaseSuccessPage extends BasePage {

    @Override
    public boolean at() {
        purchaseSummaryPanel.waitUntilVisible();
        return true;
    }

    // PURCHASE SUMMARY
    public final Element purchaseSummaryPanel = $(".purchase_summary");

    public final StaticContent purchaseSummary = $(".purchase_summary ", (Configure<StaticContent>) dataForm ->
        {
            dataForm.content("date", " div:nth-of-type(1) div:not([class*='title'])");
            dataForm.content("confirmation_number", " div:nth-of-type(2) div:not([class*='title'])");
            dataForm.content("purchase_type", " div:nth-of-type(3) div:not([class*='title'])");
            dataForm.content("amount_charged", " div:nth-of-type(4) div:not([class*='title'])");
        }
    );
    public final Element purchaseDate = $(By.xpath("//div[@class='purchase_summary']//div[text()='Purchase Date:']/../div[2]"));

    public final Element activateMessage = $(By.xpath("//p[@class='thank_you'][1]"));
    public final Element timelineStatusBar = $("span[class='meter secondary current_stage']");
    public final Element timeline_bar = $(".progress.small-centered.columns.small-6.round");
}
