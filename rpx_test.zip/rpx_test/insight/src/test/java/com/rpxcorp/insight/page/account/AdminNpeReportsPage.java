package com.rpxcorp.insight.page.account;

import org.openqa.selenium.By;

import com.rpxcorp.insight.module.DatePicker;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

/**
 * This file has Admin NPE Reports Page related elements and actions
 * 
 * @author pusulurip
 *
 */
public class AdminNpeReportsPage extends BasePage {
    public AdminNpeReportsPage() {
        this.url = new PageUrl("admin/npe_reports");
    }

    @Override
    public boolean at() {
        addNpeReportButton.waitUntilVisible();
        return npeReportsTitle.waitUntilVisible();
    }

    public final Element npeReportsTitle = $("#content .section-title");
    public final Element addNpeReportButton = $("a[href='/admin/npe_reports/new']");
    public final Element Mnthly_Npe_Report=$(By.xpath("//input[@value='Monthly NPE Report']"));
    public final Element preview_Npe_Email=$(".large-12.columns a.button.right");
    public final Table npeReportsTable = $(".large-12.columns table", Table.class);
    
    public final Element reportUploadPageTitle = $(".large-12 h1");
    public final Element reportUploadPageSections = $(".new_npe_report label");        
    public final DatePicker inputReportDate = new DatePicker("#startDate");
    //Publish Report 
    public final DatePicker selectMonthForPublish= new DatePicker("#selected_month");
    public final Element inputFile = $("#npe_report_file");    
    public final Element sendNpePublicationEmail_checkbox=$("input#npe_report_send_npe_email");
    public final Element publishReportBtn = $("input[value='Publish Report']");
    public final Element alertFlashClose = $("#flash_name a.close");
    public final Element monthly_NPEReport=$("input[value='Monthly NPE Report']");
    public final Element block_UI=$("div.blockUI.blockMsg.blockPage");
    public final Element emails=$(".admin-navbar-items>li:nth-of-type(3)>a");
    public final Element monthly_Npe_Update=$(".admin-navbar-items li>a[href='/admin/npe_reports/preview_report']");
    
    
    public void navigateToUploadNpeReports() {
        addNpeReportButton.waitUntilVisible();
        addNpeReportButton.click();
        addNpeReportButton.waitUntilInvisible();
    }

    public void inputFile(String filePath) {
        inputFile.waitUntilVisible();
        inputFile.clear();
        inputFile.sendKeys(filePath);
    }    
    
    public String getFlashMessage() {
        alertMessage.waitUntilVisible();
        return alertMessage.getText().trim().replace("\\n", "").replaceAll("\nx", "");
    }
    
    public void expand_Emails_Menu() {
    	emails.waitUntilVisible();
    	emails.clickAndHold();
    }
}
