package com.rpxcorp.insight.page;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class ForgetPasswordPage extends BasePage {

    public ForgetPasswordPage() {
        this.url = new PageUrl("users/password/new");
    }

    @Override
    public boolean at() {
        return email_textbox.waitUntilClickable();
    }

    public final Element email_textbox = $("#password_reset_form #user_email");
    public final Element forgetPasswordForm = $("#password_reset_form");
    public final Element reset_pswd_btn = $("input[value='Send me reset password instructions']");
    public final String flashText = "You will receive an email with instructions about how to reset your password in a few minutes.";
    public final Element errorMsg = $("div.errors");
    public final String errorMsgText = "The email address you entered is not yet taken.";

    public void submitPassword(String email) {
        email_textbox.waitUntilVisible();
        email_textbox.sendKeys(email);
        reset_pswd_btn.click();
    }

}
