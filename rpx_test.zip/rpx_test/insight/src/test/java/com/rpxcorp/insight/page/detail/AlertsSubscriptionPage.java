package com.rpxcorp.insight.page.detail;

import com.rpxcorp.insight.module.CheckList;
import com.rpxcorp.insight.module.Radio;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class AlertsSubscriptionPage extends BasePage {
    {
        this.baseSelector = "#alert-modal";
    }

    @Override
    public boolean at() {
        waitForPageLoad();
        title.waitUntilVisible();
        return caseEventsCheckList.waitUntilVisible();
    }

    public final Element title = $(".follow-title");
    public final Element errorMessage = $(".errors");
    private final Element selectAllEventsCheckBox = $("tr:contains(Events) .checkAll");
    private final Element selectRpxReportsEventsCheckBox = $("tr:contains(Reports) .checkAll");
    public final CheckList caseEventsCheckList = (CheckList) $("[class^='alert_events']:visible", CheckList.class);
    public final CheckList rpxReportsEventsCheckList = (CheckList) $("thead:contains(RPX Reports)+tbody:visible", CheckList.class);
    public final Radio frequencyRadio = (Radio) $("[class='alert_frequencies']", Radio.class);
    public final Element createAlertBtn = $("input[value='Create Alert']");
    public final Element updateAlertBtn = $("input[value='Update Alert']");
    private final Element deleteAlertBtn = $(".delete_alert_in_modal");
    
    //Entity Alert Subscription
    public final CheckList ptabEventsCheckList = (CheckList) $("thead:contains(PTAB Events)+tbody:visible", CheckList.class);
    public final CheckList itcEventsCheckList = (CheckList) $("thead:contains(ITC Events)+tbody:visible", CheckList.class);
    public final CheckList FederalCircuitEventsCheckList = (CheckList) $("thead:contains(Federal Circuit Events)+tbody" , CheckList.class);
    public final CheckList includeEntityFamily = (CheckList) $(".alert_include_family", CheckList.class);
    private final Element selectAllPtabEventsCheckBox = $("thead:contains(PTAB) .checkAll");
    private final Element selectAllItcEventsCheckBox = $("thead:contains(ITC) .checkAll");
    private final Element selectAllFCEventsCheckBox = $("thead:contains(Federal Circuit Events) .checkAll");
    
    public void createAlert() {
    	createAlertBtn.waitUntilVisible();
        createAlertBtn.click();
        title.waitUntilInvisible();
    }

    public void updateAlert() {
    	updateAlertBtn.waitUntilVisible();
        updateAlertBtn.click();
        title.waitUntilInvisible();
    }

    public void deleteAlert() {
    	deleteAlertBtn.waitUntilVisible();
        deleteAlertBtn.click();
        acceptAlert();
        title.waitUntilInvisible();
    }

    public void selectAllEvent() {
    	if (selectAllEventsCheckBox.isSelected()) {
            selectAllEventsCheckBox.click();
            selectAllEventsCheckBox.waitUntilElementUnSelected();
            selectAllEventsCheckBox.click();
        } else {
            selectAllEventsCheckBox.click();
        }
    }
    
    public void selectAllReportsEvent() {
    	if (selectRpxReportsEventsCheckBox.isSelected()) {
    		selectRpxReportsEventsCheckBox.click();
    		selectRpxReportsEventsCheckBox.waitUntilElementUnSelected();
    		selectRpxReportsEventsCheckBox.click();
        } else {
        	selectRpxReportsEventsCheckBox.click();
        }
    }
    
    public void selectAllPtabEvents() {
    	if (selectAllPtabEventsCheckBox.isSelected()) {
    		selectAllPtabEventsCheckBox.click();
    		selectAllPtabEventsCheckBox.waitUntilElementUnSelected();
    		selectAllPtabEventsCheckBox.click();
        } else {
        	selectAllPtabEventsCheckBox.click();
        }
    }
    
    public void selectAllItcEvents() {
    	if (selectAllItcEventsCheckBox.isSelected()) {
    		selectAllItcEventsCheckBox.click();
    		selectAllItcEventsCheckBox.waitUntilElementUnSelected();
    		selectAllItcEventsCheckBox.click();
        } else {
        	selectAllItcEventsCheckBox.click();
        }
    }

    public void selectAllFCEvents() {
        if (selectAllFCEventsCheckBox.isSelected()) {
            selectAllFCEventsCheckBox.click();
            selectAllFCEventsCheckBox.waitUntilElementUnSelected();
            selectAllFCEventsCheckBox.click();
        } else {
            selectAllFCEventsCheckBox.click();
        }
    }

    public void selectNoneEvent() {
    	if (selectAllEventsCheckBox.isSelected()) {
            selectAllEventsCheckBox.click();
        } else {
            selectAllEventsCheckBox.click();
            selectAllEventsCheckBox.waitUntilElementSelected();
            selectAllEventsCheckBox.click();
        }
    }
    
    public void selectNoneRpxReportsEvent() {
        selectRpxReportsEventsCheckBox.scrollAndFocus();
    	if (selectRpxReportsEventsCheckBox.isSelected()) {
    		selectRpxReportsEventsCheckBox.click();
        } else {
        	selectRpxReportsEventsCheckBox.click();
        	selectRpxReportsEventsCheckBox.waitUntilElementSelected();
        	selectRpxReportsEventsCheckBox.click();
        }
    }
    
    public void selectNonePtabEvent() {

        selectAllPtabEventsCheckBox.scrollAndFocus();
    	if (selectAllPtabEventsCheckBox.isSelected()) {
    		selectAllPtabEventsCheckBox.click();
        } else {
        	selectAllPtabEventsCheckBox.click();
        	selectAllPtabEventsCheckBox.waitUntilElementSelected();
        	selectAllPtabEventsCheckBox.click();
        }
    }
    
    public void selectNoneItcEvent() {
        selectAllItcEventsCheckBox.scrollAndFocus();
    	if (selectAllItcEventsCheckBox.isSelected()) {
    		selectAllItcEventsCheckBox.click();
        } else {
        	selectAllItcEventsCheckBox.click();
        	selectAllItcEventsCheckBox.waitUntilElementSelected();
        	selectAllItcEventsCheckBox.click();
        }
    }

    public void selectNoneFCEvent() {
        selectAllFCEventsCheckBox.scrollAndFocus();
        if (selectAllFCEventsCheckBox.isSelected()) {
            selectAllFCEventsCheckBox.click();
        } else {
            selectAllFCEventsCheckBox.click();
            selectAllFCEventsCheckBox.waitUntilElementSelected();
            selectAllFCEventsCheckBox.click();
        }
    }
}
