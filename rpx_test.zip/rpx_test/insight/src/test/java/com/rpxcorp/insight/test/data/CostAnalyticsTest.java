package com.rpxcorp.insight.test.data;
import java.sql.ResultSet;
import java.util.HashMap;

import com.rpxcorp.insight.page.visual_analytics.CostAnalyticsPage;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rpxcorp.testcore.util.SQLProcessor;

public class CostAnalyticsTest extends BaseDataTest {
	CostAnalyticsPage costAnalyticsPage;
	//String costAnalyticsUser = "cost_analytics.ba6f4fe1@mailosaur.io";
	String costAnalyticsUser = "asivalingam_c@rpxcorp.com";
	String costAnalyticsUserPwd = "Welcome1";

	@BeforeClass(alwaysRun = true)
	public void startBrowserAndLogin() throws Exception {
		this.dataDescription = "Cost Analytics";		
		sqlProcessor = SQLProcessor.getInstance();
		logoutAndLogin(costAnalyticsUser, costAnalyticsUserPwd);
		this.dataUrl = costAnalyticsPage.getDeclaredUrl();
		to(costAnalyticsPage);
	}

	@BeforeGroups(groups = "ptabs_analytics")
	public void selectPtabCostAnalytics() {
		to(costAnalyticsPage);
		costAnalyticsPage.searchPanelTabs.select("PTAB Cost Analytics");
	}

	@Test(priority = 1, groups = "ptabs_analytics", description = "Verify Ratio of Costs Per PTAB Petition Values")
	public void verifyRatioOfCostChart() throws Exception {
		costAnalyticsPage.ratioOfCostsperPtabPetitionChart.getLabelValue("counsel");

		assertEquals(costAnalyticsPage.ratioOfCostsperPtabPetitionChart.getLabelValue("counsel"),
				sqlProcessor.getSingleValue("CostAnalytics.RATIO_OF_COSTS_PER_PTAB_PETITION", "counsel"));
		assertEquals(costAnalyticsPage.ratioOfCostsperPtabPetitionChart.getLabelValue("expert"),
				sqlProcessor.getSingleValue("CostAnalytics.RATIO_OF_COSTS_PER_PTAB_PETITION", "expert"));
		assertEquals(costAnalyticsPage.ratioOfCostsperPtabPetitionChart.getLabelValue("filing"),
				sqlProcessor.getSingleValue("CostAnalytics.RATIO_OF_COSTS_PER_PTAB_PETITION", "filing"));	
	}	

	@Test(priority = 2, groups = "ptabs_analytics", dataProvider = "costTypeDataForOutcomeGraph", description = "Verify PTAB Petition Costs by Outcome")
	public void petitionCostByOutcome(String costType, String queryKey) throws Exception{
		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("cost_type", queryKey);		
		costAnalyticsPage.petitionCostsByOutcomeCostTypeRadio.selectValue(costType);
		ResultSet result = sqlProcessor.getResultData("CostAnalytics.PTAB_PETITION_COSTS_BY_OUTCOME", queryParams);		
		assertEquals(costAnalyticsPage.petitionCostsByOutcomeChart.getChartData("final_outcome"),
				sqlProcessor.getResultDataAsMultiMap(result, "final_outcome", "avg_cost", "litigation_count"));
	}

	@DataProvider
	public Object[][] costTypeDataForOutcomeGraph() {
		return new Object[][] {
				{ "cluster" , "Per cluster"},
				{ "petition" , "Per Petition"}
		};
	}

	@Test(priority = 2, groups = "ptabs_analytics", dataProvider = "costTypeDataForStageGraph", description = "Verify PTAB Petition Costs by Outcome")
	public void cumulativePTABPetitionCostByStage(String costType, String queryKey) throws Exception{
		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("cost_type", queryKey);	
		costAnalyticsPage.waitForLoading();
		costAnalyticsPage.petitionCostsByStageCostTypeRadio.selectValue(costType);

		ResultSet result = sqlProcessor.getResultData("CostAnalytics.CUMULATIVE_PTAB_PETITION_COST_BY_STAGE", queryParams);		
		assertEquals(costAnalyticsPage.petitionCostsByStageChart.getChartData("status"),
				sqlProcessor.getResultDataAsMultiMap(result, "status", "litigation_count", "ten_percentile", "fifty_percentile", "ninety_percentile"));
	}

	@DataProvider
	public Object[][] costTypeDataForStageGraph() {
		return new Object[][] {
				{ "Per Cluster" , "Per Cluster" },
				{ "Per Petition" , "Per Petition"}								
		};
	}

	@BeforeGroups(groups = "litigation_analytics")
	public void selectLitigationCostAnalytics() {
		costAnalyticsPage.searchPanelTabs.select("Litigation Cost Analytics");
	}

	@Test(priority = 2, groups = "litigation_analytics", dataProvider = "legalSettlementCost", description = "Verify Legal Cost by Accused Product Category")
	public void verifyLegalCostByPatentAndProductCategory(String costType, String categoryType, String category, String secondaryCategory) throws Exception {
		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("cost_type", costType);
		queryParams.put("category_type", categoryType);
		queryParams.put("category", category);	
		queryParams.put("secondary_category", secondaryCategory);

		costAnalyticsPage.selectPatentProductResolutionOptions(costType, categoryType, category, secondaryCategory);
		costAnalyticsPage.waitForLoading();

		ResultSet result = sqlProcessor.getResultData("CostAnalytics.LEGAL_SETTLEMENT_COST_TABLE", queryParams);
		assertEquals(costAnalyticsPage.patentProductResolutionChart.axisLabelValues("overall_cmpy_count")
				,sqlProcessor.getResultDataAsMultiMap(result, "bin_group", "litigation_count", "company_count", "mean", "legal_percentile_25", "legal_percentile_50",
						"legal_percentile_75", "legal_percentile_90"));					
	}

	@Test(priority = 2, groups = "litigation_analytics",dataProvider = "legalSettlementCost", description = "Verify Legal Cost by Accused Product Category Tooltip")
	public void verifyLegalCostByPatentAndProductCategoryTooltip(String costType, String categoryType, String category, String secondaryCategory) throws Exception {
		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("cost_type", costType);
		queryParams.put("category_type", categoryType);
		queryParams.put("category", category);	
		queryParams.put("secondary_category", secondaryCategory);

		costAnalyticsPage.selectPatentProductResolutionOptions(costType, categoryType, category, secondaryCategory);
		costAnalyticsPage.waitForLoading();
		ResultSet result = sqlProcessor.getResultData("CostAnalytics.LEGAL_SETTLEMENT_COST_TOOLTIP", queryParams);
		assertEquals(costAnalyticsPage.patentProductResolutionChart.getTooltipData("overall_cmpy_count"),
				sqlProcessor.getResultDataAsMap(result,"bin_group", "percentile"));
	}

	@DataProvider
	public Object[][] legalSettlementCost(){
		return new Object[][]{
				{"Legal", "Patent", "All", "All"}, {"Legal", "Patent", "Communications", "All"}, {"Legal", "Patent", "Communications", "Messaging and Collaboration"},
				{"Legal", "Patent", "Communications", "VoIP"}, {"Legal", "Patent", "Communications", "Wireless"}, {"Legal", "Patent", "Communications", "Wireline"},
				{"Legal", "Patent", "Hardware", "All"}, {"Legal", "Patent", "Hardware", "Audiovisual"}, {"Legal", "Patent", "Hardware", "Automotive"}, 
				{"Legal", "Patent", "Hardware", "Computer/PC"}, {"Legal", "Patent", "Hardware", "Computer Peripherals"}, {"Legal", "Patent", "Hardware", "Computer/Server"}, 
				{"Legal", "Patent", "Hardware", "Consumer Products"}, {"Legal", "Patent", "Hardware", "Displays/TVs"}, {"Legal", "Patent", "Hardware", "Gaming Platforms"}, 
				{"Legal", "Patent", "Hardware", "Handset"}, {"Legal", "Patent", "Hardware", "Imaging"}, {"Legal", "Patent", "Hardware", "LBS"}, 
				{"Legal", "Patent", "Hardware", "Power"}, {"Legal", "Patent", "Hardware", "Printers/MFPs"}, {"Legal", "Patent", "Hardware", "Sanner, Copier, and Fax"}, {"Legal", "Patent", "Hardware", "Smartcards"}, 
				{"Legal", "Patent", "Hardware", "Storage"}, {"Legal", "Patent", "Hardware", "Telephony"}, {"Legal", "Patent", "Hardware", "Wireless"}, 
				{"Legal", "Patent", "Networking", "All"}, {"Legal", "Patent", "Networking", "Application and Content Delivery"}, {"Legal", "Patent", "Networking", "Cable"},
				{"Legal", "Patent", "Networking", "Cellular"}, {"Legal", "Patent", "Networking", "DSL"}, {"Legal", "Patent", "Networking", "NICs"},
				{"Legal", "Patent", "Networking", "Security"}, {"Legal", "Patent", "Networking", "Surveillance/Monitoring"},
				{"Legal", "Patent", "Networking", "Switch/Router and Gateways"}, {"Legal", "Patent", "Networking", "Systems/Network Management"}, {"Legal", "Patent", "Networking", "VoIP"},
				{"Legal", "Patent", "Networking", "Wireless"}, {"Legal", "Patent", "Semiconductors", "All"}, {"Legal", "Patent", "Semiconductors", "Communications"}, 
				{"Legal", "Patent", "Semiconductors", "Displays/TVs"}, {"Legal", "Patent", "Semiconductors", "Fabrication/Packaging/A&T"}, {"Legal", "Patent", "Semiconductors", "Imaging/Sensors"}, 
				{"Legal", "Patent", "Semiconductors", "Logic"}, {"Legal", "Patent", "Semiconductors", "Memory"}, {"Legal", "Patent", "Semiconductors", "Power"}, 
				{"Legal", "Patent", "Semiconductors", "RF/Component"}, {"Legal", "Patent", "Services", "All"}, {"Legal", "Patent", "Services", "Cloud"}, 
				{"Legal", "Patent", "Services", "Content"}, {"Legal", "Patent", "Services", "Ecommerce"}, {"Legal", "Patent", "Services", "Finance"}, 
				{"Legal", "Patent", "Software", "All"}, {"Legal", "Patent", "Software", "Application"}, {"Legal", "Patent", "Software", "Ecommerce"}, 
				{"Legal", "Patent", "Software", "Enterprise"}, {"Legal", "Patent", "Software", "Gaming"}, {"Legal", "Patent", "Software", "LBS"}, 
				{"Legal", "Patent", "Software", "Media Content and Distribution"}, {"Legal", "Patent", "Software", "Platform/OS"}, {"Legal", "Patent", "Software", "Printers/MFPs"}, 
				{"Legal", "Patent", "Software", "Productivity"}, {"Legal", "Patent", "Software", "Search and Advertising"}, {"Legal", "Patent", "Software", "Security"}, 
				{"Legal", "Patent", "Software", "Storage"}, {"Legal", "Patent", "Software", "Systems/Network Management"}, {"Legal", "Patent", "Software", "Web"},
				{"Legal", "Accused Product", "All", "All"}, {"Legal", "Accused Product", "Communications", "All"}, {"Legal", "Accused Product", "Communications", "Messaging and Collaboration"},
				{"Legal", "Accused Product", "Communications", "VoIP"}, {"Legal", "Accused Product", "Communications", "Wireless"}, {"Legal", "Accused Product", "Communications", "Wireline"},								
				{"Legal", "Accused Product", "Hardware", "All"}, {"Legal", "Accused Product", "Hardware", "Audiovisual"}, {"Legal", "Accused Product", "Hardware", "Automotive"}, 				
				{"Legal", "Accused Product", "Hardware", "Computer/PC"}, {"Legal", "Accused Product", "Hardware", "Computer Peripherals"}, {"Legal", "Accused Product", "Hardware", "Computer/Server"}, 
				{"Legal", "Accused Product", "Hardware", "Consumer Products"}, {"Legal", "Accused Product", "Hardware", "Displays/TVs"}, {"Legal", "Accused Product", "Hardware", "Gaming Platforms"}, 
				{"Legal", "Accused Product", "Hardware", "Handset"}, {"Legal", "Accused Product", "Hardware", "Imaging"}, {"Legal", "Accused Product", "Hardware", "LBS"}, 
				{"Legal", "Accused Product", "Hardware", "Power"}, {"Legal", "Accused Product", "Hardware", "Printers/MFPs"}, {"Legal", "Accused Product", "Hardware", "Sanner, Copier, and Fax"}, 
				{"Legal", "Accused Product", "Hardware", "Smartcards"}, {"Legal", "Accused Product", "Hardware", "Storage"}, {"Legal", "Accused Product", "Hardware", "Telephony"}, 
				{"Legal", "Accused Product", "Hardware", "Wireless"}, {"Legal", "Accused Product", "Networking", "All"}, {"Legal", "Accused Product", "Networking", "Application and Content Delivery"}, 
				{"Legal", "Accused Product", "Networking", "Cable"}, {"Legal", "Accused Product", "Networking", "Cellular"}, {"Legal", "Accused Product", "Networking", "DSL"}, 
				{"Legal", "Accused Product", "Networking", "NICs"}, {"Legal", "Accused Product", "Networking", "Security"}, {"Legal", "Accused Product", "Networking", "Surveillance/Monitoring"},
				{"Legal", "Accused Product", "Networking", "Switch/Router and Gateways"}, {"Legal", "Accused Product", "Networking", "Systems/Network Management"}, {"Legal", "Accused Product", "Networking", "VoIP"},
				{"Legal", "Accused Product", "Networking", "Wireless"},	{"Legal", "Accused Product", "Semiconductors", "All"}, {"Legal", "Accused Product", "Semiconductors", "Communications"}, 
				{"Legal", "Accused Product", "Semiconductors", "Displays/TVs"}, {"Legal", "Accused Product", "Semiconductors", "Fabrication/Packaging/A&T"}, {"Legal", "Accused Product", "Semiconductors", "Imaging/Sensors"}, 
				{"Legal", "Accused Product", "Semiconductors", "Logic"}, {"Legal", "Accused Product", "Semiconductors", "Memory"}, {"Legal", "Accused Product", "Semiconductors", "Power"}, 
				{"Legal", "Accused Product", "Semiconductors", "RF/Component"},	{"Legal", "Accused Product", "Services", "All"}, {"Legal", "Accused Product", "Services", "Cloud"}, 
				{"Legal", "Accused Product", "Services", "Content"}, {"Legal", "Accused Product", "Services", "Ecommerce"}, {"Legal", "Accused Product", "Services", "Finance"}, 
				{"Legal", "Accused Product", "Software", "All"}, {"Legal", "Accused Product", "Software", "Application"}, {"Legal", "Accused Product", "Software", "Ecommerce"}, 
				{"Legal", "Accused Product", "Software", "Enterprise"}, {"Legal", "Accused Product", "Software", "Gaming"}, {"Legal", "Accused Product", "Software", "LBS"}, 
				{"Legal", "Accused Product", "Software", "Media Content and Distribution"}, {"Legal", "Accused Product", "Software", "Platform/OS"}, {"Legal", "Accused Product", "Software", "Printers/MFPs"}, 
				{"Legal", "Accused Product", "Software", "Productivity"}, {"Legal", "Accused Product", "Software", "Search and Advertising"}, {"Legal", "Accused Product", "Software", "Security"}, 
				{"Legal", "Accused Product", "Software", "Storage"}, {"Legal", "Accused Product", "Software", "Systems/Network Management"}, {"Legal", "Accused Product", "Software", "Web"},
				{"Settlement or Judgment", "Patent", "All", "All"}, {"Settlement or Judgment", "Patent", "Communications", "All"}, {"Settlement or Judgment", "Patent", "Communications", "Messaging and Collaboration"},
				{"Settlement or Judgment", "Patent", "Communications", "VoIP"}, {"Settlement or Judgment", "Patent", "Communications", "Wireless"}, {"Settlement or Judgment", "Patent", "Communications", "Wireline"},				
				{"Settlement or Judgment", "Patent", "Hardware", "All"}, {"Settlement or Judgment", "Patent", "Hardware", "Audiovisual"}, {"Settlement or Judgment", "Patent", "Hardware", "Automotive"}, 
				{"Settlement or Judgment", "Patent", "Hardware", "Computer/PC"}, {"Settlement or Judgment", "Patent", "Hardware", "Computer Peripherals"}, {"Settlement or Judgment", "Patent", "Hardware", "Computer/Server"}, 
				{"Settlement or Judgment", "Patent", "Hardware", "Consumer Products"}, {"Settlement or Judgment", "Patent", "Hardware", "Displays/TVs"}, {"Settlement or Judgment", "Patent", "Hardware", "Gaming Platforms"}, 
				{"Settlement or Judgment", "Patent", "Hardware", "Handset"}, {"Settlement or Judgment", "Patent", "Hardware", "Imaging"}, {"Settlement or Judgment", "Patent", "Hardware", "LBS"}, 
				{"Settlement or Judgment", "Patent", "Hardware", "Power"}, {"Settlement or Judgment", "Patent", "Hardware", "Printers/MFPs"}, {"Settlement or Judgment", "Patent", "Hardware", "Sanner, Copier, and Fax"}, 
				{"Settlement or Judgment", "Patent", "Hardware", "Smartcards"}, {"Settlement or Judgment", "Patent", "Hardware", "Storage"}, {"Settlement or Judgment", "Patent", "Hardware", "Telephony"}, 
				{"Settlement or Judgment", "Patent", "Hardware", "Wireless"}, {"Settlement or Judgment", "Patent", "Networking", "All"}, {"Settlement or Judgment", "Patent", "Networking", "Application and Content Delivery"}, 
				{"Settlement or Judgment", "Patent", "Networking", "Cable"}, {"Settlement or Judgment", "Patent", "Networking", "Cellular"}, {"Settlement or Judgment", "Patent", "Networking", "DSL"}, 
				{"Settlement or Judgment", "Patent", "Networking", "NICs"}, {"Settlement or Judgment", "Patent", "Networking", "Security"}, {"Settlement or Judgment", "Patent", "Networking", "Surveillance/Monitoring"},
				{"Settlement or Judgment", "Patent", "Networking", "Switch/Router and Gateways"}, {"Settlement or Judgment", "Patent", "Networking", "Systems/Network Management"}, {"Settlement or Judgment", "Patent", "Networking", "VoIP"},
				{"Settlement or Judgment", "Patent", "Networking", "Wireless"},	{"Settlement or Judgment", "Patent", "Semiconductors", "All"}, {"Settlement or Judgment", "Patent", "Semiconductors", "Communications"}, 
				{"Settlement or Judgment", "Patent", "Semiconductors", "Displays/TVs"}, {"Settlement or Judgment", "Patent", "Semiconductors", "Fabrication/Packaging/A&T"}, {"Settlement or Judgment", "Patent", "Semiconductors", "Imaging/Sensors"}, 
				{"Settlement or Judgment", "Patent", "Semiconductors", "Logic"}, {"Settlement or Judgment", "Patent", "Semiconductors", "Memory"}, {"Settlement or Judgment", "Patent", "Semiconductors", "Power"}, 
				{"Settlement or Judgment", "Patent", "Semiconductors", "RF/Component"},	{"Settlement or Judgment", "Patent", "Services", "All"}, {"Settlement or Judgment", "Patent", "Services", "Cloud"}, 
				{"Settlement or Judgment", "Patent", "Services", "Content"}, {"Settlement or Judgment", "Patent", "Services", "Ecommerce"}, {"Settlement or Judgment", "Patent", "Services", "Finance"}, 
				{"Settlement or Judgment", "Patent", "Software", "All"}, {"Settlement or Judgment", "Patent", "Software", "Application"}, {"Settlement or Judgment", "Patent", "Software", "Ecommerce"}, 
				{"Settlement or Judgment", "Patent", "Software", "Enterprise"}, {"Settlement or Judgment", "Patent", "Software", "Gaming"}, {"Settlement or Judgment", "Patent", "Software", "LBS"}, 
				{"Settlement or Judgment", "Patent", "Software", "Media Content and Distribution"}, {"Settlement or Judgment", "Patent", "Software", "Platform/OS"}, {"Settlement or Judgment", "Patent", "Software", "Printers/MFPs"}, 
				{"Settlement or Judgment", "Patent", "Software", "Productivity"}, {"Settlement or Judgment", "Patent", "Software", "Search and Advertising"}, {"Settlement or Judgment", "Patent", "Software", "Security"}, 
				{"Settlement or Judgment", "Patent", "Software", "Storage"}, {"Settlement or Judgment", "Patent", "Software", "Systems/Network Management"}, {"Settlement or Judgment", "Patent", "Software", "Web"},
				{"Settlement or Judgment", "Accused Product", "All", "All"}, {"Settlement or Judgment", "Accused Product", "Communications", "All"}, {"Settlement or Judgment", "Accused Product", "Communications", "Messaging and Collaboration"},
				{"Settlement or Judgment", "Accused Product", "Communications", "VoIP"}, {"Settlement or Judgment", "Accused Product", "Communications", "Wireless"}, {"Settlement or Judgment", "Accused Product", "Communications", "Wireline"},				
				{"Settlement or Judgment", "Accused Product", "Hardware", "All"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Audiovisual"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Automotive"}, 
				{"Settlement or Judgment", "Accused Product", "Hardware", "Computer/PC"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Computer Peripherals"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Computer/Server"}, 
				{"Settlement or Judgment", "Accused Product", "Hardware", "Consumer Products"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Displays/TVs"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Gaming Platforms"}, 
				{"Settlement or Judgment", "Accused Product", "Hardware", "Handset"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Imaging"}, {"Settlement or Judgment", "Accused Product", "Hardware", "LBS"}, 
				{"Settlement or Judgment", "Accused Product", "Hardware", "Power"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Printers/MFPs"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Sanner, Copier, and Fax"}, 
				{"Settlement or Judgment", "Accused Product", "Hardware", "Smartcards"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Storage"}, {"Settlement or Judgment", "Accused Product", "Hardware", "Telephony"}, 
				{"Settlement or Judgment", "Accused Product", "Hardware", "Wireless"}, {"Settlement or Judgment", "Accused Product", "Networking", "All"}, {"Settlement or Judgment", "Accused Product", "Networking", "Application and Content Delivery"}, 
				{"Settlement or Judgment", "Accused Product", "Networking", "Cable"}, {"Settlement or Judgment", "Accused Product", "Networking", "Cellular"}, {"Settlement or Judgment", "Accused Product", "Networking", "DSL"}, 
				{"Settlement or Judgment", "Accused Product", "Networking", "NICs"}, {"Settlement or Judgment", "Accused Product", "Networking", "Security"}, {"Settlement or Judgment", "Accused Product", "Networking", "Surveillance/Monitoring"},
				{"Settlement or Judgment", "Accused Product", "Networking", "Switch/Router and Gateways"}, {"Settlement or Judgment", "Accused Product", "Networking", "Systems/Network Management"}, {"Settlement or Judgment", "Accused Product", "Networking", "VoIP"},
				{"Settlement or Judgment", "Accused Product", "Networking", "Wireless"}, {"Settlement or Judgment", "Accused Product", "Semiconductors", "All"}, {"Settlement or Judgment", "Accused Product", "Semiconductors", "Communications"}, 
				{"Settlement or Judgment", "Accused Product", "Semiconductors", "Displays/TVs"}, {"Settlement or Judgment", "Accused Product", "Semiconductors", "Fabrication/Packaging/A&T"}, {"Settlement or Judgment", "Accused Product", "Semiconductors", "Imaging/Sensors"}, 
				{"Settlement or Judgment", "Accused Product", "Semiconductors", "Logic"}, {"Settlement or Judgment", "Accused Product", "Semiconductors", "Memory"}, {"Settlement or Judgment", "Accused Product", "Semiconductors", "Power"}, 
				{"Settlement or Judgment", "Accused Product", "Semiconductors", "RF/Component"}, {"Settlement or Judgment", "Accused Product", "Services", "All"}, {"Settlement or Judgment", "Accused Product", "Services", "Cloud"}, 
				{"Settlement or Judgment", "Accused Product", "Services", "Content"}, {"Settlement or Judgment", "Accused Product", "Services", "Ecommerce"}, {"Settlement or Judgment", "Accused Product", "Services", "Finance"}, 
				{"Settlement or Judgment", "Accused Product", "Software", "All"}, {"Settlement or Judgment", "Accused Product", "Software", "Application"}, {"Settlement or Judgment", "Accused Product", "Software", "Ecommerce"}, 
				{"Settlement or Judgment", "Accused Product", "Software", "Enterprise"}, {"Settlement or Judgment", "Accused Product", "Software", "Gaming"}, {"Settlement or Judgment", "Accused Product", "Software", "LBS"}, 
				{"Settlement or Judgment", "Accused Product", "Software", "Media Content and Distribution"}, {"Settlement or Judgment", "Accused Product", "Software", "Platform/OS"}, {"Settlement or Judgment", "Accused Product", "Software", "Printers/MFPs"}, 
				{"Settlement or Judgment", "Accused Product", "Software", "Productivity"}, {"Settlement or Judgment", "Accused Product", "Software", "Search and Advertising"}, {"Settlement or Judgment", "Accused Product", "Software", "Security"}, 
				{"Settlement or Judgment", "Accused Product", "Software", "Storage"}, {"Settlement or Judgment", "Accused Product", "Software", "Systems/Network Management"}, {"Settlement or Judgment", "Accused Product", "Software", "Web"},
				{"Total", "Patent", "All", "All"}, {"Total", "Patent", "Communications", "All"}, {"Total", "Patent", "Communications", "Messaging and Collaboration"},
				{"Total", "Patent", "Communications", "VoIP"}, {"Total", "Patent", "Communications", "Wireless"}, {"Total", "Patent", "Communications", "Wireline"},				
				{"Total", "Patent", "Hardware", "All"}, {"Total", "Patent", "Hardware", "Audiovisual"}, {"Total", "Patent", "Hardware", "Automotive"}, 
				{"Total", "Patent", "Hardware", "Computer/PC"}, {"Total", "Patent", "Hardware", "Computer Peripherals"}, {"Total", "Patent", "Hardware", "Computer/Server"}, 
				{"Total", "Patent", "Hardware", "Consumer Products"}, {"Total", "Patent", "Hardware", "Displays/TVs"}, {"Total", "Patent", "Hardware", "Gaming Platforms"}, 
				{"Total", "Patent", "Hardware", "Handset"}, {"Total", "Patent", "Hardware", "Imaging"}, {"Total", "Patent", "Hardware", "LBS"}, 
				{"Total", "Patent", "Hardware", "Power"}, {"Total", "Patent", "Hardware", "Printers/MFPs"}, {"Total", "Patent", "Hardware", "Sanner, Copier, and Fax"}, 
				{"Total", "Patent", "Hardware", "Smartcards"}, {"Total", "Patent", "Hardware", "Storage"}, {"Total", "Patent", "Hardware", "Telephony"}, 
				{"Total", "Patent", "Hardware", "Wireless"}, {"Total", "Patent", "Networking", "All"}, {"Total", "Patent", "Networking", "Application and Content Delivery"}, 
				{"Total", "Patent", "Networking", "Cable"}, {"Total", "Patent", "Networking", "Cellular"}, {"Total", "Patent", "Networking", "DSL"}, 
				{"Total", "Patent", "Networking", "NICs"}, {"Total", "Patent", "Networking", "Security"}, {"Total", "Patent", "Networking", "Surveillance/Monitoring"},
				{"Total", "Patent", "Networking", "Switch/Router and Gateways"}, {"Total", "Patent", "Networking", "Systems/Network Management"}, {"Total", "Patent", "Networking", "VoIP"},
				{"Total", "Patent", "Networking", "Wireless"}, {"Total", "Patent", "Semiconductors", "All"}, {"Total", "Patent", "Semiconductors", "Communications"}, 
				{"Total", "Patent", "Semiconductors", "Displays/TVs"}, {"Total", "Patent", "Semiconductors", "Fabrication/Packaging/A&T"}, {"Total", "Patent", "Semiconductors", "Imaging/Sensors"}, 
				{"Total", "Patent", "Semiconductors", "Logic"}, {"Total", "Patent", "Semiconductors", "Memory"}, {"Total", "Patent", "Semiconductors", "Power"}, 
				{"Total", "Patent", "Semiconductors", "RF/Component"}, {"Total", "Patent", "Services", "All"}, {"Total", "Patent", "Services", "Cloud"}, 
				{"Total", "Patent", "Services", "Content"}, {"Total", "Patent", "Services", "Ecommerce"}, {"Total", "Patent", "Services", "Finance"}, 
				{"Total", "Patent", "Software", "All"}, {"Total", "Patent", "Software", "Application"}, {"Total", "Patent", "Software", "Ecommerce"}, 
				{"Total", "Patent", "Software", "Enterprise"}, {"Total", "Patent", "Software", "Gaming"}, {"Total", "Patent", "Software", "LBS"}, 
				{"Total", "Patent", "Software", "Media Content and Distribution"}, {"Total", "Patent", "Software", "Platform/OS"}, {"Total", "Patent", "Software", "Printers/MFPs"}, 
				{"Total", "Patent", "Software", "Productivity"}, {"Total", "Patent", "Software", "Search and Advertising"}, {"Total", "Patent", "Software", "Security"}, 
				{"Total", "Patent", "Software", "Storage"}, {"Total", "Patent", "Software", "Systems/Network Management"}, {"Total", "Patent", "Software", "Web"},
				{"Total", "Accused Product", "All", "All"}, {"Total", "Accused Product", "Communications", "All"}, {"Total", "Accused Product", "Communications", "Messaging and Collaboration"},
				{"Total", "Accused Product", "Communications", "VoIP"}, {"Total", "Accused Product", "Communications", "Wireless"}, {"Total", "Accused Product", "Communications", "Wireline"},				
				{"Total", "Accused Product", "Hardware", "All"}, {"Total", "Accused Product", "Hardware", "Audiovisual"}, {"Total", "Accused Product", "Hardware", "Automotive"}, 
				{"Total", "Accused Product", "Hardware", "Computer/PC"}, {"Total", "Accused Product", "Hardware", "Computer Peripherals"}, {"Total", "Accused Product", "Hardware", "Computer/Server"}, 
				{"Total", "Accused Product", "Hardware", "Consumer Products"}, {"Total", "Accused Product", "Hardware", "Displays/TVs"}, {"Total", "Accused Product", "Hardware", "Gaming Platforms"}, 
				{"Total", "Accused Product", "Hardware", "Handset"}, {"Total", "Accused Product", "Hardware", "Imaging"}, {"Total", "Accused Product", "Hardware", "LBS"}, 
				{"Total", "Accused Product", "Hardware", "Power"}, {"Total", "Accused Product", "Hardware", "Printers/MFPs"}, {"Total", "Accused Product", "Hardware", "Sanner, Copier, and Fax"}, 
				{"Total", "Accused Product", "Hardware", "Smartcards"}, {"Total", "Accused Product", "Hardware", "Storage"}, {"Total", "Accused Product", "Hardware", "Telephony"}, 
				{"Total", "Accused Product", "Hardware", "Wireless"}, {"Total", "Accused Product", "Networking", "All"}, {"Total", "Accused Product", "Networking", "Application and Content Delivery"}, 
				{"Total", "Accused Product", "Networking", "Cable"}, {"Total", "Accused Product", "Networking", "Cellular"}, {"Total", "Accused Product", "Networking", "DSL"}, 
				{"Total", "Accused Product", "Networking", "NICs"}, {"Total", "Accused Product", "Networking", "Security"}, {"Total", "Accused Product", "Networking", "Surveillance/Monitoring"},
				{"Total", "Accused Product", "Networking", "Switch/Router and Gateways"}, {"Total", "Accused Product", "Networking", "Systems/Network Management"}, {"Total", "Accused Product", "Networking", "VoIP"},
				{"Total", "Accused Product", "Networking", "Wireless"},	{"Total", "Accused Product", "Semiconductors", "All"}, {"Total", "Accused Product", "Semiconductors", "Communications"}, 
				{"Total", "Accused Product", "Semiconductors", "Displays/TVs"}, {"Total", "Accused Product", "Semiconductors", "Fabrication/Packaging/A&T"}, {"Total", "Accused Product", "Semiconductors", "Imaging/Sensors"}, 
				{"Total", "Accused Product", "Semiconductors", "Logic"}, {"Total", "Accused Product", "Semiconductors", "Memory"}, {"Total", "Accused Product", "Semiconductors", "Power"}, 
				{"Total", "Accused Product", "Semiconductors", "RF/Component"},	{"Total", "Accused Product", "Services", "All"}, {"Total", "Accused Product", "Services", "Cloud"}, 
				{"Total", "Accused Product", "Services", "Content"}, {"Total", "Accused Product", "Services", "Ecommerce"}, {"Total", "Accused Product", "Services", "Finance"}, 
				{"Total", "Accused Product", "Software", "All"}, {"Total", "Accused Product", "Software", "Application"}, {"Total", "Accused Product", "Software", "Ecommerce"}, 
				{"Total", "Accused Product", "Software", "Enterprise"}, {"Total", "Accused Product", "Software", "Gaming"}, {"Total", "Accused Product", "Software", "LBS"}, 
				{"Total", "Accused Product", "Software", "Media Content and Distribution"}, {"Total", "Accused Product", "Software", "Platform/OS"}, {"Total", "Accused Product", "Software", "Printers/MFPs"}, 
				{"Total", "Accused Product", "Software", "Productivity"}, {"Total", "Accused Product", "Software", "Search and Advertising"}, {"Total", "Accused Product", "Software", "Security"}, 
				{"Total", "Accused Product", "Software", "Storage"}, {"Total", "Accused Product", "Software", "Systems/Network Management"}, {"Total", "Accused Product", "Software", "Web"}				
		};
	}	

	@Test(priority = 3, groups = "litigation_analytics", description = "Verify Settlement Cost by Termination Year in Tooltip")
	public void settlementCostByTerminationYearTooltip() throws Exception{
		ResultSet result = sqlProcessor.getResultData("CostAnalytics.SETTLEMENT_COST_BY_TERMINATION_YEAR");		
		assertEquals(costAnalyticsPage.settlementCostByTerminationYearChart.getTooltipData("terminated_year"),
				sqlProcessor.getResultDataAsMap(result, "terminated_year", "percentile"));
	}

	@Test(priority = 3, groups = "litigation_analytics", description = "Verify Settlement Cost by Termination Year")
	public void settlementCostByTerminationYear() throws Exception{
		ResultSet result = sqlProcessor.getResultData("CostAnalytics.SETTLEMENT_COST_BY_TERMINATION_YEAR_TABLE");		
		assertEquals(costAnalyticsPage.settlementCostByTerminationYearChart.axisLabelValues("terminated_year"),
				sqlProcessor.getResultDataAsMultiMap(result, "terminated_year", "litigation_count", "percentile_25", "percentile_50", "percentile_75", "percentile_90"));
	}

	@Test(priority = 3, groups = "litigation_analytics", dataProvider = "meanResolutionCostTypes", description = "Verify Mean Resolution Cost")
	public void meanResolutionCost(String appResolutionCostType, String dbResolutionCostType, String xAxis) throws Exception{
		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("cost_type", dbResolutionCostType);
		queryParams.put("x_axis", xAxis);

		costAnalyticsPage.selectResolutionCostAndXAxisValues(appResolutionCostType, xAxis);
		costAnalyticsPage.resolutionCostTypeChart.getLabelElement("mean_total_cost").waitUntilVisible();
		ResultSet result = sqlProcessor.getResultData("CostAnalytics.MEAN_RESOLUTION_COST", queryParams);		
		assertEquals(costAnalyticsPage.resolutionCostTypeChart.getChartData("bin_group"),
				sqlProcessor.getResultDataAsMultiMap(result, "bin_group", "litigation_count", "mean_total_cost", "settlement_cost", "legal_cost"));
	}

	@DataProvider
	public Object[][] meanResolutionCostTypes(){
		return new Object[][]{
				{"Mean", "Mean", "Defendant Revenue"}, {"Mean", "Mean", "Filing Venue"}, {"Mean", "Mean", "Latest Venue"},
				{"Mean", "Mean", "Length of Suit"}, {"Mean", "Mean", "Number of Patents-in-Suit"}, {"Mean", "Mean", "Sector"},
				{"Mean, excl. cases >$10M", "Mean, excl. cases >\\$10M", "Defendant Revenue"}, {"Mean, excl. cases >$10M", "Mean, excl. cases >\\$10M", "Filing Venue"}, 
				{"Mean, excl. cases >$10M", "Mean, excl. cases >\\$10M", "Latest Venue"}, {"Mean, excl. cases >$10M", "Mean, excl. cases >\\$10M", "Length of Suit"}, 
				{"Mean, excl. cases >$10M", "Mean, excl. cases >\\$10M", "Number of Patents-in-Suit"}, {"Mean, excl. cases >$10M", "Mean, excl. cases >\\$10M", "Sector"}				
		};	
	}

	@Test(priority = 3, groups = "litigation_analytics", dataProvider = "medianResolutionCostTypes", description = "Verify Median Resolution Cost")
	public void medianResolutionCost(String appResolutionCostType, String dbResolutionCostType, String xAxis) throws Exception{
		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("cost_type", dbResolutionCostType);
		queryParams.put("x_axis", xAxis);

		costAnalyticsPage.selectResolutionCostAndXAxisValues(appResolutionCostType, xAxis);
		ResultSet result = sqlProcessor.getResultData("CostAnalytics.MEDIAN_RESOLUTION_COST", queryParams);
		assertEquals(costAnalyticsPage.resolutionCostTypeChartMedian.getChartData("bin_group"),
				sqlProcessor.getResultDataAsMultiMap(result, "bin_group", "litigation_count", "median_total_cost"));
	}

	@DataProvider
	public Object[][] medianResolutionCostTypes(){
		return new Object[][]{
				{"Median", "Median", "Defendant Revenue"}, {"Median", "Median", "Filing Venue"}, {"Median", "Median", "Latest Venue"},
				{"Median", "Median", "Length of Suit"}, {"Median", "Median", "Number of Patents-in-Suit"}, {"Median", "Median", "Sector"}
		};	
	}
}
