package com.rpxcorp.insight.page.detail;

import com.rpxcorp.insight.module.ListPanel;
import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;

import java.util.ArrayList;
import java.util.List;

public class ReexaminationDetailPage extends BaseDetailPage {

    public ReexaminationDetailPage() {
        this.url = new PageUrl("reexaminations/{ID}");
    }

    @Override
    public boolean at() {
        waitForPageLoad();
        waitForLoading();
        return detailPageTitle.waitUntilVisible();
    }


    public final Element detailPageTitle = $(".presenter-name-cls.detail-page-title:not(span)");



   /* public final StaticContent header_info =$( ".header-info.details.subtitle",(Configure<StaticContent>) dataForm ->{
        dataForm.content("control_number", "li:nth-child(1)");
        dataForm.content("filed_date", "li:contains(Filed)");
        dataForm.content("terminated_date", "li:contains(Terminated)");
    });*/


    //public final Element title = $(".presenter-name-cls>span:first-child");
    //public final Element control_number = $("ul.header-info.details.subtitle li:nth-child(1)");

    public final StaticContent reexam_subtitle = $(".header-info.details.subtitle", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("controlNumber", "li:nth-child(1)");
                dataForm.content("Filed_date", "li:contains(Filed)");
                dataForm.content("Terminated", "li:contains(Terminated)");
            }
    );
    public final StaticContent metricsSection = $(".panel-metrics", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("requesterCount", "div.metrics_card a[href='#requesters'] .count");
                dataForm.content("patentownerCount", "div.metrics_card a[href='#respondents'] .count");
                dataForm.content("prosecutioneventCount", "div.metrics_card a[href='#prosecution_events'] .count");
                dataForm.content("rejectionCount", "div.metrics_card a[href='#prosecution_events'] .count");
            }
    );
    public final StaticContent overview_panel = $(".panel.overview .content", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("case_type", ".block-header:contains(Case)");
                dataForm.content("status", ".block-header:contains(Status)");
                dataForm.content("court", ".block-header:contains(Court)");
                dataForm.content("status", ".block-header:contains(Status)");
                dataForm.content("examiner", ".block-header:contains(Examiner)");
               }
    );
    public final Table prosecutionEvents = $("#prosecution_events", (Configure<Table>) table ->
            {
                table.row("tbody>tr:nth-child(odd)");
                table.uniqueId("td:nth-of-type(1)");
                //table.nextPage("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:last-child");
                //table.lastPage("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:nth-last-child(2)");
                table.subTable(new Table("tbody>tr:nth-child(even)"));
                //table.viewAllLink(By.xpath("//*[@id='dockets_wrapper']//a[text()='View All']"));
                //table.viewLessLink(By.xpath("//*[@id='dockets_wrapper']//a[text()='View Less']"));
                table.displayedRecords("#dockets_wrapper tbody>tr, #dockets_wrapper>div:not([style*='none']) tbody>tr");
            }
    );
    public final ListPanel respondents = $("#sidebar", (Configure<ListPanel>) list ->
            {
                list.dataKey(".panel:has(.respondents) li>a");
                list.link("#sidebar .panel:nth-of-type(2) a");
                list.displayedRecords("#respondents ul:not([style*='none']) li a");
                //list.viewAllLink("#respondents a.view-all:contains('View All')");
                //list.viewLessLink("#respondents a.view-all:contains('View Less')");
            }
    );
    public final Element requester_Count=$("#respondents .round-shape");
    public final Element patentowner_Count=$("#respondents .round-shape");
    public final Element prosecutionEvent_count=$("#dockets_wrapper h5:contains('Prosecution Events')");
    //public final Element rejection_Count = $("#dockets_wrapper .section-subtitle");
    public final Element viewCertificateInSummary = $("#view-complaint");
    public final ListPanel Requester = $("#sidebar", (Configure<ListPanel>) list ->
            {
                list.dataKey(".panel:has(.complainants) li>a");
                list.link("#complainants>ul>li a");
                list.displayedRecords("#complainants ul:not([style*='none']) li a");
                list.viewAllLink("#complainants a.view-all:contains('View All')");
                list.viewLessLink("#complainants a.view-all:contains('View Less')");
            }
    );
    public final ListPanel PatentOwner = $("#sidebar", (Configure<ListPanel>) list ->
            {
                list.dataKey(".panel:has(.respondents) li>a");
                list.link("#sidebar .panel:nth-of-type(2) a");
                list.displayedRecords("#respondents ul:not([style*='none']) li a");
                list.viewAllLink("#respondents a.view-all:contains('View All')");
                list.viewLessLink("#respondents a.view-all:contains('View Less')");
            }
    );
    public final Element noPatentsInPatentInSuitMsg = $(".empty-lit-patents span");
    public final Element viewAsSearchPatentInSuit = $("div.block-header:has(.section-title:contains('Patent Information')) li.view-link a");
    public final Table patent_table = $("table.patents-in-suit-table", (Configure<Table>) table ->
            {
                table.uniqueId("td:nth-child(2) a[href]");
                table.viewAllLink(By.xpath("//div[contains(@class, 'patents-in-suit')][not(@id)]//a[text()='View All']"));
                table.viewLessLink(By.xpath("//div[contains(@class, 'patents-in-suit')][not(@id)]//a[text()='View Less']"));
                table.displayedRecords(".patents-in-suit-table tbody tr:not([style*='none'])");
            }
    );
    public List<String> getColumnDataForDocketTable(String columnName) {
        List<String> columnData = new ArrayList<String>();
        int columnIndex = prosecutionEvents.getColumnIndex(columnName, prosecutionEventsHeader);
        columnData = $(prosecutionEventsColumn + columnIndex + ")").getAllData();
        return columnData;

    }
    public final Table prosecutionevents = $("#docket_entries", (Configure<Table>) table ->
            {
                table.row("tbody>tr:nth-child(odd)");
                table.uniqueId(" td:nth-of-type(1) ");
                table.nextPage("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:last-child");
                table.lastPage("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:nth-last-child(2)");
                table.subTable(new Table("tbody>tr:nth-child(even)"));
                table.viewAllLink(By.xpath("//*[@id='dockets_wrapper']//a[text()='View All']"));
                table.viewLessLink(By.xpath("//*[@id='dockets_wrapper']//a[text()='View Less']"));
                table.displayedRecords("#dockets_wrapper tbody>tr, #dockets_wrapper>div:not([style*='none']) tbody>tr");
            }
    );
    public final String prosecutionEventsHeader = "#docket_entries thead";
    public final String prosecutionEventsColumn = "#docket_entries tbody>tr:not(:nth-of-type(2n))>td:nth-of-type(";
    public final Element prosecutionEventsnextPage = $("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:last-child");
    public final Element prosecutionEventsActivePage = $("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li[class='current']");
    public final Element prosecutionEventsLastPage = $("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:nth-last-child(2)");
    public final Element prosecutionEventsnextPageDisable = $(
            "#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:last-child[class='arrow unavailable']");
    public final Element prosecutionEventActivePage = $("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li[class='current']");
    public final Element prosecutionEventLastPage = $("#dockets_wrapper .hide-for-small-only ul.pagination.pagination li:nth-last-child(2)");

}


