package com.rpxcorp.insight.page.visual_analytics;

import com.rpxcorp.insight.module.Highchart;
import com.rpxcorp.insight.module.ListPanel;
import com.rpxcorp.insight.module.Radio;
import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;
import org.testng.Assert;

public class PartyAnalyticsPage extends BasePage {

	public PartyAnalyticsPage() {
		this.url = new PageUrl("analytics/party");
	}

	@Override
	public boolean at() {
		loading.waitUntilInvisible();
		Assert.assertEquals(title.getText(),"Party Analytics");
		return analyse_button.waitUntilVisible();
	}
	public final Element title = $("h5.detail-page-title");

	public final Element analyse_button = $("input[value='Analyze']");
	public final Element defendant = $("input#s2id_autogen1");
	public final Element plaintiff = $("input#s2id_autogen2");

	//Promotional Message for Basic to Prime
	public final Element partyTab_PromoMsg=$(".logged_in.page_blocked.analytics:contains('Party analytics is not included in your current subscription. Please') a[href='/subscribe']");
	public final Element partyTab_SignInPromoMsg=$(".anonymous.page_blocked:contains('to see additional information') a.reveal_login_from_grey_out");

	public void selectDefendant(String defName) {
		plaintiff.clear();
		defendant.sendKeys(defName);
		$(".select2-input.select2-active").waitUntilInvisible();
		clickOnNthResult(1);
		analyse_button.click();
		$("div.facets_holder").waitUntilVisible();
	}

	public void selectPlaintiff(String plaName) {
		defendant.clear();
		plaintiff.sendKeys(plaName);
		$(".select2-input.select2-active").waitUntilInvisible();
		clickOnNthResult(1);
		analyse_button.click();
		$("div.facets_holder").waitUntilVisible();
	}
	public void clickOnNthResult(int rowNumber) {
		$("div#select2-drop ul li:nth-of-type(" + rowNumber + ")").click();
	}
}
