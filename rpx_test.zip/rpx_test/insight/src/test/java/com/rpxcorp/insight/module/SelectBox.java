package com.rpxcorp.insight.module;

import com.rpxcorp.testcore.element.Element;

import java.util.ArrayList;

public class SelectBox extends Element {

    Element input = new Element(".select2-drop:visible>.select2-search>input");
    public SelectBox(String selector) {
        super(selector);
    }

    private void filterAndselect(String value,boolean isfilter){
        if (value != null && !value.isEmpty() ) {
            click();
            input.waitUntilVisible();
            if(isfilter)
                input.sendKeys(value);
            Element resultValue = new Element(".select2-drop:visible>ul>li.select2-result:contains(\\\"" + value + "\\\")");
            resultValue.waitUntilVisible();
            resultValue.click();
        }
    }
    public void type(String value){
        if (value != null && !value.isEmpty() ) {
            click();
            input.waitUntilVisible();
            input.sendKeys(value);
        }
    }
    public void typeAndselect(String value){
       filterAndselect(value,true);
    }
    public void select(String value){
        filterAndselect(value,false);
    }

    public ArrayList<String> getAllResults() {
        click();
        waitForDOM();
        input.waitUntilVisible();
        return new Element(".select2-drop:visible>ul>li.select2-result").getAllData();
    }
    
}
