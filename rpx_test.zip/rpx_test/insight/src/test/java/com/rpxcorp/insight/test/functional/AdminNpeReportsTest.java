package com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.HomePage;
import com.rpxcorp.insight.page.LoginPage;
import com.rpxcorp.insight.page.LoginPage.ROLES;
import com.rpxcorp.insight.page.NpeEmailPreviewPage;
import com.rpxcorp.insight.page.account.AdminNpeReportsPage;
import com.rpxcorp.insight.page.account.FeaturesPage;
import com.rpxcorp.insight.page.account.UserViewPage;
import com.rpxcorp.insight.page.my_portal.MyAlertsPage;
import com.rpxcorp.oldtest.util.EmailApiUtil;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.FileUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.Test;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
@Authenticate(role = "ADMIN")
public class AdminNpeReportsTest extends BaseFuncTest{
    AdminNpeReportsPage npeReports;
    FeaturesPage adminFeaturePage;
    LoginPage loginPage;
    HomePage homepage;
    UserViewPage adminUserViewPage;
    EmailApiUtil email_api;
    MyAlertsPage myAlertsPage;
    private String portalQAEmail =ConfigUtil.config().get("PORTAL_QA_EMAIL").toString();
    String validFilePath=ConfigUtil.config().get("testResourcesDir") + "/test_data/";
    String inValidFilePath=ConfigUtil.config().get("testResourcesDir") + "/test_data/AdvanceSearchForm.xls";
    //String outputDirectory_Path=ConfigUtil.config().get("testOutputDir").toString();
    public String fileName="",clearQuery,prev_Month,published_month,selectedMonth;
    //File savePathForFile=new File(outputDirectory_Path);
    SimpleDateFormat selectDate,expectedDate;
    public String email_Subject,subscribed_user_email="npe_sub.ba6f4fe1@mailosaur.io",inactive_user_email="inactive.ba6f4fe1@mailosaur.io",disabled_user_email="disabled.ba6f4fe1@mailosaur.io";
    String disable_user_id=null;

    @BeforeClass(alwaysRun = true)
    public void setupTestData() {
		Calendar cal = Calendar.getInstance();				
    	cal.add(Calendar.MONTH, -1);		
    	selectDate=new SimpleDateFormat("MM/dd/yyyy");
    	prev_Month=selectDate.format(cal.getTime());
    	expectedDate = new SimpleDateFormat("MMMM YYYY");
    	published_month=expectedDate.format(cal.getTime());
    	selectedMonth=expectedDate.format(cal.getTime());
    	fileName="RPX Monthly NPE Report - " +expectedDate.format(cal.getTime())+".pdf";
    	email_Subject="RPX Monthly NPE Report - " +expectedDate.format(cal.getTime());
    	to(npeReports);
    }

    @Test(priority=1,groups="P3", description="Verification npe reports Page in Admin page.")
    public void checkDefaultDisplayForNpeReportsPage() throws Exception
    {
        assertEquals(npeReports.npeReportsTitle.getText(),"NPE Reports");
        assertEquals(npeReports.addNpeReportButton.getText(),"Add a New NPE Report");
        assertTrue(npeReports.Mnthly_Npe_Report.isDisplayed(),"Monthly NPE Report button is not displayed"); 
        
    }
    
    @BeforeGroups(groups="npe_cleanup")
    public void cleanUpNpeReports() {    	   
    	//Clear Published Reports from DB    	
		try {
			clearQuery = getJsonDataQueries("FuntionalTestData.json").get("DELETE_PUBLISHED_MONTHLY_NPE_REPORTS").getAsString();
			processDB(clearQuery);						
		} catch (Exception e) {
			assertTrue(false,e.getMessage());
		}
    }    
    
	@Test(priority=2,groups={"P3","npe_cleanup"}, description="Verify Monthly NPE Update is redirected to NPE Reports Page when there is no previous month published report")
    public void checkMonthlyNpeUpdate_Without_PublishDoc() throws Exception {
    	to(npeReports);
    	npeReports.expand_Emails_Menu();
    	withNewWindow(npeReports.monthly_Npe_Update, () -> {
    		at(npeReports);
    		npeReports.alertMessage.waitUntilVisible();
			assertTrue(npeReports.getFlashMessage().contains("Npe Report not generated for the selected month"), "Expected falsh Msg:Npe Report not generated for the selected month, Actual:"+npeReports.getFlashMessage());
			assertTrue(npeReports.preview_Npe_Email.getAttribute("class").contains("disabled"),"Preview Npe Email button is not disabled when there is no prev month published npe report");
        });
    }
    
    @Test(priority=3,groups="P3", description="Check error messages for monthly uploading report")
    public void checkErrorMsgForEmptyReportTitle() throws Exception{
    	npeReports.refresh();
        npeReports.navigateToUploadNpeReports();        
        npeReports.publishReportBtn.click();
        npeReports.alertMessage.waitUntilVisible();
        Assert.assertTrue(npeReports.getFlashMessage().contains("File can't be blank"));
        Assert.assertTrue(npeReports.getFlashMessage().contains("Selected month can't be blank"));
        Assert.assertTrue(npeReports.getFlashMessage().contains("Selected month should be in last three months"));   
    }
    
    @Test(priority=4,groups="P3", description="Error message when invalid file format is filled while uploading report")
    public void checkErrorMsgForInvalidFileFormat() throws Exception {
    	npeReports.refresh();
        npeReports.selectMonthForPublish.selectDate(prev_Month);
        npeReports.inputFile(inValidFilePath);
        npeReports.publishReportBtn.click();
        npeReports.alertMessage.waitUntilVisible();
        System.out.println(npeReports.getFlashMessage());
        Assert.assertTrue(npeReports.getFlashMessage().contains("You are not allowed to upload \"xls\" files, allowed types: [\"pdf\"]"));
    }

    @Test(priority =5,groups={"P3","npe_cleanup"},description = "Verify Monthly NPE Report is downloaded for the last month")
	public void checkMonthlyNPEReportDownload() throws Exception {
    	// Delete files if Any
    	//FileUtil.deleteFilesFromDirectory(savePathForFile);
		FileUtil.deleteFilesFromDirectory(new File(ConfigUtil.config().get("testOutputDir").toString()));
    	to(npeReports);
		npeReports.monthly_NPEReport.waitUntilVisible();
		npeReports.inputReportDate.selectDate(prev_Month);
		npeReports.monthly_NPEReport.click();
		npeReports.block_UI.waitUntilInvisible();
		FileUtil.waitUntilFileDownload(ConfigUtil.config().get("testOutputDir").toString(), 100000);
		File[] filesInDir = FileUtil.listAllFilesFromADirectory(ConfigUtil.config().get("testOutputDir").toString());
		assertTrue(filesInDir.length == 1,"Monthly NPE Report is not downloaded for Admin");		
		assertTrue(filesInDir[0].getPath().contains(fileName),
				"Downloaded Monthly NPE Report doesnt have expected file name. Expected "+fileName+",Actual: "+filesInDir[0].getPath());

	}
    
    @BeforeGroups(groups="createUsers")
    public void createUsers() throws Exception {
    	//delete user if any
    	deleteUser(subscribed_user_email);
    	deleteUser(inactive_user_email);
    	deleteUser(disabled_user_email);
    	
    	//Create inactive and disabled users with npe subscription
		createInActiveUser(inactive_user_email,ROLES.MEMBER);			
		createUser(disabled_user_email,ROLES.MEMBER);
		createUser(subscribed_user_email,ROLES.MEMBER);
		disableUser(disabled_user_email);
		
		//Delete Emails of users if any
		EmailApiUtil.deleteRecipientEmails(inactive_user_email);
		EmailApiUtil.deleteRecipientEmails(disabled_user_email);
		EmailApiUtil.deleteRecipientEmails(subscribed_user_email);
		EmailApiUtil.deleteRecipientEmails(portalQAEmail);    	    
    	
    }
    
    @Test(priority=6,groups={"P3","createUsers"},description="Verify Monthly NPE Report option in My Subscription Page for Member User")
    @Authenticate(role = "NONE") // TODO replace once parameter is implemented in auth
    public void checkNpeMonthlyUpdateForMemberUser() throws Exception {
    	login(subscribed_user_email, "Welcome@1");
    	to(myAlertsPage);
    	//assertTrue(myAlertsPage.monthly_npe_update_subscription.isSelected(),"Monthly Npe Update option should be enabled for member"); /--todo need to enable this assert once API fixed
    }

    //,dependsOnMethods={"checkNpeMonthlyUpdateForMemberUser","checkMonthlyNPEReportDownload"}
    @Test(priority=7,groups={"P3","npe_cleanup"},description="Publish the past month npe report as Admin")
    public void checkUploadingNpeReports() throws Exception{
    	String[] tableHeader={"Selected Month","Publication Date","File","Email Sent","Send Email"};
    	to(npeReports);
    	npeReports.navigateToUploadNpeReports();
        npeReports.inputFile(ConfigUtil.config().get("testOutputDir").toString()+System.getProperty("file.separator")+fileName);
        npeReports.selectMonthForPublish.waitUntilClickable();
        npeReports.selectMonthForPublish.selectDate(prev_Month);
        npeReports.sendNpePublicationEmail_checkbox.select();
        npeReports.publishReportBtn.click();
        Thread.sleep(30000);
        at(npeReports);
        //assertEquals(npeReports.getFlashMessage(), "Report successfully uploaded.");
        assertEquals(npeReports.npeReportsTable.getColumn("Selected Month").contains(selectedMonth),true); 
        assertEquals(npeReports.npeReportsTable.getHeaderData(), tableHeader);        
    }    

    //dependsOnMethods="checkUploadingNpeReports",
    @Test(priority=8,groups="P3", description="Verify Monthly NPE Update is redirected to the last month and Preview Npe Email button redirection")
    public void checkMonthlyNpeUpdate_With_PublishDoc() throws Exception {
    	npeReports.expand_Emails_Menu();    	
    	npeReports.monthly_Npe_Update.waitUntilVisible();
    	withNewWindow(npeReports.monthly_Npe_Update, () -> {    		
    		at(NpeEmailPreviewPage.class);
        });    	
    	assertFalse(npeReports.preview_Npe_Email.getAttribute("class").contains("disabled"),"Preview Npe Email button is not enabled when there is a prev month published npe report");    	
    	withNewWindow(npeReports.preview_Npe_Email, () -> {
    		at(NpeEmailPreviewPage.class);
        }); 
    }    

    //dependsOnMethods={"checkNpeMonthlyUpdateForMemberUser","checkUploadingNpeReports"},
    @Test(priority=9,groups="P3", description="Verify subscribed user recieved Monthly Npe Email")
    public void checkNpeSubscribeUserEmail() throws Exception {    	  	
    	assertTrue(EmailApiUtil.getEmailContent(subscribed_user_email,0).get("subject").contains(email_Subject),"Monthly NPE EMail is not recieved,Expected Email Subject:"+email_Subject+",Actual:"+EmailApiUtil.getEmailContent(subscribed_user_email,0).get("subject"));
    	//RPX-12564
    	assertTrue(EmailApiUtil.getEmailContent(subscribed_user_email,0).get("body").contains("Suite 1100"),"Monthly Npe Report Email doesnt contain 'Suite 1100' at footer address text");
    }

    //dependsOnMethods="checkNpeSubscribeUserEmail",
    @Test(priority=10,groups="P3", description="Check Inactive/disabled users are not received npe onthly update email")
    public void checkNpEmailForInactiveAndDisableUsers() throws Exception {
    	assertFalse(EmailApiUtil.checkForReceiveEmail(inactive_user_email,20000),"Inactive user is recieved email for Npe monthly update");
    	assertFalse(EmailApiUtil.checkForReceiveEmail(disabled_user_email,20000),"Disabled user is recieved email for Npe monthly update");
    }

    //,dependsOnMethods={"checkNpeMonthlyUpdateForMemberUser","checkNpeSubscribeUserEmail"}
    @Test(priority=11,groups="P3", description="Verify unsubscribe email functionality for Monthly NPE Email")
    public void checkUnsubscribeNpeUpdate() throws Exception {
    	logout();
    	String unscribe_link=EmailApiUtil.specific_Link(subscribed_user_email, 0,"unsubscribe");
    	loginPage.navigateTo(unscribe_link);
    	loginPage.infoMsg.waitUntilVisible();
    	assertEquals(loginPage.infoMsg.getText(),"You have been successfully unsubscribed from the RPX Monthly NPE Update.");
    	assertEquals(getUserData(subscribed_user_email,"monthly_npe_update_subscription"),"f","monthly_npe_update_subscription flag is not set to false after unsubscribe");
    	loginPage.navigateTo(unscribe_link);
    	loginPage.infoMsg.waitUntilVisible();
    	assertEquals(loginPage.infoMsg.getText(),"You have been already unsubscribed from the mailing list");
    	assertEquals(getUserData(subscribed_user_email,"monthly_npe_update_subscription"),"f","monthly_npe_update_subscription flag is not set to false after unsubscribe");
    	cleanUpNpeReports();    	    	
    	EmailApiUtil.deleteRecipientEmails(subscribed_user_email);
    	EmailApiUtil.deleteRecipientEmails(portalQAEmail);
    	loginAs(ROLES.ADMIN);
    	checkUploadingNpeReports();
    	assertFalse(EmailApiUtil.checkForReceiveEmail(subscribed_user_email,20000),"Unsubscribed user is recieved email for Npe monthly update");    	
    }
    
    //HELPER METHODS
    private String getUserData(String user_email_id,String columnName) throws Exception {
    	HashMap<String, String> params = new HashMap<String, String>();
    	params.put("EMAIL", user_email_id);
    	System.out.println(sqlProcessor.getSingleValue("FuntionalTestData.USER_SUBSCRIPTIONS",params,columnName));
		return sqlProcessor.getSingleValue("FuntionalTestData.USER_SUBSCRIPTIONS",params,columnName);
    }
    
    private void disableUser(String user_email_id) throws Exception {    	
    	this.urlData.put("ID", getUserData(user_email_id,"id"));
		to(adminUserViewPage,urlData);
		adminUserViewPage.disable_btn.click();
		adminUserViewPage.enable_Btn.waitUntilVisible();		
	}

}
