package com.rpxcorp.insight.page.detail;

import com.rpxcorp.insight.module.ListPanel;
import com.rpxcorp.insight.module.Radio;
import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;

public class PtabTechCenterPage extends BaseDetailPage {

    public PtabTechCenterPage() {
        this.url = new PageUrl("tech_center/{ID}");
    }

    @Override
    public boolean at() {
        waitForPageLoad();
        return detailPageTitle.waitUntilVisible();
    }
    public final Element subHeader = $(".include-subsidiaries-cls p.subtitle");

   public final Element techCenterDescription = $("div[data-behavior='responsive_expanding_accordions'] div>p");

   public final Element sectionTitle = $(".block-header h5.section-title");
    public final StaticContent techCenterStats = $(".panel-metrics", (Configure<StaticContent>) dataForm ->
            {
                dataForm.content("active_petitions", ".metrics_card:contains(Active Petition) .count");
                dataForm.content("inactive_petitions", ".metrics_card:contains(Inactive Petition) .count");
                dataForm.content("average_cases_per_year", ".metrics_card:contains(Average Petitions Per Year) .count");
                dataForm.content("average_length_of_case_in_days", ".metrics_card:contains(Average Petition Length) .count");

            }
    );

    public final Table petitionsTable = $("div#litigations-container .venue_judge_case_table", (Configure<Table>) table ->
            {
                table.uniqueId("td.case_title+td a");
                table.nextPage("div#litigation-cases ul.pagination.pagination li:last-child");
                table.lastPage("div#litigation-cases ul.pagination.pagination li:nth-last-child(2)");
            }
    );


    public final Radio petitionCostsByStageCostTypeRadio = new Radio(".choose-cases-type");

    public final Element recentActivityHeader = $("#recent_activity h5.section-title");
    public final Element recentActivity = $("#recent_activity", (Configure<ListPanel>) list ->
            {
                list.viewAllLink(".view-all-link-margin .view-all");
                list.dataKey("li>a[href]");
            }
    );


}
