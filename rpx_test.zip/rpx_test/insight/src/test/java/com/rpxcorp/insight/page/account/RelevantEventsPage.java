package com.rpxcorp.insight.page.account;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class RelevantEventsPage extends BasePage {

    public RelevantEventsPage() {
        this.url = new PageUrl("admin/relevant_events");
    }

    @Override
    public boolean at() {
        return preview_email_btn.waitUntilVisible();
    }

    /* CONTENT OF ENTITY DETAIL PAGE * */
    public final Element preview_email_btn = $(".button[value='Preview Email']");

}
