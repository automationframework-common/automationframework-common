package com.rpxcorp.insight.page.detail;

import com.rpxcorp.insight.module.ListPanel;
import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.insight.module.Table;
import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.insight.page.LoginPage.ROLES;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class EntityDetailPage extends BaseDetailPage {

	public EntityDetailPage() {
		this.url = new PageUrl("ent/{ID}") {
			{
				param("INCLUDE_SUBSD", "include_subsidiaries");
			}
		};
	}

	@Override
	public boolean at() {
		waitForPageLoad();
		waitForLoading();
		return detailPageTitle.waitUntilVisible();
	}


	/* NPE Profile and Detail section  */
	public final Element npeProfileDetails = $("#entity_npe_profile div.panel.cms-content");
	public final Element npeProfileDetails_pc=$(By.xpath("//div[@id='entity_npe_profile']//div[@class='subscription-promo-message']//a[text()='Start with a Free Trial']"));
	public final Element npeProfile_section_SignOnMsg = $(By.xpath("//div[@id='entity_npe_profile']//div[@class='subscription-promo-message']//a[text()='Sign In']/../span[text()='or']/../a[text()='Start with a Free Trial']"));

	/* CONTENT OF ENTITY DETAIL PAGE * */
	//public final Element entityName = $(".presenter-name-cls.detail-page-title>span:first-child");//h1.presenter-name-cls>span
	public final Element npeTagInTitle = $(".presenter-name-cls.detail-page-title span.npe_tag");
	public final Element npeTagInRelatedEnt = $("#subsidiaries span.npe_tag:contains(NPE)");
	public final Element npeTagInAffiliates = $("#affiliates span.npe_tag:contains(NPE)");
	public final Element share_link_btn = $("a[title='Share Link']");
	public final Element login_share_link_btn = $("a[title='Login Share Link']");
	public final Element create_alert_btn = $("[data-track-action='create_alert']");

	public final Element create_alert_btn_Anonymous = $("ul.button-group a.disabled");
	public final Element alertDialog = $("#alert-modal input[value='Create Alert']");
	public final Element hourlyAlertRadioBtn = $("#alert-modal #alert_delivery_hourly");
	public final Element hourlyStaticToolTip = $("li[data-behavior='static_tooltip']");
	public final Element closeIconAlertsDialog = $("#alert-modal a.close-reveal-modal");

	//Role Authorization for Alerts
	public final Element dc_Events=$(".alert_subscription input#District_Court_Events:not([class*='greyed-out']):visible");
	public final Element ptab_Events=$("#alert-modal input#PTAB_Events:not([class*='greyed-out']):visible");
	public final Element itc_Events=$("#alert-modal input#ITC_Events:not([class*='greyed-out'])");
	public final Element rpx_Reports_Events=$("#alert-modal input#RPX_Reports:not([class*='greyed-out'])");
	public final Element prior_art_Report_Event=$("#alert-modal input#alert_event__400:not([class*='greyed-out'])");
	public final Element alert_Btn_SignInMsg=$("#alerts_controls_holder a[data-ot-content*='sign in']");
	public final Element event_Promotional_Msg=$(".events_promotional_msg a[href='/payments/options']");
	public void loadAlertModal() {
		if (create_alert_btn.isDisplayed()) {
			create_alert_btn.click();
			alertDialog.waitUntilVisible();
		}
	}

	public final Element patentPortfolio = $("a.patent-portfolio-link");
	public final Element dosier_btn = $("a[title='Download Options']");
	public final Element about_section = $("#entity_npe_profile .panel.cms-content a");
	public final Element news_title = $(".orbit-container");
	public final Element subsidariesList = new ListPanel("#subsidiaries");
	public final Element subsidariesCount = $("#subsidiaries h5.section-title");
	public final Element affilatesList = new ListPanel("#affiliates");
	public final Element affilatesCount = $("#affiliates h5.section-title");
	
	/* PATENT SECTION */
	public final Element patentCount = $("#patents .header-section div.metrics-round-shape");
	public final Element patentPlaintiffTabLink = $("#entity-patents [data-lit-type=plaintiff] a");
	public final Element patentDefendantTabLink = $("#entity-patents [data-lit-type=defendant] a");
	public final Element patent_table = $("#asserted-patents-content table", (Configure<Table>) table ->
		{
			table.viewAllLink("#asserted-patents-content .view-all-entries");
			table.uniqueId("td:nth-child(1)");
		}
	);

	/* LITIGATION SECTION */
	public final Element litigation_count = $("#litigations-container .metrics-round-shape+h5.sub-section-title");
	public final StaticContent overview_panel = $(".panel-metrics", (Configure<StaticContent>) dataForm ->
		{
			dataForm.content("active", ".metrics_card:contains(Active Cases) .count");
			dataForm.content("inactive", ".metrics_card:contains(Inactive Cases) .count");
			dataForm.content("inactive", ".metrics_card:contains(Appeals) .count");
			dataForm.content("patents_in_litigation", ".metrics_card:contains(Patents in Litigation) .count");
			dataForm.content("petitions", ".metrics_card:contains(Petitions) .count");
			dataForm.content("reexaminations", ".metrics_card:contains(Reexaminations) .count");
			dataForm.content("related_entities", ".metrics_card:contains(Related Entities) .count");
		}
	);
	public final Element litAllCasesTabLink = $(".entity_lit_campaing_container dd[data-target='litigation-cases']");
	public final Element litPlaintiffCasesTabLink = $(".entity_lit_campaing_container dd[data-lit-type='plaintiff']");
	public final Element litDefendantTabLink = $(".entity_lit_campaing_container dd[data-lit-type='defendant']");
	public final Element lit_table_campaign_link = $(".lit_campaing_table .campaign-title");
	public final Element litigation_table_withoutUnique = new Table("#litigations-container-content table");
	public final Table litigation_table = $("#litigations-container-content table", (Configure<Table>) table ->
		{
			table.viewAllLink("#litigations-container-content div[target='litigation-cases'] a.view-all-entries.no-border");
			table.uniqueId("td:nth-child(3) a[href]");
		}
	);

    public final Element lcaButton = $(".right-resource-content>div.resource-content div.columns:contains('Litigation Campaign Assessment')+div.columns:last-child() img.download-icon");
	public final Element requestUpdateForLCA = $("#qtip-0-content span a");
	public final Element successMsgForRequestUpdateLCA = $("#qtip-0-content span");
	public final Table lcaModal = $("#lca_report_modal", (Configure<Table>) table ->
	{
		table.column("document_campaign", " td:nth-of-type(1)");
		table.column("updated_date", " td:nth-of-type(2)");
	}
			);

	public final Element campaignview_button = $(".switch.round.apply_filter.active");
	public final Element active_button = $(By.id("active-case-type"));
	public final Element inactive_button = $(By.id("inactive-case-type"));
	public final Element npeFilter = $(By.id("npe-parties"));
	public final Element otherFilter = $(By.id("others-parties"));
	public final Element errorHeader = $(".large-12.columns>h1");
	// public final Element recentActivity=$("#recent_case_activity a");
	public final Element newsSection = $(".panel.pos-relative");
	public final Element affiliateTitle = $("#affiliates h5");
	public final Element casesByMarketSectorGraph = $(".panel.cases-by-market-sector");
	public final Element non_campaign_ViewBtn = $("#litigations-container .switch.small.apply_filter:not(.active) label[for='lit_view']");
	public final Element campaign_ViewBtn = $("#litigations-container .switch.small.apply_filter.active label[for='lit_view']");

	public final Element campaignViewInLitigations = $("#litigations-container .switch.small.apply_filter label[for='lit_view']");
	// AFFILIATES SECTION
	public final Element affilatesLinks = $("#affiliates ul>li>a[href^='/ent']");
	public final Element affilatesWithoutData = $("#affiliates li:contains('This entity currently has no known affiliates')");

	public final Element affiliatesSignInMsg =  $("div>h5:contains('Affiliates')+div.columns:has(div.subscription-promo-message) a.signin:contains('Sign In') ~ span:contains('or') ~ a.blocked-content-promo.trial:contains('Start with a Free Trial')");
	public final Element affiliatesPromotionalMsg = $("div>h5:contains('Affiliates')+div:has(.blocked-content-promo.trial:contains('Start with a Free Trial'))");
/*
	public final Element affiliatesPromotionalMsg_without_FF = $(By.xpath("//h2[contains(text(),'Affiliates')]/..//a[text()='Learn more']"));
*/
	// SUBSIDIARIES SECTION
	public final Element subsidiariesLinks = $("#subsidiaries ul>li>a[href^='/ent']");
	public final Element subsidiariesWithoutData = $(By.xpath(
			"//*[@id='subsidiaries']//li[contains(text(),'This entity currently has no known Related Entities.')]"));
	public final Element subsidiariesSignInMsg = $("div>h5:contains('Related Entities')+div.columns:has(div.subscription-promo-message) a.signin:contains('Sign In') ~ span:contains('or') ~ a.blocked-content-promo.trial:contains('Start with a Free Trial')");
	public final Element subsidiariesPromotionalMsg = $("div>h5:contains('Related Entities')+div:has(.blocked-content-promo.trial:contains('Start with a Free Trial'))");
	/*public final Element subsidiariesPromotionalMsg_without_FF = $(By.xpath(
"//h2[contains(text(),'Related Entities')]/..//a[text()='Learn more']"));*/

	public void changeCampaignView() {
		campaignview_button.click(false);
		waitForSectionLoading();
	}

	public void switchToCampaignView() {
		if (non_campaign_ViewBtn.isDisplayed()) {
			non_campaign_ViewBtn.click();
			waitForSectionLoading();
			campaignViewInLitigations.waitUntilVisible();
		}
	}

	public void switchToCaseView() {
		if (campaignViewInLitigations.isDisplayed() && campaign_ViewBtn.isDisplayed()) {
			campaignViewInLitigations.click();
			waitForSectionLoading();
			non_campaign_ViewBtn.waitUntilVisible();
		}
		campaignViewInLitigations.waitUntilVisible();
	}

	public void filterActiveCases() {
		active_button.click(false);
		waitForSectionLoading();;
	}

	public void filterInActiveCases() {
		inactive_button.click(false);
		waitForSectionLoading();
	}

	public final Element all_button = $(By.id("all-case-type"));

	public void filterAllCases() {
		all_button.click(false);
		waitForSectionLoading();
	}

	public void filterPetitioner() {
		petitioner_radio.click(false);
		waitForSectionLoading();
	}

	public void filterPatentOwner() {
		patent_owner.click(false);
	}

	public void selectPatentDefendantTab() {
		if (patentDefendantTabLink.isDisplayed()) {
			patentDefendantTabLink.click();
		}
	}

	public void selectPatentPlaintiffTabLink() {
		if (patentPlaintiffTabLink.isDisplayed()) {
			patentPlaintiffTabLink.click();
		}
	}

	public void selectLitPlaintiffTabLink() {
		if (litPlaintiffCasesTabLink.isDisplayed()) {
			litPlaintiffCasesTabLink.click();
			waitForSectionLoading();
		}
	}

	public void selectLitDefendantTab() {
		if (litDefendantTabLink.isDisplayed()) {
			litDefendantTabLink.click();
			waitForSectionLoading();
		}
	}

	public void selectPartiesTab() {
		if (partiesTabLink.isDisplayed()) {
			partiesTabLink.click();
			waitForSectionLoading();
		}
	}

	public void selectPatentsTab() {
		if (patentsTabLink.isDisplayed()) {
			patentsTabLink.click();
			waitForSectionLoading();
		}
	}

	public void filterNPE() {
		npeFilter.moveTo();
		npeFilter.click(false);
		waitForSectionLoading();
	}

	public void filterOthers() {
		otherFilter.moveTo();
		otherFilter.click(false);
		waitForSectionLoading();
	}

	public final Element non_campaign_view_button = $(".icon-cross");
	public final Element campaign_view_button = $(".icon-briefcase");

	public void nonCampaignView() {
		non_campaign_view_button.click(false);
		waitForSectionLoading();
	}

	public final Element campaign_active_tab_count = $(".entity_lit_campaing_container .active>a");

	public final Element non_campaign_active_tab_count = $("#entity_lit_container .active>a");

	public final Table cases_By_Market_Sector = $("ul.bar-graph", (Configure<Table>) table ->
		{
			table.uniqueId("div.graph-label");
			table.column("count", " .graph-count ");
		}
	);

	@SuppressWarnings("incomplete-switch")
	public List<Object> checkHourlyAlerts(ROLES role) {
		List<Object> checkList = new ArrayList<Object>();
		switch (role) {
		case EXTERNAL_MEMBER:
			checkList.add(!(hourlyAlertRadioBtn.isDisplayed()));
			checkList.add("Hourly Alerts Option is displayed in Create Alert Dialog");
			break;
		case BASIC:
			checkList.add(!(hourlyAlertRadioBtn.isSelected()) && hourlyStaticToolTip.getAttribute("data-ot-content")
					.contains("Hourly alerts are not included in your current subscription."));
			checkList.add("Hourly Alerts Option is not displayed in Create Alert Dialog");
			break;
		}
		return checkList;
	}

	// AUTHORIZATION
	public final Element defendantLinkInLitCampaign = $(
			"#litigation-cases a[data-behavior='async_modal prevent_click_propagation']");
	public final Element defendantModal = $("#async_modal table");

	public void openDefendantModal() {
		if (defendantLinkInLitCampaign.isDisplayed()) {
			defendantLinkInLitCampaign.click();
			overlay_Loading.waitUntilInvisible();
			defendantModal.waitUntilVisible();
		}
	}

	public final Element itcMostRecentCaseMasked = $(By
			.xpath("//table[contains(@class,'campaign_defendants_table')]//tbody/tr[1]/td[3]//a[text()='337-TA-000']"));
	public final Element itcMostRecentCase = $(By.xpath(
			"//table[contains(@class,'campaign_defendants_table')]//tbody/tr[1]/td[3]//a[not(text()='337-TA-000')]"));
	public final Element firstSubtableOpen = $("tr:nth-of-type(1) .open.cursor-pointer");
	public final Element firstSubtableClose = $("tr:nth-of-type(1) .close.cursor-pointer");
	public final Element defendantSubtable = $(".case_details table.nested_inner_table");

	public void openDefendantSubtable() {
		if (!defendantModal.isDisplayed()) {
			openDefendantModal();
		}
		if (firstSubtableOpen.isDisplayed()) {
			firstSubtableOpen.click();
			defendantSubtable.waitUntilVisible();
		}
	}


	public final Element defSubtableItcCaseName_Login = $(By.xpath(
			"//*[@id='async_modal']//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[2][text()='Please login to view.']"));
	public final Element defSubtableItcCaseName_Masking = $("table.nested_inner_table tbody>tr:nth-of-type(1)>td:nth-child(3):contains('ITC access not available')>a:contains(Learn More)"); //$(By.xpath("//*[@id='async_modal']//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[2][contains(text(),'ITC access not available')]/a[text()='Learn More']"));
	public final Element defSubtableItcCaseNoMasked = $("table.nested_inner_table tbody>tr:nth-of-type(1)>td:nth-child(4)>a:contains(337-TA-000)");  // $(By.xpath("//*[@id='async_modal']//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[3]/a[text()='337-TA-000']"));
	public final Element defSubtableItcCaseNoLInk = $(".litigations_table.nested_inner_table tbody tr td.docket-number>a[href*='/usitc/']:visible()");
	public final Element defSubtableItcCaseNameLink = $(".litigations_table.nested_inner_table tbody tr td.docket-number a[href*='/usitc/']:visible()"); //$(By.xpath("//*[@id='async_modal']//table[contains(@class,'nested_inner_table')]//tbody/tr[1]/td[2]/a[contains(@href,'/itc/')]"));

	/*public final Element litigations_pc_signIn_without_FF = $(By.xpath("//h2[contains(text(),'Litigation')]/../following-sibling::div//a[contains(text(),'sign in')]"));*/
	public final Element litigations_pc = $(
			"div[class='large-8 columns']>div:nth-of-type(2) .promotional_content a[href*='mailto']");
	public final Element maskedCampNameInCampViewOfLitigations = $(By.xpath(
			"//*[@id='litigations-container']//table//tr[1]/td[1][contains(text(),'ITC CAMPAIGN (X,XXX,XXX)')]"));
	public final Element dummyRecentCaseInCampViewOfLitigations = $(
			By.xpath("//*[@id='litigations-container-content']//table//tr[1]/td[4]/a[text()='337-TA-000']"));
	public final Element noLitigations = $("div[data-behavior='sol_accordion'] div.content div.panel:contains('not known to have been party to any patent litigation')");//$(By.xpath("//div[@class='panel']//h4[contains(text(), 'not known to have been party to any patent litigation')]"));
	public final Element noCasesFound = $("#litigations-container-content span:contains('No Cases found')");
	public final Element campNameInCampViewOfLitigations = $("#litigations-container table tr:nth-child(1) td:nth-child(1) a");
	public final Element mostRecentCaseInCampViewOfLitigations = $("#litigations-container-content table tr:nth-child(1) td.docket-number a");
	public final Element startDateInCampViewOfLitigations = $("#litigations-container-content table tr:nth-child(1) td:nth-child(1)");
	public final Element termDateInCampViewOfLitigations = $("#litigations-container-content table tr:nth-child(1) td:nth-child(4)");
	public final Element recentActivity = $("#recent_case_activity", (Configure<ListPanel>) list ->
		{
			list.viewAllLink(".view-all-link-margin .view-all");
			list.dataKey("li>a[href]");
		}
	);

	//AFFILIATES
	public final ListPanel affiliates_Panel=$("#affiliates ul", (Configure<ListPanel>) list ->
		{
			list.viewAllLink(By.xpath("//*[@id='affiliates']//a[text()='View All']"));
			list.viewLessLink(By.xpath("//*[@id='affiliates']//a[text()='View Less']"));
			list.link("#affiliates ul:not([style*='none']) li a");
		}
	);
	public final Element affiliates_npe_entity=$("#affiliates ul>li:contains(NPE) a");

	// RELATED ENTITIES
	public final ListPanel related_Entities_Panel = $("#subsidiaries ul", (Configure<ListPanel>) list ->
		{
			list.viewAllLink(By.xpath("//*[@id='subsidiaries']//a[text()='View All']"));
			list.viewLessLink(By
					.xpath("//*[@id='subsidiaries']//a[text()='View Less']"));
			list.link("#subsidiaries ul:not([style*='none']) li a");
		}
	);

	public final Element related_npe_entity=$("#subsidiaries ul>li:contains(NPE) a");

	// PATENT INFORMATION
	public final Table patent_Information = $("#entity-patents .active table", (Configure<Table>) table ->
		{
			table.viewAllLink(By.xpath("//*[@id='entity-patents']//a[text()='View All']"));
			table.viewMoreLink(By.xpath("//*[@id='entity-patents']//a[text()='View More']"));
			table.viewLessLink(By.xpath("//*[@id='entity-patents']//a[text()='View Less']"));
			table.displayedRecords("#entity-patents .active table tbody tr:not([style='display: none;'])");
		}
	);

	public final Element patent_Information_SubTitleCount=$("div#patents div.metrics-round-shape");
	public final Element patent_Information_Active_Tab=$("#entity-patents dd.active");
	public void selectTabAtPatentInformation(String tabName) {
		Element activeTab=$("#entity-patents dd.active a");
		if(!activeTab.getText().toUpperCase().contains(tabName.toUpperCase())) {
			String xpath=String.format("//*[@id='entity-patents']//dd/a[contains(text(),'%s')]", tabName);
			Element requiredTab=$(By.xpath(xpath));
			requiredTab.click();			 
		}
	}

	// PETITIONS SECTION
	public final Element petitioner_radio = $(By
			.id("petitioner_petitions_radio"));
	public final Element patent_owner = $(By.id("patent_owner_petitions_radio"));

	//PETITIONS SECTION - PETITIONS TABLES
	public final Table petition_table = $("#entity-ptabs-content table", (Configure<Table>) table ->
		{			
			table.uniqueId("td:nth-child(3) a[href]");
			table.viewAllLink(By.xpath("//*[@id='entity-ptabs-content']//a[text()='View All']"));
			table.viewLessLink(By.xpath("//*[@id='entity-ptabs-content']//a[text()='View Less']"));
			table.displayedRecords("#entity-ptabs-content table tbody tr:not([style='display: none;'])");
		});

	// PETITIONS SECTION - PARTIES AND PATENT TABLES
	public final Element partiesTabLink = $("#entity-ptabs [data-lit-type=parties] a");
	public final Element patentsTabLink = $("#entity-ptabs [data-lit-type=patents] a");
	public final Element entLinkAtPartiesTab=$("#entity-ptabs-content div:nth-of-type(3) div.handle>a");
	public final Element patLinkAtPatentTab=$("#entity-ptabs-content div:nth-of-type(1) div.handle>a");
	public final Element petitionMetricsForParties=$("#entity-ptabs-content div:nth-of-type(1) div.handle li.result-count");
	public final Element partyTypeDropDown = $("#entity-ptabs select#party_type");
	public void selectPartyTypeValues(String partyType){
		partyTypeDropDown.selectByOption(partyType);
		waitForSectionLoading();
	}

	public final Table partiesNPatentTable = $("#entity-ptabs-content.active", (Configure<Table>) table -> {
			table.row("div.group.nested");
			table.uniqueId("div.handle>a");
			table.expandSubTableLink("div.group.nested div.handle");
			table.subTable($("table.table_section", (Configure<Table>) subtable ->
				{
					subtable.uniqueId("td:nth-child(2) a[href];td:nth-child(4)");
					subtable.displayedRecords("#entity-ptabs .active>div:nth-of-type(1) table tbody tr:not([style='display: none;'])");
				}));

		});

	public void selectTabInPetitionSection(String tabName) {
		Element activeTab = $("#entity-ptabs dd.active a");
		if (!activeTab.getText().toUpperCase().contains(tabName.toUpperCase())) {
			String xpath = String.format(
					"//*[@id='entity-ptabs']//dd/a[contains(text(),'%s')]",
					tabName);
			Element requiredTab = $(By.xpath(xpath));
			requiredTab.click();
		}
	}

	public void change_filter_For_PetionsSection(String filterName) {
		selectPartyTypeValues(filterName);
	}
	//US Reexamination started

	public final Table usreexaminationTable = $("#us_reexamination table", (Configure<Table>) table ->
	{
		table.uniqueId("td:nth-child(3) a[href]");
		table.viewAllLink(By.xpath("//*[@id='us_reexamination']//a[text()='View All']"));
		table.viewLessLink(By.xpath("//*[@id='us_reexamination']//a[text()='View Less']"));
		table.displayedRecords("#us_reexamination table tbody tr:not([style='display: none;'])");
	});
	public final Tabs usReexaminationTabs = new Tabs("#entity_cn_prb:has(h5:contains(Reexaminations)) dl");
//	public void selectTabInReexaminationSection(String tabName) {
//		Element activeTab = $("#entity-cn-prbs dd.active a");
//		if (!activeTab.getText().toUpperCase().contains(tabName.toUpperCase())) {
//			String xpath = String.format(
//					"//*[@id='entity-cn-prbs']//dd/a[contains(text(),'%s')]",
//					tabName);
//			Element requiredTab = $(By.xpath(xpath));
//			requiredTab.click();
//		}
//	}

	public final Element uspartyTypeDropDown = $("#reexam-cn-prbs select#party_type");
	public void selectusPartyTypeValues(String partyType){
		uspartyTypeDropDown.selectByOption(partyType);
		waitForSectionLoading();
	}
	public void change_filter_For_usReexaminationSection(String filterName) {
		selectusPartyTypeValues(filterName);
	}
	public final Element usentLinkAtRequesterTab=$("dd a[href='#reexamination_requester']");
	public final Element usReexaminationMetricsForRequester=$("#reexamination_requester div:nth-of-type(1) div.handle li.result-count");

	/*public final Table usrequesterTable = $("#reexamination_requester.content.active", (Configure<Table>) table -> {
		table.row("div.group.nested");
		table.uniqueId("div.handle>a");
		table.expandSubTableLink("div.group.nested div.handle");
		table.subTable($("table.table_section", (Configure<Table>) subtable ->
		{
			subtable.uniqueId("td:nth-child(2) a[href]");
			subtable.displayedRecords("#reexamination_requester.active>div:nth-of-type(1) table tbody tr:not([style='display: none;']) td.docket-number");
		}));

	});*/
	public final Table usRequesterTable = $("#reexamination_requester.content.active", (Configure<Table>) table -> {
		table.row("div.group.nested");
		table.uniqueId("div.handle>a");
		table.expandSubTableLink("div.group.nested div.handle");
		table.subTable($("table.table_section", (Configure<Table>) subtable ->
		{
			subtable.uniqueId("td:nth-child(2) a[href]");
			subtable.displayedRecords("#reexam-cn-prbs .active>div:nth-of-type(1) table tbody tr:not([style='display: none;'])");
		}));

	});
	public final Table usPatentTable = $("#reexamination_patents.content.active", (Configure<Table>) table -> {
		table.row("div.group.nested");
		table.uniqueId("div.handle>a");
		table.expandSubTableLink("div.group.nested div.handle");
		table.subTable($("table.table_section", (Configure<Table>) subtable ->
		{
			subtable.uniqueId("td:nth-child(2) a[href]");
			subtable.displayedRecords("#reexam-cn-prbs .active>div:nth-of-type(1) table tbody tr:not([style='display: none;'])");
		}));

	});
	public void selectTabInusReexaminationSection(String tabName) {
		Element activeTab = $("#reexam-cn-prbs dd.active a");
		if (!activeTab.getText().toUpperCase().contains(tabName.toUpperCase())) {
			String xpath = String.format(
					"//*[@id='reexam-cn-prbs']//dd/a[contains(text(),'%s')]",
					tabName);
			Element requiredTab = $(By.xpath(xpath));
			requiredTab.click();
		}
	}
	public final Element usreexaminationMetricsForRequester =$("#reexamination_patents div:nth-of-type(1) div.handle li.result-count");
	public final Element uspatListAtPatentTab=$("#reexamination_patents div:nth-of-type(1) div.handle>a");

	//US Reexamination ended
	//PRB Reexamination started

	public final Table reexaminationTable = $("#chinese_prb_reexamination table", (Configure<Table>) table ->
	{
		table.uniqueId("td:nth-child(3) a[href]");
		table.viewAllLink(By.xpath("//*[@id='chinese_prb_reexamination']//a[text()='View All']"));
		table.viewLessLink(By.xpath("//*[@id='chinese_prb_reexamination']//a[text()='View Less']"));
		table.displayedRecords("#chinese_prb_reexamination table tbody tr:not([style='display: none;'])");
	});
	public final Tabs chineseReexaminationTabs = new Tabs("#entity_cn_prb:has(h5:contains(Chinese PRB Reexaminations)) dl");
//	public void selectTabInReexaminationSection(String tabName) {
//		Element activeTab = $("#entity-cn-prbs dd.active a");
//		if (!activeTab.getText().toUpperCase().contains(tabName.toUpperCase())) {
//			String xpath = String.format(
//					"//*[@id='entity-cn-prbs']//dd/a[contains(text(),'%s')]",
//					tabName);
//			Element requiredTab = $(By.xpath(xpath));
//			requiredTab.click();
//		}
//	}

	public final Element PRBpartyTypeDropDown = $("#entity-cn-prbs select#party_type");
	public void selectPRBPartyTypeValues(String partyType){
		PRBpartyTypeDropDown.selectByOption(partyType);
		waitForSectionLoading();
	}
	public void change_filter_For_ReexaminationSection(String filterName) {
		selectPRBPartyTypeValues(filterName);
	}
	public final Element entLinkAtRequesterTab=$("#chinese_prb_requester div.handle a");
	public final Element ReexaminationMetricsForRequester=$("#chinese_prb_requester div:nth-of-type(1) div.handle li.result-count");

	public final Table requesterTable = $("#chinese_prb_requester.content.active", (Configure<Table>) table -> {
		table.row("div.group.nested");
		table.uniqueId("div.handle>a");
		table.expandSubTableLink("div.group.nested div.handle");
		table.subTable($("table.table_section", (Configure<Table>) subtable ->
		{
			subtable.uniqueId("td:nth-child(2) a[href]");
			subtable.displayedRecords("#chinese_prb_requester .active>div:nth-of-type(1) table tbody tr:not([style='display: none;'])");
		}));

	});

	public final Table requesterNPatentTable = $("#chinese_prb_patents.content.active", (Configure<Table>) table -> {
		table.row("div.group.nested");
		table.uniqueId("div.handle>a");
		table.expandSubTableLink("div.group.nested div.handle");
		table.subTable($("table.table_section", (Configure<Table>) subtable ->
		{
			subtable.uniqueId("td:nth-child(2) a[href]");
			subtable.displayedRecords("#entity-cn-prbs .active>div:nth-of-type(1) table tbody tr:not([style='display: none;'])");
		}));

	});
	public void selectTabCNPRBReexaminationSection(String tabName) {
		Element activeTab = $("#entity-cn-prbs dd.active a");
		if (!activeTab.getText().toUpperCase().contains(tabName.toUpperCase())) {
			String xpath = String.format(
					"//*[@id='entity-cn-prbs']//dd/a[contains(text(),'%s')]",
					tabName);
			Element requiredTab = $(By.xpath(xpath));
			requiredTab.click();
		}
	}
	public final Element reexaminationMetricsForRequester =$("#chinese_prb_patents div:nth-of-type(1) div.handle li.result-count");
	public final Element PRBpatListAtPatentTab=$("#chinese_prb_patents div:nth-of-type(1) div.handle>a");

	//PRB Reexamination ended
	//DOSSIER
	public final Element dossierBtn = $(".right-resource-content>div.resource-content div.columns:contains('Dossier')+div.columns>*[data-tooltip-class='dossier-btn'] img");
	public final Element dossierProfileStatus = $(".qtip-content .dossier-btn span:not(.profile-update-container)");
	//public final Element dossierRequestUpdateOption = $(".qtip-content .profile-update-container a");
	public final Element dossierRequestUpdateOption = $(".qtip-content .dossier-btn span.profile-update-container");
	public final Element dossierPromoMsg = $(By.xpath("//div[@class='qtip-content']/div[text()='Dossiers are not available for your current subscription level. Please ']/a[text()='Upgrade']"));
	//public final Element dossierPromoMsg = $(By.xpath("//div/div[@class='dossier-btn'][contains(text(),'Dossiers are not available for your current subscription level')]"));
	public void clickAndHoldDossier() {
		if(dossierBtn.isDisplayed()) {
			dossierBtn.clickAndHold();
			waitForPageLoad();
		}
	}

	public final Element requestLinkInDossierToolTip = $(".dossier-btn a");
	public final Element msgInToolTipAfterDossierRequest= $(".dossier-btn .profile-update-container");
	public final Element contactUsInDossierToolTip = $(".dossier-btn .profile-update-container a");
	public void requestDossierProfile() {
		requestLinkInDossierToolTip.waitUntilVisible();
		requestLinkInDossierToolTip.click();
		waitForPageLoad();
	}

	public Map<String, String> getOptionsFromDossierBtn() {
		dossierBtn.clickAndHold();
		dossierProfileStatus.waitUntilVisible();
		Map<String, String> dossierQtip = new HashMap<String, String>();
		dossierQtip.put("profile_status",dossierProfileStatus.getText());
		dossierQtip.put("request_status", dossierRequestUpdateOption.getText());

		return dossierQtip;
	}
	
	public final Element profileStatus_InDossierModal=$("#download-options-modal li .profile-update-container");
	public final Element profileStatusText_InDossierModal=$("#download-options-modal li:nth-of-type(1)>label>span:not([class='profile-update-container'])");
	public final Element dossierModal=$("#download-options-modal li");
	public final Element dossierModal_CloseIcon=$("#download-options-modal a.close-reveal-modal");
	public final Element download_InDossierModal=$("#dossier_selection_form input[value='Download']");
	public final Element dossier_loading_Img=$("img[src='/images/ajax-loader.gif']");
	public final Element dossier_checkedOptions=$("#dossier_options_[checked='checked']:not([disabled='disabled'])+label+span");
	public final Element dossier_allOptions=$("#dossier_options_[checked='checked']+label+span");
	public final Element dossier_disabledOptions=$("#dossier_options_[disabled='disabled']+label+span");
	public final Element dossier_ErrorMsg=$("#dossier_form_error");
	
	public void openDossierModal() {
		if(dossierBtn.isDisplayed()) {
			dossierBtn.click();
			dossierModal.waitUntilVisible();
		}		
	}
	
	public void unSelectAllDossierOptions() {
		List<WebElement> elemts=$("#dossier_options_[checked='checked']:not([disabled='disabled'])").getElements();
		for(WebElement elem:elemts) {
			if(elem.isSelected()) {
				elem.click();
			}
		}
	}
	public void downloadDossier() throws InterruptedException {
		download_InDossierModal.click();
		dossier_loading_Img.waitUntilInvisible();
	}
	
	public void closeDossierModal() {
		if(dossierModal_CloseIcon.isDisplayed()) {
			dossierModal_CloseIcon.click();
			dossierModal.waitUntilInvisible();
		}		
	}
	
	public Map<String, String> getOptionsFromDossierModal() {
		openDossierModal();
		Map<String, String> dossierQtip = new HashMap<String, String>();
		dossierQtip.put("profile_status",profileStatus_InDossierModal.getText());
		dossierQtip.put("request_status", profileStatusText_InDossierModal.getText());

		return dossierQtip;
	}
	
	//AUTHORIZATION PETITION SECTION
    public final Element petition_tab_pc= $("#entity-ptabs ul>li#entity-ptabs-content .subscription-promo-message a:contains('Start with a Free Trial')");
//    public final Element petition_tab_pc_without_FF=$(By.xpath("//li[@id='entity-ptabs-content']//h4[contains(text(),'not included in your current subscription')]"));
    public final Element parties_tab_pc=$(By.xpath("//div[@id='entity_ptabs']//div[@class='subscription-promo-message']//a[text()='Start with a Free Trial']"));
//    public final Element parties_tab_pc_without_FF=$(By.xpath("//li[@id='entity-ptabs-content']//h4[contains(text(),'not included in your current subscription')]"));
    public final Element patents_tab_pc=$(By.xpath("//div[@id='entity_ptabs']//div[@class='subscription-promo-message']//a[text()='Start with a Free Trial']"));
//    public final Element patents_tab_pc_without_FF=$(By.xpath("//li[@id='entity-ptabs-content']//h4[contains(text(),'not included in your current subscription')]"));
    public final Element petition_section_signOn=$(By.xpath("//div[@id='entity_ptabs']//div[@class='subscription-promo-message']//a[text()='Sign In']/../span[text()='or']/../a[text()='Start with a Free Trial']"));
//    public final Element petition_section_signOn_without_FF=$(By.xpath("//h2[contains(text(),'Petitions')]/../following-sibling::div//a[contains(text(),'sign in')]"));
    public final Element petition_table_td_data=$(By.xpath("//li[@id='entity-ptabs-content']//table/tbody/tr/td[text()]"));
	public final Element litigation_section_SignOnMsg = $("#litigations-container-content div.subscription-promo-message a:contains('Sign In')");
    public final Element litigation_FreeTrialPromoMsg=$("#litigations-container-content div.subscription-promo-message a:contains('Start with a Free Trial')");
	public final Element litigationBasicUserCaseView=$("#litigations-container-content table tr:nth-child(1) td:nth-child(2) a");

	public final Element patentInLitigationPromoMsg=$(By.xpath("//div[@id='entity-patents']//div[@class='subscription-promo-message']//a[text()='Start with a Free Trial']"));
	public final Element patentInLitigationSignOnMsg=$(By.xpath("//div[@id='entity-patents']//div[@class='subscription-promo-message']//a[text()='Sign In']/../span[text()='or']/../a[text()='Start with a Free Trial']"));

	public void clickOnPartiesTab() {
    	if(partiesTabLink.isDisplayed()) {
    		partiesTabLink.click();
    		loading.waitUntilInvisible();
    	}
    }
    
    public void clickOnPatentsTab() {
    	if(patentsTabLink.isDisplayed()) {
    		patentsTabLink.click();
    		loading.waitUntilInvisible();
    	}
    }
    
    //RELATED ENTITIES and AFFILIATES tooltip
    public final Element relatedEntity_Tooltip=$(By.xpath("//h2[contains(text(),'Related Entities')]//span[@class='has-tip bottomless']"));
    public final Element affiliates_Tooltip=$(By.xpath("//h2[contains(text(),'Affiliates')]//span[@class='has-tip bottomless']"));

    //DOSSIER Content for Sections
    public final String[] content=new String[] {
    	"Entity Profile","Details on the entity’s background, incorporation, and management; a summary of the entity’s patent portfolio; and a",
    	"Related Entities and Affiliates","List of related entities (subsidiaries controlled by the same corporate parent or entities controlled by the same third party,",
    	"News Articles","Articles written by the RPX Litigation Intelligence team covering newly filed litigation affecting RPX members and market",
    	"Litigation Campaign Assessments","A one-page overview of a single litigation campaign, providing essential background on the plaintiff(s), a detailed litigation",
    	"Litigation History","A list of all district court lawsuits involving the entity, grouped by litigation campaigns, along with information on the docket, courts,",
    	"Petitions","A list of all PTAB petitions involving the entity, grouped by litigation campaigns, along with information on the proceedings, challenged",
    	"Patent Portfolio","A list of all granted patents and published applications currently assigned to the entity or any of its related entities.",
    	"Prior Art Search Reports","Preliminary prior art reports for patents asserted by NPEs based on prior art searches systematically performed by RPX for the benefit"};


	//Role Auth locators for CAFC tag
	public final Element entityPatentInlitCAFCTag = $("#asserted-patents-content .cafc_call_out");
    
    
}
