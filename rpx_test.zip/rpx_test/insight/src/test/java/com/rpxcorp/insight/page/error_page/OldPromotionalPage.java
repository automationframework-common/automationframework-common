package com.rpxcorp.insight.page.error_page;

import org.openqa.selenium.By;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class OldPromotionalPage extends BasePage {

    @Override
    public boolean at() {
        oldupgrade.waitUntilVisible();
        return false;
    }

    public final Element oldupgrade = $("div.logged_in.page_blocked a:contains('upgrade')");
}
