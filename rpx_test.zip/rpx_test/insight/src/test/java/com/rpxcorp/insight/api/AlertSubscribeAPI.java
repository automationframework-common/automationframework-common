package com.rpxcorp.insight.api;

import com.rpxcorp.testcore.driver.APICache;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.util.HashMap;

public class AlertSubscribeAPI extends APICache {

    public void subscribe(String[] events,String pageUrl) throws Exception {
        HashMap<String, String> params = new HashMap<>();
        Document page = getAPIInstance().loadPage(pageUrl);
        Elements createAlertBtn = page.select("[data-alert-object-id]");
        if (createAlertBtn.size()==0)
            throw new Exception("Create Alert button not found in page "+getAPIInstance().getFullUrl(pageUrl));
        Document alertPage = getAPIInstance().loadPage("/alerts/fetch_subscription?id=&alert_object_id="
                +createAlertBtn.attr("data-alert-object-id")+"&alert_subscription_type_id="
                + createAlertBtn.attr("data-subscription-type-id")+"");
        params.put("authenticity_token", getAPIInstance().getCSRF_Token(page));
        for(String event:events){
            Elements gh = alertPage.select("label:contains(" + event + ") input");
            System.out.println(gh.attr("value"));
            String id =        gh.val();
            if(id.isEmpty())
                throw new Exception(event+" event not found");
            params.put("event_ids[]", id);
        }
        params.put("object_id", alertPage.select("#object_id").val());
        params.put("alert_object_type", alertPage.select("#alert_object_type").val());
        params.put("alert_object_name", alertPage.select("#alert_object_name").val());
        params.put("object_type_id", alertPage.select("#object_type_id").val());
        params.put("alert_delivery", "daily");
        params.put("commit", "Create Alert");
        getAPIInstance().post("/alerts", params);
    }
}
