package com.rpxcorp.insight.page;

import com.rpxcorp.insight.module.Tabs;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public abstract class BasePage extends Page {

    public final Tabs searchAllTabs = new Tabs("#search_results_replaced_content div.header-tabs dl.tabs dd");
    public final Element search_textarea = $("#searchq_revised");
    public final Element accountsMenu = $("li.account-space a.account-name");
    public final Element personalizedViewTab = $(".tabs.dashboard-header a:contains('Personalized View')");
    public final Element loginWelcomeMsg = $("a[class*='edit-dboard-btn']:visible"); //.dashboard .salutation:contains('Welcome')
    public final Element login_link=$("#primary-nav a.login-btn");
    public final Element currentSearch = $("#searchq_revised");

    public final Element pageTitle = $("#content h1");//#content .large-12.columns .section-title
    public final Element News_promo_text = $("div.anonymous-upgrade-block");

    public final Element detailPageTitle = $(".presenter-name-cls.detail-page-title");
    public final Element overlay_Loading = $(By.cssSelector(".blockUI.blockOverlay"));
    public final Element loading = $(".blockUI.blockMsg.blockElement>img");
    public final Element ajaxLoader =$("img[src='/images/ajax-loader.gif']");
    public final Element contentLoading = $(By.cssSelector(".cms_content_loading"));
    public final Element searchTextBox = $("input#searchq");
    public final Element alertMessage = $("#flash_name");
    public final Element rpx_Logo = $("#logo");
    public final Element toolTip = $(".tooltip");
    public final Element panelLinks = $(".panel a:not([href*='mailto'])");
    public final Element ajax_loading=$("img[alt='loading']");
    public final Element angularJs_loading=$(".loading-overlay");
    public final Element tooltip = $(".qtip-content");
    public final Element pdfviewer=$("embed[type='application/x-google-chrome-pdf']");
    public final Element signInToolTip=$(".qtip-content:has(a:contains('sign in')):contains('Please sign in to use this feature.'):visible()");
    public final Element npeFilterPromoToolTip=$(".qtip-content:has(a[href^='mailto:Portal-QA@rpxcorp"+
            ".com?subject=RPX Insight Account Upgrade - NPE Filter']:contains('contact us')):contains"+
            "('Your current subscription level does not allow you access to this feature. Please')");
    //GO TO ADV SEARCH LINKS
    public final Element goToAdvSearchLink=$("#affixed-table-header a.advanced_search_link[href*='/advanced_search']");
    public final Element goToAdvSearchLink_At_LitSearch=$("#affixed-table-header a.advanced_search_link[href*='/advanced_search?tab=patent_litigation']");
    public final Element goToAdvSearchLink_At_EntSearch=$("#affixed-table-header a.advanced_search_link[href*='/advanced_search?tab=entity']");
    public final Element goToAdvSearchLink_At_PatSearch=$("#affixed-table-header a.advanced_search_link[href*='/advanced_search?tab=patent']");
    public final Element goToAdvSearchLink_At_MarketSearch=$("#affixed-table-header a.advanced_search_link[href*='/advanced_search?tab=marketplace']");
    public final Element goToAdvSearchLink_At_PortfolioSearch=$("#affixed-table-header a.advanced_search_link[href*='/advanced_search?tab=portfolio']");

    public final Element advancedSearchDropdown = $("table.search-table-main td.gear-icon-td img.gear-icon");
    public final Element advancedSearchDropdownList = $("ul#advanced_drop");
    public final Element advancedSearchLink = $("a.advanced_search_link");
    public final Element glossarySearchLink = $("a:contains('Search Glossary')");
    public final Element searchFAQLink = $("a:contains('Search FAQ')");

    public void clickAllSearchTabs(String tabName) {
        searchAllTabs.select(tabName);
        waitForLoading();
    }

    public void clickOnAdvancedSearchLink() {
        advancedSearchDropdown.click();
        advancedSearchDropdownList.waitUntilVisible();
        advancedSearchLink.click();
    }

    public void clickOnSearchGlossaryLink() {
        advancedSearchDropdown.click();
        advancedSearchDropdownList.waitUntilVisible();
        glossarySearchLink.click();
    }

    public final Element SearchTypeLink = $(".search-table-main div.search-dropdown a#search-v2-menu-anc");
    public final Element searchMenu = $("#search-v2-menu");
    public void selectSearchType(String searchType){
        SearchTypeLink.click();
        searchMenu.waitUntilVisible();
        searchMenu.$("li:contains('"+searchType+"')").click();
        Assert.assertEquals(SearchTypeLink.getText().trim(),searchType);
    }
public final Element allSearchShowMore = $("#search_results_replaced_content span.show-more:visible()");
    public final Element allSearchShowLess = $("#search_results_replaced_content span.show-less:visible()");
    public void clickSelectAll() throws Exception {
        if (allSearchShowMore.isPresent())
                allSearchShowMore.click();
        allSearchShowLess.waitUntilVisible();
    }
    // To Force each page object to implement at method
    abstract public boolean at();

    // asserting page title in at method of required page
    public boolean assertPageTitle(String title) {
        pageTitle.waitUntilVisible();
        return pageTitle.waitUntilTextPresent(title);
    }

    public boolean waitForPageLoad() {
        searchTextBox.waitUntilVisible();
        return waitForLoading();
    }

    public boolean waitForLoading() {
        loading.waitUntilNoElementPresent();
        overlay_Loading.waitUntilNoElementPresent();
        return contentLoading.waitUntilNoElementPresent();
    }

    public boolean waitForSectionLoading() {
        loading.waitUntilNoElementPresent();
        return contentLoading.waitUntilNoElementPresent();
    }

    public void addIfNotEmpty(Map<String, Object> data, String key, Object value){
        if(value !=null &&
            (value.getClass().equals(ArrayList.class) && !((ArrayList)value).isEmpty()) ||
            (value.getClass().equals(HashMap.class) && !((HashMap)value).isEmpty()) ||
            (value.getClass().equals(String.class) && !((String)value).isEmpty())){
                data.put(key,value);
            }
    }

   public final Element recentActivitiesPromoMsg = $("#recent_activity div.subscription-promo-message:contains('Start with a Free Trial')");
    public final Element recentActivitiesSignOnMsg = $("#recent_activity div.subscription-promo-message:contains('Sign In')");
    public final Element marketSectorPromoMsg = $("div#market_sector_cases div.subscription-promo-message:contains('Start with a Free Trial')");
    public final Element marketSectorSignOnMsg = $("div#market_sector_cases div.subscription-promo-message:contains('Sign In')");
    public final Element recentActivityContent = $("div.activity:has(h2:contains('Recent Activities'))>ul:visible");
}
