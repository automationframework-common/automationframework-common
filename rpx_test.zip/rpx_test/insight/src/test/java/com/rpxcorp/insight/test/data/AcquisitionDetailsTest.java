package com.rpxcorp.insight.test.data;

import com.rpxcorp.insight.page.detail.AcquisitionDetailPage;
import com.rpxcorp.testcore.Authenticate;
import com.rpxcorp.testcore.TableData;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.sql.ResultSet;
import java.util.Map;
@Authenticate(role = "MEMBER")
public class AcquisitionDetailsTest extends BaseDataTest {
    AcquisitionDetailPage acqDetailPage;
    TableData tableData;
    Map<String, String> staticData;
    ResultSet resultSet;

    @Factory(dataProvider = "returnData")
    public AcquisitionDetailsTest(String dataDescription, String ptabId) {
        this.dataId = ptabId;
        this.dataDescription = dataDescription;
    }

    @DataProvider
    public static Object[][] returnData() throws Exception {
        return getTestData("AcquisitionDetail");
    }

    @BeforeClass
    public void loadPage() {
        urlData.put("ID", dataId);
        this.dataUrl = acqDetailPage.getDeclaredUrl(urlData);
        to(acqDetailPage, urlData);
    }

    @Test(description = "Verify Title", priority = 1)
    public void Title() throws Exception {       
    	resultSet = sqlProcessor.getResultData("AcquisitionDetail.HEADER_DETAILS", dataId);
    	assertEquals(acqDetailPage.detailPageTitle.getData(), resultSet, "title");
    }

    @Test(description = "Verify Priority", priority = 2)
    public void Priority() throws Exception {
        staticData = acqDetailPage.header_info.getData();
        assertEquals(staticData.get("priority"), resultSet, "priority");
    }

    @Test(description = "Verify Stage", priority = 3)
    public void Stage() throws Exception {
        assertEquals(staticData.get("stage"), resultSet, "stage");
    }

    @Test(description = "Verify Received Date", priority = 3)
    public void Received_Date() throws Exception {
        assertEquals(staticData.get("received_date"), resultSet, "received_date");
    }

    @Test(description = "Verify US patents count", priority = 4)
    public void US_patents_count() throws Exception {
        staticData = acqDetailPage.overview_status.getData();
        assertEquals(staticData.get("us_patents"), resultSet, "us_patents");
    }

    @Test(description = "Verify INT patents count", priority = 5)
    public void INT_patents_count() throws Exception {
        assertEquals(staticData.get("int_patents"), resultSet, "int_patents");
    }

    @Test(description = "Verify US Applications counts", priority = 5)
    public void US_Applications_count() throws Exception {
        assertEquals(staticData.get("us_applications"), resultSet, "us_applications");
    }

    @Test(description = "Verify INT Applications count", priority = 5)
    public void INT_Applications_count() throws Exception {
        assertEquals(staticData.get("int_applications"), resultSet, "int_applications");
    }

    @Test(description = "Verify Bid Deadline", priority = 6)
    public void Bid_Deadline() throws Exception {
        staticData = acqDetailPage.acquition_detail.getData();
        assertEquals(staticData.get("bid_deadline"), resultSet, "bid_deadline");
    }

    @Test(description = "Verify Analyst Point of Contact", priority = 7)
    public void Analyst_Name() throws Exception {
        assertEquals(staticData.get("analyst_name"), resultSet, "analyst_name");
    }

    // @Test(description = "Verify Owners Name", priority = 7)Removed as per
    // RPX-9633
    public void Owners_Name() throws Exception {
        assertEquals(staticData.get("owner_name"), resultSet, "owner_name");
    }

    @Test(description = "Verify Assignees Name", priority = 8)
    public void Assignees_Name() throws Exception {
        assertEquals(acqDetailPage.getAssignees(),
                sqlProcessor.getResultData("AcquisitionDetail.ASSIGNEE", dataId), "assignees_name");
    }

    @Test(description = "Verify Current Assignee Details")
    public void CurrentAssigneeDetails() throws Exception {
        assertEquals(acqDetailPage.assignee_table.getData(),
                sqlProcessor.getResultData("AcquisitionDetail.CURRENT_ASSIGNEE_TABLE", dataId));
    }

    @Test(description = "Verify Representative Claims", priority = 9)
    public void RepresentativeClaims() throws Exception {
        tableData = acqDetailPage.representative_claims.getData();
        resultSet = sqlProcessor.getResultData("AcquisitionDetail.REPRESENTATIVE_CLAIMS", dataId);
        assertEquals(tableData, resultSet, "patent_number");
    }

    @Test(description = "Verify Representative Claims Description", priority = 10)
    public void RepresentativeClaims_Description() throws Exception {
        assertEquals(tableData, resultSet, "description");
    }

    @Test(description = "Verify Seller Broker Information")
    public void SellerBrokerInfo() throws Exception {
        assertEquals(acqDetailPage.seller_broker_info.getData(),
                sqlProcessor.getResultData("AcquisitionDetail.SELLER_BROKER_INFO", dataId));
    }

    @Test(description = "Verify Documents Section")
    public void Documents_Section() throws Exception {
    	System.out.println("actual: " + acqDetailPage.getDocumentData());
        assertEquals(acqDetailPage.getDocumentData(),
                sqlProcessor.getSingleValue(sqlProcessor.getResultData("AcquisitionDetail.DOCUMENT_MSG", dataId), "document"));
    }

    @Test(description = "Verify Patent Information")
    public void Patent_Information() throws Exception {
        assertEquals(acqDetailPage.patent_information.getData(),
                sqlProcessor.getResultData("AcquisitionDetail.PATENT_INFO", dataId), "family", "file_number",
                "patent_number", "est_priority_date", "title", "litigated", "ipr");
    }

    @Test(description = "Tags")
    public void CheckTags() throws Exception {
        assertEquals(acqDetailPage.tags.getData(), sqlProcessor.getResultData("AcquisitionDetail.TAGS", dataId));
    }
    
    @Test(description = "Assignments| Verify displayed assignments for a portfolio", priority = 11)
    public void assignments() throws Exception {
    	assertEquals(acqDetailPage.assignmentsTable.getData(), 
    			 sqlProcessor.getResultData("AcquisitionDetail.ASSIGNMENTS", dataId));
    }
}