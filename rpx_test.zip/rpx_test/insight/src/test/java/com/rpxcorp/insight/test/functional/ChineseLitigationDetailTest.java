package com.rpxcorp.insight.test.functional;

import com.rpxcorp.insight.page.detail.BaseDetailPage;
import com.rpxcorp.insight.page.detail.ChineseLitigationDetailPage;
import com.rpxcorp.insight.page.detail.EntityDetailPage;
import com.rpxcorp.insight.page.search.PatentSearchPage;
import com.rpxcorp.testcore.Authenticate;
import org.testng.Assert;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Authenticate(role = "MEMBER")
@Test(groups = {"Lits","China"})
public class ChineseLitigationDetailTest extends BaseFuncTest {

    ChineseLitigationDetailPage chineseLitDetailPage;
    EntityDetailPage entityDetailPage;
    PatentSearchPage patentSearchPage;
    BaseDetailPage baseDetailPage;
    SoftAssert softAssert = new SoftAssert();

    @Test(priority = 1, groups = {"smoke","P2"}, description = "Verify all sections in Chinese Litigation details page")
    public void verifyAllSectionsInChineseLitDetailsPage() throws Exception {
        softAssert = new SoftAssert();
        this.urlData.put("ID", "4065841");
        to(chineseLitDetailPage, urlData);
        softAssert.assertTrue(chineseLitDetailPage.detailPageTitle.isDisplayed(),"The 'Title' is not getting displayed in the CN Litigation Details Page");
        softAssert.assertTrue(chineseLitDetailPage.metricsSection.isDisplayed(),"The 'Metrics Section' is not getting displayed in the CN Litigation Details Page");
        softAssert.assertTrue(chineseLitDetailPage.overviewContent.isDisplayed(),"The 'Overview Section' is not getting displayed in the CN Litigation Details Page");
        softAssert.assertTrue(chineseLitDetailPage.firstInstanceOutomeContent.isDisplayed(),"The 'First Instance Outcome' is not getting displayed in the CN Litigation Details Page");
        softAssert.assertTrue(chineseLitDetailPage.secondInstanceOutomeContent.isDisplayed(),"The 'Second Instance Outcome' is not getting displayed in the CN Litigation Details Page");
        softAssert.assertTrue(chineseLitDetailPage.litigationCampaign.isDisplayed(),"The 'Litigation Campaign' is not getting displayed in the CN Litigation Details Page");
        softAssert.assertTrue(chineseLitDetailPage.PATENT_TABLE.isDisplayed(),"The 'Patent Table' is not getting displayed in the CN Litigation Details Page");
        softAssert.assertTrue(chineseLitDetailPage.PLAINTIFF_PARTIES.isDisplayed(),"The 'Plaintiff Parties' is not getting displayed in the CN Litigation Details Page");
        softAssert.assertTrue(chineseLitDetailPage.DEFENDANT_PARTIES.isDisplayed(),"The 'Defendant Section' is not getting displayed in the CN Litigation Details Page");
        softAssert.assertTrue(chineseLitDetailPage.chineseLitProcessLearnMoreLink.isDisplayed(),"The 'Chinese Litigation Process' section is not getting displayed in the CN Litigation Details Page");
        softAssert.assertAll();
    }

    /** OVERVIEW SECTION TESTS **/
    @Test(priority = 1, groups="P3", description = "Verify Judgement Document for chinese litigation")
    public void verifyJudgementDocForChineseLitWithJudgement() throws Exception {
        softAssert = new SoftAssert();
        this.urlData.put("ID", "4005376");
        to(chineseLitDetailPage, urlData);
        withNewWindow(chineseLitDetailPage.viewJudgement_btn, () -> {
            softAssert.assertTrue(getDriver().getCurrentUrl().contains("/litigation/china/rpx-intl-lits/"),
                    "Document URL is not pointed to '/litigation/china/rpx-intl-lits/'");
            softAssert.assertTrue(getDriver().getPageSource().contains("application/pdf"), "MIME media type pdf is not present");
        });
        softAssert.assertAll();
    }

    @Test(priority = 2, groups="P3", description = "Verify complaint unavailable for litigation without complaint")
    public void verifyJudgementUnavailableForLitWithoutJudgement() {
        this.urlData.put("ID", "4005378");
        to(chineseLitDetailPage, urlData);
        assertTrue(chineseLitDetailPage.judgementUnavailableBtn.isDisplayed(), "Complaint Unavailable button is not displayed for litigation without complaint");
    }

    @Test(priority=3,groups="P2", description="Verify Chinese litigation metrics")
    public void verifyLitStaticsVsSectionsStatistics() {
        softAssert = new SoftAssert();
        to(chineseLitDetailPage,"4064718-wei-kong-v-jiangsu-hengtong-lighting-group");
        softAssert.assertEquals(chineseLitDetailPage.metricsSection.getIntData("plaintiffCount"),chineseLitDetailPage.plaitiff_count.getIntData(), "The Metrics Section in 'Plaintiff' count is not matching with Plaintiff Section Statistics");
        softAssert.assertEquals(chineseLitDetailPage.metricsSection.getIntData("defendantCount"),chineseLitDetailPage.defendant_count.getIntData(),"The Metrics Section in 'Defendant' count is not matching with Defendant Section Statistics");
        softAssert.assertEquals(chineseLitDetailPage.metricsSection.getIntData("patentInSuitCount"),chineseLitDetailPage.patent_in_suite_HeaderCount.getIntData(),"The Metrics Section in 'Patent-In_Suite' count is not matching with Patent-In-Suite Section Statistics");
        softAssert.assertTrue(chineseLitDetailPage.statsDaysInLitigation.isDisplayed(), "The Days in Litigation Count is not displayed in the metrics section");
        softAssert.assertAll();
    }
    //--TODO verifyPlaintiffSectionNotDisplayedForLitsWithoutPlaintiff()

    @BeforeGroups(groups = "cn_lit_with_plaintiffs")
    public void loadLitWithPlaintiffs(){
        this.urlData.put("ID", "4067102");//4013714
        to(chineseLitDetailPage, urlData);
    }

    @Test(priority = 4, groups={"P2", "cn_lit_with_plaintiffs"}, description = "Verify Chinese plaintiff link navigation")
    public void verifyPlaintiffLinkFromPlaintiffsSection() throws Exception {
        softAssert = new SoftAssert();
        chineseLitDetailPage.plaintiffSectionLink.waitUntilVisible();
        String entityFromPlaintff = chineseLitDetailPage.plaintiffSectionLink.getText().toLowerCase();
        withNewWindow(chineseLitDetailPage.plaintiffSectionLink, () -> {
            at(entityDetailPage);
            String entityNameFromDetails = entityDetailPage.detailPageTitle.getText().toLowerCase();
            softAssert.assertEquals(entityNameFromDetails, entityFromPlaintff, "Entity Link navigation is not as expected");
        });
        softAssert.assertAll();
    }

    //--TODO verifyViewLessInPlaintiffSection()
    //--TODO verifyViewAllInPlaintiffSection()

    @Test(priority = 5, groups={"P3", "cn_lit_with_plaintiffs"}, description = "Verify expand and collapse of counsel info in plaintiff section")
    public void verifyExpandAndCollapseCounselInfoInPlaintiffSection() {
        chineseLitDetailPage.counselInfoArrowInPlaintiffSection.click();
        assertTrue(chineseLitDetailPage.counselContentInPlaintiffSection.isDisplayed(), "Counsel information is not displayed after expanding the content with arrow");
        chineseLitDetailPage.counselInfoArrowInPlaintiffSection.click();
        chineseLitDetailPage.counselContentInPlaintiffSection.waitUntilInvisible();
        assertFalse(chineseLitDetailPage.counselContentInPlaintiffSection.isDisplayed(), "Counsel information is displayed after collapsing the content with arrow");
    }

    @Test(priority = 6, groups={"P3", "cn_lit_with_plaintiffs"}, description = "Verify Show All and Hide All Counsel link from Plaintiff section")
    public void verifyShowAllCounselFromPlaintiffSection() {
        chineseLitDetailPage.showAllCounselInPlaintiffSection.click();
        assertTrue(chineseLitDetailPage.counselContentInPlaintiffSection.isDisplayed(), "Counsel information is not displayed after Show All Counsel link");
        chineseLitDetailPage.hideAllCounelInPlaintiffSection.click();
        assertFalse(chineseLitDetailPage.counselContentInPlaintiffSection.isDisplayed(), "Counsel information is displayed after Hide All Counsel link");
    }
    //--TODO verifyDefSectionNotDisplayedForLitsWithoutDefendants()

    @BeforeGroups(groups = "cn_lit_with_defendants")
    public void loadLitWithDefendant(){
        this.urlData.put("ID", "4071851");//4009753
        to(chineseLitDetailPage, urlData);
    }

    @Test(priority = 7, groups={"P2", "cn_lit_with_defendants"}, description = "Verify Chinese Lit defendant link navigation")
    public void verifyDefLinkFromDefendantSection() throws Exception {
        chineseLitDetailPage.defendantSectionLink.waitUntilVisible();
        String entityFromDef = chineseLitDetailPage.defendantSectionLink.getText().toLowerCase();

        withNewWindow(chineseLitDetailPage.defendantSectionLink, () -> {
            at(entityDetailPage);
            String entityNameFromDetails = entityDetailPage.detailPageTitle.getText().toLowerCase();
            softAssert.assertEquals(entityNameFromDetails, entityFromDef, "Entity Link navigation is not as expected");
        });
    }

    //TODO verifyViewLessInDefendantSection
    //TODO verifyViewAllInDefendantSection

    @Test(priority = 8, groups={"P3", "cn_lit_with_defendants"}, description = "Verify expand and collapse of counsel info in defendant section")
    public void verifyExpandAndCollapseCounselInfoInDefendantSection() {
        chineseLitDetailPage.counselInfoArrowInDefendantSection.click();
        assertTrue(chineseLitDetailPage.counselContentInDefendantSection.isDisplayed(), "Counsel information is not displayed after expanding the content with arrow");
        chineseLitDetailPage.counselInfoArrowInDefendantSection.click();
        chineseLitDetailPage.counselContentInDefendantSection.waitUntilInvisible();
        assertFalse(chineseLitDetailPage.counselContentInDefendantSection.isDisplayed(), "Counsel information is displayed after collapsing the content with arrow");
    }

    @Test(priority = 9, groups={"P3", "cn_lit_with_defendants"}, description = "Verify Show All and Hide All Counsel link from defendant section")
    public void verifyShowAllCounselFromDefendantSection() {
        chineseLitDetailPage.defendants_showAllCounsel.click();
        assertTrue(chineseLitDetailPage.counselContentInDefendantSection.isDisplayed(), "Counsel information is not displayed after Show All Counsel link");
        chineseLitDetailPage.hideAllCounelInDefendantSection.click();
        assertFalse(chineseLitDetailPage.counselContentInDefendantSection.isDisplayed(), "Counsel information is displayed after Hide All Counsel link");
    }

    /** PATENT-IN-SUIT TESTS **/
    @BeforeGroups(groups = "ch_patent_in_suit")
    public void gotoLitWithPatentInfo() {
        this.urlData.put("ID", "4007966");
        to(chineseLitDetailPage, urlData);
        chineseLitDetailPage.PATENT_TABLE.waitUntilVisible();
    }

    @Test(priority = 10, groups={"P3", "ch_patent_in_suit"}, description = "Verify Patent-In-Suit table header")
    public void verifyPatentInSuitTableHeader() throws Exception {
        String expPatentsInSuitHeader[] = {"Patent #", "Title", "Est. Priority Date"};
        chineseLitDetailPage.PATENT_TABLE.waitUntilVisible();
        assertEquals(chineseLitDetailPage.PATENT_TABLE.getHeaderData(), expPatentsInSuitHeader, "Patent In Suit table header is not as expected");
    }

    @Test(priority = 11, groups={"P3", "ch_patent_in_suit"}, description = "Verify view less in patent-in-suit table")
    public void verifyViewLessInPatentInSuit() {
        softAssert = new SoftAssert();
        to(chineseLitDetailPage, "4004405");
        chineseLitDetailPage.PATENT_TABLE.waitUntilVisible();
        chineseLitDetailPage.PATENT_TABLE.viewAll();
        int recordsBeforeViewLess = chineseLitDetailPage.PATENT_TABLE.displayedRecords().getElements().size();
        chineseLitDetailPage.PATENT_TABLE.viewLess();
        int recordsAfterViewLess = chineseLitDetailPage.PATENT_TABLE.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsAfterViewLess == 5, "5 records are not displayed after view less, records displayed after view less: " + recordsAfterViewLess);
        softAssert.assertTrue(recordsBeforeViewLess > recordsAfterViewLess, "Records displayed after view less is not less than records before view less, "
                + "Records before view less: " + recordsBeforeViewLess + " Records after view less: " + recordsAfterViewLess);
        softAssert.assertAll();
    }

    @Test(priority = 12, groups={"P3", "ch_patent_in_suit"}, description = "Verify view all in patent-in-suit table")
    public void verifyViewAllInPatentInSuit() {
        softAssert = new SoftAssert();
        to(chineseLitDetailPage, "4004405");
        chineseLitDetailPage.PATENT_TABLE.waitUntilVisible();
        int recordsBeforeViewAll = chineseLitDetailPage.PATENT_TABLE.displayedRecords().getElements().size();
        chineseLitDetailPage.PATENT_TABLE.viewAll();
        int recordsAfterViewAll = chineseLitDetailPage.PATENT_TABLE.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsBeforeViewAll == 5, "5 records are not displayed before view all, records displayed after view all: " + recordsAfterViewAll);
        softAssert.assertTrue(recordsAfterViewAll > recordsBeforeViewAll, "Records displayed after view all is not greater than records before view all, "
                + " Records before view all: " + recordsBeforeViewAll + " Records after view all: " + recordsAfterViewAll);
        softAssert.assertAll();
    }

    @Test(priority = 13, groups={"P4", "ch_patent_in_suit", "func_sorting"}, description = "Verify default sort in patent-in-suit table")
    public void verifyDefaultSortInPatentInSuit() {
        assertColumnSort("date", "desc", chineseLitDetailPage.PATENT_TABLE.getColumn("Est. Priority Date"));
    }
    @Test(priority = 14, groups={"P4", "ch_patent_in_suit","func_sorting"}, dataProvider = "patentInSuitSortData", description = "Verify sorting in patent-in-suit table")
    public void verifySortingInPatentInSuit(String columnName, String sortType, String dataType) throws Exception {
        chineseLitDetailPage.PATENT_TABLE.sort(columnName);
        assertColumnSort(dataType, sortType, chineseLitDetailPage.PATENT_TABLE.getColumn(columnName));
    }

    @DataProvider
    public Object[][] patentInSuitSortData() {
        return new Object[][] { { "Patent #", "asc", "string" }, { "Patent #", "desc", "string" },
                { "Title", "asc", "string" }, { "Title", "desc", "string" },
                { "Est. Priority Date", "asc", "date" }, { "Est. Priority Date", "desc", "date" } };
    }


    //--TODO Enable once ViewAsSearch is implemented For Chinese Patent
    //@Test(priority = 15, groups = "ch_patent_in_suit", description = "Verify view as search results from patent information section")
/*    public void verifyViewAsSearchFromPatentInformation() throws Exception {
        softAssert = new SoftAssert();
        chineseLitDetailPage.PATENT_TABLE.waitUntilVisible();
        List<String> patentColumnInTable = chineseLitDetailPage.PATENT_TABLE.getColumn("Patent #");
        Collections.sort(patentColumnInTable);
        withNewWindow(chineseLitDetailPage.patentInfoViewAsSearch, () -> {
            at(patentSearchPage);
            List<String> searchResultsPatents = patentSearchPage.search_result.getColumn("Patent #");
            Collections.sort(searchResultsPatents);
            softAssert.assertEquals(searchResultsPatents, patentColumnInTable, "Patents does not match, Patents in lit details: " + patentColumnInTable.toString()
                    + " Patents in search results: " + searchResultsPatents);
        });
        softAssert.assertAll();
    }*/

    @Test(priority = 16, groups={"P3", "ch_patent_in_suit"}, description = "Verify message for litigation without patent in patent in suit")
    public void verifyMessageInPatentInSuitWithoutRecords() throws Exception {
        this.urlData.put("ID", "4007339");
        to(chineseLitDetailPage, urlData);
        chineseLitDetailPage.noPatentInSuitMsg.waitUntilVisible();
        assertEquals(chineseLitDetailPage.noPatentInSuitMsg.getText(), "Patents have not yet been matched", "Message for patent in suit without records");
    }

    /** LITIGATION CAMPAIGN - CASES TAB TESTS **/

    @BeforeGroups(groups = "cn_lit_with_cases_in_lit_camp")
    public void loadLitWithCasesInLitCamp() {
        this.urlData.put("ID", "4070086");
        to(chineseLitDetailPage, urlData);
        chineseLitDetailPage.litigationCampaignTabs.select("Cases");
        chineseLitDetailPage.litigation_cases.waitUntilVisible();
    }

    @Test(priority = 400, groups={"P3", "cn_lit_with_cases_in_lit_camp"}, description = "verify Litigation Campaign - Cases Table header")
    public void verifyHeaderInLitCampCasesTab() throws Exception {
        String expHeader[] = { "Date Filed", "Case Name", "Case Number", "Termination Date", "Jurisdiction" };
        chineseLitDetailPage.litigation_cases.waitUntilVisible();
        assertEquals(chineseLitDetailPage.litigation_cases.getHeaderData(), expHeader, "Litigation Campaign - Cases Tab header");
    }

    @Test(priority = 401, groups={"P3", "cn_lit_with_cases_in_lit_camp"}, description = "Verify Litigation Campaign - Cases table view less")
    public void verifyViewLessInLitCampCasesTab() {
        softAssert = new SoftAssert();
        chineseLitDetailPage.litigation_cases.viewAll();
        int recordsBeforeViewLess = chineseLitDetailPage.litigation_cases.displayedRecords().getElements().size();
        chineseLitDetailPage.litigation_cases.viewLess();
        int recordsAfterViewLess = chineseLitDetailPage.litigation_cases.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsAfterViewLess == 7, "7 records are not displayed after view less, records displayed after view less: " + recordsAfterViewLess);
        softAssert.assertTrue(recordsBeforeViewLess > recordsAfterViewLess, "Records displayed after view less is not less than records before view less, "
                + "Records before view less: " + recordsBeforeViewLess + " Records after view less: " + recordsAfterViewLess);
        softAssert.assertAll();
    }

    @Test(priority = 402, groups={"P3", "cn_lit_with_cases_in_lit_camp"}, description = "Verify Litigation Campaign - Cases table view all")
    public void verifyViewAllInLitCampCasesTab() {
        softAssert = new SoftAssert();
        int recordsBeforeViewAll = chineseLitDetailPage.litigation_cases.displayedRecords().getElements().size();
        chineseLitDetailPage.litigation_cases.viewAll();
        int recordsAfterViewAll = chineseLitDetailPage.litigation_cases.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsBeforeViewAll == 7, "7 records are not displayed before view all, records displayed after view all: " + recordsAfterViewAll);
        softAssert.assertTrue(recordsAfterViewAll > recordsBeforeViewAll, "Records displayed after view all is not greater than records before view all, "
                + " Records before view all: " + recordsBeforeViewAll + " Records after view all: " + recordsAfterViewAll);
        softAssert.assertAll();
    }

    @Test(priority = 403, groups={"P4", "cn_lit_with_cases_in_lit_camp","func_sorting"}, description = "Verify default sort in Litigation Campaign - Cases tab")
    public void verifyDefaultSortInLitCampCasesTab() {
        assertColumnSort("date", "desc", chineseLitDetailPage.litigation_cases.getColumn("Date Filed"));
    }

    @Test(priority = 404, groups={"P4", "cn_lit_with_cases_in_lit_camp","func_sorting"}, dataProvider = "litCampCasesSortData", description = "Verify sorting in Litigation Campaign - Cases tab")
    public void verifySortingInLitCampCasesTab(String columnName, String sortType, String dataType) throws Exception {
        chineseLitDetailPage.litigation_cases.sort(columnName);
        assertColumnSort(dataType, sortType, chineseLitDetailPage.litigation_cases.getColumn(columnName));
    }
    @DataProvider
    public Object[][] litCampCasesSortData() {
        return new Object[][] {
                { "Date Filed", "asc", "date" }, { "Date Filed", "desc", "date" },
                { "Case Name", "asc", "string" }, { "Case Name", "desc", "string" },
                { "Case Number", "asc", "string" }, { "Case Number", "desc", "string" },
                { "Termination Date", "asc", "date" }, { "Termination Date", "desc", "date" },
                { "Jurisdiction", "asc", "string" }, { "Jurisdiction", "desc", "string" }
        };
    }

    @Test(priority = 405, groups="P2", dataProvider = "litCampCaseLinks", description = "Verify Case Name and Case Number link navigation from Litigation Campaign - Cases tab")
    public void verifyCaseNameAndCaseNumberLinksFromLitCampCasesTab(String id , String columnName) throws Exception {
        this.urlData.put("ID", id);
        to(chineseLitDetailPage, urlData);
        chineseLitDetailPage.litigationCampaignTabs.select("Case");
        chineseLitDetailPage.litigation_cases.waitUntilVisible();
        String caseDetailInTable = chineseLitDetailPage.litigation_cases.getColumnLinkElem(columnName).getText().toLowerCase();
        //chineseLitDetailPage.litigation_cases.getFirstlinkFromColumn(3).click();
        withNewWindow(chineseLitDetailPage.litigation_cases.getColumnLinkElem(columnName) , () -> {
            at(baseDetailPage);
            if(columnName.equalsIgnoreCase("Case Name")){
                String caseDetailInDetailsPage = baseDetailPage.detailPageTitle.getText();
                Assert.assertTrue(caseDetailInDetailsPage.toLowerCase().contains(caseDetailInTable.toLowerCase()), "Case Name in Litigation Campaign Cases tab and its corresponding detail page are not same");
            }else{
                String caseDetailInDetailsPage = baseDetailPage.getCaseNumber().toLowerCase();
                Assert.assertEquals(caseDetailInDetailsPage, caseDetailInTable, "Case Number in Litigation Campaign Cases tab and its corresponding detail page are not same");
            }
        });
    }

    @Test(priority = 406, groups={"P2", "cn_lit_with_cases_in_lit_camp"} , description = "Verify Litigation Campaign section tabs")
    public void checkLitigationCampaignTab() {
        softAssert = new SoftAssert();
        softAssert.assertTrue(chineseLitDetailPage.litigationCampaignTabs.getText().toString().contains("TIMELINE"),
                "TIMELINE tab is not displayed in litigation campaign section");
        softAssert.assertTrue(chineseLitDetailPage.litigationCampaignTabs.getText().toString().contains("CASES"),
                "TIMELINE tab is not displayed in litigation campaign section");
        softAssert.assertTrue(chineseLitDetailPage.litigationCampaignTabs.getText().toString().contains("DEFENDANTS"),
                "CASES tab is displayed in litigation campaign section");
        softAssert.assertTrue(chineseLitDetailPage.litigationCampaignTabs.getText().toString().contains("PATENTS"),
                "CASES tab is displayed in litigation campaign section");
        softAssert.assertTrue(chineseLitDetailPage.litigationCampaignTabs.getText().toString().contains("ACCUSED PRODUCTS"),
                "CASES tab is displayed in litigation campaign section");
        softAssert.assertTrue(chineseLitDetailPage.litigationCampaignTabs.getText().toString().contains("PATENT GRID"),
                "CASES tab is displayed in litigation campaign section");

    }

    @DataProvider
    public Object[][] litCampCaseLinks() {
        return new Object[][] {
                { "4061058","Case Name" },{ "4061058","Case Number" },  //US and CN Campaign
                { "4022058","Case Name" },{ "4022058","Case Number" } //Only CN Campaign
        };
    }


    @BeforeGroups(groups = "ch_lit_with_defendants_tab")
    public void loadLitWithDefendants() {
        this.urlData.put("ID", "4061314");
        to(chineseLitDetailPage, urlData);
        chineseLitDetailPage.litigationCampaignTabs.select("Defendants");
        chineseLitDetailPage.defendant_table.waitUntilVisible();
    }

    @Test(priority = 500, groups={"P2", "ch_lit_with_defendants_tab"}, description = "Verify litigation campaign - defendant view table header")
    public void verifyLitCampDefendantsTableColumn() throws Exception {
        String expHeaders[] = {"Defendant Parent", "Defendants", "Most Recent Case", "Start Date", "End Date"};
        chineseLitDetailPage.defendant_table.waitUntilVisible();
        assertEquals(chineseLitDetailPage.defendant_table.getHeaderData(), expHeaders, "Litigation campaign - defendant table headers not as expected");
    }

    @Test(priority = 501, groups={"P3", "ch_lit_with_defendants_tab"}, description = "Verify view less in Litigation Campaign - Defendant table")
    public void verifyLitCampDefendantTabViewLess() {
        softAssert = new SoftAssert();
        chineseLitDetailPage.defendant_table.waitUntilVisible();
        chineseLitDetailPage.defendant_table.viewAll();
        int recordsBeforeViewLess = chineseLitDetailPage.defendant_table.displayedRecords().getElements().size();
        chineseLitDetailPage.defendant_table.viewLess();
        int recordsAfterViewLess = chineseLitDetailPage.defendant_table.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsAfterViewLess == 10, "10 records are not displayed after view less");
        softAssert.assertTrue(recordsBeforeViewLess > recordsAfterViewLess, "Records displayed after view less is not less than records before view less");
        softAssert.assertAll();
    }

    @Test(priority = 502, groups={"P3", "ch_lit_with_defendants_tab"}, description = "Verify view all in Litigation Campaign - Defendant table")
    public void verifyLitCampDefendantTabViewAll() {
        softAssert = new SoftAssert();
        chineseLitDetailPage.defendant_table.waitUntilVisible();
        int recordsBeforeViewAll = chineseLitDetailPage.defendant_table.displayedRecords().getElements().size();
        chineseLitDetailPage.defendant_table.viewAll();
        int recordsAfterViewAll = chineseLitDetailPage.defendant_table.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsBeforeViewAll == 10, "10 records are not displayed before view all");
        softAssert.assertTrue(recordsAfterViewAll > recordsBeforeViewAll, "Records displayed after view all is not greater than records before view all");
        softAssert.assertAll();
    }

    @Test(priority = 503, groups={"P2", "ch_lit_with_defendants_tab"}, description = "Verify Defendant Parent link in Litigation Campaign - Defendant table")
    public void verifyLitCampDefendantTabDefParentLink() throws Exception {
        softAssert = new SoftAssert();
        chineseLitDetailPage.defendant_table.waitUntilVisible();
        String defParentLinkFromTable = chineseLitDetailPage.defendant_table.getAttributeFromColumnLink("Defendant Parent","data-ot-content");
        withNewWindow(chineseLitDetailPage.defendant_table.getColumnLinkElem("Defendant Parent") , () -> {
            at(entityDetailPage);
            String entTitleFromDetails = entityDetailPage.detailPageTitle.getText().toLowerCase();
            softAssert.assertTrue(entTitleFromDetails.equalsIgnoreCase(defParentLinkFromTable), "Defendant Parent link text and corresponding entity details page title not matched");
        });
        softAssert.assertAll();
    }

    @Test(priority = 504, groups={"P2", "ch_lit_with_defendants_tab"}, description = "Verify Defendants link in Litigation Campaign - Defendant table")
    public void verifyLitCampDefendantTabDefendantsLink() throws Exception {
        softAssert = new SoftAssert();
        chineseLitDetailPage.defendant_table.waitUntilVisible();
        String defParentLinkFromTable = chineseLitDetailPage.defendant_table.getColumnLinkElem("Defendants").getAttribute("data-ot-content").toLowerCase(); //Defendent Column
        withNewWindow(chineseLitDetailPage.defendant_table.getColumnLinkElem("Defendants"), () -> {
            at(entityDetailPage);
            String entTitleFromDetails = entityDetailPage.detailPageTitle.getText().toUpperCase().toLowerCase();
            softAssert.assertEquals(entTitleFromDetails, defParentLinkFromTable, "Defendants link text and corresponding entity details page title not matched");
        });
        softAssert.assertAll();
    }

    @Test(priority = 505, groups={"P4", "ch_lit_with_defendants_tab","func_sorting"}, description = "Verify default sort in Litigation Campaign - Defendant table")
    public void verifyLitCampDefendantTabDefaultSort() {
        assertColumnSort("date", "desc", chineseLitDetailPage.defendant_table.getColumn("Start Date"));
    }

    @Test(priority = 506, groups={"P4","ch_lit_with_defendants_tab","func_sorting"}, dataProvider = "defendantSortData", description = "Verify sorting in Litigation Campaign - Defendant table")
    public void verifyLitCampDefendantTabSorting(String columnName, String sortType, String dataType) throws Exception {
        chineseLitDetailPage.defendant_table.sort(columnName);
        assertColumnSort(dataType, sortType, chineseLitDetailPage.defendant_table.getColumn(columnName));
    }
    @DataProvider
    public Object[][] defendantSortData() {
        return new Object[][] {
                {"Defendant Parent", "asc", "string"}, {"Defendant Parent", "desc", "string"},
                {"Defendants", "asc", "string"}, {"Defendants", "desc", "string"},
                {"Start Date", "asc", "date"}, { "Start Date", "desc", "date"},
                {"End Date", "asc", "date"}, { "End Date", "desc", "date"}
        };
    }

    @Test(priority = 507, dataProvider = "defendantSearchData", groups={"P2", "ch_lit_with_defendants_tab"}, description = "Verify search in Litigation Campaign - Defendant table")
    public void verifyLitCampDefendantTabSearch(String searchTerm) {
        chineseLitDetailPage.defendantSearch(searchTerm);
        for (String actualRowValue : chineseLitDetailPage.defendant_table.getRows()) {
            assertTrue(actualRowValue.contains(searchTerm), "Search term not retrieved in results, Search term: " + searchTerm +
                    " Actual value in table: " + actualRowValue);
        }
    }
    @DataProvider
    public Object[][] defendantSearchData() {
        return new Object[][] {
                {"Samsung Heavy Industries"},
                {"Beijing Xingxingtong"},
                {"CN-20-4061314"},
                {"12/20/2017"}
        };
    }

    @Test(priority = 508, dataProvider = "invalidDefendantSearchData", groups={"P3", "ch_lit_with_defendants_tab"},
            description = "Verify invalid search in Litigation Campaign - Defendant table")
    public void verifyLitCampDefendantTabInvalidSearch(String searchTerm) throws Exception {
        chineseLitDetailPage.defendantSearch(searchTerm);
        assertEquals(chineseLitDetailPage.noDataInDefendantTable.getText(), "No matching records found", "Message for invalid search not as expected");
    }
    @DataProvider
    public Object[][] invalidDefendantSearchData() {
        return new Object[][] { {"***INVALID ENTRY DATA***"} };
    }

    @Test(priority = 509, dataProvider = "litCampDefTabMostRecentCaseData", description = "Verify most recent case link in Litigation Campaign - Defendant table")
    public void verifyLitCampDefendantTabMostRecentCaseLink(String type, String litId , String SearchTearm) throws Exception {
        softAssert = new SoftAssert();
        this.urlData.put("ID", litId);
        to(chineseLitDetailPage, urlData);
        chineseLitDetailPage.litigationCampaignTabs.waitUntilVisible();
        chineseLitDetailPage.litigationCampaignTabs.select("Defendants");
        chineseLitDetailPage.litCampDefendantMostRecentCaseLink.waitUntilVisible();
        chineseLitDetailPage.defendantSearch(SearchTearm);
        String mostRecentCaseLinkFromTable = chineseLitDetailPage.litCampDefendantMostRecentCaseLink.getText().toLowerCase();
        withNewWindow(chineseLitDetailPage.litCampDefendantMostRecentCaseLink, () -> {
            at(baseDetailPage);
            String titleFromDetailsPage = baseDetailPage.getCaseNumber().toLowerCase();
            softAssert.assertEquals(titleFromDetailsPage, mostRecentCaseLinkFromTable, "Most Recent Case link text and corresponding details page title not matched");
        });
        softAssert.assertAll();
    }
    @DataProvider
    public Object[][] litCampDefTabMostRecentCaseData() {
        return new Object[][] {
                {"CN as most recent case", "4046979" , "CN-20-4018790"}, //CN Cases
                {"ITC as most recent case", "4046979", "337-TA-565"}, //ITC Cases
                {"DC as most recent case", "4046979", "3:16-cv-02324"} //DC Cases

        };
    }

    @BeforeGroups(groups = "ch_lit_with_defendants_subtable")
    public void loadLitigationWithDefendantSubTable() {
        this.urlData.put("ID", "4013714");
        to(chineseLitDetailPage, urlData);
        chineseLitDetailPage.litigationCampaignTabs.waitUntilVisible();
        chineseLitDetailPage.litigationCampaignTabs.select("Defendants");
    }

    @Test(priority = 550, groups={"P3", "ch_lit_with_defendants_subtable"}, description = "Verify Litigation Campaign - sub table header")
    public void verifyLitCampDefendantsSubTableColumn() throws Exception {
        String expHeader[] = { "Date Filed", "Case Name", "Case Number", "Jurisdiction", "Termination Date" };
        chineseLitDetailPage.defendant_table.expandSubTable();
        chineseLitDetailPage.defendant_table.subtable().waitUntilVisible();
        List<String> actualHeaderList = new ArrayList<String>(Arrays.asList(chineseLitDetailPage.defendant_table.subtable().getHeaderData()));
        actualHeaderList.remove("Id");
        String actualHeader[] = actualHeaderList.toArray(new String[actualHeaderList.size()]);
        assertEquals(actualHeader, expHeader,"Defendant sub table header");
    }

    @Test(priority = 551, groups={"P4", "ch_lit_with_defendants_subtable","func_sorting"}, description = "Verify default sort in Litigation Campaign - Defendant sub table")
    public void verifyLitCampDefendantTabSubTableDefaultSort() {
        chineseLitDetailPage.defendant_table.expandSubTable();
        chineseLitDetailPage.defendant_table.subtable().waitUntilVisible();
        assertColumnSort("date", "desc", chineseLitDetailPage.defendant_table.subtable().getColumn("Date Filed"));
    }

    @Test(priority = 552, groups={"P4","ch_lit_with_defendants_subtable","func_sorting"}, dataProvider = "defendantSubTableSortData",
            description = "Verify sorting in Litigation Campaign - Defendant sub table")
    public void verifyLitCampDefendantTabSubTableSorting(String columnName, String sortType, String dataType) throws Exception {
        chineseLitDetailPage.defendant_table.expandSubTable();
        chineseLitDetailPage.defendant_table.subtable().waitUntilVisible();
        chineseLitDetailPage.defendant_table.subtable().sort(columnName);
        assertColumnSort(dataType, sortType, chineseLitDetailPage.defendant_table.subtable().getColumn(columnName));
    }

    @DataProvider
    public Object[][] defendantSubTableSortData() {
        return new Object[][] {
                {"Date Filed", "asc", "date"}, {"Date Filed", "desc", "date"},
                {"Case Name", "asc", "string"}, {"Case Name", "desc", "string"},
                {"Case Number", "asc", "string"}, { "Case Number", "desc", "string"},
                {"Termination Date", "asc", "date"}, { "Termination Date", "desc", "date"}
        };
    }


    @Test(priority = 553, groups="P2", dataProvider = "defendantSubTableCaseNameData", description = "Verify case name link from Litigation Campaign - Defendant sub table")
    public void verifyCaseNameLinkFromLitCampDefendantSubTable(String type, String litId , String SearchTearm) throws Exception {
        softAssert = new SoftAssert();
        this.urlData.put("ID", litId);
        to(chineseLitDetailPage, urlData);
        chineseLitDetailPage.litigationCampaignTabs.waitUntilVisible();
        chineseLitDetailPage.litigationCampaignTabs.select("Defendants");
        chineseLitDetailPage.defendantSearch(SearchTearm);
        chineseLitDetailPage.defendant_table.expandSubTable();
        chineseLitDetailPage.caseNameLinkInLitCampDefTabSubTable.waitUntilVisible();
        String caseNameFromSubTable = chineseLitDetailPage.caseNameLinkInLitCampDefTabSubTable.getText().toLowerCase();
        withNewWindow(chineseLitDetailPage.caseNameLinkInLitCampDefTabSubTable, () -> {
            at(baseDetailPage);
            String titleFromDetails = baseDetailPage.detailPageTitle.getText().toLowerCase();
            softAssert.assertTrue(titleFromDetails.contains(caseNameFromSubTable), "Case name link text and corresponding details page title not matched");
        });
        softAssert.assertAll();
    }

    @Test(priority = 554, groups="P2", dataProvider = "defendantSubTableCaseNameData", description = "Verify case number link from Litigation Campaign - Defendant sub table")
    public void verifyLitCampDefendantTabSubTableCaseNoLink(String type, String litId , String SearchTearm) throws Exception {
        softAssert = new SoftAssert();
        this.urlData.put("ID", litId);
        to(chineseLitDetailPage, urlData);
        chineseLitDetailPage.litigationCampaignTabs.waitUntilVisible();
        chineseLitDetailPage.litigationCampaignTabs.select("Defendants");
        chineseLitDetailPage.defendantSearch(SearchTearm);
        chineseLitDetailPage.defendant_table.expandSubTable();
        chineseLitDetailPage.caseNoLinkInLitCampDefTabSubTable.waitUntilVisible();
        String caseNoFromSubTable = chineseLitDetailPage.caseNoLinkInLitCampDefTabSubTable.getText().toLowerCase();
        withNewWindow(chineseLitDetailPage.caseNoLinkInLitCampDefTabSubTable, () -> {
            at(baseDetailPage);
            String caseNoFromDetails = baseDetailPage.getCaseNumber().toLowerCase();
            softAssert.assertEquals(caseNoFromDetails, caseNoFromSubTable, "Case number link text and corresponding case number in details page not matched");
        });
        softAssert.assertAll();
    }

    @DataProvider
    public Object[][] defendantSubTableCaseNameData() {
        return new Object[][] {
                {"Chinese With PTAB Lit", "4028261" , "CN-20-4065523"}, //Clicking CN cases
                {"Chinese With itc Lit", "4028261" , "337-TA-1106"} //clicking itc cases
        };
    }

    /** LITIGATION CAMPAIGN - PATENTS TAB TESTS **/
    @Test(priority = 900, groups="P3", description = "Verify message displayed for litigation without patents in litigation campaign section")
    public void verifyMessageInLitCampPatentsTabWithNoPatents() throws Exception {
        this.urlData.put("ID", "4007339");
        to(chineseLitDetailPage, urlData);
        chineseLitDetailPage.litigationCampaignTabs.waitUntilVisible();
        chineseLitDetailPage.litigationCampaignTabs.select("Patent");
        assertEquals(chineseLitDetailPage.noPatentsInLitCamp.getText(), "No patents found", "Message for no patents in a litigation");
    }

    @BeforeGroups(groups = "ch_lit_with_patents_in_lit_camp")
    public void loadLitWithPatentsInLitCamp() {
        this.urlData.put("ID", "4065523");
        to(chineseLitDetailPage, urlData);
        chineseLitDetailPage.litigationCampaignTabs.waitUntilVisible();
        chineseLitDetailPage.litigationCampaignTabs.select("Patents");
    }

    @Test(priority = 901, groups={"P2", "ch_lit_with_patents_in_lit_camp"}, description = "Verify table header in litigation campaign - patents tab")
    public void verifyLitCampPatentsTabTableHeader() throws Exception {
        String expHeader[] =  {"Patent #", "Title", "Current Assignee", "Original Assignee", "Est. Priority Date",
                "Issue Date"};
        chineseLitDetailPage.camp_patent_table.waitUntilVisible();
        assertEquals(chineseLitDetailPage.camp_patent_table.getHeaderData(), expHeader, "Table header");
    }

    @Test(priority = 902, groups="P3", description = "Verify view less in Chinese litigation campaign - patents tab")
    public void verifyViewLessInLitCampPatentsTab() {
        softAssert = new SoftAssert();
        to(chineseLitDetailPage, "4004405");
        chineseLitDetailPage.litigationCampaignTabs.waitUntilVisible();
        chineseLitDetailPage.litigationCampaignTabs.select("Patents");
        chineseLitDetailPage.camp_patent_table.waitUntilVisible();
        chineseLitDetailPage.camp_patent_table.viewAll();
        int recordsBeforeViewLess = chineseLitDetailPage.camp_patent_table.displayedRecords().getElements().size();
        chineseLitDetailPage.camp_patent_table.viewLess();
        int recordsAfterViewLess = chineseLitDetailPage.camp_patent_table.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsAfterViewLess == 7, "7 records are not displayed after view less, records displayed after view less: " + recordsAfterViewLess);
        softAssert.assertTrue(recordsBeforeViewLess > recordsAfterViewLess, "Records displayed after view less is not less than records before view less, "
                + "Records before view less: " + recordsBeforeViewLess + " Records after view less: " + recordsAfterViewLess);
        softAssert.assertAll();
    }

    @Test(priority = 903, groups="P3", description = "Verify view all in Chinese litigation campaign - patents tab")
    public void verifyViewAllInLitCampPatentsTab() {
        softAssert = new SoftAssert();
        softAssert = new SoftAssert();
        to(chineseLitDetailPage, "4004405");
        chineseLitDetailPage.litigationCampaignTabs.waitUntilVisible();
        chineseLitDetailPage.litigationCampaignTabs.select("Patents");
        int recordsBeforeViewAll = chineseLitDetailPage.camp_patent_table.displayedRecords().getElements().size();
        chineseLitDetailPage.camp_patent_table.viewAll();
        int recordsAfterViewAll = chineseLitDetailPage.camp_patent_table.displayedRecords().getElements().size();
        softAssert.assertTrue(recordsBeforeViewAll == 7, "7 records are not displayed before view all, records displayed after view all: " + recordsAfterViewAll);
        softAssert.assertTrue(recordsAfterViewAll > recordsBeforeViewAll, "Records displayed after view all is not greater than records before view all, "
                + " Records before view all: " + recordsBeforeViewAll + " Records after view all: " + recordsAfterViewAll);
        softAssert.assertAll();
    }

    @Test(priority = 904, groups={"P4","ch_lit_with_patents_in_lit_camp","func_sorting"}, description = "Verify default sort in Litigation Campaign - Patents tab")
    public void verifyDefaultSortInLitCampPatentsTab() {
        assertColumnSort("date", "desc", chineseLitDetailPage.camp_patent_table.getColumn("Est. Priority Date"));
    }

    @Test(priority = 905, groups={"P4","ch_lit_with_patents_in_lit_camp","func_sorting"}, dataProvider = "litCampPatentsSortData", description = "Verify sorting in Litigation Campaign - Patents tab")
    public void verifySortingInLitCampPatentsTab(String columnName, String sortType, String dataType) throws Exception {
        chineseLitDetailPage.camp_patent_table.sort(columnName);
        assertColumnSort(dataType, sortType, chineseLitDetailPage.camp_patent_table.getColumn(columnName));
    }
    @DataProvider
    public Object[][] litCampPatentsSortData() {
        return new Object[][] {
                { "Patent #", "asc", "string" }, { "Patent #", "desc", "string" },
                { "Title", "asc", "string" }, { "Title", "desc", "string" },
                { "Est. Priority Date", "asc", "date" }, { "Est. Priority Date", "desc", "date" }
        };
    }

    //Enable once ViewAsSearch is Fixed in Chinese Lit Page
    //@Test(priority = 906, groups = "ch_lit_with_patents_in_lit_camp", description = "Verify View As Search in Litigation Campaign - Patents tab")
/*    public void verifyViewAsSearchInLitCampPatentsTab() throws Exception {
        softAssert = new SoftAssert();
        List<String> patentColumnInTable = chineseLitDetailPage.camp_patent_table.getColumn("Patent #");
        Collections.sort(patentColumnInTable);
        withNewWindow(chineseLitDetailPage.litCampViewAsSearchResults, () -> {
            at(patentSearchPage);
            List<String> searchResultsPatents = patentSearchPage.search_result.getColumn("Patent #");
            Collections.sort(searchResultsPatents);
            softAssert.assertEquals(searchResultsPatents, patentColumnInTable, "Patents doesn't match, Patents in litigation details lit campaign: " + patentColumnInTable.toString()
                    + " Patents in search results: " + searchResultsPatents);
        });
        softAssert.assertAll();
    }*/

    //Litigation Campaign Timeline View
    @Test(priority=951,dataProvider="defendantNames",groups="P2", description="Verify defendant name search in Campaign TimeLine View")
    public void checkDefendantSearchAtTimeLineView(String defendantName) throws Exception {
        this.urlData.put("ID", "4028261");
        to(chineseLitDetailPage, urlData);
        chineseLitDetailPage.applyDefendantFilter(defendantName);
        chineseLitDetailPage.defendantsInTimelineChart.waitUntilVisible();
        assertEquals(chineseLitDetailPage.defendantsInTimelineChart.getText(),defendantName);
    }

    @DataProvider(name="defendantNames")
    public Object[][] getDefendantNames() {
        return new Object[][] {{"Zhuhai Seine Technology Company Limited"},//Defendant involved in both PTAB and ITC
                {"Shanghai Muming Electronic Technology Co., Ltd."}, //Defendant involved in CN
                {"4L Technologies, Inc."},//Defendant involved in LIT
        };
    }

    @Test(priority=952, groups="P2", description="Counsel|Verify Defendant Popup Case View counsel text for CN cases|RPX-12334")
    public void checkCounselLabelForCases() {
        to(chineseLitDetailPage, "4070729");
        chineseLitDetailPage.applyDefendantFilter("Quanzhou Aiken Trading Company");
        chineseLitDetailPage.timeLinechartBar.waitUntilVisible();
        //litigationDetailPage.timeLinechartBar.click();
        chineseLitDetailPage.timeLinechartBar.clickAt(10,1);
        chineseLitDetailPage.defendant_timeLine_Popup_CaseDetails.waitUntilVisible();
        assertTrue(chineseLitDetailPage.counsel_LabelForCN.isDisplayed(),"Lead Counsel label is not available for CN Cases in Defendant Pop up");
        chineseLitDetailPage.closeTimelinePopupModal();
    }

//    @Test(priority = 2, description = "Verify Patent-In-Suit in Patent Information section, RPX-13370 Lit detail page - Patents-in-Suit")
//    public void verifyPatentInSuitInPatentInformation() {
//        this.urlData.put("ID", "6");
//        to(chineseLitDetailPage, urlData);
//        Assert.isTrue(chineseLitDetailPage.viewInRPXAnalyst.isDisplayed(),"View In RPX Analyst link is not shown for the user");
//        Assert.isTrue(chineseLitDetailPage.viewAsSearchResults.isDisplayed(),"View As Search Results link is not shown for the user");
//        Assert.isEquals(chineseLitDetailPage.patentsInSuit.getText(),"1 Patent-in-Suit");
//        Assert.isEquals(chineseLitDetailPage.patentInSuitContent.getData("patent"),"CN1064436C");
//        Assert.isEquals(chineseLitDetailPage.patentInSuitContent.getData("title"),"Thermal protector for hermetic electrically-driven compressors");
//        Assert.isEquals(chineseLitDetailPage.patentInSuitContent.getData("est_priority_date"),"09/22/1993");
//    }
//
//    @DataProvider
//    public Object[][] patentsInSuitSortData() {
//        return new Object[][] { { "Patent #", "asc", "string" }, { "Patent #", "desc", "string" },
//               { "Title", "asc", "string" }, { "Title", "desc", "string" },
//               { "Est. Priority Date", "asc", "date" }, { "Est. Priority Date", "desc", "date" } };
//    }


//    @BeforeGroups(groups = "chinese-lit")
//    public void gotoChineseLit(){ to(chineseLitDetailPage, "6");}

//    @Test(priority = 3, dataProvider = "patentsInSuitSortData",groups = "chinese-lit")
//    public void verifyPatentsInSuitTableSort(String columnName, String sortType, String dataType) throws Exception {
//        chineseLitDetailPage.patentsInSuit.waitUntilVisible();
//        chineseLitDetailPage.chinese_litigation_table.sort(columnName);
//        assertColumnSort(dataType, sortType, chineseLitDetailPage.chinese_litigation_table.getColumn(columnName));
//    }
//
//    @Test(priority = 4, description = "Verify Overview section, RPX-13369 Lit detail page - Overview Section")
//    public void verifyOverviewSection() {
//        this.urlData.put("ID", "6");
//        to(chineseLitDetailPage, urlData);
//        Assert.isEquals(chineseLitDetailPage.overviewContent.getData("case_type"),"");
//        Assert.isEquals(chineseLitDetailPage.overviewContent.getData("market_sector"),"Industry\n" +
//                "Manufacturing\n" +
//                "Manufacturing & Machinery");
//        Assert.isEquals(chineseLitDetailPage.overviewContent.getData("court"),"Beijing First Intermediate People's Court");
//        Assert.isEquals(chineseLitDetailPage.overviewContent.getData("judge"),"Ming Zhao\n" +
//                "Ying Jiang\n" +
//                "Yuan Chen");
//    }
//
//    @Test(priority = 5, description = "RPX-13384 Page not found is displayed when searched with case_key in the URL")
//    public void verifyPageLoadWithCaseKeyInURL() {
//        this.urlData.put("ID", "CN-05-RE1668-370796");
//        to(chineseLitDetailPage, urlData);
//        Assert.isEquals(chineseLitDetailPage.title.getText(),"CN-05-RE1668-370796");
//
//    }

}



