package com.rpxcorp.insight.test;

import java.util.HashMap;
import java.util.Map;

import javax.mail.MessagingException;

import com.rpxcorp.testcore.Assertion;
import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.rpxcorp.testcore.util.ExcelUtil;
import com.rpxcorp.testcore.util.SQLProcessor;
import com.rpxcorp.oldtest.util.EmailUtil;
import com.rpxcorp.testcore.util.ConfigUtil;

public class EmailMonthlyNPEReport extends Assertion {

	EmailUtil emailUtil;
	String email = "rpxcorpautoc@gmail.com";
	String password = "pramati123";
	Document doc;
	Elements elements;
	JSONObject npeObject;
	SQLProcessor sqlProcessor;
	ExcelUtil testData = new ExcelUtil(ConfigUtil.config().get("testResourcesDir") + "/test_data/NPETestData.xls");

	@Test(dataProvider = "npeEmailData")
	public void topDefendants(Map<String, String> data) throws Exception{		
		HashMap<String, String> dateParams = new HashMap<String, String>();
		dateParams.put("from_date", data.get("from_date"));
		dateParams.put("to_date", data.get("to_date"));

		String paramArray[] = data.get("params").split(",");		
		assertJson(emailData(data.get("type")), sqlProcessor.getSingleValue(data.get("expected_query"), dateParams, data.get("column")), paramArray);
	}

	@DataProvider
	public Object[][] npeEmailData() {
		return testData.getAllCoumnDataAsMap("NPE_Email");				
	}

	public String emailData(String type) throws MessagingException {
		emailUtil = new EmailUtil(email, password);
		emailUtil.connect();

		doc = emailUtil.getLatestMessageAsHTML();
		System.out.println("doc"+ doc);
		elements = doc.select("td.columns:contains(" + type + ") tr");

		JSONArray jsonArray = new JSONArray();		
		for (Element element : elements) {
			JSONObject jsonData = new JSONObject();
			jsonData.put("defendant_name", element.select("td.seven").text());
			jsonData.put("new_campaign_count", element.select("td.sss").text());
			jsonArray.put(jsonData);
		}
		return jsonArray.toString();
	}
}
