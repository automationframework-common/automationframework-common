package com.rpxcorp.insight.page.account;

import org.openqa.selenium.By;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class TermOfServicePage extends BasePage {

    public TermOfServicePage() {
        this.url = new PageUrl("company/terms-of-service");
    }

    @Override
    public boolean at() {
        assertPageTitle("Terms of Service");
        termsOfServiceHeader.waitUntilVisible();
        return copyrightYear.waitUntilVisible();
    }

    public final Element copyrightYear = $(By.xpath(
            "//div[@class='panel']//p[contains(text(),'Copyright 2018 RPX Corporation. All rights reserved.')]"));
    public final Element termsOfServiceHeader = $("#content h1:contains('Terms of Service')");
}
