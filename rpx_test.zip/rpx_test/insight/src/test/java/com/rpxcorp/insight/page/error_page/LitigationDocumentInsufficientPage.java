package com.rpxcorp.insight.page.error_page;

import org.openqa.selenium.By;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class LitigationDocumentInsufficientPage extends BasePage {

    @Override
    public boolean at() {
        return insufficientHeader.waitUntilVisible();
    }

    public final Element insufficientHeader = $(
            By.xpath("//*[@id='doc_download_modal']/div/h2[text()='Insufficient Credit']"));

    public final Element accountCredit = $(".small-3.columns.available_credit.text-right");
    public final Element documentCost = $(".small-3.columns.doc_cost.text-right");

    public final Element purchaseMoreCreditBtn = $(".button.text-transform");
    public final Element cancelBtn = $(".button.secondary.cancle");
}
