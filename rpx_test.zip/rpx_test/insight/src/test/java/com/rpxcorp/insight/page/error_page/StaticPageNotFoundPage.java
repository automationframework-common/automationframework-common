package com.rpxcorp.insight.page.error_page;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;

public class StaticPageNotFoundPage extends BasePage {

    public final Element errorMessage = $(".panel>p");
    public final Element title=$("h1");

    @Override
    public boolean at() {
        return title.getText().equalsIgnoreCase("Page Not Found");
    }

}
