package com.rpxcorp.insight.page.payment;

import com.rpxcorp.insight.page.BasePage;
import com.rpxcorp.testcore.element.Element;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserCreationPage extends BasePage {

    @Override
    public boolean at() {
        loading.waitUntilInvisible();
        return subscribe.waitUntilVisible();
    }

    public final Element userTitle = $("span.ac_title");
    public final Element subscribe = $("form#signup_form button#signup-btn");

    // SIGN UP FORM
    public final Element createAccountTitle = $("h2[class='payment_registration']");
    public final Element first_name = $("form#signup_form #user_first_name");
    public final Element last_name = $("form#signup_form #user_last_name");
    public final Element comp_name = $("form#signup_form input[id*='_company']");
    public final Element email_id = $("form#signup_form #user_email");
    public final Element password = $("form#signup_form #user_password");
    public final Element confirm_password = $("form#signup_form #user_password_confirmation");
    public final Element continue_Button = $("form#signup_form #signup-btn span");
    public final Element loginAtSignup = $(".payment_registration .float-right a");

    // SIGN IN FORM
    public final Element upgradeToTitle = $("h2[class='payment_login']");
    public final Element createOneHereLink = $(By.xpath("//a[text()='Create one here']"));

    // TIMELINE
    public final Element timeline_bar = $(".progress.small-centered.columns.small-6.round");
    public final Element timelineText = $(".small-2.columns");
    public final Element timelineTitle = $(".payment_registration");
    public final Element timelineLogin = $(".payment_login");

    public final Element loginErrors = $(".payment_login .errors");

    public void enterUserDetails(HashMap<String, String> billingData) {
        first_name.sendKeys(billingData.get("first_name"));
        last_name.sendKeys(billingData.get("last_name"));
        comp_name.sendKeys(billingData.get("comp_name"));
        email_id.sendKeys(billingData.get("mail_id"));
        password.sendKeys(billingData.get("PASSWORD"));
        confirm_password.sendKeys(billingData.get("CFM PASSWORD"));
    }

    //new Payment method
    public void enterUserDetailsnew(Map<String, String> billingData) throws Exception{
        first_name.waitUntilClickable();
        Thread.sleep(2000);
        first_name.sendKeys(billingData.get("first_name"));
        last_name.sendKeys(billingData.get("last_name"));
        comp_name.sendKeys(billingData.get("comp_name"));
        email_id.sendKeys(billingData.get("mail_id"));
        password.sendKeys(billingData.get("password"));
        confirm_password.sendKeys(billingData.get("cfm_password"));
    }

    public void signUpAccount(HashMap<String, String> billingData) {
        first_name.sendKeys(billingData.get("first_name"));
        last_name.sendKeys(billingData.get("last_name"));
        comp_name.sendKeys(billingData.get("comp_name"));
        email_id.sendKeys(billingData.get("mail_id"));
        password.sendKeys(billingData.get("password"));
        confirm_password.sendKeys(billingData.get("cnf_password"));
        continue_Button.click();
    }

    public void signupPaymentAccount(String firstName, String lastName, String compName , String email, String pwd, String confirmPwd) {
        first_name.sendKeys(firstName);
        last_name.sendKeys(lastName);
        comp_name.sendKeys(compName);
        email_id.sendKeys(email);
        password.sendKeys(pwd);
        confirm_password.sendKeys(confirmPwd);
        continue_Button.click();
        loading.waitUntilInvisible();
        overlay_Loading.waitUntilInvisible();
    }

    public final Element paymentSignupError = $(".payment_registration .errors:not(.hidden)");

    public List<String> getTimeLineData() {
        List<String> timelineData = new ArrayList<String>();
        List<WebElement> timelineSize = getDriver().findElements(By.cssSelector(
                ".row.progress_stages div:not([class='small-2 columns text-center payment_login hidden']):not([class='small-2 columns'])"));
        for (WebElement time : timelineSize) {
            if (!(time.getText().isEmpty()) && time.getText() != null)
                timelineData.add(time.getText().trim());
        }
        return timelineData;
    }

    public boolean getTimelineCurrentStage(int index) {
        boolean flag = false;
        System.out.println(
                getDriver().findElement(By.cssSelector("span:nth-of-type(" + index + ")")).getAttribute("class"));
        if (getDriver()
                .findElement(By.cssSelector("span:nth-of-type(" + index + ")[class='meter secondary current_stage']"))
                .isDisplayed())
            flag = true;
        return flag;
    }

    public String[] getStageColor() {
        String[] colors = new String[3];
        for (int index = 1; index <= 3; index++) {
            if (getDriver()
                    .findElement(By.cssSelector(
                            ".progress.small-centered.columns.small-6.round span:nth-of-type(" + index + ")"))
                    .getCssValue("background-color").contentEquals("rgba(4, 148, 254, 1)"))  { //BlueColour
                colors[index - 1] = "blue";
            } else if (getDriver()
                    .findElement(By.cssSelector(
                            ".progress.small-centered.columns.small-6.round span:nth-of-type(" + index + ")"))
                    .getCssValue("background-color").contentEquals("rgba(186, 188, 190, 1)")) { //GreyColour
                colors[index - 1] = "grey";
            }
        }
        return colors;
    }

    public final Element user_email_TextBox = $("#login_form #user_email");
    public final Element password_TextBox = $("#login_form  #user_password");
    public final Element login_btn = $("#login_form  input[value*='Login']");

    public void login(String mailId, String pwd) {
        user_email_TextBox.waitUntilClickable();
        user_email_TextBox.sendKeys(mailId);
        password_TextBox.sendKeys(pwd);
        login_btn.click();
    }

    public List<String> timelineData() {
        List<String> timelineData = new ArrayList<String>();
        timelineData.add("Choose Account");
        timelineData.add("Login");
        timelineData.add("Add Payment");
        timelineData.add("Upgrade Complete!");
        return timelineData;
    }

    public void clickOnLoginHereLink() {
        loginAtSignup.waitUntilVisible();
        loginAtSignup.click();
    }

    public void clickCreateOneHereLink() {
        createOneHereLink.click();
        loading.waitUntilInvisible();
    }

}
