package com.rpxcorp.insight.test.functional.advancedsearch;

import com.rpxcorp.insight.page.advance_search.AdvanceSearchPage;
import com.rpxcorp.insight.page.advance_search.LitigationAdvanceSearchPage;
import com.rpxcorp.insight.test.functional.BaseFuncTest;
import com.rpxcorp.testcore.Assert;
import com.rpxcorp.testcore.Authenticate;
import org.testng.annotations.Test;

import java.util.List;

@Authenticate(role = "MEMBER")
public class LitigationAdvanceSearchTest extends BaseFuncTest{

	AdvanceSearchPage advanceSearchPage;
	LitigationAdvanceSearchPage litigationAdvanceSearchPage;

	@Test(priority = 1, groups = "P2", dataProvider = "json",description = "verify patent in suit auto suggest with valid data")
	public void verifyPatentsInSuitAutoSuggestWithValidData(String searchValue,String expectedText,String assertMessage) {
		navigateToLitigationAdvanceSearch();
		litigationAdvanceSearchPage.patentInSuit.sendKeys(searchValue);
		Assert.contains(litigationAdvanceSearchPage.patentInSuit.getDropDownValue(),expectedText);
	}

    @Test(priority = 2, groups = "P3", dataProvider = "json",description = "verify patent in suit auto suggest with in valid data")
    public void verifyPatentsInSuitAutoSuggestWithInValidData(String searchValue,String assertMessage) {
        navigateToLitigationAdvanceSearch();
        litigationAdvanceSearchPage.patentInSuit.sendKeys(searchValue);
        litigationAdvanceSearchPage.waitForRequestInit();
        Assert.isTrue(litigationAdvanceSearchPage.patentInSuit.dropdown.waitUntilInvisible(),
                assertMessage);
    }

    @Test(priority = 3, groups = "P2", dataProvider = "json",description = "verify Header Labels in Patent Litigations Advanced Search Page")
	public void verifyPatentLitHeaderLabels(List<String> expectedHeaders){
		navigateToLitigationAdvanceSearch();
		Assert.isEquals(litigationAdvanceSearchPage.headerLabel.getAllData(), expectedHeaders);
	}

    private void navigateToLitigationAdvanceSearch() {
		to(advanceSearchPage);
		advanceSearchPage.searchFormTabLinks.select(AdvanceSearchPage.SEARCHTAB.Patent_Litigation);
		at(litigationAdvanceSearchPage);
	}

}
