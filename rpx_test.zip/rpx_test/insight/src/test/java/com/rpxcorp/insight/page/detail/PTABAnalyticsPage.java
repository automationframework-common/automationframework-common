package com.rpxcorp.insight.page.detail;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.page.PageUrl;

public class PTABAnalyticsPage extends Page {

    public PTABAnalyticsPage() {
        this.url = new PageUrl("analytics/ptab");
    }

    @Override
    public boolean at() {
        return title.waitUntilVisible();
    }

    public final Element title = $("div.columns h1");


}
