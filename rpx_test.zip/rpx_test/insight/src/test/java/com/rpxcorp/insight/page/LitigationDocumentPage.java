package com.rpxcorp.insight.page;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;

public class LitigationDocumentPage extends BasePage {

    public LitigationDocumentPage() {
        this.url = new PageUrl("litigation_documents/{ID}");
    }

    public final Element document_container = $("embed#plugin[type='application/pdf']");

    @Override
    public boolean at() {
        document_container.isDisplayed();
        return true;
    }
  }
