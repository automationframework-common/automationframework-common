package com.rpxcorp.data;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.rpxcorp.testcore.util.ConfigLoader;
import com.rpxcorp.testcore.util.ConfigUtil;
import org.apache.commons.lang3.ArrayUtils;
import org.testng.ITest;
import org.testng.annotations.*;

import java.io.File;
import java.util.*;
import java.util.Map.Entry;

public class DataETLTest extends ETLHarness implements ITest {
    static final String testSuitePath = ConfigUtil.config().get("testResourcesDir")
            + "/test_case/etl_test/core/";
    String testSuiteName;
    private boolean isBulkRun;
    private boolean processedBulk;
    private Map<String,JsonObject> bulkRunTestData;
    private String bulkModeEtl;

    @Factory(dataProvider = "testSuites")
    public DataETLTest(String testSuiteName) {
        this.testSuiteName = testSuiteName;
    }

    @Test(dataProvider = "testCases")
    public void dataAPITest(String testCaseId, String testDescription,String etlFunction, JsonObject testData,
                            JsonObject expected) throws Exception {
        this.testCaseId=testCaseId;
        if(!isBulkRun) {
            insertOrUpdate(testData);
            Thread.sleep(10000);
            executeETL(etlFunction);
        }
        assertExpectedData(expected);
    }


    /* * * * CONFIGURATION * * * */
    @BeforeMethod
    public void processBulkData() throws Exception {
      if(isBulkRun && !processedBulk){
         for(String testCaseId:bulkRunTestData.keySet()) {
             this.testCaseId=testCaseId;
             insertOrUpdate(bulkRunTestData.get(testCaseId));
         }
         Thread.sleep(10000);
         executeETL(bulkModeEtl);
         processedBulk=true;
      }
    }

    @DataProvider
    public Object[][] testSuites() {
        ArrayList<String> listOfFiles = new ArrayList<String>();
        List<String> seletiveTests = new ArrayList<>();
        String seletiveTest =config.getProperty("test");
        if(seletiveTest != null)
            seletiveTests = Arrays.asList(seletiveTest.split(","));

        for (File file : new File(testSuitePath).listFiles()) {
            String fileName = file.getName();
            if (fileName.endsWith(".json")) {
                if(seletiveTest == null ||
                        (seletiveTest !=null && seletiveTests.contains(fileName.split(".json")[0]))) {
                    listOfFiles.add(fileName);
                }
            }
        }

        Object[][] testSuites = new String[listOfFiles.size()][1];
        for (int i = 0; i < listOfFiles.size(); i++) {
            testSuites[i][0] = listOfFiles.get(i);

        }
        return testSuites;
    }

    @DataProvider
    public Object[][] testCases() throws Exception {
        JsonObject json = ConfigLoader.loadJson(testSuitePath + this.testSuiteName);
        Set<Entry<String, JsonElement>> testCases = json.entrySet();
        this.currentTestUser=json.get("_SETUP").getAsJsonObject().get("user").getAsString();
        JsonElement runinbulk = json.get("_SETUP").getAsJsonObject().get("run_in_bulk");
        if(runinbulk !=null) {
            this.bulkModeEtl = json.get("_SETUP").getAsJsonObject().get("bulk_mode_etls").getAsString();
            this.isBulkRun =   runinbulk.getAsBoolean();
            this.bulkRunTestData = new HashMap<>();
        }

        Object[][] testdata = new Object[testCases.size()-1][5];
        int i = 0;
        for (Entry<String, JsonElement> testCase : testCases) {
            String testKey = testCase.getKey();
            if(!testKey.startsWith("_")) {
                testdata[i][0] = testKey;
                JsonObject testObject = testCase.getValue().getAsJsonObject();
                testdata[i][1] = testObject.get("test_description").getAsString();
                JsonObject testData = testObject.get("testdata").getAsJsonObject();
                if(!isBulkRun){
                    testdata[i][2] = testObject.get("etl").getAsString();
                    testdata[i][3]=testData;
                }else {
                    bulkRunTestData.put(testKey,testData);
                }
                testdata[i][4] = testObject.get("expected").getAsJsonObject();
                i++;
            }
        }
        return testdata;
    }

    @Override
    public String getTestName() {
        return this.testSuiteName;
    }


}
