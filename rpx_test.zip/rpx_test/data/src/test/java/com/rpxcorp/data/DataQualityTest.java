package com.rpxcorp.data;

import java.io.File;
import java.sql.ResultSet;
import java.util.*;
import java.util.stream.Collectors;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.rpxcorp.testcore.UITest;
import com.rpxcorp.testcore.util.ConfigLoader;
import com.rpxcorp.testcore.util.ConfigUtil;
import org.apache.commons.lang3.StringUtils;
import org.testng.ITest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;
import com.rpxcorp.testcore.util.SQLProcessor;


public class DataQualityTest extends UITest implements ITest {
    SQLProcessor sqlProcessor = SQLProcessor.getInstance();
    public static final Properties config = ConfigUtil.config();
    static final String testSuitesPath = ConfigUtil.config().get("testResourcesDir")
            + "/test_case/dq/"+config.getProperty("project").trim().toLowerCase()+"/";
    /*static final String testDataPath = ConfigUtil.config().get("testResourcesDir")
            + "/test_data/dq/";*/
    public final String testSuiteName;
    String testmode = config.getProperty("TEST_DATA_MODE");
    boolean isTestMode = testmode != null && testmode.equals("true");
    static Map<String, Map<String, String>> testdata;
    JsonObject json;

    @Factory(dataProvider = "testSuites")
    public DataQualityTest(String testSuiteName) {
        this.testSuiteName = testSuiteName;
    }

    @Test(dataProvider = "testCases")
    public void verifyDataQuality(String testcase, String query,String openTicket,String queryParams) throws Exception {
        String[] paginate = StringUtils.substringsBetween(query, "@PAGE{", "}");
        ArrayList<String> invalidData = paginate !=null ? getPaginationData(query,paginate[0]) : getData(query,queryParams);
        assertEquals(invalidData, new ArrayList<>());
    }

    public ArrayList<String> getPaginationData(String query, String paginate) throws Exception {
        String[] pageParams = paginate.split(":");
        int limit=  Integer.parseInt(pageParams[0]);
        String countQuery = json.get(pageParams[1]).getAsString();
        int totalRows = Integer.parseInt(sqlProcessor.getSingleValue(sqlProcessor.getResultDataFromQuery(countQuery, null),1));
        int offset = 0;
        ArrayList<String> invalidData = new ArrayList<>();
        while(totalRows > 0){
            if(limit>totalRows)
                limit=totalRows;
            String prmtrzdQuery = query.replace("@PAGE{" + paginate + "}", "LIMIT " + limit + " OFFSET " + offset);
            invalidData.addAll(getData(prmtrzdQuery,null));
            offset = offset+ limit;
            totalRows = totalRows- limit;
            if(invalidData.size() > 10) break;
        }
        return invalidData;
    }
    public ArrayList<String> getData(String query,String paramString) throws Exception {
        ResultSet resultSet;
        HashMap<String,String> params=new HashMap<>();
        if(!StringUtils.isEmpty(paramString))
            params.put("id",paramString);
        resultSet = sqlProcessor.getResultDataFromQuery(query, params);
        return sqlProcessor.getListValue(resultSet, 1);
    }

    @DataProvider
    public Object[][] testSuites()throws Exception {
        JsonObject json = ConfigLoader.loadJson(ConfigUtil.config().get("testResourcesDir") + "/test_data/dq_test_data.json");
        Gson gson = new Gson();
        testdata = gson.fromJson(json, HashMap.class);
        String seletiveTest =config.getProperty("test");
        List<String> seletiveTests = new ArrayList<>();
        //Selective Testsuites
        if(seletiveTest != null)
            seletiveTests = Arrays.asList(seletiveTest.split(","));
        Set<String> sel_SuiteSet = new HashSet<String>(seletiveTests);
        //Json testSuites
        Set<String> test_suites = testdata.keySet();
        //Filter selective test suites from test data suites
        if(!seletiveTests.isEmpty() && isTestMode) {
            test_suites.retainAll(sel_SuiteSet);
        }
        ArrayList<String> listOfFiles = new ArrayList<>();
        for (File file : new File(testSuitesPath).listFiles()) {
            String fileName = file.getName();
            if (fileName.endsWith(".json")) {
                if((isTestMode && test_suites.contains(fileName.split(".json")[0]))||
                        (!isTestMode && StringUtils.isEmpty(seletiveTest)) ||
                        (!isTestMode && !StringUtils.isEmpty(seletiveTest)
                                && seletiveTests.contains(fileName.split(".json")[0]))) {
                    listOfFiles.add(fileName);
                }
            }
        }
        Object[][] testSuites = new String[listOfFiles.size()][1];
        for (int i = 0; i < listOfFiles.size(); i++) {
            testSuites[i][0] = listOfFiles.get(i);
        }
        return testSuites;
    }


    @DataProvider
    public Object[][] testCases() throws Exception {
        String common_input_data=null;
         json = ConfigLoader.loadJson(testSuitesPath + this.testSuiteName);
         Set<Map.Entry<String, JsonElement>> testCases = json.entrySet().stream()
                .filter(testCase -> !testCase.getKey().startsWith("_") &&
                        (!isTestMode || isTestMode &&
                                testdata.get(testSuiteName.split(".json")[0]).containsKey(testCase.getKey()))).collect(Collectors.toSet());

         if(isTestMode && testdata.get(testSuiteName.split(".json")[0]).containsKey("_input_data_from_query")) {
             String input=testdata.get(testSuiteName.split(".json")[0]).get("_input_data_from_query").toString();
             if(input.toLowerCase().contains("select"))
                 common_input_data=getData(input,null).get(0);
             else
                 common_input_data=input;
         }
        Object[][] testdata = new Object[testCases.size()][4];
        int i = 0;
        for (Map.Entry<String, JsonElement> testCase : testCases) {
            String testKey = testCase.getKey();
            testdata[i][0] = testKey;
            JsonObject testObject = testCase.getValue().getAsJsonObject();
            testdata[i][1] = testObject.get("query").getAsString();
            testdata[i][2] = testObject.get("open_ticket").getAsString();
            if(common_input_data!=null)
                testdata[i][3] = common_input_data;
            else
                testdata[i][3] = getTestData(testKey);
            i++;
        }
        return testdata;
    }
    private String getTestData(String testKey){
        if(!this.testdata.containsKey(testSuiteName.split(".json")[0]))
            return null;
        return this.testdata.get(testSuiteName.split(".json")[0]).get(testKey);
    }

    @Override
    public String getTestName() {
        return testSuiteName;
    }
}
