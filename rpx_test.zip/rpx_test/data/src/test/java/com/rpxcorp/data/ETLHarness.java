package com.rpxcorp.data;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.DbConnection;
import com.rpxcorp.testcore.util.HTTPUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.xml.sax.InputSource;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.io.StringReader;
import java.sql.*;
import java.util.*;
import java.util.Date;

public class ETLHarness {
    Map<String,List<String>> processIds= new HashMap<>();
    Properties config=ConfigUtil.config();
    protected String currentTestUser="";
    Map<String,Connection> connectedUser= new HashMap<>();
    String data_Id= DateFormatUtils.format(new Date(), "ddmmHH");
    HTTPUtil etlApi = new HTTPUtil(config.getProperty("ETL_API_BASE_URL"));
    XPathFactory xpathFactory = XPathFactory.newInstance();
    XPath xpath = xpathFactory.newXPath();
    String testCaseId;
    // TODO : add update and delete option
    protected void insertOrUpdate(JsonObject queryData) throws SQLException {
        for (Map.Entry<String, JsonElement> tables : queryData.entrySet()) {
            String tableName = tables.getKey();
            if (tables.getValue().isJsonArray()) {
                for (JsonElement tableData : tables.getValue().getAsJsonArray()) {
                    insertData(tableName, tableData.getAsJsonObject());
                }
            } else {
                insertData(tableName, tables.getValue().getAsJsonObject());
            }
        }
    }

    protected void executeETL(String etlFunction) throws Exception {
        for(String function:etlFunction.split(";")){
            if (function.startsWith("/")) {
                executeETLAPI(function);
            } else {
                executeETLFunction(function);
            }
        }
    }

    protected void executeETLFunction(String function) throws SQLException, InterruptedException {
            function=parseIds(function);
            ResultSet rs = processQuery("select "+function.replaceAll("\\{data_id\\}",data_Id));
            if(rs.next())
                System.out.println(rs.getInt(1));
    }
    protected String executeETLAPI(String etlAPI) throws Exception{
        String jobId = startJob(etlAPI);
        waitForApiJob(10,600,jobId);
        return jobId;
    }

    protected String startJob(String etlAPI) throws Exception {
        Map<String,String> param = new HashMap<>();
        param.put("job","/opt/pentaho/repos/pentaho_misc/current/carte_job_executor/job/jb_carte_utilization.kjb");
        param.put("script","ruby /opt/pentaho/repos/data_ops/current/tools/job_wrapper/job_wrapper.rb "
                + config.get("ETL_ENV") + " /opt/pentaho/repos/portal_etl/current/pdi/bin/" + etlAPI + ".sh -i -q");
        InputSource xmlSource = new InputSource(new StringReader(etlApi.get("kettle/executeJob", param)));
        return xpath.evaluate("//webresult/id",xmlSource);
    }

    public void waitForApiJob(int retryInterval, int timeout,String jobId) throws Exception {
        long start = System.currentTimeMillis();
        String status;
        while (true) {
            Document doc =etlApi.loadPage("/kettle/jobStatus/?name=jb_carte_utilization&id="+jobId);
            Elements element = doc.select("table tr:eq(1)>td:eq(1)");
            status=element.get(0).text();
            if(status.equals("Finished"))
                break;
            if ((System.currentTimeMillis() - start) / 1000 > timeout)
                throw new Exception("Job wait " + timeout + " seconds for job id "+jobId);
            Thread.sleep((long) (1000 * retryInterval));
        }
    }

    protected void assertExpectedData(JsonObject expected) throws SQLException {
        StringBuffer message = new StringBuffer();
        for (Map.Entry<String, JsonElement> tables : expected.entrySet()) {
            ResultSet resultset = processQuery(prepareSelectQuery(tables.getKey(), tables.getValue().getAsJsonObject()));
            JsonElement expectedDatas = tables.getValue().getAsJsonObject().get("_data");
            if (expectedDatas.isJsonNull() && resultset.next()) {

                message.append("Actual :[Record found in table] Expected: [No Data in table] for \""
                        + tables.getKey() + "\"\n");
            } else if (expectedDatas.isJsonArray()) {
                for (JsonElement expectedData : expectedDatas.getAsJsonArray()) {
                    message.append(compareResult(resultset, expectedData, tables.getKey()));
                }
            } else if (expectedDatas.isJsonObject()) {
                message.append(compareResult(resultset, expectedDatas, tables.getKey()));
            }
        }
        assertFailure(message.toString());
    }

    private void insertData(String tableName,JsonObject tableData ) throws SQLException {
        List<String> ids = processUpdate(prepareInsertQuery(tableName,tableData),getUser(tableData));
        String processIdKey = testCaseId + ":" + tableName;
        if(processIds.containsKey(processIdKey)){
            processIds.get(processIdKey).addAll(ids);
        }else {
            processIds.put(processIdKey,ids);
        }
    }
    private String getUser(JsonObject tableData){
        String user = null;
        if(tableData.get("_user") !=null){
            user= tableData.get("_user").getAsString();
        }
        return user;
    }
    private String compareResult(ResultSet resultset, JsonElement expected, String tableName) throws SQLException {
        StringBuffer message = new StringBuffer();
        if (resultset.next()) {
            for (Map.Entry<String, JsonElement> rowData : expected.getAsJsonObject().entrySet()) {
                String actualValue = resultset.getString(rowData.getKey());
                if (actualValue == null)
                    actualValue = "null";
                String expectedValue = rowData.getValue().getAsString();
                expectedValue = expectedValue.replaceAll("\\{data_id\\}", data_Id);
                String[] dataIds = StringUtils.substringsBetween(expectedValue, "{", "}");
                if (dataIds != null) {
                    for (String dataId : dataIds) {
                        String[] position = dataId.split("\\|")[1].split(",");
                        expectedValue = expectedValue.replace("{" + dataId + "}", data_Id.substring(Integer.parseInt(position[0]) - 1, Integer.parseInt(position[1])));
                    }
                }
                if (!expectedValue.equals(actualValue))
                    message.append("Actual :[" + actualValue + "] Expected: [" + expectedValue + "] for \""
                            + tableName + ":" + rowData.getKey() + "\"\n");
            }
        }else {
            message.append("Actual :[No Record found in table] Expected: ["+expected.toString()+"] for \""
                    + tableName + ":" + tableName + "\"\n");
        }
        return message.toString();
    }

    private String prepareInsertQuery(String tableName, JsonObject columns) {
        StringBuffer queryString = new StringBuffer();
        StringBuffer columnData = new StringBuffer();
        queryString.append("insert into ").append(tableName).append(" (");
        for (Map.Entry<String, JsonElement> data : columns.entrySet()) {
            if(!data.getKey().startsWith("_")) {
                queryString.append("\"").append(data.getKey()).append("\",");
                columnData.append("'").append(parseData(data.getValue().getAsString())).append("',");
            }
        }
        columnData.deleteCharAt(columnData.length()-1);
        queryString.deleteCharAt(queryString.length()-1);
        queryString.append(")");
        queryString.append(" values (").append(columnData).append(");");
        return queryString.toString().replaceAll("\\{data_id\\}",data_Id);
    }

    private String prepareSelectQuery(String tableName, JsonObject expectedData){
        StringBuffer queryString = new StringBuffer();
        queryString.append("select ");
        ArrayList<String> expectColumns = getExpectedColumns(expectedData.get("_data"));
        if(expectColumns.size() > 0){
            for (String columnName:expectColumns)
                queryString.append(columnName + ",");
            queryString.deleteCharAt(queryString.length() - 1);
        }else {
            queryString.append("*");
        }
        queryString.append(" from " + tableName);
        if(expectedData.has("_alias")){
           for(Map.Entry<String, JsonElement> alias : expectedData.get("_alias").getAsJsonObject().entrySet()) {
               String aliasTable = alias.getKey();
               String[] aliasColumns=alias.getValue().getAsString().split("=");
               String joinCondition=aliasTable+".";
               if(aliasColumns.length == 2)
                   joinCondition= joinCondition+aliasColumns[0]+"=" + tableName + "." + aliasColumns[1];
               else
                   joinCondition= joinCondition+"id=" + tableName + "." + aliasColumns[0];
               queryString.append(" join " + aliasTable + " on " +joinCondition);
           }
        }
        queryString.append(" where " + parseData(expectedData.get("_restriction").getAsString()) + ";");
        String query = queryString.toString();
        return query.replaceAll("\\{data_id\\}",data_Id);
    }

    private ArrayList<String> getExpectedColumns(JsonElement expectColumns){
        ArrayList<String> columns = new ArrayList<>();
        if(expectColumns.isJsonArray()){
            expectColumns.getAsJsonArray().iterator().forEachRemaining( value -> {
                columns.addAll(extractColumns(value.getAsJsonObject()));
            });
        }else if(expectColumns.isJsonObject()) {
            columns.addAll(extractColumns(expectColumns.getAsJsonObject()));
        }
        return columns;
    }
    private ArrayList<String> extractColumns(JsonObject columnNames){
        ArrayList<String> columns = new ArrayList<>();
        columnNames.entrySet().forEach((data) -> {
            columns.add(data.getKey());
        });
        return columns;
    }
    public String parseIds(String data) {
        if(data.matches("^.*\\{.*\\}.*$") && !data.matches("^.*\\{data_id}.*$")) {
            for (String dataIdKeyString : StringUtils.substringsBetween(data, "{", "}")) {
                String dataIdKey = dataIdKeyString;
                int row = 0;
                if (dataIdKeyString.contains("[")) {
                    String[] dataKeyRow = dataIdKeyString.split("\\[");
                    dataIdKey = dataKeyRow[0];
                    row = Integer.valueOf(dataKeyRow[1].replace("]", ""));
                }
                dataIdKey=testCaseId+":"+dataIdKey;
                if (!processIds.containsKey(dataIdKey))
                    throw new Error("No id found for table " + dataIdKey + " for data row " + row);
                data = data.replace("{" + dataIdKeyString + "}", processIds.get(dataIdKey).get(row));
            }
        }
        return data;
    }
    public String parseData(String data) {
        data=data.replaceAll("'","''");
        return parseIds(data);
    }


    // TODO Move below code to SQL Processor and make it generic
    private Connection getDBConnection(String user) throws SQLException {
        if(user==null)
            user=currentTestUser;
        Connection connection = connectedUser.get(user);
        if(connection == null) {
            connection = DbConnection.getConnection(config.getProperty("DBCORE_HOST_NAME"),
                    user, user + "-" + config.getProperty("DBCORE_PASS_PREFIX"),
                    "5432", false);
            connectedUser.put(user,connection);
        }
        return connection;
    }
    private List<String> processUpdate(String query,String user) throws SQLException {
        List<String> ids= new ArrayList<>();
        try {
            PreparedStatement stmt = getDBConnection(user).prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            int rowsAffected = stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            while(rs.next()){
                ids.add(String.valueOf(rs.getLong(1)));
            }

        } catch (Exception e) {
            System.out.println("Failed to Execute query ...\n" + query);
            System.out.println("---------------------------");
            throw e;
        }

        return ids;
    }

    private ResultSet processQuery(String query) throws SQLException {
        try {
            ResultSet rs = getDBConnection(null).prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY).executeQuery();
            rs.beforeFirst();
            return rs;
        } catch (Exception e) {
            System.out.println("Failed to Execute query ...\n" + query);
            System.out.println("---------------------------");
            throw e;
        }
    }



    private void assertFailure(String message) {
        if (!(message == null || message.equals(""))) {
            String normalizedMessage = message;
            try {
                normalizedMessage = new String(message.getBytes(), "UTF-8");
            } catch (Exception e) {
                e.printStackTrace();
            }
            throw new AssertionError(normalizedMessage);
        }
        assert true;
    }

}
