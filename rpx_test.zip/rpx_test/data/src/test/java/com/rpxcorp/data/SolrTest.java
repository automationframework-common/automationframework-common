package com.rpxcorp.data;

import com.google.gson.*;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.rpxcorp.testcore.Assert;
import com.rpxcorp.testcore.Assertion;
import com.rpxcorp.testcore.util.*;
import org.postgresql.jdbc4.Jdbc4ResultSet;
import org.testng.ITest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.util.*;

public class SolrTest extends Assertion implements ITest{
    public static final Properties config = ConfigUtil.config();
    static final ExcelUtil excelData = new ExcelUtil(config.get("testResourcesDir")
            + "/test_data/solr/"+config.get("test")+"Data.xls");

    SQLProcessor sql= new SQLProcessor();
    HTTPUtil solr=new HTTPUtil(config.getProperty("SOLR_URL"),config.getProperty("SOLR_UNAME"),config.getProperty("SOLR_PSWD"));
    private final String testScenario;
    private final String testCase;
    private final String collection;
    private String q;
    private final String fq;
    private final String fl;
    private final String rawQueryParam;
    private final String json_Facet;
    private final String facet_Pivot;
    private final String facet_Query;
    private final String facet_Fields;
    private final String actualJsonPath;
    private final String assertionCondition;
    private String expected;
    private final String openTicket;
    private String solrUrl;
    private boolean isDbQuery;
    static HashMap<String,String> solrCore= new HashMap<>();
    String[] fq_data,facet_data,facet_query;
    String rowCount="20";
    String fromDate=null,toDate=null;
    private boolean isDLATest=config.getProperty("test").equalsIgnoreCase("DailyLitAlert");
    private String actualData;
    private String expectedData;
    boolean isDLS=false;


    @Test
    public void verifySolr() throws Exception {
        this.solrUrl=getSolrUrl();
        DocumentContext json;
        // If test application is Analyst, we need Solr Hit retry mechanism for 5 times
        // because first few hits return exception(known issue)
        if(!config.get("test").equals("Insight")){
        for(int i = 1 ;  ; i ++)
        {
            try
                {
                    json = solr.getJSON(solrUrl.toString());
                    break;
            }
            catch (JsonSyntaxException e)
            {
                System.out.println(i+"th Attempt Made for:"+this.q);
                if(i == 5)
                {
                    throw e;
                }
            }

        }
        }
        // For Insights Application Test, Solt Query hit need not to retried. One time hit is the validation
        else
            json = solr.getJSON(solrUrl.toString());
        String[] actual;
        Object expectedResult;
        if(expected.toLowerCase().contains("select")){
            if(isDLS && isDLATest){
                expected=expected.replaceAll("12 hours","13 hours");
            }
            expectedResult= sql.getResultDataFromQuery(expected,null);
        }else {
            expectedResult=expected;
        }
        if(assertionCondition.trim().contains("assertJsonArrayOfElements")) {
            JsonArray jsonArray=json.read(actualJsonPath);
            String[] extractedJson=jsonArrayDataBasedOnParams(jsonArray,assertionCondition.split("->")[1]);
            assertOutput(extractedJson, assertionCondition.split("->")[0], expectedResult);
        }
        else {
            actual = json.read(actualJsonPath, String[].class);
            assertOutput(actual,assertionCondition, expectedResult);
        }
    }
    /*
     Description: Conversion of JsonArray to List
     Inputs
     jsonArray-> [{"key1":key1_value1,"key_2":"key2_value2"},{"key1":key1_value2,"key_2":"key2_value2"}]
     String JsonPath of keys
     Output: Appended data in each array of list object based on json path key
     */
    private String[] jsonArrayDataBasedOnParams(JsonArray jsonArray, String s) throws Exception {
        String[] actual_Json_Array=new String[jsonArray.size()];
        String[] keys = s.trim().split(",key=");
        StringBuffer str = new StringBuffer();
        for (int i = 0; i < jsonArray.size(); i++) {
            str.delete(0, str.length());
            for (int k = 0; k < keys.length; k++) {
                DocumentContext json_data = JsonPath.parse(jsonArray.get(i).getAsJsonObject());
                String json_Type = json_data.read(keys[k]).getClass().getSimpleName();
                switch (json_Type) {
                    case "JsonArray":
                        str.append(getJsonArrayDataToString(json_data.read(keys[k])));
                        break;
                    default:
                        str.append(json_data.read(keys[k]).toString()+" ");
                }
            }
            actual_Json_Array[i]=str.toString().trim();
        }
        return actual_Json_Array;
    }
    private String getJsonArrayDataToString(JsonArray json) {
        String str="";
        Iterator it=json.iterator();
        while(it.hasNext()){
            JsonObject obj= JsonPath.parse(it.next()).json();
            Iterator inner_Json=obj.entrySet().iterator();
            while(inner_Json.hasNext()) {
                str = str + inner_Json.next().toString().split("=")[1] + " ";
            }
        }
        return str.trim();
    }

    //***  CONFIGURATION
    @Factory(dataProvider = "testData")
    public SolrTest(String testScenario,String testCase, String collection, String q, String fq,
                    String fl, String rawQueryParam, String actualJsonPath, String assertionCondition, String expected,String openTicket,String json_Facet,String facet_Fields,String facet_Pivot,String facet_Query){
        this.testScenario=testScenario;
        this.testCase=testCase;
        this.collection=collection;
        this.q=q;
        this.fq=fq;
        this.fl=fl;
        this.rawQueryParam=rawQueryParam;
        this.json_Facet=json_Facet;
        this.facet_Pivot = facet_Pivot ;
        this.facet_Query=facet_Query;
        this.facet_Fields=facet_Fields;
        this.actualJsonPath=actualJsonPath;
        this.assertionCondition=assertionCondition;
        this.expected=expected;
        this.openTicket = openTicket;
    }
    
    @DataProvider
    public static Object[][] testData() throws Exception {
        if(config.getProperty("test").equalsIgnoreCase("Insight")) {
            JsonObject solrCoreDatas = ConfigLoader.loadJson(config.get("testResourcesDir") + "/test_data/SoleCoreNames.json");
            for (Map.Entry<String, JsonElement> solrCoreData : solrCoreDatas.entrySet()) {
                Iterator<JsonElement> typeNames = solrCoreData.getValue().getAsJsonArray().iterator();
                while (typeNames.hasNext()) {
                    solrCore.put(typeNames.next().getAsString(), solrCoreData.getKey());
                }
            }
        }
        return excelData.getAllDataFromColumn(0, new Object[] { 0, 1, 2, 3, 4, 5,6,7,8,9,10,11,12,13,14});

    }
    
    @Override
    public String getTestName() {
        return this.testScenario+";"+this.testCase+";"+this.collection+";"+this.q+";"+this.fq+";"
                +this.fl+";"+this.rawQueryParam+";"+this.actualJsonPath+";"+this.assertionCondition+";"+this.expected+";"
                +config.getProperty("SOLR_URL")+this.solrUrl+";"+this.openTicket+";"+this.actualData+";"+this.expectedData+";"+this.json_Facet+";"+this.facet_Fields+";"+this.facet_Pivot+";"+this.facet_Query;
    }
    
    // **** HELPER METHODS   **** /
    
    public String getSolrUrl() throws UnsupportedEncodingException {
        StringBuffer solrUrl = new StringBuffer();
        solrUrl.append(this.collection);
        if(config.getProperty("test").equalsIgnoreCase("Insight")){
            this.isDbQuery=expected.toLowerCase().startsWith("select");
            //****** PARAMTERIZE SOLR QUERY AND DB QUERY
            for (String param:testCase.split(";")){
                String[] keyVal = param.split("=");
                q=q.replace(keyVal[0],keyVal[1]);
                if(isDbQuery)
                    expected=expected.replace(keyVal[0],keyVal[1]);
            }
            solrUrl.append(solrCore.get(fq));
        }
        if(!rawQueryParam.contains("spellcheck=true")) {
            solrUrl.append("/select?");
        }else {
            solrUrl.append("/spell?spellcheck.");
        }
        if(!q.isEmpty()) {
            solrUrl.append("q=").append(URLEncoder.encode(q, "UTF-8") );
        }

        if(!fq.isEmpty())
        { //Handle multiple fq inputs by splitting using delimiter ,fq=
            fq_data=fq.split(",fq=");
            for(String fq1:fq_data) {
                solrUrl.append("&fq=").append(URLEncoder.encode(fq1, "UTF-8"));
            }
        }

        if(!facet_Query.isEmpty())
        { //Handle multiple facet queries inputs by splitting using delimiter ,query=
            facet_query=facet_Query.split(",query=");
            for(String fq1:facet_query) {
                solrUrl.append("&facet.query=").append(URLEncoder.encode(fq1, "UTF-8"));
            }
        }

        if(!json_Facet.isEmpty()) {
            solrUrl.append("&json.facet=").append(URLEncoder.encode(json_Facet, "UTF-8") );
        }
        if(!facet_Pivot.isEmpty()) {
            solrUrl.append("&facet.pivot=").append(URLEncoder.encode(facet_Pivot, "UTF-8") );
        }
        if(!facet_Fields.isEmpty()) {
            facet_data=facet_Fields.split(",facet.field=");
            for(String fc_field:facet_data) {
                solrUrl.append("&facet.field=").append(URLEncoder.encode(fc_field, "UTF-8"));
            }
        }
        if(!fl.isEmpty())
          solrUrl.append("&fl=").append(fl);
        if(!rawQueryParam.isEmpty())
         solrUrl.append("&").append(rawQueryParam);
        if(isDLATest){
            rowCount="500";
            String time="T12:30:00Z";
            TimeZone timeZone = TimeZone.getTimeZone("America/Los_Angeles");
            if(timeZone.getDSTSavings()==3600000){
                //For Day light savings
                  time="T12:30:00Z";
                  isDLS=true;

            }
            try {
                fromDate=sql.getSingleValue("DLA_QUERIES.FROM_DATE","from_date")+time;
                toDate=sql.getSingleValue("DLA_QUERIES.TO_DATE","to_date")+time;
            } catch(Exception e){
                Assert.isFalse(true,"DB query Execution is failed"+e.getMessage());
            }
            solrUrl=new StringBuffer(solrUrl.toString().replace("from_date",fromDate));
            solrUrl=new StringBuffer(solrUrl.toString().replace("to_date",toDate));
        }
        solrUrl.append("&rows="+rowCount+"&wt=json&indent=true");
        return solrUrl.toString();
    }
    // TODO Need to migrate to common assertion class
    private void assertOutput(String[] actualArray, String operation, Object expected) throws Exception {
    	ArrayList<String> actual = new ArrayList<String>(Arrays.asList(actualArray));
    	String jsonKey=null;
    	Boolean isUniqueData=false;
    	String filterCondition=null;
        ResultSet resultSet;

        if(operation.contains(",") && isDLATest) {
    	    String jsonFilters[]=operation.split(",");
    	    operation=jsonFilters[0];
            filterCondition=jsonFilters[1];
    	    jsonKey=jsonFilters[2];
            isUniqueData=Boolean.getBoolean(jsonFilters[3]);
        }
        switch (operation){
            case "contains":
                assertTrue(actual.contains(((String) expected).toLowerCase())
                        ,actual+" not "+operation+" expected value \""+expected+"\"");
                this.actualData=getArrayListAsString(actual);
                this.expectedData=(String) expected;
                break;
            case ">=":
                if(expected.getClass()== Jdbc4ResultSet.class)
                    expected=sql.getSingleValue((ResultSet) expected,1);
                int actualValue = Integer.parseInt(actual.get(0));
                this.actualData=actual.get(0);
                this.expectedData=(String) expected;
                assertTrue(actualValue >=  Integer.parseInt((String) expected),
                        actual+" "+operation+" "+expected);

                break;
            case "assertJsonArrayOfElements":
                    resultSet = (ResultSet) expected;
                    this.actualData=actualArray.toString();
                    this.expectedData=sql.getListValue(resultSet,1).toString();
                    assertEquals(actual,sql.getListValue(resultSet,1));
                    break;
            case "=":
                if(expected.getClass()== Jdbc4ResultSet.class) {
                    resultSet = (ResultSet) expected;
                    int size=sql.getResultCount(resultSet);
                    Set<String> uniqueSet = new HashSet<String>((ArrayList)actual);
                    if(uniqueSet.size() == 0 && isDLATest){
                        this.actualData=getArrayListAsString((ArrayList)actual);
                        this.expectedData=getArrayListAsString(sql.getListValue(resultSet, 1));
                        assertEquals(actual,sql.getListValue(resultSet, 1));
                        break;
                    }
                    if(actual.size() ==1 && size == 1) {
                        expected = sql.getSingleValue(resultSet, 1);
                    }
                    else {
                        if(isDLATest) {
                            this.actualData = getArrayListAsString((ArrayList) actual);
                            this.expectedData = getArrayListAsString(sql.getListValue(resultSet, 1));
                            assertEquals(actual, sql.getListValue(resultSet, 1));
                        }
                        else {
                            this.actualData = getArrayListAsString((ArrayList) actual);
                            this.expectedData = getArrayListAsString(sql.getListValue(resultSet, 1));
                            assertEquals(actualData, expectedData);
                        }
                        break;
                    }
                }
                this.actualData=actual.get(0);
                this.expectedData=(String) expected;
                assertEquals(actual.get(0),expected);
                break;
            case "uniqueData":
                Set<String> uniqueSet = new HashSet<String>((ArrayList)actual);
                ArrayList<String> actualDatas=new ArrayList<String>();
                actualDatas.addAll(uniqueSet);
                if(expected.getClass()== Jdbc4ResultSet.class) {
                    resultSet = (ResultSet) expected;
                    if (uniqueSet.size() == 0 && isDLATest) {
                        this.actualData=String.valueOf(uniqueSet.size());
                        this.expectedData=String.valueOf(sql.getResultCount(resultSet));
                        assertEquals(uniqueSet.size(), sql.getResultCount(resultSet));

                    } else {
                        this.actualData=getArrayListAsString(actualDatas);
                        this.expectedData=getArrayListAsString(sql.getListValue(resultSet,1));
                        assertEquals(actualDatas,sql.getListValue(resultSet,1));
                    }
                }
                    break;
            case "getDataFromFlatJson"://This assertion will compare unique data from flat Json and DB Results
                resultSet=null;
                int size;
                if(expected.getClass()== Jdbc4ResultSet.class) {
                    resultSet = (ResultSet) expected;
                    expected = sql.getListValue(resultSet,1);
                    this.expectedData=getArrayListAsString(sql.getListValue(resultSet,1));
                }
                actual=getFilteredDataFromFlatJson(actual,filterCondition,jsonKey,isUniqueData);
                if(actual.size()==0) {
                    size=sql.getResultCount(resultSet);
                    this.actualData=String.valueOf(size);
                    this.expectedData=String.valueOf(actual.size());
                    assertEquals(actual.size(),size);
                    break;
                }
                this.actualData=getArrayListAsString(actual);
                assertEquals(actual,expected);
                break;

        }
    }

    private String getArrayListAsString(ArrayList<String> actual) {
        String listString = "";

        for (String s : actual)
        {
            if(isDLATest)
            listString += s + "\t";
            else
                listString += s + " ";
        }
        return listString.trim();
    }

    private ArrayList<String> getFilteredDataFromFlatJson(ArrayList<String> jsonPathData,String filterCondition, String jsonKey, Boolean isUniqueData) {
        ArrayList<String> filteredJsonData=new ArrayList<>();
        ArrayList<String> finalFilteredJsonData = filteredJsonData;
        String filterKey = null,filterValue=null;
        //check if we pass any condition(is_newcampaign=true) to filter data from json
        Boolean isfilterData=(!filterCondition.isEmpty());
        if(isfilterData) {
            filterKey = filterCondition.split("=")[0];
            filterValue = filterCondition.split("=")[1];
        }
        for (String data : jsonPathData) {
            //remove[,] at start and at end position to get a json file format in case of such test data ex:[{key:value}]
            if(data.startsWith("[")){
                data=data.replaceFirst("\\[","").replaceAll("\\]$","");
            }
            JsonObject jsonObject = ConfigLoader.loadFlatJsonData(data);
            if (isfilterData) {
                //filter condition ex:is_new_campaign=true
                if (jsonObject.get(filterKey).toString().equalsIgnoreCase(filterValue)){
                        finalFilteredJsonData.add(jsonObject.get(jsonKey).getAsString());
                }
            } else {
                finalFilteredJsonData.add(jsonObject.get(jsonKey).getAsString());
            }
        }
        if(isUniqueData) {
            Set<String> uniqueSet = new HashSet<String>((ArrayList)filteredJsonData);
            filteredJsonData=new ArrayList(Arrays.asList(uniqueSet));
        }

        return filteredJsonData;
    }

}