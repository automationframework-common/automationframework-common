package com.rpxcorp.data;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.rpxcorp.testcore.UITest;
import com.rpxcorp.testcore.util.ConfigLoader;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.SQLProcessor;
import org.testng.ITest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.*;

public class DataComparisonTest extends UITest implements ITest {

    public final String testSuiteName;
    public Properties src_config1 = null;
    public Properties dest_config2 = null;
    SQLProcessor sqlProcessor = SQLProcessor.getInstance();
    static final String testSuitesPath = ConfigUtil.config().get("testResourcesDir")
            + "/test_case/compare_db/"+ConfigUtil.config().getProperty("project").trim().toLowerCase()+"/";
    public HashMap<String,String> src_DB=new HashMap<String,String>();
    public  HashMap<String,String> dest_DB=new HashMap<String,String>();
    public static Connection src_Conn,dest_Conn;
    String input_dataSet=null;
    Boolean is_inputCond=false;

    @BeforeSuite
    public void setUp(){
        src_config1= ConfigLoader.loadProp(ConfigUtil.config().get("testResourcesDir") + "/environment/"
                + ConfigUtil.config().get("source_db") + ".properties");
        dest_config2= ConfigLoader.loadProp(ConfigUtil.config().get("testResourcesDir") + "/environment/"
                + ConfigUtil.config().get("dest_db") + ".properties");
        //Source DB configuarion
        src_DB=setConfig(src_config1);
        //Dest DB configuration
        dest_DB=setConfig(dest_config2);
        try {
             src_Conn = sqlProcessor.initiateConn(src_DB);
             dest_Conn = sqlProcessor.initiateConn(dest_DB);
            } catch (Exception e) {
                e.printStackTrace();
            }
    }

    @Test(dataProvider = "testCases")
    public void verifyDataComparison(String testcase, String src_Query,String dest_Query,String openTicket) throws Exception{
        ResultSet exp_resultSet,act_resultSet;
        if(src_Conn==null || dest_Conn==null ){
            src_Conn = sqlProcessor.initiateConn(src_DB);
            dest_Conn = sqlProcessor.initiateConn(dest_DB);
        }
        if(is_inputCond && input_dataSet.split(",").length>10000){
            List<String[]> inputDataSets = splitInputData(input_dataSet.split(","), 10000);
            for(int i=0;i<inputDataSets.size();i++) {
                System.out.println("Execution dataset"+i);
                String inputData=Arrays.toString(inputDataSets.get(i)).substring(1,Arrays.toString(inputDataSets.get(i)).length()-1);
                src_Query=src_Query.replaceAll("input_data", inputData);
                dest_Query=dest_Query.replaceAll("input_data",inputData);
                exp_resultSet = sqlProcessor.getResultDataFromQuery(src_Query, null, src_Conn);
                act_resultSet = sqlProcessor.getResultDataFromQuery(dest_Query, null, dest_Conn);
                assertResultSets(act_resultSet, exp_resultSet);
            }
        } else {
            exp_resultSet=sqlProcessor.getResultDataFromQuery(src_Query,null,src_Conn);
            act_resultSet=sqlProcessor.getResultDataFromQuery(dest_Query,null,dest_Conn);
            assertResultSets(act_resultSet,exp_resultSet);
        }

    }

    @Factory(dataProvider = "testSuites")
    public DataComparisonTest(String testSuiteName) {
        this.testSuiteName = testSuiteName;
    }

    @DataProvider
    public Object[][] testCases() throws Exception {
        String input_q,input_DbConn;
        Connection dbConn=null;
        JsonObject json = ConfigLoader.loadJson(testSuitesPath + this.testSuiteName);
        Set<Map.Entry<String, JsonElement>> testCases = json.entrySet();
        Object[][] testdata = new Object[testCases.size()][4];
        int i = 0;
        for (Map.Entry<String, JsonElement> testCase : testCases) {
            String testKey = testCase.getKey();
            testdata[i][0] = testKey;
            JsonObject testObject = testCase.getValue().getAsJsonObject();
            if(testObject.keySet().contains("input_data")){
                input_DbConn=ConfigUtil.config().getProperty("input_data_from").trim().toLowerCase();
                is_inputCond=true;
                System.out.println("Started Input Query Execution"+System.currentTimeMillis());
                dbConn=(input_DbConn.equalsIgnoreCase("source"))?src_Conn:dest_Conn;
                input_q=(input_DbConn.equalsIgnoreCase("source"))?testObject.get("input_data").getAsJsonObject().get("src_input_query").getAsString()
                        :testObject.get("input_data").getAsJsonObject().get("dest_input_query").getAsString();
                ResultSet exp_resultSet=sqlProcessor.getResultDataFromQuery(input_q,null,dbConn);
                input_dataSet=sqlProcessor.getSingleValue(exp_resultSet,1);
                System.out.println("Executed Input Query"+ System.currentTimeMillis());
            }
            if(is_inputCond && input_dataSet.split(",").length<=10000) {
                testdata[i][1] = testObject.get("source_query").getAsString().replaceAll("input_data", input_dataSet);
                testdata[i][2] = testObject.get("dest_query").getAsString().replaceAll("input_data", input_dataSet);
            } else {
                testdata[i][1] = testObject.get("source_query").getAsString();
                testdata[i][2] = testObject.get("dest_query").getAsString();
            }
            testdata[i][3] = testObject.get("open_ticket").getAsString();
            i++;
        }
        return  testdata;
    }

    @DataProvider(name="testSuites")
    public Object[][] testSuites()throws Exception {
        String seletiveTest =ConfigUtil.config().getProperty("test");
        List<String> seletiveTests = new ArrayList<>();
        //Selective Testsuites
        if(seletiveTest != null)
            seletiveTests = Arrays.asList(seletiveTest.split(","));
        ArrayList<String> listOfFiles = new ArrayList<>();
        for (File file : new File(testSuitesPath).listFiles()) {
            String fileName = file.getName();
            if (fileName.endsWith(".json")) {
                if((seletiveTests.size()>0 && seletiveTests.contains(fileName.split(".json")[0])) ||(seletiveTests.size()==0)) {
                    listOfFiles.add(fileName);
                }
            }
        }
        Object[][] testSuites = new String[listOfFiles.size()][1];
        for (int i = 0; i < listOfFiles.size(); i++) {
            testSuites[i][0] = listOfFiles.get(i);
        }
        return testSuites;
    }
    //Helper method
    public HashMap<String,String> setConfig(Properties prop){
        HashMap<String,String> dataConn=new HashMap<String, String>();
        dataConn.put("host",prop.getProperty("DB_HOST_NAME").trim().toLowerCase());
        dataConn.put("username",prop.getProperty("DB_USER_NAME"));
        dataConn.put("password",prop.getProperty("DB_PASS"));
        dataConn.put("port",prop.getProperty("DB_PORT"));
        return dataConn;
    }

    public static <T> List<T[]> splitInputData(T[] dataSet, int chunkSize) {
        List<T[]> result = new ArrayList<T[]>();
        if (dataSet ==null || dataSet.length == 0) {
            return result;
        }

        int from = 0;
        int to = 0;
        int slicedItems = 0;
        while (slicedItems < dataSet.length) {
            to = from + Math.min(chunkSize, dataSet.length - to);
            T[] slice = Arrays.copyOfRange(dataSet, from, to);
            result.add(slice);
            slicedItems += slice.length;
            from = to;
        }
        return result;
    }


    @Override
    public String getTestName() {
        return testSuiteName;
    }
}
