package com.rpxcorp.data;

import com.google.common.collect.Sets;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import com.jayway.jsonpath.DocumentContext;
import com.rpxcorp.testcore.Assert;
import com.rpxcorp.testcore.Assertion;
import com.rpxcorp.testcore.util.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.postgresql.jdbc4.Jdbc4ResultSet;
import org.testng.ITest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.text.Normalizer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;


import static net.javacrumbs.jsonunit.JsonAssert.assertJsonEquals;
import static net.javacrumbs.jsonunit.JsonAssert.when;
import static net.javacrumbs.jsonunit.core.Option.IGNORING_ARRAY_ORDER;

public class SolrDQTest extends Assertion implements ITest{
    public static final Properties config = ConfigUtil.config();
    static final ExcelUtil excelData = new ExcelUtil(config.get("testResourcesDir")
            + "/test_data/solr/"+config.get("test")+"Data.xls");

    SQLProcessor sql= new SQLProcessor();
    //HTTPUtil solr=new HTTPUtil(config.getProperty("SOLR_URL"));
    HTTPUtil solr=new HTTPUtil(config.getProperty("SOLR_URL"),config.getProperty("SOLR_UNAME"),config.getProperty("SOLR_PSWD"));
    private final String testScenario;
    private final String testCase;
    private final String collection;
    private String q;
    private final String fq;
    private final String fl;
    private final String rawQueryParam;
    private final String actualJsonPath;
    private final String assertionCondition;
    private String expected;
    private String facetFields;
    private String statsFields;
    private final String openTicket;
    private String solrUrl;
    private boolean isDbQuery;
    private String actualData;
    private String expectedData;
    static HashMap<String,String> solrCore= new HashMap<>();
    String[] fq_data;
    String rowCount="2000";
    String fromDate=null,toDate=null;
    String db_input,solr_input;
    private String input;
    private String uniqueKey;
    Gson gsonObj = new Gson();
    JsonParser parser = new JsonParser();
    private StringBuffer message = new StringBuffer();
    String normalized;
    @Test
    public void verifySolr() throws Exception {
        this.solrUrl=getSolrUrl();
        Object expectedResult;
        DocumentContext json;
        String[] actual=null;
        List<Map<String, Object>> actuallist = null;

        json = solr.getJSON(solrUrl.toString());

        if(config.get("test").equals("PtabAnalytics") && assertionCondition.equals("="))
            actual = json.read(actualJsonPath, String[].class);
        else {
            actuallist = json.read(actualJsonPath, List.class);
            if (actuallist.isEmpty()) {
                assertFalse(true, "Solr doesnt have records for the given input data");
            }
        }
            if(expected.toLowerCase().contains("select")){
                if(db_input!=null)
                    expected=expected.replaceAll("db_input",db_input);
                 expectedResult= sql.getResultDataFromQuery(expected,null);
            }else {
                expectedResult=expected;
            }
            if(assertionCondition.equals("json"))
                assertOutput(actuallist,assertionCondition,expectedResult);
            else
                assertOutput(actual,assertionCondition,expectedResult);
    }

    //***  CONFIGURATION
    @Factory(dataProvider = "testData")
    public SolrDQTest(String testScenario,String testCase, String collection, String q, String fq,
                    String fl, String rawQueryParam, String actualJsonPath, String assertionCondition, String expected,String openTicket,String input,String uniqueKey,String facetFields, String statsFields){
        this.testScenario=testScenario;
        this.testCase=testCase;
        this.collection=collection;
        this.q=q;
        this.fq=fq;
        this.fl=fl;
        this.rawQueryParam=rawQueryParam;
        this.actualJsonPath=actualJsonPath;
        this.assertionCondition=assertionCondition;
        this.expected=expected;
        this.openTicket = openTicket;
        this.input=input;
        this.uniqueKey=uniqueKey;
        this.facetFields = facetFields;
        this.statsFields = statsFields;

    }

    @DataProvider
    public static Object[][] testData() throws Exception {
        return excelData.getAllDataFromColumn(0, new Object[] { 0, 1, 2, 3, 4, 5,6,7,8,9,10,11,12,13,14});

    }

    @Override
    public String getTestName() {
        return this.testScenario+";;"+this.testCase+";;"+this.collection+";;"+this.q+";;"+this.fq+";;"
                +this.fl+";;"+this.rawQueryParam+";;"+this.actualJsonPath+";;"+this.assertionCondition+";;"+this.expected+";;"
                +config.getProperty("SOLR_URL")+this.solrUrl+";;"+this.openTicket+";;"+this.actualData+";;"+this.expectedData+";;"+this.facetFields+";;"+this.statsFields;
    }

    // **** HELPER METHODS   **** /

    public String getSolrUrl() throws UnsupportedEncodingException,Exception {
        StringBuffer solrUrl = new StringBuffer();
        if(!input.isEmpty()) {
            if (input.toLowerCase().contains("select")) {
                ResultSet rs = sql.getResultDataFromQuery(input, null);
                db_input = sql.getSingleValue(rs, "db_input");
                solr_input = sql.getSingleValue(rs, "solr_input");
            }
        }
        solrUrl.append(this.collection);
        if(!rawQueryParam.contains("spellcheck=true")) {
            solrUrl.append("/select?");
        }else {
            solrUrl.append("/spell?spellcheck.");
        }
        if(!q.isEmpty()) {
            solrUrl.append("q=").append(URLEncoder.encode(q.replaceAll("solr_input",solr_input), "UTF-8") );
        }

        if(!fq.isEmpty())
        { //Handle multiple fq inputs by splitting using delimiter ,fq=
            fq_data=fq.split(",fq=");
            for(String fq1:fq_data) {
                solrUrl.append("&fq=").append(URLEncoder.encode(fq1.replaceAll("solr_input",solr_input), "UTF-8"));
            }
        }

        if(!fl.isEmpty())
            solrUrl.append("&fl=").append(fl.replaceAll("solr_input",solr_input));
        if(!rawQueryParam.isEmpty())
            solrUrl.append("&").append(rawQueryParam.replaceAll("solr_input",solr_input));

        //For Ptab analytics cases
        if(!facetFields.isEmpty()) {
            String facetFieldSplitted = facetFields.split("json.facet=")[1];
            solrUrl.append("&json.facet=").append(URLEncoder.encode(facetFieldSplitted, "UTF-8"));
        }
        if(!statsFields.isEmpty()) {
            String statsFieldSplitted = statsFields.split("stats.field=")[1];
            solrUrl.append("&stats.field=").append(URLEncoder.encode(statsFieldSplitted, "UTF-8"));
        }
        solrUrl.append("&rows="+rowCount+"&wt=json&indent=true");
        return solrUrl.toString();
    }

    private void assertOutput(List<Map<String, Object>> actualArray, String operation, Object expected) throws Exception {
        switch (operation) {
            case "json":
                DocumentContext exp = null;
                JsonElement actualJson;
                JsonElement expectedJson = null;
                Type type = new TypeToken<List<Map<String, Object>>>() {
                }.getType();
                if (expected.getClass() == Jdbc4ResultSet.class) {
                    ResultSet resultSet = (ResultSet) expected;
                    expectedJson = parser.parse(sql.getSingleValue(resultSet, 1)).getAsJsonArray();

                }
                Type resultType = new TypeToken<List<Map<String, Object>>>() {
                }.getType();

                List<Map<String, Object>> exp_result = gsonObj.fromJson(gsonObj.toJson(expectedJson), resultType);
                List<Map<String, Object>> act_result = gsonObj.fromJson(gsonObj.toJson(actualArray), resultType);
                compareTwoJsonData(getMapListAsJsonString(actualArray), getMapListAsJsonString(exp_result));
                break;
        }
    }
// Added for Ptab Analytics
private void assertOutput(String[] actualArray, String operation, Object expected) throws Exception {
    ArrayList<String> actual = new ArrayList<String>(Arrays.asList(actualArray));
    String jsonKey=null;
    Boolean isUniqueData=false;
    String filterCondition=null;

    if(operation.contains(",")) {
        String jsonFilters[]=operation.split(",");
        operation=jsonFilters[0];
        filterCondition=jsonFilters[1];
        jsonKey=jsonFilters[2];
        isUniqueData=Boolean.getBoolean(jsonFilters[3]);
    }
    switch (operation){

        case "=":
            if(expected.getClass()== Jdbc4ResultSet.class) {
                ResultSet resultSet = (ResultSet) expected;
                int size=sql.getResultCount(resultSet);
                Set<String> uniqueSet = new HashSet<String>((ArrayList)actual);

                if(actual.size() ==1 && size == 1) {
                    expected = sql.getSingleValue(resultSet, 1);
                }else {
                    this.actualData=getArrayListAsString((ArrayList)actual);
                    this.expectedData=getArrayListAsString(sql.getListValue(resultSet, 1));
                    assertEquals(actual,sql.getListValue(resultSet, 1));
                    break;
                }
            }

            if(actual.get(0).contains(".0")) {
                assertEquals(actual.get(0),(String)expected+".0");
                break;
            }


            this.actualData=actual.get(0);
            this.expectedData=(String) expected;
            assertEquals(actual.get(0),expected);
            break;


    }
}

    private String getArrayListAsString(ArrayList<String> actual) {
        String listString = "";

        for (String s : actual)
        {
            listString += s + "\t";
        }
        return listString.trim();
    }
    private String getMapListAsJsonString(List<Map<String,Object>> list) {
        JsonParser jsonParser=new JsonParser();
        JSONArray json_arr=new JSONArray();
        for (Map<String, Object> map : list) {
            JSONObject json_obj=new JSONObject();
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                String key = entry.getKey();
                Object value = entry.getValue();
                try {
                    if(value!=null)
                        json_obj.put(key,(Object)value);
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    Assert.isFalse(true,e.getMessage());
                }
            }
            json_arr.put(json_obj);
        }
        return jsonParser.parse(json_arr.toString()).toString();

    }

    private Map<String,JSONObject> getMapListAsJsonMap(List<Map<String,Object>> list,String uniqueKey) throws ParseException {
        JSONArray json_arr=new JSONArray();
        Map<String,JSONObject> jsonMap=new HashMap<String,JSONObject>();
        String map_key=null;
        for (Map<String, Object> map : list) {
            JSONObject json_obj=new JSONObject();
            List<String> uniqueSetIds=new ArrayList<String>();
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                String key = entry.getKey();
                String[] uniqueIDs=uniqueKey.split(",");
                for(String uniqueData:uniqueIDs) {
                    if (key.equalsIgnoreCase(uniqueData)) {
                        uniqueSetIds.add(entry.getValue().toString().replaceAll(".0$",""));
                    }
                }
                if(uniqueSetIds.size()==uniqueIDs.length) {
                    StringBuffer stringBuffer = new StringBuffer();
                    Collections.sort(uniqueSetIds);
                    uniqueSetIds.stream().forEach(e -> {
                        stringBuffer.append(e+"::");
                    });
                    map_key = stringBuffer.toString().substring(0, stringBuffer.toString().length() - 2);
                    uniqueSetIds.clear();
                }
                Object value = entry.getValue();
                //date format
                if(key.contains("date")){
                    SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                    SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
                    Pattern DATE_PATTERN = Pattern.compile(
                            "^\\d{4}-\\d{2}-\\d{2}$");
                    if(DATE_PATTERN.matcher(value.toString()).matches()) {
                        Date date = inputFormat.parse(value.toString());
                        String formattedDate = outputFormat.format(date);
                        value=(Object)formattedDate;
                        map.put(key,value);
                    }
                }
                try {
                    switch (value.getClass().getSimpleName()){
                       case "ArrayList":
                        List<Object> data=(ArrayList<Object>) value;
                        data.removeAll(Collections.singletonList(null));
                           if(data.size()>=1) {
                               for (int i = 0; i < data.size(); i++) {
                                   String string_Val=String.valueOf(data.get(i));
                                   //Removing decimal points which got added during conversion
                                   if(string_Val.endsWith(".0")){
                                       string_Val=string_Val.replaceAll(".0$","");
                                   }
                                   //Removing non alpha numeric space and -
                                   string_Val=string_Val.replaceAll("[^A-Za-z0-9\\s-]", "");
                                   normalized = Normalizer.normalize(string_Val, Normalizer.Form.NFD);
                                   String result = normalized;
                                   //Removing special characters
                                   result=result.replaceAll("[!@#$%^&*(),.?\"{}|<>//\\#=\n]","");
                                   StringBuilder sb = new StringBuilder(result);
                                   if(sb.toString().matches("\\d+")){
                                      data.set(i,(Object)(Integer.valueOf(sb.toString())));
                                           } else {
                                       data.set(i,(Object)sb.toString());
                                     }
                                   }
                               json_obj.put(key, data);
                           }
                        break;
                        case "String":
                            if(value!=null){
                                String str;
                                str=value.toString().replaceAll("\\s:\\s",":");
                                str=str.replaceAll("\\s+", "")
                                        .replaceAll("[^-a-zA-Z0-9:]", "");
                                normalized = Normalizer.normalize(str, Normalizer.Form.NFD);
                                json_obj.put(key, normalized);
                            }
                            break;
                        default:
                            json_obj.put(key, value);
                            break;

                    }

                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    Assert.isFalse(true,e.getMessage());
                }
            }
            json_arr.put(json_obj);
            jsonMap.put(map_key,json_obj);
        }
        return jsonMap;
    }

    public void compareTwoJsonData(String actualData,String  expectedData) throws Exception{
        Type type = new TypeToken<List<Map<String, Object>>>(){}.getType();
        List<Map<String, Object>> act = gsonObj.fromJson(actualData.toString(), type);
        List<Map<String, Object>> exp = gsonObj.fromJson(expectedData.toString(), type);
        compareJsonMaps(getMapListAsJsonMap(act, uniqueKey),getMapListAsJsonMap(exp, uniqueKey));

    }


    public void compareJsonMaps( Map<String, JSONObject> act_map, Map<String, JSONObject> exp_map){
        DocumentContext json_act=null;
        DocumentContext json_exp=null;
        Set<String> act_map_keys=act_map.keySet();
        Set<String> exp_map_keys=exp_map.keySet();

        Set<String> diff = Sets.difference(exp_map_keys,act_map_keys);
        if(diff.size()>0){
            message.append(String.join(", ",diff)+" Data is available in DB but not in Solr\n");
        }
        Iterator it=act_map_keys.iterator();
        while (it.hasNext()){
            JsonParser parser=new JsonParser();
            Object key=it.next();
            try {
                assertJsonEquals( parser.parse(exp_map.get(key).toString()),parser.parse(act_map.get(key).toString()), when(IGNORING_ARRAY_ORDER));
            }catch (AssertionError e){
                message.append("For Unique Key: "+key+"\n");
                message.append(e.getMessage().replaceAll("expected:","\n Expected:").replaceAll("but was: <\\{","\n\n Actual: ")+"\n----------------------------------------------------------------------------------------\n");
            }
            }
        if(message.length()>0 || message!=null){
            Assert.isFalse(true,message.toString());
        }

    }


}

