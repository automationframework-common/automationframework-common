package com.rpxcorp.testcore;

import com.google.common.base.Preconditions;
import com.google.common.base.Predicates;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import org.openqa.selenium.*;
import org.openqa.selenium.internal.FindsByXPath;
import org.openqa.selenium.internal.WrapsDriver;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

public class By extends org.openqa.selenium.By {
    public static org.openqa.selenium.By jquery(final String jQueryExpression) {
        if (jQueryExpression == null)
            throw new IllegalArgumentException(
                    "Cannot find elements with a null id attribute.");

        return new ByJquery(jQueryExpression);
    }

    @Override
    public List<WebElement> findElements(SearchContext context) {
        return null;
    }
    public static class ByJquery extends org.openqa.selenium.By implements Serializable {

        private static final long serialVersionUID = -6727228887685051584L;

        private final String jQueryExpression;

        public ByJquery(String jQueryExpression) {
            this.jQueryExpression = jQueryExpression;
        }

        @Override
        public List<WebElement> findElements(SearchContext context) {
            injectCustomSelectors(context);
            List<WebElement> webElements = (List<WebElement>) getJsExecutor(context)
                    .executeScript("return $(\"" + jQueryExpression + "\").get();");
            return webElements;
        }

        @Override
        public WebElement findElement(SearchContext context) {
            injectCustomSelectors(context);
            WebElement element=(WebElement) getJsExecutor(context).executeScript("return $(\"" + jQueryExpression + "\").get(0);");
            if(element==null)
                throw new NoSuchElementException(jQueryExpression+" not found");
            return element;
        }
        private void injectCustomSelectors(SearchContext context) {
            if(jQueryExpression.contains(":match")) {
                getJsExecutor(context).executeScript("$.expr[':'].match = function(el, i, m) {\n" +
                        "    var searchText = m[3];\n" +
                        "    var match = $(el).text().trim().match(searchText)\n" +
                        "    return match && match.length > 0;\n" +
                        "}");
            }
        }
        private static JavascriptExecutor getJsExecutor(SearchContext context) {
            if (context instanceof JavascriptExecutor) {
                // context is most likely the whole WebDriver
                return (JavascriptExecutor)context;
            }
            if (context instanceof org.openqa.selenium.WrapsDriver) {
                // context is most likely some WebElement
                WebDriver driver = ((org.openqa.selenium.WrapsDriver)context).getWrappedDriver();
                Preconditions.checkState(driver instanceof JavascriptExecutor, "This WebDriver doesn't support JavaScript.");
                return (JavascriptExecutor)driver;
            }
            throw new IllegalStateException("We can't invoke JavaScript from this context.");
        }
//        @SuppressWarnings("unchecked")  // cast thoroughly checked
//        private static List<WebElement> getElementListFromJsResponse(Object response) {
//            if (response == null) {
//                // no element found
//                return Lists.newArrayList();
//            }
//            if (response instanceof WebElement) {
//                // a single element found
//                return Lists.newArrayList((WebElement)response);
//            }
//            if (response instanceof List) {
//                // found multiple things, check whether every one of them is a WebElement
//                Preconditions.checkArgument(
//                        Iterables.all((List<?>)response, Predicates.instanceOf(WebElement.class)),
//                        "The JavaScript query returned something that isn't a WebElement.");
//                return (List<WebElement>)response;  // cast is checked as far as we can tell
//            }
//            throw new IllegalArgumentException("The JavaScript query returned something that isn't a WebElement.");
//        }
//
//        private static void filterOutElementsWithoutCommonAncestor(List<WebElement> elements, WebElement ancestor) {
//            for (Iterator<WebElement> iter = elements.iterator(); iter.hasNext(); ) {
//                WebElement elem = iter.next();
//
//                // iterate over ancestors
//                while (!elem.equals(ancestor) && !elem.getTagName().equals("html")) {
//                    elem = elem.findElement(By.xpath("./.."));
//                }
//
//                if (!elem.equals(ancestor)) {
//                    iter.remove();
//                }
//            }
//        }
        @Override
        public String toString() {
            return "By.jquery: " + jQueryExpression;
        }
    }
}
