package com.rpxcorp.testcore.util;

public class SSHUtil extends BashBase {
    String host;
    String username;
    String sshKeyPath;
    public SSHUtil (String host,String username,String sshKeyPath) {
        this.host=host;
        this.username=username;
        this.sshKeyPath=getWinBashPath(sshKeyPath);
        try {
            executeBash("mkdir /tmp");
        } catch (Exception e) {
            System.out.println("Executed make tmp line");
        }
    }

    public String runCommand(String command) throws Exception {
       return executeBash("ssh -o StrictHostKeyChecking=no  -o UserKnownHostsFile=/dev/null  -o LogLevel=quiet -i "+sshKeyPath+" "+username+"@"+host+" "+command);
    }
    public String CopyFilesTo(String localFileLoc, String remoteFileLoc) throws Exception {
        localFileLoc=getWinBashPath(localFileLoc);
        return  executeBash("scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null  -o LogLevel=quiet -i "+sshKeyPath+" "+localFileLoc+" "+username+"@"+host+":"+remoteFileLoc);
    }
    private String getWinBashPath(String path){
        return "/"+path.replaceAll("\\\\", "/").replace(":","");
    }
}
