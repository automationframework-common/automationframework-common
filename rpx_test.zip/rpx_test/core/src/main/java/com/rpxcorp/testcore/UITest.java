package com.rpxcorp.testcore;

import com.google.gson.*;
import com.rpxcorp.testcore.page.Page;
import com.rpxcorp.testcore.util.Base64;
import com.rpxcorp.testcore.util.*;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.Augmenter;
import org.testng.ITestResult;
import org.testng.annotations.*;
import org.testng.internal.ConstructorOrMethod;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;
import java.util.List;

@Listeners(ScreenshotListener.class)
public class UITest extends Assertion {
    private String screenshotPath = getSysConfig("reportsDir") + "/screenshots/";
    // TODO Remove this dummy assignment after cleaning ConfigUtil
    static final Properties config = ConfigUtil.config();
    final static String testDataPath = config.get("testResourcesDir") + "/test_data/";
    protected JsonObject testData;
    private  static UIAuthenticator authenticator =null;
    Authenticate classAuthenticate =null;
    protected Gson gson = new Gson();
    {
        Class<?> pageClass = null;
        try {
            pageClass = Class.forName("com.rpxcorp.insight.util.PortalUIAuthenticator");
            authenticator= (UIAuthenticator) pageClass.newInstance();
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException e) {
//            e.printStackTrace();
        };

    }

    @BeforeClass(alwaysRun = true)
    public void loadTestData() throws Exception {
        if (testData == null && !isFactoryTest()) {
            this.testData = getJsonTestData(this.getClass().getSimpleName() + ".json");
        }
        injectPageObjects();
        classAuthenticate=this.getClass().getAnnotation(Authenticate.class);
        processAuthentication(classAuthenticate);
    }

    @BeforeMethod
    public void authenticator(Method method) {
        this.newWindowImage=null;
        if(authenticator !=null){
            Authenticate authenticate = method.getAnnotation(Authenticate.class);
            if(authenticate == null)
                authenticate = classAuthenticate;
            processAuthentication(authenticate);
        }
    }

    public void processAuthentication(Authenticate authenticate){
        if(authenticate !=null) {
            String auth = getAuth();
            String role = authenticate.role();
            if (auth == null || !auth.split("::")[1].equals(role)) {
                if (auth != null) {
                    authenticator.logout();
                    setAuth(null);
                }
                if(!role.equals("NONE")) {
                    String username = getConfig(role + "_EMAIL");
                    String password = getConfig(role + "_PSWD");
                    authenticator.login(username, password);
                    setAuth(username + "::" + role);
                }
            }
        }
    }

    private void injectPageObjects() throws IllegalAccessException {
        Class<?> currentClass = this.getClass();
        while (currentClass != null && !currentClass.equals(UITest.class)) {
            for (Field field : currentClass.getDeclaredFields()) {
                Class<?> fieldClass = field.getType();
                field.setAccessible(true);
                if (field.get(this) == null && Page.class.isAssignableFrom(fieldClass)) {
                    field.set(this, getPageInstance(fieldClass));
                }
            }
            currentClass = currentClass.getSuperclass();
        }
    }
    private boolean isFactoryTest(){
        boolean isFactoryTest = false;
        for(Constructor<?> cons:this.getClass().getConstructors()){
            isFactoryTest=cons.getAnnotation(Factory.class) !=null;
            if(isFactoryTest)
                break;
        }
        return isFactoryTest;
    }
    protected static JsonObject getJsonTestData(String jsonFileName) throws Exception {
        String filePath = testDataPath + jsonFileName;
        JsonObject data = null;
        if (new File(filePath).exists()) {
            data = ConfigLoader.loadJson(filePath);
        }
        return data;
    }

    protected String dataAsString(String dataKey) {
        return getData(this.testData, dataKey).getAsString();
    }

    protected List<String> dataAsList(String dataKey) throws Exception {
        ArrayList<String> data = null;
        JsonElement jdata = getData(this.testData, dataKey);
        if (jdata != null) {
            if (!jdata.isJsonArray())
                throwInvalidDataException(dataKey, "Json Array");
            data = gson.fromJson(jdata, ArrayList.class);
        }
        return data;
    }

    private void throwInvalidDataException(String dataKey, String dataType) throws Exception {
        throw new Exception("Json Key '" + dataKey + "' in " + this.getClass().getSimpleName() + ".json" + " is not valid " + dataType);
    }

    protected Map<String, String> dataAsMap(String dataKey) throws Exception {
        Map<String, String> data = null;
        JsonElement jdata = getData(this.testData, dataKey);
        if (jdata != null) {
            if (!jdata.isJsonObject())
                throwInvalidDataException(dataKey, "Json Object");
            data = gson.fromJson(jdata, HashMap.class);
        }
        return data;
    }
    protected Object[][] dataAsTestObject(String fileName, String dataKey) throws Exception {
        return dataAsTestObject(getJsonTestData(fileName), dataKey);
    }
    protected Object[][] dataAsTestObject(JsonObject testData,String dataKey) {
        JsonElement jData = getData(testData, dataKey);
        Object[][] data = new Object[0][];
        if (jData == null)
            return data;
        if (jData.isJsonArray()) {
            JsonArray jArray = jData.getAsJsonArray();

            ArrayList<Object> datas = new ArrayList<Object>();
            for (int itemCnt = 0; itemCnt < jArray.size(); itemCnt++) {
                Object formattedData = formatData(jArray.get(itemCnt));
                if(formattedData.getClass().equals(Object[].class)){
                    datas.add(formattedData);
                }else{
                    datas.add(new Object[]{formattedData});
                }
            }
            data= datas.toArray(new Object[jArray.size()][datas.size()]);
        } else if (jData.isJsonObject()) {
            JsonObject jObject = jData.getAsJsonObject();
            data = new Object[jObject.size()][2];
            int i=0;
            for(Map.Entry<String, JsonElement> value:jObject.entrySet()){
                data[i][0]= value.getKey();
                data[i][1]= formatData(value.getValue());
                i++;
            }
        }
        return data;
    }
    protected Object[][] dataAsTestObject(String dataKey) {
        return dataAsTestObject(this.testData, dataKey);
    }

    private Object formatData(JsonElement jdata){
        if(jdata.isJsonArray()){
            return gson.fromJson(jdata, Object[].class);
        }else if(jdata.isJsonObject()){
            return (Map<String,Object>) gson.fromJson(jdata,HashMap.class);
        }else if(jdata.isJsonPrimitive()) {
            return jdata.getAsString();
        }
        return null;
    }
    private JsonElement getData(JsonObject data, String dataKey) {
        if(dataKey.isEmpty()){
            return data;
        }else if (dataKey.contains(".")) {
            String[] keys = dataKey.split("\\.", 2);
            return getData(data.getAsJsonObject(keys[0]), keys[1]);
        } else {
            return data.get(dataKey);
        }
    }

    public void reportScreenshot(ITestResult testResult) {
        if (getSysConfig("screenshot") != null && isBrowserExists()) {
            takeScreenshot(getScreenshotPath(testResult));
        }
    }

    private String getScreenshotPath(ITestResult testResult) {
        Object[] params = testResult.getParameters();
        StringBuffer paramString = new StringBuffer();
        for (Object param : params) {
            paramString.append(param);
        }

        StringBuffer fileName = new StringBuffer();
        fileName.append(screenshotPath)
                .append(testResult.getInstance().getClass().getSimpleName())
                .append(testResult.getInstance().toString().split("@")[1]).append("/")
                .append(testResult.getMethod().getMethodName());
        if (paramString.length() > 0) {
            fileName.append("_").append(checksum(StringUtils.normalizeSpace(paramString.toString())));
        }
        fileName.append(".png");
        return fileName.toString();
    }
    private void takeScreenshot(String fileName) {
       try{
    	   String currentUrl = getDriver().getCurrentUrl();
    	   File screenshotFile = new File(fileName);
    	   File directory = screenshotFile.getParentFile();
    	   if (!directory.exists()) {
            directory.mkdirs();
    	   }
    	   BufferedImage image;
    	   if(this.newWindowImage==null) {
               image= getScreenshotImage();
           }else{
               image =newWindowImage;
           }
    	   saveScreenshot(image,screenshotFile,currentUrl);
       } catch(Exception e) {
    	   System.out.println("Screen shot failed"+e.getMessage());
       }
    }
    private void saveScreenshot(BufferedImage originalImage, File screenshotFile, String currentUrl) {
        try {
            int height = originalImage.getHeight();
            int width = originalImage.getWidth();
            int type = originalImage.getType() == 0 ? BufferedImage.TYPE_INT_ARGB : originalImage.getType();
            BufferedImage resizedImage = new BufferedImage(width, height + 25, type);
            Graphics2D g = resizedImage.createGraphics();
            g.setColor(Color.white);
            g.fillRect(0, 0, width, 25);
            g.setColor(Color.BLACK);
            g.setFont(new Font("Trebuchet MS", Font.BOLD, 15));
            g.drawString("User Role:", 20, 18);
            String userInfo = getAuth();
            if (userInfo != null) {
                String[] value = userInfo.split("::");
                if (value.length > 1) {
                    g.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));
                    g.drawString(value[1], 100, 18);
                    g.setFont(new Font("Trebuchet MS", Font.BOLD, 15));
                    g.drawString("User Name:", 200, 18);
                    g.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));
                    g.drawString(value[0], 290, 18);
                } else {
                    System.out.println("LOGIN INFO VALUE IS [" + value + "]");
                }
            } else {
                g.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));
                g.drawString("ANONYMOUS", 100, 18);
            }
            g.setFont(new Font("Trebuchet MS", Font.BOLD, 15));
            g.drawString("Url:", 640, 18);
            g.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));
            g.drawString(currentUrl, 670, 18);
            g.drawImage(originalImage, 0, 26, width, height + 25, null);
            g.dispose();
            g.setComposite(AlphaComposite.Src);
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            ImageIO.write(resizedImage, "png", screenshotFile);
        } catch (IOException e) {
            System.out
                    .println("'An exception has been thrown while getting the screenshot'");
            e.printStackTrace();
        }
    }
    private void takeScreenshotold(String fileName) {
        FileOutputStream fos;
        try {
            String rawBase64 = getScreenshotDriver().getScreenshotAs(OutputType.BASE64);
            String currentUrl = getDriver().getCurrentUrl();
            byte[] decoded = Base64.decode(rawBase64);
            if (!isPng(decoded)) {
                decoded = Base64.decode(decoded);
            }
            File screenshotFile = new File(fileName);
            File directory = screenshotFile.getParentFile();
            if (!directory.exists()) {
                directory.mkdirs();
            }
//		if (reduceSize){
            saveReducedImage(decoded, screenshotFile, currentUrl);
//		}else{
//			fos = new FileOutputStream(screenshotFile);
//			fos.write(decoded);
//			fos.close();
//		}
        } catch (WebDriverException e) {
            System.out
                    .println("'An exception has been thrown while getting the screenshot'");
            e.printStackTrace();
        }
    }

    private void saveReducedImage(byte[] decoded, File screenshotFile, String currentUrl) {
        try {
            ByteArrayInputStream bis = new ByteArrayInputStream(decoded);
            BufferedImage originalImage = ImageIO.read(bis);
            int height = originalImage.getHeight();
            int width = originalImage.getWidth();
            int type = originalImage.getType() == 0 ? BufferedImage.TYPE_INT_ARGB : originalImage.getType();
            BufferedImage resizedImage = new BufferedImage(width, height + 25, type);
            Graphics2D g = resizedImage.createGraphics();
            g.setColor(Color.white);
            g.fillRect(0, 0, width, 25);
            g.setColor(Color.BLACK);
            g.setFont(new Font("Trebuchet MS", Font.BOLD, 15));
            g.drawString("User Role:", 20, 18);
            String userInfo = getAuth();
            if (userInfo != null) {
                String[] value = userInfo.split("::");
                if (value.length > 1) {
                    g.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));
                    g.drawString(value[1], 100, 18);
                    g.setFont(new Font("Trebuchet MS", Font.BOLD, 15));
                    g.drawString("User Name:", 200, 18);
                    g.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));
                    g.drawString(value[0], 290, 18);
                } else {
                    System.out.println("LOGIN INFO VALUE IS [" + value + "]");
                }
            } else {
                g.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));
                g.drawString("ANONYMOUS", 100, 18);
            }
            g.setFont(new Font("Trebuchet MS", Font.BOLD, 15));
            g.drawString("Url:", 640, 18);
            g.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));
            g.drawString(currentUrl, 670, 18);
            g.drawImage(originalImage, 0, 26, width, height + 25, null);
            g.dispose();
            g.setComposite(AlphaComposite.Src);
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            ImageIO.write(resizedImage, "png", screenshotFile);
        } catch (IOException e) {
            System.out
                    .println("'An exception has been thrown while getting the screenshot'");
            e.printStackTrace();
        }
    }

    private TakesScreenshot getScreenshotDriver() {
        if (getDriver() instanceof TakesScreenshot) {
            return (TakesScreenshot) getDriver();
        } else {
            WebDriver augmentedDriver = new Augmenter().augment(getDriver());
            if (augmentedDriver instanceof TakesScreenshot) {
                return (TakesScreenshot) augmentedDriver;

            }
        }
        return null;
    }

    private boolean isPng(byte[] bytes) {
        try {
            return new DataInputStream(new ByteArrayInputStream(bytes))
                    .readLong() == 0x89504e470d0a1a0aL;
        } catch (IOException e) {
            // not going to happen
            return false;
        }
    }

    public static int checksum(String string) {
        final int length = string.length();
        int sum1 = 0;
        int sum2 = 0;
        for (int offset = 0; offset < length; offset++) {
            final int codepoint = string.codePointAt(offset);
            sum1 = (sum1 + codepoint) % 255;
            sum2 = (sum2 + sum1) % 255;
        }

        return sum2 * 256 + sum1;
    }

    @DataProvider
    public static Object[][] json(ConstructorOrMethod consOrMethod) throws Exception {
        JsonData jsonData=null;
        if(consOrMethod.getMethod() != null) {
            jsonData = consOrMethod.getMethod().getAnnotation(JsonData.class);
        }else{
            jsonData= (JsonData) consOrMethod.getConstructor().getAnnotation(JsonData.class);
        }
        String jsonKey,fileName="";
        if (jsonData == null){
            if(consOrMethod.getMethod() != null) {
                jsonKey = consOrMethod.getMethod().getName();
            }else {
                jsonKey = consOrMethod.getConstructor().getDeclaringClass().getSimpleName();
            }
        }else {
            fileName = jsonData.fileName();
            jsonKey = jsonData.datakey();
        }
        if(fileName.isEmpty())
            fileName=consOrMethod.getDeclaringClass().getSimpleName();

        Object[][] data = new UITest().dataAsTestObject(fileName + ".json", jsonKey);
        if(data.length ==0)
            throw new Exception("Mention the data key value using @JsonData(value='jsonPath')");
        return data;
    }

    @DataProvider
    public static Object[][] excelData(ConstructorOrMethod consOrMethod) throws Exception {
        ExcelData excelData=null;
        if(consOrMethod.getMethod() != null) {
            excelData = consOrMethod.getMethod().getAnnotation(ExcelData.class);
        }else{
            excelData= (ExcelData) consOrMethod.getConstructor().getAnnotation(ExcelData.class);
        }
        if (excelData == null)
            throw new Exception("Mention the data key value using @ExcelData(fileName='FooExcel',columns='1,2,3,\"columnName\",\"{{factoryVariable}}\"' )");
        ExcelUtil excelFile = new ExcelUtil(testDataPath + excelData.fileName() + ".xls");
        return excelFile.getAllDataFromColumn(excelData.columns().split(","));
    }

}
