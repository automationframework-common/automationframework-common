package com.rpxcorp.testcore.element;

import com.rpxcorp.testcore.util.Configure;
import jodd.csselly.CSSelly;
import jodd.csselly.CssSelector;
import jodd.csselly.Selector;
import jodd.csselly.selector.AttributeSelector;
import jodd.csselly.selector.Match;
import jodd.csselly.selector.PseudoClassSelector;
import jodd.csselly.selector.PseudoFunctionSelector;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import java.lang.invoke.SerializedLambda;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

public class Element extends BaseElement {
    private By locator;
    static List<String> customClass = Arrays.asList("first", "last", "button", "checkbox", "file", "header", "image", "input", "parent", "password", "radio", "reset", "selected", "checked", "submit", "text", "even", "odd");
    static List<String> customFuntions = Arrays.asList("contains", "eq", "gt", "lt", "has");

    public Element(By locator) {
        this.locator = locator;
    }

    public Element(String selectorStr) {
        this.locator = getByObject(selectorStr);
    }

    //TODO Temp method for module concept
    protected void updateSelector(String selector) {
        this.locator = By.cssSelector(selector);
    }

    @Override
    public WebElement getElement() {
//        waitForDOM();
        return getDriver().findElement(this.locator);
    }

    @Override
    public List<WebElement> getElements() {
        waitForDOM();
        return getDriver().findElements(this.locator);
    }

    public void inputText(Object value){
        sendKeys((String) value);
    }

    public Element of(Object... value) {
        String selectorString = getSelectorString();
        int i = 0;
        String[] keys = StringUtils.substringsBetween(selectorString, "{", "}");
        for (String key : keys) {
            selectorString = selectorString.replaceAll("\\{" + key + "\\}", String.valueOf(value[i]));
            i++;
        }
        return new Element(selectorString);
    }

    public Element $(String subSelector) {
        if (!subSelector.startsWith(":") && !subSelector.startsWith("+")
                && !subSelector.startsWith("[") && !subSelector.startsWith(">"))
            subSelector = " " + subSelector;
        return new Element(getSelectorString() + subSelector);
    }

    protected <T> T $(String cssseletor, Configure<T> configuration) {
        T value = $(cssseletor,getModuleClass(configuration));
        configuration.apply(value);
        return value;
    }

    private Class<?> getModuleClass(Configure configuration) {
        Class<?> type = null;
        try {
            Method replaceMethod = configuration.getClass().getDeclaredMethod("writeReplace");
            replaceMethod.setAccessible(true);
            SerializedLambda lambda = (SerializedLambda) replaceMethod.invoke(configuration);
            String implClassName = lambda.getImplClass().replace('/', '.');
            Class<?> implClass = Class.forName(implClassName);
            String value = lambda.getInstantiatedMethodType();
            String lambdaName = lambda.getImplMethodName();
            Method method = null;
            for (Method m : implClass.getDeclaredMethods()) {
                if (m.getName().equals(lambdaName)) {
                    method = m;
                    break;
                }
            }
            Type[] types = method.getGenericParameterTypes();
            type = (Class<?>) types[types.length-1];
        } catch (Exception e) {
            e.printStackTrace();
        }
        return type;
    }
    protected <T> T $(String cssSelector, String moduleClass) {
        return $(cssSelector, findClass(moduleClass));
    }

    protected <T> T $(String subSelector, Class<?> moduleClass) {
        if (!subSelector.startsWith(":") && !subSelector.startsWith("+"))
            subSelector = " " + subSelector;
        T element = null;
        Constructor<?> ctor;

        try {
            ctor = moduleClass.getDeclaredConstructor(String.class);
            ctor.setAccessible(true);
            element = (T) ctor.newInstance(getSelectorString() + subSelector);
        } catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException
                | IllegalArgumentException | InvocationTargetException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return element;
    }
    public void selectByOption(Object value) {
        selectByOption((String) value);
    }
    public void selectByOption(String value) {
        if (value != null && !value.isEmpty())
            new Select(getElement()).selectByVisibleText(value);
    }
    public void selectByOptionAndWaitForAjaxLoader(String value) throws Exception{
        if (value != null && !value.isEmpty())
            new Select(getElement()).selectByVisibleText(value);
        Thread.sleep(1000);
        $(".blockUI.blockMsg.blockElement>img").waitUntilInvisible();
    }
    public void selectByIndex(int index) {
            new Select(getElement()).selectByIndex(index);
    }

    public String getSelectedOption() {
        return new Select(getElement()).getFirstSelectedOption().getText();
    }

    public int size() {
        return getElements().size();
    }
    public String findNextChildLocator(String baseLocator, String locator, int depth){
        String navigate="";
        for (int i = 0; i < depth; i++) {
            String chilLocator=baseLocator+navigate+locator;
            if ($(chilLocator).isPresent())
                return chilLocator;
            navigate+=">";
        }
        return null;
    }
    public boolean waitUntilPresent() {
        getWait().until(ExpectedConditions.presenceOfElementLocated(locator));
        return true;
    }
    public boolean waitUntilVisible() {
        getWait().until(ExpectedConditions.visibilityOfElementLocated(locator));
        return true;
    }

    public boolean waitUntilTextPresent(String text) {
        getWait().until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
        return true;
    }

    public boolean waitUntilTextContains(String text) {
        return waitUntilTextMatches(".*" + text + ".*");
    }

    private boolean waitUntilTextMatches(String text) {
        Pattern pattern = Pattern.compile(text);
        getWait().until(ExpectedConditions.textMatches(locator, pattern));
        return true;
    }

    public Class<?> findClass(String className) {
        try {
            return Class.forName(className);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new Error(className + "module not found");
        }
    }

    public boolean waitUntilClickable() {
        getWait().until(ExpectedConditions.elementToBeClickable(locator));
        return true;
    }

    public boolean waitUntilElementSelected() {
        getWait().until(ExpectedConditions.elementToBeSelected(locator));
        return true;
    }

    public boolean waitUntilElementUnSelected() {
        getWait().until(ExpectedConditions.elementSelectionStateToBe(locator, false));
        return true;
    }

    public boolean waitUntilInvisible() {
        getWait().until(ExpectedConditions.invisibilityOfElementLocated(locator));
        return true;
    }

    public boolean waitUntilElementSize(int size) {
        return getWait().until(new ExpectedCondition<Boolean>() {
            @Override
            public Boolean apply(WebDriver webDriver) {
                return webDriver.findElements(locator).size() == size;
            }
        });
    }

    public boolean waitUntilNoElementPresent() {
        return waitUntilElementSize(0);
    }

    protected String getInnerHtml() {
        return getAttribute("outerHTML");
    }

    public int count() {
        return getElements().size();
    }

    public Object getData() {
        return getText();
    }

    public ArrayList<String> getAllData() {
        ArrayList<String> data = new ArrayList<String>();
        for (WebElement element : getElements()) {
            data.add(element.getAttribute("textContent").trim());//getText()
        }
        return data;
    }

    public String text() {
        StringBuilder string = new StringBuilder();
        for (WebElement element : getElements()) {
            string.append(element.getText());
        }
        return string.toString();
    }

    public ArrayList<Integer> getAllDataInInteger() {
        ArrayList<Integer> data = new ArrayList<Integer>();
        for (WebElement element : getElements()) {
            data.add(Integer.parseInt(element.getText()));
        }
        return data;
    }

    public ArrayList<String> getAllLinksURLs() {
        ArrayList<String> data = new ArrayList<String>();
        for (WebElement element : getElements()) {
            data.add(element.getAttribute("href"));
        }
        return data;
    }

    public String getLink() {
        return getElement().getAttribute("href");
    }

    public String getPartialLink() {
        return getLink().replaceAll(getConfig("BASE_URL"), "");
    }

    public int getIntData() {
        int data = 0;
        try {
            data = Integer.parseInt((getText()).replaceAll("[\\D]", "").trim());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }

    public Object getData(int i) {
        Object data = "";
        try {
            data = getElements().get(i).getText();
        } catch (NoSuchElementException e) {
            // e.printStackTrace();
        }
        return data;
    }


    public String getSelectorString() {
        String locatorStr = locator.toString();
        String selector = locatorStr.replaceAll("By\\..*?\\: ", "");
        if (locatorStr.contains("By.className:")) {
            selector = "." + selector;
        } else if (locatorStr.contains("By.id:")) {
            selector = "#" + selector;
        } else if (locatorStr.contains("By.name:")) {
            selector = "[name='" + selector + "']";
        }
        return selector;
    }

    public boolean waitUntilSwitchToFrame() {
        getWait().until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(locator));
        return true;
    }

    private org.openqa.selenium.By getByObject(String selectorStr) {
        if (selectorStr.contains("//")) {
            return com.rpxcorp.testcore.By.xpath(selectorStr);
        }
        List<CssSelector> selectors = parseCSSSelector(selectorStr);
        if (selectors == null) {
            return com.rpxcorp.testcore.By.jquery(selectorStr);
        }

        CssSelector selector = selectors.get(0);
        if (selectors.size() == 1) {
            if (!selector.getElement().equals("*") && selector.selectorsCount() == 0) {
                return com.rpxcorp.testcore.By.tagName(selector.getElement());
            } else if (selector.getElement().equals("*") && selector.selectorsCount() == 1) {
                Selector selectorValue = selectors.get(0).getSelector(0);
                if (selectorValue instanceof AttributeSelector) {
                    AttributeSelector attribute = (AttributeSelector) selectorValue;
                    if (attribute.getMatch().equals(Match.EQUALS)) {
                        if (attribute.getName().equals("id")) {
                            return com.rpxcorp.testcore.By.id(attribute.getValue());
                        } else if (attribute.getName().equals("name")) {
                            return com.rpxcorp.testcore.By.name(attribute.getValue());
                        }
                    } else if (attribute.getMatch().equals(Match.INCLUDES) && attribute.getName().equals("class")) {
                        return com.rpxcorp.testcore.By.className(attribute.getValue());
                    }
                }
            }
        }
        return com.rpxcorp.testcore.By.cssSelector(selectorStr);
    }


    private List<CssSelector> parseCSSSelector(String selectorStr) {
        List<CssSelector> selectors = null;
        try {
            CSSelly csselly = new CSSelly(selectorStr);
            selectors = csselly.parse();
        } catch (Exception e) {
        }
        if (selectors != null) {
            for (CssSelector selector : selectors) {
                for (int i = 0; i < selector.selectorsCount(); i++) {
                    boolean a = false;
                    if (selector.getSelector(i) instanceof PseudoFunctionSelector) {
                        a = customFuntions.contains(((PseudoFunctionSelector) selector.getSelector(i)).getPseudoFunction().getPseudoFunctionName());
                    } else if (selector.getSelector(i) instanceof PseudoClassSelector) {
                        a = customClass.contains(((PseudoClassSelector) selector.getSelector(i)).getPseudoClass().getPseudoClassName());
                    }
                    if (a) {
                        selectors = null;
                        break;
                    }
                }
            }
        }
        return selectors;
    }

    public void select() {
        if (!getElement().isSelected()) {
            getElement().click();
        }
    }

    public void unSelect() {
        if (getElement().isSelected()) {
            getElement().click();
        }
    }

    public void clickAndHold() {
        Actions action = new Actions(getDriver());
        action.clickAndHold(getElement()).build().perform();
    }

    public void mouseover() {
        JavascriptExecutor js = (JavascriptExecutor) getDriver();
        System.out.println("$('" + getSelectorString() + "').mouseover()");
        js.executeScript("$('" + getSelectorString().replaceAll("'", "\"") + "').mouseover();");
    }

    public void moveTo(int x, int y) {
        Actions action = new Actions(getDriver());
        action.moveToElement(getElement(), x, y).build().perform();
    }

    public void moveTo() {
        Actions action = new Actions(getDriver());
        action.moveToElement(getElement()).build().perform();
    }

    public void clickAt(int x, int y) {
        Actions action = new Actions(getDriver());
        action.moveToElement(getElement(), x, y).click().build().perform();
    }

    public void rightClickToOpenNewTab() {
        Actions action = new Actions(getDriver());
        action.contextClick(getElement()).sendKeys(Keys.ARROW_UP).sendKeys(Keys.ENTER);
        action.build().perform();
    }

    public void dragAndDropBy(int xOffset, int yOffset) {
        new Actions(getDriver()).dragAndDropBy(getElement(), xOffset, yOffset).build().perform();
    }

    public String getValue() {
        return getElement().getAttribute("value");
    }

    public void click(Boolean hasException) {
        try {
            getElement().click();
        } catch (Exception e) {
            if (hasException)
                throw e;
        }
    }

    public void scrollAndClickOn(){
        ((JavascriptExecutor) getDriver()).executeScript(
                "arguments[0].scrollIntoView(true);", getElement());

        getElement().click();
    }

    public void scrollAndFocus(){
        ((JavascriptExecutor) getDriver()).executeScript(
                "arguments[0].scrollIntoView(true);", getElement());
    }

    public boolean isEditable() {
        return !$("[readonly]").isDisplayed();
    }

    public boolean isFocused() {
        return $(":focus").isDisplayed();
    }

    public void inputData() {
        inputData("some TEST");
    }
    public void inputData(Object data) {
        sendKeys(data.toString());
    }
}
