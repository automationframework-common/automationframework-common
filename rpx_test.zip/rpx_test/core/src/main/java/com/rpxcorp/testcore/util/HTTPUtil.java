package com.rpxcorp.testcore.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.*;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.*;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.*;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.*;
import org.apache.http.impl.conn.SingleClientConnManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.xml.sax.InputSource;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

@SuppressWarnings("deprecation")
public class HTTPUtil {
    String BaseURL;
    HttpClient httpClient;
    HttpHost httpHost;
    HttpContext httpContext;
    CredentialsProvider credsProvider;
    XPath xpath;
    public HTTPUtil(String BaseURL) {
        this.BaseURL = BaseURL;
        HostnameVerifier hostnameVerifier = org.apache.http.conn.ssl.SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER;
        httpClient = new DefaultHttpClient();
        httpClient.getParams().setParameter(ClientPNames.COOKIE_POLICY, CookiePolicy.BROWSER_COMPATIBILITY);
        if(BaseURL.startsWith("https")){
            SchemeRegistry registry = new SchemeRegistry();
            SSLSocketFactory socketFactory = SSLSocketFactory.getSocketFactory();
            socketFactory.setHostnameVerifier((X509HostnameVerifier) hostnameVerifier);
            registry.register(new Scheme("https", socketFactory, 443));
            SingleClientConnManager mgr = new SingleClientConnManager(httpClient.getParams(), registry);
            httpClient = new DefaultHttpClient(mgr, httpClient.getParams());
        }

        CookieStore cookieStore = new BasicCookieStore();
        httpContext = new BasicHttpContext();
        httpContext.setAttribute(ClientContext.COOKIE_STORE, cookieStore);

    }
    public HTTPUtil(String BaseURL, String username, String password){
        this.BaseURL = BaseURL;
        URI uri = URI.create(BaseURL);
        httpHost = new HttpHost(uri.getHost(), uri.getPort(), uri.getScheme());
        credsProvider = new BasicCredentialsProvider();
        credsProvider.setCredentials(new AuthScope(uri.getHost(), uri.getPort()), new UsernamePasswordCredentials(username, password));
        AuthCache authCache = new BasicAuthCache();
        BasicScheme basicAuth = new BasicScheme();
        authCache.put(httpHost, basicAuth);
        HttpClientContext httpClientContext = HttpClientContext.create();
        httpClientContext.setAuthCache(authCache);
        httpContext = httpClientContext;

    }
    public Document loadPage(String url)throws Exception {

        return Jsoup.parse(get(url));
    }
    public String get(String url)  throws Exception {
        if(url.contains("uspto")){
            // use the TrustSelfSignedStrategy to allow Self Signed Certificates
            SSLContext sslContext = SSLContextBuilder
                    .create()
                    .loadTrustMaterial(new TrustSelfSignedStrategy())
                    .build();

            // we can optionally disable hostname verification.
            // if you don't want to further weaken the security, you don't have to include this.
            HostnameVerifier allowAllHosts = new NoopHostnameVerifier();

            // create an SSL Socket Factory to use the SSLContext with the trust self signed certificate strategy
            // and allow all hosts verifier.
            SSLConnectionSocketFactory connectionFactory = new SSLConnectionSocketFactory(sslContext, allowAllHosts);

            // finally create the HttpClient using HttpClient factory methods and assign the ssl socket factory
            this.httpClient=HttpClients
                    .custom()
                    .setSSLSocketFactory(connectionFactory)
                    .build();
        }
        HttpGet httpget = new HttpGet(getFullUrl(url));
       return processRequest(httpget);
    }
    public String get(String url, Map<String,String> params)  throws Exception {
        URIBuilder uri = new URIBuilder(getFullUrl(url));
        params.entrySet().forEach( param-> {
            uri.addParameter(param.getKey(),param.getValue());
        });
        HttpGet httpget = new HttpGet(uri.build());
        return processRequest(httpget);
    }
    public DocumentContext getJSON(String url) throws Exception {
        return JsonPath.parse(get(url));
    }

    public DocumentContext getJSONFromPost(String url,List<BasicNameValuePair> params,HashMap<String,String> headers) throws Exception {
        HttpPost httpPost = new HttpPost(BaseURL+url);
        for (String key : headers.keySet()) {
            httpPost.addHeader(key, headers.get(key));
        }

        httpPost.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
        return JsonPath.parse(processRequest(httpPost));
    }

    public String getFullUrl(String url){
        if(!url.startsWith("http"))
            url=BaseURL + url;
        return url;
    }
    public String getCSRF_Token(Document doc){
        return doc.select("meta[name*=token]").get(0).attr("content");
    }

    public String getCSRF_Token(String url)  throws Exception {
        Document doc =loadPage(url);
        return getCSRF_Token(doc);
    }

    public String put(String url, HashMap<String, String> params)  throws Exception {

        List<NameValuePair> api_params = new ArrayList<>();
        HttpPut httpPut= new HttpPut(BaseURL + url);
        for (String key : params.keySet()) {
            api_params.add(new BasicNameValuePair(key, params.get(key)));
        }
        httpPut.setEntity(new UrlEncodedFormEntity(api_params));
        return processRequest(httpPut);
    }
    public String post(String url, HashMap<String, String> params) throws Exception {
        return  post(url,params, new HashMap<>());
    }
    public String post(String url, String json, HashMap<String, String> headers) throws Exception {
        List<NameValuePair> api_params = new ArrayList<>();
        HttpPost httpPost = new HttpPost(BaseURL + url);
        StringEntity jsonData = new StringEntity(json);
        httpPost.setEntity(jsonData);
        for (String key : headers.keySet()) {
            httpPost.addHeader(key, headers.get(key));
        }
        return  processRequest(httpPost);
    }
    public String post(String url, HashMap<String, String> params, HashMap<String, String> headers) throws Exception {
        List<NameValuePair> api_params = new ArrayList<>();
        HttpPost httpPost = new HttpPost(BaseURL + url);
        for (String key : params.keySet()) {
            api_params.add(new BasicNameValuePair(key, params.get(key)));
        }
        httpPost.setEntity(new UrlEncodedFormEntity(api_params));
        for (String key : headers.keySet()) {
            httpPost.addHeader(key, headers.get(key));
        }
        return  processRequest(httpPost);
    }

    public String processRequest(HttpUriRequest request) throws Exception {
        HttpResponse httpresponse;
        if(httpHost!=null) {
            httpClient = HttpClients.custom().setDefaultCredentialsProvider(credsProvider).build();
            httpresponse = httpClient.execute(httpHost, request, httpContext);
        }
        else if(httpContext!=null)
            httpresponse= httpClient.execute(request, httpContext);
        else
            httpresponse= httpClient.execute(request);
        if (httpresponse.getStatusLine().getStatusCode() == 302) {
            EntityUtils.consumeQuietly(httpresponse.getEntity());
            return get(httpresponse.getFirstHeader("Location").getValue());
        }
        BufferedReader rd = new BufferedReader(new InputStreamReader(httpresponse.getEntity().getContent()));
        StringBuffer result = new StringBuffer();
        String line1 = "";
        while ((line1 = rd.readLine()) != null) {
            result.append(line1);
        }
        return result.toString();
    }

// Added for API Sanity Test to get response code. GET Method Calls this with URL.

    public HashMap<String,String> processStatusCodeandresponse(String url) throws Exception {
        HttpGet request = new HttpGet(getFullUrl(url));
        HashMap<String, String> resultset = new HashMap<>();
        HttpResponse httpresponse;
        if(httpHost!=null) {
            httpClient = HttpClients.custom().setDefaultCredentialsProvider(credsProvider).build();
            httpresponse = httpClient.execute(httpHost, request, httpContext);
        }
        else
            httpresponse= httpClient.execute(request, httpContext);

        if (httpresponse.getStatusLine().getStatusCode() == 302) {
            EntityUtils.consumeQuietly(httpresponse.getEntity());
            resultset.put("responseBody",get(httpresponse.getFirstHeader("Location").getValue()));
        }
        BufferedReader rd = new BufferedReader(new InputStreamReader(httpresponse.getEntity().getContent()));
        StringBuffer result = new StringBuffer();
        String line1 = "";
        while ((line1 = rd.readLine()) != null) {
            result.append(line1);
        }

            resultset.put("responseBody",result.toString());

        resultset.put("responsecode",String.valueOf(httpresponse.getStatusLine().getStatusCode()));
        return  resultset;

    }

// Added for API Sanity test of Analyst application - POST & PATCH Methods
public HashMap<String,String> postandgetfullresult(String url, String json, HashMap<String, String> headers) throws Exception {
    List<NameValuePair> api_params = new ArrayList<>();
    HttpPost httpPost = new HttpPost(BaseURL + url);
    StringEntity jsonData = new StringEntity(json);
    httpPost.setEntity(jsonData);
    for (String key : headers.keySet()) {
        httpPost.addHeader(key, headers.get(key));
    }
     return  processStatusCodeandresponse(httpPost);
}

    // Added for API Sanity test of Analyst application - POST Method
    public HashMap<String,String> patchandgetfullresult(String url, String json, HashMap<String, String> headers) throws Exception {
        List<NameValuePair> api_params = new ArrayList<>();
        HttpPatch httpPatch = new HttpPatch(BaseURL + url);
//        System.out.println("URL:"+BaseURL+url);
        StringEntity jsonData = new StringEntity(json);
        httpPatch.setEntity(jsonData);
        for (String key : headers.keySet()) {
            httpPatch.addHeader(key, headers.get(key));
        }
        return  processStatusCodeandresponse(httpPatch);
    }

    public HashMap<String,String> processStatusCodeandresponse(HttpUriRequest request) throws Exception {
        HttpResponse httpresponse;
        HashMap<String, String> resultset = new HashMap<>();

        if(httpHost!=null) {
            httpClient = HttpClients.custom().setDefaultCredentialsProvider(credsProvider).build();
            httpresponse = httpClient.execute(httpHost, request, httpContext);
        }
        else
            httpresponse= httpClient.execute(request, httpContext);
        if (httpresponse.getStatusLine().getStatusCode() == 302) {
            EntityUtils.consumeQuietly(httpresponse.getEntity());
            resultset.put("responseBody",get(httpresponse.getFirstHeader("Location").getValue()));
        }
        BufferedReader rd = new BufferedReader(new InputStreamReader(httpresponse.getEntity().getContent()));
        StringBuffer result = new StringBuffer();
        String line1 = "";
        while ((line1 = rd.readLine()) != null) {
            result.append(line1);
        }

        resultset.put("responseBody",result.toString());
        resultset.put("responsecode",String.valueOf(httpresponse.getStatusLine().getStatusCode()));
        return  resultset;
    }
}

