package com.rpxcorp.testcore.util;



import java.io.BufferedReader;
import java.io.InputStreamReader;

public class BashBase {
        String bashPath = ConfigUtil.config().getProperty("BASH_PATH");

        protected String executeBash(String command) throws Exception {
            return executeCommand(bashPath,"-c",command);
        }
        protected String executeCmd(String command) throws Exception {
            return executeCommand("cmd.exe","-c",command);
        }

        private String executeCommand(String... command) throws Exception {
            String cmdStr="";
            for(String cmd: command){
                cmdStr=cmdStr+cmd;
            }
            System.out.println("Executing command \n" + cmdStr);
            StringBuffer output = new StringBuffer();
            StringBuffer error = new StringBuffer();
            Process p;
            try {
                p = Runtime.getRuntime().exec(command, new String[] { "PGPASSWORD=postgres" });
                p.waitFor();
                BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line = "";
                while ((line = reader.readLine()) != null) {
                    output.append(line + "\n");
                }
                BufferedReader errorReader = new BufferedReader(new InputStreamReader(p.getErrorStream()));
                while ((line = errorReader.readLine()) != null) {
                    error.append(line + "\n");
                }
            } catch (Exception e) {
                e.printStackTrace();
                throw e;
            }
            if (error.length() > 0) {
                throw new Exception("Command Failed with following error: \n" + error.toString());
            }
            System.out.println(output.toString());
            return output.toString();

        }
}
