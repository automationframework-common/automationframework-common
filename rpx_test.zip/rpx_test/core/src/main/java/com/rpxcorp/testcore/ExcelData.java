package com.rpxcorp.testcore;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;

@Target({METHOD, TYPE, CONSTRUCTOR})
@Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
public @interface ExcelData {
    public String fileName();
    public String columns();
    public String sheet() default "1";
    public int startRow() default 1;
}