package com.rpxcorp.testcore.page;

import com.rpxcorp.testcore.element.StaticElement;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.File;
import java.io.IOException;

public class StaticPage {
    Document doc;
    public void load(String html) throws IOException {
        this.doc=Jsoup.parse(new File("C:\\Users\\navarasum\\Desktop\\daily lit.txt"), null);
    }

    protected StaticElement $(String selector){
       return new StaticElement(this,selector);
    }

    public Document getDoc(){
      return  this.doc;
    }

}
