package com.rpxcorp.testcore;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;

@Target({METHOD, TYPE, CONSTRUCTOR})
@Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
public @interface Authenticate {
    public String role();
}