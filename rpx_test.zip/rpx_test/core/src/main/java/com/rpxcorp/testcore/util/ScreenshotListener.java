package com.rpxcorp.testcore.util;

import com.rpxcorp.testcore.UITest;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.internal.IResultListener2;

public class ScreenshotListener implements IResultListener2 {
    @Override
    public void onConfigurationFailure(ITestResult testResult) {
        Object currentClass = testResult.getInstance();
        if(currentClass !=null && currentClass instanceof UITest && testResult.getMethod().isBeforeClassConfiguration()){
            ((UITest) currentClass).reportScreenshot(testResult);
        }
    }

    @Override
    public void onTestFailure(ITestResult testResult){
        Object currentClass = testResult.getInstance();
        if(currentClass !=null && currentClass instanceof UITest) {
            ((UITest) currentClass).reportScreenshot(testResult);
        }
    }

    @Override
    public void onTestStart(ITestResult result) {

    }
    @Override
    public void onTestSuccess(ITestResult result) {

    }
    @Override
    public void onTestSkipped(ITestResult result) {

    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

    }

    @Override
    public void onStart(ITestContext context) {

    }

    @Override
    public void onFinish(ITestContext context) {

    }

    @Override
    public void beforeConfiguration(ITestResult tr) {

    }

    @Override
    public void onConfigurationSuccess(ITestResult itr) {

    }

    @Override
    public void onConfigurationSkip(ITestResult itr) {

    }
}
