package com.rpxcorp.testcore.util;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.Option;
import com.jayway.jsonpath.spi.json.GsonJsonProvider;
import com.jayway.jsonpath.spi.json.JsonProvider;
import com.jayway.jsonpath.spi.mapper.GsonMappingProvider;
import com.jayway.jsonpath.spi.mapper.MappingProvider;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.EnumSet;
import java.util.Properties;
import java.util.Set;

/**
 * 
 * @author navarasu ConfigurationUtil is a Singleton Class where all
 *         configuration properties and object are declared
 * 
 */
public class ConfigUtil {
    private static final ConfigUtil INSTANCE = new ConfigUtil();
    private final Properties CONFIG;

    private ConfigUtil() {
        CONFIG = System.getProperties();
        System.out.println("Environment:"+CONFIG.getProperty("env"));
        /* Adding SYSTEM PROPERTIES to configuration */

        /* Adding ADDITIONAL CONFIGURAITON to support non-gradle executions */
        if (CONFIG.get("projectDir") == null) { // this is custom system
                                                // property configured in
                                                // build.gradle
            String userDir= (String) CONFIG.get("user.dir");
            if(userDir.contains(".idea\\modules\\"))
                userDir=userDir.replace(".idea\\modules\\","");
            CONFIG.put("projectDir", userDir);
            CONFIG.put("mainResourcesDir", userDir + "/src/main/resources");
            CONFIG.put("testResourcesDir", userDir + "/src/test/resources");
            CONFIG.put("buildDir", userDir+ "/build");
            CONFIG.put("reportsDir", userDir + "/build/reports/");
            CONFIG.put("BROWSER", "chrome");//chrome
//            System.setProperty("screenshot","true");
            try {
                File driverFolder = new File(CONFIG.get("buildDir") + "/driver");
                File reportFolder = new File(CONFIG.get("buildDir") + "/reports");
                if(driverFolder.exists())
                    FileUtils.forceDelete(driverFolder);
                if(reportFolder.exists())
                    FileUtils.forceDelete(reportFolder);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        CONFIG.put("testFileDir",CONFIG.get("testResourcesDir")+"/test_data/files");
        if ((new File("C:\\Program Files (x86)\\Git\\bin\\bash.exe")).exists()){
            CONFIG.put("BASH_PATH","C:\\Program Files (x86)\\Git\\bin\\bash.exe");
        }else {
            CONFIG.put("BASH_PATH","C:\\Program Files\\Git\\bin\\bash.exe");
        }

        CONFIG.putAll(ConfigLoader.loadProp(CONFIG.get("testResourcesDir") + "/environment/default.properties"));
        if (CONFIG.get("ENV") == null || CONFIG.getProperty("ENV").isEmpty()) {
            CONFIG.put("ENV", CONFIG.get("DEFAULT_ENV"));
        }
        CONFIG.putAll(ConfigLoader.loadProp(CONFIG.get("testResourcesDir")
                + "/environment/" + CONFIG.getProperty("ENV").toLowerCase() + ".properties"));
        /* Adding OTHER CONFIGURAITON for UI Test */
        if (CONFIG.get("custom_URL") != null && !CONFIG.getProperty("custom_URL").isEmpty()) {
            CONFIG.put("BASE_URL", CONFIG.get("custom_URL"));
        }

        CONFIG.put("browserBinary", CONFIG.get("testResourcesDir") + "/drivers");
        Configuration.setDefaults(new Configuration.Defaults() {
            private final JsonProvider jsonProvider = new GsonJsonProvider();
            private final MappingProvider mappingProvider = new GsonMappingProvider();

            @Override
            public JsonProvider jsonProvider() {
                return jsonProvider;
            }

            @Override
            public MappingProvider mappingProvider() {
                return mappingProvider;
            }

            @Override
            public Set<Option> options() {
                return EnumSet.noneOf(Option.class);
            }
        });
    }

    public static ConfigUtil instance() {
        return INSTANCE;
    }

    public static Properties config() {
        return INSTANCE.CONFIG;
    }

}
