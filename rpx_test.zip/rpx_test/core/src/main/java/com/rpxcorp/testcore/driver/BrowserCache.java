package com.rpxcorp.testcore.driver;

import com.rpxcorp.testcore.util.ConfigUtil;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.UnreachableBrowserException;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;

public class BrowserCache {
	private static ThreadLocal<Browser> BROWSERCACHE = new ThreadLocal<Browser>();

	protected Browser getBrowser() {
		Browser cachedBrowser = BROWSERCACHE.get();
		if (cachedBrowser == null) {
			cachedBrowser = new Browser(ConfigUtil.config());
			setBrowser(cachedBrowser);
		}
		return cachedBrowser;
	}
	protected boolean isBrowserExists() {
		Browser cachedBrowser = BROWSERCACHE.get();
		return cachedBrowser != null;
	}
	public void setBrowser(Browser browser) {
		BROWSERCACHE.set(browser);
		configureBrowserAutoQuit();
	}

    protected WebDriver getDriver() {
		return getBrowser().getDriver();
	}
	protected String getAuth() {
		return getBrowser().getAuth();
	}
	protected void setAuth(String auth) {
		getBrowser().setAuth(auth);
	}
	protected WebDriverWait getWait() {
		return getBrowser().getWait();
	}
	protected WebDriverWait getWait(long timeout){
		return new WebDriverWait(getDriver(), timeout);
	}

	protected String getConfig(String configName) {
		return getBrowser().getConfig().get(configName).toString();
	}

	protected static String getSysConfig(String configName) {
		return System.getProperty(configName);
	}

	protected Browser clearBrowserCache() {
		Browser cachedBrowser = BROWSERCACHE.get();
		BROWSERCACHE.set(null);
		return cachedBrowser;
	}

	protected Browser clearCacheAndQuit() {
		Browser cachedBrowser = clearBrowserCache();
		try {
			cachedBrowser.getDriver().manage().deleteAllCookies();
			cachedBrowser.getDriver().quit();
		}catch (UnreachableBrowserException e) {
			e.printStackTrace();
		}finally {
			File cachedFolder = new File(ConfigUtil.config().getProperty("buildDir") + "/driver/" + System.identityHashCode(Thread.currentThread()));
			try {
				FileUtils.forceDelete(cachedFolder);
			} catch (IOException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		return cachedBrowser;
	}

	protected Browser quitBrowser() {
		Browser cachedBrowser = clearBrowserCache();
		cachedBrowser.getDriver().quit();
		return cachedBrowser;
	}
    public Boolean waitForDOM() {
		try {
			return getWait().until((ExpectedCondition<Boolean>) webDriver ->
						((JavascriptExecutor) webDriver).executeScript("return document.readyState === 'complete'").equals(true)); //&& $.active === 0
		} catch (WebDriverException e) {
			if (e.getMessage().contains("$ is not defined")) {
				System.out.println("handled");
				return null;
			} else {
				throw e;
			}
		}
	}

	public boolean waitForRequestInit() {
		try {
			getWait(1).until((ExpectedCondition<Boolean>) webDriver ->
					((JavascriptExecutor) webDriver).executeScript("return $.active > 0").equals(true));
		}catch (TimeoutException e){

		}
		return true;
	}

	protected Object executeJs(String javaScript){
		return ((JavascriptExecutor) getDriver())
				.executeScript(javaScript);
	}
    private void configureBrowserAutoQuit() {
        new BrowserAutoQuit(getDriver()).start();
    }
}

class BrowserAutoQuit extends Thread {
    private final WebDriver driver;
    private final Thread thread;
    public BrowserAutoQuit(WebDriver driver){
        this.thread=Thread.currentThread();
        this.driver=driver;
    }
    public void run() {
        try {
            this.thread.join();
            driver.quit();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}