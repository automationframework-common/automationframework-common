package com.rpxcorp.testcore.util;

import com.google.gson.*;

import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.*;
import java.util.*;
import java.util.Map.Entry;

public class SQLProcessor {
    private static Gson gson = new Gson();
    HashMap<String, JsonObject> queriesCache = new HashMap<String, JsonObject>();
    private static ThreadLocal<SQLProcessor> DBPROCESSORCACHE = new ThreadLocal<SQLProcessor>();

    public static SQLProcessor getInstance() {
        SQLProcessor cachedDriver = DBPROCESSORCACHE.get();
        if (cachedDriver == null) {
            cachedDriver = new SQLProcessor();
        }
        return cachedDriver;
    }

    public ResultSet getResultData(String queryKey) throws Exception {
        return getResultDataFromQuery(getQuery(queryKey), null);
    }

    public ResultSet getResultData(String queryKey, HashMap<String, String> params) throws Exception {
        return getResultDataFromQuery(getQuery(queryKey), params);        
    }
    public JsonElement aliasToJson(ResultSet resultSet) throws Exception {
        List<Map<String,Object>> data=new ArrayList<>();
        String[][] aliases = getColumnNames(resultSet);

        while (resultSet.next()) {

            Map result = new LinkedHashMap();

            for (int i = 0; i < aliases.length; i++) {

                String alias = aliases[i][0];
                Object obj;
//                System.out.println("aliased"+aliases[i][1]);

                if(aliases[i][1].equals("4"))
                    obj = resultSet.getInt(i+1);
                else
                    obj = resultSet.getString(i+1);
                if (alias.contains(".")) {
                    String[] sp = alias.split("\\.");
                    LinkedHashMap value = addorGetalias(result, sp[0]);
                    for (int j = 1; j < sp.length - 1; j++) {
                        value = addorGetalias((LinkedHashMap) value.get(sp[j - 1]), sp[j]);
                    }

                    ((LinkedHashMap) value.get(sp[sp.length - 2])).put(sp[sp.length - 1], obj);
                } else {
                    result.put(alias, obj);
                }
//                data.add(result);
            }
            data.add(result);
        }
        return gson.toJsonTree(groupIntoCollections(data));
    }

    private static LinkedHashMap addorGetalias(Map result, String key) {

        if (!result.containsKey(key)) {
            result.put(key, new LinkedHashMap());
        }
        return (LinkedHashMap) result;
    }

    private String[][] getColumnNames(ResultSet resultSet) throws SQLException {
        ResultSetMetaData metaData = resultSet.getMetaData();
        int columnCount=metaData.getColumnCount();
        String[][] columns=new String[columnCount][2];
        for (int i = 0; i < columnCount; i++ ) {
            columns[i][0]=metaData.getColumnName(i+1);
            columns[i][1]=Integer.toString(metaData.getColumnType(i+1));
        }
        return  columns;
    }
    private List<Map<String, Object>> groupIntoCollections(List<Map<String, Object>> datas) {

        List<Map<String, Object>> groups = new ArrayList<Map<String, Object>>();

        for(Map<String, Object> data: datas) {

            String id = id(data);
            Optional<Map<String, Object>> optionalParent = getEqualsObject(groups, id);
            Map<String, Object> parent = optionalParent.isPresent() ? optionalParent.get() : null;
            if( parent == null ) {
                parent = new LinkedHashMap<String, Object>();
                groups.add(parent);
            }
            group(parent, data);
        }
        return groups;
    }

    @SuppressWarnings("unchecked")
    private void group(Map<String, Object> parent, Map<String, Object> data) {

        for(Entry<String, Object> entries : data.entrySet()) {
            String key = entries.getKey();
            Object value = entries.getValue();
            if( value instanceof Map ) {

                Map<String, Object> childData = (Map<String, Object>) value;
                Map<String, Object> child = null;

                if( key.endsWith("[]") ) {

                    key = key.substring(0, key.length() - 2);
                    List<Map<String, Object>> childs = (List<Map<String, Object>>) parent.get(key);
                    if( childs == null ) {
                        childs = new ArrayList<Map<String, Object>>();
                        parent.put(key, childs);
                    }
                    String childId = id(childData);

                    Optional<Map<String, Object>> optionalChild = getEqualsObject(childs, childId);
                    child = optionalChild.isPresent() ? optionalChild.get() : null;
                    if( child == null ) {
                        child = new LinkedHashMap<String, Object>();
                        childs.add(child);
                    }
                } else {
                    child = (Map<String, Object>) parent.get(key);
                    if( child == null ) {
                        child = new LinkedHashMap<String, Object>();
                        parent.put(key, child);
                    }
                }
                group(child, childData);
            } else {
                parent.put(key, value);
            }
        }
    }

    private Optional<Map<String, Object>> getEqualsObject(List<Map<String, Object>> list, String id) {

        return id == null ? Optional.empty() :
                list.stream().filter(value -> {
                    String compId = id(value);
                    return compId != null && compId.equals(id);
                }).findFirst();
    }

    private String id(Map<String, Object> data) {

        Object id = data.containsKey("_id") ? data.get("_id") : data.get("claim_number");
        return id == null ? null : id.toString();

//        Object id = data.containsKey("_claim_number") ? data.get("_claim_number") : data.get("claim_number");
//        return id == null ? null : id.toString();
    }
    public ResultSet getResultDataFromQuery(String queryString, HashMap<String, String> params) throws Exception {
        if (params != null) {
            for (String key : params.keySet()) {            	
                queryString = queryString.replaceAll("\\?" + key + "\\?", params.get(key));	
            }            
        }   
        return processQuery(queryString);        
    }
    
    public int getResultCountFromQuery(String queryString, HashMap<String, String> params) throws Exception {

        System.out.println(queryString);
        return getResultCount(getResultDataFromQuery(queryString,params));
    }
    public String getSingleValue(String queryKey, String columnName) throws Exception {
        return getSingleValue(queryKey, null, columnName);
    }

    public String[] getListValue(String queryKey, HashMap<String, String> params, String columnName) throws Exception {
        ResultSet resultSet = getResultData(queryKey, params);
        int size = getResultCount(resultSet);
        String[] listValue = new String[size];
        int i=0;
        resultSet.beforeFirst();
        while (resultSet.next()) {
            listValue[i]=resultSet.getString(columnName);
            i++;
        }
        return listValue;
    }

    public String[] getListValue(String queryKey, String columnName) throws Exception {
        HashMap<String, String> params = null;
        return getListValue(queryKey,params,columnName);
    }


    public List<String> getListValue(String queryKey, String param, String columnName) throws Exception {
    	HashMap<String, String> params = new HashMap<>();
    	params.put("id", param);
    	String[] valueArray = getListValue(queryKey, params, columnName);
    	List<String> valueList = new ArrayList<>(Arrays.asList(valueArray));
    	return valueList;
    }    
    
    public String getSingleValue(String queryKey, HashMap<String, String> params, String columnName) throws Exception {
        ResultSet resultSet = getResultData(queryKey, params);
        return  getSingleValue(resultSet,columnName);
    }
    public String getSingleValue(ResultSet resultSet, int index) throws Exception {
        String value = "";
        resultSet.beforeFirst();
        if (resultSet.next()) {
            value = resultSet.getString(index);
        }
        return value;
    }
    public ArrayList<String> getListValue(ResultSet resultSet, int index) throws Exception {
        ArrayList<String> listValue = new ArrayList<>();
        int i=0;
        resultSet.beforeFirst();
        while (resultSet.next()) {
            listValue.add(i,resultSet.getString(index));
            i++;
        }
        return listValue;
    }
    public String getSingleValue(ResultSet resultSet, String columnName) throws Exception {
        String value = "";
        resultSet.beforeFirst();
        if (resultSet.next()) {
            value = resultSet.getString(columnName);
        }
        return value;
    }

    public ResultSet getResultData(String queryKey, String id) throws Exception {
        String query = getQuery(queryKey);
        query = query.replaceAll("\\?id\\?", id);   
        return processQuery(query);
    }
    
    public String getSinglResultValue(String queryKey, String id) throws Exception{
    	  ResultSet rs =  getResultData(queryKey,id);
    	  String value = "";
    	  rs.beforeFirst();
    	  if(rs.next()){
    		  value = rs.getString(1);
    	  }
        return value;
    }

    public ResultSet getResultData(String queryKey, List<String> ids) throws Exception {
        String query = getQuery(queryKey);
        String s = "'" + ids.toString().replace("[", "").replace("]", "").replace(" ", "").replace(",", "','") + "'";
        query = query.replaceAll("\\?List\\?", s);
        return processQuery(query);
    }
    
    public ResultSet getResultData(String queryKey, List<String> ids, String dataID) throws Exception{
    	String query = getQuery(queryKey);
    	String s = "'" + ids.toString().replace("[", "").replace("]", "").replace(" ", "").replace(",", "','") + "'";
    	query = query.replaceAll("\\?List\\?", s).replaceAll("\\?id\\?", dataID);
    	return processQuery(query);
    }

    public ResultSet getResultData(String[] queryKeys) throws Exception {
        String query = "";
        for (int i = 0; i < queryKeys.length; i++) {
            query += getQuery(queryKeys[i]);
            if ((i + 1) < queryKeys.length)
                query += " INTERSECT ";

        }
        return processQuery(query);
    }
    
    public boolean getBoolean(String queryKey, String id) throws Exception{    	
    	if(getSinglResultValue(queryKey, id).equals("t"))    
    		return true;
    	return false;
    }

    private String joinQueriesFromArray(String[] queryKeys, String joinTerm)
            throws JsonIOException, JsonSyntaxException, FileNotFoundException {
        String query = "";
        if (queryKeys[0].contains("COUNT")) {
            for (int i = 0; i < queryKeys.length; i++) {
                query += getQuery(queryKeys[i]);
                if ((i + 1) < queryKeys.length)
                    query += " " + joinTerm + " ";
            }
            query = "select count(*) from (" + query + ") as t";
        }

        else {
            for (int i = 0; i < queryKeys.length; i++) {
                query += getQuery(queryKeys[i]);
                if ((i + 1) < queryKeys.length)
                    query += " " + joinTerm + " ";
            }
        }
        return query;
    }

    public ResultSet getResultData(String[] queryKeys, List<String> ids) throws Exception {
        String query = joinQueriesFromArray(queryKeys, "INTERSECT");
        String s = "'" + ids.toString().replace("[", "").replace("]", "").replace(" ", "").replace(",", "','") + "'";
        query = query.replaceAll("\\?List\\?", s);
        return processQuery(query);
    }

    public ResultSet getResultData(String[] queryKeys, Map<String, String> test_data) throws Exception {
        String query = joinQueriesFromArray(queryKeys, "INTERSECT");
        for (String key : test_data.keySet()) {
            query = query.replaceAll("\\?" + key + "\\?", test_data.get(key));
        }
        return processQuery(query);
    }

    public ResultSet getResultData(String[] queryKeys, List<String> ids, Map<String, String> test_data)
            throws Exception {
        String query = joinQueriesFromArray(queryKeys, "INTERSECT");
        String s = "'" + ids.toString().replace("[", "").replace("]", "").replace(" ", "").replace(",", "','") + "'";
        query = query.replaceAll("\\?List\\?", s);
        for (String key : test_data.keySet()) {
            query = query.replaceAll("\\?" + key + "\\?", test_data.get(key));
        }
        return processQuery(query);
    }

    public int getResultCount(String queryKey,HashMap<String,String> params) throws Exception {
        return getResultCount(getResultData(queryKey,params));
    }
    public int getResultCount(String queryKey) throws Exception {
        return getResultCount(getResultData(queryKey));
    }

    public int getResultCount(String queryKey, String id) throws Exception {
        return getResultCount(getResultData(queryKey, id));
    }

    public int getResultCount(ResultSet rs) throws Exception {
        rs.last();
        return rs.getRow();
    }

    public int getResultsCount(String query,Connection dbConn) throws Exception {
        return getResultCount(processQuery(query,dbConn));
    }

    public ResultSet getResultDataFromQuery(String queryString, HashMap<String, String> params,Connection dbConn) throws Exception {
        if (params != null) {
            for (String key : params.keySet()) {
                queryString = queryString.replaceAll("\\?" + key + "\\?", params.get(key));
            }
        }
        return processQuery(queryString,dbConn);
    }

    public int processUpdate(String query,Connection dbConn) throws SQLException {
        int rs = -1;
        try {
            PreparedStatement pstmt = dbConn.prepareStatement(query,
                    ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = pstmt.executeUpdate();
        } catch (Exception e) {
            System.out.println("Failed to Execute query ...\n" + query);
            System.out.println("---------------------------");
            throw e;
        }
        return rs;
    }


    public int updateData(String queryKey,HashMap<String,String> params) throws Exception {
        String queryString=getQuery(queryKey);
        if (params != null) {
            for (String key : params.keySet()) {
                queryString = queryString.replaceAll("\\?" + key + "\\?", params.get(key));

            }
        }
       return processUpdate(queryString);
    }
    private ResultSet processQuery(String query) throws SQLException {
        ResultSet rs = null;
        try {
            PreparedStatement pstmt = DbConnection.getConnection().prepareStatement(query,
                    ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = pstmt.executeQuery();
            rs.beforeFirst();
        } catch (SQLException e) {
            System.out.println("Failed to Execute query ...\n" + query);
            System.out.println("---------------------------"+e.getMessage());
            throw e;
        }
        return rs;

    }
    public Connection initiateConn(HashMap<String,String> dbConfig) throws SQLException{
        Connection con=null;
        try{
            con=DbConnection.getConnection(dbConfig.get("host"),dbConfig.get("username"),dbConfig.get("password"),dbConfig.get("port"),true);
        }
        catch (Exception e){
            System.out.println("Failed to Connect ...\n" +e.getMessage());
        }
        return con;
    }
    public ResultSet processQuery(String query,Connection dbConn) throws SQLException {
        ResultSet rs = null;
        try {
            if(dbConn.isClosed()){
                dbConn=DbConnection.getConnection();
            }
            PreparedStatement pstmt = dbConn.prepareStatement(query,
                    ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = pstmt.executeQuery();
            rs.beforeFirst();
        } catch (SQLException e) {
            System.out.println("Failed to Execute query ...\n" + query);
            System.out.println("---------------------------"+e.getMessage());
            throw e;
        }
        return rs;

    }

    public int processUpdate(String query) throws SQLException {
        int rs = -1;
        try {
            PreparedStatement pstmt = DbConnection.getConnection().prepareStatement(query,
                    ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = pstmt.executeUpdate();
        } catch (Exception e) {
            System.out.println("Failed to Execute query ...\n" + query);
            System.out.println("---------------------------");
            throw e;
        }
        return rs;
    }

    public String getQuery(String queryKey) throws JsonIOException, JsonSyntaxException, FileNotFoundException {
        String[] queryKeys = queryKey.split("\\.");
        if (!queriesCache.containsKey(queryKeys[0])) {
            queriesCache.put(queryKeys[0], ConfigLoader
                    .loadJson(ConfigUtil.config().get("testResourcesDir") + "/data_queries/" + queryKeys[0] + ".json"));
        }
        return prepareQuery(queryKeys);
    }

    private String prepareQuery(String[] queryKeys) {
        JsonObject queryBase = queriesCache.get(queryKeys[0]).getAsJsonObject();
        JsonElement queryElement = queryBase.get(queryKeys[1]);
        String query = "";
        if (queryElement.isJsonObject()) {
            JsonObject queryObject = queryElement.getAsJsonObject();
            Iterator<Entry<String, JsonElement>> params = queryObject.get("params").getAsJsonObject().entrySet()
                    .iterator();
            query = queryBase.get(queryObject.get("query_base").getAsString()).getAsString();
            while (params.hasNext()) {
                Entry<String, JsonElement> value = params.next();
                query = query.replaceAll("\\?" + value.getKey() + "\\?", value.getValue().getAsString());
            }
        } else {
            query = queryElement.getAsString();
        }       
        return query;
    }

    public List<String> getTableAsList(String query, String id) throws Exception {
        ResultSet rs = getResultData(query, id);
        return getTableAsList(rs);
    }

    public List<String> getTableAsList(ResultSet rs) throws Exception {
        List<String> table = new ArrayList<>();

        while (rs.next()) {
            String row = "";
            int size = rs.getMetaData().getColumnCount();
            for (int i = 1; i < size + 1; i++) {
                row += rs.getString(i).replaceAll("  ", " ") + " ";
            }
            row = row.length() > 1 ? row.substring(0, row.length() - 1) : row;
            table.add(row);
        }
        return table;
    }
    
    public HashMap<String, Map<String, String>> getResultDataAsMultiMap(ResultSet rs, String keyColumn, String... valueColumn) throws SQLException {
    	HashMap<String, Map<String, String>> data = new HashMap<>();
    	while(rs.next()){
    		Map<String, String> values = new HashMap<>();
    		for(int columnCount = 0; columnCount < valueColumn.length; columnCount++) {
    			String colValue;
    			try {
    				colValue = rs.getString(valueColumn[columnCount]).replaceAll("\\.$", "").replace(".0", "");
    			}
    			catch(NullPointerException npe){
    				colValue = "0";
    			}
    			values.put(valueColumn[columnCount], colValue);
    		}
    		data.put(rs.getString(keyColumn), values);
    	}    	
    	return data;
    }
    
    public HashMap<String, String> getResultDataAsMap(ResultSet rs, String keyColumn, String... valueColumn) throws SQLException {

    	HashMap<String, String> data = new HashMap<>();
    	while(rs.next()){    		
    		for(int columnCount = 0; columnCount < valueColumn.length; columnCount++) {
    			String columnData = rs.getString(valueColumn[columnCount]);       			
    			String convertedColData = "";
    			try {
    				BigDecimal number = new BigDecimal(columnData.toString());			
    				convertedColData = number.stripTrailingZeros().toPlainString();
    			} catch (Exception e) {
    				convertedColData = columnData;
    			}							
    			data.put(rs.getString(keyColumn), columnData);
    		}    		
    	}    	
    	return data;
    }
}
