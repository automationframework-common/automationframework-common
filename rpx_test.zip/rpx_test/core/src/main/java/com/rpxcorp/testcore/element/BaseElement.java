package com.rpxcorp.testcore.element;

import com.rpxcorp.testcore.driver.BrowserCache;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;

import java.util.List;

public abstract class BaseElement extends BrowserCache implements WebElement {
    public abstract WebElement getElement();

    public abstract List<WebElement> getElements();

    @Override
    public <X> X getScreenshotAs(OutputType<X> arg0) throws WebDriverException {
        return getElement().getScreenshotAs(arg0);
    }

    @Override
    public void clear() {
        getElement().clear();
    }

    @Override
    public void click() {
        final WebDriverException[] exception = new WebDriverException[1];
        try{
        getWait(20).until(new ExpectedCondition<Boolean>() {
            @Override
            public Boolean apply(WebDriver driver) {
                try {
                    getElement().click();
                    return Boolean.TRUE;
                }catch (WebDriverException e){
                    exception[0] = e;
                    if(e.getMessage().contains("is not clickable") || e.getMessage().contains("not interactable")|| e.getMessage().contains("intercepted")) {
                        JavascriptExecutor executor = (JavascriptExecutor)getDriver();
                        executor.executeScript("arguments[0].click();", getElement());
                        System.out.println("handled not clickable element error");
                        return Boolean.TRUE;
                    }else{
                        throw e;
                    }
                }
            }
        });} catch(Exception e) {
            throw  exception[0];

        }

    }
    @Override
    public WebElement findElement(By locator) {
        return getElement().findElement(locator);
    }

    @Override
    public List<WebElement> findElements(By locator) {
        return getElement().findElements(locator);
    }

    @Override
    public String getAttribute(String attributeName) {
        return getElement().getAttribute(attributeName);
    }

    @Override
    public String getCssValue(String propertyName) {
        return getElement().getCssValue(propertyName);
    }

    @Override
    public Point getLocation() {
        return getElement().getLocation();
    }

    @Override
    public Dimension getSize() {
        return getElement().getSize();
    }

    @Override
    public String getTagName() {
        return getElement().getTagName();
    }

    @Override
    public String getText() {
        return getElement().getText();
    }

    @Override
    public boolean isDisplayed() {
        boolean status = false;
        if (isPresent()) {
            status = getElement().isDisplayed();
        }
        return status;
    }

    @Override
    public boolean isEnabled() {
        return getElement().isEnabled();
    }

    @Override
    public boolean isSelected() {
        return getElement().isSelected();
    }

    @Override
    public void sendKeys(CharSequence... chars) {
        if (chars.length > 0 && chars[0] != null) {
            getElement().clear();
            getElement().sendKeys(chars);
        }
    }

    @Override
    public void submit() {
        getElement().submit();
    }

    @Override
    public Rectangle getRect() {
        return getElement().getRect();
    }

    public boolean isPresent() {
        return getElements().size() > 0;
    }

}
