package com.rpxcorp.testcore.util;

import java.io.*;
import java.util.Properties;

import com.google.gson.*;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

public class ConfigLoader {
	public static Properties loadProp(String propertyPath) {
		Properties config = new Properties();
		InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(propertyPath);
			config.load(inputStream);
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return config;
	}
	public static DocumentContext loadJsonPath(String jsonFilePath) throws JsonIOException, JsonSyntaxException, IOException {
		return JsonPath.parse(new File(jsonFilePath));

	}
	public static JsonObject loadJson(String jsonFilePath) throws JsonIOException, JsonSyntaxException, FileNotFoundException {
		JsonParser parser = new JsonParser();
		JsonObject jsonObject;
		try {
			JsonElement jsonElement = parser.parse(new FileReader(jsonFilePath));
			jsonObject = jsonElement.getAsJsonObject();
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}
		return jsonObject;
	}

	public static JsonObject loadFlatJsonData(String inputData) throws JsonIOException, JsonSyntaxException{
		JsonParser parser = new JsonParser();
		JsonObject jsonObj = parser.parse(inputData).getAsJsonObject();
		return jsonObj;
	}
}
