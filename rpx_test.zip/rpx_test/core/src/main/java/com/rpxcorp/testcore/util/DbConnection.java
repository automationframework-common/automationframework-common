package com.rpxcorp.testcore.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

public class DbConnection {
    static final String db_password = (String) ConfigUtil.config().get("DB_PASS");
    static final String dbHostName = (String) ConfigUtil.config().getProperty("DB_HOST_NAME").trim().toLowerCase();
    static final String db_username = (String) ConfigUtil.config().getProperty("DB_USER_NAME");
    static final String db_port = (String) ConfigUtil.config().getProperty("DB_PORT");
    private static ThreadLocal<Connection> CONNECTION_CACHE = new ThreadLocal<>();
    private static ArrayList<Connection> connectionList = new ArrayList<Connection>();

    public static synchronized Connection getConnection(String host, String username, String password, String port,
                                                        boolean ssl) throws SQLException {

        String db_url=null;
        Connection connection=null;
        String schema="rpx";
        if(username.equalsIgnoreCase("ale_read")){
            schema="alexandria";
        }
        switch(port) {
            case "3306":
                db_url="jdbc:mysql://"+host+":"+port+"/newsdb1?&ssl=true";
                break;
            default:
                db_url = "jdbc:postgresql://" + host + ":" + port + "/"+schema;
                if (ssl && !username.equalsIgnoreCase("ale_read"))
                    db_url = db_url + "?&ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";
                break;
        }
        try {
            connection = DriverManager.getConnection(db_url, username, password);
            System.out.println("Connected to Db: "+dbHostName+" User:"+db_username );
        } catch (Exception e){
            e.printStackTrace();
            System.out.println("Db connection is not established");
        }

        return connection;
    }

    public static synchronized Connection getConnection() throws SQLException {

        Connection cachedConnection = CONNECTION_CACHE.get();
        if (cachedConnection == null || cachedConnection.isClosed()) {
            cachedConnection = getConnection(dbHostName, db_username, db_password, db_port, true);
            CONNECTION_CACHE.set(cachedConnection);
            connectionList.add(cachedConnection);
        }
        return cachedConnection;
    }
    public static void closeConnection() throws SQLException {
        Connection connection = CONNECTION_CACHE.get();
        if(connection!=null) {
            connection.close();
            CONNECTION_CACHE.set(null);
            connectionList.remove(connection);
        }
    }
    public static void closeAllConnection() throws SQLException {
        for (Connection connection : connectionList) {
            connection.close();
        }
    }
}
