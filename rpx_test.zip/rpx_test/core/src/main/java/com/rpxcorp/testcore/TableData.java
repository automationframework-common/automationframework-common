package com.rpxcorp.testcore;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.ArrayUtils;

public class TableData {
    private String[] header;
    private HashMap<String, String[]> data;

    public TableData(String[] header, HashMap<String, String[]> data) {
        this.header = header;
        this.data = data;
    }

    public TableData() {
        this.header = new String[0];
        this.data = new HashMap<String, String[]>();
    }

    public String[] getHeader() {
        return header;
    }

    public void setHeader(String[] header) {
        this.header = header;
    }

    public HashMap<String, String[]> getData() {
        return data;
    }
    public String[] lastrow() {
        return row(data.size()-1);
    }
    public String[] row(Object value) {
        return data.get(String.valueOf(value));
    }

    public void setData(HashMap<String, String[]> data) {
        this.data = data;
    }
    
    public void addAll(TableData data){
    	this.header = (String[])ArrayUtils.addAll(this.header, data.getHeader());
    	this.data.putAll(data.getData());
    }

    public int size() {
        return data.size();
    }
}
