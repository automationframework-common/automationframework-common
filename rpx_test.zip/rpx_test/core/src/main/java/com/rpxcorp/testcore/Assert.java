package com.rpxcorp.testcore;

import com.google.gson.Gson;
import com.google.gson.JsonElement;

import java.text.SimpleDateFormat;
import java.util.*;

public class Assert  {

    private static Gson gson = new Gson();
    public static void contains(List<String> actual, String expected)  {
        if(!actual.contains(expected))
            assertFailure(String.join(",", actual) + " doesn't contains "+expected);
    }
    public static void contains(String actual, String expected)  {
        if(!actual.contains(expected))
            assertFailure(actual + " doesn't contains "+expected);
    }
    public static void isValidDateFormat(String actual, String expected)  {
        boolean isValid = false;
        try {
            SimpleDateFormat dateformat = new SimpleDateFormat(expected);
            if(dateformat.format(dateformat.parse(actual)).equals(actual)){
                isValid=true;
            }
        } catch (Exception ex) {

        }
        isTrue(isValid,actual+ " is not in '"+expected+"' date format");
    }
    public static void isEquals(String[] actual, String[] expected)  {
        isEquals(new ArrayList<>(Arrays.asList(actual)), new ArrayList<>(Arrays.asList(expected)));
    }

    public static void isEquals(List<String> actual, String[] expected)  {
        isEquals(actual, new ArrayList<>(Arrays.asList(expected)));
    }
    public static void isEquals(String[] actual, List<String> expected) {
        isEquals(new ArrayList<>(Arrays.asList(actual)),expected);
    }
    public static void isEquals(Set<String> actual, Set<String> expected)  {
        isEquals(new ArrayList<>(actual), new ArrayList<>(expected));
    }
    public static void isEquals(List<String> actual, List<String> expected)  {
        StringBuffer message = new StringBuffer();

        List<String> temp = new ArrayList<>();
        temp.addAll(actual);
        actual.removeAll(expected);
        expected.removeAll(temp);

        for (String row : actual)
            message.append("Actual :[" + row + "] Expected: [] for " + row.split("\t")[0] + "\n");

        for (String row : expected)
            message.append("Actual :[] Expected: [" + row + "] for " + row.split("\t")[0] + "\n");

        assertFailure(message.toString());
    }
    //commented as its deprecated method now
    /*public static void isEquals(JsonElement actual, JsonElement expected){
   org.junit.Assert.assertThat(actual, JsonMatchers.jsonEquals(expected).when(Option.IGNORING_ARRAY_ORDER));
//        org.junit.Assert.assertThat(actual, JsonMatchers.jsonEquals(expected));
    }*/
    public static void isEquals(JsonElement actual, Object expected){
        isEquals(formatData(actual),expected);
    }
    private static Object formatData(JsonElement jdata){
        if(jdata.isJsonArray()){
            return gson.fromJson(jdata, Object[].class);
        }else if(jdata.isJsonObject()){
            return (Map<String,Object>) gson.fromJson(jdata,HashMap.class);
        }else if(jdata.isJsonPrimitive()) {
            return jdata.getAsString();
        }
        return null;
    }
    public static void isEquals(Object actual,Object expected){
        String message=null;
        if (!actual.equals(expected)) {
            if(message==null)
                message = "Actual :[" + actual + "] Expected : [" + expected + "]";
        }
        assertFailure(message);
    }
    static public void isTrue(boolean isTrue, String message) {
        if (isTrue == false)
            assertFailure(message);
    }

    static public void isFalse(boolean isFalse, String message) {
        if (isFalse == true)
            assertFailure(message);

    }
    static private void assertFailure(String message) {
        if (!(message == null || message.equals(""))) {
            String normalizedMessage = message;
            try {
                normalizedMessage = new String(message.toString().getBytes("ISO-8859-1"), "UTF-8");
            } catch (Exception e) {
                e.printStackTrace();
            }
            throw new AssertionError(normalizedMessage);
        }
    }
}





