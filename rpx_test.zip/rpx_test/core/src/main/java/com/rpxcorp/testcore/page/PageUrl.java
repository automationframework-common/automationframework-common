package com.rpxcorp.testcore.page;

import com.rpxcorp.testcore.driver.BrowserCache;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.utils.URIBuilder;

import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

public class PageUrl extends BrowserCache {
    String url;
    Map<String, String> urlParams = new HashMap<String, String>();

    public PageUrl(String url) {
        super();
        this.url = url;
    }

    public PageUrl(String url, Map<String, String> urlParams) {
        super();
        this.url = url;
        this.urlParams = urlParams;
    }

    public void param(String key, String value) {
        this.urlParams.put(key, value);
    }

    public String build(Object urlData) throws Exception {
        URIBuilder uri = new URIBuilder(getConfig("BASE_URL"));
        String appendUrl = "";
        if (!url.isEmpty()) {
            if (urlData != null && urlData instanceof Map<?, ?>) {
                Map<String, String> urlParams = (Map<String, String>) ((HashMap<String, String>) urlData).clone();
                if (urlParams.containsKey("defaultUrl")) {
                    appendUrl = urlParams.remove("defaultUrl");
                }
                setPathVariable(uri, urlParams);
                setRequestParams(uri, urlParams);
            } else {
                setPathVariable(uri, urlData);
            }
        }
        String urlString = URLDecoder.decode(uri.toString());
        if(!appendUrl.isEmpty()){
            if(appendUrl.contains("=")){
                if(!urlString.contains("?")) {
                    urlString = urlString + "?";
                }else{
                    urlString = urlString + "&";
                }
            }
            urlString=urlString +appendUrl;
        }
        return urlString;
    }

    private void setPathVariable(URIBuilder uri, Object urlData) {
        String new_url = url;
        if (urlData != null) {
            String pathVariables[] = StringUtils.substringsBetween(url, "{", "}");
            new_url = new_url.replace("{" + pathVariables[0] + "}", urlData.toString());
        }
        parsePartial(uri, new_url);
    }

    private void setPathVariable(URIBuilder uri, Map<String, String> urlData) throws Exception {
        String new_url = url;
        String pathVariables[] = StringUtils.substringsBetween(url, "{", "}");
        if (pathVariables != null) {
            for (String pathVariable : pathVariables) {
                if (!urlData.containsKey(pathVariable))
                    throw new Exception("Path variable " + pathVariable + " is not found in param data");
                new_url = new_url.replace("{" + pathVariable + "}", urlData.remove(pathVariable));
            }
        }
        parsePartial(uri, new_url);
    }

    private void parsePartial(URIBuilder uri, String url) {
        if (url.contains("?")) {
            String[] urls = url.split("\\?", 2);
            url = urls[0];
            for (String urlParam : urls[1].split("&")) {
                if (urlParam.contains("=")) {
                    String[] params = urlParam.split("=", 2);
                    uri.setParameter(params[0], params[1]);
                } else {
                    uri.setParameter(urlParam, "");
                }
            }
        }
        String fragment = url.replaceFirst(".*#(((?!\\/).)*).*", "$1");
        if (!fragment.isEmpty() && !fragment.equals(url)) {
            url = url.replace("#"+fragment,"");
            uri.setFragment(fragment);
        }
        uri.setPath(url);
    }

    private void setRequestParams(URIBuilder uri, Map<String, String> urlData) throws Exception {
        for (String key : urlData.keySet()) {
            String value = urlData.get(key);
            String paramKey = urlParams.get(key);
            if(paramKey!=null) {
//                throw new Exception("No param found for data " + key);
                if (!"".equals(value)) {
                    if (value.equals("${Empty}")) {
                        uri.addParameter(paramKey, "");
                    } else {
                        String[] values = value.split(";");
                        for (String dataValue : values) {
                            uri.addParameter(paramKey, dataValue);
                        }
                    }
                }
            }
        }
    }
}
