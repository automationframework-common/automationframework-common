package com.rpxcorp.testcore.driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Properties;

public class Browser {
	WebDriver driver;
	WebDriverWait wait;
	Properties config;
	String auth;
	
	public Browser(Properties config) {
		super();
		this.config = config;
		this.driver=DriverFactory.getDriver();
		driver.manage().window().maximize();
		this.wait=new WebDriverWait(driver,Integer.parseInt(config.getProperty("DEFAULT_TIME_OUT","120")));
	}
	
	public WebDriver getDriver() {
		return driver;
	}
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	public WebDriverWait getWait() {
		return wait;
	}
	public void setWait(WebDriverWait wait) {
		this.wait = wait;
	}
	public Properties getConfig() {
		return config;
	}
	public void setConfig(Properties config) {
		this.config = config;
	}

	public boolean isAuthenticated() {
		return auth==null;
	}
	public String getAuth() {
		return auth;
	}
	public void setAuth(String auth) {
		this.auth = auth;
	}
}
