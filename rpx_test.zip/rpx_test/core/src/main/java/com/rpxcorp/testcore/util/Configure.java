package com.rpxcorp.testcore.util;

import java.io.Serializable;

public interface Configure<T> extends Serializable {
     void apply(T object);
}
