package com.rpxcorp.testcore.util;

import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;

/*
 @Author: mprasanna_c
  Description: This util is used to connect to Redis (App Cache server) and do required actions.
 */

public class RedisUtil {
    RedissonClient client;
    public void RedisUtil(String hostname,String password,String port)    {
        Config config = new Config();
        config.useSingleServer().setAddress("redis://"+hostname+":"+port).setDatabase(1).setPassword(password);
        client = Redisson.create(config);
        System.out.println(client.getPatternTopic("cache:*_feature"));
    }

    public void deleteCache_ByPattern(String Pattern){
        client.getKeys().deleteByPattern(Pattern);
    }
    /*This menthod will shutdown reddison service not redis server*/
    public void stopReddisonServie(){
        if(!client.isShutdown()) client.shutdown();
    }
}
