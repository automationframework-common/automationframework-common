package com.rpxcorp.testcore.element;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class StaticContent extends Element {
    Map<String, String> contents = new HashMap<String, String>();

    public StaticContent(By locator) {
        super(locator);
    }

    public StaticContent(String selector) {
        super(selector);
    }

    public void content(String key, String value) {
        this.contents.put(key, value);
    }

    public Map<String, String> getData() {
        Map<String, String> data = new HashMap<String, String>();
        Document doc = Jsoup.parse(getInnerHtml());
        for (String key : contents.keySet()) {
            data.put(key, doc.select(contents.get(key)).text());
        }
        return data;
    }

    public String getData(String key) {
        Document doc = Jsoup.parse(getInnerHtml());
        return doc.select(contents.get(key)).text();
    }

    public int getIntData(String key) {
        return Integer.parseInt(getData(key).replaceAll("[\\D]", "").trim());
    } 
    
    public Element getElement(String key) {
		return $(contents.get(key));
    	
    }
}
