package com.rpxcorp.testcore;

public interface UIAuthenticator {
    public void login(String username, String password);
    public void logout();

}
