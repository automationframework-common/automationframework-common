package com.rpxcorp.testcore.driver;

import com.rpxcorp.testcore.util.HTTPUtil;
import com.rpxcorp.testcore.util.ConfigUtil;

public class APICache {
	private static ThreadLocal<HTTPUtil> APICACHE = new ThreadLocal<HTTPUtil>();
	protected static ThreadLocal<String> authenticatedUser = new ThreadLocal<String>();

	protected HTTPUtil getAPIInstance() {
		HTTPUtil cachedAPI = APICACHE.get();
		if (cachedAPI == null) {
			cachedAPI = new HTTPUtil(ConfigUtil.config().getProperty("BASE_URL"));
			APICACHE.set(cachedAPI);
		}
		return cachedAPI;
	}

	protected HTTPUtil clearCache() {
		HTTPUtil cachedAPI = APICACHE.get();
		APICACHE.set(null);
		authenticatedUser.set(null);
		return cachedAPI;
	}
	protected HTTPUtil getNewInstance() {
		return new HTTPUtil(ConfigUtil.config().getProperty("BASE_URL"));
	}
}
