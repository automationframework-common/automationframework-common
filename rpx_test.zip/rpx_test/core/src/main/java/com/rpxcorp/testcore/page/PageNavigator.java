package com.rpxcorp.testcore.page;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.rpxcorp.testcore.driver.Browser;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.google.common.collect.ImmutableSet;
import com.google.common.reflect.ClassPath;
import com.google.common.reflect.ClassPath.ClassInfo;
import com.rpxcorp.testcore.driver.BrowserCache;
import com.rpxcorp.testcore.element.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class PageNavigator extends BrowserCache {

	private final Logger LOGGER = LoggerFactory.getLogger(PageNavigator.class);
	public final static HashMap<String, String> pages= new HashMap<String,String>();
	protected BufferedImage newWindowImage;

	{
		if (pages.size() == 0) {
			final ClassLoader loader = Thread.currentThread().getContextClassLoader();
			ImmutableSet<ClassInfo> ds = null;
			try {
				ds = ClassPath.from(loader).getTopLevelClassesRecursive("com.rpxcorp.insight.page");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(ds.size());
			for (ClassInfo classInfo : ds) {
				pages.put(classInfo.getSimpleName(), classInfo.getName());
			}
		}
	};


	protected <T> T to(Page pageObject,boolean wait) {
		return to(pageObject, null, null,wait);
	}

	protected <T> T to(Page pageObject, Object urlData) {
		return to(pageObject, urlData,true);
	}
	protected <T> T to(Page pageObject,Object urlData,boolean wait) {
		return to(pageObject, urlData,null,wait);
	}
	protected <T> T to(Page pageObject) {
		return to(pageObject,null);
	}
	protected <T> T to(Page pageObject, Browser browser) {
		return to(pageObject, browser,true);
	}
	protected <T> T to(Page pageObject, Browser browser,boolean wait) {
		return to(pageObject, null, browser,wait);
	}
	protected <T> T to(Page pageObject,Object urlData, Browser browser,boolean wait) {
		LOGGER.trace("to  " + Thread.currentThread().getName());
		System.out.println("to  " + Thread.currentThread().getName());
//		T pageObject = getPageInstance(pageClass);
		Page page = (Page) pageObject;
		if (browser != null)
			page.setBrowser(browser);
		page.navigate(urlData,wait);
		if(wait)
			page.at();
		return (T) pageObject;
	}

	protected <T> T to(String className) {
		return to(className, true);
	}
	protected <T> T to(String className,boolean wait) {
		return to(className, null, wait);
	}
	protected <T> T to(String className, Map<String, String> urlData) {
		return to(className,urlData,true);
	}
	protected <T> T to(String className, Map<String, String> urlData,boolean wait) {
		return to(className, null, urlData,wait);
	}
	protected <T> T to(String className, Browser browser) {
		return to(className, browser, null,true);
	}
	protected <T> T to(String className, Browser browser, Map<String, String> urlData){
		return to(className, browser, urlData,true);
	}
	protected <T> T to(String className, Browser browser, Map<String, String> urlData,boolean wait) {
		return to((Page) getPageInstance(getPageClass(className)), urlData,browser,wait);
	}
	protected void toUrl(String url) {
		getDriver().get(url);
	}
	protected <T> T at(Page pageObject) {
		return at(pageObject, null);
	}


	protected <T> T at(Page pageObject,Browser browser) {
		if (browser != null)
			pageObject.setBrowser(browser);
		pageObject.at();
		return (T) pageObject;
	}
	protected <T> T at(Class<T> pageClass , Browser browser) {
		Page pageObject = getPageInstance(pageClass);
		return at(pageObject, browser);
	}
	protected <T> T at(Class<T> pageClass){
		return at(pageClass, null);
	}

	protected <T> T getPageInstance(Class<?> pageClass) {
		T pageObject = null;
		try {
			pageObject = (T) pageClass.newInstance();
		} catch (InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
		}
		return pageObject;
	}

	protected String getPageUrl(String className, Map<String, String> urlData) throws Exception {
		Page page = (Page) getPageInstance(getPageClass(className));
		return page.url.build(urlData);
	}

	protected String getPagePartialUrl(String className, Map<String, String> urlData) {
        try {
            return getPageUrl(className,urlData);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

	protected Class<?> getPageClass(String className) {
		Class<?> pageClass = null;
		if (pages.containsKey(className)){
			try {
				pageClass = Class.forName(pages.get(className));
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new Error(className+" not found in class loader");
			}
		} else {
			throw new Error(className+" not found in page list");
		}
		return pageClass;
	}

	protected void withNewWindow(Element element,Runnable object) {
		String parent = getDriver().getWindowHandle();
		element.click();
		String newWindow = waitForNewWindow(1);
		getDriver().switchTo().window(newWindow);
		try {
		object.run();
		} catch (Exception e) {
            newWindowImage = getScreenshotImage();
            throw e;
        } finally {
			getDriver().close();
			getDriver().switchTo().window(parent);
		}
	}

    protected BufferedImage getScreenshotImage() {
		Screenshot screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(getDriver());
		return screenshot.getImage();
	}
	protected void withRightClickNewWindow(Element element,Runnable object) throws Exception {
		String parent = getDriver().getWindowHandle();
		element.rightClickToOpenNewTab();
		String newWindow = waitForNewWindow(1);
		getDriver().switchTo().window(newWindow);
		try {
		object.run();
		} finally {
			getDriver().close();
			getDriver().switchTo().window(parent);
		}
	}

	protected String waitForNewWindow(int prevSize) {
		return getWait().until(new ExpectedCondition<String>() {
			@Override
			public String apply(WebDriver webDriver) {
				Set<String> windowHandles = getDriver().getWindowHandles();
					if (windowHandles.size() > prevSize) {
						return (String) windowHandles.toArray()[windowHandles.size() - 1];
					}
					System.out.println("waiting");
					throw new NoSuchWindowException("No new window found");
			}
		});
	}

	protected String waitForActiveWindow(int size) {
		return getWait(180).until(new ExpectedCondition<String>() {
			@Override
			public String apply(WebDriver webDriver) {
				Set<String> windowHandles = getDriver().getWindowHandles();
				if (windowHandles.size() == size) {
					return (String) windowHandles.toArray()[windowHandles.size() - 1];
				}
				throw new NoSuchWindowException("No new window found");
			}
		});
	}

	protected String getTitle() {
		return getDriver().getTitle();
	}

	protected void rightClickToOpenInNewTab(Element element,Runnable object) throws Exception {
            String parent = getDriver().getWindowHandle();
            Actions action=new Actions(getDriver());
            action.keyDown(Keys.CONTROL).keyDown(Keys.SHIFT).click(element.getElement()).keyUp(Keys.CONTROL).keyUp(Keys.SHIFT).build().perform();
            String newWindow = waitForNewWindow(1);
            getDriver().switchTo().window(newWindow);
            object.run();
            getDriver().close();
            getDriver().switchTo().window(parent);
        }

	protected String getPageSource() {
            return getDriver().getPageSource();
	}



}
