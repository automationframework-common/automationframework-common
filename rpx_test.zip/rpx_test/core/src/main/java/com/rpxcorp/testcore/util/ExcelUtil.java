package com.rpxcorp.testcore.util;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelUtil {

	private Workbook wb = null;

	public ExcelUtil(String pathExcel) {
		try {
			this.wb = WorkbookFactory.create(new File(pathExcel));

		} catch (IOException e) {
			e.printStackTrace();
		} catch (InvalidFormatException e) {
			e.printStackTrace();
		}

	}

	public Boolean isSheetExists(String sheetName) {
		int index = wb.getSheetIndex(sheetName);
		if (index == -1) {
			return false;
		} else {
			return true;

		}
	}

	public String[] getAllSheetName() {
		String[] sheets = new String[wb.getNumberOfSheets()];
		for (int i = 0; i < sheets.length; i++) {
			sheets[i] = wb.getSheetName(i);
		}
		return sheets;
	}
	public String[][] getAllDataByGrouping(Object[] sheets, Object[] columns, Object uniqueIdColumn){
		HashMap<String, String[]> datas = new HashMap<>();
		for (Object sheet:sheets){
			datas.putAll(getAllDataByGrouping(sheet, columns,uniqueIdColumn));
		}
		return new TreeMap<String, String[]>(datas).values().toArray(new String[datas.values().size()][]);
	}

	public Map<String,String[]> getAllDataByGrouping(Object sheetNameorIndex, Object[] columns,Object uniqueIdColumn){
		Sheet sheet = getSheet(sheetNameorIndex);
		int uniqueIdIndex = getColumn(sheet, uniqueIdColumn);
		int[] columnIndex=getColumn(sheet,columns);
		int startRow = 1;
		Map<String,String[]> data= new HashMap<>();
		for (int row = startRow; row < sheet.getPhysicalNumberOfRows(); row++) {
			data.put(getCellDataAsString(sheet,row,uniqueIdIndex),getAllRowData(sheet,row,columnIndex));
		}
		return data;
	};

	public String[] getAllRowData(Sheet sheet,int row,int[] columns){
		String[] data = new String[columns.length];
		for (int i = 0; i < columns.length; i++) {
			data[i] = getCellDataAsString(sheet, row, columns[i]);
		}
		return data;
	}

	public String[][] getAllDataFromColumn(Object[] columns) {
		return getAllDataFromColumn(columns, wb.getSheetAt(0), 1);
	}

	public String[][] getAllDataFromColumn(Object sheetNameorIndex, Object[] columns) {
		return getAllDataFromColumn(sheetNameorIndex, columns, 1);
	}

	public String[][] getAllDataFromColumn(Object sheetNameorIndex, Object[] columns, int startRow) {
		return getAllDataFromColumn(columns, getSheet(sheetNameorIndex), startRow);
	}
	private Sheet getSheet(Object sheetNameorIndex){
		Sheet sheet = null;
		if (sheetNameorIndex.getClass().equals(String.class)) {
			sheet = wb.getSheet(sheetNameorIndex.toString());
		} else {
			sheet = wb.getSheetAt((int) sheetNameorIndex);
		}
		return sheet;
	}
	private int getColumn(Sheet sheet,Object columnNameorIndex){
		int columnIndex;
		if (columnNameorIndex.getClass().equals(String.class)) {
			columnIndex = getIndexofColumn(sheet, columnNameorIndex.toString());
		}else{
			columnIndex=(int) columnNameorIndex;
		}
		return columnIndex;
	}

	private int[] getColumn(Sheet sheet,Object[] columns){
		int[] columnIndex= new int[columns.length];
		for (int col = 0; col < columns.length; col++) {
			columnIndex[col] = getColumn(sheet, columns[col]);
		}
		return columnIndex;
	}

	public String[][] getAllDataFromColumn(Object[] columnsObj, Sheet sheet, int startRow) {
		String[][] data = new String[sheet.getPhysicalNumberOfRows() - startRow][columnsObj.length];
		for (int col = 0; col < columnsObj.length; col++) {
			int column = getColumn(sheet,columnsObj[col]);
			for (int row = 0; row < data.length; row++) {
				data[row][col] = getCellDataAsString(sheet, row + startRow,column);
			}
		}
		return data;
	}

	public Object[][] getAllCoumnDataAsMap(String sheetName) {
		Sheet sheet = wb.getSheet(sheetName);
		Object[][] data = new Object[sheet.getPhysicalNumberOfRows() - 1][1];
		Row columns = sheet.getRow(0);
		for (int row = 0; row < data.length; row++) {
			HashMap<String, String> rowData = new HashMap<String, String>();
			for (int col = 0; col < columns.getLastCellNum(); col++) {
				String rowValue = getCellDataAsString(sheet, row + 1, col);
				if (!rowValue.equals("")) {
					rowData.put(getCellDataAsString(columns.getCell(col)), rowValue);
				}
				data[row][0] = rowData;
			}
		}
		return data;
	}

	public Map<String, String> getDataAsMap(String sheetName, int keyRowNumber, int valueRowNumber) {
		Sheet sheet = wb.getSheet(sheetName);
		Row keyRow = sheet.getRow(keyRowNumber);
		Map<String, String> data = new HashMap<String, String>();

		for (int keyRowCellCount = 0; keyRowCellCount < keyRow.getLastCellNum(); keyRowCellCount++) {
			String key = getStringCellData(sheetName, keyRowNumber, keyRowCellCount);
			String value = getStringCellData(sheetName, valueRowNumber, keyRowCellCount);
			data.put(key, value);
		}
		return data;
	}

	public Object[][] getAllDataFromColumnAsMap(String sheetName, int startRow, int endRow) {
		Sheet sheet = wb.getSheet(sheetName);
		Object[][] data = new Object[(endRow - startRow) + 1][1];
		Row columns = sheet.getRow(0);
		for (int row = 0; row < data.length; row++) {
			HashMap<String, String> rowData = new HashMap<String, String>();
			for (int col = 0; col < columns.getLastCellNum(); col++) {
				String rowValue = getCellDataAsString(sheet, startRow + row, col);
				if (!rowValue.equals("")) {
					rowData.put(getCellDataAsString(columns.getCell(col)), rowValue);
				}
				data[row][0] = rowData;
			}
		}
		return data;
	}

	public int getIndexofColumn(Sheet sheet, String columnName) {
		Row data = sheet.getRow(0);
		for (int i = 0; i < data.getLastCellNum(); i++) {
			System.out.println(data.getCell(i).getStringCellValue());
			if (data.getCell(i).getStringCellValue().equals(columnName))
				return i;
		}
		return -1;
	}

	public int getColCount(String sheetName) {
		if (!isSheetExists(sheetName))
			return -1;
		Sheet sheet = wb.getSheet(sheetName);
		int colCount = sheet.getRow(0).getLastCellNum();
		return colCount;
	}

	public int getRowCount(String sheetName) {
		if (!isSheetExists(sheetName))
			return -1;
		Sheet sheet = wb.getSheet(sheetName);
		int rowCount = sheet.getLastRowNum() + 1;
		return rowCount;
	}

	public String getCellDataAsString(Sheet sheet, int rowNum, int colNum) {
		Row row = sheet.getRow(rowNum);
		if (row == null)
			return "";
		Cell cell = row.getCell(colNum);
		return getCellDataAsString(cell);
	}

	public String getCellDataAsString(Cell cell) {
		if (cell == null)
			return "";
		switch (cell.getCellType()) {
		default:
		case Cell.CELL_TYPE_STRING:
			return cell.getStringCellValue();
		case Cell.CELL_TYPE_BOOLEAN:
			return String.valueOf(cell.getBooleanCellValue());
		case Cell.CELL_TYPE_NUMERIC:
			if (DateUtil.isCellInternalDateFormatted(cell) || DateUtil.isCellDateFormatted(cell))
				return getDateValueAsString(cell);
			String cellValueInString = new BigDecimal(cell.getNumericCellValue()).toPlainString();
			return cellValueInString.replaceFirst("\\.0+$", "");
		}
	}

	public String getDateValueAsString(Cell cell) {
		double dt = cell.getNumericCellValue();
		Calendar cal = Calendar.getInstance();
		cal.setTime(DateUtil.getJavaDate(dt));
		return cal.get(Calendar.MONTH) + 1 + "/" + cal.get(Calendar.DAY_OF_MONTH) + "/"
				+ String.valueOf(cal.get(Calendar.YEAR));
	}

	public String getStringCellData(String sheetName, int rowNum, int colNum) {

		// System.out.println("In getStringCellData by Column Name");
		Sheet sheet = null;
		String cellText = "";

		if (isSheetExists(sheetName))
			sheet = wb.getSheet(sheetName);
		// System.out.println(sheet.getSheetName());
		else {
			System.out.println("Verify the sheet name: " + sheetName);
			return "";
		}

		if (rowNum <= 0) {
			System.out.println("Row num cannot be <= zero");
			return "";
		}

		Row row = sheet.getRow(rowNum - 1);

		if (row == null) {
			return "";
		}
		// RETURN_NULL_AND_BLANK: Missing cells are returned as null, Blank
		// cells are returned as normal
		// Cell cell = row.getCell(colNum, Row.RETURN_NULL_AND_BLANK);
		Cell cell = row.getCell(colNum, Row.RETURN_BLANK_AS_NULL);
		if (cell == null) {
			// The spreadsheet is empty in this cell
			// --System.out.print("empty in this cell"+"#");
			// cellText="EmptyCell";

			return cellText;

		}

		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_STRING:
			cellText = cell.getRichStringCellValue().getString();
			break;
		case Cell.CELL_TYPE_FORMULA:

			cellText = String.valueOf(cell.getNumericCellValue());
			break;
		case Cell.CELL_TYPE_NUMERIC:

			if (DateUtil.isCellDateFormatted(cell)) {
				double dt = cell.getNumericCellValue();
				Calendar cal = Calendar.getInstance();
				cal.setTime(DateUtil.getJavaDate(dt));
				cellText = String.valueOf(cal.get(Calendar.YEAR));
				cellText = cal.get(Calendar.MONTH) + 1 + "/" + cal.get(Calendar.DAY_OF_MONTH) + "/" + cellText;

			}
			cellText = String.valueOf(cell.getNumericCellValue());
			break;
		case Cell.CELL_TYPE_BOOLEAN:

			cellText = String.valueOf(cell.getBooleanCellValue());
			break;
		default: // Cell.CELL_TYPE_ERROR
			return "";
		}

		return cellText;

	}

	public String getStringCellData(String sheetName, int rowNum, String colName) {

		Sheet sheet = null;
		String cellText = "";

		if (isSheetExists(sheetName))
			sheet = wb.getSheet(sheetName);
		// System.out.println(sheet.getSheetName());
		else {
			System.out.println("Verify the sheet name: " + sheetName);
			return "";
		}

		if (rowNum <= 0) {
			System.out.println("Row num cannot be <= zero");
			return "";
		}

		Row row = sheet.getRow(0);
		int colInd = 0;
		for (int i = 0; i < row.getLastCellNum(); i++) {
			if (row.getCell(i).getStringCellValue().compareToIgnoreCase(colName) == 0) {
				// if(row.getCell(i).getStringCellValue().trim().equals(colName.trim())){
				colInd = row.getCell(i).getColumnIndex();
				// System.out.println("Column number: "+colInd);
				break;
			}
		}

		// row = sheet.getRow(rowNum);
		row = sheet.getRow(rowNum - 1);

		if (row == null) {
			return "";
		}
		// RETURN_BLANK_AS_NULL: Missing cells and blank cells are returned as
		// null
		// Cell c = row.getCell(colInd, Row.RETURN_BLANK_AS_NULL);
		// RETURN_NULL_AND_BLANK: Missing cells are returned as null, Blank
		// cells are returned as normal
		Cell c = row.getCell(colInd, Row.RETURN_BLANK_AS_NULL);
		if (c == null) {
			// The spreadsheet is empty in this cell
			// System.out.print("empty in this cell"+"#");

			// cellText="EmptyCell";
			cellText = "";
			return cellText;

		}

		else if (c.getCellType() == Cell.CELL_TYPE_STRING)
			return c.getStringCellValue();
		else if (c.getCellType() == Cell.CELL_TYPE_FORMULA)
			return String.valueOf(c.getNumericCellValue());
		else if (c.getCellType() == Cell.CELL_TYPE_NUMERIC) {
			if (DateUtil.isCellDateFormatted(c)) {
				double dt = c.getNumericCellValue();
				Calendar cal = Calendar.getInstance();
				cal.setTime(DateUtil.getJavaDate(dt));
				cellText = String.valueOf(cal.get(Calendar.YEAR));
				cellText = cal.get(Calendar.MONTH) + 1 + "/" + cal.get(Calendar.DAY_OF_MONTH) + "/" + cellText;

				// System.out.println("String rep of Dat:" + cellText);
			} else {
				cellText = String.valueOf(c.getNumericCellValue());
			}
			return cellText;
		} else if (c.getCellType() == Cell.CELL_TYPE_BOOLEAN) {
			return String.valueOf(c.getBooleanCellValue());
		} else
			// Cell.CELL_TYPE_ERROR
			return "";

	}

	/**
	 * 
	 * To get the column names of the work sheet.
	 * 
	 * @param sheetName
	 */
	public ArrayList<String> toGetColumnNamesBySheetName(String sheetName) {

		ArrayList<String> colNames = new ArrayList<String>();
		if (sheetName != null && isSheetExists(sheetName)) {
			Sheet sheet = wb.getSheet(sheetName);
			int colCount = getColCount(sheetName);
			for (int iterate = 0; iterate < colCount; iterate++) {
				colNames.add(sheet.getRow(sheet.getFirstRowNum()).getCell(iterate).getRichStringCellValue().toString());
			}
		}
		return colNames;
	}

	public String[] getAllDataFromColumn(Object sheetNameorIndex, String column) {
		Sheet sheet = wb.getSheet((String) sheetNameorIndex);
		int columnIndex = getIndexofColumn(sheet, column);
		ArrayList<String> list = new ArrayList<String>();
		String[][] data = getAllDataFromColumn(sheetNameorIndex, new Object[] { columnIndex }, 1);

		for (int i = 0; i < data.length; i++) {
			for (int j = 0; j < data[i].length; j++) {
				list.add(data[i][j]);
			}
		}
		return list.toArray(new String[0]);

	}

}
