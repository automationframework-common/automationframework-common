package com.rpxcorp.testcore;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import com.google.common.collect.Sets;
import com.rpxcorp.testcore.page.PageNavigator;
import com.rpxcorp.testcore.util.AlphanumComparator;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.formula.functions.T;
import org.json.JSONArray;
import org.json.JSONObject;
import org.postgresql.jdbc4.Jdbc4ResultSet;

public class Assertion extends PageNavigator {

    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void assertEquals(Object actual, Object expected, String... params) throws Exception {        	
        if (expected.getClass().equals(Jdbc4ResultSet.class)) {
            switch (actual.getClass().getSimpleName()) {
            case "TableData":
                assertDBTableResult((TableData) actual, (ResultSet) expected, params);
                break;

            case "ArrayList":
                assertDBListResult((ArrayList) actual, (ResultSet) expected);
                break;

            case "HashMap":
                assertContentResult((HashMap<String, String>) actual, (ResultSet) expected);
                break;

            case "String":
                assertDBString((String) actual, (ResultSet) expected, params);
                break;
      
            default:
                String message = "";
                if (!expected.equals(actual))
                    message = "Actual :[" + actual + "] Expected : [" + expected + "]";
                assertFailure(message);
                break;
            }
        } else {
            switch (actual.getClass().getSimpleName()) {
            case "TableData":
                assertTableData((TableData) actual, (TableData) expected);
                break;

            case "ArrayList":
                assertList((List<String>) actual, (List<String>) expected);
                break;

            case "HashMap":
                assertHashMap((HashMap<?, ?>) actual, (HashMap<?, ?>) expected,params);
                break;
            case "String[]":
                assertArray((String[]) actual, (String[]) expected);
                break;
            default:

                if (actual.getClass().equals(Integer.class) && expected.getClass().equals(String.class))
                    expected = Integer.parseInt((String) expected);
                if (actual.getClass().equals(String.class) && expected.getClass().equals(Integer.class))
                    actual = Integer.parseInt((String) actual);
                String message = null;
                if (!actual.equals(expected)) {
                    message = "Actual :[" + actual + "] Expected : [" + expected + "]";
                }
                assertFailure(message);

                break;
            }
        }
    }   
    
    private void assertDBString(String actual, ResultSet expected, String[] params) throws SQLException {
        String message = null;
        expected.beforeFirst();
        if (expected.next()) {
            if (!compareString(actual, expected.getString(params[0]))) {
                message = "Actual :[" + actual + "] Expected : [" + expected.getString(params[0]) + "]";
            }
        } else {
            if (actual.length() > 0)
                message = "Actual :[" + actual + "] Expected : [ ]";
        }
        assertFailure(message);
    }

    private void assertContentResult(HashMap<String, String> actual, ResultSet expected) throws SQLException {
        StringBuffer message = new StringBuffer();
        expected.beforeFirst();
        if (expected.next()) {
            for (String key : actual.keySet()) {
                if (!compareString(actual.get(key), expected.getString(key)))
                    message.append("Actual :[ " + actual.get(key) + "] Expected: [" + expected.getString(key)
                            + "] for \"" + key + "\"\n");
            }
        } else {
            for (String key : actual.keySet()) {
                message.append("Actual :[ " + actual.get(key) + "] Expected: [ ] for \"" + key + "\"\n");
            }
        }
        assertFailure(message.toString());
    }

    private void assertDBListResult(ArrayList<?> actual, ResultSet expected) throws Exception {
        StringBuffer message = new StringBuffer();
        int i = 0;
        expected.beforeFirst();
        while (expected.next()) {
            if (!actual.remove(expected.getString("value").replaceAll("\\s+", " ").trim())) {
                message.append("Actual :[ ] Expected: [" + expected.getString("value") + "] for \"Missing Row "
                        + (i + 1) + "\"\n");
                i++;
            }
        }
        i = 1;
        for (Object object : actual) {
            message.append("Actual :[" + object + "] Expected: [ ] for \"Missing Row " + (i + 1) + "\"\n");
            i++;
        }
        assertFailure(message.toString());
    }

    @SuppressWarnings("unchecked")
    private void assertDBTableResult(TableData actual, ResultSet expected, String... columns) throws SQLException {
        StringBuffer message = new StringBuffer();
        HashMap<String, String[]> act_datas = (HashMap<String, String[]>) actual.getData().clone();
        String[] headers = actual.getHeader();
        List<String> headerList = Arrays.asList(headers);
        if (columns == null || columns.length == 0)
            columns = headers;
        expected.beforeFirst();
        int i = 0;
        while (expected.next()) {
            String uniqueId = Integer.toString(i);
            i++;
            try {
                uniqueId = expected.getString("unique_id");
                uniqueId = uniqueId.replaceAll("\\s+", " ").trim();
            } catch (Exception e) {

            }
            String[] act_data = act_datas.remove(uniqueId);
            if (act_data != null) {
                // REPORT MISMATCH BETWEEN UI AND DB VALUE
                for (String header : columns) {
                    int index = headerList.indexOf(header);
                    if (!compareString(act_data[index], expected.getString(header)))
                        message.append("Actual :[" + act_data[index] + "] Expected: [" + expected.getString(header)
                                + "] for \" " + uniqueId + " : " + header + "\"\n");
                }
            } else {
                if (columns.length > 0) {
                    // REPORT MISMATCH UI ROWS
                    for (String header : columns) {
                        message.append("Actual :[ ] Expected: [" + expected.getString(header) + "] for \"Missing :"
                                + (uniqueId) + " : " + header + "\"\n");

                    }
                } else {
                    message.append("Actual :[ ] Expected: [" + expected.getString("unique_id") + "] for \"Missing :"
                            + (uniqueId) + "\"\n");
                }
            }
        }
        // REPORT MISMATCH DB ROWS
        for (String key : act_datas.keySet()) {
            for (String header : columns) {
                int index = headerList.indexOf(header);
                message.append("Actual :[" + act_datas.get(key)[index] + "] Expected: [ ] for \"Missing for Id " + (key)
                        + " : " + header + "\"\n");
            }
        }
        assertFailure(message.toString());
    }

    public void assertResultSet(ResultSet actual, ResultSet expected) throws SQLException {
    	StringBuffer message = new StringBuffer();

    	int actTotalColCount = actual.getMetaData().getColumnCount();    
    	int expTotalColCount = expected.getMetaData().getColumnCount();   

    	if(actTotalColCount == expTotalColCount) {
    		int rowCounter = 1;
    		while(actual.next() && expected.next()) {
    			{    				
    				for(int colCount = 1; colCount <= actTotalColCount; colCount++) {    					
    					if (actual.getString(colCount) == null || expected.getString(colCount) == null) {
    						if(!(actual.getString(colCount) == expected.getString(colCount))){    							
    							message.append("Mismatch: Actual: " + actual.getString(colCount)
    									+ " Expected: " + expected.getString(colCount) + " for column: " +  actual.getMetaData().getColumnName(colCount) 
    									+ " in row: " + rowCounter + "\n");	
    						} 
    					} else if(!(actual.getString(colCount)).equals(expected.getString(colCount))){    							
    						message.append("Mismatch: Actual: " + actual.getString(colCount)
    								+ " Expected: " + expected.getString(colCount) + " for column: " +  actual.getMetaData().getColumnName(colCount)
    								+ " in row: " + rowCounter + "\n");	
    					}    				
    				}
    			}
    			rowCounter++;
    		}
    	} else    		
    		message.append("Mismatch in total rows and columns. Actual column lenght: " + actTotalColCount + "Expected column length: " + expTotalColCount);
    	assertFailure(message.toString());
    }


    public void assertResultSets(ResultSet actual, ResultSet expected) throws Exception {
        StringBuffer message = new StringBuffer();
        System.out.println(actual.getMetaData().toString());
        int actTotalColCount = actual.getMetaData().getColumnCount();
        int expTotalColCount = expected.getMetaData().getColumnCount();
        Set<String> keys;

        if(actTotalColCount == expTotalColCount) {
            if(actTotalColCount==1){
                List<String> eList=getResultsSetData(expected,expTotalColCount);
                List<String> aList=getResultsSetData(actual,actTotalColCount);
                if(eList.size()==1 && aList.size()==1)
                assertEquals(aList.get(0),eList.get(0));
                else {
                    List<String> result_not_in_Exp = eList.stream().filter(aObject ->
                            !aList.contains(aObject)).collect(Collectors.toList());

                    List<String> result_not_in_Act = aList.stream().filter(aObject ->
                            !eList.contains(aObject)).collect(Collectors.toList());
                    if (result_not_in_Exp.size() > 0) {
                        message.append("The below data is not available in Actual destination:\n");
                        message.append(result_not_in_Exp + "\n");
                    }
                }
            }
            else if(actTotalColCount>1) {
            Map<String,HashMap<String,Object>> aMap=getResultsSetDataInMaps(actual,actTotalColCount);
            Map<String,HashMap<String,Object>> eMap=getResultsSetDataInMaps(expected,expTotalColCount);

            Set<String> aKeys=aMap.keySet();
            Set<String> eKeys=eMap.keySet();
            Set<String> diff=new HashSet<>();
            for(String mapkey:eKeys) {
                if(aKeys.contains(mapkey)) {
                    for (String key : aMap.get(mapkey).keySet()) {
                        Object exp = eMap.get(mapkey).get(key);
                        Object act = aMap.get(mapkey).get(key);
                        if (!java.util.Objects.equals(act, exp)) {
                            message.append(" " + mapkey + ":-" + key + " Actual:" + act + " Expected: " + exp + "\n");
                        }
                    }
                } else {
                    diff.add(mapkey);
                }
            }
                if(diff.size()>0){
                    message.append("The data is not available in dest system:"+diff);
                }
            }
        }
          else
            message.append("Mismatch in total rows and columns. Actual column lenght: " + actTotalColCount + "Expected column length: " + expTotalColCount);
            assertFailure(message.toString());
    }

    private ArrayList<String> getResultsSetData(ResultSet actual, int actTotalColCount) throws SQLException{
        ArrayList<String> data=new ArrayList<String>();
      while(actual.next()){
          String temp=" ";
        for(int i=1;i<=actTotalColCount;i++){
          temp=actual.getString(i)+"  "+temp;
        }
           data.add(temp.trim());
        }
        return data;
    }

    private Map<String,HashMap<String,Object>> getResultsSetDataInMaps(ResultSet actual, int actTotalColCount) throws SQLException{
        Map<String,HashMap<String,Object>> maps=new HashMap<>();
        HashMap<String,Object> data=new HashMap<String,Object>();
        ResultSetMetaData rsmd = actual.getMetaData();
        while(actual.next()){
            for(int i=1;i<=actTotalColCount;i++){
                data.put(rsmd.getColumnName(i),actual.getString(rsmd.getColumnName(i)));
            }
            maps.put(actual.getString("unique_id"),data);
            data.clear();
        }
        return maps;
    }


    public void assertTableData(TableData actual, TableData expected) {
        StringBuffer message = new StringBuffer();
        String[] headers;
        int rowSize;
        HashMap<String, String[]> act_data = actual.getData();
        HashMap<String, String[]> exp_data = expected.getData();
        int actual_size = act_data.size();
        int exp_size = exp_data.size();

        if (actual_size <= exp_size) {
            rowSize = actual_size;
            headers = expected.getHeader();
        } else {
            rowSize = exp_size;
            headers = actual.getHeader();
        }
        // REPORT MISMATCH BETWEEN LEFT SIDE UI AND RIGHT SIDE UI VALUE
        for (int row = 0; row < rowSize; row++) {
            String rowString = Integer.toString(row);
            String[] actual_Row = act_data.get(rowString);
            String[] exp_Row = exp_data.get(rowString);
            for (int col = 0; col < actual_Row.length; col++) {
                if (actual_Row[col] == null)
                    actual_Row[col] = "";
                if (exp_Row[col] == null)
                    exp_Row[col] = "";
                if (!actual_Row[col].equals(exp_Row[col]))
                    message.append("Actual :[" + actual_Row[col] + "] Expected: [" + exp_Row[col] + "] for \"Row "
                            + (row + 1) + " : " + headers[col] + "\"\n");

            }
        }
        if (actual_size > exp_size) {
            // REPORT MISSING ROWS IN RIGHT SIDE UI
            for (int row = rowSize; row < actual_size; row++) {
                String[] row_data = act_data.get(Integer.toString(row));
                for (int col = 0; col < row_data.length; col++) {
                    message.append("Actual :[" + row_data[col] + "] Expected: [] for \"Missing Row " + (row + 1) + " : "
                            + headers[col] + "\"\n");
                }
            }
        } else {
            // REPORT MISSING ROWS IN LEFT SIDE UI
            for (int row = rowSize; row < exp_size; row++) {
                String[] row_data = exp_data.get(Integer.toString(row));
                for (int col = 0; col < row_data.length; col++) {
                    message.append("Actual :[] Expected: [" + row_data[col] + "] for \"Missing Row " + (row + 1) + " : "
                            + headers[col] + "\"\n");
                }
            }
        }

        assertFailure(message.toString());
    }

    public void assertString(String actual, String expected) {
        String message = null;
        if (!compareString(actual, expected)) {
            message = "Actual :[" + actual + "] Expected : [" + expected + "]";
        }
        assertFailure(message);
    }

    public Boolean compareString(String actual, String expected) {
        actual = StringUtils.defaultString(actual, "");
        expected = StringUtils.defaultString(expected, "");
        if (actual.contains("...")) {
            if (actual.contains(";")) {
                expected = normalize(expected);
                for (String temp : actual.split(";")) {
                    temp = normalize(temp);
                    if (!expected.contains(temp) & !temp.contains("NULL"))
                        return false;
                }
            } else {
                actual = actual.replaceAll("\\.\\.\\.", "");
                expected = expected.replaceAll(";", " ");
                double diff = StringUtils.getJaroWinklerDistance(actual, expected);
                System.out.println("Percentage Match:" + (diff * 100) + "%\n|" + actual + "|\n|" + expected
                        + "|\n---------------");
                if (diff <= 0.8)
                    return false;
            }

        } else if (expected.contains(";")) {
            actual = normalize(actual);
            for (String temp : expected.split(";")) {
                temp = normalize(temp);
                if (!actual.contains(temp) & !temp.contains("NULL"))
                    return false;
            }
        }
        // TODO Enable equals comparison and remove contains logic
        // else if(!normalize(actual).equals(normalize(expected))) {
        // return false;
        // }
        else {
            actual = normalize(actual);
            expected = normalize(expected);
            if (!actual.equals(expected)) {
                if (!(expected.length() > 0 && actual.contains(expected))) {
                    return false;
                }
            }
        }

        return true;
    }

    private String normalize(String value) {
        value = value.replaceAll("[^a-zA-Z0-9]+", "");
        value = value.replaceAll(" ", "").toUpperCase().trim();
        return value;
    }

    protected void assertTrue(boolean isTrue, String message) {
        if (isTrue == false)
            assertFailure(message);
    }

    protected void assertFalse(boolean isFalse, String message) {
        if (isFalse == true)
            assertFailure(message);

    }

    private void assertFailure(String message) {
        if (!(message == null || message.equals(""))) {
            String normalizedMessage = message;
            try {
                normalizedMessage = new String(message.toString().getBytes("ISO-8859-1"), "UTF-8");
            } catch (Exception e) {
                e.printStackTrace();
            }
            throw new AssertionError(normalizedMessage);
        }
        assert true;
    }

	protected void assertColumnSort(String dataType, String sortType,
			List<String> actualValues) {
		boolean result = false;
		List<String> expectedValues = new ArrayList<String>();
		List<String> expectedEmptyValues = new ArrayList<String>();
		List<String> expectedNonEmptyValues = new ArrayList<String>();
		// Temporary cleaned empty value to avoid failures
		actualValues.removeAll(Arrays.asList(""));
		// Added the below condition for empty list
		if (actualValues.isEmpty()) {
			System.out.println("Empty List");
			actualValues.addAll(Arrays.asList(""));
			expectedValues = actualValues;
		} else {
			for (String actualValue : actualValues) {
				if (actualValue.equals("") || actualValue.isEmpty()
						|| actualValue.equals("--") || actualValue.equals("N/A"))
					expectedEmptyValues.add(actualValue);
				else
					expectedNonEmptyValues.add(actualValue);
			}

			Comparator<Object> compartor = null;
			if (dataType.equalsIgnoreCase("date")) {
				compartor = new DateComparator();
			} else if (dataType.equalsIgnoreCase("string")) {
				compartor = new StringIgnoreCase();
			} else if (dataType.equals("string_only")) {
				compartor = new SortIgnoreCharacter();
			} else {
				compartor = new AlphanumComparator();
			}

			Collections.sort(expectedNonEmptyValues, compartor);
			if (sortType.equalsIgnoreCase("DESC")) {
				Collections.reverse(expectedNonEmptyValues);
                expectedValues.addAll(expectedNonEmptyValues);
                expectedValues.addAll(expectedEmptyValues);
			}else if(sortType.equalsIgnoreCase("ASC")){
                expectedValues.addAll(expectedEmptyValues);
                expectedValues.addAll(expectedNonEmptyValues);
            }

		}
		for (int listCounter = 0; listCounter < actualValues.size(); listCounter++) {
			if (expectedValues.get(listCounter).toString()
					.equals(actualValues.get(listCounter).toString()))
				result = true;
			else {
				result = false;
				break;
			}
		}

		if (result == false)
			assertFailure("Sorting not as expected, Actual: " + actualValues
					+ ", Expected: " + expectedValues);
	}

    /**
     * Asserts the given two hash map with any data type and asserts the
     * mismatches along with the missing and additional values
     *
     * @author Benasir Jailabudeen
     *
     * @param actual
     * @param expected
     * @throws Exception
     */
    private void assertHashMap(HashMap<?, ?> actual, HashMap<?, ?> expected,String... params) throws Exception {
        StringBuffer message = new StringBuffer();
        TreeSet<Object> keys = new TreeSet<Object>(expected.keySet());
        for (Object key : keys) {
            String description = key.toString().replaceAll("_", " ");

            try {
                Object actualValue = actual.get(key), expectedValue = expected.get(key);
                actual.remove(key);
                if (!actualValue.equals(expectedValue))
                    message.append("Actual :[" + actualValue + "] Expected: [" + expectedValue + "] for \" "
                            + description + "\"\n");
            } catch (Exception e) {
                message.append(
                        "Actual :[] Expected: [" + expected.get(key) + "] for \"Missing " + description + "\"\n");
            }
        }
        keys = new TreeSet<Object>(actual.keySet());
        for (Object key : keys) {
            String description = key.toString().replaceAll("_", " ");
            message.append("Actual :[" + actual.get(key) + "] Expected: [] for \"Missing " + description + "\"\n");
        }
        if(params.length==0)
        assertFailure(message.toString());
        else assertFailure(params[0]+"\n"+message.toString());
    }

    /**
     * Asserts the given two list and identify mismatches along with the missing
     * and additional values. Note: Exact duplicate values may not be shown in
     * failure if there is a mismatch in duplicated count
     * 
     * @author Benasir Jailabudeen
     * @param actual
     * @param expected
     * @throws Exception
     */
    private void assertList(List<String> actual, List<String> expected) throws Exception {
        StringBuffer message = new StringBuffer();

        List<String> temp = new ArrayList<>();
        temp.addAll(actual);
        actual.removeAll(expected);
        expected.removeAll(temp);

        for (String row : actual)
            message.append("Actual :[" + row + "] Expected: [] for " + row.split("\t")[0] + "\n");

        for (String row : expected)
            message.append("Actual :[] Expected: [" + row + "] for " + row.split("\t")[0] + "\n");

        assertFailure(message.toString());
    }

    private void assertArray(String[] actual, String[] expected) throws Exception {
        StringBuffer message = new StringBuffer();

        boolean isEqual = false;
        isEqual = Arrays.asList(actual).equals(Arrays.asList(expected));
        // for(int i=0;i<actual.length();)
        if (!isEqual) {
            message.append(
                    "Actual :[" + Arrays.asList(actual) + "] Expected: [] for " + Arrays.asList(expected) + "\n");
        }
        assertFailure(message.toString());
    }
    
    public void assertJson(String actual, String expectd, String[] compareKeys) {
    	StringBuffer message = new StringBuffer();
    	JSONArray actualJsonArray = new JSONArray(actual);
    	JSONArray expJsonArray = new JSONArray(expectd);

    	if(actualJsonArray.length() == expJsonArray.length()){
    		int jsonCount =  actualJsonArray.length();

    		for (int count = 0; count < jsonCount; count++){
    			JSONObject actualObject = actualJsonArray.getJSONObject(count);						
    			JSONObject expObject = expJsonArray.getJSONObject(count);				
    			for (int keyCount = 0; keyCount < compareKeys.length; keyCount++ ){
    				String actualValue = actualObject.get(compareKeys[keyCount]).toString();
    				String expValue = expObject.get(compareKeys[keyCount]).toString();
    				if(!actualValue.equals(expValue))
    					message.append("Mismatch in array index " + count + " for key " + compareKeys[keyCount] +
    							" Actual: " + actualValue + " Expected: " + expValue);						
    			}
    		}
    	} else {
    		message.append("The actual and expected json count is not the same. Actual: " + actualJsonArray + "Expected: "+ expJsonArray);
    	}
    	assertFailure(message.toString());
    }

}

class StringIgnoreCase implements Comparator<Object> {
    public int compare(Object o1, Object o2) {
        String s1 = (String) o1;
        String s2 = (String) o2;
        return s1.toLowerCase().compareTo(s2.toLowerCase());
    }
}

class DateComparator implements Comparator<Object> {
    DateFormat f = new SimpleDateFormat("MM/dd/yyyy");

    public int compare(Object o1, Object o2) {
        String s1 = (String) o1;
        String s2 = (String) o2;
        try {
            return f.parse(s1).compareTo(f.parse(s2));
        } catch (java.text.ParseException e) {
            throw new IllegalArgumentException(e);
        }
    }

}

class SortIgnoreCharacter implements Comparator<Object> {
    public int compare(Object o1, Object o2) {
        String s1 = (String) o1;
        String s2 = (String) o2;
        s1 = s1.replaceAll("[^\\w\\s]", "");
        s2 = s2.replaceAll("[^\\w\\s]", "");
        return s1.toLowerCase().compareTo(s2.toLowerCase());
    }
}