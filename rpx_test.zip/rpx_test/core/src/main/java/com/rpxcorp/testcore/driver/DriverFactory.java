package com.rpxcorp.testcore.driver;

import com.rpxcorp.testcore.util.ConfigUtil;
import io.github.bonigarcia.wdm.ChromeDriverManager;
import io.github.bonigarcia.wdm.InternetExplorerDriverManager;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;

import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static io.github.bonigarcia.wdm.DriverManagerType.CHROME;
import static io.github.bonigarcia.wdm.DriverManagerType.IEXPLORER;


public class DriverFactory {

	public synchronized static WebDriver getDriver() {
		Object browser = ConfigUtil.config().get("BROWSER");
		if (browser == null)
			browser = "";
		switch (browser.toString().toUpperCase()) {
		default:
		case "CHROME":
//			ChromeDriverManager.getInstance(CHROME).setup();
			ChromeDriverManager.getInstance(CHROME).version("92.0.4515.43").setup();//.version("87.0.4280.88")
//			System.setProperty(ChromeDriverService.CHROME_DRIVER_EXE_PROPERTY, getDriverPath("chrome"));
			Map<String, Object> prefs = new HashMap<String, Object>();
			ConfigUtil.config().put("testOutputDir",ConfigUtil.config().get("buildDir").toString()+ "/testOutputs/"+System.identityHashCode(Thread.currentThread()));
			prefs.put("download.default_directory", ConfigUtil.config().get("testOutputDir").toString().replace("/", "\\"));
			prefs.put("credentials_enable_service", false);
			prefs.put("profile.password_manager_enabled", false);
			DesiredCapabilities caps = DesiredCapabilities.chrome();
			ChromeOptions options = new ChromeOptions();
			// options.setExperimentalOption("excludeSwitches",
			// Arrays.asList("test-type", "--ignore-certificate-errors"));
//			System.out.println(System.identityHashCode(Thread.currentThread()));
			File dataDir = new File(ConfigUtil.config().getProperty("buildDir") + "/driver/" + System.identityHashCode(Thread.currentThread()) );
            if(!dataDir.exists())
                dataDir.mkdirs();
            //options.addArguments("--user-data-dir="+dataDir.getAbsolutePath().replace("\\","\\\\"));
			options.addArguments("test-type");
			options.addArguments("--allow-running-insecure-content");
			options.addArguments("--disable-extensions");
			options.addArguments("disable-infobars");
			options.setExperimentalOption("prefs", prefs);
			options.setExperimentalOption("useAutomationExtension", false);
			options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
			caps.setCapability(ChromeOptions.CAPABILITY, options);
			return new ChromeDriver(caps);

		case "FIREFOX":
			WebDriverManager.firefoxdriver().setup();
			System.out.println(System.getProperty("webdriver.gecko.driver"));
			FirefoxOptions firefoxOptions=new FirefoxOptions();
			FirefoxProfile profile = new FirefoxProfile();
			profile.setPreference("browser.download.folderList", 2);
			profile.setPreference("browser.download.manager.showWhenStarting", false);
			ConfigUtil.config().put("testOutputDir",ConfigUtil.config().get("buildDir").toString()+ "/testOutputs/"+System.identityHashCode(Thread.currentThread()));
		    profile.setPreference("browser.download.dir", ConfigUtil.config().get("testOutputDir").toString().replace("/", "\\"));
			profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "text/csv");
			profile.setAcceptUntrustedCertificates(true);
			File f_dataDir = new File(ConfigUtil.config().getProperty("buildDir") + "/driver/" + System.identityHashCode(Thread.currentThread()) );
			if(!f_dataDir.exists())
				f_dataDir.mkdirs();
			firefoxOptions.setProfile(profile);
			return new FirefoxDriver(firefoxOptions);
		case "IE":
            InternetExplorerDriverManager.getInstance(IEXPLORER).setup();
			DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			return new InternetExplorerDriver(capabilities);
		case "SAFARI":
			DesiredCapabilities safCapability = DesiredCapabilities.safari();
			SafariOptions safariOptions = new SafariOptions();
		//	safariOptions.setUseCleanSession(true);
			safCapability.setCapability(SafariOptions.CAPABILITY, safariOptions);
			safCapability.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			safCapability.setCapability("safari.options.dataDir",ConfigUtil.config().get("testOutputDir").toString());
			return new SafariDriver(safCapability);
		}
	}
}
