package com.rpxcorp.testcore.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.FileAttribute;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.*;

import org.apache.commons.io.FilenameUtils;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.SimpleBookmark;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;

public class FileUtil {

    public static void createDirectory(File filePath) {
        try {
            if (!filePath.exists()) {
                filePath.mkdirs();
                filePath.setReadable(true,false);
                filePath.setWritable(true,false);
                filePath.setExecutable(true,false);
            }
        } catch (Exception e) {
            System.out.println("Exception in createDirectory: " + e);
        }
    }

    public static File[] listAllFilesFromADirectory(String dirPath) {
        File dir = new File(dirPath);
        File[] listOfFiles = dir.listFiles();
        return listOfFiles;
    }

    public static void deleteFilesFromDirectory(File dir) {
        if (dir.exists()) {
            for (File file : dir.listFiles()) {
                if (file.isDirectory())
                    deleteFilesFromDirectory(file);
                file.delete();
            }
        } else {
            try {
                dir.mkdirs();
                dir.setReadable(true,false);
                dir.setWritable(true,false);
                dir.setExecutable(true,false);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    public static Map<String, Boolean> validatePDFFile(String dirPath) throws IOException {
        String fileExtension;
        PdfReader pdfReader ;
        Map<String, Boolean> validationMap = new HashMap<String, Boolean>();
        boolean isFile = false, isFilePDF = false, arePagesPresent = false, isPDFTampered = true;

        File[] files = listAllFilesFromADirectory(dirPath);
        for (File file : files) {
            if (file.isFile()) {
                isFile = true;
                fileExtension = FilenameUtils.getExtension(file.getAbsolutePath());
                if (fileExtension.contains("pdf")) {
                    isFilePDF = true;
                    pdfReader = new PdfReader(file.getAbsolutePath());

                    if (pdfReader.getNumberOfPages() > 0)
                        arePagesPresent = true;
                    else
                        arePagesPresent = false;

                    if (pdfReader.isTampered())
                        isPDFTampered = true;
                    else
                        isPDFTampered = false;
                    List list = SimpleBookmark.getBookmark(pdfReader);
                    System.out.println(list);
                    pdfReader.close();
                } else
                    isFilePDF = false;
            } else
                isFile = false;
        }
        validationMap.put("isFile", isFile);
        validationMap.put("isFilePDF", isFilePDF);
        validationMap.put("arePagesPresent", arePagesPresent);
        validationMap.put("isPDFTampered", isPDFTampered);
        
        

        return validationMap;
    }

    public static String readPDFFile(String dirPath, int pageNumber) throws IOException, InterruptedException {
        String fileExtension, pageContent = null;

        File[] files = listAllFilesFromADirectory(dirPath);
        for (File file : files) {
            if (file.isFile()) {
                fileExtension = FilenameUtils.getExtension(file.getAbsolutePath());
                if (fileExtension.contains("pdf")) {
                	PdfReader pdfReader = new PdfReader(file.getAbsolutePath());                    
                    pageContent = PdfTextExtractor.getTextFromPage(pdfReader, pageNumber);
                    pdfReader.close();
                }
            }
        }
        return pageContent;
    }
    
    public static ArrayList<String> readBookMarksOfPDFFile(String dirPath) throws IOException {
        String fileExtension, pageContent = null;
        ArrayList<String> bookmarks_Data=new ArrayList<String>();
        File[] files = listAllFilesFromADirectory(dirPath);
        for (File file : files) {
            if (file.isFile()) {
                fileExtension = FilenameUtils.getExtension(file.getAbsolutePath());
                if (fileExtension.contains("pdf")) {
                    PdfReader pdfReader = new PdfReader(file.getAbsolutePath());
                    List<HashMap<String, Object>> bookmarks = SimpleBookmark.getBookmark(pdfReader);
                    
                    for (int i = 0;i<bookmarks.size(); i++) {
                    	bookmarks_Data.add(bookmarks.get(i).get("Title").toString());                    	
                    }
                    pdfReader.close();
                }
            }
        }
        
        return bookmarks_Data;
    }
    public static void waitUntilFileDownload(String dirPath, int timeOutLimitms) throws Exception {
        String fileExtension;
        int timeOutLimit = timeOutLimitms / 1000;

        Thread.sleep(1000);
        File[] files = listAllFilesFromADirectory(dirPath);
        if(files==null)
            throw new Exception("No directory found"+dirPath);
        for (int timeOut = 1; timeOut <= timeOutLimit; timeOut++) {
            for (File file : files) {
                if (file.isFile()) {
                    fileExtension = FilenameUtils.getExtension(file.getAbsolutePath());
                    System.out.println(fileExtension);
                    if (fileExtension.contains("crdownload") || fileExtension.contains("tmp"))
                        Thread.sleep(1000);
                    else if (fileExtension.contains("part"))
                        Thread.sleep(1000);
                    else
                        break;
                }
            }
        }
    }

    public static String returnFileExtension(String dirPath) {
        String fileExtension = null;

        File[] files = listAllFilesFromADirectory(dirPath);
        for (File file : files)
            if (file.isFile())
                fileExtension = FilenameUtils.getExtension(file.getAbsolutePath());

        return fileExtension;
    }

    /**
     * Read CSV Row Value from output directory path
     * 
     * @param dirPath
     * @return
     * @throws IOException
     */
    public static List<String> readCSVFile(String dirPath) throws IOException {
        List<String> rowValue = new ArrayList<>();
        String fileExtension = null;
        File[] files = listAllFilesFromADirectory(dirPath);
        for (File file : files) {
            if (file.isFile()) {
                fileExtension = FilenameUtils.getExtension(file.getAbsolutePath());
                if (fileExtension.contains("csv") || fileExtension.contains("xlsx")) {
                    // Get scanner instance
                    Scanner scanner = new Scanner(new File(file.getAbsolutePath()));
                    // Set the delimiter used in file
                    scanner.useDelimiter(System.getProperty("line.separator"));
                    // Get all tokens and store them in some data structure
                    while (scanner.hasNext()) {
                        rowValue.add(scanner.next());
                    }
                    // Close the scanner
                    scanner.close();
                }
            }
        }
        return rowValue;
    }
}