package com.rpxcorp.testcore.page;

import com.rpxcorp.testcore.driver.BrowserCache;
import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.util.Configure;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;

import java.io.UnsupportedEncodingException;
import java.lang.invoke.SerializedLambda;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URLDecoder;

public abstract class Page extends BrowserCache {
    protected String baseSelector;
    protected PageUrl url = new PageUrl("");

    public Page() {
    }

    public Page(String baseSelector) {
        this.baseSelector = baseSelector;
    }

    public abstract boolean at();

    protected Element $(String cssSelector) {
        if (baseSelector != null)
            cssSelector = baseSelector + " " + cssSelector;
        return new Element(cssSelector);
    }

    protected Element $(By locator) {
        return new Element(locator);
    }

    protected Element $$(String cssSelector) {
        return $(By.cssSelector(cssSelector));
    }

    protected Element $x(String xpathString) {
        return $(By.xpath(xpathString));
    }


    protected <T> T $(String cssseletor, Configure<T> configuration) {
        T value = $(cssseletor,getModuleClass(configuration));
        configuration.apply(value);
        return value;
    }

    protected <T> T $(String cssSelector, Class<?> moduleClass) {

        T element = null;
        Constructor<?> ctor;

        try {
            ctor = moduleClass.getDeclaredConstructor(String.class);
            ctor.setAccessible(true);
            element = (T) ctor.newInstance(cssSelector);
        } catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException
                | IllegalArgumentException | InvocationTargetException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return element;
    }


    protected <T> T $(By byObject, Configure configuration) {
        T value = $(byObject, getModuleClass(configuration));
        configuration.apply(value);
        return value;
    }


    protected <T> T $(By byObject, Class<?> moduleClass) {

        T element = null;
        Constructor<?> ctor;

        try {
            ctor = moduleClass.getDeclaredConstructor(By.class);
            ctor.setAccessible(true);
            element = (T) ctor.newInstance(byObject);
        } catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException
                | IllegalArgumentException | InvocationTargetException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return element;
    }

    public boolean navigate() {
        return navigate(null,true);
    }

    public boolean navigateBack() {
        getDriver().navigate().back();
        return true;
    }

    public boolean refresh() {
        getDriver().navigate().refresh();
        return true;
    }

    public String getCurrentUrl() {
        return getDriver().getCurrentUrl();
    }
    public String getPartialUrl(){
        return URLDecoder.decode(getCurrentUrl()).replaceAll(getConfig("BASE_URL"),"");
    }

    public String getPageTitle() {
        return getDriver().getTitle();
    }

    public String getPageSource() {
        return getDriver().getPageSource();
    }

    public boolean navigate(Object urlData,boolean wait) {
        String urlString = getDeclaredUrl(urlData);
        boolean navigate = true;
        if (wait == false) {
            try {
                navigate = !isSameUrl(urlString, URLDecoder.decode(getDriver().getCurrentUrl(), "UTF-8"));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        if (navigate == true) {
            getDriver().get(urlString);
        }
        return true;
    }

    private boolean isSameUrl(String url, String compareUrl) {
        url = url.replaceAll("#", "").replaceAll("\\?", "");
        compareUrl = compareUrl.replaceAll("#", "").replaceAll("\\?", "");
        return url.equals(compareUrl);
    }

    public Element object(String objectName) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException {
        return (Element) this.getClass().getField(objectName).get(this);
    }

    public Object invokeMethod(String methodName) throws SecurityException,
            IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        Object retVal = null;
        if (!methodName.isEmpty()) {
            Method method;
            try {
                method = this.getClass().getDeclaredMethod(methodName);
            } catch (NoSuchMethodException e) {
                method = this.getClass().getSuperclass().getDeclaredMethod(methodName);
            }
            retVal = method.invoke(this);
        }
        return retVal;
    }

    private Class<?> getModuleClass(Configure configuration) {
        Class<?> type = null;
        try {
            Method replaceMethod = configuration.getClass().getDeclaredMethod("writeReplace");
            replaceMethod.setAccessible(true);
            SerializedLambda lambda = (SerializedLambda) replaceMethod.invoke(configuration);
            String implClassName = lambda.getImplClass().replace('/', '.');
            Class<?> implClass = Class.forName(implClassName);

            String lambdaName = lambda.getImplMethodName();
            Method method = null;
            for (Method m : implClass.getDeclaredMethods()) {
                if (m.getName().equals(lambdaName)) {
                    method = m;
                    break;
                }
            }
            type = (Class<?>) method.getGenericParameterTypes()[0];
        } catch (Exception e) {
            e.printStackTrace();
        }
        return type;
    }

    public String getDeclaredUrl() {
        return getDeclaredUrl(null);
    }

    public String getDeclaredUrl(Object urlData) {
        try {
            return url.build(urlData);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public void navigateTo(String url) {
        getDriver().navigate().to(url);
    }

    public String acceptAlert() {
        String text=null;
        try{
        text = getDriver().switchTo().alert().getText();
        getDriver().switchTo().alert().accept();
        }catch(NoAlertPresentException ex){
        }
        return text;
    }

}
