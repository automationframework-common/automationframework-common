package com.rpxcorp.testcore.util;

import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import com.braintreegateway.BraintreeGateway;
import com.braintreegateway.CreditCard;
import com.braintreegateway.CreditCardVerification;
import com.braintreegateway.CreditCardVerificationSearchRequest;
import com.braintreegateway.Customer;
import com.braintreegateway.CustomerSearchRequest;
import com.braintreegateway.Environment;
import com.braintreegateway.PaymentMethodRequest;
import com.braintreegateway.ResourceCollection;
import com.braintreegateway.Result;
import com.braintreegateway.Subscription;
import com.braintreegateway.Transaction;
import com.braintreegateway.exceptions.NotFoundException;

/**
 * Created Braintree Api Test Class
 * 
 * @author pusulurip
 *
 */
public class BraintreeUtil {

    static BraintreeGateway gateway = new BraintreeGateway(Environment.SANDBOX,
            (String) ConfigUtil.config().get("MERCHANT_KEY"), (String) ConfigUtil.config().get("PUBLIC_KEY"),
            (String) ConfigUtil.config().get("PRIVATE_KEY"));

    public static HashMap<String, String> getTransactionStatus(String transactionId) {
        HashMap<String, String> transInfo = new HashMap<String, String>();
        Transaction transaction = gateway.transaction().find(transactionId);
        // For Sucess -1000
        transInfo.put("RESP_CODE", transaction.getProcessorResponseCode());
        // SETTLE
        transInfo.put("STATUS", transaction.getStatus().toString());
        // Transaction Amount
        transInfo.put("AMOUNT", transaction.getAmount().toString());
        // Mode of pay Ex:credit_card
        transInfo.put("PAYMENT_TYPE", transaction.getPaymentInstrumentType());
        // Subscription Plan like plus_monthly
        transInfo.put("SUBSCRIPTION_PLAN", transaction.getPlanId());
        // TRUE if its monthly payment ,FALSE if its single pay(Annual)
        transInfo.put("IS_RECURRING", transaction.getRecurring().toString());
        transInfo.put("COUNTRY_NAME", transaction.getBillingAddress().getCountryName());
        transInfo.put("POSTAL_CODE", transaction.getBillingAddress().getPostalCode());
        return transInfo;
    }
    
    public static Map<String, String> getSubscriptionInfo(String customerId, int nthCreditCard, int nthSubscription) throws ParseException {
    	HashMap<String, String> info = new HashMap<String, String>();
    	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		sdf.setTimeZone(TimeZone.getTimeZone("PST"));
    	Subscription subscription = gateway.customer().find(customerId).getCreditCards().get(nthCreditCard).getSubscriptions().get(nthSubscription);
    	
    	info.put("subscription_status", subscription.getStatus().toString());
    	info.put("plan_id", subscription.getPlanId());    	
    	info.put("first_billing_date", sdf.format(subscription.getFirstBillingDate().getTime()));   	
    	info.put("billing_end_date", sdf.format(subscription.getBillingPeriodEndDate().getTime()));
    	    	
    	return info;
    }

	public static Map<String, String> getSubscriptionInfonew(String customerId, int nthCreditCard, int nthSubscription)  {
		HashMap<String, String> info = new HashMap<>();

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
		Subscription subscription = gateway.customer().find(customerId).getCreditCards().get(nthCreditCard).getSubscriptions().get(nthSubscription);

		info.put("subscription_status", subscription.getStatus().toString());
		info.put("plan_id", subscription.getPlanId());
		info.put("billing_date", sdf.format(subscription.getBillingPeriodStartDate().getTime()));
		info.put("billing_end_date", sdf.format(subscription.getBillingPeriodEndDate().getTime())); //billing end date (or) subscription end date
		info.put("next_billing_date", sdf.format(subscription.getNextBillingDate().getTime()));
		info.put("transaction_id" , subscription.getTransactions().get(subscription.getTransactions().size()-1).getId());
		return info;
	}

    public static HashMap<String, String> getCreditCardVerificationErrors(String tokenId) {
        HashMap<String, String> creditCardInfo = new HashMap<String, String>();
        CreditCardVerificationSearchRequest request = new CreditCardVerificationSearchRequest().id().is(tokenId);
        ResourceCollection<CreditCardVerification> collection = gateway.creditCardVerification().search(request);

        for (CreditCardVerification verification : collection) {
            creditCardInfo.put("BT_Avs_Response_Code", String.valueOf(verification.getAvsErrorResponseCode()));
            creditCardInfo.put("BT_Avs_Postal_Response_Code",
                    String.valueOf(verification.getAvsPostalCodeResponseCode()));
            creditCardInfo.put("BT_Cvv_Response_Code", String.valueOf(verification.getCvvResponseCode()));
            creditCardInfo.put("BT_Processor_Response_Code", String.valueOf(verification.getProcessorResponseCode()));
            creditCardInfo.put("BT_Processor_Response_Text", String.valueOf(verification.getProcessorResponseText()));
            creditCardInfo.put("BT_Gateway_Rejection_Reason", String.valueOf(verification.getGatewayRejectionReason()));
            creditCardInfo.put("BT_Status", String.valueOf(verification.getStatus()));
            creditCardInfo.put("BT_CountryName", String.valueOf(verification.getBillingAddress().getCountryName()));
        }

        return creditCardInfo;
    }
    

	//UPDATE CREDIT CARD EXPIRE DATE OF USER
	public static void updateCreditCardExpiredDate(String customerId, int nthCreditCard, int nthSubscription,String expiredDate) throws ParseException {
		Subscription subscription = gateway.customer().find(customerId).getCreditCards().get(nthCreditCard).getSubscriptions().get(nthSubscription);
		String token=subscription.getPaymentMethodToken();
		PaymentMethodRequest updateRequest = new PaymentMethodRequest().expirationDate(expiredDate).options().verifyCard(false).done();
		gateway.paymentMethod().update(token, updateRequest);
	}


	//UPDATE CREDIT CARD EXPIRE DATE OF USER
	public static void updateCreditCardExpiredDateInTrialPeriod(String customerId, int nthCreditCard,String expiredDate) throws ParseException {
		//Subscription subscription = gateway.customer().find(customerId).getCreditCards().get(nthCreditCard);
		CreditCard creditCard = gateway.customer().find(customerId).getCreditCards().get(nthCreditCard);
		String token=creditCard.getToken();
		PaymentMethodRequest updateRequest = new PaymentMethodRequest().expirationDate(expiredDate).options().verifyCard(false).done();
		gateway.paymentMethod().update(token, updateRequest);
	}

    public static int getTotalCreditCards(String customerId) {
    	return gateway.customer().find(customerId).getCreditCards().size();
    }

	public static String getDefaultCardLast4Digit(String customerId) {
		String defaultCardLast4Number = null;
		List<CreditCard> userCards = gateway.customer().find(customerId).getCreditCards();
		for (CreditCard card : userCards) {
			if (card.isDefault()) {
				defaultCardLast4Number = card.getLast4();
				break;
			}
		}
		if (defaultCardLast4Number == null) {
			return "";
		} else {
			return defaultCardLast4Number;
		}
	}
    
    public static String getCreditCardToken(String customerId,String cardLast4Digit) {
    	String cardToken=null;
    	List<CreditCard> userCards= gateway.customer().find(customerId).getCreditCards();
    	System.out.println("size ......"+userCards.size());
    	for(CreditCard card:userCards) {
    		if(card.getLast4().equalsIgnoreCase(cardLast4Digit)) {
    			cardToken=card.getToken();
    			break;
    		}
    	}    	
    	return cardToken;    	
    }
    
    public static String getCardLast4Digit(String customerId,int nthCreditCard) {
    	return gateway.customer().find(customerId).getCreditCards().get(nthCreditCard).getLast4();
    }
    
	public static void deleteCustomer(String cutomerId) {
		try {
			Result<Customer> result = gateway.customer().delete(cutomerId);
			if (result.isSuccess() == true) {
				System.out.println("Customer deleted..");
			} else {
				System.out.println("Customer account is not deleted..");
			}
		} catch (NotFoundException e) {
			System.out
					.println("Customer account is not available in Braintree");
		}

	}
}
