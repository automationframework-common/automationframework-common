package com.rpxcorp.testcore.element;

import com.rpxcorp.testcore.page.StaticPage;
import org.jsoup.select.Elements;

public class StaticElement {
    StaticPage page;
    String selector;
    public StaticElement(StaticPage page, String selector){
        this.page=page;
        this.selector=selector;
    }

    public String getText() {
        return page.getDoc().select(selector).text();
    }
    public Elements getElements(){
        return page.getDoc().select(selector);
    }
}
