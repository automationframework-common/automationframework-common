package com.rpxcorp.analyst;

import com.google.gson.JsonElement;
import com.jayway.jsonpath.DocumentContext;
import com.rpxcorp.testcore.Assert;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.ExcelUtil;
import com.rpxcorp.testcore.util.HTTPUtil;
import com.rpxcorp.testcore.util.SQLProcessor;
import org.testng.*;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;
import java.io.IOException;

import java.net.URLEncoder; 
import java.util.HashMap;
import java.util.Properties;

public class APITest implements ITest{
    public static final Properties config = ConfigUtil.config();
    protected static ThreadLocal<HTTPUtil> httpCache = new ThreadLocal<HTTPUtil>();
    HTTPUtil solr=new HTTPUtil(config.getProperty("SOLR_URL"),config.getProperty("SOLR_UNAME"),config.getProperty("SOLR_PSWD"));
    static final ExcelUtil excelData = new ExcelUtil(config.get("testResourcesDir") + "/test_data/APITestData.xls");
    SQLProcessor sql= new SQLProcessor();
    String testScenario,testCase, apiPath, params,method,assertion, jsonPath,  expected,openTicket;
    private boolean isDbQuery;


    @Test
    public void verifyApi() throws Exception {

        //******* REQUEST SOLR

        String formedApiPath = formApiPath(this.apiPath,this.params);

        DocumentContext json = getHttpApi().getJSON(formedApiPath+"");

        //******* PROCESS EXPECTED RESULT
        JsonElement actual = json.read(jsonPath);
//        System.out.println("Actual : "+actual);

        if(!isDbQuery)
            Assert.isEquals(actual,expected);
        else{
            if(assertion.equals("Simple"))
            Assert.isEquals(actual,sql.getSingleValue(sql.getResultDataFromQuery(expected, null),  1));
//            if(assertion.equals("Deep")){
////            System.out.println("Expected: "+sql.aliasToJson(sql.getResultDataFromQuery(expected, null)));
//            Assert.isEquals(actual,sql.aliasToJson(sql.getResultDataFromQuery(expected, null)));
//            }
        }
    }

    //***  CONFIGURATION

    @Factory(dataProvider = "testData")
    public APITest(String testScenario, String testCase, String apiPath, String params,String method,String assertion,String jsonPath, String expected,String openTicket){
        this.testScenario=testScenario;
        this.testCase=testCase;
        this.apiPath=apiPath;
        this.params=params;
        this.method=method;
        this.assertion=assertion;
        this.jsonPath=jsonPath;
        this.expected=expected;
        this.openTicket=openTicket;
    }

    @BeforeClass
    public void setupTest() throws Exception {
        this.isDbQuery=expected.toLowerCase().startsWith("select");
    }

    @DataProvider
    public static Object[][] testData(ITestContext context) throws IOException {
        return excelData.getAllDataFromColumn(3, new Object[] { 0, 1, 2, 3, 4,5,6,7,8});
    }

    @Override
    public String getTestName() {
        return this.testScenario+";"+this.testCase+";"+config.getProperty("BASE_URL")+this.apiPath+";"+this.params+";"+this.method+";"+this.assertion+";"
                +this.jsonPath+";"+this.expected+";"+this.openTicket;
    }

    //***  HELPER METHODS
    public HTTPUtil getHttpApi() throws Exception {
        HTTPUtil analystAPI= httpCache.get();
        if(analystAPI == null) {
            analystAPI = new HTTPUtil(config.getProperty("BASE_URL"));
            HashMap<String, String> header = new HashMap<>();
//            params.put("username", config.getProperty("USERNAME"));
//            params.put("password", config.getProperty("PASSWORD"));
            header.put("Content-Type","application/json");
            analystAPI.get("/#/");
            analystAPI.post("/auth/user/oauth_login", "{\"username\": \"srenganathan_c@rpxcorp.com\"," +
                    " \"password\": \"RPX@2015\"}", header);
            httpCache.set(analystAPI);
        }
        return analystAPI;
    }

    // Forming API Path with dyanamic data
    public String formApiPath(String apiPath,String params) throws  Exception{
        String resourceId="",formedPath="";
        String solrpartialurl="";
        if(apiPath.contains("fromSolr")){
            String q = params.split(";")[0];
            String fl = params.split(";")[1];
            String solrjsonpath = apiPath.split("fromSolr")[1];

            q=q.split("q=")[1];
            q = URLEncoder.encode(q,"UTF-8");

            solrpartialurl = "analyst_pats_app/select?q="+q+"+&"+fl+"&rows=1&wt=json";

            DocumentContext json = solr.getJSON(solrpartialurl);
            resourceId=json.read(solrjsonpath,String[].class)[0];
            System.out.println("ResourceId:"+resourceId);
        }
        for(int i=0;i<apiPath.split("/").length-1;i++)
            formedPath = formedPath+apiPath.split("/")[i]+"/";

        formedPath=formedPath+resourceId;

    return formedPath;
    }
}