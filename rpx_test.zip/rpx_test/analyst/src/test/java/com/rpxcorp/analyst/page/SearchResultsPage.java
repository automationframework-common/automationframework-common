package com.rpxcorp.analyst.page;

import com.rpxcorp.testcore.element.Element;
import org.openqa.selenium.By;

public class SearchResultsPage extends BasePage {

    @Override
    public boolean at() {
//        patentCountHeader.waitUntilVisible();
        return (patentCountHeader.waitUntilVisible()) ;
    }

    public final Element patentCountHeader = $(".patent-count");
   public final Element patSearchVariationModalCloseBtn = $("span.close i.fa-close");
    public final Element resultPatentLink = $(".patent-grid-container .patent-link");
    public final Element multipleMatchesFoundErrorMsg = $(By.xpath("//*[contains(text(),'Multiple Matches Found')]"));
    public final Element noMatchesFoundErrorMsg = $(By.xpath("//*[contains(text(),'No Matches Found')]"));


}