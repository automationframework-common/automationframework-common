package com.rpxcorp.analyst.test;

import com.rpxcorp.analyst.page.PatentDetailPage;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class PatentTest extends BaseFuncTest {
PatentDetailPage patent;

    @BeforeClass
    public void loginToApp(){
        login(config.getProperty("READONLYUSER"), config.getProperty("READONLYPWD"));
    }

    @Test(description = "Verify Patent header details",groups = "smoke_test",priority = 0)
    public void checkPatentStatus() throws Exception {
        String ID="US6666666B1";
        to(patent,ID);
        patent.patent_Overview.waitUntilVisible();
        //Hard coded value
        assertEquals(patent.patent_Overview.getData("pub_numb"),"US 20030223896 A1");
        //Dynamic DB validation
        assertEquals(patent.patent_Overview.getData("status"),getSingleData("Patent.STATUS",ID,"patent_status"));
    }

    @AfterClass
    public void logoutFromApp(){
        logout();
    }



}
