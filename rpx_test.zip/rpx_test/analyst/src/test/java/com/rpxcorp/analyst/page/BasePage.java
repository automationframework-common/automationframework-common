package com.rpxcorp.analyst.page;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.Page;
import org.openqa.selenium.By;

public abstract class BasePage extends Page {

    public final Element login_button = $("input[value*='Login']");
    public final Element dashboardLink = $(By.xpath("//header//a[text()='Dashboard']"));


    //    public final Element pageTitle = $("#content h1");


    // To Force each page object to implement at method
    abstract public boolean at();

    // asserting page title in at method of required page
    public boolean assertPageTitle(String title) {
        login_button.waitUntilVisible();
        return login_button.waitUntilVisible();
    }


}
