package com.rpxcorp.analyst.test;


import com.rpxcorp.analyst.page.HomePage;
import com.rpxcorp.analyst.page.LoginPage;
import com.rpxcorp.analyst.page.SearchResultsPage;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.ExcelUtil;
import org.testng.annotations.Test;

public class PantetSearchTest extends BaseFuncTest {


	LoginPage login;
	HomePage homePage;
	SearchResultsPage searchResultsPage;
	ExcelUtil testData = new ExcelUtil(ConfigUtil.config().get("testResourcesDir") + "/test_data/DataMetrics.xls");

	
	@Test(priority=1,description="login to analyst application")
	public void validLogin(){
		to(login);
		login("srenganathan_c@rpxcorp.com", "RPX@2015");
		at(homePage);
		assertTrue(homePage.dashboard_link.waitUntilVisible(),"Home Page Not loaded ");
	}

	@Test(priority=2,description="Patent Search with keyword:")
	public void patentSearch(){
		String keyword = "US 9,224,159 B2";
		to(homePage);
		homePage.patentSearchTextArea.sendKeys(keyword);
		assertFalse(homePage.patentSearchErroMessage.isDisplayed(),"The Input data is invalid for Key: "+keyword);
		homePage.patentSearchButton.click();
		at(searchResultsPage);
		assertTrue(searchResultsPage.resultPatentLink.waitUntilVisible(),"Result not displayed for Keyword: US 8,416,651 B2");

	}
	
	

	
}
