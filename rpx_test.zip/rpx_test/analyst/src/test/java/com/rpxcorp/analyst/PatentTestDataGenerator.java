package com.rpxcorp.analyst;

import com.google.gson.JsonSyntaxException;
import com.jayway.jsonpath.DocumentContext;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.ExcelUtil;
import com.rpxcorp.testcore.util.HTTPUtil;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileOutputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Properties;
import java.util.*;

//** Input sheet : resources->testdata->SolrSearchCasesInput
//** Output sheet: resources->testdata->SolrPatSearchData
//** Default env setup : resources ->environment->default.properties


public class PatentTestDataGenerator {
    public static final Properties config = ConfigUtil.config();
    static final ExcelUtil excelData = new ExcelUtil(ConfigUtil.config().get("testResourcesDir") + "/test_data/SolrSearchCasesInput.xlsx");
    HTTPUtil solr = new HTTPUtil(config.getProperty("SOLR_URL"),config.getProperty("SOLR_UNAME"),config.getProperty("SOLR_PSWD"));
    private String solrUrl;
    private String collections = "analyst_pats_search_app";
    private String[] actual;
    private DocumentContext json;
    private boolean success = true;
    private int min_patnum_length = 3;  // min patnum length - used for searching patnum with different length
    private int max_patnum_length = 20; // max patnum length - used for searching patnum with different length
    private Workbook outputWorkbook = new XSSFWorkbook();
    private Sheet outputsheet = outputWorkbook.createSheet();
    private int rowIndex = 1;


    @BeforeClass
    public void setupOutputSheet() {
        createOutputSheetHeaders(this.outputsheet);
    }

    @Test(priority = 1, description = "Patent Search with keyword:", dataProvider = "SearchInput")
    public void SearchDataGenerator(HashMap<String, String> searchData) throws Exception {
        String actualJsonPath = "$..patnum"; //To read patnum from the solr json output
        String patentStatusFacetPath = "$.facet_counts.facet_fields.patent_status"; //To read the patent statue facet list from the solr output
        String docKindCodeFacetPath = "$.facet_counts.facet_fields.doc_kind_code"; //To read the doc kind code facet list from the solr output
        String fq; //Used to define fq in the solr url
        String searchKeywordPatnum; //Used to save the sample patnum fetched using this data generator utility

        //Form the solr query to fetch the doc kind code for different country code and get the json output
        //Sample : q:country_Code:US (US fetched from data sheet) , fq:empty ,Facet:doc_kind_code
        generateJsonOutput("country_code:" + searchData.get("country_code"), "", "", "doc_kind_code");
        //Read the facet value alone and not facet count and store in the docKindCodeList
        ArrayList<String> docKindCodeList = getflValueOrFacetList(docKindCodeFacetPath);
        this.json = null;
        //If there is any error  - either solr down or facet times out, then error will be stored in list(0).
        //If that is the case , query formed will be q:countryy_code:US , fq:doc_kind_code:error ,fl:patnum
        //To avoid this unnecessary load to solr  (i.e, f=doc_kind_Code:error) , the below condition is checked
        if (!(docKindCodeList.get(0).equalsIgnoreCase("Error"))) { //If there is a valid doc kind code list ,iterate thru each doc_kind_code ,  hit solr with q,f and fl and get the sample patnum
            // Example : q=country_code:US , fq=doc_kind_code:A1 ,fl=patnum
            for (int i = 0; i < docKindCodeList.size(); i++) // needs to be edited once result is changed to list
            {
                fq = "doc_kind_code:" + docKindCodeList.get(i);
                generateJsonOutput("country_code:" + searchData.get("country_code"), fq, "patnum", "");
                searchKeywordPatnum = getflValueOrFacetList(actualJsonPath).get(0); // There will be only one element in the list and that will be the patnum and hence get(0)
                writeOutput(this.rowIndex, searchData.get("country_code"), fq, searchKeywordPatnum);
            }
        }
//
        //Form the solr query to fetch the patent_status for different country code and get the json output
        //Sample : q:country_Code:US (US fetched from data sheet) , fq:empty ,Facet:patent_status
        generateJsonOutput("country_code:" + searchData.get("country_code"), "", "", "patent_status");
        ArrayList<String> patentStatusList = getflValueOrFacetList(patentStatusFacetPath);
        this.json = null;
        //If there is any error  - either solr down or facet times out, then error will be stored in list(0).
        //If that is the case , query formed will be q:countryy_code:US , fq:patent_status:error ,fl:patnum
        //To avoid this unnecessary load to solr  (i.e, f=patent_status:error) , the below condition is checked
        if (!(patentStatusList.get(0).equalsIgnoreCase("Error"))) {
            //If there is a valid doc kind code list ,iterate thru each doc_kind_code ,  hit solr with q,f and fl and get the sample patnum
            // Example : q=country_code:US , fq=patent_status="Issued patent" ,fl=patnum
            //Note: As patent_status field is a 2 word double quotes is introduced for the value . ex:"Issued patent"
            for (int i = 0; i < patentStatusList.size(); i++) //this needs to be edited after the list changes.
            {
                fq = "patent_status:\"" + patentStatusList.get(i) + "\"";
                generateJsonOutput("country_code:" + searchData.get("country_code"), fq, "patnum", "");
                searchKeywordPatnum = getflValueOrFacetList(actualJsonPath).get(0);// There will be only one element in the list and that will be the patnum and hence get(0)
                writeOutput(this.rowIndex, searchData.get("country_code"), fq, searchKeywordPatnum);
            }
        }
        //Get patnum samples based on patnum length(Interate from min to max patnum length)
        for (int i = min_patnum_length; i <= max_patnum_length; i++) {
            fq = "patnum:/.{" + i + "}/";
            generateJsonOutput("country_code:" + searchData.get("country_code"), fq, "patnum", "");
            searchKeywordPatnum = getflValueOrFacetList(actualJsonPath).get(0);
            //A country code might not have patnum of some length , say US patent may not have patnum of length 3, in such case Error will be the output
            //To avoid such entry written in the output file , the below check is made.
            //Note: This check is not done for the doc kind code and patent status because we are always hitting with the valid doc kind code and patent status based list got from the faceting step
            if (!searchKeywordPatnum.equalsIgnoreCase("error"))
                writeOutput(this.rowIndex, searchData.get("country_code"), fq, searchKeywordPatnum);
        }


    }
    //This function frames solr url using  getSolrUrl function with the given input q, fq , fl (or) q and facet and makes a http request
    //The response json will be stored in the global variable json


    public void generateJsonOutput(String q, String fq, String fl, String facet) throws Exception {

        this.solrUrl = getSolrUrl(q, fq, fl, facet);
        System.out.println("URL: " + solr.getFullUrl(solrUrl.toString()));

//        DocumentContext json;
        // If test application is Analyst, we need Solr Hit retry mechanism for 5 times
        // because first few hits return exception(known issue)
        for (int i = 1; ; i++) {

            try {

                json = solr.getJSON(solrUrl.toString()); //Make http request
                break;
            } catch (JsonSyntaxException e) {
                System.out.println(i + "th Attempt Made for:" + q);
                if (i == 5) {
                    this.success = false;
                    break;
                }
            }
        }
    }
    //This function takes the solr json output (Stored in the global variable json) and the jsonpath as input
    //This is used to get the facet list or the fl value(in our case : patnum) and returns as a list

    public ArrayList<String> getflValueOrFacetList(String actualJsonPath) throws Exception {
        ArrayList<String> result = new ArrayList<String>();
        if (success) {
            try {
                this.actual = json.read(actualJsonPath, String[].class);
                //If only fl(i.e, patnum) , first element alone will be sent
                //If
                if (actual.length == 0) //this case may not be possible but I encountered this case. it was not throwing exception when the json was empty.So added this
                {
                    result.add("Error");
                }
                for (int i = 0; i < actual.length; i = i + 2) {
                    //If fl (i.,e patnum in our case) is the output , then only the first element in the list will have value
                    //IF facet list is the output , then the json will be a comma separated value of facet value and count.i.e, 0th element will be the facet value ,1th element will be the count,2nd element will be next facet value , 3rd element will be next facet count and hence forth.
                    //So , the increment is by 2 (to ignore the count and fetch only the facet list.
                    result.add(actual[i]);
                }

            } catch (Exception e) {
                result.add("Error");
            }
        } else
            // result[0] = "Error";
            result.add("Error");

        //result=result1.toArray(result);
        return result;
    }

    // This function is used to frame solr url by taking q,fq and fl (or) q,facet as input.
    private String getSolrUrl(String q, String fq, String fl, String facet) throws Exception {

        StringBuffer solrUrl = new StringBuffer();
        solrUrl.append(this.collections + "/select?");


        if (!q.isEmpty()) {
            solrUrl.append("q=").append(URLEncoder.encode(q, "UTF-8"));

        }
        if (!fq.isEmpty()) {
            solrUrl.append("&fq=").append(URLEncoder.encode(fq, "UTF-8"));
        }

        if (!fl.isEmpty())
            solrUrl.append("&fl=").append(fl);

        if (fl.isEmpty() && !facet.isEmpty()) {
            solrUrl.append("&facet.field=").append(URLEncoder.encode(facet, "UTF-8"));
            solrUrl.append("&facet.mincount=1&facet=on");
        }
        solrUrl.append("&rows=1&wt=json&indent=true");
        return solrUrl.toString();

    }


    @DataProvider(name = "SearchInput")
    public Object[][] getAnonymousData() {
        return excelData.getAllDataFromColumnAsMap("SolrSearchInput", 1, (excelData.getRowCount("SolrSearchInput") - 1));
    }

    //This function is used to create the output file header
    public void createOutputSheetHeaders(Sheet outputsheet) {
        outputsheet.createRow(0);

        outputsheet.getRow(0).createCell(0);
        outputsheet.getRow(0).createCell(1);
        outputsheet.getRow(0).createCell(2);

        outputsheet.getRow(0).getCell(0).setCellValue("Country_Code");
        outputsheet.getRow(0).getCell(1).setCellValue("fq_Conditions");
        outputsheet.getRow(0).getCell(2).setCellValue("Search_Keyword");

    }

    public void writeOutput(int index, String country_code, String fq_condition, String patnum_keyword) {
        this.outputsheet.createRow(index);
        //this loop creates 3 empty cells
        for (int i = 0; i < 3; i++) {
            this.outputsheet.getRow(index).createCell(i);
        }
        //The below statements writes the value in the 3 empty cell in the current row.
        this.outputsheet.getRow(index).getCell(0).setCellValue(country_code);
        this.outputsheet.getRow(index).getCell(1).setCellValue(fq_condition);
        this.outputsheet.getRow(index).getCell(2).setCellValue(patnum_keyword);

        this.rowIndex++;
    }

    @AfterClass
    public void writeResults() throws Exception {
        outputWorkbook.write(new FileOutputStream(new File(config.get("testResourcesDir") + "/test_data/SolrPatSearchData.xlsx")));
    }


}
