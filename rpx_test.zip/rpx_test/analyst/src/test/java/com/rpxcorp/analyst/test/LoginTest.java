package com.rpxcorp.analyst.test;

import com.rpxcorp.analyst.page.HomePage;
import com.rpxcorp.analyst.page.LoginPage;
import org.testng.annotations.Test;


public class LoginTest extends BaseFuncTest {
    LoginPage login;
    HomePage homePage;

    @Test(description = "Login to Analyst Application")
    public void checkGuestUserLogin() throws InterruptedException {
        login(config.getProperty("READONLYUSER"), config.getProperty("READONLYPWD"));
        assertTrue(homePage.dashboard_link.isDisplayed(),"Login is not successful");
    }
}
