package com.rpxcorp.analyst;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.jayway.jsonpath.DocumentContext;
import com.rpxcorp.testcore.Assert;
import com.rpxcorp.testcore.Assertion;
import com.rpxcorp.testcore.util.*;
import org.postgresql.jdbc4.Jdbc4ResultSet;
import org.testng.ITest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.util.*;

public class SolrDbTest extends Assertion implements ITest{
    public static final Properties config = ConfigUtil.config();
    static final ExcelUtil excelData = new ExcelUtil(config.get("testResourcesDir")
            + "/test_data/SolrDbTestData.xls");

    SQLProcessor sql= new SQLProcessor();
    HTTPUtil solr=new HTTPUtil(config.getProperty("SOLR_URL"),config.getProperty("SOLR_UNAME"),config.getProperty("SOLR_PSWD"));
    private final String testScenario;
    private final String testCase;
    private final String collection;
    private String q;
    private final String fq;
    private final String fl;
    private final String rawQueryParam;
    private final String actualJsonPath;
    private final String assertionCondition;
    private String expected;
    private final String openTicket;
    private String solrUrl;
    private boolean isDbQuery;
    static HashMap<String,String> solrCore= new HashMap<>();
    String[] fq_data;
    String rowCount="20";
    String fromDate=null,toDate=null;
    private boolean isDLATest= false;
    private String solrcount;
    private String dbcount;

    @Test
    public void verifySolr() throws Exception {
        this.solrUrl=getSolrUrl();
        if(isDLATest){
            expected=expected.replaceAll("now()",toDate);
        }
        DocumentContext json;
        // If test application is Analyst, we need Solr Hit retry mechanism for 5 times
        // because first few hits return exception(known issue)

        for(int i = 1 ;  ; i ++)
        {
            try
                {
                    json = solr.getJSON(solrUrl.toString());
                    break;
            }
            catch (JsonSyntaxException e)
            {
                System.out.println(i+"th Attempt Made for:"+this.q);
                if(i == 5)
                {
                    throw e;
                }
            }

        }

    	String[] actual = json.read(actualJsonPath,String[].class);
        Object expectedResult;
    	if(expected.toLowerCase().contains("select")){
    		expectedResult= sql.getResultDataFromQuery(expected,null);
    	}else {
    		expectedResult=expected;
    	}
    	assertOutput(actual,assertionCondition,expectedResult);
    }

    //***  CONFIGURATION
    @Factory(dataProvider = "testData")
    public SolrDbTest(String testScenario, String testCase, String collection, String q, String fq,
                      String fl, String rawQueryParam, String actualJsonPath, String assertionCondition, String expected, String openTicket){
        this.testScenario=testScenario;
        this.testCase=testCase;
        this.collection=collection;
        this.q=q;
        this.fq=fq;
        this.fl=fl;
        this.rawQueryParam=rawQueryParam;
        this.actualJsonPath=actualJsonPath;
        this.assertionCondition=assertionCondition;
        this.expected=expected;
        this.openTicket = openTicket;
    }
    
    @DataProvider
    public static Object[][] testData() throws Exception {
        int sheetno = 0;
        if(config.get("MODULE").equals("PriorArts"))
            sheetno=1;

        return excelData.getAllDataFromColumn(sheetno, new Object[] { 0, 1, 2, 3, 4, 5,6,7,8,9,10});

    }
    
    @Override
    public String getTestName() {
        return this.testScenario+";"+this.testCase+";"+this.collection+";"+this.q+";"+this.fq+";"
                +this.fl+";"+this.rawQueryParam+";"+this.actualJsonPath+";"+this.assertionCondition+";"+this.expected+";"
                +config.getProperty("SOLR_URL")+this.solrUrl+";"+this.openTicket+";"+this.solrcount+";"+this.dbcount;
    }
    
    // **** HELPER METHODS   **** /
    
    public String getSolrUrl() throws UnsupportedEncodingException {
        StringBuffer solrUrl = new StringBuffer();
        solrUrl.append(this.collection);

        if(!rawQueryParam.contains("spellcheck=true")) {
            solrUrl.append("/select?");
        }else {
            solrUrl.append("/spell?spellcheck.");
        }
        if(!q.isEmpty()) {
            solrUrl.append("q=").append(URLEncoder.encode(q, "UTF-8") );
        }

        if(!fq.isEmpty())
        { //Handle multiple fq inputs by splitting using delimiter ,fq=
            fq_data=fq.split(",fq=");
            for(String fq1:fq_data) {
                solrUrl.append("&fq=").append(URLEncoder.encode(fq1, "UTF-8"));
            }
        }

        if(!fl.isEmpty())
          solrUrl.append("&fl=").append(fl);
        if(!rawQueryParam.isEmpty())
         solrUrl.append("&").append(rawQueryParam);

        solrUrl.append("&rows="+rowCount+"&wt=json&indent=true");
        return solrUrl.toString();
    }
    // TODO Need to migrate to common assertion class
    private void assertOutput(String[] actualArray, String operation, Object expected) throws Exception {
    	ArrayList<String> actual = new ArrayList<String>(Arrays.asList(actualArray));
    	String jsonKey=null;
    	Boolean isUniqueData=false;
    	String filterCondition=null;

    	if(operation.contains(",")) {
    	    String jsonFilters[]=operation.split(",");
    	    operation=jsonFilters[0];
            filterCondition=jsonFilters[1];
    	    jsonKey=jsonFilters[2];
            isUniqueData=Boolean.getBoolean(jsonFilters[3]);
        }
        switch (operation){
            case "contains":
                assertTrue(actual.contains(((String) expected).toLowerCase())
                        ,actual+" not "+operation+" expected value \""+expected+"\"");
                break;
            case ">=":
                if(expected.getClass()== Jdbc4ResultSet.class)
                    expected=sql.getSingleValue((ResultSet) expected,1);
                int actualValue = Integer.parseInt(actual.get(0));           
                assertTrue(actualValue >=  Integer.parseInt((String) expected),
                        actual+" "+operation+" "+expected);
                break;
            case "=":
                if(expected.getClass()== Jdbc4ResultSet.class) {
                    ResultSet resultSet = (ResultSet) expected;
                    int size=sql.getResultCount(resultSet);
                    Set<String> uniqueSet = new HashSet<String>((ArrayList)actual);
                    if(uniqueSet.size() == 0 && isDLATest){
                        assertEquals(actual,sql.getListValue(resultSet, 1));
                        break;
                    }
                    if(actual.size() ==1 && size == 1) {
                        expected = sql.getSingleValue(resultSet, 1);
                    }else {
                        assertEquals(actual,sql.getListValue(resultSet, 1));
                        break;
                    }
                }
//                System.out.println("Expected: "+expected.toString()+"Actual: "+actual.get(0));
                this.solrcount= actual.get(0);
                this.dbcount=expected.toString();
                assertEquals(actual.get(0),expected);
                break;
            case "uniqueData":
                Set<String> uniqueSet = new HashSet<String>((ArrayList)actual);
                ArrayList<String> actualData=new ArrayList<String>();
                actualData.addAll(uniqueSet);
                if(expected.getClass()== Jdbc4ResultSet.class) {
                    ResultSet resultSet = (ResultSet) expected;
                    if (uniqueSet.size() == 0 && isDLATest) {
                        assertEquals(uniqueSet.size(), sql.getResultCount(resultSet));

                    } else {
                        System.out.println(actualData+" "+sql.getListValue(resultSet,1));
                        assertEquals(actualData,sql.getListValue(resultSet,1));
                    }
                }
                    break;
            case "getDataFromFlatJson"://This assertion will compare unique data from flat Json and DB Results
                ResultSet resultSet=null;
                int size;
                if(expected.getClass()== Jdbc4ResultSet.class) {
                    resultSet = (ResultSet) expected;
                    expected = sql.getListValue(resultSet,1);

                }
                actual=getFilteredDataFromFlatJson(actual,filterCondition,jsonKey,isUniqueData);
                System.out.println(actual.getClass()+" "+expected.getClass());
                if(actual.size()==0) {
                    size=sql.getResultCount(resultSet);
                    assertEquals(actual.size(),size);
                    break;
                }
                assertEquals(actual,expected);
                break;

        }
    }

    private ArrayList<String> getFilteredDataFromFlatJson(ArrayList<String> jsonPathData,String filterCondition, String jsonKey, Boolean isUniqueData) {
        ArrayList<String> filteredJsonData=new ArrayList<>();
        ArrayList<String> finalFilteredJsonData = filteredJsonData;
        String filterKey = null,filterValue=null;
        //check if we pass any condition(is_newcampaign=true) to filter data from json
        Boolean isfilterData=(!filterCondition.isEmpty());
        if(isfilterData) {
            filterKey = filterCondition.split("=")[0];
            filterValue = filterCondition.split("=")[1];
        }
        for (String data : jsonPathData) {
            //remove[,] at start and at end position to get a json file format in case of such test data ex:[{key:value}]
            if(data.startsWith("[")){
                data=data.replaceFirst("\\[","").replaceAll("\\]$","");
            }
            JsonObject jsonObject = ConfigLoader.loadFlatJsonData(data);
            if (isfilterData) {
                //filter condition ex:is_new_campaign=true
                if (jsonObject.get(filterKey).toString().equalsIgnoreCase(filterValue)){
                        finalFilteredJsonData.add(jsonObject.get(jsonKey).getAsString());
                }
            } else {
                finalFilteredJsonData.add(jsonObject.get(jsonKey).getAsString());
            }
        }
        if(isUniqueData) {
            Set<String> uniqueSet = new HashSet<String>((ArrayList)filteredJsonData);
            filteredJsonData=new ArrayList(Arrays.asList(uniqueSet));
        }

        return filteredJsonData;
    }

}