package com.rpxcorp.analyst.test;

import com.paulhammant.ngwebdriver.NgWebDriver;
import com.rpxcorp.analyst.page.HomePage;
import com.rpxcorp.analyst.page.LoginPage;
import com.rpxcorp.testcore.UITest;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.HTTPUtil;
import com.rpxcorp.testcore.util.SQLProcessor;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.ITest;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

// TODO Necessary methods has to be added
public class BaseFuncTest extends UITest implements ITest{
    protected static NgWebDriver ngDriver;
    SQLProcessor sqlProcessor = SQLProcessor.getInstance();
    DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
    static final Properties config = ConfigUtil.config();
    protected HashMap<String, String> urlData = new HashMap<String, String>();
    HTTPUtil jenkins = new HTTPUtil("http://ci/job/","dsingaram","GymQ^*Sb");
    String unique_Id= DateFormatUtils.format(new Date(), "ddMMHHmm");
    LoginPage login;
    HomePage homePage;

    @BeforeClass(alwaysRun = true)
    public void setAngularDriver(){
        ngDriver = new NgWebDriver((JavascriptExecutor) getDriver());
        ngDriver.waitForAngularRequestsToFinish();
        System.out.println("NgDriver initiated..");
    }

    @AfterClass(alwaysRun = true)
    public void closeBrowser(){
        clearCacheAndQuit();
    }

    public void login(){
        to(login);
        login.login(config.getProperty("READONLYUSER"), config.getProperty("READONLYPWD"));
        at(homePage);
    }

    public Object getSingleData(String queryKey,String ID,String column) throws Exception {
        return sqlProcessor.getSingleValue(sqlProcessor.getResultData(queryKey,ID),column);
    }


    @Override
	public String getTestName() {		
		return "";
	}


    /** COMMON HELPER METHODS **/

    // LOGIN AND LOGOUT METHODS
    public void login(String userName, String password) {
        to(login);
        login.login(userName, password);
        at(homePage);
    }

    public void logout(){
        homePage.account_Menu_Expand_Arrow.moveTo();
        homePage.logout_Link.waitUntilClickable();
        homePage.logout_Link.click();
        at(login);
    }


}
