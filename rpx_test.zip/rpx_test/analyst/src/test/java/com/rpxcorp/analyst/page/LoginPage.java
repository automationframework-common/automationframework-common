package com.rpxcorp.analyst.page;

import com.paulhammant.ngwebdriver.ByAngularBinding;
import com.rpxcorp.testcore.element.Element;
import org.openqa.selenium.By;

public class LoginPage extends BasePage {

    @Override
    public boolean at() {
        System.out.println("Navigate to Login Page");
        return ngLogin_Btn.waitUntilClickable();
    }

    public final Element ngLogin_Btn=$(ByAngularBinding.linkText("Login"));
    public final Element user_email_TextBox = $(By.id("username"));
    public final Element password_TextBox = $(By.id("user_password"));
    public final Element login_btn = $("input[value*='Login']");
    public final Element ngLogin_Btn_In_Form=$(By.cssSelector(".modal-open button[value='Login']"));


    public void login(String username, String password) {
        ngLogin_Btn.click();
        user_email_TextBox.waitUntilVisible();
        System.out.println(password);
        user_email_TextBox.sendKeys(username);
        password_TextBox.sendKeys(password);
        ngLogin_Btn_In_Form.waitUntilClickable();
        ngLogin_Btn_In_Form.click();
        ngLogin_Btn_In_Form.waitUntilInvisible();
    }



}