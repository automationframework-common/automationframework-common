package com.rpxcorp.analyst.test;

import com.google.gson.JsonElement;
import com.jayway.jsonpath.DocumentContext;
import com.rpxcorp.testcore.Assert;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.ExcelUtil;
import com.rpxcorp.testcore.util.HTTPUtil;
import com.rpxcorp.testcore.util.SQLProcessor;
import org.testng.ITest;
import org.testng.ITestContext;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Properties;

public class APISanityTest implements ITest{
    public static final Properties config = ConfigUtil.config();
    protected static ThreadLocal<HTTPUtil> httpCache = new ThreadLocal<HTTPUtil>();
//    HTTPUtil solr=new HTTPUtil(config.getProperty("SOLR_URL"),config.getProperty("SOLR_UNAME"),config.getProperty("SOLR_PSWD"));
    static final ExcelUtil excelData = new ExcelUtil(config.get("testResourcesDir") + "/test_data/APISanityTestData.xls");
    SQLProcessor sql= new SQLProcessor();
    String testScenario,testCase, apiPath, params,method,assertion, application,  expected,openTicket,action;
    private boolean isDbQuery;
    String appurl="";
    String env = System.getProperty("ENV");


    @Test
    public void verifyApi() throws Exception {
        HashMap<String, String> actualResult=  new HashMap<>();
        System.out.println("Path: " + this.apiPath);
        if(this.application.equals("ANALYST")){
            appurl = this.apiPath;
        }else if(this.application.equals("INSIGHTS")){
            appurl = config.getProperty("INSIGHTS_BASE_URL")+this.apiPath;
        }else if(this.application.equals("PRIORART")){
            appurl = config.getProperty("PRIORART_BASE_URL")+this.apiPath;
        }
        if(this.method.equals("GET")){
        actualResult = getHttpApi().processStatusCodeandresponse(getHttpApi().getFullUrl(appurl +""));
        }
        if(this.method.equals(("POST"))) {
            HashMap<String, String> header = new HashMap<>();
            header.put("Content-Type", "application/json");
//        String result = getHttpApi().post(this.apiPath,this.params,header);
            actualResult = getHttpApi().postandgetfullresult(this.apiPath, this.params, header);
        }
        if(this.method.equals(("PATCH"))) {
            HashMap<String, String> header = new HashMap<>();
            header.put("Content-Type", "application/json");
//        String result = getHttpApi().post(this.apiPath,this.params,header);
            actualResult = getHttpApi().patchandgetfullresult(this.apiPath, this.params, header);
        }

        String actualResponseBody = actualResult.get("responseBody");
        String actualResponseCode = actualResult.get("responsecode");
        System.out.println("responseCode:" + actualResponseCode);
        System.out.println("responseData:" + actualResponseBody);
        if (this.testScenario.contains("Columns") || this.testScenario.contains("Filters") || this.testScenario.contains("Advanced_Search")|| this.testScenario.contains("PriorArtGrid")) {
            if(actualResponseCode.contains("504")) {
                Thread.sleep(60000);
                System.out.println("exiting from timeout");
            }
        }
        Assert.isEquals(actualResponseCode, this.expected);
        Assert.isTrue(isResponseBodyValid(actualResponseBody),"Invalid Responsebody: "+actualResponseBody);


    }

    //***  CONFIGURATION

    @Factory(dataProvider = "testData")
    public APISanityTest(String testScenario, String testCase, String apiPath, String params, String method, String action,String assertion, String application, String expected, String openTicket ){
        if(!(env.trim().toLowerCase().equals("prod") && action.trim().toLowerCase().equals("write"))) {
            this.testScenario = testScenario;
            this.testCase = testCase;
            this.apiPath = apiPath;
            this.params = params;
            this.method = method;
            this.action = action;
            this.assertion = assertion;
            this.application = application;
            this.expected = expected;
            this.openTicket = openTicket;

        }
    }

    @BeforeClass
    public void setupTest() throws Exception {
        this.isDbQuery=expected.toLowerCase().startsWith("select");
    }

    @DataProvider
    public static Object[][] testData(ITestContext context) throws IOException {
        int sheetNo;
        switch (System.getProperty("MODULE")){
            case "All_ReadWrite_APIs":
                sheetNo=0;
                break;
            case "All_ReadOnlyAPIs":
                sheetNo=1;
                break;
            case "Readonly_Solr_APIs":
                sheetNo=2;
                break;
            case "Readonly_Non-Solr_APIs":
                sheetNo=3;
                break;
            case "Prod_Sanity_Cases":
                sheetNo=4;
                break;
            default:
                sheetNo=3;

        }

        return excelData.getAllDataFromColumn(sheetNo, new Object[] { 0, 1, 2, 3, 4,5,6,7,8,9});
    }

    @Override
    public String getTestName() {
        String tempurl = this.appurl;
        if(this.application.equals("ANALYST"))
            tempurl=config.getProperty("BASE_URL")+tempurl;
        return this.testScenario+";"+this.testCase+";"+tempurl+";"+this.params+";"+this.method+";"+this.assertion+";"
                +this.application+";"+this.expected+";"+this.openTicket;
    }

    //***  HELPER METHODS
    public HTTPUtil getHttpApi() throws Exception {
        HTTPUtil analystAPI= httpCache.get();
        if(analystAPI == null) {
            analystAPI = new HTTPUtil(config.getProperty("BASE_URL"));
            HashMap<String, String> header = new HashMap<>();
//            params.put("username", config.getProperty("USERNAME"));
//            params.put("password", config.getProperty("PASSWORD"));
            header.put("Content-Type","application/json");
            analystAPI.get("/#/");
            analystAPI.post("/auth/user/oauth_login", "{\"username\": \""+config.getProperty("USERNAME")+"\"," +
                    " \"password\": \""+config.getProperty("PASSWORD")+"\"}", header);
            httpCache.set(analystAPI);
        }
        return analystAPI;
    }

    // Is Response Body valid
    public boolean isResponseBodyValid(String responseBody) throws  Exception{
            boolean validFlag =false;
            if(responseBody.length()>2){
            if(!(responseBody.contains("\"count\": 0")))
                validFlag =true;
            }
        return validFlag;
    }

}