package com.rpxcorp.analyst;

import com.google.gson.JsonSyntaxException;
import com.jayway.jsonpath.DocumentContext;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.HTTPUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URLEncoder;
import java.util.*;



public class SolrMetricsTest {
    public static final Properties config = ConfigUtil.config();
    HTTPUtil solr=new HTTPUtil(config.getProperty("SOLR_URL"),config.getProperty("SOLR_UNAME"),config.getProperty("SOLR_PSWD"));
    private String solrUrl;
    private String fl = "patnum";
    private String collections="analyst_pats_app";
    private String actualJsonPath = "$..numFound";
    private String[] actual;
    private DocumentContext json;

    @Test
    public void verifySolr() throws Exception {
        File file1 = new File(config.get("testResourcesDir") + "/test_data/SolrMetricsInput.xlsx");
        //FileInputStream file2 = new FileInputStream(new File(config.get("testResourcesDir") + "/test_data/APITestData1.xlsx"));
        Workbook workbook1 = WorkbookFactory.create(file1);
        Workbook workbook2 = new XSSFWorkbook();
        Sheet sheet1 = workbook1.getSheetAt(0);
        Sheet sheet11 = workbook2.createSheet();

        String[][] originalData = new String[sheet1.getLastRowNum()+1][sheet1.getRow(0).getLastCellNum()];

       System.out.println ("Count "+sheet1.getLastRowNum());
        for (int i = 0; i < sheet1.getLastRowNum()+1; i++) {
            sheet11.createRow(i);
            for (int j = 0; j < sheet1.getRow(0).getLastCellNum(); j++) {
                sheet11.getRow(i).createCell(j);
                if (i == 0 || j == 0) {
//                    originalData[i][j] = sheet1.getRow(i).getCell(j).getStringCellValue();
                    sheet11.getRow(i).getCell(j).setCellValue(sheet1.getRow(i).getCell(j).getStringCellValue());
                } else {
                    //TODO
                    // sheet1.getRow(i).getCell(j).getStringCellValue()
                    sheet11.getRow(i).getCell(j).setCellValue(getSolrMetrics("country_code:"+sheet1.getRow(i).getCell(0).getStringCellValue(),sheet1.getRow(0).getCell(j).getStringCellValue()+":*"));
//                    originalData[i][j]=("country_code:"+sheet1.getRow(i).getCell(0).getStringCellValue() +""+ sheet1.getRow(0).getCell(j).getStringCellValue());
//                    originalData[i][j] = getSolrMetrics("country_code:"+sheet1.getRow(i).getCell(0).getStringCellValue(),sheet1.getRow(0).getCell(j).getStringCellValue()+":*");
                }
            }
        }


//        for(int i=0;i<sheet1.getLastRowNum()+1;i++) {
//            System.out.println("");
//            for(int j=0;j<sheet1.getRow(0).getLastCellNum();j++) {
//                System.out.print(originalData[i][j] + "\t");
//            }
//        }

        //excel change
//        System.out.println(config.get("testResourcesDir") + "/test_data/solrmetrics.xlsx");
        workbook2.write(new FileOutputStream(new File(config.get("testResourcesDir") + "/test_data/solrmetrics.xlsx")));
    }

    public String getSolrMetrics(String q,String fq) throws Exception {

        boolean success = true;
        this.solrUrl=getSolrUrl(q,fq);
        //System.out.println("URL: "+solr.getFullUrl(solrUrl.toString()));

//        DocumentContext json;
        // If test application is Analyst, we need Solr Hit retry mechanism for 5 times
        // because first few hits return exception(known issue)
            for(int i = 1 ;  ; i ++)
            {
                try
                {

                    json = solr.getJSON(solrUrl.toString());
                    break;
                }
                catch (JsonSyntaxException e)
                {
                    System.out.println(i+"th Attempt Made for:"+q);
                    if(i == 5)
                    {
                        success = false;
                        break;
                    }
                }

            }
if(success)
        this.actual = json.read(actualJsonPath,String[].class);
            else
                actual[0]="Error";

            return actual[0];

    }
    // form Solr URL
    private String getSolrUrl(String q,String fq) throws Exception{

        StringBuffer solrUrl = new StringBuffer();
        solrUrl.append(this.collections+"/select?");



        if(!q.isEmpty()) {
            solrUrl.append("q=").append(URLEncoder.encode(q, "UTF-8") );

        }
        if(!fq.isEmpty())
        { //Handle multiple fq inputs by splitting using delimiter ,fq=

            solrUrl.append("&fq=").append(URLEncoder.encode(fq, "UTF-8"));
        }

        if(!fl.isEmpty())
          solrUrl.append("&fl=").append(fl);

        solrUrl.append("&rows=10&wt=json&indent=true");
        return solrUrl.toString();

    }
}
