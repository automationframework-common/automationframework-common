package com.rpxcorp.analyst.page;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.page.PageUrl;
import org.openqa.selenium.By;

public class HomePage extends BasePage {

    public HomePage() {
        this.url = new PageUrl("#");
    }

    @Override
    public boolean at() {
        dashboard_link.waitUntilVisible();
        return dashboard_link.waitUntilVisible();
    }



    public final Element dashboard_link = $(By.xpath("//span[text()='My Dashboard']"));
    public final Element patentSearchTextArea = $(".search-text");
    public final Element searchValidationProgressMessage = $(By.xpath("//div[contains(@class,'validation-progress')]"));
    public final Element patentSearchErroMessage = $(By.xpath("//div[contains(@class,'rpx-alert')]"));
    public final Element patentSearchButton = $(".row.search-patents .button");

    public final Element account_Menu_Expand_Arrow=$(By.cssSelector("[class*='account-header'] i[class*='fa-chevron-down']"));
    public final Element logout_Link=$(By.cssSelector("#primary-nav li a[ng-click='$ctrl.logOut()']"));








//    private ROLES loggedInUser;

//    public ROLES getLoggedInUser() {
//        return loggedInUser;
//    }

//    public void setLoggedInUser(ROLES loggedInUser) {
//        this.loggedInUser = loggedInUser;
//    }


    public void searchPatent(String keyWord) {
        patentSearchTextArea.sendKeys(keyWord);
        searchValidationProgressMessage.waitUntilInvisible();
//        if(patentSearchButton.isEnabled())
//            patentSearchButton.click();
    }



}