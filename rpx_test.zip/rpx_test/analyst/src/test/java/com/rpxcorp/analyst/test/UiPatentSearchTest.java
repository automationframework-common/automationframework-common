package com.rpxcorp.analyst.test;


import com.rpxcorp.analyst.page.HomePage;
import com.rpxcorp.analyst.page.SearchResultsPage;
import com.rpxcorp.testcore.util.ConfigUtil;
import com.rpxcorp.testcore.util.ExcelUtil;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;

public class UiPatentSearchTest extends BaseFuncTest {



	HomePage homePage;
	SearchResultsPage searchResultsPage;
	String country_code,fq_condition,patnum_keyword;
	static final ExcelUtil excelData = new ExcelUtil(config.get("testResourcesDir") + "/test_data/UISearchCasesInput.xlsx");
	Workbook outputWorkbook = new XSSFWorkbook();
	Sheet outputsheet = outputWorkbook.createSheet();
	int rowIndex = 1;


	@BeforeClass
	public void validLogin(){
		login(ConfigUtil.config().getProperty("USERNAME"), ConfigUtil.config().getProperty("PASSWORD"));
		assertTrue(homePage.dashboard_link.waitUntilVisible(),"Home Page Not loaded ");
		createOutputSheetHeaders(this.outputsheet);
	}


	@Test(priority=1,description="Patent Search with keyword:",dataProvider = "PatentSearchData")
	public void patentSearch(HashMap<String, String> searchData){

		String result = "";
		try {
			to(homePage);
			homePage.patentSearchTextArea.sendKeys(searchData.get("Search_Keyword"));
			try {
//			if(!(homePage.patentSearchErroMessage.isDisplayed())){
				Thread.sleep(2000);
				System.out.println(homePage.patentSearchErroMessage.getAttribute("aria-hidden"));
				if (homePage.patentSearchErroMessage.getAttribute("aria-hidden").equals("true")) {
					homePage.patentSearchButton.click();
//					at(searchResultsPage);
					try {
						Thread.sleep(6000);
						if (searchResultsPage.resultPatentLink.isDisplayed())
							result = "PASS";
						else if(searchResultsPage.multipleMatchesFoundErrorMsg.isDisplayed()) {
							result = "Multiple Matches Found";
							searchResultsPage.patSearchVariationModalCloseBtn.click();
						}

						else if(searchResultsPage.noMatchesFoundErrorMsg.isDisplayed()) {
							result = "No Matches Found";
							searchResultsPage.patSearchVariationModalCloseBtn.click();
						}

						else
							result = "BACKEND FAIL";
					} catch (Exception e) {
						result = "BACKEND FAIL";
					}
				} else
					result = "UI FAIL";
			} catch (Exception e) {
				result = "UI FAIL";
			}
		}catch(org.openqa.selenium.TimeoutException e){
			getDriver().navigate().refresh();

			if(!homePage.dashboardLink.isDisplayed())
			to(login);
			login(ConfigUtil.config().getProperty("USERNAME"), ConfigUtil.config().getProperty("PASSWORD"));
			result = "Timeout Fail";
		}

		writeOutput(this.rowIndex,searchData.get("Country_Code"),searchData.get("fq_Conditions"),searchData.get("Search_Keyword"),result);
		assertString(result,"PASS");

	}



	@DataProvider(name = "PatentSearchData")
	public Object[][] getAnonymousData() {
		String sheetname=excelData.getAllSheetName()[0];
			return excelData.getAllDataFromColumnAsMap(sheetname, 1,(excelData.getRowCount(sheetname)-1));

	}

	public void createOutputSheetHeaders(Sheet outputsheet){
//		this.outputsheet = outputsheet;
		outputsheet.createRow(0);
		outputsheet.getRow(0).createCell(0);
		outputsheet.getRow(0).createCell(1);
		outputsheet.getRow(0).createCell(2);
		outputsheet.getRow(0).createCell(3);
		outputsheet.getRow(0).getCell(0).setCellValue("Country_Code");
		outputsheet.getRow(0).getCell(1).setCellValue("fq_Conditions");
		outputsheet.getRow(0).getCell(2).setCellValue("Search_Keyword");
		outputsheet.getRow(0).getCell(3).setCellValue("Status");
	}

	public void writeOutput(int index,String country_code,String fq_condition,String patnum_keyword,String result){
		this.outputsheet.createRow(index);
		for(int i=0;i<4;i++){
			this.outputsheet.getRow(index).createCell(i);
			}
		this.outputsheet.getRow(index).getCell(0).setCellValue(country_code);
		this.outputsheet.getRow(index).getCell(1).setCellValue(fq_condition);
		this.outputsheet.getRow(index).getCell(2).setCellValue(patnum_keyword);
		this.outputsheet.getRow(index).getCell(3).setCellValue(result);
		this.rowIndex++;
	}

	@AfterClass
	public void writeResults()throws Exception{
		outputWorkbook.write(new FileOutputStream(new File(config.get("testResourcesDir") + "/test_data/UISearchCasesResults.xlsx")));
	}


}
