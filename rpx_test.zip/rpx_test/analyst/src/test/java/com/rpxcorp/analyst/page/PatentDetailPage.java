package com.rpxcorp.analyst.page;

import com.rpxcorp.testcore.element.Element;
import com.rpxcorp.testcore.element.StaticContent;
import com.rpxcorp.testcore.page.PageUrl;
import com.rpxcorp.testcore.util.Configure;

public class PatentDetailPage extends BasePage {

    public PatentDetailPage(){
        this.url = new PageUrl("#/patent/{ID}");
    }

    @Override
    public boolean at() {
        return patent_Title.waitUntilVisible();
    }

    public final Element patent_Title=$(".mk_patent_header div[title]");
    public final StaticContent patent_Overview = $("div.mk_patent_header", (Configure<StaticContent>) form -> {
        form.content("pub_numb", "span:contains(Pub)+a[ui-sref*='patnum:$ctrl.getPub()']");
        form.content("status", "span:contains(Status:)+span");
    });



}
