function alphanum(a, b) {
    function chunkify(t) {
        var tz = new Array();
        var x = 0, y = -1, n = 0, i, j;

        while (i = (j = t.charAt(x++)).charCodeAt(0)) {
            var m = (i == 46 || (i >=48 && i <= 57));
            if (m !== n) {
                tz[++y] = "";
                n = m;
            }
            tz[y] += j;
        }
        return tz;
    }

    var aa = chunkify(a);
    var bb = chunkify(b);

    for (x = 0; aa[x] && bb[x]; x++) {
        if (aa[x] !== bb[x]) {
            var c = Number(aa[x]), d = Number(bb[x]);
            if (c == aa[x] && d == bb[x]) {
                return c - d;
            } else return (aa[x] > bb[x]) ? 1 : -1;
        }
    }
    return aa.length - bb.length;
}


global.sort = function(arrayToSort, orderBy, sortType) {
    var arrayToProcess = arrayToSort;
    if (orderBy === 'ascending') {
        switch (sortType) {
            case "numeric":
                return arrayToProcess.slice().sort(function (a, b) {
                    return a - b;
                });
            case "date":
                return arrayToProcess.slice().sort(function (a, b) {
                    return new Date(a) - new Date(b);
                });
            case "alphaNum":
                return arrayToProcess.slice().sort(function (a, b) {
                    return alphanum(a, b);
                });
            default:
                return arrayToProcess.slice().sort(function (a, b) {
                    return a.toLowerCase().localeCompare(b.toLowerCase());
                });
        }
    } else {
        switch (sortType) {
            case "numeric":
                return arrayToProcess.slice().sort(function (a, b) {
                    return b - a
                });
            case "date":
                return arrayToProcess.slice().sort(function (a, b) {
                    return new Date(b) - new Date(a);
                });
            case "alphaNum":
                var alphaNumAscSorted = arrayToProcess.slice().sort(function (a, b) {
                    return alphanum(a, b);
                });
                return alphaNumAscSorted.slice().reverse();
            default:
                var stringAscSorted = arrayToProcess.slice().sort(function (a, b) {
                    return a.toLowerCase().localeCompare(b.toLowerCase());
                });
                return stringAscSorted.slice().reverse();
        }
    }
};