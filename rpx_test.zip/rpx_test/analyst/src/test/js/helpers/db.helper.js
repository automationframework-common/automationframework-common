var pg = require("pg");
var queryProcessor = require("./query.processor");

//TODO open and close DB connection per execution instead of per request
var DbHelper = function () {
    this.execute = function (queryObject,field, id) {
        

        // var conString = browser.params.dbConString;
        var conString = 'postgresql://mmurugesan_c:B5OSYwUG@qa-cortaldb:5432/rpx';
        var dbClient;
        var queryString;

        var getQueryString = function () {
            if (typeof id === 'undefined') {
                queryString = queryProcessor.process(queryObject).toQuery();
            } else {
                queryString = queryProcessor.process(queryObject).toQueryWithId(id);
            }
        };

        var connectToDb = function () {
            var deferred = protractor.promise.defer();
            pg.connect(conString, function (error, client) {
                console.log("Connection String: "+conString);
                if (!error) {
                    console.log("*** CONNECTED TO DATABASE ***");
                    dbClient = client;
                    deferred.fulfill(dbClient);
                } else {
                    console.error('*** ERROR IN CONNECTION***', error);
                    deferred.reject(error);
                }
            });
            return deferred.promise;
        };

        var getResult = function () {
            var deferred = protractor.promise.defer();

            dbClient.query(queryString, function (error, result) {
                if (error) {
                    console.log(error, "q_err");
                    throw error;
                } else {
                    dbClient.end();
                    
                    deferred.fulfill(result);
                }
            });
            return deferred.promise;
        };

        var getSingleRowResult = function () {
            var resultsSet = [];
            var deferred = protractor.promise.defer();            
            dbClient.query(queryString, function (error, result) {
                if (error) {
                    console.log(error, "q_err");
                    throw error;
                } else {
                    resultsSet.push(result.rows[0]);
                    console.log("resultsSet: "+resultsSet);
                    dbClient.end();                                
                    deferred.fulfill(result.rows[0]);                    
                }
            });
            return deferred.promise;
        };

        var getSingleFieldValue = function () {
            
            
            var deferred = protractor.promise.defer();            
            this.dbClient.query(queryString, function (error, result) {
                if (error) {
                    console.log(error, "q_err");
                    throw error;
                } else {                  
                    this.dbClient.end();                                
                    deferred.fulfill(result.rows[0][field]);                    
                }
            });
            return deferred.promise;
        };
       
        

        var getRecordsCount = function () {
            var deferred = protractor.promise.defer();

            getResult().then(function (data) {                
                deferred.fulfill(data["rowCount"]);
            });

            return deferred.promise;
        };

        return {
            getData: function () {
                getQueryString();
                var flow = browser.controlFlow();
                flow.execute(connectToDb);
                return flow.execute(getResult);
            },
            getSingleRow: function () {
                getQueryString();
                var flow = browser.controlFlow();
                flow.execute(connectToDb);
                return flow.execute(getSingleRowResult);
            },
            getValueforField: function(){
                getQueryString();
                var flow = browser.controlFlow();
                flow.execute(connectToDb);
                return flow.execute(getSingleFieldValue);
            },
           getConnection : function(){
            getQueryString();
            var flow = browser.controlFlow();
            flow.execute(connectToDb);
           },

           getField : function(){
            getSingleFieldValue();
           },
            
            
            getRecordsCount: function () {
                getQueryString();
                var flow = browser.controlFlow();
                flow.execute(connectToDb);              
                return flow.execute(getRecordsCount);
            }
        }
    };
};
module.exports = new DbHelper();