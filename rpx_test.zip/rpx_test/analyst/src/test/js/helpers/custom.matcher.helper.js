var _ = require("underscore");

var customMatchers = {
    toEqualSort: function() {
        return {
            compare: function (actual, expectedConditions) {
                var sortOrder,
                    sortType;
                var result = {};

                if(expectedConditions === undefined) {
                    sortOrder = "ascending";
                    sortType = "string";
                } else {
                    sortOrder = expectedConditions["order"];
                    sortType = expectedConditions["type"];
                }

                var expected = sort(actual, sortOrder, sortType);

                result.pass = _.isEqual(actual, expected);
                if (result.pass) {
                    result.message = "Array comparison passed";
                } else {
                    result.message = "Expected [" + actual + "] to equal [" + expected + "] after sorting for order: " + sortOrder + " with type: " + sortType;
                }
                return result;
            }
        };
    }
};

beforeEach(function(){
    jasmine.addMatchers(customMatchers);
});