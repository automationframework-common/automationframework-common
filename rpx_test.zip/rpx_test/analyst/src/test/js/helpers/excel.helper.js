var xl = require("exceljs");
var wb = new xl.Workbook();

var Excel = function () {
    this.getData = function (filePath, sheetName) {
        return new Promise(function (resolve, reject) {
            wb.xlsx.readFile(filePath).then(function () {
                var ws = wb.getWorksheet(sheetName);
                var headers = ws.getRow(1).values;

                var tcArr = [];
                ws.eachRow(function (row, rowNumber) {
                    if (rowNumber !== 1) {
                        var rowCells = row.values;
                        var tcObj = {};
                        for (var cCnt = 1; cCnt <= rowCells.length; cCnt++) {
                            tcObj[headers[cCnt]] = rowCells[cCnt];
                        }
                        tcArr.push(tcObj);
                    }
                });
                resolve(tcArr);
            });
        });
    };
};
module.exports = new Excel();