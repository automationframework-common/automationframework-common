var AuthHelper = function () {
    this.getExpectedBool = function (expStatus) {
        if (expStatus !== undefined) {
            if (expStatus.startsWith('YES'))
                return true;
            else if (expStatus.startsWith('NO'))
                return false;
        }
    };

    this.getTestCaseDescription = function (rawDescription, expStatus) {
        if (this.getExpectedBool(expStatus)) {
            return rawDescription.includes("***") ?
                rawDescription.replace("***", "should be enabled") : rawDescription.replace("**", "should be displayed");
        } else {
            return rawDescription.includes("***") ?
                rawDescription.replace("***", "should be disabled") : rawDescription.replace("**", "should not be displayed");
        }
    };

    this.preActions = function (preActionsString, pageObject) {
        if (preActionsString != undefined) {
            if (preActionsString.includes(",")) {
                var preActionsChunk = preActionsString.split(",");
                for (var chksCnt = 0; chksCnt < preActionsChunk.length; chksCnt++)
                    this.preAction(preActionsChunk[chksCnt], pageObject);
            } else
                this.preAction(preActionsString, pageObject);
        }
    };

    this.preAction = function (preActionString, pageObject) {
        step("Execute pre action: " + preActionString + " for page " + pageObject);
        var methodString, params;

        if (preActionString.includes(":")) {
            var methodAndParams = preActionString.replace("\n", "").split(":");
            methodString = methodAndParams[0];
            params = methodAndParams[1].split("|");
        } else {
            methodString = preActionString;
            params = [];
        }

        if (methodString.includes(".")) {
            var prop = methodString.split(".");
            switch (prop.length) {
                case 2:
                    pageObject[prop[0]][prop[1]](...params);
                    break;
                case 3:
                    pageObject[prop[0]][prop[1]][prop[2]](...params);
                    break;
                case 4:
                    pageObject[prop[0]][prop[1]][prop[2]][prop[3]](...params);
                    break;
                case 5:
                    pageObject[prop[0]][prop[1]][prop[2]][prop[3]][prop[4]](...params);
                    break;
            }
        } else
            pageObject[methodString](...params);
    };

    this.getElement = function (elementString, pageObject) {
        var deferred = protractor.promise.defer();

        if (elementString != undefined) {
            if (elementString.includes(".")) {
                var elementChunks = elementString.split(".");
                var intermediateElem;
                for (var chkCnt = 0; chkCnt < elementChunks.length; chkCnt++) {
                    var currentChk = elementChunks[chkCnt];

                    if (chkCnt == 0)
                        intermediateElem = pageObject[currentChk];
                    else
                        intermediateElem = intermediateElem[currentChk];
                }
                deferred.fulfill(intermediateElem);
            } else {
                deferred.fulfill(pageObject[elementString]);
            }
        }
        return deferred.promise;
    };

    this.getElementPresence = function (element, pageObject) {
        var deferred = protractor.promise.defer();

        this.getElement(elementString, pageObject).then(function (element) {
            element.isDisplayed().then(function () {
                deferred.fulfill(true);
            }).catch(function () {
                deferred.fulfill(false);
            });
        });
        return deferred.promise;
    };

    this.assertCondition = function (elementsString, pageObject, expBool) {
        var elementsArr = elementsString.split(",");
        for (elementString of elementsArr) {
            step("Verify " + elementString + " displayed to be " + expBool);
            expect(this.getElementPresence(elementString, pageObject))
                .toEqual(expBool);
        }
    };

    //Asserts elements specified within {} to be displayed irrespective of the main element   
    this.assertToBeDisplayedCondition = function (pageObject, condition) {
        var toBeDisplayedElements = condition.match(/{([^}]+)}/);
        if (toBeDisplayedElements !== null) {
            this.assertCondition(toBeDisplayedElements[1], pageObject, true);
        }
    };
};
module.exports = new AuthHelper();