var pg = require("pg");
var queryProcessor = require("./query.processor");


var simpleQueryHelper = function () {
    var conString = browser.params.dbConString;
    // var conString = 'postgresql://mmurugesan_c:B5OSYwUG@stage-cortaldb:5433/rpx';
    var dbClient;
    var queryString;

    this.getQueryString = function (queryObject) {
        if (typeof id === 'undefined') {
            this.queryString = queryProcessor.process(queryObject).toQuery();
        } else {
            this.queryString = queryProcessor.process(queryObject).toQueryWithId(id);
        }
    };

    this.connectToDb = function () {
        var deferred = protractor.promise.defer();
        pg.connect(conString, function (error, client) {
            console.log("Connection String: " + conString);
            if (!error) {
                console.log("*** CONNECTED TO DATABASE ***");
                dbClient = client;
                deferred.fulfill(dbClient);
            } else {
                console.error('*** ERROR IN CONNECTION***', error);
                deferred.reject(error);
            }
        });
        return deferred.promise;
    };

    this.closeConnection = function () {
        dbClient.end();
    },
        this.getSingleFieldValue = function (queryStmt, field) {
            // dbClient = this.dbClient;

            var deferred = protractor.promise.defer();
            dbClient.query(queryStmt, function (error, result) {
                if (error) {
                    console.log(error, "q_err");
                    throw error;
                } else {
                    // dbClient.end();                                
                    deferred.fulfill(result.rows[0][field]);
                }
            });
            return deferred.promise;
        };
};
module.exports = new simpleQueryHelper();