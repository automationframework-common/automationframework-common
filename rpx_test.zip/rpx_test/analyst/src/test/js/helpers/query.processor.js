var QueryProcessor = function () {
    this.process = function (queryObject) {

        var getQuery = function () {
            if (typeof queryObject === 'object') {
                var base = queryObject['base'];
                var params = queryObject['params'];

                var query = base;
                for (var key in params) {
                    if (params.hasOwnProperty(key)) {
                        query = query.replace(key, params[key]);
                    }
                }
                return query;
            } else {
                return queryObject;
            }
        };

        return {
            toQuery: function () {
                return getQuery();
            },
            toQueryWithId: function (replaceWith) {
                var processedQuery = getQuery();
                return processedQuery.replace(/\|id\|/g, "'" + replaceWith + "'");
            }
        }
    };
};
module.exports = new QueryProcessor();