var request = require('request');


var httpHelper = function () {
   this.getResponseBody = function(requestURL){
    var deferred = protractor.promise.defer();
    request(siteUrl, function (error, response, body) {
        if (!error && response.statusCode == 200) {
            deferred.fulfill(JSON.parse(body));
        }
    });
    return deferred.promise;
   };
};
module.exports = new httpHelper();