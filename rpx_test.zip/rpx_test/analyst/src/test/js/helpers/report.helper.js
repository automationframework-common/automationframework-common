require("jasmine-allure-reporter");

global.log = function (logObject) {
    if (logObject["feature"] !== undefined)
        feature(logObject["feature"]);

    if (logObject["story"] !== undefined)
        story(logObject["story"]);

    if (logObject["description"] !== undefined)
        description(logObject["description"]);

    if (logObject["severity"] !== undefined)
        severity(logObject["severity"]);
};

global.feature = function (featureName) {
    allure.feature(featureName);
};

global.story = function (storyName) {
    allure.story(storyName);
};

global.description = function (description) {
    allure.description(description);
};

//blocker, critical, normal, minor, trivial
global.severity = function (severity) {
    allure.severity(severity);
};

global.step = function (stepDescription) {
    allure.createStep(stepDescription, function () { })();
};

global.addArgument = function (name, value) {
    allure.addArgument(name, value);
};

global.addArguments = function (argsObj) {
    for (var arg in argsObj) {
        if (argsObj.hasOwnProperty(arg)) {
            addArgument(arg, argsObj[arg]);           
        }
    }
};