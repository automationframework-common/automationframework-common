var PortfolioDetailsQuery = function () {
    this.portfolioTitle = "SELECT name FROM pa_web.analysis_portfolio WHERE id = |id|";

    this.portfolioAssetsGrants = "";

    this.portfolioAssetsApplciations = "";

    this.portfolioAssetsLits = "select count (*) as lits from core.pats p " +
        "join pa_web.analysis_portfolio_patents app on p.id = app.pats_id " +
        "join core.pat_stats ps on p.stripped_patnum = ps.stripped_patnum " +
        "where app.portfolio_id = |id| and ps.is_litigated = true";

    this.portfolioAssetsPatsChallenged = "select count(*) as pats_challenged from ptab.ptab_cases ptc " +
        "join core.pats p on ptc.stripped_patnum = p.stripped_patnum " +
        "join pa_web.analysis_portfolio_patents app on p.id = app.pats_id " +
        "where app.portfolio_id = |id|";

    this.portfolioPriorArtRef = "SELECT COUNT(*) as prior_art_ref FROM pa_web.v_patent_priorart_reference WHERE v_patent_priorart_reference.patent_id IN " +
        "(SELECT U0.id FROM core.pats U0 INNER JOIN pa_web.analysis_portfolio_patents U1 ON ( U0.id = U1.pats_id ) WHERE U1.portfolio_id = |id|)";

    this.randomPortfolio = "SELECT id, name FROM pa_web.analysis_portfolio LIMIT 1";

    this.analysisStatus = "SELECT quick_recommendation, primary_market_sector FROM pa_web.analysis_portfolio " +
        "WHERE id = |id|";

    this.portfolioWOAnnotations = "SELECT portfolio_id FROM analyst_app.analysis_portfoliomemo WHERE memo_type in ('SR', 'MB', 'ES', 'SU') " +
        "AND memo_text IS NULL GROUP BY portfolio_id HAVING COUNT(portfolio_id) = 4 LIMIT 1";

    this.portfolioWithAllAnnotations = "SELECT portfolio_id FROM analyst_app.analysis_portfoliomemo WHERE memo_type in ('SR', 'MB', 'ES', 'SU') " +
        "AND memo_text IS NOT NULL GROUP BY portfolio_id HAVING COUNT(portfolio_id) = 4 LIMIT 1";

        // modifying pa_web.analysis_portfolio to anaylst_app.analysis_portfolio -- updated the db creds in gulpfile.
    this.dealData = "SELECT opp.record_type_text__c as portfoliotype, a.namex as seller_broker, to_char(port.created_at,'fmMonth dd, yyyy') as intakedate, opp.priority__c as priority, " +
        "stagename__c as stage, confidentiality_level__c as confidentiality ,opp.currencyisocode || ' ' || sellersexplicitexpectation__c as sellerexpectation , " +
        "coalesce (bids_due__c::text, '') as bids_due , rejected_deal_primary_reason , coalesce( rejected_deal_secondary_reason::text, '') as rejected_deal_secondary_reason, seller_notes__c as seller_notes , " +
        "private_deal_notes__c as private_deal_notes , deal_notes__c as deal_notes from sf.acquisition_opportunity__c opp " +
        "JOIN analyst_app.analysis_portfolio port ON port.salesforce_id = opp.id join sf.accountx a on opp.account__c = a.id WHERE port.id = |id|";

        this.dealData_m = "SELECT opp.record_type_text__c as portfoliotype, a.namex as seller_broker, to_char(port.created_at,'fmMonth dd, yyyy') as intakedate, opp.priority__c as priority, " +
        "stagename__c as stage, confidentiality_level__c as confidentiality ,opp.currencyisocode || ' ' || sellersexplicitexpectation__c as sellerexpectation , " +
        "coalesce (bids_due__c::text, '') as bids_due , rejected_deal_primary_reason , coalesce( rejected_deal_secondary_reason::text, '') as rejected_deal_secondary_reason, seller_notes__c as seller_notes , " +
        "private_deal_notes__c as private_deal_notes , deal_notes__c as deal_notes from sf.acquisition_opportunity__c opp " +
        "JOIN analyst_app.analysis_portfolio port ON port.salesforce_id = opp.id join sf.accountx a on opp.account__c = a.id WHERE port.id = '5917' ";



    this.patentSummary = "SELECT memo_text FROM pa_web.analysis_patentmemo WHERE memo_type ='PS' AND " +
        "patent_id IN (SELECT id FROM core.pats WHERE patnum = |id|)";

    this.representativeClaim = "select pc.claim_num as claim_num ,pcr.is_representative_claim from pa_web.analysis_patclaimratings pcr " +
        "join core.pat_claims pc on pcr.claim_id = pc.id " +
        "where patent_id = (select id from core.pats  where patnum = |id|) " +
        "and is_representative_claim = true";

    this.patentTechTags = "select array_agg(distinct pa_web.analysis_techtag.name) as techtag from pa_web.analysis_techtag " +
        "join pa_web.analysis_techtagannotation atta on pa_web.analysis_techtag.id = atta.tech_tag_id " +
        "join core.pat_claims pc on atta.claim_id = pc.id " +
        "where pc.pat_id in (select id from core.pats  where patnum = |id|)";

    this.patentPrc = "select array_agg(distinct core.ents.name) as prc from core.ents " +
        "join pa_web.analysis_techtagannotation atta on core.ents.id = atta.potentially_relevant_company_id " +
        "join core.pat_claims pc on atta.claim_id = pc.id " +
        "where pc.pat_id in (select id from core.pats  where patnum = |id|) " +
        "and atta.tech_tag_id is null and theory_of_relevance_id is null and potentially_relevant_company_id is not null";
};
module.exports = new PortfolioDetailsQuery();