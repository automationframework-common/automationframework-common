var PatentQueries = function () {
    this.patNumber = "SELECT patnum FROM core.pats WHERE id = |id|";

    this.patentInfo = "SELECT title, patnum, stripped_patnum FROM core.pats where id = |id|";

    this.patentScore = "SELECT '(' || quality_score::float || ')' as quality_score FROM pa_web.analysis_patentmetric WHERE patent_id = |id|";

    this.patentStatus = "";

    this.patentFamilyDetails = "SELECT 'US: '|| pat_family_us_patent_count || ' | FN: ' || pat_family_non_us_patent_count as family " +
        "FROM core.pat_family_pats_details WHERE pat_id = |id|";

    this.patentCluster = "";

    this.patentSponsor = "select a.name as sponsor from core.pat_stats_sponsoring_parties sp " +
        "join core.aliases a on sp.alias_id = a.id " +
        "where sp.pat_id = |id|";

    this.patentCurrentAssignee = "select array_agg(name) as current_assignee from core.aliases a " +
        "join core.pat_stats_current_assignees psca on a.id = psca.alias_id " +
        "join core.pat_stats ps on psca.pat_stats_id = ps.id " +
        "join core.pats p on ps.patnum = p.patnum " +
        "where p.id = |id|";

    this.patentInventors = "select array_agg(replace (a.name, ',', '')) as inventor from core.pat_stats_inventors si " +
        "join core.aliases a on si.alias_id = a.id " +
        "where si.pat_id = |id|";

    this.patentPriorityDate = "WITH date as (SELECT COALESCE((SELECT pat_corr.priority_date " +
        "FROM pa_web.analysis_patentcorrection pat_corr " +
        "WHERE ((pat_corr.patent_id = |id|)) ), " +
        "( SELECT pat_stats.priority_date FROM core.pat_stats " +
        "WHERE (pat_stats.pat_id = |id|))) AS exp) " +
        "SELECT to_char(exp,'fmMonth dd, yyyy') as priority_date, to_char(exp,'mm/dd/yyyy') priority_date_mmddyyy FROM date";

    this.patentFilingDate = "select to_char(app_filing_date, 'fmMonth fmdd, YYYY') as app_filing_date, " +
        "to_char(app_filing_date, 'mm/dd/yyyy') as app_filing_date_mmddyyyy from core.pats where id = |id|";

    this.patentIssueDate = "select to_char(issue_date, 'mm/dd/yyyy') as issue_date_mmddyyyy from core.pats where id = |id|";

    this.patentLitigations = "select count(*) as litigations_count from core.pats p " +
        "join core.lits_pats_map lpm on p.stripped_patnum = lpm.patnum " +
        "where p.id = |id|";

    this.patentCampaign = "select coalesce(name, 'NA') as name from lit_campaigns.campaigns camp " +
        "join lit_campaigns.campaign_patents cp on cp.campaign_id = camp.id " +
        "join core.pats p on p.stripped_patnum = cp.stripped_patnum " +
        "where p.id = |id|";

    this.patentExpirationDate = "WITH date as (SELECT COALESCE((SELECT pat_corr.expiration_date " +
        "FROM pa_web.analysis_patentcorrection pat_corr " +
        "WHERE ((pat_corr.patent_id = |id|) )), " +
        "( SELECT pat_stats.expiration_date FROM core.pat_stats " +
        "WHERE (pat_stats.pat_id = |id|))) AS exp) " +
        "SELECT to_char(exp,'fmMonth dd, yyyy') as expiration_date, to_char(exp,'mm/dd/yyyy') expiration_date_mmddyyy FROM date";

    // this.patentPortfolioCount = "select count (*) as portfolio_count from pa_web.analysis_portfolio_patents " +
    //     "where pats_id = |id|";

        this.patentPortfolioCount = "select count (*) as portfolio_count from analyst_app.analysis_portfolio_patents " +
        "where pats_id = |id|";

    this.patentTypeBase = "SELECT pat_id FROM core.pats_invention_link WHERE |WHERE| and is_current = 't' ORDER BY RANDOM() LIMIT 1";

    this.pubPatent = {
        base: this.patentTypeBase,
        params: {"|WHERE|": "document_type = 'publication'"}
    };

    this.issuedPat = {
        base: this.patentTypeBase,
        params: {"|WHERE|": "document_type = 'issued patent'"}
    };

    this.reIssuedPat = {
        base: this.patentTypeBase,
        params: {"|WHERE|": "document_type = 're-issued patent'"}
    };

    this.warningPatent = "SELECT pat_id FROM core.pats_invention_link WHERE is_current = 'f' ORDER BY RANDOM() LIMIT 1";

    this.patentAnnotations = "SELECT patent_id FROM pa_web.analysis_patentmemo " +
        "WHERE memo_type in ('SS', 'PR', 'AN', 'CO', 'PS', 'HR', 'ER', 'SR') " +
        "AND memo_text IS NOT NULL GROUP BY patent_id HAVING COUNT(patent_id) = 8 LIMIT 1";

    this.patentWithoutLicensees = "select pat.id as patent_id from core.pats pat " +
        "LEFT JOIN pa_web.analysis_patentlicensee apl " +
        "ON pat.id = apl.patent_id WHERE apl.licensee_notes IS NULL LIMIT 1";

    this.patentWithLicensees = "SELECT patent_id FROM pa_web.analysis_patentlicensee LIMIT 1";

    this.patentLicensees = "select array_agg(e.name) as licensees from pa_web.analysis_patentlicensee  pl " +
        "join core.ents e on pl.licensed_company_id = e.id " +
        "where patent_id = |id|";

    this.patentClaimId = "select patent_id, claim_id from pa_web.analysis_patclaimratings limit 1";

    this.claimRatings = "SELECT " +
        "CASE is_representative_claim " +
        "WHEN 't' then true " +
        "ELSE false " +
        "END as is_representative, " +
        "CASE stretchy_claim " +
        "WHEN 't' THEN true " +
        "ELSE false " +
        "END as is_stretchy " +
        "FROM pa_web.analysis_patclaimratings where claim_id = |id|";

    this.claimStarRatings = "SELECT COALESCE(literal_infringement, 0) AS literal_relevance, COALESCE(relevant_companies, 0) AS relevant_companies, " +
        "COALESCE(priority, 0) AS priority, COALESCE(detection, 0) AS detection, " +
        "COALESCE(claim_simplicity, 0) AS claim_simplicity, COALESCE(importance, 0) AS importance, " +
        "COALESCE(statute_101_issue, 0) AS eligibility, COALESCE(written_description, 0) AS description, " +
        "COALESCE(enablement, 0) AS enablement, COALESCE(indefiniteness, 0) AS indefiniteness " +
        "FROM pa_web.analysis_patclaimratings WHERE claim_id = |id|";

    this.claimsWithFreeFormTags = "select cpc.pat_id as pat_id, acfft.claim_id as claim_id " +
        "from pa_web.analysis_freeformtag afft " +
        "join pa_web.analysis_claimfreeformtags acfft on afft.id = acfft.free_form_tag_id " +
        "join core.pat_claims cpc on acfft.claim_id = cpc.id " +
        "join core.pats cp on cpc.pat_id = cp.id " +
        "where afft.name is not null";

    this.freeFormTags = "select array_agg(afft.name) as tags from pa_web.analysis_freeformtag afft " +
        "join pa_web.analysis_claimfreeformtags acfft on afft.id = acfft.free_form_tag_id " +
        "join core.pat_claims cpc on acfft.claim_id = cpc.id " +
        "join core.pats cp on cpc.pat_id = cp.id " +
        "where acfft.claim_id = |id|";
};
module.exports = new PatentQueries();