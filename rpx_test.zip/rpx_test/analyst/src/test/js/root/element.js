var page = require('./page');

var Element = function (e) {
    this.isPresent = function () {
        return e.isPresent();
    };

    this.isDisplayed = function () {
        return e.isDisplayed();
    };
};
Element.prototype = page;
module.exports = Element;

global.getAllData = function (elements) {
    var deferred = protractor.promise.defer();

    elements.count().then(function (elemCount) {        
        if (elemCount > 0) {
            elements.map(function (item) {
                return item.getText();
            }).then(function (values) {                
                deferred.fulfill(values);
            });
        } else {            
            deferred.fulfill([]);            
        }
    });

    return deferred.promise;
};

global.filterTextAndClick = function (filterElement, filterText) {
    element.all(filterElement).filter(function (element) {
        return element.getText().then(function (text) {
            return text == filterText;
        });
    }).first().click();
};

global.is = function (element) {
    var deferred = protractor.promise.defer();

    return {
        displayed: function () {
            element.isDisplayed().then(function () {
                deferred.fulfill(true);
            }).catch(function () {
                deferred.fulfill(false);
            });
            return deferred.promise;
        }
    }
};

global.scrollToView = function (element){
    browser.executeScript("arguments[0].scrollIntoView();", element.getWebElement());
};

global.click = function (element) {
    var deferred = protractor.promise.defer();
    return {
        ifDisplayed: function () {
            element.isDisplayed().then(function (isTrue) {
                angularWait();
                if (isTrue) {
                    element.click();
                }
                deferred.fulfill(angularWait());
            });
            return deferred.promise;
        }
    }
};

global.getText = function (element) {
    var deferred = protractor.promise.defer();
    element.isDisplayed().then(function () {
        deferred.fulfill(element.getText());
    }).catch(function () {
        deferred.fulfill("");
    });

    return deferred.promise;
};

global.mouseHover = function (element) {
    browser.actions().mouseMove(element).perform();
};

global.$f = function (element) {
    var EC = protractor.ExpectedConditions;
    //TODO get wait from config
    var waitTime = 5000;

    return {
        isDisplayed: function () {
            var deferred = protractor.promise.defer();

            element.isPresent().then(function () {
                element.isDisplayed().then(function () {
                    deferred.fulfill(true);
                });
            }).catch(function () {
                deferred.fulfill(false);
            });

            return deferred.promise;
        },
        sendKeys: function (text) {
            var deferred = protractor.promise.defer();
            if (text != undefined) {
                element.isDisplayed().then(function () {
                    element.clear().then(function () {
                        element.sendKeys(text);
                        angularWait();
                    });
                }).then(function () {
                    deferred.fulfill();
                }).catch(function (msg) {
                    deferred.reject("Exception at $f: sendKeys - " + msg);
                });
            }

            return deferred.promise;
        },
        getText: function () {
            var deferred = protractor.promise.defer();

            element.isPresent().then(function () {
                element.getText().then(function (text) {
                    deferred.fulfill(text);
                });
            });

            return deferred.promise;
        },
        waitUntilVisible: function () {
            waitFor(element).toBeVisible();
        },
        waitUntilInvisible: function () {
            waitFor(element).toBeInvisible();
        },
        waitUntilClickable: function () {
            waitFor(element).toBeClickable();
        },
        waitForElementPresence: function () {
            browser.wait(EC.presenceOf(element), waitTime);
        }
    }
};