var Browser = function() {
    this.get = function(url) {
        browser.ignoreSynchronization = true;
        browser.get(url);
    };
};
module.exports = new Browser();

global.inNewWindow = function (actions) {
    browser.getAllWindowHandles().then(function (handles) {
        browser.switchTo().window(handles[1]);
        browser.waitForAngular();
        actions();
        browser.driver.close();
        browser.switchTo().window(handles[0]);
    });
};

global.angularWait = function() {
    browser.ignoreSynchronization = false;
    browser.waitForAngular();
};

global.navigateBack = function () {
    browser.ignoreSynchronization = true;
    browser.navigate().back();
    return angularWait();
};

global.refresh = function() {
    browser.ignoreSynchronization = true;
    browser.navigate().refresh();
    return angularWait();
};

global.getCurrentUrl = function () {
    browser.ignoreSynchronization = true;
    return browser.getCurrentUrl();
};

global.waitFor = function (element) {
    var until = protractor.ExpectedConditions;
    var timeout = browser.params.maxTimeOut;

    return {
        presence: function () {
            browser.wait(until.presenceOf(element), timeout, 'Timeout waiting for presence of element');
        },
        toBeClickable: function () {
            browser.wait(until.elementToBeClickable(element), timeout, "Timeout waiting for element to be click able");
        },
        toBeInvisible: function () {
            browser.wait(until.invisibilityOf(element), timeout, "Timeout waiting for element to be invisible");
        },
        toBeVisible: function () {
            browser.wait(until.visibilityOf(element), timeout, "Timeout waiting for element to be visible");
        }
    }
};