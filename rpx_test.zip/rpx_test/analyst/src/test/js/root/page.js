var browser_ = require('./browser');

var Page = function () {

};
Page.prototype = browser_;
module.exports = new Page();

var formUrl = function (urlItems, id, params) {
    var deferred = protractor.promise.defer();

    if (id === undefined && params === undefined) {
        deferred.fulfill(browser.baseUrl + urlItems);
    } else if (id != undefined && params === undefined) {
        getPartialUrl(urlItems, id).then(function (composedUrl) {
            if (typeof id === "string" || typeof urlItems == "string")
                deferred.fulfill(browser.baseUrl + composedUrl.replace('{{id}}', id));
            else {
                var tUrl = composedUrl;
                for (var idCnt = 0; idCnt < id.length; idCnt++) {
                    tUrl = tUrl.replace("{{id}}", id[idCnt]);
                }
                deferred.fulfill(browser.baseUrl + tUrl);
            }
        });
    } else if (id != undefined && params != undefined) {
        //TODO IMPLEMENT URL WITH PARAMS
    } else {
        deferred.reject("Error in forming url at page.js -> formUrl fn");
    }

    return deferred.promise;
};

var getPartialUrl = function (urlItems, id) {
    return new Promise(function (resolve, reject) {
        if (typeof urlItems === "string")
            resolve(urlItems);
        else {
            var urlItemsKey = Object.keys(urlItems);
            if (typeof id == "string") {
                resolve(urlItems[urlItemsKey[0]]);
            } else {
                var partialUrl = "";
                for (var keyCnt = 0; keyCnt < id.length; keyCnt++) {
                    partialUrl = partialUrl + urlItems[urlItemsKey[keyCnt]];
                }
                resolve(partialUrl);
            }
        }
        reject("Error in forming partial URL at page.js -> getPartialUrl fn");
    });
};

global.to = function (pageObj, id, params) {
    var deferred = protractor.promise.defer();

    formUrl(pageObj.url, id, params).then(function (url) {
        console.log("formed url: " + url);
        browser_.get(url);
    });
    deferred.fulfill(at(pageObj));

    return deferred.promise;
};

global.at = function (pageObj) {
    angularWait();
    pageObj.at();
    return pageObj;
}; 