var element_ = require("../root/element");

var confirmationModal = require("../pages/modals/confirmation.modal");

var PriorArtPanel = function (paPanelElement) {
    element_.apply(this, [paPanelElement]);

    this.accordionPanels = paPanelElement.all(by.css("uib-accordion .panel-default"));

    this.get = function (accordionPanelIndex) {
        var this_ = this;
        this_.accordionPanels.count().then(function (c) {
            console.log("count: " + c);
        });

        var accordionPanel = this_.accordionPanels.get(accordionPanelIndex);
        return {
            edit: function () {
                //TODO add edit functionality
            },
            clickTargetPatent: function () {
                accordionPanel.element(by.css("span[class='rpx-flex  truncate'] a[href*='patent']")).click();
                angularWait();
            },
            clickDocument: function () {
                accordionPanel.element(by.css(".fa-file-text")).click();
                angularWait();
            },
            clickCaseTitle: function () {
                accordionPanel.element(by.css("span[class*='rpx-flex-row']:not([class*='padded']) a[href*='ptabs']:not([href*='/rpx-ptab'])"))
                    .click();
                angularWait();
            },
            clickCaseNumber: function () {
                accordionPanel.element(by.css("span[class*='rpx-flex-row padded'] a[href*='ptabs']")).click();
                angularWait();
            },
            isEditPresent: function () {
                var deferred = protractor.promise.defer();

                accordionPanel.element(by.css(".rpx-flex .fa-pencil-square-o")).isPresent().then(function () {
                    deferred.fulfill(true);
                }).catch(function () {
                    deferred.fulfill(false);
                });

                return deferred.promise;
            },
            isDeletePresent: function () {
                var deferred = protractor.promise.defer();

                accordionPanel.element(by.css(".rpx-flex .fa-trash")).isPresent().then(function () {
                    deferred.fulfill(true);
                }).catch(function () {
                    deferred.fulfill(false);
                });

                return deferred.promise;
            },
            delete: function () {
                accordionPanel.element(by.css(".rpx-flex .fa-trash")).click();
                confirmationModal.confirm();
            },
            
            /**
             * @param {String} refIndex - references index
             * @param {String} type - reference type NPL/US Patent/Foreign Patent
             */
            clickReferenceLink: function (refIndex, type) {
                var referencePanel = accordionPanel.all(by.css("priorart-reference-list div[class='ng-scope'][ng-repeat]"));
                referencePanel.get(refIndex)
                    .element(by.xpath("//span[contains(@class, 'rpx-alt-text-4')][contains(text(),'" + type + "')]//a")).click();
                angularWait();
            }
        }
    };
};
PriorArtPanel.prototype = new element_();
module.exports = PriorArtPanel;