var element_ = require("../root/element");

var SaveCancelContainer = function (saveCancelContainerElement) {

    this.saveBtn = saveCancelContainerElement.element(by.css(".save-btn"));
    this.cancelBtn = saveCancelContainerElement.element(by.css(".cancel-btn"));
    this.processingStatusHide = saveCancelContainerElement.element(by.css("div[class='processing-status ng-hide']"));

    this.save = function () {        
        this.saveBtn.click();
        $f(this.processingStatusHide).waitForElementPresence();
        angularWait();
    };

    this.cancel = function () {
        this.cancelBtn.click();
        $f(this.processingStatusHide).waitForElementPresence();
        angularWait();
    };
};
SaveCancelContainer.prototype = new element_();
module.exports = SaveCancelContainer;