var element_ = require("../root/element");

var StarRating = function (starRatingElement, params) {
    element_.apply(this, [starRatingElement]);

    var labelElements,
        ratingElements;

    //AUTH
    this.enabled = (params["enabled"] !== undefined ?
        starRatingElement.element(params['enabled'].locator()) : null);
    this.disabled = (params["disabled"] !== undefined ?
        starRatingElement.element(params['disabled'].locator()) : null);

    (function () {
        if (params["labels"] !== undefined)
            labelElements = params["labels"];
        ratingElements = params['ratings'];
    })();

    this.getStarValue = function () {
        var deferred = protractor.promise.defer();

        var starValue = [];
        element.all(starRatingElement.locator()).each(function (starElem) {
            var ratingElement = starElem.element(ratingElements.locator());

            ratingElement.all(by.css("i[class='fa ng-scope fa-star']")).count().then(function (starCount) {
                var ratingObject = {};

                ratingElement.getAttribute("max").then(function (value) {
                    ratingObject['actual'] = starCount;
                    ratingObject['max'] = value;

                    starValue.push(ratingObject);
                });
            });
        }).then(function () {
            deferred.fulfill(starValue);
        });
        return deferred.promise;
    };

    this.getLabels = function () {
        var deferred = protractor.promise.defer();

        var labels = [];
        element.all(starRatingElement.locator()).each(function (starElem) {
            var labelElement;

            if (labelElements !== undefined)
                labelElement = starElem.element(labelElements.locator());
            else
                labelElement = starElem;
            labelElement.getText().then(function (text) {
                text = text.replace(':', '');
                labels.push(text);
            });
        }).then(function () {
            labels = labels.filter(String);
            deferred.fulfill(labels);
        });
        return deferred.promise;
    };

    this.getRatings = function () {
        var this_ = this;
        var deferred = protractor.promise.defer();
        var data = [];

        this_.getLabels().then(function (labels) {
            this_.getStarValue().then(function (starValue) {
                for (var labelCount = 0; labelCount < labels.length; labelCount++) {
                    var dataObj = {};
                    dataObj[labels[labelCount]] = starValue[labelCount];
                    data.push(dataObj);
                }
            });
        }).then(function () {
            deferred.fulfill(data);
        });
        return deferred.promise;
    };

    this.getRatingsObject = function () {
        var this_ = this;
        var deferred = protractor.promise.defer();

        protractor.promise.all([
            this_.getLabels(),
            this_.getStarValue()
        ]).then(function (data) {
            var ratings = {};

            var labelsArr = data[0];
            var starValueArr = data[1];

            for (labelIndex in labelsArr) {  
                var label = labelsArr[labelIndex];  
                var value = starValueArr[labelIndex];            
                ratings[label] = value;                                         
            }
             
            deferred.fulfill(ratings);
        });

        return deferred.promise;
    };

    this.setStarRatings = function (ratingObject,type) {
        for (var key in ratingObject) {
            if (ratingObject.hasOwnProperty(key)) {
                this.selectRating(key, ratingObject[key],type);
            }
        }
    };

    this.selectRating = function (label, ratingToSelect,type) {
        var starRatingElem;
        if(type==undefined)
        // var starRatingElem = starRatingElement.element(by.xpath("//a[contains(text(),'" + label + ":')]/ancestor::div[@class='row collapse']"));
        var starRatingElem = starRatingElement.element(by.xpath("//a[contains(text(),'" + label + "')]/ancestor::div[@class='row collapse']"));
        //TODO refactor locator 
        if(type=='tags')
        var starRatingElem = starRatingElement.element(by.xpath("//*[contains(text(),'" + label + "')]/../../.."));
        var selectedStars = starRatingElem.all(by.css("i[class='fa ng-scope fa-star']"));
        selectedStars.count().then(function (selectedStarsCount) {
            if (selectedStarsCount > 0) {
                starRatingElem.element(by.css("i[class*='fa-star']:nth-of-type(" + selectedStarsCount + ")")).click();
                angularWait();
            }
        }).then(function () {
            if (ratingToSelect !== 0) {
                starRatingElem.element(by.css("i[class*='fa-star']:nth-of-type(" + ratingToSelect + ")")).click();
                angularWait();
            }
        });
    };
};
StarRating.prototype = new element_();
module.exports = StarRating;