var element_ = require("../root/element");

var Dropdown = function (dropDownElement) {
    element_.apply(this, [dropDownElement]);

    this.getAvailableOptions = function () {
        return getAllData(dropDownElement.all(by.css("option")));
    };

    this.getSelectedOption = function () {
        return dropDownElement.element(by.css("option[selected]")).getText();
    };

    this.select = function(option) {
        return dropDownElement.element(by.cssContainingText('option', option)).click();        
    };

    this.selectByFullName = function(option) {
        // return dropDownElement.element(by.cssContainingText('option', option)).click();    
        return dropDownElement.element(by.xpath("//option[text()='"+option+"']")).click();        
    };

    this.selectAllOptions = function () {
        var deferred = protractor.promise.defer();

        var options = dropDownElement.all(by.css("option:not([selected]):not([disabled])"));
        options.count().then(function (count) {
            while(count > 0) {
                options.get(0).click();
                angularWait();
                count--;
            }
        });
        deferred.fulfill();

        return deferred.promise;
    };
};
Dropdown.prototype = new element_();
module.exports = Dropdown;