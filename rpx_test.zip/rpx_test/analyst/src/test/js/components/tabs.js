var element_ = require("../root/element");

var Tabs = function (tabsElement) {
    element_.apply(this, [tabsElement]);

    this.getTabsList = function () {
        var deferred = protractor.promise.defer();

        getAllData(tabsElement.all(by.css("a"))).then(function (values) {
            deferred.fulfill(values);
        });
        return deferred.promise;
    };

    this.select = function (tab) {
        var deferred = protractor.promise.defer();

        tabsElement.all(by.css("a")).each(function (tabElement) {
            tabElement.getText().then(function (value) {
                if(value.toLowerCase() === tab.toLowerCase()) {
                    browser.executeScript("arguments[0].scrollIntoView();", tabElement.getWebElement());
                    tabElement.click();
                    angularWait();
                    deferred.fulfill();
                }
            })
        });

        return deferred.promise;
    };
};
Tabs.prototype = new element_();
module.exports = Tabs;