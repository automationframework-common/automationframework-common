var element_ = require("../root/element");

var Checkbox = function (checkBoxElement) {
    element_.apply(this, [checkBoxElement]);

    this.isChecked = function () {
        var deferred = protractor.promise.defer();

        checkBoxElement.getAttribute("class").then(function (value) {
            if(value.includes("ng-not-empty"))
                deferred.fulfill(true);
            else
                deferred.fulfill(false);
        });

        return deferred.promise;
    };

    this.select = function(action) {
        if(action === true) {
            this.check();
        } else {
            this.unCheck();
        }
    };

    this.check = function () {        
        this.isChecked().then(function (status) {
            if(status === false) {
                checkBoxElement.click();
                angularWait();
            }
        });
    };

    this.unCheck = function () {
        this.isChecked().then(function (status) {
            if(status === true) {
                checkBoxElement.click();
                angularWait();
            }
        });
    };
};
Checkbox.prototype = new element_();
module.exports = Checkbox;
