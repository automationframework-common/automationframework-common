var element_ = require("../root/element");

var RadioButton = function (radioElement) {
    element_.apply(this, [radioElement]);

    this.selectContainingValue = function(value) {
        radioElement.element(by.css("input[value='" + value + "']")).click();
    };

    this.selectContainingLabel = function (label) {
        radioElement.element(by.cssContainingText("label", label)).click();
    };

    this.selectContainingId = function (id) {
        radioElement.element(by.css("input[id='" + id + "']")).click();
    };

    this.getSelectedOption = function() {
        var deferred = protractor.promise.defer();

        var selectedElement = radioElement.element(by.css("input[class*='ng-valid-parse']"));
        selectedElement.getText().then(function (value) {
            deferred.fulfill(value);
        });

        return deferred.promise;
    };
};
RadioButton.prototype = new element_();
module.exports = RadioButton;