var element_ = require('../root/element');

var dropDown = require("../components/dropdown"),
    starRating = require("../components/star.rating"),
    checkBox = require("../components/checkbox");

var Card = function (cardElement, params) {
    element_.apply(this, [cardElement]);

    var rows,
        selectedRows,
        noDataElement;

    var cardOptions,
        cardOptionsIcon,
        cardOptionsCloseIcon,
        cardOptionsDropDown,
        selectedOptions,
        closeInSelectedOptions;

    (function () {
        rows = cardElement.all(by.css(".card.vs-repeat-repeated-element"));
        selectedRows = cardElement.all(by.css(".card.selected"));

        cardOptions = params["cardOptions"];
        if (cardOptions !== undefined) {
            cardOptionsIcon = cardOptions.element(by.css("a[zf-hard-toggle='grid-column-options-card']"));
            cardOptionsModal = cardOptions.element(by.css(".action-sheet"));
            cardOptionsCloseIcon = cardOptions.element(by.css(".action-sheet a[zf-close='grid-column-options-card']"));
            cardOptionsDropDown = new dropDown(cardOptions.element(by.css(".action-sheet select")));
            selectedOptions = cardOptions.all(by.css(".action-sheet .grid-column-labels-container li"));
            closeInSelectedOptions = cardOptions.all(by.css(".action-sheet .grid-column-labels-container li a"));
            cardOptionsAlertLabel = cardOptions.element(by.css(".alert.label"));
        }

        if (params["pagination"] !== undefined)
            pagination = params["pagination"];
        noDataElement = params["noData"];
    })();

    //TODO Seperate Options Selector as new component
    var openOrCloseOptionsSelector = function (option, element) {
        var deferred = protractor.promise.defer();

        cardOptionsModal.getAttribute("class").then(function (classValue) {
            if (!classValue.includes("is-active") && option === "open")
                element.click();
            else if (classValue.includes("is-active") && option === "close")
                element.click();

            angularWait();
        }).then(function () {
            deferred.fulfill();
        });

        return deferred.promise;
    };

    this.openOptionsSelector = function () {
        return openOrCloseOptionsSelector("open", cardOptionsIcon);
    };

    this.closeOptionsSelector = function () {
        return openOrCloseOptionsSelector("close", cardOptionsCloseIcon);
    };

    this.metrics = function () {
        var _this = this;
        var deferred = protractor.promise.defer();
        _this.openOptionsSelector();

        return {
            getAvailableOptions: function () {
                deferred.fulfill(cardOptionsDropDown.getAvailableOptions());

                _this.closeOptionsSelector();
                return deferred.promise;
            },
            deSelectAll: function () {
                closeInSelectedOptions.count().then(function (count) {
                    while (count > 0) {
                        closeInSelectedOptions.get(0).click();
                        angularWait();
                        count--;
                    }
                }).then(function () {
                    _this.closeOptionsSelector();
                });

                return deferred.promise;
            },
            deSelect: function (optionArr) {
                for (var index in optionArr) {
                    var option = element(by.cssContainingText('.action-sheet .grid-column-labels-container li', optionArr[index]));
                    option.element(by.css("a")).click();
                    angularWait();
                }
                _this.closeOptionsSelector().then(function () {
                    deferred.fulfill();
                });

                return deferred.promise;
            },
            select: function (optionArr) {
                for (var index in optionArr) {
                    cardOptionsDropDown.select(optionArr[index]);
                    angularWait();
                }
                _this.closeOptionsSelector().then(function () {
                    deferred.fulfill();
                });

                return deferred.promise;
            },
            getSelectedOptions: function () {
                var selectedOptionsArr = [];
                selectedOptions.each(function (selectedOption) {
                    selectedOption.getText().then(function (text) {
                        selectedOptionsArr.push(text);
                    });
                }).then(function () {
                    deferred.fulfill(selectedOptionsArr);
                    _this.closeOptionsSelector();
                });

                return deferred.promise;
            },
            getAlertMsg: function () {
                cardOptionsAlertLabel.isDisplayed().then(function () {
                    deferred.fulfill(cardOptionsAlertLabel.getText());
                }).catch(function () {
                    deferred.fulfill("");
                });

                _this.closeOptionsSelector();
                return deferred.promise;
            }
        };
    };

    //Implement pagination
    this.getData = function (pageNumber) {
        var deferred = protractor.promise.defer();
        this.openOptionsSelector();
        var dataArr = [];

        var this_ = this;

        rows.each(function (row) {
            var rowObj = {};

            protractor.promise.all([
                row.element(by.css(".card-divider .left")).getText(),
                row.element(by.css("div[ng-if='card.priority_date'] .label")).getText(),
                row.element(by.css("div[ng-if='card.issue_date'] .label")).getText(),
                row.element(by.css(".patent-title")).getText(),
                row.element(by.css(".card-claim.main-claim")).getText(),
                this_.getCardMetrics(row)
            ]).then(function (arr) {
                rowObj["patent_number"] = arr[0];
                rowObj["priority_date"] = arr[1];
                rowObj["issue_date"] = arr[2];
                rowObj["patent_title"] = arr[3];
                rowObj["claim"] = arr[4];
                rowObj["metrics"] = arr[5];
            }).then(function () {
                dataArr.push(rowObj);
            });
        }).then(function () {
            deferred.fulfill(dataArr);
        });

        return deferred.promise;
    };

    this.getCardMetrics = function (metricRow) {
        var deferred = protractor.promise.defer();
        var metricsArr = [];

        if (metricRow === undefined) {
            
            rows.each(function (row) {
                getSingleCardMetric(row).then(function (rowObj) {
                    metricsArr.push(rowObj);
                });
            }).then(function () {
                deferred.fulfill(metricsArr);
            });
        } else {
            getSingleCardMetric(metricRow).then(function (values) {
                deferred.fulfill(values);
            });
        }

        return deferred.promise;
    };

   
    var getSingleCardMetric = function (row) {
        var deferred = protractor.promise.defer();

        var ratingOptions = [
            'importance rating', 'literal relevance rating', 'relevant companies rating', 'priority rating',
            'detection rating', 'claim simplicity', 'importance rating',
        ];

        var rowObj = {};
        //element class has been modified 
        // row.all(by.css(".card-ratings li[class='ng-binding ng-scope']")).each(function (cardRating) {
            row.all(by.css(".card-ratings li[class='ng-scope']")).each(function (cardRating) {
            cardRating.getText().then(function (cardRatingText) {
                if (ratingOptions.includes(cardRatingText.toLowerCase())) {
                    var cardValue = cardRating.all(by.css("span[ng-switch='metric.type'] i[class='fa ng-scope fa-star']"));
                    cardValue.count().then(function (rating) {
                        rowObj[cardRatingText.toLowerCase().replace(new RegExp(' ', 'g'), "_")] = rating;
                    });
                } else {
                    cardRating.element(by.css("span")).getText().then(function (text) {
                        //TODO refactor
                        if (cardRatingText.includes("[")) {
                            var key = cardRatingText.substr(0, cardRatingText.indexOf("[") - 1).toLowerCase().replace(new RegExp(' ', 'g'), "_");
                            rowObj[key] = text;
                        } else {
                            var key = cardRatingText.substr(0, cardRatingText.lastIndexOf(" ")).toLowerCase().replace(new RegExp(' ', 'g'), "_");
                            rowObj[key] = text;
                        }
                    });
                }
            });
        }).then(function () {
            deferred.fulfill(rowObj);
        });

        return deferred.promise;
    };

//Get card Metrics Names

this.getCardMetricsNames = function (metricRow) {
    var deferred = protractor.promise.defer();
    var metricsNameArr = [];

    if (metricRow === undefined) {
                getSingleCardMetricsName(rows.get(0)).then(function (values) {
                    deferred.fulfill(values);
               
            });
       
    } else {
        getSingleCardMetricsName(metricRow).then(function (values) {
            deferred.fulfill(values);
        });
    }

    return deferred.promise;
};
var getSingleCardMetricsName =function (row) {
var deferred = protractor.promise.defer();

 var name=[];
//element class has been modified 
// row.all(by.css(".card-ratings li[class='ng-binding ng-scope']")).each(function (cardRating) {
    row.all(by.css(".card-ratings li[class='ng-scope'] div[class*='ng-binding']")).each(function (cardMetricName) {
        cardMetricName.getText().then(function (cardRatingText) {
            // cardRatingText = cardRatingText.toLowerCase();
            // cardRatingText = cardRatingText.replace(" ","_");
            name.push(cardRatingText.toLowerCase().replace(new RegExp(' ', 'g'), "_"));
            
        });
    
}).then(function () {
    deferred.fulfill(name);
});

return deferred.promise;
};


    this.select = function (index) {
        var cardCheckBox = new checkBox(rows.get(index).element(by.css("input")));
        cardCheckBox.check();
        angularWait();
    };

    this.deSelect = function (index) {
        var cardCheckBox = new checkBox(rows.get(index).element(by.css("input")));
        cardCheckBox.unCheck();
        angularWait();
    };

    this.loadPatent = function (index) {
        var deferred = protractor.promise.defer();

        rows.get(index).getAttribute("class").then(function (classValue) {
            if (!classValue.includes("patent-state")) {
                var patentElement = rows.get(0).element(by.css(".clearfix .left"));

                protractor.promise.all([
                    patentElement.getText(),
                    patentElement.click()
                ]).then(function (arr) {
                    deferred.fulfill(arr[0]);
                });
            }
        });

        return deferred.promise;
    };
};
Card.prototype = new element_;
module.exports = Card;