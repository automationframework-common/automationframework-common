var element_ = require("../root/element");

var Ellipsis = function(ellipsisElement) {
    element_.apply(this, [ellipsisElement]);

    var ellipsisTitle,
        ellipsisExpand,
        ellipsisCompress,
        ellipsisSummary,
        ellipsisContent;

    (function() {
        ellipsisTitle = ellipsisElement.element(by.css(".summary-title"));
        ellipsisExpand = ellipsisElement.element(by.css(".fa-expand"));
        ellipsisCompress = ellipsisElement.element(by.css(".fa-compress"));
        ellipsisSummary = ellipsisElement.element(by.css(".ellipsis-content ellipisis-summary"));
        ellipsisContent = ellipsisElement.element(by.css(".ellipsis-content ellipisis-content"));
    })();

    this.getTitle = function() {
        return ellipsisTitle.getText();
    };

    this.getSummary = function() {
        var deferred = protractor.promise.defer();

        ellipsisCompress.isDisplayed().then(function () {
            ellipsisCompress.click().then(function () {
                angularWait();
                deferred.fulfill(ellipsisSummary.getText());
            }).catch(function () {
                deferred.reject("Failed in data extraction for ellipsis component summary");
            });
        }).catch(function () {
            ellipsisSummary.getText().then(function (value) {
                deferred.fulfill(value);
            }).catch(function () {
                deferred.reject("Failed in data extraction for ellipsis component summary");
            });
        });

        return deferred.promise;
    };

    this.getContent = function() {
        var deferred = protractor.promise.defer();

        ellipsisExpand.isDisplayed().then(function () {
            ellipsisExpand.click().then(function () {
                angularWait();
                deferred.fulfill(ellipsisContent.getText());
            }).catch(function () {
                deferred.reject("Failed in data extraction for ellipsis component content");
            });
        }).catch(function () {
            ellipsisContent.getText().then(function (value) {
                deferred.fulfill(value);
            }).catch(function () {
                deferred.reject("Failed in data extraction for ellipsis component content");
            });
        });

        return deferred.promise
    };

    this.expand = function() {
        ellipsisExpand.click().then(function () {
            angularWait();
        });
    };

    this.compress = function() {
        ellipsisCompress.click().then(function () {
            angularWait();
        });
    };
};
Ellipsis.prototype = new element_();
module.exports = Ellipsis;