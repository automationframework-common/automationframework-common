var element_ = require("../root/element");

var Chart = function (chartElement, params) {
    element_.apply(this, [chartElement]);

    var dataLabels,
        toolTipText;

    (function () {
        dataLabels = chartElement.all(params["dataLabels"].locator());
        toolTipText = chartElement.element(params["toolTipText"].locator());
    })();

    this.getDataLabels = function () {
        var deferred = protractor.promise.defer();
        var resultArr = [];

        dataLabels.each(function (dataLabel) {
            var title = dataLabel.element(by.css("title"));
            var tspans = dataLabel.all(by.css("tspan:not([class])"));

            title.isPresent().then(function () {
                title.getText().then(function (titleText) {
                    resultArr.push(titleText);
                });
            }).catch(function () {
                tspans.count().then(function (tspanCount) {
                    if (tspanCount === 1) {
                        var tempValue = "";
                        tspans.getText().then(function (singleTSpanValue) {
                            tempValue = tempValue + singleTSpanValue;
                            resultArr.push(tempValue.trim());
                        });
                    } else {
                        var tempValue = "";
                        tspans.each(function (tspan) {
                            tspan.getText().then(function (tspanText) {
                                tempValue = tempValue + tspanText + " ";
                            });
                        }).then(function () {
                            resultArr.push(tempValue.trim());
                        });
                    }
                });
            });
        }).then(function () {
            deferred.fulfill(resultArr);
        });

        return deferred.promise;
    };

    this.getToolTipData = function () {
        var deferred = protractor.promise.defer();
        var dataArr = [];

        dataLabels.each(function (dataLabel) {
            mouseHover(dataLabel);
            toolTipText.getText().then(function (toolTipValue) {
                dataArr.push(toolTipValue);
            });
        }).then(function () {
            deferred.fulfill(dataArr);
        });

        return deferred.promise;
    };

    this.selectDataLabel = function (labelName) {
        dataLabels.filter(function (element) {
            return element.getText().then(function (text) {
                return text.includes(labelName);
            });
        }).first().click().then(function () {
            //TODO wait for load 
            browser.sleep(500);
            angularWait();
        });
    };
};
Chart.prototype = new element_();
module.exports = Chart;