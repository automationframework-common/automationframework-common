var element_ = require("../root/element");

var starRating = require("../components/star.rating");

var KeyPatents = function (keyPatentsGroup) {
    element_.apply(this, [keyPatentsGroup]);

    var externalLinks;

    var showDetailsLinks,
        hideDetailsLinks;



    var keyPatents,
        representativeClaim,
        patentNumber,
        patentNumbers,
        patentRatings,
        annotation,
        techTag,
        theoryOfRelevance,
        patentNumberLabels,
        prc;

    (function () {
        // showDetailsLinks = keyPatentsGroup.all(by.css(".summary-link a .fa.fa-chevron-right"));
        hideDetailsLinks = keyPatentsGroup.all(by.css(".summary-link a .fa.fa-chevron-down"));
        externalLinks = keyPatentsGroup.all(by.css(".fa-external-link"));
        // patentNumbers = keyPatentsGroup.all(by.css(".internal"));
        patentNumbers = element.all(by.css(".sf-patent-details .internal"));
        patentNumberLabels = $(".sf-patent-details .internal");
        showDetailsLinks = $$(".sf-patent-details .summary-link a .fa.fa-chevron-right");
        // keyPatents = keyPatentsGroup.all(by.css(".row.sf-patent-details"));
        keyPatents = $$(".row.sf-patent-details");

    })();

    (function () {
        representativeClaim = element(by.css("i[class='fa fa-check-circle rpx-blue1']"));
        patentNumber = element(by.css("a[ng-click='$ctrl.goToPatentState(patent)']"));
        patentRatings = element(by.css(".card-ratings ul li"));
        annotation = element(by.css(".pat-desc"));
        techTag = element(by.css("div[ng-show='patent.details.tech_tags.length'] .tag-text"));
        theoryOfRelevance = element(by.css("div[ng-show='patent.details.theory_of_relevance.length'] .tag-text"));
        prc = element(by.css("div[ng-show='patent.details.potentially_relevant_companies.length'] .tag-text"));
    })();


    this.showDetails = function () {
        showDetailsLinks.each(function (showDetailLink) {
            showDetailLink.click();
            angularWait();
        });
    };

    this.hideDetails = function () {
        hideDetailsLinks.each(function (hideDetailLink) {
            hideDetailLink.click();
            angularWait();
        });
    };

    this.showDetailsOfPatentClaim = function (patentId) {
        var showDetailLink;
        this.getPatentIndex(patentId).then(function (index) {
            if (index > -1) {
                console.log("Inside Click of Index: ", index);
                showDetailLink = showDetailsLinks.get(index);
                showDetailLink.click();
                angularWait();
            }
        });
    };

    //Getting StarRating value of any competency under a annotated patent;

    this.getStarRatingOfCompetency = function (patentId, starLabel) {
        var deferred = protractor.promise.defer();
        var starRatingElement = element.all(by.xpath("//div[@class='card-ratings']//li[contains(text(),'" + starLabel + "')]/span"));
        var starValue;
        this.getPatentIndex(patentId).then(function (index) {
            if (index > -1) {
                var ratingElement = starRatingElement.get(index);
                ratingElement.all(by.css("i[class='fa ng-scope fa-star']")).count().then(function (starCount) {
                    starValue = starCount;
                    deferred.fulfill(starValue);
                });
            }
        });
        return deferred.promise;
    };

     //Getting overall StarRating value of claim under a annotated patent;

     this.getStarRatingOfClaim= function (patentId) {
        var deferred = protractor.promise.defer();
        var starRatingElement;
        var starValue;
        this.getPatentIndex(patentId).then(function (index) {
            if (index > -1) {
                var patentHandle = keyPatents.get(index);
                starRatingElement = patentHandle.all(by.css("div[ng-repeat='claimRating in patent.details.claim_ratings'] span")).get(0);
                starRatingElement.all(by.css("i[class='fa ng-scope fa-star']")).count().then(function (starCount) {
                    starValue = starCount;
                    deferred.fulfill(starValue);
                });
            }
        });
        return deferred.promise;
    };


    //    Getting Tech Tags value

    this.getTechTagText = function (patentId) {
        var deferred = protractor.promise.defer();
        var tagTextElement;
        var tagText = [];
        this.getPatentIndex(patentId).then(function (index) {
            if (index > -1) {
                var patentHandle = keyPatents.get(index);
                tagTextElements = patentHandle.all(by.css(".sf-patent-details div[ng-show='patent.details.tech_tags.length'] .tag-text"));
                tagTextElements.each(function (tagTextElement){
                    tagTextElement.getText().then(function (text) {
                        tagText.push(text);
                       
                    });
                });
                deferred.fulfill(tagText);
            }
        });
        return deferred.promise;
    };

    //    Getting Theory of Relevance value

    // this.getTheoryOfRelevanceText = function (patentId) {
    //     var deferred = protractor.promise.defer();
    //     var theoryOfRelevanceTextElement;
    //     var tagText;
    //     this.getPatentIndex(patentId).then(function (index) {
    //         if (index > -1) {
    //             var patentHandle = keyPatents.get(index);
    //             theoryOfRelevanceTextElement = patentHandle.all(by.css(".sf-patent-details div[ng-show='patent.details.theory_of_relevance.length'] .tag-text")).get(0);
    //             theoryOfRelevanceTextElement.getText().then(function (text) {
    //                 tagText = text;
    //                 deferred.fulfill(tagText);
    //             });
    //         }
    //     });
    //     return deferred.promise;
    // };

 //    Getting Theory of Relevance value

 this.getTheoryOfRelevanceText = function (patentId) {
    var deferred = protractor.promise.defer();
    var theoryOfRelevanceTextElement;
    var tagText = [];
    this.getPatentIndex(patentId).then(function (index) {
        if (index > -1) {
            var patentHandle = keyPatents.get(index);
            theoryOfRelevanceTextElements = patentHandle.all(by.css(".sf-patent-details div[ng-show='patent.details.theory_of_relevance.length'] .tag-text"));
            theoryOfRelevanceTextElements.each(function (theoryOfRelevanceTextElement){
                theoryOfRelevanceTextElement.getText().then(function (text) {
                    tagText.push(text);
                   
                });
            });
            deferred.fulfill(tagText);
        }
    });
    return deferred.promise;
};


    //    Getting PRC value

    this.getPRCText = function (patentId) {
        var deferred = protractor.promise.defer();
        var prcElement;
        var tagText = [];
        this.getPatentIndex(patentId).then(function (index) {
            if (index > -1) {
                var patentHandle = keyPatents.get(index);
                prcElements = patentHandle.all(by.css(".sf-patent-details div[ng-show='patent.details.potentially_relevant_companies.length'] .tag-text"));
                prcElements.each(function (prcElement){
                    prcElement.getText().then(function (text) {
                        tagText.push(text);
                       
                    });
                });
                deferred.fulfill(tagText);
            }
        });
        return deferred.promise;
    };

    // Getting Memo text under any Memo in Annotated Patents list
    this.getMemoTextInAnnotatedPatent = function (patentId,memo) {
        //memo could be {Analysts Notes,Comparables,Enforcement Review,File History Review,
    //                  Patent Summary,SME Review,Spec Support,Priority Research}
        var deferred = protractor.promise.defer();
        var memoTextElement;
        var memoText;
        this.getPatentIndex(patentId).then(function (index) {
            if (index > -1) {
                var patentHandle = keyPatents.get(index);
                
                // memoTextElement = patentHandle.all(by.xpath("//h5[text()='"+memo+"']/following-sibling::div"));
                memoTextElement =element(by.xpath("//div[contains(@class,'sf-patent-details')]["+(index+1)+"]//h5[text()='"+memo+"']/following-sibling::div"));
               
                memoTextElement.getText().then(function (text) {
                    memoText = text;
                    // console.log("=========================================");
                    // console.log(patentSummaryText);
                    deferred.fulfill(memoText);
                });
            }
        });
        return deferred.promise;
    };

 // Getting Claim Description text for selected patent Annotated Patents list
 this.getClaimTextInAnnotatedPatent = function (patentId) {
    var deferred = protractor.promise.defer();
    var claimDescElement;
    var ClaimText;
    this.getPatentIndex(patentId).then(function (index) {
        if (index > -1) {
            var patentHandle = keyPatents.get(index);
            claimDescElement = patentHandle.all(by.css(".main-claim")).get(0);
            claimDescElement.getText().then(function (text) {
                ClaimText = text.replace(/(\r\n|\n|\r)/gm, "");
                ClaimText = ClaimText.replace(" ","");
                // console.log("=========================================");
                // console.log(ClaimText);
                deferred.fulfill(ClaimText);
            });
        }
    });
    return deferred.promise;
};



    // Checking whether annotated patent is key patent in annotated patent list
    this.isKeyPatent = function (patentId) {
        var deferred = protractor.promise.defer();
        var keyPatentLabel, patentHandle;
        this.getPatentIndex(patentId).then(function (index) {
            if (index > -1) {
                var patentHandle = keyPatents.get(index);
                keyPatentLabel = patentHandle.element(by.css(".key-patent-checkbox"));
                keyPatentLabel.isDisplayed().then(function () {
                    deferred.fulfill(true);
                }).catch(function () {
                    deferred.fulfill(false);
                });

            }
        });
        return deferred.promise;
    };

    // checking a patent is annotated patent from annotated patent list
    this.isAnnotatedPatent = function (patentNumber) {
        var deferred = protractor.promise.defer();
        this.getPatents().then(function (patents) {
            // console.log("Patents : ",patents);
            if (patents.indexOf(patentNumber) > -1) {
                console.log("index ", patents.indexOf(patentNumber));
                deferred.fulfill(true);
            }
            else
                deferred.fulfill(false);
        });
        return deferred.promise;
    };

    // getting index of a patent in KeyPatents list
    this.getPatentIndex = function (patentNumber) {
        var deferred = protractor.promise.defer();
        this.getPatents().then(function (patents) {
            // console.log("Patents : ",patents);
            if (patents.indexOf(patentNumber) > -1) {
                console.log("index ", patents.indexOf(patentNumber));
                deferred.fulfill(patents.indexOf(patentNumber));
            }
            else
                deferred.fulfill("Patent Not in List");
        });
        return deferred.promise;
    };

    

    this.openPatentInNewWindow = function (patentIndex) {
        var patNum = patentNumbers.get(patentIndex).getText();
        externalLinks.get(patentIndex).click();
        angularWait();
        return patNum;
    };

    this.getPatents = function () {
        var deferred = protractor.promise.defer();
        var patArr = [];

        patentNumbers.each(function (patNumber) {
            patNumber.getText().then(function (pNum) {
                // console.log("Pnum: "+pNum);
                patArr.push(pNum);
            });
        }).then(function () {
            deferred.fulfill(patArr);
        });

        return deferred.promise;
    };

    this.getData = function () {
        var dataArr = [];

        this.showDetails();
        keyPatents.each(function (keyPatent) {
            var patDataObj = {};

            getText(keyPatent.element(patentNumber.locator())).then(function (patNum) {
                patDataObj["Patent Number"] = patNum;
            });
            is(keyPatent.element(representativeClaim.locator())).displayed().then(function (value) {
                patDataObj["Has Representative Claim"] = value;
            });
            getText(keyPatent.element(annotation.locator())).then(function (keyPat) {
                patDataObj["Annotation"] = keyPat;
            });
            getAllData(keyPatent.element(techTag.locator())).then(function (tags) {
                patDataObj["Tech Tags"] = tags;
            });
            getAllData(keyPatent.element(theoryOfRelevance.locator())).then(function (theories) {
                patDataObj["Theory of Relevance"] = theories;
            });
            getAllData(keyPatent.element(prc.locator())).then(function (prcs) {
                patDataObj["Potentially Relevant Companies"] = prcs;
            });
            var keyPatentStarRating = new starRating(keyPatent.element(patentRatings.locator()), {
                ratings: element(by.css("span"))
            });

            var ratingsObj = {};
            keyPatentStarRating.getRatings().then(function (ratings) {
                ratingsObj = ratings;
            }).then(function () {
                dataArr.push(Object.assign(patDataObj, ratingsObj));
            });
        }).then(function () {
            return dataArr;
        })
    };
};
KeyPatents.prototype = new element_();
module.exports = KeyPatents;