var element_ = require('../root/element');

var dropDown = require("./dropdown");

var Grid = function (gridElement, params) {
    element_.apply(this, [gridElement]);

    var type,
        columnSelectorType;

    var headerElements,
        rowElements,
        selectIcons,
        expandIcons,
        paginationElement,
        noDataElement;

    var subGrid,
        subGridHeaderElements,
        subGridRowElements;

    var columnOptionsElement,
        columnSelectorDropDown,
        columnSelectCloseIcon,
        deSelectIconsInColumnSelector,
        selectedOptionsInColumnSelector;

    var columnSelectIcon,
        optionsInColumnSelector,
        selectIconsInColumnSelector,
        deleteIconsInColumnSelector;

    (function () {
        type = params["type"];
        columnOptionsElement = params["columnOptions"];
        if (columnOptionsElement !== undefined)
            columnSelectorType = "dropDown";
        else
            columnSelectorType = "menu";

        switch (type) {
            case "pinned":
                headerElements = gridElement.all(by.css("div[class*='contents']>div:not([class*='ui-grid-pinned']) .ui-grid-header .ui-grid-header-cell"));
                rowElements = gridElement.all(by.css("div[class*='contents']>div:not([class*='ui-grid-pinned']) .ui-grid-row"));
                selectIcons = gridElement.all(by.css(".ui-grid div[class*='contents']>div[class*='ui-grid-pinned'] .ui-grid-viewport .ui-grid-icon-ok"));
                break;
            case "subGrid":
                headerElements = gridElement.all(by.css("div[class*='contents']>div:not([class*='ui-grid-pinned']) .ui-grid-header .ui-grid-header-cell"));
                rowElements = gridElement.all(by.css("div[class*='contents']>div:not([class*='ui-grid-pinned']) .ui-grid-row"));
                expandIcons = gridElement.all(by.css(".ui-grid div[class*='contents']>div[class*='ui-grid-pinned'] .ui-grid-row i"));
                subGrid = gridElement.element(by.css(".sub-grid.ui-grid"));
                subGridHeaderElements = subGrid.all(by.css(".ui-grid-header .ui-grid-header-cell"));
                subGridRowElements = subGrid.all(by.css(".ui-grid-row"));
                break;
            default:
                headerElements = gridElement.all(by.css(".ui-grid-header .ui-grid-header-cell"));
                rowElements = gridElement.all(by.css(".ui-grid-row"));
                // This applicable only for SF PRC GRID
                selectIcons = gridElement.all(by.css(".ui-grid div[class*='contents']>div[class*='ui-grid-pinned'] .ui-grid-viewport .ui-grid-icon-ok"));
                break;
        }

        if (columnSelectorType !== undefined) {
            if (columnSelectorType === "dropDown") {
                columnSelectIcon = columnOptionsElement.element(by.css(".fa-bars"));
                columnSelectCloseIcon = columnOptionsElement.element(by.css("div:not([class*='label'])>a .fa-times"));
                columnSelectorDropDown = new dropDown(columnOptionsElement.element(by.css("select")));
                selectedOptionsInColumnSelector = columnOptionsElement.all(by.css(".grid-column-labels-container div"));
                deSelectIconsInColumnSelector = columnOptionsElement.all(by.css(".grid-column-labels-container li>a"))
            } else {
                columnSelectIcon = gridElement.element(by.css(".ui-grid-menu-button"));
                optionsInColumnSelector = gridElement.all(by.css(".ui-grid-menu ul li[class]"));
                selectIconsInColumnSelector = gridElement.all(by.css("ul i[class='ui-grid-icon-ok']"));
                deleteIconsInColumnSelector = gridElement.all(by.css("ul i[class='ui-grid-icon-cancel']"));
            }
        }

        paginationElement = params["pagination"];
        noDataElement = params["noData"];
    })();

    this.getHeaders = function (type) {
        var deferred = protractor.promise.defer();
        var headerElements_;
        var headers = [];

        if (type === "subGrid")
            headerElements_ = subGridHeaderElements;
        else
            headerElements_ = headerElements;

        headerElements_.each(function (headerElem) {
            browser.executeScript("arguments[0].scrollIntoView();", headerElem.getWebElement());
            headerElem.getText().then(function (text) {
                headers.push(text);
            });
            deferred.fulfill(headers);
        });

        return deferred.promise;
    };

    this.getColumn = function (columnName) {
        var deferred = protractor.promise.defer();

        this.getHeaders().then(function (headers) {
            var results = [];
            var columnIndex = (headers.indexOf(columnName) + 1);
            var columnElements = rowElements.all(by.css("div[id*='cell']:nth-of-type(" + columnIndex + ")"));

            getAllData(columnElements).then(function (values) {
                results = results.concat(values);
            }).then(function () {
                is(paginationElement).displayed().then(function (value) {
                    if (value === true) {
                        var nextPageElement = paginationElement.element(by.css("li:nth-last-child(2)"));
                        var paginate = function () {
                            nextPageElement.getAttribute("class").then(function (value) {
                                if (value !== "ng-scope unavailable") {
                                    nextPageElement.click();
                                    angularWait();
                                    getAllData(columnElements).then(function (columnValues) {
                                        results = results.concat(columnValues);
                                    });
                                    paginate();
                                }
                                deferred.fulfill(results);
                            });
                        };
                        paginate();
                    }
                });
            });
        });
        return deferred.promise;
    };

    this.getFirstPageColumn = function (columnName) {
        var deferred = protractor.promise.defer();

        this.getHeaders().then(function (headers) {
            var columnIndex = (headers.indexOf(columnName) + 1);
            var columnElements = rowElements.all(by.css("div[id*='cell']:nth-of-type(" + columnIndex + ")"));
            getAllData(columnElements).then(function (values) {
                deferred.fulfill(Object.keys(values).map(function (a) {
                    if (values[a]) {
                        // console.log("value: "+values[a]);
                        return values[a];
                    }
                }));
            });
        });

        return deferred.promise;
    };


    this.clickColumn = function (columnName, rowIndex) {
        var deferred = protractor.promise.defer();

        this.getHeaders().then(function (headers) {
            var columnIndex = (headers.indexOf(columnName) + 1);
            rowElements.all(by.css("div[id*='cell']:nth-of-type(" + columnIndex + ") a")).get(rowIndex).click().then(function () {
                deferred.fulfill();
            });
        });

        return protractor.promise;
    };

    this.clickCell = function (rowIndex, columnName) {
        var deferred = protractor.promise.defer();

        this.getHeaders().then(function (headers) {
            var columnIndex = (headers.indexOf(columnName) + 1);
            var cellElement = rowElements.get(rowIndex).element(by.css("div[id*='cell']:nth-of-type(" + columnIndex + ")"));
            cellElement.click().then(function () {
                angularWait();
                deferred.fulfill(cellElement.getText());
            });
        });

        return deferred.promise;
    };

    this.clickCellWithTextOf = function (searchTerm) {
        var deferred = protractor.promise.defer();


        // var cellElement = rowElements.get(rowIndex).element(by.css("div[id*='cell']:nth-of-type(" + columnIndex + ")"));
        var cellElement = element(by.xpath("//div[contains(@class,'rpx-grid')]//a[text()='" + searchTerm + "']"));

        cellElement.click().then(function () {
            angularWait();
            deferred.fulfill(cellElement.getText());
        });


        return deferred.promise;
    };



    this.clickRowAndGetCellData = function (rowIndex, columnName) {
        var deferred = protractor.promise.defer();

        this.getHeaders().then(function (headers) {
            var columnIndex = (headers.indexOf(columnName) + 1);
            var cellElement = rowElements.get(rowIndex).element(by.css("div[id*='cell']:nth-of-type(" + columnIndex + ")"));
            rowElements.get(rowIndex).click().then(function () {
                angularWait();
                deferred.fulfill(cellElement.getText());
            });
        });

        return deferred.promise;
    };

    this.selectRow = function (rowIndex, columnName) {
        var deferred = protractor.promise.defer();
        var this_ = this;

        selectIcons.get(rowIndex).getAttribute("class").then(function (classValue) {
            if (!classValue.includes("ui-grid-row-selected")) {
                selectIcons.get(rowIndex).click().then(function () {
                    angularWait();
                    if (columnName !== undefined) {
                        this_.getHeaders().then(function (headers) {
                            var columnIndex = (headers.indexOf(columnName) + 1);
                            deferred.fulfill(rowElements.get(rowIndex).element(by.css("div[id*='cell']:nth-of-type(" + columnIndex + ")")).getText());
                        });
                    }
                });
            }
        });

        return deferred.promise;
    };

    this.deSelectRow = function (rowIndex) {
        selectIcons.get(rowIndex).getAttribute("class").then(function (classValue) {
            if (classValue.includes("ui-grid-row-selected")) {
                selectIcons.get(rowIndex).click().then(function () {
                    //TODO wait for load
                    browser.sleep(500);
                    angularWait();
                });
            }
        });
    };

    this.getRow = function (rowIndex) {

    };

    this.sort = function (columnName, sortType, type) {
        var deferred = protractor.promise.defer();
        var headerElement_;

        if (type === "subGrid") {
            headerElement_ = subGridHeaderElements;
        } else {
            headerElement_ = headerElements;
        }

        this.getHeaders(type).then(function (columns) {
            var columnElementIndex = columns.indexOf(columnName);
            /** CHECK -1 SCENARIO **/
            var sortClassElement = headerElement_.get(columnElementIndex).element(by.css(".sortable"));

            var sortCount = 1;
            while (sortCount <= 2) {
                sortClassElement.getAttribute("aria-sort").then(function (attribValue) {
                    if (attribValue.includes(sortType) === false) {
                        browser.executeScript("arguments[0].scrollIntoView();", headerElement_.get(columnElementIndex).getWebElement());
                        headerElement_.get(columnElementIndex).click();
                        angularWait();
                    }
                });
                sortCount++;
            }

            deferred.fulfill();
        });
        return deferred.promise;
    };

    this.openColumnSelector = function () {
        var deferred = protractor.promise.defer();

        if (columnSelectorType === "dropDown") {
            columnOptionsElement.element(by.css(".action-sheet")).getAttribute("class").then(function (classValue) {
                if (!classValue.includes("is-active")) {
                    columnSelectIcon.click().then(function () {
                        deferred.fulfill(angularWait());
                    });
                }
            });
        } else {
            optionsInColumnSelector.count().then(function (optionsCount) {
                if (optionsCount === 0) {
                    columnSelectIcon.click().then(function () {
                        deferred.fulfill(angularWait());
                    });
                }
            });
        }
        return deferred.promise;
    };

    this.closeColumnSelector = function () {
        if (columnSelectorType === "dropDown") {
            columnOptionsElement.element(by.css(".action-sheet")).getAttribute("class").then(function (classValue) {
                if (classValue.includes("is-active")) {
                    columnSelectCloseIcon.click().then(function () {
                        angularWait();
                    });
                }
            });
        } else {
            optionsInColumnSelector.count().then(function (optionsCount) {
                if (optionsCount > 0) {
                    columnSelectIcon.click();
                }
            });
        }
    };

    this.columnSelector = function () {
        var _this = this;
        var deferred = protractor.promise.defer();

        return {
            getAvailableColumns: function () {
                _this.openColumnSelector();

                if (columnSelectorType === "dropDown") {
                    deferred.fulfill(columnSelectorDropDown.getAvailableOptions());
                } else {
                    getAllData(optionsInColumnSelector).then(function (columnOptions) {
                        deferred.fulfill(columnOptions);
                    });
                }
                _this.closeColumnSelector();

                return deferred.promise;
            },
            selectAllColumns: function () {
                _this.openColumnSelector();

                if (columnSelectorType === "dropDown") {
                    deferred.fulfill(columnSelectorDropDown.selectAllOptions());
                } else {
                    deleteIconsInColumnSelector.each(function (deletedColumn) {
                        deletedColumn.click();
                    });
                }
                _this.closeColumnSelector();

                return deferred.promise;
            },
            deSelectAllColumns: function () {
                _this.openColumnSelector();

                if (columnSelectorType === "dropDown") {
                    var closeIcons = deSelectIconsInColumnSelector;
                    closeIcons.count().then(function (count) {
                        while (count > 0) {
                            closeIcons.get(0).click();
                            angularWait();
                            count--;
                        }
                    });
                } else {
                    selectIconsInColumnSelector.each(function (selectedColumn) {
                        selectedColumn.click();
                    });
                }
                _this.closeColumnSelector();

                return deferred.promise;
            }
        }
    };

    this.subGrid = function () {
        var _this = this;

        return {
            expandFirst: function () {
                expandIcons.get(0).click();
                angularWait();
            },
            sort: function (columnName, sortType) {
                return _this.sort(columnName, sortType, "subGrid");
            },
            getHeaders: function () {
                return _this.getHeaders("subGrid");
            },
            getColumn: function (columnName) {
                return _this.getSubTableColumn(columnName);
            }
        }
    };

    this.getSubTableColumn = function (columnName) {
        var deferred = protractor.promise.defer();

        this.getHeaders("subGrid").then(function (headersList) {
            var columnIndex = (headersList.indexOf(columnName) + 1);
            var columnElements = subGridRowElements.all(by.css("div[id*='cell']:nth-of-type(" + columnIndex + ")"));

            getAllData(columnElements).then(function (columnList) {
                deferred.fulfill(columnList);
            });
        });

        return deferred.promise;
    };

    /***** bulk grid functions****/
    // get row index of any patent of claim number given
    this.getRowIndex = function (patentNumber) {

        var deferred = protractor.promise.defer();
        this.getBulkGridPatents().then(function (patents) {
            console.log("index ", patents.indexOf(patentNumber));
            deferred.fulfill(patents.indexOf(patentNumber));


        });
        return deferred.promise;
    };

    // This function is to check the search results {Note the keyword should be exact including spaces}

    this.isKeywordPresentInGrid = function (keyword) {
        var deferred = protractor.promise.defer();
        var keyWordElement = gridElement.element(by.xpath("//*[text()='" + keyword + "']"));
        keyWordElement.isDisplayed().then(function () {
            deferred.fulfill(true);
        }).catch(function () {
            deferred.fulfill(false);
        });
        return deferred.promise;
    }

// This function is to check the search results {Note the keyword should be exact including spaces}

this.isFieldPresentInGrid = function (field) {
    var deferred = protractor.promise.defer();
    var keyWordElement = gridElement.element(by.xpath("//*[text()='" + field + "']"));
    keyWordElement.isDisplayed().then(function () {
        deferred.fulfill(true);
    }).catch(function () {
        deferred.fulfill(false);
    });
    return deferred.promise;
}


    // This function gets us the count of patents in grid. This text present above the grid
    this.getCountofPatentsinGrid = function () {
        var patentCount = $(".patent-count ng-pluralize");
        var deferred = protractor.promise.defer();
        patentCount.getText().then(function (count) {
            deferred.fulfill(count);
        });
        return deferred.promise;

    }

    // This selects the tick mark of row which contains the searchterm{search term is patnum or claim num}
    this.clickSelectIconOfRow = function (searchTerm) {
        var selectIcons = $$(".bulk-tagging-modal .ui-grid-icon-ok");
        this.getRowIndex(searchTerm).then(function (index) {
            selectIcons.get(index + 1).click();
            angularWait();


        });

    };

    // Select all rows by clicking tick icon at header
    this.selectAllRows = function () {
        var selectIcons = $$(".bulk-tagging-modal .ui-grid-icon-ok");
        selectIcons.get(0).click();
        angularWait();
    };

    // Expand all - By clicking all the expand (+) buttons iteratively in a grid
    this.bulkGridExpandAll = function () {
        var bulkGridExpandIcons = element.all(by.css(".bulk-tagging-modal .ui-grid-icon-plus-squared"));
        bulkGridExpandIcons.each(function () {
            bulkGridExpandIcons.get(0).click();
            angularWait();
        });
    };

    this.getBulkGridPatents = function () {
        var deferred = protractor.promise.defer();
        var patArr = [];
        var formattedText;
        var patColElements = element.all(by.xpath("//span[contains(@ng-if,'row.entity.claim_num')]"));
        patColElements.each(function (patNumber) {
            patNumber.getText().then(function (pNum) {
                formattedText = pNum.trim();
                // console.log("Pnum: "+formattedText);
                patArr.push(formattedText);
            });
        }).then(function () {
            deferred.fulfill(patArr);
        });

        return deferred.promise;
    };



};
Grid.prototype = new element_();
module.exports = Grid;