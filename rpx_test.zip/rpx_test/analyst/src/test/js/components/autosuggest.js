var element_ = require('../root/element');

var AutoSuggest = function (autoSuggestElement, params) {
    element_.apply(this, [autoSuggestElement]);

    var searchInput,
        searchResults,
        clearIcon,
        enabled,
        selectedValueElement;

    //AUTH ELEMENT
    this.closeIcon = (params["clear"] !== undefined ?
        autoSuggestElement.element(params["clear"].locator()) : "");
    
    

    (function () {
        if (params["input"] !== undefined)
            searchInput = autoSuggestElement.element(params["input"].locator());
        
       

        if (params["options"] !== undefined)
            searchResults = autoSuggestElement.element(params["options"].locator());

        if (params["clear"] !== undefined)
            clearIcon = autoSuggestElement.element(params["clear"].locator());

        if (params["selectedValue"] !== undefined)
            selectedValueElement = autoSuggestElement.element(params["selectedValue"].locator());
    })();

    this.getSelectedData = function () {
        var deferred = protractor.promise.defer();

        selectedValueElement.getText().then(function (value) {
            deferred.fulfill(value);
        });

        return deferred.promise;
    };

    this.enabled = autoSuggestElement.element(by.css("div[aria-disabled='false']"));

    this.search = function (searchText) {
        var deferred = protractor.promise.defer();

        if(clearIcon === undefined) {
            protractor.promise.all([
                autoSuggestElement.click(),
                searchInput.sendKeys(searchText),
                angularWait()
            ]).then(function () {
                deferred.fulfill();
            });
        } else {
            clearIcon.isDisplayed().then(function () {
                clearIcon.click();
                angularWait();
            }).catch(function () {
            }).then(function () {
                autoSuggestElement.click().then(function () {
                    searchInput.sendKeys(searchText).then(function () {
                        angularWait();
                    });
                });
                deferred.fulfill();
            });
        }

        return deferred.promise;
    };

    this.select = function (searchText) {
        var deferred = protractor.promise.defer();

        this.search(searchText).then(function () {
            element.all(searchResults.locator()).get(0).click().then(function () {
                angularWait();
                deferred.fulfill();
            });
            angularWait();
        });

        return deferred.promise;
    };

    this.getAutoSuggestOptions = function (searchText) {
        var deferred = protractor.promise.defer();
        this.search(searchText).then(function () {
            getAllData(searchResults).then(function (values) {
                deferred.fulfill(values);
            });
        });
        return deferred.promise;
    };
};
AutoSuggest.prototype = new element_();
module.exports = AutoSuggest;