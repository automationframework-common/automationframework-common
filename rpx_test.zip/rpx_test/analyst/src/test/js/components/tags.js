var element_ = require("../root/element");

var confirmationModal = require("../pages/modals/confirmation.modal"),
    prcModal = require("../pages/modals/prc.modal"),
    theoryModal = require("../pages/modals/theory.modal");

var starRating = require("../components/star.rating"),
    checkBox = require("../components/checkbox");

/**
 * @param tagsElement
 * @param {Object} params
 * @param {String} params.type - Type of the tag list star/badge/default
 * @constructor
 */
var Tags = function (tagsElement, params) {
    element_.apply(this, [tagsElement]);

    var type;

    var tagsText,
        tagsClose,freeformTexts,
        freeformTagsClose,
        tagsLinks;

    var rows,
        starRatings;

    //AUTH ELEMENTS
    this.closeIcon = tagsElement.element(by.css(".tag-remove"));
    //CURRENTLY A SINGLE ELEMENT WITHIN THE TAG GROUP CAN BE SET FOR ENABLE/DIABLE CHECK
    this.enabled = (params["enabled"] !== undefined ?
        tagsElement.element(params['enabled'].locator()) : null);
    this.disabled = (params["disabled"] !== undefined ?
        tagsElement.element(params['disabled'].locator()) : null);

    (function () {
        type = params["type"];
        if (type === "prc") {
            type = "badge";
        } else if (type === "tech") {
            type = "star";
        } else if (type === "theory") {
            type = "default";
        }
        else if (type === "default") {
            type = "default";
        }

        tagsText = tagsElement.all(by.css(".tag-text"));
        // tagsText = tagsElement.all(by.css(".tech-tag"));
        freeformTexts = tagsElement.all(by.css(".ui-select-match-item"))
        this.freeformTagsClose = element(by.css(".claim-rating freeform-tag-selector .ui-select-match .close"));
        tagsClose = (params["close"] !== undefined ?
            tagsElement.all(params["close"].locator()) : tagsElement.all(by.css(".tag-remove.ng-scope")));
        tagsLinks = tagsElement.all(by.css(".tag-text.underline"));
        // tagsLinks = tagsElement.all(by.css(".tech-tag"));

        rows = params["rows"];
        if (type === "star") {
            starRatings = new starRating(rows, {
                // labels: element(by.css("div[class*='tag-text']")),
                labels: element(by.css("div[class*='tech-tag']")),
                ratings: element(by.css("span[class*='tech_tags_rating']"))
            });
        }
    })();

    // Patent header free tags
    this.getFreeFormedTags = function(){
        var deferred = protractor.promise.defer();
        var data = [];
        freeformTexts.each(function (freeformtext) {
            freeformtext.getText().then(function (tagText) {
               data.push(tagText)
                });
                deferred.fulfill(data);
            });
            return deferred.promise;
        };
// Getting theory tags text

this.getTagsText = function(){
    var deferred = protractor.promise.defer();
    var data  = [];
        
            tagsText.each(function (tags) {
                tags.getText().then(function (tagText) {
                    
                   data.push(tagText)
                    });
                    deferred.fulfill(data);
                    console.log(" INside Tags Text:" + data);
                });        
                console.log("Tags Text:" + data);
             
            return deferred.promise;
    };

       
    this.clickTagLink = function (index) {
        if (typeof index === "string")
            tagsLinks.get(parseInt(index)).click();
        else
            tagsLinks.get(index).click();
        angularWait();
    };

    this.clickTag = function (tagName) {
        var deferred = protractor.promise.defer();
        var data = [];
        tagsLinks.each(function (tagsLink) {
            tagsLink.getText().then(function (tagText) {
                if (tagText === tagName) {
                    deferred.fulfill(tagsLink.click());
                }
            });
        });

        return deferred.promise;
    };

    this.deleteAll = function () {
        tagsClose.each(function (tagClose) {
            tagClose.click();
            confirmationModal.panel.isPresent().then(function () {
                confirmationModal.confirm();
            }).catch(function () { });
            angularWait();
        });
    };

//TODO : Chech this code is right. There is no defn for getAllData
    this.getTags = function () {
        return getAllData(tagsText);
    };





    
    this.setTagStarRatings = function (ratingsDataObj) {
        starRatings.setStarRatings(ratingsDataObj,"tags")
    };

    this.getData = function () {
        var deferred = protractor.promise.defer();

        if (type === "star") {
            deferred.fulfill(starRatings.getRatings());
        } else if (type === "badge") {
            deferred.fulfill(this.getBadgeTagsData());
        } else {
            deferred.fulfill(this.getModalTagsData());
        }

        return deferred.promise;
    };

    //TODO MOVE THIS TO SEPERATE COMPONENT IF REQUIRED
    this.getBadgeTagsData = function () {
        var deferred = protractor.promise.defer();
        var data = [];

        element.all(rows.locator()).each(function (row) {
            var rowData = {};

            var tagLink = row.element(by.css(".tag-text.underline"));
            var claimCharted = new checkBox(row.element(by.css(".prc-right-section input")));
            var theoryCount = row.element(by.css(".theory-count"));
            var techTagCount = row.element(by.css(".tech-tag-count"));

            //TAG AND MODAL DATA
            tagLink.getText().then(function (tagValue) {
                tagLink.click().then(function () {
                    angularWait();
                    prcModal.getData().then(function (tagModalData) {
                        rowData["prc"] = tagValue;
                        rowData["modalContent"] = tagModalData;
                    });
                });
            }).then(function () {
                //CHARTED FLAG, THEORY AND TECHNOLOGY COUNT
                claimCharted.isChecked().then(function (status) {
                    theoryCount.getText().then(function (theoryValue) {
                        techTagCount.getText().then(function (techTagValue) {
                            rowData["claimCharted"] = status
                            rowData["theoryCount"] = theoryValue;
                            rowData["techTagCount"] = techTagValue;
                        });
                    });
                }).then(function () {
                    data.push(rowData);
                });
            });
        }).then(function () {
            deferred.fulfill(data);
        });

        return deferred.promise;
    };

    this.getModalTagsData = function () {
        var deferred = protractor.promise.defer();
        var data = [];

        tagsLinks.each(function (tagLink) {
            var rowData = {};

            protractor.promise.all([
                tagLink.getText(),
                tagLink.click(),
                theoryModal.getData()
            ]).then(function (dataArray) {
                rowData = dataArray[2];
                rowData["linkText"] = dataArray[0];
            }).then(function () {
                data.push(rowData);
            });
        }).then(function () {
            deferred.fulfill(data);
        });

        return deferred.promise;
    };

    this.setData = function (dataObj) {
        if (type === "star") {
            this.setTagStarRatings(dataObj);
        } else if (type === "badge") {
            for (var key in dataObj) {
                this.setBadgeTags(key, dataObj[key]);
            }
        } else {
            for (var key in dataObj) {
                this.setModalTags(key, dataObj[key]);
            }
        }
    };

    this.setModalTags = function (tag, modalData) {
        var deferred = protractor.promise.defer();

        this.clickTag(tag).then(function () {
            deferred.fulfill(theoryModal.save(modalData));
        });

        return deferred.promise;
    };

    this.setBadgeTags = function (tag, tagData) {
        var deferred = protractor.promise.defer();
        var this_ = this;

        element.all(rows.locator()).each(function (row) {
            row.element(by.css(".tag-text.underline")).getText().then(function (tagValue) {
                if (tagValue === tag) {
                    var chartedElem = new checkBox(row.element(by.css(".prc-right-section input")));
                    chartedElem.select(tagData["isCharted"]);
                }
            });
        }).then(function () {
            this_.clickTag(tag).then(function () {
                deferred.fulfill(prcModal.save(tagData));
            });
        });

        return deferred.promise;
    };
};
Tags.prototype = new element_();
module.exports = Tags;