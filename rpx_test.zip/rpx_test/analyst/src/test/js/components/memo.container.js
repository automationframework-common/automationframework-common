var element_ = require('../root/element');

var quillEditor = require("../components/quill.editor");

var MemoContainer = function (memoContainerElement, params) {
    element_.apply(this, [memoContainerElement]);

    var createDropDown,
        createDisabled,
        createOptions,

        filterIcon,
        filterOptions,
        filterHeader,

        content,
        contentList,
        contentMessage,

        saveBtn,
        cancelBtn;

    //AUTH ELEMENTS        
    this.createDropdownElem = memoContainerElement.element(params["createDropDown"].locator());
    this.filterIcon = memoContainerElement.element(params["filterIcon"].locator());

    (function () {
        createDropDown = memoContainerElement.element(params["createDropDown"].locator());        
        createDisabled = memoContainerElement.element(params["createDisabled"].locator());
        createOptions = memoContainerElement.element(by.css("ul[class*='f-open-dropdown'] li:not([class='filter-header'])"));

        filterIcon = memoContainerElement.element(params["filterIcon"].locator());
        filterOptions = memoContainerElement.element(by.css("ul[class*='f-open-dropdown'][id*='filter_dropdown'] li:not([class='filter-header'])"));
        filterHeader = memoContainerElement.element(by.css("ul[class*='f-open-dropdown'] li a"));

        content = memoContainerElement.element(params["content"].locator());
        contentList = content.element(by.css("div[id*='annotation']:not([class*='.no-annotations-message'])"));
        contentMessage = content.element(by.css(".no-annotations-message"));

        saveBtn = memoContainerElement.element(by.css("button[ng-click*='onSave']"));
        cancelBtn = memoContainerElement.element(by.css("#patent-annotation-AN button[ng-click*='onCancel']"));
    })();

    this.getData = function () {
        var deferred = protractor.promise.defer();
        var content = {};

        element.all(contentList.locator()).map(function(item) {
            item.element(by.css("h5")).getText().then(function (header) {
                header = header.replace("\nNew Association", "").trim();
                if(header !== '') {
                    item.element(by.css(".panel")).getText().then(function (text) {
                        content[header] = text.toString().trim();
                    });
                }
            });
        }).then(function() {
            deferred.fulfill(content);
        });
        return deferred.promise;
    };

    this.clearAll = function () {
        var deferred = protractor.promise.defer();
        var savebtn = element(by.xpath("//button[contains(text(),'Save')]"));
        element.all(contentList.locator()).map(function (item) {
            item.element(by.css(".panel.word-wrap")).click().then(function () {
                var editorElem = new quillEditor(item);
                editorElem.clearEntry();
                angularWait();
                savebtn.click();
            });
        }).then(function () {
            deferred.fulfill();
        });
        return protractor.promise;
    };
// Deprecated old code at annotated patents 
    // this.openCreateDropDown = function () {
    //     createOptions.isDisplayed().then().catch(function () {
    //         createDropDown.click();
    //     });
    // };
    this.openCreateDropDown = function () {
        createDropDown.click().then(function(){
            angularWait();
        });
    };

    //REFACTOR
    this.getAvailableCreateOptions = function () {
        var deferred = protractor.promise.defer();
        var options = [];
        this.openCreateDropDown();
        element.all(createOptions.locator()).then(function (createOptions) {
            for (var optionsCount = 0; optionsCount < createOptions.length; optionsCount++) {
                createOptions[optionsCount].getText().then(function (optionText) {
                    options.push(optionText.trim());
                });
            }
        }).then(function () {
            deferred.fulfill(options);
        });
        return deferred.promise;
    };

    this.selectCreateOption = function (option) {
        this.openCreateDropDown();
        filterTextAndClick(createOptions.locator(), option);
        angularWait();
    };

    this.save = function (option, value) {
        var deferred = protractor.promise.defer();

        this.selectCreateOption(option);
        var editorElement = new quillEditor(element(by.xpath("//h5[contains(text(),'" + option + "')]/parent::div")));
        editorElement.enterText(value);
        saveBtn.click().then(function () {
            deferred.fulfill(angularWait());
        });

        return deferred.promise;
    };

    this.isCreateDisabled = function () {
        return createDisabled.isDisplayed();
    };

    this.openFilterDropDown = function () {
        filterOptions.isDisplayed().then().catch(function () {
            filterIcon.click();
        });
    };

    //REFACTOR
    this.getAvailableFilterOptions = function () {
        var deferred = protractor.promise.defer();
        var options = [];
        this.openFilterDropDown();
        element.all(filterOptions.locator()).then(function (filterOptions) {
            for (var optionsCount = 0; optionsCount < filterOptions.length; optionsCount++) {
                filterOptions[optionsCount].getText().then(function (filterText) {
                    options.push(filterText.trim());
                });
            }
        }).then(function () {
            deferred.fulfill(options);
        });
        return deferred.promise;
    };

    this.selectFilterOption = function (option) {
        this.deselectAllFilterOptions();
        filterTextAndClick(filterOptions.locator(), option);
    };

    this.selectAllFilterOptions = function () {
        this.openFilterDropDown();
        filterTextAndClick(filterHeader.locator(), 'Select All');
    };

    this.deselectAllFilterOptions = function () {
        this.openFilterDropDown();
        filterTextAndClick(filterHeader.locator(), 'Unselect All');
    };

    this.getMessage = function () {
        var deferred = protractor.promise.defer();
        contentMessage.getText().then(function (text) {
            deferred.fulfill(text);
        });
        return deferred.promise;
    };
};
MemoContainer.prototype = new element_();
module.exports = MemoContainer;