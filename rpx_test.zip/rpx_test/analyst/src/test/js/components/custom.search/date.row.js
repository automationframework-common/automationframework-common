var element_ = require("../../root/element");

var DateRow = function (dateRowElement) {

    var fromDate,
        toDate,
        closeElement;

    (function() {
        fromDate = dateRowElement.element(by.css("input[name='fromDate']"));
        toDate = dateRowElement.element(by.css("input[name='toDate']"));
        closeElement = dateRowElement.element(by.css("a[class*='right'] .fa-times"));
    })();

    this.enterDates = function (fDate, tDate) {
        fromDate.sendKeys(fDate);
        toDate.sendKeys(tDate);
    };

    this.closeRow = function () {
        closeElement.click();
        angularWait();
    };
};
DateRow.prototype = new element_();
module.exports = DateRow;