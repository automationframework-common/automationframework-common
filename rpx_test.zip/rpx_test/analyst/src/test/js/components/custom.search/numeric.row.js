var element_ = require("../../root/element");

var dropDownComponent = require("../../components/dropdown");

var NumericRow = function (numericRowElement) {

    var numericDropdown,
        numericEqualsElement,
        numericBetweenElement,
        closeElement;

    (function() {
        var dropdownElement = numericRowElement.element(by.css("select"));
        numericDropdown = new dropDownComponent(dropdownElement);
        numericEqualsElement = numericRowElement.element(by.css("span[ng-show*='equals']"));
        numericBetweenElement = numericRowElement.element(by.css("span[ng-show*='between']"));
        closeElement = numericRowElement.element(by.css("a[class*='right'] .fa-times"));
    })();

    this.set = function(type, value1, value2) {
        numericDropdown.select(type);
        if(type === "equals") {
            numericEqualsElement.element(by.css("input")).sendKeys(value1);
        } else {
            /** TODO Handle clear and between logic **/
        }
    };

    this.closeRow = function () {
        closeElement.click();
        angularWait();
    };
};
NumericRow.prototype = new element_();
module.exports = NumericRow;