var element_ = require("../../root/element");

var TextRow = function (textRowElement, params) {

    var textAreaElement,
        clearIconElement,
        closeElement;

    (function () {
        textAreaElement = textRowElement.element(params["input"].locator());
        clearIconElement = textRowElement.element(by.css(".fa-minus-circle"));
        closeElement = textRowElement.element(by.css("a[class*='right'] .fa-times"));
    })();

    this.enterSearchTerm = function (searchTerm) {
        var deferred = protractor.promise.defer();

        if (closeElement.isPresent() === false)
            closeElement.click();
        textAreaElement.sendKeys(searchTerm).then(function () {
            deferred.fulfill(angularWait());
        });

        return deferred.promise;
    };

    this.inputSearchTermWithEnterKey = function (searchTerms) {
        var deferred = protractor.promise.defer();

        for (var searchTermIndex in searchTerms) {
            textAreaElement.sendKeys(searchTerms[searchTermIndex]).then(function () {
                browser.actions().sendKeys(protractor.Key.ENTER).perform();
            });
        }

        return deferred.promise;
    };

    this.closeRow = function () {
        closeElement.click();
        angularWait();
    };
};
TextRow.prototype = new element_();
module.exports = TextRow;