var element_ = require("../../root/element");

var radioButtonComponent = require("../../components/radio.button");

var RadioGroupRow = function (radioGroupElement) {

    var radio,
        closeElement;

    (function() {
        // var radioElement = radioGroupElement.element(by.css("div:nth-of-type(2)[class*='small-7']"));
        var radioElement = radioGroupElement.element(by.css("radiobutton-group-row"));
        radio = new radioButtonComponent(radioElement);
        closeElement = radioGroupElement.element(by.css("a[class*='right'] .fa-times"));
    })();

    this.select = function(option) {
        radio.selectContainingValue(option);
    };

    this.closeRow = function () {
        closeElement.click();
        angularWait();
    };
};
RadioGroupRow.prototype = new element_();
module.exports = RadioGroupRow;