var element_ = require("../../root/element");

var autoSuggestComponent = require("../../components/autosuggest");

var FacetRow = function (facetElement) {

    var autoSuggest,
        closeElement;

    var options,
        selectedOptions;

    var facetExpandIcon,
        facetCloseIcon;

    (function () {
        var autoSuggestElement = facetElement.element(by.css("span[class*='rpx-bootstrap']"));
        autoSuggest = new autoSuggestComponent(autoSuggestElement, {
            "input": element(by.css("input[class*='ui-select-search']")),
            "options": element(by.css(".ui-select-choices-row-inner div")),
            "clear": element(by.css("a[class*='rpx-alert']>i"))
        });
        closeElement = facetElement.element(by.css("a[class*='right'] .fa-times"));

        facetExpandIcon = facetElement.element(by.css(".fa-chevron-right"));
        facetCloseIcon = facetElement.element(by.css(".fa-chevron-down"));

        selectedOptions = facetElement.all(by.css(".label.facet.active"));
        options = facetElement.all(by.css(".label.facet"));
    })();

    this.select = function (option) {
        return autoSuggest.select(option);
    };

    this.openFacet = function () {
        facetExpandIcon.isDisplayed().then(function () {
            facetExpandIcon.click();
            angularWait();
        }).catch(function () { });
    };

    this.getSelectedOptions = function () {
        return getAllData(selectedOptions);
    };

    this.deSelectAllOptions = function () {
        this.openFacet();
        selectedOptions.each(function (selectedOption) {
            selectedOption.click();
            angularWait();
        });
    };

    this.selectFromAvailableOptions = function (option) {
        this.openFacet();
        options.filter(function (element) {
            return element.getText().then(function (text) {               
                if (text === option) {                    
                    return element.getAttribute("class").then(function (classValue) {                       
                        return !classValue.includes("active");                            
                    });
                }
            });
        }).first().click();
    };
};
FacetRow.prototype = new element_();
module.exports = FacetRow;