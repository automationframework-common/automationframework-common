var element_ = require("../../root/element");

var checkBox = require("../../components/checkbox");

var CheckBoxRow = function(checkBoxRowElement) {
    var checkBoxGroupElement;

    (function () {
        // checkBoxGroupElement = checkBoxRowElement.element(by.css(".columns.small-7"));
        checkBoxGroupElement = checkBoxRowElement.element(by.css("checkbox-group-row"));
    })();

    this.deselectAll = function () {
        checkBoxGroupElement.all(by.css("input")).each(function (checkBoxInput) {
            var checkBoxElement = new checkBox(checkBoxInput);
            checkBoxElement.unCheck();
        });
    };

    this.select = function(option) {
        var labelElement = checkBoxGroupElement.element(by.xpath("//label[text()='" + option + "']"));
        labelElement.getAttribute("for").then(function (forValue) {
            var checkBoxElement = new checkBox($("input[id='" + forValue + "']"));
            checkBoxElement.check();
        });
    };
};
CheckBoxRow.prototype = new element_();
module.exports = CheckBoxRow;