var element_ = require("../root/element");

var SearchSelect = function (searchSelectElement, params) {
    element_.apply(this, [searchSelectElement]);

    var searchInput,
        searchResults,
        closeIcon,
        selectedRecords;

    (function () {
        if (params["input"] !== undefined)
            searchInput = searchSelectElement.element(params["input"].locator());
        if (params["options"] !== undefined)
            searchResults = searchSelectElement.element(params["options"].locator());
        if (params["close"] !== undefined)
            closeIcon = searchSelectElement.element(params["close"].locator());
        if (params["selectedOptions"] !== undefined)
            selectedRecords = searchSelectElement.all(params["selectedOptions"].locator());
    })();

    //AUTH ELEMENTS
    this.closeIcons = (params["close"] !== undefined ?
        searchSelectElement.element(params["close"].locator()) : "");

    this.search = function (searchText) {
        var deferred = protractor.promise.defer();

        searchSelectElement.click().then(function () {
            searchInput.clear().then(function () {
                searchInput.sendKeys(searchText).then(function () {
                    angularWait();
                });
            });
        }).then(function () {
            deferred.fulfill();
        });

        return deferred.promise;
    };

    this.select_ = function (searchText) {
        var deferred = protractor.promise.defer();

        this.search(searchText).then(function () {
            waitFor(searchResults).presence();
            var optionToSelect = element.all(searchResults.locator()).get(0);
            optionToSelect.click().then(function () {
                angularWait();
                deferred.fulfill(closeIcon.click());
            });
        });

        return deferred.promise;
    }

    this.select = function (searchText) {
        var deferred = protractor.promise.defer();

        if (typeof searchText === "object") {
            for (var text of searchText) {
                deferred.fulfill(this.select_(text));
            }
        } else {
            deferred.fulfill(this.select_(searchText));
        }

        return deferred.promise
    };

    this.clickAndSelect = function (searchText) {
        var deferred = protractor.promise.defer();

        this.search(searchText).then(function () {
            searchInput.click();
            angularWait();
            waitFor(searchResults).presence();
            var optionToSelect = element.all(searchResults.locator()).get(0);
            optionToSelect.click().then(function () {
                angularWait();
                deferred.fulfill(closeIcon.click());
            });
        });

        return deferred.promise;
    };

    this.getSelectedOptions = function () {
        return getAllData(selectedRecords);
    };
};
SearchSelect.prototype = new element_();
module.exports = SearchSelect;