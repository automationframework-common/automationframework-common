var element_ = require("../root/element")

var PaddleSwitch = function (paddleSwitchGroupRows, params) {
    element_.apply(this, [paddleSwitchGroupRows]);

    var paddleSwitches;

    var label,
        switchIcon;

    (function () {
        label = params["label"];
        switchIcon = params["switchIcon"];

        paddleSwitches = element.all(paddleSwitchGroupRows.locator());
    })();

    this.getLabels = function () {
        var deferred = protractor.promise.defer();
        var labelsArr = [];

        paddleSwitches.each(function (paddleSwitchElement) {
            paddleSwitchElement.element(label.locator()).getText().then(function (labelValue) {
                labelsArr.push(labelValue);
            });
        }).then(function () {
            deferred.fulfill(labelsArr);
        });

        return deferred.promise;
    };

    this.getData = function () {
        var deferred = protractor.promise.defer();
        var data = {};

        paddleSwitches.each(function (paddleSwitchElement) {
            var tLabel, tStatus;

            paddleSwitchElement.element(label.locator()).getText().then(function (labelValue) {
                tLabel = labelValue;
            }).then(function () {
                paddleSwitchElement.element(switchIcon.locator()).getAttribute("class").then(function (attrib) {
                    if (attrib.includes("ng-empty")) {
                        tStatus = false;
                    } else {
                        tStatus = true;
                    }
                });
            }).then(function () {
                data[tLabel] = tStatus;
            });
        }).then(function () {
            deferred.fulfill(data);
        });

        return deferred.promise;
    };

    this.toggleSwitches = function (dataObj) {
        for (var key in dataObj) {
            this.toggleSwitch(key, dataObj[key]);
        }
    };

    this.selectPaddleSwitch = function (switchLabel) {
        this.toggleSwitch(true, switchLabel);
    };

    this.deSelectPaddleSwitch = function (switchLabel) {
        this.toggleSwitch(false, switchLabel);
    };

    this.toggleSwitch = function (switchLabel, select) {
        //TODO IMPLEMENT BREAK WITH EACH
        paddleSwitches.each(function (paddleSwitchElement) {
            paddleSwitchElement.element(label.locator()).getText().then(function (labelValue) {
                if (labelValue === switchLabel) {
                    paddleSwitchElement.element(switchIcon.locator()).getAttribute("class").then(function (attribValue) {
                        if (attribValue.includes("ng-empty") && select === true) {
                            paddleSwitchElement.$("label").click();
                            angularWait();
                        } else if (attribValue.includes("ng-not-empty") && select === false) {
                            paddleSwitchElement.$("label").click();
                            angularWait();
                        }
                    });
                }
            });
        });
    };
};
PaddleSwitch.prototype = new element_();
module.exports = PaddleSwitch;