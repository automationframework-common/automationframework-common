var element_ = require("../root/element");

var QuillEditor = function (editorElement) {
    element_.apply(this, [editorElement]);

    var editorContainerElement,
        inputElement;

    (function () {
        editorContainerElement = editorElement.element(by.css(".editor-container"));
        inputElement = editorElement.element(by.css("div[id*='editor']"));
    })();

    this.enterText = function (text) {    
        var deferred = protractor.promise.defer();

        inputElement.clear().then(function () {
            for (i = 0; i < text.length; i++) {
                inputElement.sendKeys(text.charAt(i));
            }
        }).then(function () {
            deferred.fulfill();
        });
                
        return deferred.promise;
    };

    this.getData = function () {
        var deferred = protractor.promise.defer();

        inputElement.getText().then(function (value) {
            deferred.fulfill(value.toString().trim());
        });

        return deferred.promise;
    };

    this.clearEntry = function () {
        inputElement.clear();
        angularWait();
    };
};
QuillEditor.prototype = new element_();
module.exports = QuillEditor;