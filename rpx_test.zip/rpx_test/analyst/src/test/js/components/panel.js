var element_ = require("../root/element");

var Panel = function (panelElement, params) {
    element_.apply(this, [panelElement]);

    this.getData = function () {
        var deferred = protractor.promise.defer();
        var data = {};

        element.all(panelElement.locator()).each(function (element) {
            element.element(params["label"].locator()).getText().then(function (label) {
                var labelContent = label.replace(':', '');
                element.element(params["value"].locator()).getText().then(function (value) {
                    data[labelContent] = value;
                });
            });
        }).then(function () {
            deferred.fulfill(data);
        });
        return deferred.promise;
    };
};
Panel.prototype = new element_();
module.exports = Panel;