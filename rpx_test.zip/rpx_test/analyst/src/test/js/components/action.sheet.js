var element_ = require("../root/element");

var ActionSheet = function (actionSheetElement, params) {
    element_.apply(this, [actionSheetElement]);

    var title,
        dateInput,
        checkbox,
        saveBtn;

    (function () {
        if(params.type === "date") {
            title = actionSheetElement.element(by.css("div[class='rpx-flex-row']:nth-of-type(1)>span"));
            dateInput = actionSheetElement.element(by.css("input[ng-model*='ate'][type='text']"));
        }
        saveBtn = actionSheetElement.element(by.css("a[class='button tiny']:not([disabled='disabled'])"));
        checkbox = actionSheetElement.element(by.css("input[type='checkbox']"));
    })();

    this.selectCheckBox = function (value) {
        if(value === true) {
            checkbox.getAttribute("class").then(function (checkboxClass) {
                if(checkboxClass.includes("ng-empty") === true) {
                    checkbox.click();
                    angularWait();
                }
            });
        } else {
            checkbox.getAttribute("class").then(function (checkboxClass) {
                if(checkboxClass.includes("ng-empty") === false) {
                    checkbox.click();
                    angularWait();
                }
            });
        }
    };

    this.editAndSave = function (isCheckboxSet, date) {
        if(date !== undefined) {
            dateInput.clear();
            dateInput.sendKeys(date);
        }
        if(isCheckboxSet !== undefined)
            this.selectCheckBox(isCheckboxSet);
        is(saveBtn).displayed().then(function (displayed) {
            if(displayed) {
                saveBtn.click();
                angularWait();
            } else {
                refresh();
            }
        });
    };
};
ActionSheet.prototype = new element_();
module.exports = ActionSheet;