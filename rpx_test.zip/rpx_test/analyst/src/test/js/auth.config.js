var q = require("q"),
    excel = require('./helpers/excel.helper');

exports.config = {
    require: require('./root/browser'),
    require: require('./root/page'),
    require: require('./root/element'),
    require: require('./helpers/report.helper'),
    require: require('./helpers/sort.helper'),

    framework: 'jasmine2',

    params: {
        login: {
            readUser: {
                userName: 'qareadrpx@gmail.com',
                password: 'Welcome1'
            },
            writeUser: {
                userName: 'srenganathan_c@rpxcorp.com',
                password: "RPX@2015"
            }
        },
        maxTimeOut: 10000
    },

    multiCapabilities: [
        {
            browserName: 'chrome',
            chromeOptions: {
                args: [
                    '--start-maximized'
                ]
            },
            role: 'readUser',
        },
        {
            browserName: 'chrome',
            chromeOptions: {
                args: [
                    '--start-maximized'
                ]
            },
            role: 'writeUser'
        }
    ],
    directConnect: true,
    allScriptsTimeout: 120000,

    specs: [
        "specs/auth.specs.js"
    ],

    jasmineNodeOpts: {
        defaultTimeoutInterval: 300000
    },

    baseUrl: 'https://qa-analyst.rpxcorp.com/#',

    onPrepare: function () {
        var AllureReporter = require('jasmine-allure-reporter');
        jasmine.getEnv().addReporter(new AllureReporter({
            resultsDir: 'allure-results'
        }));
        jasmine.getEnv().afterEach(function (done) {
            browser.takeScreenshot().then(function (png) {
                allure.createAttachment('Screenshot', function () {
                    return new Buffer(png, 'base64')
                }, 'image/png')();
                done();
            })
        });

        return q.fcall(function () {
            return browser.getProcessedConfig().then(function (config) {
                return excel.getData("./resources/auth.xlsx", "temp").then(function (excelData) {
                    browser.params["role"] = config.capabilities.role;
                    browser.params["tc"] = excelData;
                });
            });
        });
    }
};