var q = require("q"),
    excel = require('./helpers/excel.helper');

exports.config = {

    require: require('./helpers/report.helper'),
    framework: 'jasmine2',

    params :{
        dbConString : "postgresql://mmurugesan_c:B5OSYwUG@stage-cortaldb:5433/rpx",
    },
    

    allScriptsTimeout: 60000,

    jasmineNodeOpts: {
        defaultTimeoutInterval: 60000
    },

    specs: ['specs/data.quality.specs.js'],
    directConnect: true,

    onPrepare: function () {
        var AllureReporter = require('jasmine-allure-reporter');
        jasmine.getEnv().addReporter(new AllureReporter({
            resultsDir: 'allure-results'
        }));

        return q.fcall(function () {
            return browser.getProcessedConfig().then(function (config) {
                return excel.getData("./resources/data_quality.xlsx", "temp").then(function (excelData) {
                    browser.params["tc"] = excelData;
                });
            });
        });
    }
};