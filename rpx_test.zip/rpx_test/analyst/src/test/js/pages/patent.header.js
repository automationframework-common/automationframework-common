var basePage = require("./base.page");

var panel = require("../components/panel"),
    actionSheet = require('../components/action.sheet'),
    tabs = require("../components/tabs"),
    tags = require("../components/tags"),
    memoContainer = require("../components/memo.container"),
    autoSuggest = require("../components/autosuggest")
    searchSelect = require("../components/search.select");

var licenseeAnnotationModal = require("../pages/modals/licensees.annotation.modal");

var PatentHeader = function () {
    this.panel = $(".patent.panel");
    this.pubType = $(".asset-title[ng-class*='isPublication'] .patent-type");
    this.pubNumber = $(".asset-title[ng-class*='isPublication'] .patent-list");

    this.patentType = $(".asset-title[ng-class*='isPatent'] .patent-type");
    this.patentNumber = $(".asset-title[ng-class*='isPatent'] .patent-list");
    this.patentTitle = $(".patent-title.ng-binding");
    this.googleLink = element(by.xpath("//div[contains(@class, 'outbound-links')]//a[text()='Google']"));
    this.usptoLink = element(by.xpath("//div[contains(@class, 'outbound-links')]//a[text()='USPTO']"));
    this.pairFileWrapperLink = $("span[ng-if='pairLink'] a");

    this.bulkTagIcon = $("a[ng-click='openBulkTagging()']");
    this.openBulkTagging = function () {
        this.bulkTagIcon.click();
        angularWait();
    };
    this.bulkTagModal = $(".bulk-tagging-modal");
    this.bulkTagModalClose = $(".bulk-tagging-modal .fa.fa-close");
    this.closeBulkTagging = function () {
        this.bulkTagModalClose.click();
        angularWait();
    };

    this.termDefinitions = $("div[ng-click='toggleTerms()'] i");
    this.patentReferenceIcon = $(".fa.fa-archive");
    this.highLights = $$(".highlight");

    this.breadcrumbs = $(".breadcrumbs");
    this.breadcrumbsPatNum = $("a[ng-click='patentEdit()']");
    this.breadcrumbsClaimNo = $("a[ng-click='dependentEdit()']");

    // this.patentInfo = new panel(element(by.css(".rpx-flex-column .rpx-flex-row")), {
    //     label: element(by.css(".rpx-flex-column:first-child")),
    //     value: element(by.css(".rpx-flex-column:last-child"))
    // });

    // this.patentInfo = new panel(element(by.css(".patent-info")), {
    //     label: element(by.css(".header_label")),
    //     value: element(by.css(".info .ng-binding:first-child"))
    // });

    this.patentInfo = new panel(element(by.css(".patent-header-component .rpx-table tr")),{
        label: element(by.css("td:first-child")),
        value: element(by.css("td:last-child "))
    }),

    this.sponsor = {
        link: $("span[class*='pedigree'][ng-repeat*='sponsors'] .ng-binding"),
        actionSheet: new actionSheet(element(by.css(".pedigree.annotation .action-sheet-container")), {
            type: "sponsor"
        }),
        thumbsUp: $(".pedigree.annotation .fa-thumbs-up"),

        edit: function (checkBoxChecked) {
            var this_ = this;
            this_.link.click();
            this_.actionSheet.editAndSave(checkBoxChecked);
        },
        enabled: $("span[class='ng-binding ng-scope'][zf-hard-toggle*='sponsor']"),
        disabled: $("span[ng-repeat*='sponsors'] span[class*='rpx-read-only']")
    };
    this.citations = {
        link: $("a[ng-click='$ctrl.openCitationsModal()'] i"),
        chart: $(".citation-timeline"),
        closeModal: function () {
            var closeElement = $(".reveal-modal[style*='visible'] .fa-close");
            return click(closeElement).ifDisplayed();
        }
    };
    this.family = {
        link: $("a[zf-open='sankeyModalHeader'] .fa-sitemap"),
        chart: $("#sankey-container-header"),
        closeModal: function () {
            var closeElement = $(".modal.is-active .close-button");
            return click(closeElement).ifDisplayed();
        }
    };
    this.timeLine = {
        link: $("a[ng-click='$ctrl.openAssignentModal()'] i"),
        chart: $("#patent-assignment-chart"),
        closeModal: function () {
            var closeElement = $(".assignment-dialog .close-reveal-modal");
            return click(closeElement).ifDisplayed();
        }
    };

    this.priorityDate = {
        // link: element(by.xpath("//div[@id='priority-date']/ancestor::span[contains(@class, 'annotation')]")),
        link: element(by.xpath("//div[@id='priority-date']/ancestor::span[contains(@class, 'annotation')]/span[@zf-hard-toggle='priority-date']")),
        actionSheet: new actionSheet(element(by.css("#priority-date")), {
            type: "date"
        }),
        verifiedIcon: element(by.xpath("//div[@id='priority-date']/ancestor::span[contains(@class, 'annotation')]" +
            "//span[contains(@ng-class, 'not-verified')]")),
        notVerifiedIcon: element((by.xpath("//div[@id='priority-date']/ancestor::span[contains(@class, 'annotation')]" +
            "//span[contains(@ng-class, 'not-verified')][@class='not-verified']"))),

        edit: function (checkBoxChecked, date) {
            var this_ = this;
            scrollToView(this_.link);
            this_.link.click();
            this_.actionSheet.editAndSave(checkBoxChecked, date);
        },
        enabled: element(by.xpath("//div[@id='priority-date']/ancestor::span//span[@class='ng-binding ng-scope']")),
        disabled: element(by.xpath("//div[@id='priority-date']/ancestor::span//span[@class='rpx-read-only ng-binding ng-scope']"))
    };
    this.expiryDate = {
        link: element(by.xpath("//div[@id='expiry-date']/ancestor::span[contains(@class, 'annotation')]/span")),
        actionSheet: new actionSheet(element(by.css("#expiry-date")), {
            type: "date"
        }),
        verifiedIcon: element(by.xpath("//div[@id='expiry-date']/ancestor::span[contains(@class, 'annotation')]" +
            "//span[contains(@ng-class, 'not-verified')]")),
        notVerifiedIcon: element((by.xpath("//div[@id='expiry-date']/ancestor::span[contains(@class, 'annotation')]" +
            "//span[contains(@ng-class, 'not-verified')][@class='not-verified']"))),

        edit: function (checkBoxChecked, date) {
            var this_ = this;
            // browser.executeScript("arguments[0].scrollIntoView();", this_.link.getWebElement());scrollToView
            scrollToView(this_.link);
            this_.link.click();
            this_.actionSheet.editAndSave(checkBoxChecked, date);
        },
        enabled: element(by.xpath("//div[@id='expiry-date']/ancestor::span//span[@class='ng-binding ng-scope']")),
        disabled: element(by.xpath("//div[@id='expiry-date']/ancestor::span//span[@class='rpx-read-only ng-binding ng-scope']"))
    };
    this.assignees = $("div[ng-if*='current_assignee_names'] .group-display span");
    this.inventors = {
        // links: $$("div[ng-if*='inventors'] .group-display span[ng-repeat]"),
            links: $$("span[class*='pedigree'][ng-repeat*='inventors']"),
    
        edit: function (inventorIndex, isStrong) {
            var this_ = this;
            var actionSheetElem = new actionSheet(this_.links.get(inventorIndex).element(by.css(".action-sheet-container")), {
                type: "nonDate"
            });
            this_.links.get(inventorIndex).element(by.css("span[zf-hard-toggle*='inventor']")).click().then(function () {
                actionSheetElem.editAndSave(isStrong);
            });
        },
     
        thumbsUpIcon: function (inventorIndex) {
            var this_ = this;
            return this_.links.get(inventorIndex).element(by.css(".fa-thumbs-up"));
        },
        enabled: $("span[class='ng-binding ng-scope'][zf-hard-toggle*='inventor']"),
        disabled: $("span[ng-repeat*='inventors'] span[class*='rpx-read-only']")
    };

    this.annotationTabs = new tabs(element(by.css("div[ng-if='patentHeaderLoaded'] .tabs")));
    this.annotations = new memoContainer(element(by.css(".patent-annotation-memo")), {
        createDropDown: element(by.css("a[class*=create]")),
        createDisabled: element(by.css("a[class*=create][disabled='disabled']")),
        filterIcon: element(by.css("a[class*='filter-dropdown']")),
        content: element(by.css(".all-annotations-list"))
    });
    this.freeFormAutoSuggest = new autoSuggest(element(by.css("patent-header-component freeform-tag-selector")), {
        input: element(by.css("input[type='search']")),
        options: element(by.css(".ui-select-choices-row"))        
    });
    this.freeFormTagSpan = element(by.xpath("//span[contains(@class ,'ui-select-match-item')]//span[contains(@class,'ng-binding')]"));
    this.freeFormTags = new tags(element(by.css("patent-header-component freeform-tag-selector .ui-select-match")), {
        type: "default",
        close: element(by.css(".close"))
    });
    this.noAnnotationsMsg = element(by.css(".no-annotations-message span"));
    this.priorityResearchNewAssociationBtn = $("#patent-annotation-PR span[title='Add Associations']");
    this.licensees = {
        noLicenseesMsg: $(".patent-licenses-container .no-data"),
        searchSelect: new searchSelect(element(by.css(".prc-select-container")), {
            input: element(by.css("input[type='search']")),
            options: element(by.css(".ui-select-choices-row .option div")),
            close: element(by.css(".select-close"))
        }),
        tags: new tags(element(by.css(".license_data_container")), {
            type: "default"
        }),
        applyToFamilyBtn: $(".save-family-btn"),
        addAnnotationModal: new licenseeAnnotationModal(element(by.css(".reveal-modal[style*='visible']")))
    };
};
PatentHeader.prototype = basePage;
module.exports = new PatentHeader();