var basePage = require("./base.page");

var grid = require("../components/grid");

var PortfolioListPage = function () {
    this.url = "/portfolio";

    this.title = element(By.css("h2"));

    this.grid = new grid(element(by.css("#portfolio-grid")), {
        type: "default"
    });
};
PortfolioListPage.prototype = basePage;
module.exports = new PortfolioListPage();