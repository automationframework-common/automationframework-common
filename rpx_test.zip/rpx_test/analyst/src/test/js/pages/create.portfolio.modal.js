var basePage = require("./base.page");

var CreatePortfolioModal = function () {
    this.modal = $(".reveal-modal.fade.in");
};
CreatePortfolioModal.prototype = basePage;
module.exports = new CreatePortfolioModal();