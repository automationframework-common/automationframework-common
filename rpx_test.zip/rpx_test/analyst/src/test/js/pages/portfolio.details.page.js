var basePage = require('./base.page'),
    patentAdvancedSearch = require("./advanced.search"),
    patentHeader = require("../pages/patent.header"),
    bulkTaggingModal = require("../pages/modals/bulk.tagging.modal"),
    patentClaims = require("../pages/patent.claims");

var grid = require('../components/grid'),
    tabs = require("../components/tabs"),
    autoSuggest = require("../components/autosuggest"),
    dropDown = require("../components/dropdown"),
    memoContainer = require("../components/memo.container"),
    panel = require("../components/panel"),
    starRating = require("../components/star.rating"),
    card = require("../components/card"),
    
    keypatents = require('../components/key.patents');

var PortfolioDetails = function () {
    this.url = "/portfolio/{{id}}";

    this.title = $(".portfolio-header-name");
    this.detailsPanelExpandIcon = $(".module-right .fa.fa-expand");
    this.detailsPanelCollapseIcon = $(".module-right .fa.fa-compress");
    this.expandDetailsPanel = function () {
        this.detailsPanelExpandIcon.click();
        angularWait();
    
    };

    this.patentList = {
        expandIcon: $(".expando.expando-medium-6 i"),
        collapseIcon: $(".expando.expando-small-12 i"),
        
        expand: function () {
            var this_ = this;
            this_.expandIcon.isDisplayed().then(function () {
                this_.expandIcon.click();
                angularWait();
            }).catch(function () { });
        },
        compress: function () {
            var this_ = this;
            this_.collapseIcon.isDisplayed().then(function () {
                this_.collapseIcon.click();
                angularWait();
            }).catch(function () { });
        },

        actionItemsIcon: $(".patent-grid-container .fa.fa-gear"),
        actionItems: $("#portfolio-grid-action-items li a"),
        actionItemOptions: {
            createPortfolio: element(by.cssContainingText("#portfolio-grid-action-items li[class='ng-scope'] a",
                "Create Portfolio")),
            addToPortfolio: element(by.cssContainingText("#portfolio-grid-action-items li[class='ng-scope'] a",
                "Add to Portfolio")),
        },

        clickActionItemsIcon: function () {
            this.actionItemsIcon.click();
            angularWait();
        },
        selectActionItem: function (actionItem) {
            this.actionItemsIcon.click();
            element.all(by.cssContainingText("#portfolio-grid-action-items li a", actionItem)).click();
        },

        filterIcon: $(".patent-grid-container .fa.fa-filter"),
        filterSlide: $(".offscreen-content"),
        openFilterSlide: function () {
            var this_ = this;
            this_.filterIcon.click().then(function () {
                angularWait();
            });
        },
        filterSearch: new patentAdvancedSearch("offscreen"),
        clearAllLinkInFilterSlide : $(".reset-search"),
        filterTags: $(".filter-tag"),
        
        isFilterTagPresent : function(filterfield){
            TempfilterTag = element(by.xpath("//a[contains(text(),'"+filterfield+"')]/parent::span[contains(@class,'filter-tag')]"));
            deferred = protractor.promise.defer();
            TempfilterTag.isPresent().then(function(bool){
                deferred.fulfill(bool);
            });
            return deferred.promise;
        },
        
        clearFilterTag : function(filterfield){
            filterTagRemoveIcon = element(by.xpath("//a[contains(text(),'"+filterfield+"')]/parent::span//i"));
            filterTagRemoveIcon.click().then(function () {
                angularWait();
            });

        },
        patentCountText : $("div[class*='patent-count'] ng-pluralize[count*='patentCount']"),

        // Following functions are to check the Filters are removed
        isFacetSearchValuePresent : function(filterfield){
            // TempfilterTag = element(by.css("faceted-row a[title*='"+filterfield+"']"));
            TempfilterTag = element(by.css(".faceted-row.open"));

            deferred = protractor.promise.defer();
            TempfilterTag.isPresent().then(function(bool){
                deferred.fulfill(bool);
            });
            return deferred.promise;
        },

        isNumericSearchValuePresent : function(filterfield){
            // TempfilterTag = element(by.xpath("//div[contains(text(),'"+filterfield+"')]/parent::numeric-row//a[@class='rpx-alert reset-input-numeric']"));
            TempfilterTag = element(by.css(".numeric-input.ng-valid.ng-not-empty"));
            deferred = protractor.promise.defer();
            TempfilterTag.isPresent().then(function(bool){
                deferred.fulfill(bool);
            });
            return deferred.promise;
        },

        isRadioSearchValuePresent : function(filterfield){
            // TempfilterTag = element(by.xpath("//radiobutton-group-row//input[contains(@class,'ng-valid-parse')]"));
            TempfilterTag = element(by.css("radiobutton-group-row input[class*='ng-not-empty']"));
            deferred = protractor.promise.defer();
            TempfilterTag.isPresent().then(function(bool){
                deferred.fulfill(bool);
            });
            return deferred.promise;
        },

        isDateSearchValuePresent : function(filterfield){
            // TempfilterTag = element(by.xpath("//div[contains(text(),'"+filterfield+"')]//parent::form//a[@class='rpx-alert reset-input']"));
            TempfilterTag = element(by.css(".date-input.ng-not-empty"));
            deferred = protractor.promise.defer();
            TempfilterTag.isPresent().then(function(bool){
                deferred.fulfill(bool);
            });
            return deferred.promise;
        },

        isTextRowSearchValuePresent : function(filterfield){
            // TempfilterTag = element(by.xpath("//span[contains(text(),'"+filterfield+"')]/parent::div/parent::text-row//a[@class='rpx-alert reset-input']"));
            TempfilterTag = element(by.css("text-row input[class*='ng-not-empty']"));
            deferred = protractor.promise.defer();
            TempfilterTag.isPresent().then(function(bool){
                deferred.fulfill(bool);
            });
            return deferred.promise;
        },


        gridViewIcon: $(".patent-grid-container a[title*='grid']"),
        grid: new grid(element(by.css(".rpx-grid")), {
            type: "pinned",
            columnOptions: element(by.css("#grid-column-options-grid"))
        }),

        cardViewIcon: $(".patent-grid-container a[title*='card']"),
        cardView: $(".patent-card-container"),
        view: function (type) {
            var this_ = this;
            if (type === 'card')
                this_.cardViewIcon.click();
            else
                this_.gridViewIcon.click();

            angularWait();
        },
        cards: new card(element(by.css(".patent-card-container")), {
            cardOptions: element(by.css(".card-metric-menu"))
        })
    };

    this.familyMemberNotInPortfolio = {
        modal: element(by.xpath("//h4[text()='Family Members not in Portfolio']/ancestor::div[contains(@class, 'reveal-modal')]")),
        closeIcon: $(".reveal-modal .fa-close"),
        close: function () {
            var closeElement = this.closeIcon;
            click(closeElement).ifDisplayed();
        }
    };

    this.createPortfolio = {
        modal: element(by.xpath("//h4[text()='Create Portfolio']/ancestor::div[contains(@class, 'reveal-modal')]")),
        closeIcon: $(".reveal-modal .fa-close"),
        close: function () {
            var closeElement = this.closeIcon;
            click(closeElement).ifDisplayed();
        }
    };

    this.addToPortfolio = {
        modal: element(by.xpath("//h4[text()='Add to Portfolio']/ancestor::div[contains(@class, 'reveal-modal')]")),
        closeIcon: $(".reveal-modal .fa-close"),
        close: function () {
            var closeElement = this.closeIcon;
            click(closeElement).ifDisplayed();
        }
    };

    this.customExport = {
        modal: element(by.xpath("//h4[text()='Custom Export']/ancestor::div[contains(@class, 'reveal-modal')]")),
        closeIcon: $(".close-reveal-modal"),
        close: function () {
            var closeElement = this.closeIcon;
            click(closeElement).ifDisplayed();
        }
    };

    //MAIN TABS
    this.patentDataTabs = new tabs(element(by.css(".patent-data .tabs")));
    //SUB TABS
    this.patentDataSubTabs = {
        portfolio: new tabs(element(by.css(".active .sub-nav"))),
        patent: new tabs(element(by.css(".active .sub-nav")))
    };
    //TERTIARY TABS
    this.patentDataTertirayNavs = {
        assets: new tabs(element(by.css(".tertiary-nav:nth-of-type(2)"))),
        summaries: new tabs(element(by.css(".tertiary-nav:nth-of-type(3)"))),
        litigations: new tabs(element(by.css(".tertiary-nav:nth-of-type(4)"))),
        petitions: new tabs(element(by.css(".tertiary-nav:nth-of-type(5)"))),
        priorArt: new tabs(element(by.css(".patent-prioart-container dl")))
    };
    this.selectPatentDataTabs = function (mainTab, subTab, tertiaryTab) {
        this.patentDataTabs.select(mainTab);

        switch (mainTab.toLowerCase()) {
            case "portfolio":
                this.patentDataSubTabs.portfolio.select(subTab);
                break;

            case "patent":
                this.patentDataSubTabs.patent.select(subTab);
                break;
        }

        switch (subTab.toLowerCase) {
            case "assets":
                this.patentDataTertirayNavs.assets.select(tertiaryTab);
                break;

            case "summaries":
                this.patentDataTertirayNavs.summaries.select(tertiaryTab);
                break;

            case "litigations":
                this.patentDataTertirayNavs.litigations.select(tertiaryTab);
                break;

            case "petitions":
                this.patentDataTertirayNavs.petitions.select(tertiaryTab);
                break;

            case "prior art":
                this.patentDataTertirayNavs.priorArt.select(tertiaryTab);
                break;
        }
    };

    this.portfolioAssetsTab = {
        overview: {
            barChart: $(".column.overview-bar.relative.small-8"),
            grantsCount: $("li[ng-if*='summary.grants'] .count"),
            applicationsCount: $("li[ng-if*='summary.applications'] .count"),
            litigationsCount: $("li[ng-if*='summary.litigations'] .count"),
            patentsChallengedCount: $("li[ng-if*='summary.challenged'] .count"),
            potentialReferencesCount: $("li[ng-if*='summary.potential_art_references'] .count")
        },
        landscape: {
            highChart: $("#portfolio-metric-chart")
        },
        clusters: {
            highChart: $("#cluster-donut")
        },
        techTags: {
            highChart: $("#techtag-donut")
        },
        cpc: {
            highChart: $(".cpc-donut-container")
        }
    };

    this.portfolioSummariesTab = {
        rpxTab: {
            salesForceSummaryLink: $(".analysis_memo_container .fa-external-link-square"),
            // recommendation: new dropDown(element(by.css(".quick_recommendation_select"))),
            recommendation: new dropDown(element(by.css("select[ng-model*='quick_recommendation']"))),
            recommendationText: $(".quick_recommendation_select_col>div"),
            // marketSector: new dropDown(element(by.css(".primary_market_select"))),
            marketSector: new dropDown(element(by.css("select[ng-model*='primary_market_sector']"))),
            marketSectorText: $(".primary_market_select_col>div"),
            annotations: new memoContainer(element(by.css(".portfolio-annotation-memo")), {
                createDropDown: element(by.css("a[class*=create]")),
                createDisabled: element(by.css("a[class*=create][disabled='disabled']")),
                filterIcon: element(by.css("a[class*='filter-dropdown']")),
                content: element(by.css(".all-annotations-list"))
            })
        },
        dealTab: {
            dealDataItems: $("div[ng-show*='dealData'] ul li"),
            getDealItems: function () {
                var deferred = protractor.promise.defer();
                var dealItems = {};
                element.all(this.dealDataItems.locator()).then(function (items) {
                    for (var itemsCnt = 0; itemsCnt < items.length; itemsCnt++) {
                        items[itemsCnt].getText().then(function (itemText) {
                            var text = itemText.split(":");
                            dealItems[text[0].trim()] = text[1].trim();
                        });
                    }
                }).then(function () {
                    deferred.fulfill(dealItems);
                });
                return dealItems;
            },
            sellerNotes: $("div[ng-show='sellerNotesAvailable'] .deal-notes-body"),
            publicDealNotes: $("div[ng-show='publicDealNotesAvailable'] .deal-notes-body"),
            viewInSalesForceBtn: $(".deal-data-link.button")
        },
        keyPatentsTab: {
            keyPatents: $("sf-key-patents"),
            patNum: $(".key-patents-list .patent-num h3"),
            showDetailsLink: $(".summary-link"),
            firstPatentSummary: $(".key-patents-summary>div:nth-of-type(1)"),
            claimNo: $(".key-patent-detail .claim-num a"),
            techTags: $$(".row.tech-tags-list .tag-text")
        },
        annotedPatentsTab : new keypatents(element(by.css(".sf-patent-details"))),
        
        

        // annotatedPatentsTab:{

        //     this.check
        //     annotatedPatents: $(".sf-patent-details"),

            
        //     patNum: $(".sf-patent-details .pat-header-container>a.internal"),    
      
        //     // patNum: $(".sf-patent-details .pat-header-container>a.internal"),
        //     keyPatentCheckBox: $(".sf-patent-details .key-patent-checkbox"),
        //     showDetailsLink: $(".sf-patent-details .summary-link"),
        //     // firstPatentSummary: $(".key-patents-summary>div:nth-of-type(1)"),
        //     claimNo: $(".key-patent-detail .claim-num a"),
        //     techTags: $$(".row.tech-tags-list .tag-text")
        // }

    };

    this.portfolioLitigationsTab = {
        campaignsTab: {
            grid: new grid(element(by.css(".lit-campaign-content .ui-grid")), {
                type: "default"
            })
        },
        defendantsTab: {
            grid: new grid(element(by.css(".lit-defendants-content .grid.ui-grid")), {
                type: "default",
                pagination: element(by.css("patent-defendants .pagination")),
                noData: element(by.css(".defendants-content .no-data span"))
            }),
            input: $(".defendants-content input"),
            search: function (searchTerm) {
                var inputElem = this.input;
                inputElem.clear().then(function () {
                    inputElem.sendKeys(searchTerm);
                    angularWait();
                });
            }
        },
        accusedProductsTab: {
            grid: new grid(element(by.css(".accused-products-content .ui-grid")), {
                type: "default"
            })
        },
        patDefendantsTab: {
            grid: new grid(element(by.css(".patent-group-defendants-content .grid.ui-grid")), {
                type: "subGrid"
            })
        }
    };

    this.portfolioPetitionsTab = {
        petitionsTab: {
            grid: new grid(element(by.css(".ptab-petitions-container .ui-grid")), {
                type: "default"
            })
        },
        petitionersTab: {
            grid: new grid(element(by.css(".petitioners-content .ui-grid")), {
                type: "subGrid"
            })
        },
        patentsTab: {
            grid: new grid(element(by.css(".ptab-patents-content .ui-grid")), {
                type: "subGrid"
            })
        }
    };

    this.portfolioCompareTab = {
        portfolioAAutoSuggest: new autoSuggest(element(by.css("select-portfolio[on-select*='updatePortfolioA']")), {
            input: element(by.css("input[type='search']")),
            options: element(by.css(".ui-select-choices-row span")),
            clear: element(by.css(".select-close")),
            selectedValue: element(by.css(".ui-select-match-text span"))
        }),
        portfolioBAutoSuggest: new autoSuggest(element(by.css("select-portfolio[on-select*='updatePortfolioB']")), {
            input: element(by.css("input[type='search']")),
            options: element(by.css(".ui-select-choices-row span")),
            clear: element(by.css(".select-close")),
            selectedValue: element(by.css(".ui-select-match-text span"))
        }),
        clusterFilterHightChart: $("#clusterFilter"),
        patentsCountHighChart: $("#patentsCountOverTime")
    };

    this.portfolioSimilarityTab = {
        // highChart: $("#portfolio-similarity-chart-container")
        highChart: $("#portfolio-similarity-chart")
    };

    this.defendantModal = {
        container: $(".shared-patent-defendants-modal-container"),
        closeIcon: $(".close-reveal-modal"),
        close: function () {
            var closeElement = this.closeIcon;
            click(closeElement).ifDisplayed();
        }
    };

    this.patentInfoTab = {
        title: $(".patent-info-container h2"),
        starRating: new starRating(element(by.css(".patent-info-container .star-container")), {
            ratings: element(by.css("span[value]"))
        }),
        starValue: element(by.css(".star-container span:not([value])")),
        score: $("span[ng-show*='patent.overall_score']"),
        patentDetailsPanel: new panel(element(by.css(".patent-info .rpx-table tr")), {
            label: element(by.css("td:first-child")),
            value: element(by.css("td:last-child"))
        }),
        citation: {
            link: $("a[ng-click='openCitationsModal()'] i"),
            chart: $(".citation-timeline"),
            closeModal: function () {
                var closeElement = $(".reveal-modal[style*='visible'] .fa-close");
                return click(closeElement).ifDisplayed();
            }
        },
        family: {
            link: $("td[ng-show='patent']>a>i"),
            chart: $("#patent-family-chart"),
            closeModal: function () {
                var closeElement = $(".modal.is-active .close-button");
                return click(closeElement).ifDisplayed();
            }
        },
        litigation: {
            link: element(by.xpath("//td[text()='Litigation:']/../td/a")),
            grid: new grid(element(by.css(".litigations-for-patent-grid")), {
                type: "subGrid"
            }),
            closeModal: function () {
                var closeElement = $(".reveal-modal[style*='visible'] .close-reveal-modal");
                return click(closeElement).ifDisplayed();
            }
        },
        timeLine: {
            link: $("a[ng-click='$ctrl.openAssignentModal()'] i"),
            chart: $("#patent-assignment-chart"),
            closeModal: function () {
                var closeElement = $(".assignment-dialog .close-reveal-modal");
                return click(closeElement).ifDisplayed();
            }
        },
        grid: new grid(element(by.css(".patent-portfolio-list .ui-grid")), {
            type: "default"
        })
    };

    this.patentMetricsTab = {
        chart: $("#patent-metrics-chart")
    };

    this.patentSimilarityTab = {
        chart: $("#patent-similarity-chart")
    };

    this.patentDetailsHeader = {
        title: $(".asset-title.active .patent-list")
    };

    this.patentHeader = patentHeader;
    this.patentClaims = patentClaims;
    this.annotatedPatentClaims = patentClaims;
    
};
PortfolioDetails.prototype = basePage;
module.exports = new PortfolioDetails();