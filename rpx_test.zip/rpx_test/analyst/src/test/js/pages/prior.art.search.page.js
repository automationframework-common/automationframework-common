var basePage = require("./base.page"),
    advancedSearchOffScreen = require("../pages/advanced.search");

var grid = require("./../components/grid"),
    tabs = require("./../components/tabs"),
    panel = require("./../components/panel");

var PriorArtSearchPage = function () {

    this.url = "/priorart";

    this.expandLayoutBtn = $(".expando-button");
    this.collapseLayoutBtn = $(".expando-button.expanded");

    //PRIOR ART FILTER
    this.filterIcon = $(".priorart-grid-container .fa.fa-filter");
    this.filterSlide = $(".offscreen-content");
    this.openFilterSlide = function () {
        waitFor(this.filterIcon).toBeClickable();
        this.filterIcon.click().then(function () {
            angularWait();
        });
    };
    this.filterSearch = new advancedSearchOffScreen("offscreen");
    this.filterTags = $(".filter-tag");

    //PRIOR ART GRID
    this.priorArtGrid = new grid(element(by.css("priorart-grid")), {
        type: "default",
        pagination: element(by.css("priorart-grid .pagination"))
    });

    //DETAIL TABS
    this.priorArtInfoTabs = new tabs(element(by.css(".prioart-layout>.tabs")));
    this.paInfoAssociationTab = element(by.css(".prioart-layout>.tabs dd:nth-of-type(2)"));

    //ASSOCIATION TAB
    this.associationsTab = {
        summary: {
            title: $(".priorart-summary-container h4"),
            detailsBtn: $(".priorart-summary-container .button"),
            details: new panel(element(by.css(".priorart-summary-container label")), {
                label: element(by.css('.detail-item>div:nth-of-type(1)')),
                value: element(by.css(".detail-item>div:nth-of-type(2)"))
            })
        },
        association: {
            newAssociationBtn: $("a[ng-click='$ctrl.addNewAssociation()']")
        }
    };
};
PriorArtSearchPage.prototype = basePage;
module.exports = new PriorArtSearchPage();