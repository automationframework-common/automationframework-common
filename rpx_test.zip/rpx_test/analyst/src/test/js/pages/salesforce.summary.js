var basePage = require("./base.page"),
    advancedSearch = require("../pages/advanced.search");

var tabs = require("../components/tabs"),
    grid = require("../components/grid"),
    chart = require("../components/chart"),
    keyPatents = require("../components/key.patents");

var SalesForceSummaryPage = function () {
    this.url = "/overview/{{id}}";

    this.title = $(".portfolio-header-name a");

    this.summary = {
        recommendation: element(by.xpath("//div[text()='Recommendation:']/../div[@class='ng-binding']")),
        marketSector: element(by.xpath("//div[text()='Market Sector:']/../div[@class='ng-binding']")),
        licensees: element.all(by.xpath("//div[text()='Licensees:']/../div/span"))
    };

    this.summaryTabs = new tabs(element(by.css(".tabs")));
    this.annotedPatentsTab = new keyPatents(element(by.css(".sf-patent-details")));
    this.executiveSummaryTab = {
        content: $("div[ng-bind-html*='executive_summary']")
    };
    this.marketBulletsTabs = {
        content: $("div[ng-bind-html*='market_bullets']")
    };
    this.portfolioSummaryTab = {
        content: $("div[ng-bind-html*='portfolio_summary']")
    };
    this.sellerResearchTab = {
        content: $("div[ng-bind-html*='seller_research']")
    };

    this.filter = {
        icon: $(".sf-overview .fa-filter"),
        slide: $(".offscreen-content"),
        openFilterOffscreen: function () {
            var this_ = this;
            this_.icon.click().then(function () {
                angularWait();
            });
        },
        modal: new advancedSearch("offscreen"),
        tags: $$(".filter-tag"),
        clearFilters: function () {
            var this_ = this;
            this_.openFilterOffscreen();
            this_.modal.clearFilters();
        }
    };

    this.otherPortfolios = {
        grid: new grid(element(by.css("other-portfolios-list")), {
            type: "default"
        })
    };

    this.prc = {
        title: $(".prc-chart-container div:not([class*='techtag'])>h4"),
        chartDisplayIconActive: $("a[title='chart display'][class*='active-button']"),
        chartDisplayIcon: $("a[title='chart display']"),
        gridDisplayIcon: $("a[title='table display']"),
        gridDisplayIconActive: $("a[title='table display'][class*='active-button']"),
        loadGridView: function () {
            var this_ = this;
            is(this_.gridDisplayIconActive).displayed().then(function (status) {
                if (status === false) {
                    this_.gridDisplayIcon.click();
                    angularWait();
                }
            });
        },

        highChart: new chart($("#prc-chart"), {
            dataLabels: element(by.css(".highcharts-data-labels>g")),
            toolTipText: $(".highcharts-tooltip text")
        }),
        grid: new grid($(" .sf-prc-grid.has-data"), {
            type: "default"
        }),
        noDataMsg: $("prc-chart .small-loading")
    };

    this.techTags = {
        title: $(".techtag-section h4"),
        highChart: new chart($("#techtag-donut"), {
            dataLabels: $(".highcharts-data-labels>g"),
            toolTipText: $(".highcharts-tooltip text")
        }),
        noDataMsg: $(".techtag-donut-container .small-loading")
    };

    //REFACTOR
    this.patentDetails = {
        title: $("[ng-init*='keyPatentsCount'] h4"),
        noDataMsg: $("[ng-init*='keyPatentsCount'] .loading"),
        keyPatents: new keyPatents($(".key-patents-container-content"))
    };
 //Missing Family members widget - APV
 this.missingFamilyMebersWidget = {
    widget: $("li[ng-click*='loadMissingFamilyMembers']"),
    count: $(".widget-content .count"),
    // count : $(".widget-content>span[class*='count']")
    tittle: $(".widget-content .title"),
    loadModal: function () {
        var deferred = protractor.promise.defer();
        var this_ = this;
        // is(this_.widget).displayed().then(function (status) {
        // if (status === true) {
        this_.widget.click().then(function () {
            deferred.fulfill(angularWait());
        });
        // }
        // });

        return deferred.promise;
    }
};

//Missing family members Grid Modal - APV
this.missingFamilyMebersGridModal = {
    tittle: $(".reveal-modal.fade h4"),
    firstPatentLink: element.all(by.xpath("//div[contains(@id,'grid1')]//div[contains(@class,'ui-grid-viewport')]//a")).get(0),
    // firstPatentLink : this.patentLinkElements.get(0),
    pinnedSubGrid: new grid(element(by.xpath("//div[@id='grid1']")), {
        type: "pinnedSubGrid",
    }),
    clickFirstPatentLink: function () {
        var this_ = this;
        is(this_.firstPatentLink).displayed().then(function (status) {
            if (status === true) {
                this_.firstPatentLink.click();
                angularWait();
            }
        });
    },

};
    this.keyPatents = $(".key-patents-container");
};
SalesForceSummaryPage.prototype = basePage;
module.exports = new SalesForceSummaryPage();