var basePage = require("../pages/base.page");

var grid = require('../components/grid');
var filterScreen = require("../pages/advanced.search")

var SearchResultsPage = function () {
    this.title = $(".portfolio-header-name>a");
    this.patentCountText = $("div[class*='patent-count'] ng-pluralize[count*='patentCount']");
    this.filterIcon = $(".patent-grid-container .fa.fa-filter");
    this.filterScreen = new filterScreen();
    this.filterTags = $("filter-tags a");
    this.secondfilterTags = $("filter-tags span:nth-child(3) a");
    this.searchResultsGrid = new grid(element(by.css(".rpx-grid")), {
        type: "pinned",
        columnOptions: element(by.css("#grid-column-options-grid"))
    });

    this.getPatentCount = function () {
        var this_ = this;
        deferred = protractor.promise.defer();
        this_.patentCountText.getText().then(function (count) {
            deferred.fulfill(count);
        }).catch(function () {
            deferred.fulfill("No Patent Count Displayed");
        });
        return deferred.promise;
    };
    this.openFilterSlide = function () {
        var this_ = this;
        this_.filterIcon.click().then(function () {
            angularWait();
        });
    },
        this.isFilterTagPresent = function (filterfield) {
            TempfilterTag = element(by.xpath("//a[contains(text(),'" + filterfield + "')]/parent::span[contains(@class,'filter-tag')]"));
            deferred = protractor.promise.defer();
            TempfilterTag.isPresent().then(function (bool) {
                deferred.fulfill(bool);
            });
            return deferred.promise;
        };

    this.clearFilterTag = function (filterfield) {
        filterTagRemoveIcon = element(by.xpath("//a[contains(text(),'" + filterfield + "')]/parent::span//i"));
        filterTagRemoveIcon.click().then(function () {
            angularWait();
        });

    };




};
SearchResultsPage.prototype = basePage;
module.exports = new SearchResultsPage();