var MenuPartial = function () {

    this.dropDown = function (dropDownName) {
        return {
            open: function () {
                browser.actions()
                    .mouseMove($(".inline-list.show-for-large-up").element(by.linkText(dropDownName)))
                    .perform();
            },

            item: function (itemName) {
                this.open();

                element(by.xpath("//a[contains(text(), '" + dropDownName + "')]/ancestor::li//ul"))
                    .element(by.linkText(itemName)).click();
            }
        };
    };
};
module.exports = new MenuPartial();