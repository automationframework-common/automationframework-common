

var basePage = require("./base.page");

var textRow = require("../components/custom.search/text.row"),
    facetRow = require("../components/custom.search/facet.row"),
    numericRow = require("../components/custom.search/numeric.row"),
    radioGroupRow = require("../components/custom.search/radio.group.row"),
    dateRow = require("../components/custom.search/date.row"),
    autoSuggest = require("../components/autosuggest"),
    dropDown = require("../components/dropdown"),
    checkBoxRow = require("../components/custom.search/checkbox.row");

var PatentAdvancedSearch = function (type) {

    var baseElement;

    (function () {
        if (type === "offscreen") {
            baseElement = element(by.css(".offscreen-content"));
        } else {
            baseElement = element(by.css(".modal.is-active"));
        }
    })();

    this.clearLink = baseElement.element(by.css(".clearfix .left a"));
    this.doneBtn = baseElement.element(by.css(".clearfix .right a"));
    // this.customSearchDropDown = new dropDown(baseElement.element(by.css("select[class*='custom-filter']")));
    // this.customSearchDropDown = new dropDown(element(by.css(".custom-filter-select")));
    this.customSearchDropDown = baseElement.element(by.css(".selectize-input"));
    this.filterSearchBox = $("fieldset .selectize-input input[type='search']");


    this.patentNumber = new textRow(baseElement.element(by.xpath("//*[contains(text(), 'Patent Number')]/ancestor::div[contains(@class, 'filter-row')]")), {
        "input": element(by.css("textarea"))
    });
    this.termSearch = new textRow(baseElement.element(by.xpath("//*[contains(text(), 'Term Search')]/ancestor::div[contains(@class, 'filter-row')]")), {
        "input": element(by.css("input"))
    });
    this.termSearchError = baseElement.element(by.css(".error.info"));
    this.portfolioName = new autoSuggest(baseElement.element(by.xpath("//*[contains(text(), 'Portfolio Name')]/ancestor::div[contains(@class, 'filter-row')]")), {
        "input": element(by.css("input[class*='ui-select-search']")),
        "options": element(by.css(".ui-select-choices-row-inner div")),
        "clear": element(by.css("a[class*='rpx-alert']>i"))
    });
    this.associatedToPatent = new textRow(baseElement.element(by.xpath("//*[contains(text(), 'Associated to Patent')]/ancestor::div[contains(@class, 'filter-row')]")), {
        "input": element(by.css("textarea"))
    });

    this.clickClearFiltersLink = function () {
        this.clearLink.click();
        angularWait();
    };

    this.clickDoneBtn = function () {
        this.doneBtn.click();
        angularWait();
    };

    this.clearFilters = function () {
        this.clickClearFiltersLink();
        this.clickDoneBtn();
    };

    this.facet = function (facetName) {
        return new facetRow(baseElement.element(by.xpath("//*[contains(text(), '" + facetName + "')]/ancestor::div[contains(@class, 'filter-row')]")));
    };

    this.selectFromFacetOptions = function (facetName, searchTerm) {
        this.facetRowElement = this.facet(facetName);
        this.facetRowElement.selectFromAvailableOptions(searchTerm);
    };

    this.selectFromFacetAutoSuggest = function (field, searchTerm) {
        
        var facetRowElement = this.facet(field);
        facetRowElement.select(searchTerm);
    };



    this.facetRowSearch = function (field, searchTerm) {
        // this.customSearchDropDown.select(field);


        this.customSearchDropDown.selectByFullName(field);

        this.selectFromFacetAutoSuggest(field, searchTerm);
        this.clickDoneBtn();
    };

    // Selecting filter field based on new UI
    this.selectFilterField = function (field) {
        var filterFieldElement = element(by.xpath("//span[text()='" + field + "']"));
      
        // this.customSearchDropDown.scrollToView();
        
        this.customSearchDropDown.click();
        // angularWait();
        filterFieldElement.click();
        this.customSearchDropDown.click();
    }

    this.selectfacetFilter = function (field, searchTerm) {
        // this.customSearchDropDown.select(field);
        this.selectFilterField(field);

        // this.customSearchDropDown.selectByFullName(field);

        this.selectFromFacetAutoSuggest(field, searchTerm);
        this.clickDoneBtn();
    };

    // selecting facets 
    this.selectfacets = function (field, searchTerm) {
        // this.customSearchDropDown.select(field);
        // this.selectFilterField(field);

        // this.customSearchDropDown.selectByFullName(field);

        this.selectFromFacetAutoSuggest(field, searchTerm);
        this.clickDoneBtn();
    };

    this.facetOptionsSearch = function (facetName, searchTerm) {
        this.selectFromFacetOptions(facetName, searchTerm);
        this.clickDoneBtn();
    };

    this.numericRowSearch = function (field, type, value1, value2) {
        // this.customSearchDropDown.select(field);
        this.customSearchDropDown.selectByFullName(field)
        var numericRowElement = new numericRow(baseElement.element(by.xpath("//*[contains(text(), '" + field + "')]/ancestor::div[contains(@class, 'filter-row')]")));
        numericRowElement.set(type, value1, value2);
        this.clickDoneBtn();
    };

    // selecting with new filter type

    this.selectNumericFilter = function (field, type, value1, value2) {
        this.selectFilterField(field);
        var numericRowElement = new numericRow(baseElement.element(by.xpath("//*[contains(text(), '" + field + "')]/ancestor::div[contains(@class, 'filter-row')]")));
        numericRowElement.set(type, value1, value2);
        this.clickDoneBtn();
    };

    this.radioRowSearch = function (field, option) {
        this.customSearchDropDown.select(field);
        var radioRowElement = new radioGroupRow(baseElement.element(by.xpath("//*[contains(text(), '" + field + "')]/ancestor::div[contains(@class, 'filter-row')]")));
        radioRowElement.select(option);
        this.clickDoneBtn();
    };

    // selecting with new filter type
    this.selectRadioFilter = function (field, option) {
        this.selectFilterField(field);
        var radioRowElement = new radioGroupRow(baseElement.element(by.xpath("//*[contains(text(), '" + field + "')]/ancestor::div[contains(@class, 'filter-row')]")));
        radioRowElement.select(option);
        this.clickDoneBtn();
    };

    this.checkBoxRowSearch = function (field, option) {
        this.customSearchDropDown.select(field);
        var checkBoxRowElement = new checkBoxRow(baseElement.element(by.xpath("//*[contains(text(), '" + field + "')]/ancestor::div[contains(@class, 'filter-row')]")))
        checkBoxRowElement.deselectAll();
        checkBoxRowElement.select(option);
        this.clickDoneBtn();
    };

    // Selecting checkboxrow with new filter type
    this.checkBoxRowFilter = function (field, option) {
        this.selectFilterField(field);
        var checkBoxRowElement = new checkBoxRow(baseElement.element(by.xpath("//*[contains(text(), '" + field + "')]/ancestor::div[contains(@class, 'filter-row')]")))
        checkBoxRowElement.deselectAll();
        checkBoxRowElement.select(option);
        this.clickDoneBtn();
    };


    this.textRowSearch = function (field, searchTerm) {
        // this.customSearchDropDown.select(field);
        this.customSearchDropDown.selectByFullName(field);

        var textRowElement = new textRow(baseElement.element(by.xpath("//*[contains(text(), '" + field + "')]/ancestor::div[contains(@class, 'filter-row')]")), {
            input: element(by.css("form input"))
        });
        textRowElement.enterSearchTerm(searchTerm);
        this.clickDoneBtn();
    };

    // Selecting textrow search with new filter type
    this.textRowFilter = function (field, searchTerm) {
        this.selectFilterField(field);

        var textRowElement = new textRow(baseElement.element(by.xpath("//*[contains(text(), '" + field + "')]/ancestor::div[contains(@class, 'filter-row')]")), {
            input: element(by.css("form input"))
        });
        textRowElement.enterSearchTerm(searchTerm);
        this.clickDoneBtn();
    };

    this.dateRowSearch = function (field, fromDate, toDate) {
        this.customSearchDropDown.select(field);
        var textRowElement = new dateRow(baseElement.element(by.xpath("//*[contains(text(), '" + field + "')]/ancestor::div[contains(@class, 'filter-row')]")));
        textRowElement.enterDates(fromDate, toDate);
        this.clickDoneBtn();
    };
    // Select date row search with filter

    this.dateRowFilter = function (field, fromDate, toDate) {
        this.selectFilterField(field);
        var textRowElement = new dateRow(baseElement.element(by.xpath("//*[contains(text(), '" + field + "')]/ancestor::div[contains(@class, 'filter-row')]")));
        textRowElement.enterDates(fromDate, toDate);
        this.clickDoneBtn();
    };
    
    //Priority date filter - common
    this.prioritydateRowFilter = function (field, fromDate, toDate) {
        // this.selectFilterField(field);
        var textRowElement = new dateRow(baseElement.element(by.xpath("//*[contains(text(), '" + field + "')]/ancestor::div[contains(@class, 'filter-row')]")));
        textRowElement.enterDates(fromDate, toDate);
        this.clickDoneBtn();
    };

    // Selecting filter by patent status
    this.selectPatentByStatus = function(status)
    {
        
        var expandPatentStatusIcon = baseElement.element(by.xpath("//a[@title='Patent Status']"));
        var statusCheckBox = baseElement.element(by.xpath("//input[contains(@id,'"+status+"')]"));
        expandPatentStatusIcon.click();
        angularWait();
        statusCheckBox.click();
        angularWait();  
        this.clickDoneBtn();

    };

    // Following functions are to check the Filters are removed
    this.isFacetSearchValuePresent = function (filterfield) {
        TempfilterTag = element(by.css("faceted-row a[title*='" + filterfield + "']"));
        deferred = protractor.promise.defer();
        TempfilterTag.isPresent().then(function (bool) {
            deferred.fulfill(bool);
        });
        return deferred.promise;
    };

    this.isNumericSearchValuePresent = function (filterfield) {
        TempfilterTag = element(by.xpath("//div[contains(text(),'" + filterfield + "')]/parent::numeric-row//a[@class='rpx-alert reset-input-numeric']"));
        deferred = protractor.promise.defer();
        TempfilterTag.isPresent().then(function (bool) {
            deferred.fulfill(bool);
        });
        return deferred.promise;
    };

    this.isRadioSearchValuePresent = function (filterfield) {
        TempfilterTag = element(by.xpath("//radiobutton-group-row//input[contains(@class,'ng-valid-parse')]"));
        deferred = protractor.promise.defer();
        TempfilterTag.isPresent().then(function (bool) {
            deferred.fulfill(bool);
        });
        return deferred.promise;
    };

    this.isDateSearchValuePresent = function (filterfield) {
        TempfilterTag = element(by.xpath("//div[contains(text(),'" + filterfield + "')]//parent::form//a[@class='rpx-alert reset-input']"));
        deferred = protractor.promise.defer();
        TempfilterTag.isPresent().then(function (bool) {
            deferred.fulfill(bool);
        });
        return deferred.promise;
    };

    this.isTextRowSearchValuePresent = function (filterfield) {
        TempfilterTag = element(by.xpath("//span[contains(text(),'" + filterfield + "')]/parent::div/parent::text-row//a[@class='rpx-alert reset-input']"));
        deferred = protractor.promise.defer();
        TempfilterTag.isPresent().then(function (bool) {
            deferred.fulfill(bool);
        });
        return deferred.promise;
    };

    this.deleteAllRows = function () {
        // var closeIcons = baseElement.all(by.css("a[class*='right'] .fa-times"));
        var closeIcons = baseElement.all(by.css("a[ng-click*='remove']"));
        closeIcons.count().then(function (count) {
            console.log("Count of icons"+count);
            while (count > 0) {
                closeIcons.get(0).click();
                angularWait();
                count--;
            }
        });
    };
};
PatentAdvancedSearch.prototype = basePage;
module.exports = PatentAdvancedSearch;