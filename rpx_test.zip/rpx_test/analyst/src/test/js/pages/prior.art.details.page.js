var basePage = require("./base.page");

var PriorArtDetailsPage = function () {
    this.title = $("module-heading a");
};
PriorArtDetailsPage.prototype = basePage;
module.exports = new PriorArtDetailsPage();