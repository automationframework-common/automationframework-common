var basePage = require("./base.page");

var PortfolioSearchResults = function () {
    this.url = "/portfolio";

    this.title = $(".small-12.medium-12.columns>h2");
};
PortfolioSearchResults.prototype = basePage;
module.exports = new PortfolioSearchResults();