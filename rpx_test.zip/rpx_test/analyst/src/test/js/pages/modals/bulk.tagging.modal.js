var basePage = require("./../base.page");

var tabs = require("../../components/tabs");
var grid = require("../../components/grid");

var BulkTaggingModal = function () {
    this.bulkTaggingIcon = $("bulk-tagging a"),
        this.modal = $(".bulk-tagging-modal");
    this.bulkTagModalClose = $(".bulk-tagging-modal .fa.fa-close");
    this.sourcePatentName = element(by.xpath("//div[contains(@class,'bulk-tagging-modal')]/div[contains(@class,'header')]/span[2]"));
    this.tagElements = $$(".bulk-tagging-modal .tag-content");
    this.nextButton = this.modal.element(by.xpath("//a[contains(text(),'Next')]"));
    this.saveButton = this.modal.element(by.xpath("//a[contains(text(),'Save')]"));
    this.bulkGrid = new grid(element(by.css(".bulk-tagging-modal #bulk-grid")), {
        type: "default"
    })


    this.portfolioName = this.modal.element(by.model("portfolio.name"));
    this.createBtn = this.modal.element(by.css("a[class='button tiny']"));

    this.tabs = new tabs(this.modal.element(by.css(".tabbable dl")));
    this.copyPasteTab = {
        assetNumbers: this.modal.element(by.model("portfolio.stripped_patnums"))
    };
    this.uploadTab = {
        dropBox: $("input[type=file][ng-model='portfolio.pub_or_pat_num']")
    };



    // open bulk-tagging modal
    this.openBulkTaggingModal = function () {
        
                this.bulkTaggingIcon.click().then(function () {
                    angularWait();});
           
                 
    };

    this.isBulkTagginModalPresent = function () {
        var deferred = protractor.promise.defer();
        this.modal.isDisplayed().then(function () {
            deferred.fulfill(true);
        }).catch(function () {
            deferred.fulfill(false);
        });
        return deferred.promise;

    };

    // close the modal
    this.closeBulkTaggingModal = function () {
        
        this.bulkTagModalClose.click().then(function () {
            angularWait();});
   
         
};

    //Getting tag value by default

    this.getNoDataText = function (tagTittle) {
        var deferred = protractor.promise.defer();
        var tagText = element(by.xpath("//div[contains(text(),'" + tagTittle + "')]/parent::div/parent::div//div[contains(@class,'no-data')]"))
        tagText.getText().then(function (text) {
            deferred.fulfill(text);
        });
        return deferred.promise;
    };

    // Getting tags under any tag section
    this.getTags = function (techTagTitle) {
        var data =[];
        var deferred = protractor.promise.defer();
        var tagsText = element.all(by.xpath("//div[contains(text(),'" + techTagTitle + "')]/parent::div/parent::div//div[contains(@class,'tech-tag')]"));
        tagsText.each(function (tags) {
            tags.getText().then(function (tagText) {
                data.push(tagText)
            });
            deferred.fulfill(data);
        });
        return deferred.promise;

    };
    // Selecting Paddle Switches of TechTags
    this.toggleAllTagSwitches = function (tagType) {
        var type;
        switch (tagType) {
            case "Tech Tags":
                type = "tech-tag-switch";

            case "Theory":
                type = "theory-switch";

            case "PRC":
                type = "company-switch";

            case "Claim Chart":
                type = "company-cc-switch";

            case "Licensees":
                type = "licensee-switch";

            default:
                type = "type";

                break;

        }
        var toggleSwitches = $$(".bulk-tagging-modal input[id*='" + type + "']");
        toggleSwitches.each(function (toggleSwitch) {
            toggleSwitch.click().then(function () {
                angularWait();
            });

        });
    };

    // Toggling any indivdual tag switch
    this.toggleAnyTag = function (tagText) {
        var tagSwitch = element(by.xpath("//div[contains(text(),'" + tagText + "')]/parent::div/parent::div/following-sibling::div//input"))
        tagSwitch.click().then(function () {
            angularWait();
        });
    };


// Select the tag-switch
this.selectToggleOfTag = function (tagText) {
    var tagSwithControl = element(by.xpath("//div[contains(text(),'" + tagText + "')]/parent::div/parent::div/following-sibling::div//label"));
    var tagSwitch = element(by.xpath("//div[contains(text(),'" + tagText + "')]/parent::div/parent::div/following-sibling::div//input"))
    tagSwitch.getAttribute("class").then(function (attribValue) {
        if (attribValue.includes("ng-empty")) {
            tagSwithControl.click();
            angularWait();
        }
    });
};

// Deselect the tag-switch {tagText}
this.deSelectToggleOfTag = function (tagText) {
    var tagSwithControl = element(by.xpath("//div[contains(text(),'" + tagText + "')]/parent::div/parent::div/following-sibling::div//label"));
    var tagSwitch = element(by.xpath("//div[contains(text(),'" + tagText + "')]/parent::div/parent::div/following-sibling::div//input"));
    tagSwitch.getAttribute("class").then(function (attribValue) {
        if (attribValue.includes("ng-not-empty")) {
            tagSwithControl.click();
            angularWait();
        }
    });
};

//Select the tag-switch of claim chart for a PRC
this.selectClaimChartofPRC = function (tagText) {
    var tagSwithControl = element(by.xpath("//div[contains(text(),'" + tagText + "')]/parent::div/parent::div/following-sibling::div/following-sibling::div//label"));
    var tagSwitch = element(by.xpath("//div[contains(text(),'" + tagText + "')]/parent::div/parent::div/following-sibling::div/following-sibling::div//input"))
    tagSwitch.getAttribute("class").then(function (attribValue) {
        if (attribValue.includes("ng-empty")) {
            tagSwithControl.click();
            angularWait();
        }
    });
};


    // Checking Toggle Switch Present
    this.toggleSwitchIsDisplayed = function (tagName) {
        var deferred = protractor.promise.defer();
        var tagSwitch = element(by.xpath("//div[contains(text(),'" + tagName + "')]/parent::div/parent::div/following-sibling::div//input"))
        tagSwitch.isDisplayed().then(function () {
            deferred.fulfill(true);
        }).catch(function () {
            deferred.fulfill(false);
        });
        return deferred.promise;

    };
    // Clicking Next Button
    this.clickNext = function () {
        this.nextButton.click().then(function () {
            angularWait();
        });
    };

    // Clicking Save Button
    this.clickSave = function () {
        this.saveButton.click().then(function () {
            angularWait();
        });
    };

};
BulkTaggingModal.prototype = basePage;
module.exports = new BulkTaggingModal();