var basePage = require("./../base.page");

var searchSelect = require("../../components/search.select");

var NewNplReferenceModal = function () {

    this.qualificationDate = $("label[ng-class*='qualificationDate']>input");
    this.referenceTitle = $("label[ng-class*='priorArtReference.title']>input");

    this.qualificationDateNotes = element(by.model("ctrl.reference.qualification_date_notes"));
    this.notes = element(by.model("ctrl.reference.notes"));

    this.url = element(by.model("ctrl.reference.url"));
    this.author = element(by.model("ctrl.reference.authors"));
    this.citation = element(by.model("ctrl.reference.citation"));

    this.techTagsSearchSelect = new searchSelect(element(by.xpath("//div[contains(@title, 'tech tags')]/ancestor::label")), {
        input: element(by.css("input[type='search']")),
        options: element(by.css(".ui-select-choices-row")),
        close: element(by.css(".select-close"))
    });
    this.freeformTagsSearchSelect = new searchSelect(element(by.xpath("//div[contains(@title, 'free form tags')]/ancestor::label")), {
        input: element(by.css("input[type='search']")),
        options: element(by.css(".ui-select-choices-row")),
        close: element(by.css(".select-close")),
        selectedOptions: element(by.css("span[ng-repeat*='selected'] span[class='ng-binding ng-scope']"))
    });

    this.saveBtn = element(by.css(".save-btn"));
    this.cancelBtn = element(by.css("a[ng-click='ctrl.cancel()']"));

    this.saveNPLReference = function (dataObject) {
         (this.qualificationDate).sendKeys(dataObject["Qualification Date"]);
         (this.referenceTitle).sendKeys(dataObject["Reference Title"]);
         (this.qualificationDateNotes).sendKeys(dataObject["Qualification Dt. Notes"]);
         (this.notes).sendKeys(dataObject["Reference Notes"]);
         (this.author).sendKeys(dataObject["Author"]);
         (this.citation).sendKeys(dataObject["Citation"]);
        //  (this.techTagsSearchSelect).sendKeys(dataObject["Tech Tags"]);
        //  (this.freeformTagsSearchSelect).sendKeys(dataObject["Freeform Tags"]);
        (this.techTagsSearchSelect).select(dataObject["Tech Tags"]);
        (this.freeformTagsSearchSelect).select(dataObject["Freeform Tags"]);

        this.saveBtn.click();
        angularWait();
    };
};
NewNplReferenceModal.prototype = basePage;
module.exports = new NewNplReferenceModal();