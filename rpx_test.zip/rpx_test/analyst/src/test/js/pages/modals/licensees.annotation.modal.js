var basePage = require("./../base.page");

var quillEditor = require("../../components/quill.editor");

var LicenseesAnnotationModal = function (modalElement) {

    this.closeIcon = modalElement.element(by.css(".close-reveal-modal"));

    this.priorityDate = modalElement.element(by.css(".license_data_expiry:not([disabled])"));
    this.priorDateDisabled = modalElement.element(by.css(".license_data_expiry[disabled='disabled']"));
    this.licenseesEditor = new quillEditor(modalElement.element(by.css(".editor-container")));
    this.saveBtn = modalElement.element(by.css(".save-btn"));
    this.cancelBtn = modalElement.element(by.xpath(".cancel-btn"));

    this.save = function (priorDate, annotation) {
        if (priorDate !== undefined)
            this.priorityDate.sendKeys(priorDate);
        this.licenseesEditor.enterText(annotation);
        this.saveBtn.click();
        angularWait();
    };

    this.getData = function () {
        var this_ = this;
        var deferred = protractor.promise.defer();

        var dataObj = {};
        this_.priorityDate.getText().then(function (priorityDateValue) {
            dataObj["priorityDate"] = priorityDateValue;
            this_.licenseesEditor.getData().then(function (annotationValue) {
                dataObj["licenseesAnnotation"] = annotationValue;
            });
        }).then(function () {
            deferred.fulfill(dataObj);
        });

        return deferred.promise;
    };

    this.close = function () {
        var this_ = this;
        this_.closeIcon.isDisplayed().then(function () {
            this_.closeIcon.click();
            angularWait();
            // waitFor(this_.closeIcon).toBeInvisible();
        }).catch(function () { });
    };
};
LicenseesAnnotationModal.prototype = basePage;
//TODO NEW PAGE
module.exports = LicenseesAnnotationModal;