var basePage = require("../base.page");

var saveCancelContainer = require("../../components/save.cancel.container");

var quillEditor = require("../../components/quill.editor"),
    paddleSwitches = require("../../components/paddle.switches"),
    searchSelect = require("../../components/search.select"),
    checkBox = require("../../components/checkbox");

var TheoryModal = function () {
    // this.panel = $(".reveal-modal.fade.x-large.in");
    this.panel = $(".theory-modal-container-new");

    this.closeModal = function () {
        element(by.css(".fa-close")).click();
        angularWait();
    };


    // Role Auth Check with a Editor selector
    this.nonEditableTheoryField = element(by.xpath("//div[@contenteditable='false']"));
    //THEORY
    this.theory = new quillEditor(this.panel.element(by.css(".editor-container")));
    this.theoryError = this.panel.element(by.css(".editor_error"));
    this.theorySaveCancel = new saveCancelContainer(this.panel.element(by.css("save-cancel[sc-form-name='notesForm']")));
    this.setTheoryName = function (theoryName) {        
        var this_ = this;
        if (theoryName !== undefined) {            
            this.theory.enterText(theoryName).then(function () {
                this_.theorySaveCancel.save();
            });
        }
    };

    //CREDIBILITY
    this.credibility = this.panel.element(by.css(".credibility-input"));
    this.credibilitySaveCancel = new saveCancelContainer(this.panel.element(by.css("save-cancel[sc-form-name='credibilityForm']")));
    this.setCredibility = function (credibilityValue) {
        var this_ = this;
        if (credibilityValue !== undefined) {
            angularWait();
            $f(this.credibility).sendKeys(credibilityValue).then(function () {
                this_.credibilitySaveCancel.save();
            });
        }
    };

    //TECH TAGS
    this.techTags = this.panel.all(by.css(".theory-tags-list .tech-tag"));
    this.selectTechTags = function (techTagsName, deSelectAll) {        
        if (techTagsName !== undefined) {            
            selectOrDeselectTechTags(techTagsName, "select");     
        } 
    };
    this.deSelectTechTags = function (techTagsName) {
        if (techTagsName !== undefined)
            selectOrDeselectTechTags(techTagsName, "deSelect");
    };
    var selectOrDeselectTechTags = function (techTagsName, type) {
        var this_ = this;
        for (var techTagNameIndex in techTagsName) {
            var techTagElem = element(by.cssContainingText(".theory-tags-list .tech-tag", techTagsName[techTagNameIndex]));            
            techTagElem.getAttribute("class").then(function (classValue) {
                if (type === "deSelect" && classValue.includes("active")) {
                    techTagElem.click();
                    angularWait();
                } else if (type === "select" && !classValue.includes("active")) {
                    techTagElem.click();
                    angularWait();
                }
            });
        }
    };
    this.deselectAllTechTags = function () {
        var deferred = protractor.promise.defer();

        this.panel.all(by.css(".tech-tag.label.active")).each(function () {
            element(by.css(".tech-tag.label.active")).click();
            angularWait();
        }).then(function () {
            deferred.fulfill();
        });

        return deferred.promise;
    };
    this.getTechTags = function () {
        var deferred = protractor.promise.defer();
        var data = {};

        var selectedTags = this.panel.all(by.css(".theory-tags-list div[class='tech-tag label active'] span[class*='tag-text-label']"));
        var nonSelectedTags = this.panel.all(by.css(".theory-tags-list div[class='tech-tag label'] span[class*='tag-text-label']"));

        protractor.promise.all([
            getAllData(selectedTags),
            getAllData(nonSelectedTags)]
        ).then(function (results) {
            data["selected"] = results[0];
            data["unSelected"] = results[1];
            data["all"] = results[0].concat(results[1]);
        }).then(function () {
            deferred.fulfill(data);
        });

        return deferred.promise;
    };

    




    //PRC
    this.deSelectAllPRCs = function () {
        var deferred = protractor.promise.defer();

        this.panel.all(by.css(".prcs-list .prcs.ng-scope .prc-tag.label.active")).each(function (prc) {
            element(by.css(".prcs-list .prcs.ng-scope .prc-tag.label.active")).click();
            angularWait();
        }).then(function () {
            deferred.fulfill();
        });

        return deferred.promise;
    };
    this.prcSearchSelect = new searchSelect(element(by.css("div[class*='prc-select-container']")), {
        input: element(by.css("input[type='search']")),
        options: element(by.css(".ui-select-choices-row")),
        close: element(by.css(".select-close"))
    });
    this.addPRCs = function (prcArray) {
        if (prcArray !== undefined) {
            for (var prcArrayIndex in prcArray) {
                this.addPRC(prcArray[prcArrayIndex]);
            }
        }
    };

    /** 
     * @param {prcObject} -> { name: "testPRC", claimCharted: true, rating: "test rating", eou: "test eou" }
     */
    this.addPRC = function (prcObject) {
        var this_ = this;
        var prcName = prcObject["name"];

        var prcRow = element(by.xpath("//span[contains(@class,'prc-text-label')][text()='" + prcName +
            "']/../ancestor::div[@class='row prc-row']"));

        selectPRC(prcRow, prcName, this.prcSearchSelect).then(function () {
            selectPRCClaimCharted(prcRow, prcObject["claimCharted"]);
            setRatingAndEou(prcRow, prcObject["rating"], prcObject["eou"]);
        });
    };
    var selectPRC = function (prcRow, prcName, prcSearchSelect) {
        var deferred = protractor.promise.defer();

        prcRow.isDisplayed().then(function () {

        }).catch(function () {
            prcSearchSelect.select(prcName);
        }).then(function () {
            element(by.xpath(prcRow.locator().value + "//div[contains(@class,'small-5')]//div")).getAttribute("class").then(function (classVar) {
                if (!classVar.includes("active")) {
                    element(by.xpath(prcRow.locator().value + "//div[contains(@class,'small-5')]//div")).click();
                    angularWait();
                }
            }).then(function () {
                deferred.fulfill();
            });
        });

        return deferred.promise;
    };
    var selectPRCClaimCharted = function (prcRow, claimChartedValue) {
        var claimChartedElement = new checkBox(element(by.xpath(prcRow.locator().value + "//div[contains(@class,'small-3')]/input")))

        if (claimChartedValue === true)
            claimChartedElement.check();
        else if (claimChartedValue === false)
            claimChartedElement.unCheck();
    };
    var setRatingAndEou = function (prcRow, rating, eou) {
        var ratingEouSaveCancel = new saveCancelContainer(element(by.xpath(prcRow.locator().value + "//save-cancel")));

        if (rating !== undefined || eou !== undefined) {
            protractor.promise.all([
                $f(element(by.xpath(prcRow.locator().value + "//input[contains(@class, 'prc-score')]"))).sendKeys(rating),
                $f(element(by.xpath(prcRow.locator().value + "//input[contains(@class, 'prc-eou')]"))).sendKeys(eou)
            ]).then(function () {
                ratingEouSaveCancel.save();
            });
        }
    };

    //TODO get all data including claim charted option and rating form
    this.getPrcs = function () {
        var deferred = protractor.promise.defer();
        var data = {}

        var selectedTags = this.panel.all(by.css("div[class='prc-tag label truncate active']"));
        var nonSelectedTags = this.panel.all(by.css("div[class='prc-tag label truncate']"));

        protractor.promise.all([
            getAllData(selectedTags),
            getAllData(nonSelectedTags)
        ]).then(function (results) {
            data["selected"] = results[0];
            data["unSelected"] = results[1];
            data["all"] = results[0].concat(results[1]);
        }).then(function () {
            deferred.fulfill(data);
        });

        return deferred.promise;
    };

    //ADD THEORIES
    this.addTheory = function (theoryObject) {
        if (theoryObject !== undefined) {
            this.setTheoryName(theoryObject["theory"]);
            this.setCredibility(theoryObject["credibility"]);
            this.selectTechTags(theoryObject["techTags"], true);
            this.addPRCs(theoryObject["prcs"]);
            angularWait();
            this.closeModal();
            console.log("Window closed");
        }
    };

    this.getData = function () {
        var deferred = protractor.promise.defer();
        var this_ = this;
        var data = {};

        protractor.promise.all([
            this_.theory.getData(),
            this_.credibility.getAttribute("value"),
            this_.getTechTags(),
            this_.getPrcs()
        ]).then(function (resultArray) {
            data["theory"] = resultArray[0];
            data["credibility"] = resultArray[1];
            data["techTags"] = resultArray[2];
            data["prcs"] = resultArray[3];
            this_.closeModal();
        }).then(function () {
            deferred.fulfill(data);
        });

        return deferred.promise;
    };
};
TheoryModal.prototype = basePage;
module.exports = new TheoryModal();