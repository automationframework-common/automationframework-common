var basePage = require("../base.page");

var dropDown = require("../../components/dropdown"),
    checkBox = require("../../components/checkbox"),
    searchSelect = require("../../components/search.select"),
    autoSuggest = require('../../components/autosuggest');

var NewPriorArtAssociationModal = function () {
    this.modal = $(".reveal-modal.fade.x-large.in");

    this.basis = new dropDown(this.modal.element(by.model("ctrl.priorArt.basis")));
    this.priorArtReportCheckBox = new checkBox(this.modal.element(by.model("ctrl.priorArt.pa_search_report")));

    this.arguementTextArea = this.modal.element(by.model("ctrl.priorArt.argument"));
    this.accusedProducts = new searchSelect(this.modal.element(by.css("label[class='tagging-label']")), {
        input: element(by.css("input[type='search']")),
        options: element(by.css(".ui-select-choices li")),
        close: element(by.css(".select-close"))
    });

    this.saveBtn = this.modal.element(by.css("button[ng-click='ctrl.savePriorArt()']"));
    this.cancelBtn = this.modal.element(by.css("button[ng-click='ctrl.cancelPriorArt()']"));

    //TAEGET PATENTS LIST
    this.addTargetPatentLink = this.modal.element(by.css("a[ng-click='ctrl.addTargetPatentItem()']"));
    this.targetPatentsList = this.modal.all(by.css("target-patents-list .patent-claim-container div.patent-claim.row"));
    this.addTargetPatents = function (data) {
        if (data instanceof Object && data instanceof Array) {
            for (var index in data) {
                this.addTargetPatent(data[index]);
            }
        } else if (data instanceof Object) {
            this.addTargetPatent(data);
        }
    };
    this.addTargetPatent = function (dataObj) {
        var this_ = this;
        var lastRowIndex;

        this_.addTargetPatentLink.click().then(function () {
            this_.targetPatentsList.count().then(function (count) {
                lastRowIndex = count - 1;
            });
        }).then(function () {
            var targetPatentRow = this_.targetPatentsList.get(lastRowIndex);

            var patentDropDown = new autoSuggest(targetPatentRow.element(by.css(".col-sm-6")), {
                input: element(by.css("input")),
                options: element(by.css(".ui-select-choices-row-inner")),
                clear: element(by.css(".ui-select-match-close"))
            });
            var claimTextBox = targetPatentRow.element(by.css(".col-sm-4 input"));
            var close = targetPatentRow.element(by.css(".col-sm-2 .fa-close"));

            protractor.promise.all([
                patentDropDown.select(dataObj["patent"]),
                claimTextBox.sendKeys(dataObj["claim"])
            ]);
        });
    };

    //ADD REFERENCES
    this.addReferencesLink = this.modal.element(by.css("a[dropdown-toggle='#add-reference-search-dropdown']"));
    this.selectReferencesType = function (type) {
        var deferred = protractor.promise.defer();

        protractor.promise.all([
            this.addReferencesLink.click(),
            this.modal.element(by.cssContainingText('#add-reference-search-dropdown li', type)).click()
        ]).then(function () {
            deferred.fulfill(angularWait());
        });

        return deferred.promise;
    };
    this.paReferencesRows = this.modal.all(by.css(".row.priorart-reference-row"));
    this.addReferences = function (data) {
        if (data instanceof Object && data instanceof Array) {
            for (var index in data) {
                this.addReference(data[index]);
            }
        } else if (data instanceof Object) {
            this.addReference(data);
        }
    };
    
    /**
     * @param {Object} dataObj - NPL/Patent reference data 
     * eg: {
            type: "patent",
            country: "US",
            patent: "7777777"
        } or {
            type: "NPL",
            npl: "test"
        }
     */
    this.addReference = function (dataObj) {
        var this_ = this;
        var lastRowIndex;

        var refType = dataObj["type"].includes("NPL") ? "NPL" : "Patent";
        this_.selectReferencesType(refType).then(function () {
            this_.paReferencesRows.count().then(function (count) {
                lastRowIndex = count - 1;
            }).then(function () {
                var referencesRow = this_.paReferencesRows.get(lastRowIndex);

                if (refType.includes("NPL")) {
                    var nplAutoSuggest = new autoSuggest(referencesRow.element(by.model("priorart.transformedData.npl_details")), {
                        input: element(by.css("input")),
                        options: element(by.css(".ui-select-choices-row-inner")),
                        clear: element(by.css(".ui-select-match-close"))
                    });

                    protractor.promise.all([
                        nplAutoSuggest.select(dataObj["npl"])
                    ]);
                } else {
                    var countryDropDown = new dropDown(referencesRow.element(by.css(".pa-ref-patent-country-input")));
                    var patentAutoSuggest = new autoSuggest(referencesRow.element(by.css(".pa-ref-patent-country-pat-input")), {
                        input: element(by.css("input")),
                        options: element(by.css(".ui-select-choices-row-inner")),
                        clear: element(by.css(".ui-select-match-close"))
                    });

                    protractor.promise.all([
                        countryDropDown.select(dataObj["country"]),
                        patentAutoSuggest.select(dataObj["patent"])
                    ]);
                }
            });
        });
    };

    /**
     * @param {Object} dataObj - New Prior Art data
     * eg. { 
            basis: "Background", 
            priorArtSearch: true, 
            targetPatents: {                
                patent: "US 8,888,999 B2",
                claim: "1"            
            }, 
            references: {
                type: "patent",
                country: "US",
                patent: "7777777"
            },
            argument: "test argument",
            accusedProducts: 
        } 
    */
    this.saveNewPriorArtAssociation = function () {
        //TODO use the above helper methods and object structure for create
    };
};
NewPriorArtAssociationModal.prototype = basePage;
module.exports = new NewPriorArtAssociationModal();