var basePage = require("./../base.page");

var tabs = require("../../components/tabs");

var CreatePortfolioModal = function () {
    this.modal = $(".reveal-modal");

    this.portfolioName = this.modal.element(by.model("portfolio.name"));
    this.createBtn = this.modal.element(by.css("a[class='button tiny']"));

    this.tabs = new tabs(this.modal.element(by.css(".tabbable dl")));
    this.copyPasteTab = {
        assetNumbers: this.modal.element(by.model("portfolio.stripped_patnums"))
    };
    this.uploadTab = {
        dropBox: $("input[type=file][ng-model='portfolio.pub_or_pat_num']")
    };

    this.createFromCopyPaste = function (pName, assetNumbers) {
        this.tabs.select("Copy And Paste");
        this.portfolioName.sendKeys(pName);
        this.copyPasteTab.assetNumbers.sendKeys(assetNumbers);
        waitFor(this.createBtn).toBeClickable();
        this.createBtn.click();
        angularWait();
    };

    this.createFromUpload = function (pName, path) {
        this.portfolioName.sendKeys(pName);
        this.tabs.select("Upload");
        this.uploadTab.dropBox.sendKeys(path);
        waitFor(this.createBtn).toBeClickable();
        this.createBtn.click();
        angularWait();
    };
};
CreatePortfolioModal.prototype = basePage;
module.exports = new CreatePortfolioModal();