var basePage = require("../base.page");

var paddleSwitches = require("../../components/paddle.switches"),
    quillEditor = require("../../components/quill.editor");

var PrcModal = function () {
    this.panel = $(".reveal-modal.fade.in");

    this.title = this.panel.element(by.css(".column.title"));
    this.tags = new paddleSwitches(this.panel.element(by.css("div[ng-repeat='tag in prc.annotations.all_tech_tags']")), {
        "label": $("div[class*='tag-text']"),
        "switchIcon": $(".switch.tiny.round input")
    });
    this.theory = new paddleSwitches(this.panel.element(by.css("div[ng-repeat='theory in prc.annotations.all_theories']")), {
        "label": $("div[class*='tag-text']"),
        "switchIcon": $(".switch.tiny.round input")
    });
    this.comment = new quillEditor(this.panel.element(by.css(".editor-container")));

    this.disabledSaveBtn = this.panel.element(by.css("a[ng-click='save()']"));
    this.saveBtn = this.panel.element(by.css("a[ng-click='save()']:not([class*='disabled'])"));
    this.cancelBtn = this.panel.element(by.css("a[ng-click='cancel()']"));

    this.save = function (dataObj) {
        this.comment.enterText(dataObj["notes"]);
        this.tags.toggleSwitches(dataObj["tags"]);
        this.theory.toggleSwitches(dataObj["theory"]);
        
        $f(this.saveBtn).waitUntilVisible();
        this.saveBtn.click();  
        angularWait();
    };

    this.getData = function () {
        var deferred = protractor.promise.defer();
        var this_ = this;
        var data = {};

        this_.title.getText().then(function (titleText) {
            this_.tags.getData().then(function (tagSwitches) {
                this_.theory.getData().then(function (theorySwitches) {
                    this_.comment.getData().then(function (commentText) {
                        data["title"] = titleText;
                        data["tags"] = tagSwitches;
                        data["theory"] = theorySwitches;
                        data["notes"] = commentText;
                    });
                });
            });
        }).then(function () {
            this_.cancelBtn.click();
            angularWait();
            deferred.fulfill(data);
        });

        return deferred.promise;
    };
};
PrcModal.prototype = basePage;
module.exports = new PrcModal();