var basePage = require("../base.page");

var ConfirmationModal = function () {
    // this.panel = $(".confirm_modal_container_common");
    this.panel = $("div[class*='confirm_modal']");
    
    this.yesBtn = $(".button_success");
    

    this.confirm = function () {
        waitFor(this.panel).toBeClickable();
        this.yesBtn.click().then(function () {
            angularWait();
            //waitFor(deleteModal).toBeInvisible();
        });
    };
}
ConfirmationModal.prototype = basePage;
module.exports = new ConfirmationModal();