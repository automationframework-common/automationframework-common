
var basePage = require('./base.page');

var autoSuggest = require("./../components/autosuggest"),
    portfolioPage = require("./portfolio.details.page"),
    patentAdvancedSearch = require("./advanced.search");

var HomePage = function () {
    this.userLabel = $(".home-grid .welcome strong");
    this.userCompanyLabel = $(".home-grid .welcome>div");
    this.bannerImage = $(".global_logo_image");
    this.dashBoardLink = $("a[ui-sref='insight.main.home']");

    this.pinned_Portfolio = {
        pane: $("div[ng-if*='pinned_portfolios']"),
        noPortfolioTextMessage: $("div[class*='pinned_portfolios_container'] li[class*='no-data']"),
        isPortfolioPinned: function (portfolioName) {
            var deferred = protractor.promise.defer();
            portfolioLink = element(by.xpath("//div[contains(@class,'pinned_portfolios_container')]//a[contains(text(),'" + portfolioName + "')]"));
            portfolioLink.isPresent().then(function (bool) {
                deferred.fulfill(bool);
            });
            return deferred.promise;
        },
        clickPinnedPortfolio: function (portfolioName) {
            portfolioLink = element(by.xpath("//div[contains(@class,'pinned_portfolios_container')]//a[contains(text(),'" + portfolioName + "')]"));
            portfolioLink.click();
            angularWait();
        },
        // Removing pinned portfolio yet to be implemented
        removeAllPinnedPortfolios: function () {

            var pinnedPortfolioLinks = element.all(by.xpath("//div[contains(@class,'pinned_portfolios_container')]//a"));
            pinnedPortfolioLinks.count().then(function (count) {
                for (i = 0; i < count; i++) {
                    pLink = element(by.xpath("//div[contains(@class,'pinned_portfolios_container')]//a"));
                    pLink.click();
                    angularWait();
                    at(portfolioPage);
                    // portfolioPage.patentList.clickActionItemsIcon();
                    portfolioPage.patentList.selectActionItem("Unpin from Dashboard");
                    navigateBack();
                    angularWait();
                }

            });

        }

    };

    this.footerSection = {
        rpxCorpPageHeader: element(by.xpath("//h1[@class='home-banner__headline']")),
        feedBackLink: element(by.xpath("//app-footer//a[contains(text(),'Feedback')]")),

        getCopyRightText: function () {
            copyRightText = $("app-footer div[class*='text-left']>span");
            var deferred = protractor.promise.defer();
            copyRightText.getText().then(function (text) {
                deferred.fulfill(text.trim());
            });
            return deferred.promise;
        },
        getToSHeaderText: function () {
            TosHeaderElem = $("terms_service h3");
            var deferred = protractor.promise.defer();
            TosHeaderElem.getText().then(function (text) {
                deferred.fulfill(text.trim());
            });
            return deferred.promise;
        },
        getPrivacyPolicyHeaderText: function () {
            TosHeaderElem = $("privacy_policy h3");
            var deferred = protractor.promise.defer();
            TosHeaderElem.getText().then(function (text) {
                deferred.fulfill(text.trim());
            });
            return deferred.promise;
        },
        clickLinkOf: function (footerLink) {
            var linkElement = element(by.xpath("//app-footer//a[contains(text(),'" + footerLink + "')]"));
            linkElement.click();
            // angularWait();
        },
        clickCloseButton: function () {
            closeBtn = element(by.xpath("//button[contains(text(),'Close')]"));
            closeBtn.click();
            angularWait();
        },
    };
    this.uSPublicationsSection = {
        publicationsPane: $(".dashboard-publications-chart"),
        publicationsDataLabel: $(".highcharts-data-labels.highcharts-series-0"),
        grantsDataLabel: $(".highcharts-data-labels.highcharts-series-1"),
        Xcharts: element.all(by.css(".highcharts-series-0 .highcharts-text-outline")),
        Ycharts: element.all(by.css(".highcharts-series-1 .highcharts-text-outline")),
        contextMenuButton: $(".highcharts-button"),
        menuOptions: element.all(by.css(".highcharts-menu-item")),
        publicationsSelector: $(".highcharts-legend-item.highcharts-series-0"),
        grantsSelector: $(".highcharts-legend-item.highcharts-series-1"),


        selectViewOf: function (field, bool) {
            var fieldSelector, fieldDataLabel;
            if (field === 'publications') {
                fieldSelector = this.publicationsSelector;
                fieldDataLabel = this.publicationsDataLabel;
            }
            else if (field === 'grants') {
                fieldSelector = this.grantsSelector;
                fieldDataLabel = this.grantsDataLabel;
            }
            fieldDataLabel.getAttribute('visibility').then(function (val) {
                if (bool === 'yes') {
                    if (val === 'hidden')
                        fieldSelector.click();
                    else { }
                }
                else if (bool === 'no') {
                    if (val === 'visible')
                        fieldSelector.click();
                    else { }
                };
                angularWait();
            });

        },

        getDataArray: function (field) {
            var fieldset;
            if (field === 'publications')
                fieldset = this.Xcharts;
            else if (field === 'grants')
                fieldset = this.Ycharts;
            else if (field === 'menuOptions')
                fieldset = this.menuOptions;

            var deferred = protractor.promise.defer();
            data = [];
            fieldset.each(function (elem) {
                elem.getText().then(function (Value) {
                    data.push(Value);
                });
                deferred.fulfill(data);
            });
            return deferred.promise;
        },

        getVisibilityProperty: function (type) {
            var field;
            var deferred = protractor.promise.defer();
            if (type == 'publications')
                field = this.publicationsDataLabel;
            else if (type === 'grants')
                field = this.grantsDataLabel;
            field.getAttribute('visibility').then(function (value) {
                deferred.fulfill(value);
            });
            return deferred.promise;

        }
    };

    this.portfolioActions = {
        viewAllPortfoliosBtn: $(".grid-cell a[ui-sref='insight.main.portfolio']"),
        viewAllPortfolios: function () {
            this.viewAllPortfoliosBtn.click();
            angularWait();
        },

        createNewPortfolioBtn: $("a[ng-click='open()'][class*='portfolio-action']"),
        clickCreateNewPortfolioBtn: function () {
            this.createNewPortfolioBtn.click();
            angularWait();
        },

        openPortfolioAutoSuggest: new autoSuggest(element(by.css(".select-portfolio")), {
            input: element(by.css("input[type='search']")),
            options: element(by.css(".ui-select-choices-row-inner div")),
            clear: element(by.css(".rpx-alert.reset-input"))
        })
    };

    this.patentSearch = {
        patentTextArea: $(".search-patents .search-text"),
        searchBtn: $(".row.search-patents .button"),
        search: function (searchTerm) {
            this.patentTextArea.clear();
            this.patentTextArea.sendKeys(searchTerm);
            this.searchBtn.click();
            angularWait();
        }
    };

    this.patent = {
        advancedSearch: new patentAdvancedSearch("modal"),
        advancedSearchLink: $("a[ng-click='$ctrl.openGlobalSearchModal()']"),
        advancedSearchModal: $(".modal.is-active"),
        openAdvancedSearchModal: function () {
            var this_ = this;
            this_.advancedSearchModal.isDisplayed().then().catch(function () {
                this_.advancedSearchLink.click();
                angularWait();
            });
        }
    };
    
    


    // New simple search added for checking differnt combinational input
    this.simpleSearch = {
        patentTextArea: $(".search-patents .search-text"),
        searchBtn: $(".row.search-patents .button"),
        noPatentMatchText: $(".ng-invalid-pat-number-check .rpx-alert"),
        search: function (searchTerm) {
            this.patentTextArea.clear();
            this.patentTextArea.sendKeys(searchTerm);
            this.searchBtn.click();
            angularWait();
        },
        enterSearchTerm: function (searchTerm) {
            // this.patentTextArea.clear();
            this.patentTextArea.sendKeys(searchTerm);
            this.patentTextArea.sendKeys(protractor.Key.ENTER);
            angularWait();
        },
        getErrorText: function () {
            var deferred = protractor.promise.defer();
            this.noPatentMatchText.getText().then(function (text) {
                text = text.trim();
                deferred.fulfill(text);
            });
            return deferred.promise;
        }
    };

    this.recentActivity = {
        panel: $(".grid-cell:nth-of-type(3)"),
        content: $(".history-container a")
    };
};
HomePage.prototype = basePage;
module.exports = new HomePage();