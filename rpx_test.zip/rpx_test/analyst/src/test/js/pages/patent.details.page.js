var basePage = require("./base.page"),
    patentHeader = require("./patent.header"),
    patentClaims = require("./patent.claims");

var panel = require("../components/panel"),
    grid = require("../components/grid"),
    tabs = require("../components/tabs");

var PatentDetailsPage = function () {
    this.url = {
        main: "/patent/{{id}}",
        sub: "/claim/{{id}}"
    };

    this.info = {
        title: $(".patent-info-container h2"),
        starValue: element(by.css(".star-container span:not([value])")),
        patentDetailsPanel: new panel(element(by.css(".patent-info .rpx-table tr")),{
            label: element(by.css("td:first-child")),
            value: element(by.css("td:last-child "))
        }),
        citation: {
            link: $("a[ng-click='openCitationsModal()'] i"),
            chart: $(".citation-timeline"),
            closeModal: function() {
                var closeElement = $(".reveal-modal[style*='visible'] .fa-close");
                return click(closeElement).ifDisplayed();
            }
        },
        family: {
            link: $("td[ng-show='patent']>a>i"),
            chart: $("#patent-family-chart"),
            closeModal: function () {
                var closeElement = $(".modal.is-active .close-button");
                return click(closeElement).ifDisplayed();
            }
        },
        litigation: {
            link: element(by.xpath("//td[text()='Litigation:']/../td/a")),
            grid: new grid(element(by.css(".litigations-for-patent-grid")), {
                type: "subGrid"
            }),
            closeModal: function () {
                var closeElement = $(".reveal-modal[style*='visible'] .close-reveal-modal");
                return click(closeElement).ifDisplayed();
            }
        },
        timeLine: {
            link: $("a[ng-click='$ctrl.openAssignentModal()'] i"),
            chart: $("#patent-assignment-chart"),
            closeModal: function () {
                var closeElement = $(".assignment-dialog .close-reveal-modal");
                return click(closeElement).ifDisplayed();
            }
        },
        grid: new grid(element(by.css(".portfoliolist-for-patent .ui-grid")), {
            type: "default"
        })
    };

    this.patentTabs = new tabs(element(by.css(".single-patent-data dl")));
    
    this.metricsTab = {
        chart: $("#patent-metrics-chart")
    };
    this.similarityTab = {
        chart: $("#patent-similarity-chart")
    };
    this.priorArtTab = {
        secondaryTabs: new tabs(element(by.css(".patent-prioart-container dl")))
    };
    this.patentClaimTabs = new tabs(element(by.css(".claim-list-tabs dl")));
    this.patentClaimTabsRightScrollArrow = $(".scrolling-tabs.nav-buttons.nav-buttons-right");
    this.patentClaimTabsLeftScrollArrow = $(".scrolling-tabs.nav-buttons.nav-buttons-right");
    
    this.abstractTab = {
        abstractContent: $(".spec-abstract-body")
    };
    this.imagesTab = {
        imageThumbs: $(".fotorama__nav--thumbs"),
        loadedImage: $(".fotorama__loaded--img.fotorama__active"),
        nextImagePointer: $(".fotorama__arr--next"),
        prevImagePointer: $(".fotorama__arr--prev")
    }
    this.familyTab = {
        familySankey: $(".family-sankey-container"),
        familyHeader: element(by.xpath("//div[contains(@class,'family-sankey-container')]/preceding-sibling::h4")),
    };
    this.citationsTab = {
      patentCitationButton:element(by.xpath("//ul[contains(@class,'citation-buttons')]//a[text()='Patent Citations']")),
      familyReferencesButton: element(by.xpath("//ul[contains(@class,'citation-buttons')]//a[text()='Family References']")),
      citationTimeline:$(".citation-timeline"),
      citationTimelineFiltersGrid:$(".citation-timeline-filters")
    };
    this.assignmentsTab = {
        timelineTopGraph:$("#timelineTop"),
        assignmentChart:$("#timelineTop"),
        timelineBottomGraph:$("#timelineBottom"),
        tableIcon: $(".fa-table"),
        graphIcon: $(".fa-sitemap")
    };
    this.transactionsTab = {
        flexrowFilter: $(".rpx-flex-row"),
        transactionsTableHeader:$(".transactions-table.header")
    };
    this.patentHeader = patentHeader;
    this.patentClaims = patentClaims;
};
PatentDetailsPage.prototype = basePage;
module.exports = new PatentDetailsPage();