var element_ = require('../root/element');

var BasePage = function() {
    this.url = "/";

    this.at = function() {
        angularWait();
    };
};
BasePage.prototype = new element_();
module.exports = new BasePage();