

var basePage = require("../pages/base.page");

var tabs = require("../components/tabs"),
    actionSheet = require("../components/action.sheet"),
    checkBox = require("../components/checkbox"),
    searchSelect = require("../components/search.select"),
    autoSuggest = require("../components/autosuggest"),
    tags = require("../components/tags"),
    starRatings = require("../components/star.rating");

var licenseeAnnotationModal = require("../pages/modals/licensees.annotation.modal"),
    theoryModal = require("../pages/modals/theory.modal"),
    bulkTaggingModal = require("../pages/modals/bulk.tagging.modal"),
    prcModal = require("../pages/modals/prc.modal");

var PatentClaims = function () {
    //TABS
    this.abstractClaimTabs = new tabs(element(by.css(".claim-list-tabs dl")));

    //ABSTRACT
    this.abstract = {
        content: $("p[ng-bind-html='abstract']")
    };

    //CLAIMS
    this.allClaims = $$(".claims-container div.claim-container.ng-scope");
    this.getTotalClaimsCount = function () {
        return this.allClaims.count();
    };
    this.claimHeader = function (index) {
        return this.allClaims.get(index).element(by.css("h4"))
    };
    this.claimText = function (index) {
        return this.allClaims.get(index).element(by.css("span[ng-bind-html='claim.claim_text']")).getText();
    };
    this.clickClaim = function (index) {
        this.allClaims.get(index).element(by.css("div[role='button']")).click();
        angularWait();
    };
    this.showDependentClaims = function (index) {
        this.allClaims.get(index).element(by.xpath("//section[contains(@class,'claims dependent')]//span[contains(text(), 'Show')]")).click();
        angularWait();
    };
    this.hideDependentClaims = function (index) {
        this.allClaims.get(index).element(by.xpath("//section[contains(@class,'claims dependent')]//span[contains(text(), 'Hide')]")).click().then(function () {
            angularWait();
        });
    };
    this.getDependentClaimsCount = function (index) {
        return this.allClaims.get(index).all(by.css(".claims.dependent div.panel:not([class*='ng-hide'])")).count();
    };

    //CLAIM DETAILS
    this.bulkTaggingModal = bulkTaggingModal,
    this.bulkTagIcon = $("a[ng-click='openBulkTagging()']");
    this.openBulkTagging = function () {
        this.bulkTagIcon.click();
        angularWait();
    };
    this.bulkTagModal = $(".bulk-tagging-modal");
    this.bulkTagModalClose = $(".bulk-tagging-modal .fa.fa-close");
    this.closeBulkTagging = function () {
        this.bulkTagModalClose.click();
        angularWait();
    };

    this.termDefinitions = $("div[ng-click='toggleTerms()'] i");
    this.patentReferenceIcon = $(".fa.fa-archive");
    this.highLights = $$(".highlight");
    this.selectedClaimNotes = $(".selected-claim-panel");
    this.breadcrumbs = $(".breadcrumbs");
    this.breadcrumbsPatNum = $("a[ng-click='patentEdit()']");
    this.breadcrumbsClaimNo = $("a[ng-click='dependentEdit()']");
    this.freeFormTagsSpan = element(by.xpath("//span[contains(@class ,'ui-select-match-item')]//span[contains(@class,'ng-binding')]"));
    this.priorityDate = {
        link: $("#claim-priority-date2 form span"),
        actionSheet: new actionSheet(element(by.css("#claim-priority-date2 .action-sheet")), {
            type: "date"
        }),
        edit: function (dateInput) {
            var this_ = this;
            this_.link.click();
            this_.actionSheet.editAndSave(undefined, dateInput);
        },
        enabled: $("span[class='ng-binding ng-scope'][zf-hard-toggle*='claim-priority-date']"),
        disabled: $("#claim-priority-date2 span[class*='rpx-read-only']")
    };

// Getting Claim notes for selected claim of a patent
    this.getClaimDescription = function(){
        
        var deferred = protractor.promise.defer();       
        var claimDescription;
        selectedClaimNotes = $(".selected-claim-panel");
        
        selectedClaimNotes.getText().then(function (text) {
            claimDescription = text.replace(/(\r\n|\n|\r)/gm, "");
            claimDescription = claimDescription.replace(" ","");
            deferred.fulfill(claimDescription);
        });
       return deferred.promise;
    };
    


    this.representativeClaim = new checkBox(element(by.css(".representative-row input:not([disabled])")));
    this.disabledRepClaim = $(".representative-row input[disabled]");
    this.stretchClaim = new checkBox(element(by.css(".stretch-row input:not([disabled])")));
    this.disabledStretchClaim = $(".stretch-row input[disabled='disabled']");
    this.keyPatentCheckBox = new checkBox(element(by.css(".key-patent-checkbox input")));

    this.freeFormAutoSuggest = new autoSuggest(element(by.css(".claim-rating freeform-tag-selector")), {
        input: element(by.css("input[type='search']")),
        options: element(by.css(".ui-select-choices-row")),
        
    });
    this.freeFormTags = new tags(element(by.css(".claim-rating freeform-tag-selector .ui-select-match")), {
        type: "default",
        close: element(by.css(".close"))
    });
    this.freeFormTagsCloseIcon = $(".claim-rating freeform-tag-selector .ui-select-match span[class*='close'][aria-hidden='false']")
    this.claimStarRating = new starRatings(element(by.css(".claim-rating-row .star-container .row")), {
        labels: element(by.css("label a")),
        ratings: element(by.css("span")),
        enabled: element(by.css("span[ng-if*='enablePatentEdits'][class='ng-scope ng-isolate-scope']")),
        disabled: element(by.css("span[ng-if*='enablePatentEdits'][class*='read-only']"))
    });

    this.claimTabs = new tabs(element(by.css(".claim-tabs dl")));
    this.claimsTechnologyTab = {
        searchSelect: new searchSelect(element(by.css(".tech_tags_header .ui-select-component")), {
            input: element(by.css("input[type='search']")),
            options: element(by.css(".ui-select-choices-row .option div")),
            close: element(by.css(".select-close"))
        }),
        tags: new tags($(".tech_tag_container.grid-container .tech_tags_body"), {
            type: "tech",
            rows: element(by.css(".tech_tags_body.row>div")),
            enabled: element(by.css(".tech_tags_rating[ng-if*='enableTechTagEdit']")),
            disabled: element(by.css(".rating-read-only"))
        }),
        noTags: $(".tech_tag_container .no_tech_tags"),
        createTemplateBtn: $(".tech_tags_footer a[ng-click='addTemplate()']"),
        applyToFamilyBtn: $(".tech_tags_footer a[ng-click='addToFamily()']")
    };
    this.claimsTheoryTab = {
        newBtn: $("button[ng-click*='openTheoryModal()']"),
        roleAuthRemoveIcon: $(".tag-remove .fa-times-circle"),
        multiAdd: function (multipleTheoriesData) {
            var this_ = this;
            for (var theoryData of multipleTheoriesData) {
                this_.add(theoryData);
            }
        },
        add: function (dataObj) {
            var deferred = protractor.promise.defer();
            var this_ = this;
            this_.newBtn.click().then(function () {
                angularWait();                
                deferred.fulfill(theoryModal.addTheory(dataObj));
            });

            return deferred.promise;
        },
        addWithError: function (dataObj) {
            var deferred = protractor.promise.defer();
            var errorObj = {}; var this_ = this;
            this_.newBtn.click().then(function () {
                angularWait();
                theoryModal.save(dataObj);
                $f(theoryModal.theoryNameError).getText().then(function (tnErrorTxt) {
                    errorObj["theoryName"] = tnErrorTxt;
                });
                $f(theoryModal.notesError).getText().then(function (nErrorTxt) {
                    errorObj["notes"] = nErrorTxt;
                });
                theoryModal.cancelBtn.click();
            }).then(function () {
                deferred.fulfill(errorObj);
            });

            return deferred.promise;
        },
        edit: function (name, dataObj) {
            var deferred = protractor.promise.defer();
            var this_ = this;

            this_.tags.clickTag(name).then(function () {
                deferred.fulfill(theoryModal.addTheory(dataObj));
            });

            return deferred.promise;
        },
        theoryModal: theoryModal,
        tags: new tags(element(by.css(".claim_theory_container")), {
            type: "default",
            rows: element(by.css("div[ng-repeat='theory in theories']"))
        }),
        noTags: $(".claim_theory_container .no-theories-found")
    };

    this.claimsPrcTab = {
        noTags: $(".prc-tab .column"),
        searchSelect: new searchSelect(element(by.css(".prc-select-container .ui-select-component")), {
            input: element(by.css("input[type='search']")),
            options: element(by.css(".ui-select-choices-row .option div")),
            close: element(by.css(".select-close"))
        }),
        tagsLink: $("a[ng-click='loadTags()']"),
        tags: new tags(element(by.css(".prcs-list")), {
            type: "prc",
            rows: element(by.css("div[ng-repeat='prc in prcs']")),
            enabled: $("input:not([disabled='disabled'])"),
            disabled: $("input[disabled='disabled']")
        }),
        prcModal: prcModal,
        applyToFamilyBtn: $(".prc-tab a[ng-click='addToFamily()']")
    };

    this.deleteAllTechnologyTags = function () {
        this.claimTabs.select("Technology");
        this.claimsTechnologyTab.tags.deleteAll();
    };
    this.deleteAllTheoryTags = function () {
        this.claimTabs.select("Theory");
        this.claimsTheoryTab.tags.deleteAll();
    };
    this.deleteAllPrcTags = function () {
        this.claimTabs.select("PRC");
        this.claimsPrcTab.tags.deleteAll();
    };
    this.createTechnologyTags = function (techTags) {
        this.deleteAllTechnologyTags();
        this.claimsTechnologyTab.searchSelect.select(techTags);
    };
    this.addTheory = function (theoryData) {
        this.deleteAllTheoryTags();
        this.claimsTheoryTab.add(theoryData);
    };
};
PatentClaims.prototype = basePage;
module.exports = new PatentClaims();