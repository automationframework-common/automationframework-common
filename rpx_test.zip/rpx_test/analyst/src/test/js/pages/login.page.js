var basePage = require('./base.page');

var menu = require("../pages/menu.partial");

var LoginPage = function () {
    this.loginLink = $("a[ng-click='open()']");

    this.loginForm = {
        modal: $(".login-modal"),
        userName: element(by.id("username")),
        password: element(by.id("user_password")),
        loginBtn: $("[value='Login Now']")
    };

    this.loginAsAdmin = function () {
        if (this.loginForm.userName.isPresent()) {
            this.loginForm.userName.sendKeys(browser.params.login.userName);
            this.loginForm.password.sendKeys(browser.params.login.password);
            this.loginForm.loginBtn.click();
            angularWait();
        }
    };

    this.login = function (role) {   
        console.log("Login as " + role);     
        if (this.loginForm.userName.isPresent()) {       
            this.loginForm.userName.sendKeys(browser.params.login[role].userName);
            this.loginForm.password.sendKeys(browser.params.login[role].password);
            this.loginForm.loginBtn.click();            
            angularWait();
        }
    };

    this.logOut = function () {
        menu.dropDown("Account").item("Log Out");
        angularWait();
    };
};
LoginPage.prototype = basePage;
module.exports = new LoginPage();