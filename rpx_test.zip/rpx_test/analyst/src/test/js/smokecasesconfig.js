exports.config = {
    require: require('./root/browser'),
    require: require('./root/page'),
    require: require('./root/element'),
    require: require('./helpers/report.helper'),
    require: require('./helpers/sort.helper'),

    framework: 'jasmine2',
//    baseUrl : "https://st-analyst.rpxcorp.com/#",

    params: {
        login: {
            displayName: "Sharmila",
            userName: 'srenganathan_c@rpxcorp.com',
            password: 'RPX@2015'
        },
        maxTimeOut: 5000
    },
    capabilities: {
        browserName: 'chrome',
        chromeOptions: {
            args: [
                '--start-maximized'
            ]
        },
        shardTestFiles: true        
    },
    directConnect: true,
    allScriptsTimeout: 120000,

    specs: [ 
         'specs/smoke.specs.js'       
         
    ],

    jasmineNodeOpts: {
        defaultTimeoutInterval: 300000
    },

    onPrepare: function () {
        var AllureReporter = require('jasmine-allure-reporter');
        jasmine.getEnv().addReporter(new AllureReporter({
            resultsDir: 'allure-results'
        }));
        jasmine.getEnv().afterEach(function(done){
            browser.takeScreenshot().then(function (png) {
                allure.createAttachment('Screenshot', function () {
                    return new Buffer(png, 'base64')
                }, 'image/png')();
                done();
            })
        });
    }
};