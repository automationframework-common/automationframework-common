var gulp = require('gulp');
var clean = require('gulp-clean');
var protractor = require('gulp-protractor').protractor;
var webDriverUpdate = require('gulp-protractor').webdriver_update_specific;
var argv = require('yargs').argv;

var baseUrl,
    dbConString;

var maxInstances = (argv.maxInstances === undefined) ? 5 : argv.maxInstances;
var env = (argv.env === undefined) ? 'qa' : argv.env;
var config = (argv.config === undefined) ? 'config.js' : argv.config;

if(argv.customUrl === undefined || argv.customUrl === true
    && argv.customDBConString === undefined || argv.customDBConString === true) {
    if(env === 'qa') {
        baseUrl = "https://qa-analyst.rpxcorp.com/#";
        // dbConString = "postgresql://pa_web:pa_web-qa@qa-coredb:5433/rpx";
        dbConString = 'postgresql://mmurugesan_c:B5OSYwUG@qa-cortaldb:5432/rpx';
    } else if(env === 'stage') {
        baseUrl = "https://st-analyst.rpxcorp.com/#";
        // dbConString = "postgresql://pa_web:pa_web-st@stage-coredb:5433/rpx"
        dbConString = 'postgresql://mmurugesan_c:B5OSYwUG@st-cortaldb:5433/rpx';
    }
} else {
    baseUrl = argv.customUrl;
    dbConString = argv.customDBConString;
}

gulp.task('clean', function () {
    return gulp.src('allure-results', {read: false})
        .pipe(clean());
});

gulp.task('webDriver_update', webDriverUpdate({
    browsers: ['ignore_ssl']
}));

gulp.task('protractor', ['webDriver_update'], function () {
    gulp.src([])
        .pipe(protractor({
            configFile: config,
            args: [
                '--baseUrl', baseUrl,
                '--params.dbConString', dbConString,
                '--capabilities.maxInstances', maxInstances
            ]
        }));
});

gulp.task('execute', ['clean', 'protractor']);
