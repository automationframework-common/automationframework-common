exports.config = {

    require: require('./root/browser'),
    require: require('./root/page'),
    require: require('./root/element'),
    require: require('./helpers/report.helper'),
    require: require('./helpers/sort.helper'),
    framework: 'jasmine2',

    params: {
        login: {
            rpxUser: {
                userName: 'srenganathan_c@rpxcorp.com',
                password: 'RPX@2015'
            },
            nonRpxUser: {
                userName: 'ana_google_user@rpxcorp.com',
                password: "Welcome1"
            }
        },
        maxTimeOut: 5000
    },
    capabilities: {
        browserName: 'chrome',
        chromeOptions: {
            args: [
                '--start-maximized'
            ]
        },
        shardTestFiles: true
    },
    baseUrl: "https://qa-analyst.rpxcorp.com/#",

    allScriptsTimeout: 120000,

    jasmineNodeOpts: {
        defaultTimeoutInterval: 300000
    },

    specs: ['specs/group.testing.specs.js'],
    directConnect: true,

    onPrepare: function () {
        var AllureReporter = require('jasmine-allure-reporter');
        jasmine.getEnv().addReporter(new AllureReporter({
            resultsDir: 'allure-results'
        }));
        jasmine.getEnv().afterEach(function(done){
            browser.takeScreenshot().then(function (png) {
                allure.createAttachment('Screenshot', function () {
                    return new Buffer(png, 'base64')
                }, 'image/png')();
                done();
            })
        });
    }
};