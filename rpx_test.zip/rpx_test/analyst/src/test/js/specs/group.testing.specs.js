//TODO POC and implement synchronised testing for different accounts and take data from db
var loginPage = require("../pages/login.page"),
    homePage = require("../pages/home.page"),
    patentDetails = require("../pages/patent.details.page"),
    patentHeader = require("../pages/patent.header"),
    patentClaims = require("../pages/patent.claims");

describe("RPX user - Non RPX user", function () {

    describe("From patent header", function () {
        var patentNo = "5393014",
            priorityDate = "12/12/2015",
            expiryDate = "12/12/2019",
            annotationsData = [
                { type: "Analysts Notes", value: "Test" },
                { type: "Comparables", value: "Test" },
                { type: "Enforcement Review", value: "Test" },
                { type: "File History Review", value: "Test" },
                { type: "Patent Summary", value: "Test" },
                { type: "SME Review", value: "Test" },
                { type: "Spec Support", value: "Test" },
                { type: "Priority Research", value: "Test" }
            ],
            licensee = "Alphabet Inc.";

        beforeAll(function () {
            loginAs("rpxUser");
            to(patentDetails, patentNo);
            patentHeaderPreActions(priorityDate, expiryDate, annotationsData, licensee);

            logOutAndLoginAs("nonRpxUser");
            to(patentDetails, patentNo);
        });

        afterAll(function () {
            loginPage.logOut();
        });

        it("sponsor's verified value should not be copied", function () {
            expect(patentHeader.sponsor.thumbsUp.isDisplayed()).toEqual(false);
        });

        it("inventor's verified value should not be copied", function () {
            expect(patentHeader.inventors.thumbsUpIcon(0).isDisplayed()).toEqual(false);
        });

        it("priority date value should be copied", function () {
            expect(patentHeader.priorityDate.link.getText()).toEqual(priorityDate);
        });

        it("priority date verified value should not be copied", function () {
            expect(patentHeader.priorityDate.notVerifiedIcon.isPresent()).toEqual(true);
        });

        it("expiry date value should be copied", function () {
            expect(patentHeader.expiryDate.link.getText()).toEqual(expiryDate);
        });

        it("expiry date verified value should not be copied", function () {
            expect(patentHeader.expiryDate.notVerifiedIcon.isPresent()).toEqual(true);
        });

        it("patent annotations should not be copied", function () {
            expect(patentHeader.noAnnotationsMsg.getText()).toEqual("No Patent Annotations.");
        });

        it("licensees should not be copied", function () {
            patentHeader.annotationTabs.select("Licensees");
            expect(patentHeader.noLicenseesMsg.getText()).toEqual("No Licensees Found.");
        });
    });

    describe("From patent claim", function () {
        var patentNo = "5393014",
            claimNo = "200855961",
            claimPriorityData = "12/12/2029", 
            freeFormTag = "TESLA TAG",
            claimRatingEdit = {
                "Literal Relevance": 3,
                "Relevant Companies": 2,
                "Priority:": 3,
                "Detection": 2,
                "Claim Simplicity": 1,
                "Importance": 2,
                "101 Eligibility": 3,
                "112 Description": 1,
                "112 Enablement": 2,
                "112 Indefiniteness": 1
            };

            var expRatings = {
                "LITERAL RELEVANCE": { actual: 3, max: '4' },
                "RELEVANT COMPANIES": { actual: 2, max: '3' },
                "PRIORITY": { actual: 3, max: '3' },
                "DETECTION": { actual: 2, max: '3' },
                "CLAIM SIMPLICITY": { actual: 1, max: '3' },
                "IMPORTANCE": { actual: 2, max: '3' },
                "101 ELIGIBILITY": { actual: 3, max: '3' },
                "112 DESCRIPTION": { actual: 1, max: '2' },
                "112 ENABLEMENT": { actual: 2, max: '2' },
                "112 INDEFINITENESS": { actual: 1, max: '2' }
            };

        beforeAll(function () {
            loginAs("rpxUser");
            to(patentDetails, [patentNo, claimNo]);
            patentClaimPreActions(claimPriorityData, freeFormTag, claimRatingEdit);

            logOutAndLoginAs("nonRpxUser");
            to(patentDetails, [patentNo, claimNo]);
        });

        afterAll(function () {
            loginPage.logOut();
        });

        it("priority date value should be copied", function () {
            expect(patentClaims.priorityDate.link.getText()).toEqual(claimPriorityData);
        });

        it("representative claim value should be copied", function () {
            expect(patentClaims.representativeClaim.isChecked()).toEqual(true);
        });

        it("stretch claim value should be copied", function () {
            expect(patentClaims.stretchClaim.isChecked()).toEqual(true);
        });

        it("free form tag value should be copied", function () {
            expect(patentClaims.freeFormTags.getTags()).toEqual([freeFormTag]);
        });

        it("star rating value should be copied", function () {
            expect(patentClaims.claimStarRating.getRatingsObject()).toEqual(expRatings);
        });
    });
});

var loginAs = function (user) {
    to(loginPage);
    loginPage.login(user);
};

var logOutAndLoginAs = function (user) {
    to(loginPage);
    loginPage.logOut();
    loginAs(user);
};

var patentHeaderPreActions = function (priorityEditData, expiryEditDate, annotationData, licensee) {
    //sponsor to strong
    patentHeader.sponsor.edit(true);
    //inventor to strong
    patentHeader.inventors.edit(0, true);
    //set priority date
    patentHeader.priorityDate.edit(undefined, priorityEditData);
    //priority date to verified
    patentHeader.priorityDate.edit(true);
    //set expiry date
    patentHeader.expiryDate.edit(undefined, expiryEditDate);
    //expiry date to verified
    patentHeader.expiryDate.edit(true);
    //set annotations
    setAnnotations(annotationData);
    //add licensee
    patentHeader.annotationTabs.select("Licensees");
    patentHeader.licensees.tags.deleteAll();
    patentHeader.licensees.searchSelect.select(licensee);
};

var setAnnotations = function (annotationData) {
    patentHeader.annotations.clearAll();

    for (annotationDataIndex in annotationData) {
        var data = annotationData[annotationDataIndex];
        patentHeader.annotations.save(data["type"], data["value"]);
    }
};

var patentClaimPreActions = function (claimPriorityDate, freeFormTag, claimRatingEdit) {
    //set priority date
    patentClaims.priorityDate.edit(claimPriorityDate);
    //set representative claim
    patentClaims.representativeClaim.check();
    //set stretch claim
    patentClaims.stretchClaim.check();

    //add free form tags
    patentClaims.freeFormTags.deleteAll();
    patentClaims.freeFormAutoSuggest.select(freeFormTag);

    //set star ratings
    patentClaims.claimStarRating.setStarRatings(claimRatingEdit);
};