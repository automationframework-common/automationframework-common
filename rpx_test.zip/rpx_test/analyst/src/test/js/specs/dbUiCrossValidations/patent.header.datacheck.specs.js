var loginPage = require("../../pages/login.page"),
    homePage = require("../../pages/home.page"),
    patentDetailsPage = require("../../pages/patent.details.page"),
    patentHeader = require("../../pages/patent.header");

var db = require("../../helpers/simpleQuery.helper");
var using = require('jasmine-data-provider');

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe("Patent details", function () {
    describe("header", function () {
        var patId = "5158899";
        var patNum = "US6418471B1";
        var queryString = "select p.title,p.issue_date from core.pats p where p.patnum ='US6418471B1'";
        beforeAll(function () {
            to(patentDetailsPage, patNum);
            db.connectToDb();
        });
        afterAll(function () {
            db.closeConnection();
        });
        beforeEach(function () {
            step("Connected to the DB");
            step("Navigate to patent details page: " + patNum);
        });

        it("should display the patent title", function () {
            // var expTitle = "Method for recording and reproducing the browsing activities of an individual web browser";

            step("Verify the patent title displayed");
            expect(patentHeader.patentTitle.getText()).toEqual(db.getSingleFieldValue(queryString, 'title'));
        });

        it("should have the assignees information displayed", function () {
            step("Verify the assignees information");
            expect(patentHeader.patentTitle.getText()).toEqual(db.getSingleFieldValue(queryString, 'issue_date'));
        });


    });
});