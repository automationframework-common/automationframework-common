// const HttpClient = require("protractor-http-client").HttpClient;
var request = require('request');
var using = require("jasmine-data-provider");

describe("Patent details", function () {
    // New test to check few solr responses
    var countrycode = [
    { cc: "doc_kind_code" }, { cc: "first_claim_text" }, { cc: "ipc_classes" },{ cc: "issue_date" }, { cc: "term_disclaimer" }, { cc: "title" }]//, { cc: "num_medium_iclaims" }, { cc: "num_method_iclaims" }, { cc: "num_other_iclaims" }, { cc: "num_process_iclaims" }, { cc: "num_program_iclaims" }, { cc: "num_system_iclaims" }, { cc: "preposition_score" }
    // { cc: "ptab_petitioner_alias_ids" }, { cc: "ptab_reference_details" }, { cc: "alice_words" }

    
    using(countrycode, function (data) {
        var param = data["cc"];
        fit('Should reach google.com', done => {
            var defer = protractor.promise.defer();
            var info;
            var field = 'grant_time_percentage';
            // var siteUrl = "http://qa-solr-cloud:8080/solr/analyst_pats_app/select?fl=patnum&indent=on&q=-is_analyzed:true%20and%20is_application:false&wt=json";
            var siteUrl = "http://stage-solr-cloud:8080/solr/analyst_pats_app/select?fq=country_code:US&fq="+param+":*&indent=on&q=patnum:/.{12}/&wt=json"
            request(siteUrl, function (error, response, body) {
                // console.log("siteurl: "+siteUrl);
                info = JSON.parse(body);
                console.log(param+":"+info.response.numFound); // Print the HTML for the Google homepage.
                done(); //informs runner that the asynchronous code has finished
            });

        });
    });


});