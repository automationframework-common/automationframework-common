var using = require("jasmine-data-provider");
var db = require("../helpers/db.helper");
var pg = require("pg");
var loginPage = require("../../../pages/login.page"),
    patentDetailsPage = require("../../../pages/patent.details.page"),

var tc;

(function () {
    tc = browser.params.tc; 
})();

describe("cortalDB: ", function () {
    // using(tc, function (tcData) {
    //     describe(tcData["schema"] + " : " + tcData["table"], function () {
    //         it(tcData["description"], function () {
    //             addArgument("query", tcData["query"]);                
    //             expect(db.execute(tcData["query"]).getRecordsCount()).toEqual(tcData["expected"]);
                
    //         });
    //     });
    // });
    it("Sample Query Execution",function(){
       
        var queryString = "select p.title,p.issue_date from core.pats p where p.patnum ='US8275359B2'"; 
        db.execute(queryString,'title').getValueforField();            
        expect(db.execute(queryString,'title').getValueforField()).toEqual("Wireless user based n");

        
        // expect(db.execute(tcData["query"]).getRecordsCount()).toEqual(tcData["expected"]);

    });
});