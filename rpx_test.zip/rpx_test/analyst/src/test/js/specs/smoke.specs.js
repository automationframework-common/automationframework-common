var loginPage = require("../pages/login.page"),
    homePage = require("../pages/home.page"),
    patentDetailsPage = require("../pages/patent.details.page"),
    portfolioListPage = require("../pages/portfolio.list.page"),
    portfolioDetailsPage = require("../pages/portfolio.details.page"),
    portfolioSearchResults = require("../pages/portfolio.results.page"),
    createPortfolioModal = require("../pages/create.portfolio.modal"),
    sfSummaryPage = require("../pages/salesforce.summary"),
    priorArtSearchPage = require("../pages/prior.art.search.page"),
    patentSearchResultsPage = require("../pages/search.results.page");

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe("Home page", function () {
    var portfolioId = "6001", portfolioName = "Elia Data - Lit";
    beforeEach(function () {
        to(homePage);
        step("Navigate to home page");
    });
    it('should have RPX Banner displayed', function () {
        step("Verify the RPX Banner displayed in the top nav");
        expect(homePage.bannerImage.isPresent()).toEqual(true);
    });

    it('should have user name displayed after login', function () {
        step("Verify the user name displayed in the top nav");
        expect(homePage.userLabel.getText()).toEqual('Welcome, Sharmila Renganathan');
    });

    it('should have Company name of the User displayed after login', function () {
        step("Verify the Company name of the User displayed in the top nav");
        expect(homePage.userCompanyLabel.getText()).toEqual('Company: RPX');
    });

    it('should have Dashboard Link displayed ', function () {
        step("Verify the Company name of the User displayed in the top nav");
        expect(homePage.dashBoardLink.isPresent()).toEqual(true);
    });

    it('should have Proper CopyRight Message at footer', function () {
        step("Verify the Copyright message in the footer ");
        expect(homePage.footerSection.getCopyRightText()).toEqual('Copyright © 2008-2019 RPX Corporation. All Rights Reserved.');
    });

    it('should have feedback link at footer', function () {
        step("Verify the Give Us Feedback link DISPLAYED in the footer ");
        expect(homePage.footerSection.feedBackLink.isPresent()).toEqual(true);
    });

        it("should have Portfolio Actions and Patent Search sections displayed", function () {
        // to(homePage);
        expect(homePage.portfolioActions.viewAllPortfoliosBtn.isDisplayed()).toEqual(true);
        expect(homePage.patentSearch.searchBtn.isDisplayed()).toEqual(true);
    });

    it("should be able to perform portfolio search from home page", function () {
        var portfolioName = "Joao - Lit";
        // to(homePage);
        homePage.portfolioActions.openPortfolioAutoSuggest.select(portfolioName);
        at(portfolioDetailsPage);
        expect(portfolioDetailsPage.title.getText()).toEqual(portfolioName);
    });

    it("should be able to search patents from home page", function () {
        var patNum = "US 9,674,132 B1";
        // to(homePage);
        homePage.patentSearch.search(patNum);
        at(patentSearchResultsPage);
    });

    it("- pin portfolio: " + portfolioName + " and verify it displayed in pinned portfolios", function () {
        step("Navigate to " + portfolioName + " Portfolio details page");
        to(portfolioDetailsPage, portfolioId);
        step("Select Pin to Dashboard action in portfolio Details Page");
        portfolioDetailsPage.patentList.selectActionItem("Pin to Dashboard");
        step("Navigate to Home page again");
        to(homePage);
        step("verify that " + portfolioName + " is displayed in Pinned Portfolios Pane ");
        expect(homePage.pinned_Portfolio.isPortfolioPinned(portfolioName)).toEqual(true);
    });
    it("- Unpin portfolio: " + portfolioName + " and verify it is NOT Displayed in pinned portfolios", function () {
        step("Navigate to " + portfolioName + " Portfolio details page");
        to(portfolioDetailsPage, portfolioId);
        step("Select UnPin from Dashboard action in portfolio Details Page");
        portfolioDetailsPage.patentList.selectActionItem("Unpin from Dashboard");
        step("Navigate to Home page again");
        to(homePage);
        step("verify that " + portfolioName + " is NOT Displayed in Pinned Portfolios Pane ");

        expect(homePage.pinned_Portfolio.isPortfolioPinned(portfolioName)).toEqual(false);
    });

    it("should display no pinned portfolio when all pinned portfolios are removed", function () {
        step("Unpin all the pinned portfolios displayed at home page");
        homePage.pinned_Portfolio.removeAllPinnedPortfolios();
        step("verify that No Pinned Portfolio Msg should be displayed");
        expect(homePage.pinned_Portfolio.noPortfolioTextMessage.getText()).toEqual("No Pinned Portfolios");
    });

    it("should have recently accessed portfolio name in Recent_Portfolio Panel", function () {
        var searchTerm = "Pantech Bulk - OMA";

        step("Search in open portfolio with data: " + searchTerm);
        homePage.portfolioActions.openPortfolioAutoSuggest.select(searchTerm);
        at(portfolioDetailsPage);
        navigateBack();
        step("Verify that recently viewed portfolio is displayed in home page - recent activities");
        expect(homePage.recentActivity.content.getText()).toEqual(searchTerm);
    });
    it("should direct the users to search results on clicking 'View All Portfolios' button", function () {
        step("Click view all portfolios");
        homePage.portfolioActions.viewAllPortfolios();
        at(portfolioSearchResults);
        step("Verify the title from portfolio results page");
        expect(portfolioSearchResults.title.getText()).toEqual("Portfolios");
    }); 
    it("should display the US Publication Grants Section ", function () {
        step("verify that US Publications displayed is True");
        expect(homePage.uSPublicationsSection.publicationsPane.isPresent()).toEqual(true);

    });
    
});

describe("Portfolio details", function () {
    var portfolioId = "5818";
    beforeAll(function () {
        to(portfolioDetailsPage, portfolioId);
    });

    it("should have patent grid displayed", function () {
        expect(portfolioDetailsPage.patentList.grid.isDisplayed()).toEqual(true);
    });

    describe("Portfolio - Assets tab", function () {
        beforeAll(function () {
            portfolioDetailsPage.patentDataSubTabs.portfolio.select("Assets");
        });

        it("should display graph in Overview tab", function () {
            portfolioDetailsPage.patentDataTertirayNavs.assets.select("Overview");
            expect(portfolioDetailsPage.portfolioAssetsTab.overview.barChart.isDisplayed()).toEqual(true);
        });

        it("should display graph in Landscape tab", function () {
            portfolioDetailsPage.patentDataTertirayNavs.assets.select("Landscape");
            expect(portfolioDetailsPage.portfolioAssetsTab.landscape.highChart.isDisplayed()).toEqual(true);
        });

        it("should display graph in Clusters tab", function () {
            portfolioDetailsPage.patentDataTertirayNavs.assets.select("Clusters");
            expect(portfolioDetailsPage.portfolioAssetsTab.clusters.highChart.isDisplayed()).toEqual(true);
        });

        it("should display graph in TechTags tab", function () {
            portfolioDetailsPage.patentDataTertirayNavs.assets.select("Techtags");
            expect(portfolioDetailsPage.portfolioAssetsTab.techTags.highChart.isDisplayed()).toEqual(true);
        });

        it("should display graph in CPC tab", function () {
            portfolioDetailsPage.patentDataTertirayNavs.assets.select("CPC");
            expect(portfolioDetailsPage.portfolioAssetsTab.cpc.highChart.isDisplayed()).toEqual(true);
        });
    });

    describe("Portfolio - Summaries tab", function () {
        beforeAll(function () {
            portfolioDetailsPage.patentDataSubTabs.portfolio.select("Summaries");
        });

        it("should have data displayed in RPX tab", function () {
            portfolioDetailsPage.patentDataTertirayNavs.summaries.select("RPX");
            expect(portfolioDetailsPage.portfolioSummariesTab.rpxTab.salesForceSummaryLink.isDisplayed()).toEqual(true);
        });

        it("should have data displayed in deal data tab", function () {
            portfolioDetailsPage.patentDataTertirayNavs.summaries.select("Deal Data");
            expect(portfolioDetailsPage.portfolioSummariesTab.dealTab.dealDataItems.isDisplayed()).toEqual(true);
        });

        it("should have data displayed in key patents tab", function () {
            portfolioDetailsPage.patentDataTertirayNavs.summaries.select("Annotated Patents");
            expect(portfolioDetailsPage.portfolioSummariesTab.keyPatentsTab.keyPatents.isDisplayed()).toEqual(true);
        });
    });

    describe("Portfolio - Litigations tab", function () {
        beforeAll(function () {
            portfolioDetailsPage.patentDataSubTabs.portfolio.select("Litigations");
        });

        it("should have grid displayed in campaigns tab", function () {
            portfolioDetailsPage.patentDataTertirayNavs.litigations.select("Campaigns");
            expect(portfolioDetailsPage.portfolioLitigationsTab.campaignsTab.grid.isDisplayed()).toEqual(true);
        });

        it("should have grid displayed in defendants tab", function () {
            portfolioDetailsPage.patentDataTertirayNavs.litigations.select("Defendants");
            expect(portfolioDetailsPage.portfolioLitigationsTab.defendantsTab.grid.isDisplayed()).toEqual(true);
        });

        it("should have grid displayed in accused products tab", function () {
            portfolioDetailsPage.patentDataTertirayNavs.litigations.select("Accused Products");
            expect(portfolioDetailsPage.portfolioLitigationsTab.accusedProductsTab.grid.isDisplayed()).toEqual(true);
        });

        it("should have grid displayed in patent defendants tab", function () {
            portfolioDetailsPage.patentDataTertirayNavs.litigations.select("Patent Defendants");
            expect(portfolioDetailsPage.portfolioLitigationsTab.patDefendantsTab.grid.isDisplayed()).toEqual(true);
        });
    });

    describe("Portfolio - Petitions tab", function () {
        beforeAll(function () {
            portfolioDetailsPage.patentDataSubTabs.portfolio.select("Petitions");
        });

        it("should have grid displayed in petitions tab", function () {
            portfolioDetailsPage.patentDataTertirayNavs.petitions.select("Petitions");
            expect(portfolioDetailsPage.portfolioPetitionsTab.petitionsTab.grid.isDisplayed()).toEqual(true);
        });

        it("should have grid displayed in petitioners tab", function () {
            portfolioDetailsPage.patentDataTertirayNavs.petitions.select("Petitioners");
            expect(portfolioDetailsPage.portfolioPetitionsTab.petitionersTab.grid.isDisplayed()).toEqual(true);
        });

        it("should have grid displayed in patents tab", function () {
            portfolioDetailsPage.patentDataTertirayNavs.petitions.select("Patents");
            expect(portfolioDetailsPage.portfolioPetitionsTab.patentsTab.grid.isDisplayed()).toEqual(true);
        });
    });

    describe("Portfolio - Compare tabs", function () {
        beforeAll(function () {
            portfolioDetailsPage.patentDataSubTabs.portfolio.select("Compare");
        });

        it("should have portfolio selection drop downs displayed", function () {
            expect(portfolioDetailsPage.portfolioCompareTab.portfolioAAutoSuggest.isDisplayed()).toEqual(true);
            expect(portfolioDetailsPage.portfolioCompareTab.portfolioBAutoSuggest.isDisplayed()).toEqual(true);
        });
    });

    // Enable once time out issue is fixed
    // describe("Portfolio - Similarity tabs", function () {
    //     beforeAll(function () {
    //         portfolioDetailsPage.patentDataSubTabs.portfolio.select("Similarity");
    //     });

    //     it("should have graph displayed in similarity tab", function () {
    //         expect(portfolioDetailsPage.portfolioSimilarityTab.highChart.isDisplayed()).toEqual(true);
    //     });
    });

    describe("Patent", function () {
        beforeAll(function () {
            to(portfolioDetailsPage, "500395");
            portfolioDetailsPage.patentList.grid.clickCell(0, "Patent Number").then(function () {
                portfolioDetailsPage.patentDataTabs.select("Patent");
            });
        });

        it("should have grid displayed in the info tab", function () {
            portfolioDetailsPage.patentDataSubTabs.patent.select("Info");
            expect(portfolioDetailsPage.patentInfoTab.grid.isDisplayed()).toEqual(true);
        });

        it("should have chart displayed in the metrics tab", function () {
            portfolioDetailsPage.patentDataSubTabs.patent.select("Metrics");
            expect(portfolioDetailsPage.patentMetricsTab.chart.isDisplayed()).toEqual(true);
        });
    });
// });

describe("Patent details header", function () {
    beforeAll(function () {
        to(patentDetailsPage, "US7839729B2");
    });

    it("should have data displayed in the patent header", function () {
        expect(patentDetailsPage.patentHeader.patentInfo.getData()).not.toEqual({});
    });

    it("should have patent annotations data displayed", function () {
        expect(patentDetailsPage.patentHeader.annotations.getData()).not.toEqual({});
    });

    it("should have licensees data displayed", function () {
        patentDetailsPage.patentHeader.annotationTabs.select("Licensees");
        expect(patentDetailsPage.patentHeader.licensees.tags.isDisplayed()).toEqual(true);
    });
});

describe("Patent details claims", function () {
    beforeAll(function () {
        to(patentDetailsPage, ["US10003149B2", "1"]);
    });

    it("should have data displayed in the patent claims", function () {
        expect(patentDetailsPage.patentClaims.claimStarRating.isDisplayed()).toEqual(true);
    });

    it("should have tech tags data displayed", function () {
        patentDetailsPage.patentClaims.claimTabs.select("Technology");
        expect(patentDetailsPage.patentClaims.claimsTechnologyTab.tags.isDisplayed()).toEqual(true);
    });

    it("should have prc data displayed", function () {
        patentDetailsPage.patentClaims.claimTabs.select("PRC");
        expect(patentDetailsPage.patentClaims.claimsPrcTab.tags.isDisplayed()).toEqual(true);
    });
});

describe("Prior Art", function () {
    it("should have prior art grid displayed", function () {
        to(priorArtSearchPage);
        expect(priorArtSearchPage.priorArtGrid.isDisplayed()).toEqual(true);
    });
});

describe("SF", function () {
    beforeAll(function () {
        to(sfSummaryPage, "501569");
    });

it("should have other portfolios grid displayed", function () {
        expect(sfSummaryPage.otherPortfolios.grid.isDisplayed()).toEqual(true);
    });

    it("should have PRC graph displayed", function () {
        expect(sfSummaryPage.prc.highChart.isDisplayed()).toEqual(true);
    });

    it("should have Tech tags graph displayed", function () {
        expect(sfSummaryPage.techTags.highChart.isDisplayed()).toEqual(true);
    });

    it("should have Key patents displayed", function () {
        expect(sfSummaryPage.keyPatents.isDisplayed()).toEqual(true);
    });
});