var using = require("jasmine-data-provider"),
    authHelper = require("./../helpers/auth.helper");

var loginPage = require("../pages/login.page"),
    homePage = require("../pages/home.page"),
    portfolioDetails = require("../pages/portfolio.details.page"),
    patentDetails = require("../pages/patent.details.page"),
    patentHeader = require("../pages/patent.header"),
    patentClaims = require("../pages/patent.claims"),
    priorArtSearchPage = require("../pages/prior.art.search.page");

var role, tc;

(function () {
    role = browser.params.role;
    tc = browser.params.tc;
})();

describe(role, function () {
    beforeAll(function () {
        to(loginPage);
        loginPage.login(role);
    });

    afterAll(function () {
        to(loginPage);
        loginPage.logOut();
    });

    using(tc, function (tcData) {
        var condition = tcData[role];
        var page = tcData["page"];
        var description = page + " | " + authHelper.getTestCaseDescription(tcData["description"], condition);
        var pageObject = eval(page);
        var pageId = tcData["page_id"];
        var preActionsString = tcData["pre_actions"];
        var elementsString = tcData["elements"];
        var scenario = tcData["scenario"];

        it(description, function () {
            addArguments({
                "pageId": pageId,
                "preActions": preActionsString,
                "elements": elementsString,
                "expCondition": condition
            });
            feature(scenario);

            step("Navigate to " + page);
            var pageIds = ((pageId !== undefined) ? pageId.toString().split(",") : pageId);
            to(pageObject, pageIds);

            authHelper.preActions(preActionsString, pageObject);
            authHelper.assertCondition(elementsString, pageObject, authHelper.getExpectedBool(condition));
            authHelper.assertToBeDisplayedCondition(pageObject, condition);
        });
    });
});