var menu = require("../../../pages/menu.partial"),
    loginPage = require("../../../pages/login.page"),
    newNplReferenceModal = require("../../../pages/modals/new.npl.reference.modal"),
    priorArtSearchPage = require("../../../pages/prior.art.search.page");

var date = new Date();

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe("Prior Art Search", function () {

    var referenceTitleWithDate = "Auto NPL Reference " + date.getDate() + " " + date.getMilliseconds();

    var nplRefCreateData = {
        "Qualification Date": "12/12/2017",
        "Reference Title": referenceTitleWithDate,
        "Qualification Dt. Notes": "Auto Test Qualification Notes",
        "Reference Notes": "Auto Test Notes",
        "Author": "Auto Author",
        "Citation": "Auto Citation",
        "Tech Tags": "Software Network Management and Test",
        "Freeform Tags": "Auto Free Form Tag"
    };

    it("should list the newly created New NPL reference as first record", function () {
        menu.dropDown("Prior Art").item("New NPL Ref +");
        newNplReferenceModal.saveNPLReference(nplRefCreateData);
        to(priorArtSearchPage);
        expect(priorArtSearchPage.priorArtGrid.clickRowAndGetCellData(0, "Title"))
            .toEqual(nplRefCreateData["Reference Title"]);
    });

    var allNPLRefCreateOptions = {
        "Reference Type": "NPL",
        "Private": "No",
        "URL": "N/A",
        "File": "No Files Attached."
    };

    it("should display NPL reference details in Associations tab", function () {
        var expNPLRefData = Object.assign(nplRefCreateData, allNPLRefCreateOptions);
        delete expNPLRefData["Reference Title"];

        expect(priorArtSearchPage.associationsTab.summary.details.getData())
            .toEqual(expNPLRefData);
    });
});