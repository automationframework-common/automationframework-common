
var loginPage = require("../../pages/login.page.js"),
    homePage = require("../../pages/home.page.js"),
    portfolioDetailsPage = require("../../pages/portfolio.details.page"),
    portfolioSearchResults = require("../../pages/portfolio.results.page"),
    createPortfolioModal = require("../../pages/create.portfolio.modal"),
    searchResultsPage = require("../../pages/search.results.page");
var using = require('jasmine-data-provider');

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe("Simple-Search", function () {
    beforeEach(function () {
        to(homePage);
        step("Navigate to home page");

    });


    describe("Patnum,StripPatnum & combinations search", function () {


        var searchData = [
            { searchTerm: "US 6,515,603 B1", expResult: "US 6,515,603 B1", validFlag: 'true' },
            { searchTerm: "US6,515,603B1", expResult: "US 6,515,603 B1", validFlag: 'true' },
            { searchTerm: "US6515603B3", expResult: "", validFlag: 'NA' },
            { searchTerm: "US7777777", expResult: "US 7,777,777 B2", validFlag: 'true' },
            { searchTerm: "7777777B2", expResult: "US 7,777,777 B2", validFlag: 'true' },
            { searchTerm: "7777777", expResult: "US 7,777,777 B2", validFlag: 'true' },
            { searchTerm: "US77/77777B2", expResult: "US 7,916,648 B2", validFlag: 'false' },
            { searchTerm: "77/77777B2", expResult: "US 7,916,648 B2", validFlag: 'false' },
            { searchTerm: "US77/77777", expResult: "US 7,916,648 B2", validFlag: 'false' },
            { searchTerm: "77/77777", expResult: "US 7,916,648 B2", validFlag: 'false' },
            { searchTerm: "US77,77,77,7B2", expResult: "US 7,777,777 B2", validFlag: 'true' },
            { searchTerm: "77,77,77,7B2", expResult: "US 7,777,777 B2", validFlag: 'true' },
            { searchTerm: "US77,77,77,7", expResult: "US 7,777,777 B2", validFlag: 'true' },
            { searchTerm: "77,77,77,7", expResult: "US 7,777,777 B2", validFlag: 'true' },
            { searchTerm: "US77-77-77-7B2", expResult: "US 7,777,777 B2", validFlag: 'true' },
            { searchTerm: "77-77-77-7B2", expResult: "US 7,777,777 B2", validFlag: 'true' },
            { searchTerm: "US77-77-77-7", expResult: "US 7,777,777 B2", validFlag: 'true' },
            { searchTerm: "77-77-77-7", expResult: "US 7,777,777 B2", validFlag: 'true' }

        ];
        using(searchData, function (data) {
            var searchTerm = data["searchTerm"], expResult = data["expResult"], validFlag = data["validFlag"];
            it("using patnum " + data["searchTerm"] + " ", function () {

                step("Search for patent number in simple search: " + searchTerm);
                if (validFlag=='true') {
                    homePage.simpleSearch.search(searchTerm);
                    step("Verify that search results page is displayed");
                    at(searchResultsPage);
                    expect(searchResultsPage.searchResultsGrid.isKeywordPresentInGrid(expResult)).toEqual(true);
                }
                if (validFlag == 'NA') {
                    homePage.simpleSearch.search(searchTerm);
                    step("Verify that search results page is displayed");
                    at(searchResultsPage);
                    expect(searchResultsPage.searchResultsGrid.getCountofPatentsinGrid()).toEqual('0 Patents');
                }
                if (validFlag =='false') {
                    step("Search for patent number in simple search with invalid data: " + searchTerm);
                    homePage.simpleSearch.enterSearchTerm(searchTerm);
                    step("Check that error message displayed as No Matching Patents");
                    expect(homePage.simpleSearch.getErrorText()).toEqual("No Matching Patents")
                }
            });
        });
    });


    describe("AppCountryCodes & combinations search", function () {


        var searchData = [
            { searchTerm: "US10424310", expResult: "US 7,777,777 B2", validFlag: 'NA' },
            { searchTerm: "10424310", expResult: "US 7,777,777 B2", validFlag: 'NA' },
            { searchTerm: "US10,424310", expResult: "US 7,777,777 B2", validFlag: 'NA' },
            { searchTerm: "10,424310", expResult: "US 7,777,777 B2", validFlag: 'NA' },
            { searchTerm: "US10,42,43,10", expResult: "US 7,777,777 B2", validFlag: 'NA' },
            { searchTerm: "10,42,43,10", expResult: "US 7,777,777 B2", validFlag: 'NA' },
            { searchTerm: "US10-42-43-10", expResult: "US 7,777,777 B2", validFlag: 'NA' },
            { searchTerm: "10-42-43-10", expResult: "US 7,777,777 B2", validFlag: 'NA' },
            { searchTerm: "US10/424310", expResult: "US 7,777,777 B2", validFlag: 'NA' },
            { searchTerm: "10/424310", expResult: "US 7,777,777 B2", validFlag: 'NA' },
            { searchTerm: "US104/24310", expResult: "US 7,777,777 B2", validFlag: 'false' },
            { searchTerm: "10424/310", expResult: "US 7,777,777 B2", validFlag: 'false' },
            { searchTerm: "US04/561523", expResult: "US 3,457,470 A1", validFlag: 'NA' }

        ];
        using(searchData, function (data) {
            var searchTerm = data["searchTerm"], expResult = data["expResult"], validFlag = data["validFlag"];
            it("using AppCountryCode " + data["searchTerm"] + " ", function () {

                step("Search for AppCountryCode in simple search: " + searchTerm);
                if (validFlag=='true') {
                    homePage.simpleSearch.search(searchTerm);
                    step("Verify that search results page is displayed");
                    at(searchResultsPage);
                    expect(searchResultsPage.searchResultsGrid.isKeywordPresentInGrid(expResult)).toEqual(true);
                }
                if (validFlag == 'NA') {
                    homePage.simpleSearch.search(searchTerm);
                    step("Verify that search results page is displayed");
                    at(searchResultsPage);
                    expect(searchResultsPage.searchResultsGrid.getCountofPatentsinGrid()).toEqual('0 Patents');
                }
                if (validFlag =='false') {
                    step("Search for patent number in simple search with invalid data: " + searchTerm);
                    homePage.simpleSearch.enterSearchTerm(searchTerm);
                    step("Check that error message displayed as No Matching Patents");
                    expect(homePage.simpleSearch.getErrorText()).toEqual("No Matching Patents")
                }
            });
        });
    });


    describe("Application-number & combinations search", function () {


        var searchData = [
            { searchTerm: "US20030202112A1", expResult: "US 20030202112 A1", validFlag:'true' },
            { searchTerm: "20030202112A1", expResult: "US 20030202112 A1", validFlag: 'true' },
            { searchTerm: "US20030202112", expResult: "US 20030202112 A1", validFlag: 'true' },
            { searchTerm: "20030202112", expResult: "US 20030202112 A1", validFlag: 'true' },
            { searchTerm: "US20/030202112A1", expResult: "US 20030202112 A1", validFlag: 'false' },
            { searchTerm: "20/030202112A1", expResult: "US 20030202112 A1", validFlag: 'false' },
            { searchTerm: "US20/030202112", expResult: "US 20030202112 A1", validFlag: 'false' },
            { searchTerm: "20/030202112", expResult: "US 20030202112 A1", validFlag: 'false' },
            { searchTerm: "US2003/0202112A1", expResult: "US 20030202112 A1", validFlag: 'true' },
            { searchTerm: "2003/0202112A1", expResult: "US 20030202112 A1", validFlag: 'true' },
            { searchTerm: "US2003/0202112", expResult: "US 20030202112 A1", validFlag: 'true' },
            { searchTerm: "2003/0202112", expResult: "US 20030202112 A1", validFlag: 'true' },
            { searchTerm: "US2003,020,211,2A1", expResult: "US 20030202112 A1", validFlag: 'true' },
            { searchTerm: "2003,020,211,2A1", expResult: "US 20030202112 A1", validFlag: 'NA' },
            { searchTerm: "US2003,020,211,2", expResult: "US 20030202112 A1", validFlag: 'true' },
            { searchTerm: "2003,020,211,2", expResult: "US 20030202112 A1", validFlag: 'NA' },
            { searchTerm: "US2003-020-211-2A1", expResult: "US 20030202112 A1", validFlag: 'true' },
            { searchTerm: "2003-020-211-2A1", expResult: "US 20030202112 A1", validFlag: 'true' },
            { searchTerm: "US2003-020-211-2", expResult: "US 20030202112 A1", validFlag: 'true' },
            { searchTerm: "2003-020-211-2", expResult: "US 20030202112 A1", validFlag: 'true' },
            { searchTerm: "US 20030202112 A1", expResult: "US 20030202112 A1", validFlag: 'true' }

        ];
        using(searchData, function (data) {
            var searchTerm = data["searchTerm"], expResult = data["expResult"], validFlag = data["validFlag"];
            it("using Application-number " + data["searchTerm"] + " ", function () {

                step("Search for Application-number in simple search: " + searchTerm);
                if (validFlag=='true') {
                    homePage.simpleSearch.search(searchTerm);
                    step("Verify that search results page is displayed");
                    at(searchResultsPage);
                    expect(searchResultsPage.searchResultsGrid.isKeywordPresentInGrid(expResult)).toEqual(true);
                }
                if (validFlag == 'NA') {
                    homePage.simpleSearch.search(searchTerm);
                    step("Verify that search results page is displayed");
                    at(searchResultsPage);
                    expect(searchResultsPage.searchResultsGrid.getCountofPatentsinGrid()).toEqual('0 Patents');
                }
                if (validFlag =='false') {
                    step("Search for patent number in simple search with invalid data: " + searchTerm);
                    homePage.simpleSearch.enterSearchTerm(searchTerm);
                    step("Check that error message displayed as No Matching Patents");
                    expect(homePage.simpleSearch.getErrorText()).toEqual("No Matching Patents")
                }
            });
        });
    });


    describe("Matching Patent & combinations search", function () {


        var searchData = [
            { searchTerm: "US4,76,39-16A2", expResult: "US 4,763,916 A1", validFlag: 'NA' },
            { searchTerm: "US7-27-56,50,B2", expResult: "US 7,275,650 B1", validFlag: 'NA' },
            { searchTerm: "U-SR,E1-15-50,E-0", expResult: "US 20030202112 A1", validFlag: 'NA' },
            { searchTerm: "US,H0,02-13-0H,0", expResult: "US 20030202112 A1", validFlag: 'NA' },
            { searchTerm: "US,T9,58-00,1I-2", expResult: "US 20030202112 A1", validFlag: 'NA' },
            { searchTerm: "US-PP-04,52-3P,0", expResult: "US 20030202112 A1", validFlag: 'NA' },
            { searchTerm: "U-SPP,12,04-7P-1", expResult: "US PP12047 P2", validFlag: 'NA' },
            { searchTerm: "US-P-P13,68,5P2", expResult: "US PP13685 P3", validFlag: 'NA' },
            { searchTerm: "US-D2-427-71S,0", expResult: "US 20030202112 A1", validFlag: 'true' },
            { searchTerm: "U,S6-69,67-67-W1", expResult: "US 20030202112 A1", validFlag: 'NA' }

        ];
        using(searchData, function (data) {
            var searchTerm = data["searchTerm"], expResult = data["expResult"], validFlag = data["validFlag"];
            it("using Matching Patent " + data["searchTerm"] + " ", function () {

                step("Search for Matching Patent in simple search: " + searchTerm);
                if (validFlag=='true') {
                    homePage.simpleSearch.search(searchTerm);
                    step("Verify that search results page is displayed");
                    at(searchResultsPage);
                    expect(searchResultsPage.searchResultsGrid.isKeywordPresentInGrid(expResult)).toEqual(true);
                }
                if (validFlag == 'NA') {
                    homePage.simpleSearch.search(searchTerm);
                    step("Verify that search results page is displayed");
                    at(searchResultsPage);
                    expect(searchResultsPage.searchResultsGrid.getCountofPatentsinGrid()).toEqual('0 Patents');
                }
                if (validFlag =='false') {
                    step("Search for patent number in simple search with invalid data: " + searchTerm);
                    homePage.simpleSearch.enterSearchTerm(searchTerm);
                    step("Check that error message displayed as No Matching Patents");
                    expect(homePage.simpleSearch.getErrorText()).toEqual("No Matching Patents")
                }
            });
        });
    });


    // Matching-application combination cases
    describe("Matching application & combinations search", function () {


        var searchData = [
            { searchTerm: "US2016/01,282-50P0", expResult: "US 4,763,916 A1", validFlag: 'false' },
            { searchTerm: "US2,015/024-41,35-A0", expResult: "US 7,275,650 B1", validFlag: 'false' },
            { searchTerm: "U-S20,16/01,26-67,5A-1", expResult: "US 20160126675 A2", validFlag: 'NA' },
            { searchTerm: "US20-16/01,20-33,5A-2", expResult: "US 20160120335 A9", validFlag: 'NA' }

        ];
        using(searchData, function (data) {
            var searchTerm = data["searchTerm"], expResult = data["expResult"], validFlag = data["validFlag"];
            it("using Matching application " + data["searchTerm"] + " ", function () {

                step("Search for Matching application in simple search: " + searchTerm);
                if (validFlag=='true') {
                    homePage.simpleSearch.search(searchTerm);
                    step("Verify that search results page is displayed");
                    at(searchResultsPage);
                    expect(searchResultsPage.searchResultsGrid.isKeywordPresentInGrid(expResult)).toEqual(true);
                }
                if (validFlag == 'NA') {
                    homePage.simpleSearch.search(searchTerm);
                    step("Verify that search results page is displayed");
                    at(searchResultsPage);
                    expect(searchResultsPage.searchResultsGrid.getCountofPatentsinGrid()).toEqual('0 Patents');
                }
                if (validFlag =='false') {
                    step("Search for patent number in simple search with invalid data: " + searchTerm);
                    homePage.simpleSearch.enterSearchTerm(searchTerm);
                    step("Check that error message displayed as No Matching Patents");
                    expect(homePage.simpleSearch.getErrorText()).toEqual("No Matching Patents")
                }
            });
        });
    });

    // Multi line input
    describe("Matching application & combinations search", function () {
        it("using Matching application ", function () {
            var multipleDataInput = ["US 6,515,603 B1","US20030202112A1"];
            var multipleDataOutput = ["US 6,515,603 B1","US 20030202112 A1"];
            step("Verify search with mulitple keyword input");
            step("Enter a Patent number and new line break");
            homePage.simpleSearch.enterSearchTerm(multipleDataInput[0]);
            step("Enter a AppCountrycode number and new line break");
            homePage.simpleSearch.enterSearchTerm(multipleDataInput[1]);
            step("Click the search button");
            homePage.simpleSearch.searchBtn.click();
            angularWait();

            at(searchResultsPage);
            step("Verify that search results page contains expected Patent Number" + multipleDataOutput[0]);
            expect(searchResultsPage.searchResultsGrid.isKeywordPresentInGrid(multipleDataOutput[0])).toEqual(true);
            step("Verify that search results page contains expected AppCountrycode Number" + multipleDataOutput[1]);
            expect(searchResultsPage.searchResultsGrid.isKeywordPresentInGrid(multipleDataOutput[1])).toEqual(true);
            
        });

    });


});

