var loginPage = require("../../../pages/login.page"),
    portfolioDetailsPage = require("../../../pages/portfolio.details.page");

beforeAll(function () {
   to(loginPage);
   loginPage.loginAsAdmin();
});

var portfolioId = "501036";
var portfolioName = "Anza Technology - Lit";
describe("Portfolio details", function () {
    beforeAll(function () {
        to(portfolioDetailsPage, portfolioId);
    });
    beforeEach(function () {
        step("Login and navigate to portfolio details");
    });

    describe("Compare tab", function () {
        beforeAll(function () {
            portfolioDetailsPage.patentDataSubTabs.portfolio.select("Compare");
        });
        beforeEach(function () {
            step("Click on Compare tab");
        });

        it("should display the current portfolio name by default in portfolio A auto suggest", function () {
            step("Verify the default option selected in portfolio A auto suggest");
            expect(portfolioDetailsPage.portfolioCompareTab.portfolioAAutoSuggest.getSelectedData())
                .toEqual(portfolioName);
        });

        var searchTermForPortfolioA = "Google Fuel Cell - OMA";
        it("should be able to select different option from portfolio A auto suggest", function () {
            step("Search and select " + searchTermForPortfolioA + " from portfolio A auto suggest");
            portfolioDetailsPage.portfolioCompareTab.portfolioAAutoSuggest.select(searchTermForPortfolioA);
            step("Verify that selected value is displayed in portfolio A auto suggest");
            expect(portfolioDetailsPage.portfolioCompareTab.portfolioAAutoSuggest.getSelectedData())
                .toEqual(searchTermForPortfolioA);
        });
// modifying this test to compare the default portfolio with other portfolio
        var searchTermForPortfolioB = "Google dMarc - OMA";
        it("should display patentsCountOverTime and cluster filter on valid compare", function () {
            // step("Search and select " + portfolioName + " from portfolio A auto suggest");
            // portfolioDetailsPage.portfolioCompareTab.portfolioAAutoSuggest.select(portfolioName);
            step("Portfolio "+portfolioName+" selected by default on Portfolia A auto Suggest");
            step("Search and select " + searchTermForPortfolioB + " from portfolio B auto suggest");
            portfolioDetailsPage.portfolioCompareTab.portfolioBAutoSuggest.select(searchTermForPortfolioB);
            angularWait();
            step("Verify that Cluster Filter and Patents Count Overtime high charts are displayed");
            expect(portfolioDetailsPage.portfolioCompareTab.clusterFilterHightChart.isDisplayed())
                .toEqual(true, "Cluster Filter high chart is not displayed");
            expect(portfolioDetailsPage.portfolioCompareTab.patentsCountHighChart.isDisplayed())
                .toEqual(true, "Patents count over time high chart is not displayed");
        });
    });
});