// var loginPage = require("../../../pages/login.page"),
//     portfolioDetailsPage = require("../../../pages/portfolio.details.page");

// var using = require('jasmine-data-provider');

// beforeAll(function () {
//     to(loginPage);
//     loginPage.loginAsAdmin();
// });

// var portfolioId = "500802";
// var initialPatentCount = "972 Patents";
// describe("Portfolio details - Patents list filter", function () {
//     beforeAll(function () {
//         to(portfolioDetailsPage, portfolioId);
//     });
//     beforeEach(function () {
//         addArgument("Portfolio id", portfolioId);
//         step("Navigate to portfolio details page");
//         step("Click on filter icon from the grid to open the modal");
//         portfolioDetailsPage.patentList.openFilterSlide();
//         portfolioDetailsPage.patentList.filterSearch.deleteAllRows();

//     });

//     var facetCustomSearchData = [
//         { filterName: "Plaintiff", searchTerm: "PanOptis", patentCount: "23 Patents" },
//         { filterName: "Defendant", searchTerm: "Apple", patentCount: "12 Patents" },
//         { filterName: "Campaign", searchTerm: "Openwave Systems", patentCount: "7 Patents" },
//         { filterName: "Sponsoring Entity", searchTerm: "Phone", patentCount: "13 Patents" },
//         { filterName: "Sub Cluster", searchTerm: "base station", patentCount: "195 Patents" },
//         { filterName: "Super Cluster", searchTerm: "servers", patentCount: "37 Patents" }


//       /* Below Cases are Removed as these are not valid

//         { filterName: "Any Assignee", searchTerm: "Great Elm", patentCount: "188 Patents" },
//         { filterName: "Current Assignee", searchTerm: "Telefona", patentCount: "48 Patents" },     
//         // // This CPC mid level Search is not Facet Search
//         /* { filterName: "CPC Mid Level", searchTerm: "H04B", patentCount:"23 Patents" },
//         { filterName: "IPC Class", searchTerm: "455/436", patentCount: "14 Patents" },
//         // This PRC is also not Facet Search
//         { filterName: "PRC", searchTerm: "Amazon" },
//         { filterName: "Tech Tags", searchTerm: "Network", patentCount: "4 Patents" },
        
//         */
        
//     ];

//     using(facetCustomSearchData, function (data) {
//         var filterName = data["filterName"], searchTerm = data["searchTerm"], patentCount = data["patentCount"];

//         it("should filter the patents with " + filterName + " filter for data: " + searchTerm, function () {
//             step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
//             portfolioDetailsPage.patentList.filterSearch.selectfacetFilter(filterName, searchTerm);
//             // portfolioDetailsPage.patentList.filterSearch.facetRowSearch(filterName, searchTerm);
//             step("FilterTag :" + filterName + " should be displayed at top of Patent Grid");
//             expect(portfolioDetailsPage.patentList.filterTags.getText()).toEqual(filterName);
//         });
//     });
//     // Clearing filter tags should remove the filter selections in Filter Slide
//     using(facetCustomSearchData, function (data) {
//         var filterName = data["filterName"], searchTerm = data["searchTerm"], patentCount = data["patentCount"];

//         it("Verify that removing filtertag " + filterName + " clears the filter selection in filterslide", function () {
//             step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
//             portfolioDetailsPage.patentList.filterSearch.selectfacetFilter(filterName, searchTerm);
//             // portfolioDetailsPage.patentList.filterSearch.facetRowSearch(filterName, searchTerm);
//             step("FilterTag :" + filterName + " should be displayed at top of Patent Grid");
//             expect(portfolioDetailsPage.patentList.filterTags.getText()).toEqual(filterName);
//             step("Clear the Filter Tag and Open the Filter Slide");
//             portfolioDetailsPage.patentList.clearFilterTag(filterName);
//             // portfolioDetailsPage.patentList.openFilterSlide();
//             step("Verify that FacetSearch Row of " + filterName + " is not displayed");
//             expect(portfolioDetailsPage.patentList.isFacetSearchValuePresent(filterName)).toEqual(false);
            

//         });
//     });


//     // Clearing Filter tag and checking the results
//     using(facetCustomSearchData, function (data) {
//         var filterName = data["filterName"], searchTerm = data["searchTerm"], patentCount = data["patentCount"];

//         it("Verify the Patent count changes by applying and removing filter: " + filterName, function () {

//             step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
//             portfolioDetailsPage.patentList.filterSearch.selectfacetFilter(filterName, searchTerm);
//             step("Verify that results patent count should be: " + patentCount);
//             expect(portfolioDetailsPage.patentList.patentCountText.getText()).toEqual(patentCount);
//             step("Clear the filter tag: " + filterName);
//             portfolioDetailsPage.patentList.clearFilterTag(filterName);
//             step(" Verify that Patent count updated to its initial value: " + initialPatentCount);
//             expect(portfolioDetailsPage.patentList.patentCountText.getText()).toEqual(initialPatentCount);

//         });
//     });
//     // verify that clearing filter remove the tags added
//     using(facetCustomSearchData, function (data) {
//         var filterName = data["filterName"], searchTerm = data["searchTerm"], patentCount = data["patentCount"];
//         it("Verify the filter tags cleared by removing filter: " + filterName, function () {
//             step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
//             portfolioDetailsPage.patentList.filterSearch.selectfacetFilter(filterName, searchTerm);
//             step("Clear the filter tag: " + filterName);
//             portfolioDetailsPage.patentList.clearFilterTag(filterName);
//             step("verify that filter tag " + filterName + " is not displayed");
//             expect(portfolioDetailsPage.patentList.isFilterTagPresent(filterName)).toEqual(false);
//         });
//     });







//     var numericCustomSearchData = [
//         { filterName: "# of Claim Charts", type: "equals", value1: "2", patentCount: "0 Patents" },
//         { filterName: "# of Defendants", type: "equals", value1: "1", patentCount: "29 Patents" },
//         { filterName: "Analyst Sum", type: "equals", value1: "6", patentCount: "2 Patents" },
//         { filterName: "PRC Count", type: "equals", value1: "3", patentCount: "0 Patents" },
//         { filterName: "# of US Patents in Family", type: "equals", value1: "2", patentCount: "105 Patents" },
//         { filterName: "Foreign Counterparts", type: "equals", value1: "0.01", patentCount: "199 Patents" },
//         { filterName: "Open Continuances", type: "equals", value1: "4", patentCount: "70 Patents" },
//         { filterName: "Alice Words", type: "equals", value1: "1", patentCount: "468 Patents" },
//         { filterName: "Claim Originality", type: "equals", value1: "3", patentCount: "0 Patents" },
//         { filterName: "Defendant Score", type: "equals", value1: "0.01", patentCount: "8 Patents" },
//         { filterName: "Claims Length", type: "equals", value1: "0.25", patentCount: "5 Patents" },
//         { filterName: "Examination Thoroughness", type: "equals", value1: "0.25", patentCount: "6 Patents" },
//         { filterName: "Grant Time", type: "equals", value1: "2000", patentCount: "2 Patents" },
//         { filterName: "Limiting Language Score", type: "equals", value1: "1", patentCount: "241 Patents" },
//         { filterName: "Litigation Likelihood", type: "equals", value1: "1", patentCount: "18 Patents" },
//         { filterName: "Overall Score", type: "equals", value1: "2", patentCount: "1 Patent" },
//         { filterName: "Preposition Score", type: "equals", value1: "1", patentCount: "1 Patent" },
//         { filterName: "References - Backward", type: "equals", value1: "5", patentCount: "48 Patents" },
//         { filterName: "References - Forward", type: "equals", value1: "6", patentCount: "19 Patents" },
//         { filterName: "Shortest Claim Length", type: "equals", value1: "1", patentCount: "1 Patent" },
//         { filterName: "Citations-Backward", type: "equals", value1: "0.01", patentCount: "272 Patents" },
//         { filterName: "Citations-Forward", type: "equals", value1: "0.01", patentCount: "191 Patents" },
//         { filterName: "Citing Assignees", type: "equals", value1: "0.04", patentCount: "69 Patents" },
//         { filterName: "Citing Clusters", type: "equals", value1: "0.04", patentCount: "183 Patents" }
//     ];

//     using(numericCustomSearchData, function (data) {
//         var filterName = data["filterName"], searchType = data["type"], value1 = data["value1"], patentCount = data["patentCount"];
//         it("should filter patent results with " + filterName + " filter for data type: " + searchType, function () {
//             step("Add " + filterName + " row and select " + searchType + " from numeric row");
//             portfolioDetailsPage.patentList.filterSearch.selectNumericFilter(filterName, searchType, value1);
//             // portfolioDetailsPage.patentList.filterSearch.numericRowSearch(filterName, searchType, value1);
//             step("Verify that patent results with selected filters are displayed");
//             expect(portfolioDetailsPage.patentList.filterTags.getText()).toEqual(filterName);
//         });
//     });
//     // Clearing filter tags should remove the filter selections in Filter Slide
//     using(numericCustomSearchData, function (data) {
//         var filterName = data["filterName"], searchType = data["type"], value1 = data["value1"], patentCount = data["patentCount"];
//         it("Verify that removing filtertag" + filterName + " clears the filter selection in filterslide", function () {
//             step("Add " + filterName + " row and select " + searchType + " from numeric row");
//             portfolioDetailsPage.patentList.filterSearch.selectNumericFilter(filterName, searchType, value1);
//             // portfolioDetailsPage.patentList.filterSearch.numericRowSearch(filterName, searchType, value1);
//             step("FilterTag :" + filterName + " should be displayed at top of Patent Grid");
//             expect(portfolioDetailsPage.patentList.filterTags.getText()).toEqual(filterName);
//             step("Clear the Filter Tag and Open the Filter Slide");
//             portfolioDetailsPage.patentList.clearFilterTag(filterName);
//             portfolioDetailsPage.patentList.openFilterSlide();
//             step("Verify that NumericSearch Row of " + filterName + " is not displayed in filter slide");
//             expect(portfolioDetailsPage.patentList.isNumericSearchValuePresent(filterName)).toEqual(false);
//         });
//     });

//     // Clearing Filter tag and checking the results
//     using(numericCustomSearchData, function (data) {
//         var filterName = data["filterName"], searchType = data["type"], value1 = data["value1"], patentCount = data["patentCount"];

//         it("Verify the Patent count changes by applying and removing filter: " + filterName, function () {

//             step("Add " + filterName + " row and select " + searchType + " from numeric row");
//             portfolioDetailsPage.patentList.filterSearch.selectNumericFilter(filterName, searchType, value1);
//             step("Verify that results patent count should be: " + patentCount);
//             expect(portfolioDetailsPage.patentList.patentCountText.getText()).toEqual(patentCount);
//             step("Clear the filter tag: " + filterName);
//             portfolioDetailsPage.patentList.clearFilterTag(filterName);
//             step(" Verify that Patent count updated to its initial value: " + initialPatentCount);
//             expect(portfolioDetailsPage.patentList.patentCountText.getText()).toEqual(initialPatentCount);

//         });
//     });
//     // verify that clearing filter remove the tags added
//     using(numericCustomSearchData, function (data) {
//         var filterName = data["filterName"], searchType = data["type"], value1 = data["value1"], patentCount = data["patentCount"];
//         it("Verify the filter tags cleared by removing filter: " + filterName, function () {
//             step("Add " + filterName + " row and select " + searchType + " from numeric row");
//             portfolioDetailsPage.patentList.filterSearch.selectNumericFilter(filterName, searchType, value1);
//             step("Clear the filter tag: " + filterName);
//             portfolioDetailsPage.patentList.clearFilterTag(filterName);
//             step("verify that filter tag " + filterName + " is not displayed");
//             expect(portfolioDetailsPage.patentList.isFilterTagPresent(filterName)).toEqual(false);
//         });
//     });


//     var radioCustomSearchData = [
//         { filterName: "Has Representative Claim", option: "true", patentCount: "20 Patents" },
//         { filterName: "Is Analyzed", option: "true", patentCount: "190 Patents" },
//         { filterName: "Is Stretch Claim", option: "false", patentCount: "972 Patents" }
//     ];

//     using(radioCustomSearchData, function (data) {
//         var filterName = data["filterName"], searchOption = data["option"];
//         it("should filter patent results with " + filterName + " filter for option: " + searchOption, function () {
//             step("Add " + filterName + " row and select " + searchOption + " from radio group row");
//             // portfolioDetailsPage.patentList.filterSearch.radioRowSearch(filterName, searchOption);
//             portfolioDetailsPage.patentList.filterSearch.selectRadioFilter(filterName, searchOption);
//             step("Verify that patent results with selected filters are displayed");
//             expect(portfolioDetailsPage.patentList.filterTags.getText()).toEqual(filterName);
//         });
//     });
//     // Clearing filter tags should remove the filter selections in Filter Slide
//     using(radioCustomSearchData, function (data) {
//         var filterName = data["filterName"], searchOption = data["option"];
//         it("Verify that removing filtertag" + filterName + " clears the filter selection in filterslide", function () {
//             step("Add " + filterName + " row and select " + searchOption + " from radio group row");
//             // portfolioDetailsPage.patentList.filterSearch.radioRowSearch(filterName, searchOption);
//             portfolioDetailsPage.patentList.filterSearch.selectRadioFilter(filterName, searchOption);
//             step("FilterTag :" + filterName + " should be displayed at top of Patent Grid");
//             expect(portfolioDetailsPage.patentList.filterTags.getText()).toEqual(filterName);
//             step("Clear the Filter Tag and Open the Filter Slide");
//             portfolioDetailsPage.patentList.clearFilterTag(filterName);
//             portfolioDetailsPage.patentList.openFilterSlide();
//             step("Verify that RadioSearchRow of " + filterName + " is not displayed in filter slide");
//             expect(portfolioDetailsPage.patentList.isRadioSearchValuePresent(filterName)).toEqual(false);
//         });
//     });

//     // Clearing Filter tag and checking the results
//     using(radioCustomSearchData, function (data) {
//         var filterName = data["filterName"], searchOption = data["option"], patentCount = data["patentCount"];

//         it("Verify the Patent count changes by applying and removing filter: " + filterName, function () {

//             step("Add " + filterName + " row and select " + searchOption + " from radio group row");
//             // portfolioDetailsPage.patentList.filterSearch.radioRowSearch(filterName, searchOption);
//             portfolioDetailsPage.patentList.filterSearch.selectRadioFilter(filterName, searchOption);
//             step("Verify that results patent count should be: " + patentCount);
//             expect(portfolioDetailsPage.patentList.patentCountText.getText()).toEqual(patentCount);
//             step("Clear the filter tag: " + filterName);
//             portfolioDetailsPage.patentList.clearFilterTag(filterName);
//             step(" Verify that Patent count updated to its initial value: " + initialPatentCount);
//             expect(portfolioDetailsPage.patentList.patentCountText.getText()).toEqual(initialPatentCount);

//         });
//     });
//     // verify that clearing filter remove the tags added
//     using(radioCustomSearchData, function (data) {
//         var filterName = data["filterName"], searchOption = data["option"], patentCount = data["patentCount"];
//         it("Verify the filter tags cleared by removing filter: " + filterName, function () {
//             step("Add " + filterName + " row and select " + searchOption + " from radio group row");
//             // portfolioDetailsPage.patentList.filterSearch.radioRowSearch(filterName, searchOption);
//             portfolioDetailsPage.patentList.filterSearch.selectRadioFilter(filterName, searchOption);
//             step("Clear the filter tag: " + filterName);
//             portfolioDetailsPage.patentList.clearFilterTag(filterName);
//             step("verify that filter tag " + filterName + " is not displayed");
//             expect(portfolioDetailsPage.patentList.isFilterTagPresent(filterName)).toEqual(false);
//         });
//     });
//     var textRowCustomSearchData = [ 
//         { filterName: "Patent Family Name", searchTerm: "10/323", patentCount: "5 Patents" },
//         { filterName: "Title", searchTerm: "Mobile", patentCount: "125 Patents" }
//     ];

//     using(textRowCustomSearchData, function (data) {
//         var filterName = data["filterName"], searchTerm = data["searchTerm"], patentCount = data["patentCount"];
//         it("should filter patent results with " + filterName + " filter for data: " + searchTerm, function () {
//             step("Add " + filterName + " row and enter " + searchTerm + " from text row");
//             portfolioDetailsPage.patentList.filterSearch.textRowFilter(filterName, searchTerm);
//             step("Verify that patent results with selected filters are displayed");
//             expect(portfolioDetailsPage.patentList.filterTags.getText()).toEqual(filterName);
//         });
//     });
//     // Clearing filter tags should remove the filter selections in Filter Slide
//     using(textRowCustomSearchData, function (data) {
//         var filterName = data["filterName"], searchTerm = data["searchTerm"], patentCount = data["patentCount"];
//         it("Verify that removing filtertag" + filterName + " clears the filter selection in filterslide", function () {
//             step("Add " + filterName + " row and enter " + searchTerm + " from text row");
//             portfolioDetailsPage.patentList.filterSearch.textRowFilter(filterName, searchTerm);
//             step("FilterTag :" + filterName + " should be displayed at top of Patent Grid");
//             expect(portfolioDetailsPage.patentList.filterTags.getText()).toEqual(filterName);
//             step("Clear the Filter Tag and Open the Filter Slide");
//             portfolioDetailsPage.patentList.clearFilterTag(filterName);
//             portfolioDetailsPage.patentList.openFilterSlide();
//             step("Verify that RadioSearchRow of " + filterName + " is not displayed in filter slide");
//             expect(portfolioDetailsPage.patentList.isTextRowSearchValuePresent(filterName)).toEqual(false);
//         });
//     });
//         // Clearing Filter tag and checking the results
//         using(textRowCustomSearchData, function (data) {
//             var filterName = data["filterName"], searchTerm = data["searchTerm"], patentCount = data["patentCount"];

//             it("Verify the Patent count changes by applying and removing filter: " + filterName, function () {

//                 step("Add " + filterName + " row and enter " + searchTerm + " from text row");
//                 portfolioDetailsPage.patentList.filterSearch.textRowFilter(filterName, searchTerm);
//                 step("Verify that results patent count should be: " + patentCount);
//                 expect(portfolioDetailsPage.patentList.patentCountText.getText()).toEqual(patentCount);
//                 step("Clear the filter tag: " + filterName);
//                 portfolioDetailsPage.patentList.clearFilterTag(filterName);
//                 step(" Verify that Patent count updated to its initial value: " + initialPatentCount);
//                 expect(portfolioDetailsPage.patentList.patentCountText.getText()).toEqual(initialPatentCount);

//             });
//         });
//         // verify that clearing filter remove the tags added
//         using(textRowCustomSearchData, function (data) {
//             var filterName = data["filterName"], searchTerm = data["searchTerm"], patentCount = data["patentCount"];
//             it("Verify the filter tags cleared by removing filter: " + filterName, function () {
//                 step("Add " + filterName + " row and enter " + searchTerm + " from text row");
//                 portfolioDetailsPage.patentList.filterSearch.textRowFilter(filterName, searchTerm);
//                 step("Clear the filter tag: " + filterName);
//                 portfolioDetailsPage.patentList.clearFilterTag(filterName);
//                 step("verify that filter tag " + filterName + " is not displayed");
//                 expect(portfolioDetailsPage.patentList.isFilterTagPresent(filterName)).toEqual(false);
//             });
//         });

//         var dateRowCustomSearchData = [
//             { filterName: "Expiration Date", fromDate: "01/24/2017", toDate: "11/02/2017", patentCount: "96 Patents" },
//             { filterName: "Filing Date", fromDate: "04/01/2013", toDate: "11/14/2013", patentCount: "10 Patents" },
//             { filterName: "Issue Date", fromDate: "09/22/2015", toDate: "09/29/2016", patentCount: "10 Patents" },
//             { filterName: "Priority Date", fromDate: "05/26/2005", toDate: "06/17/2005", patentCount: "2 Patents" }
//         ];

//         using(dateRowCustomSearchData, function (data) {
//             var filterName = data["filterName"], fromDate = data["fromDate"], toDate = data["toDate"], patentCount = data["patentCount"];
//             it("should filter patent results with " + filterName + " filter between dates: " + fromDate + " and " + toDate, function () {
//                 step("Add " + filterName + " row and select date between " + fromDate + " and " + toDate + " from date row");
//                 portfolioDetailsPage.patentList.filterSearch.dateRowFilter(filterName, fromDate, toDate);
//                 step("Verify that patent results with selected filters are displayed");
//                 expect(portfolioDetailsPage.patentList.filterTags.getText()).toEqual(filterName);
//             });
//         });

//         // Clearing Filter tag and checking the results
//         using(dateRowCustomSearchData, function (data) {
//             var filterName = data["filterName"], fromDate = data["fromDate"], toDate = data["toDate"], patentCount = data["patentCount"];

//             it("Verify the Patent count changes by applying and removing filter: " + filterName, function () {

//                 step("Add " + filterName + " row and select date between " + fromDate + " and " + toDate + " from date row");
//                 portfolioDetailsPage.patentList.filterSearch.dateRowFilter(filterName, fromDate, toDate);
//                 step("Verify that results patent count should be: " + patentCount);
//                 expect(portfolioDetailsPage.patentList.patentCountText.getText()).toEqual(patentCount);
//                 step("Clear the filter tag: " + filterName);
//                 portfolioDetailsPage.patentList.clearFilterTag(filterName);
//                 step(" Verify that Patent count updated to its initial value: " + initialPatentCount);
//                 expect(portfolioDetailsPage.patentList.patentCountText.getText()).toEqual(initialPatentCount);

//             });
//         });
//         // verify that clearing filter remove the tags added
//         using(dateRowCustomSearchData, function (data) {
//             var filterName = data["filterName"], fromDate = data["fromDate"], toDate = data["toDate"], patentCount = data["patentCount"];
//             it("Verify the filter tags cleared by removing filter: " + filterName, function () {
//                 step("Add " + filterName + " row and select date between " + fromDate + " and " + toDate + " from date row");
//                 portfolioDetailsPage.patentList.filterSearch.dateRowFilter(filterName, fromDate, toDate);
//                 step("Clear the filter tag: " + filterName);
//                 portfolioDetailsPage.patentList.clearFilterTag(filterName);
//                 step("verify that filter tag " + filterName + " is not displayed");
//                 expect(portfolioDetailsPage.patentList.isFilterTagPresent(filterName)).toEqual(false);
//             });
//         });


//         it("should filter patent results with 'Patent Number' filter", function () {
//             var patNum = "9246844";
//             step("Search for patent number " + patNum + " from Patent Number text field");
//             portfolioDetailsPage.patentList.filterSearch.patentNumber.enterSearchTerm(patNum);
//             step("Click on done button from filter search");
//             portfolioDetailsPage.patentList.filterSearch.doneBtn.click();
//             angularWait();
//             step("Verify that patent results with selected filters are displayed");
//             expect(portfolioDetailsPage.patentList.filterTags.getText()).toEqual("Patent Number");
//         });
//         it("Verify the Patent count changes by applying and removing filter 'Patent Number'", function () {

//             var patNum = "9246844", patentCount = "1 Patent";
//             portfolioDetailsPage.patentList.clearAllLinkInFilterSlide.click();
//             step("Search for patent number " + patNum + " from Patent Number text field");
//             portfolioDetailsPage.patentList.filterSearch.patentNumber.enterSearchTerm(patNum);
//             step("Click on done button from filter search");
//             portfolioDetailsPage.patentList.filterSearch.doneBtn.click();
//             angularWait();
//             step("Verify that results patent count should be: " + patentCount);
//             expect(portfolioDetailsPage.patentList.patentCountText.getText()).toEqual(patentCount);
//             step("Clear the filter tag: " + "Patent Number");
//             portfolioDetailsPage.patentList.clearFilterTag("Patent Number");
//             step(" Verify that Patent count updated to its initial value: " + initialPatentCount);
//             expect(portfolioDetailsPage.patentList.patentCountText.getText()).toEqual(initialPatentCount);

//         });

//         it("Verify the filter tags cleared by removing filter: 'Patent Number'", function () {
//             var patNum = "9246844";
//             portfolioDetailsPage.patentList.clearAllLinkInFilterSlide.click();
//             step("Search for patent number " + patNum + " from Patent Number text field");
//             portfolioDetailsPage.patentList.filterSearch.patentNumber.enterSearchTerm(patNum);
//             step("Click on done button from filter search");
//             portfolioDetailsPage.patentList.filterSearch.doneBtn.click();
//             angularWait();
//             step("Clear the filter tag: " + "Patent Number");
//             portfolioDetailsPage.patentList.clearFilterTag("Patent Number");
//             step("verify that filter tag " + "Patent Number" + " is not displayed");
//             expect(portfolioDetailsPage.patentList.isFilterTagPresent("Patent Number")).toEqual(false);
//         });


//         var expCustomSearchFields = ['Filter Options', 'Plaintiff', 'Defendant', 'Campaign',
//             'Jurisdiction', '# of Claim Charts', '# of Defendants', 'Analyst Sum', 'Has Representative Claim', 'Is Analyzed',
//             'Is Stretch Claim', 'PRC', 'PRC Count', '# of US Patents in Family', 'Foreign Counterparts',
//             'Open Continuances', 'Patent Family Name', 'Alice Words', 'Citations-Backward', 'Citations-Forward',
//             'Citing Assignees', 'Citing Clusters', 'Claim Originality', 'Claims Length', 'Defendant Score',
//             'Examination Thoroughness', 'Limiting Language Score', 'Litigation Likelihood', 'Overall Score',
//             'Preposition Score', 'Any Assignee', 'Current Assignee', 'Sponsoring Entity', 'CPC Mid Level',
//             'CPC Top Level', 'Freeform Tags', 'IPC Class', 'Tech Tags', 'Topic Cluster', 'Expiration Date',
//             'Filing Date', 'Issue Date', 'Priority Date', 'Grant Time', 'Patent Status', 'References - Backward',
//             'References - Forward', 'Shortest Claim Length', 'Title'];

//         it("should have custom search options to select from", function () {
//             step("Verify the options available in custom search drop down");
//             expect(portfolioDetailsPage.patentList.filterSearch.customSearchDropDown.getAvailableOptions()).toEqual(expCustomSearchFields);
//         });
//     });