var loginPage = require("../../../pages/login.page"),
    homePage = require("../../../pages/home.page"),
    patentDetailsPage = require("../../../pages/patent.details.page"),
    patentHeader = require("../../../pages/patent.header");

var using = require('jasmine-data-provider');

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe("Patent details", function () {
    describe("header", function () {
        var patId = "5158899";
        var patNum = "US 6,418,471 B1";
        beforeAll(function () {
             // to(patentDetailsPage, patId);
          // Changing URL navigation using patnum for UserStory : 1720
          to(patentDetailsPage, patNum);
        });
        beforeEach(function () {            
            step("Navigate to patent details page: " + patNum);
        });

        it("should display patent number along with type", function () {
            step("Verify the patent number and type displayed");
            expect(patentHeader.patentNumber.getText()).toEqual("US 6,418,471 B1");
            expect(patentHeader.patentType.getText()).toEqual("Pat:");
        });

        it("should display the patent title", function () {
            var expTitle = "Method for recording and reproducing the browsing activities of an individual web browser";

            step("Verify the patent title displayed");
            expect(patentHeader.patentTitle.getText()).toEqual(expTitle);
        });

        it("should direct the users to google patents page on clicking google link", function () {
            step("Click on the google link");
            patentHeader.googleLink.click();
            step("Verify that google patent page is loaded in new tab");
            inNewWindow(function () {
                expect(getCurrentUrl()).toContain("patents.google.com/patent/US6418471");
            });
        });

        it("should direct the users to USPTO website on clicking uspto link", function () {
            step("Click on the USPTO link");
            patentHeader.usptoLink.click();
            step("Verify that uspto link is loaded in the same tab");
            inNewWindow(function () {
            expect(getCurrentUrl()).toContain("uspto.gov");
            // navigateBack();
            });
        });
// The test been commented since the Pair file wrapper icon is no longer available
        // it("should have Pair File Wrapper icon", function () {
        //     step("Verify that pair wrapper icon is displayed");
        //     expect(patentHeader.pairFileWrapperLink.isDisplayed())
        //         .toEqual(true, "Pair file wrapper icon is not displayed");
        // });

        describe("edit ", function () {
            var patentDataInEditModule;
            beforeAll(function () {
                patentHeader.patentInfo.getData().then(function (values) {                    
                    patentDataInEditModule = values;
                });
            });

            it("should highlight terms on clicking enable term definition icon", function () {
                step("Click on the Enable Term Definition icon");
                patentHeader.termDefinitions.click();
                angularWait();
                step("Verify that terms are highlighted");
                patentHeader.highLights.count().then(function (count) {
                    expect(count > 1).toEqual(true, "Terms are not highlighted after enable term definitions");
                });
            });

            it("should not highlight the terms on clicking disable term definition icon", function () {
                step("Click on the Disable Term Definition icon");
                patentHeader.termDefinitions.click();
                angularWait();
                step("Verify that terms are not highlighted");
                patentHeader.highLights.count().then(function (count) {
                    expect(count).toEqual(0, "Terms are not highlighted after enable term definitions");
                });
            });

            it("should have open patent reference dialog displayed", function () {
                step("Verify that Open Paten Reference dialog is displayed");
                expect(patentHeader.patentReferenceIcon.isDisplayed())
                    .toEqual(true, "Open Paten Reference dialog icon is not displayed");
            });

            it("should have stripped patent number in the breadcrumbs", function () {
                step("Verify that stripped patnum is displayed in the breadcrumb");
                expect(patentHeader.breadcrumbs.getText())
                    .toEqual("6,418,471");
            });

            var patInfoInHeader = [
                { label: "STATUS", value: "Expired Patent" },
                { label: "RELATION", value: "Continuation-in-part of US 5,951,643 A" },
                { label: "EXAMINER", value: "Harrell, Robert B.;  " },
                { label: "SPONSOR", value: "NCR CORPORATION ;  " },
                { label: "CPC CODES", value: "G06F11/3495;  G06F17/30873;  G06F2201/875;  G06F2216/15;  " },
                { label: "CLUSTER", value: "web application / server;  " },
                { label: "PRIORITY DATE", value: "10/06/1997" },
                { label: "EXPIRY DATE", value: "10/06/2017" },
                { label: "FILE DATE", value: "09/11/1998" },
                { label: "ISSUE DATE", value: "07/09/2002" }
            ];

            using(patInfoInHeader, function (data) {
                var label = data["label"], expValue = data["value"];
                it("should have '" + label + "' with data displayed", function () {
                    step("Verify the " + label + " displayed");
                    expect(patentDataInEditModule[label]).toEqual(expValue);
                });
            });

            it("should have the assignees information displayed", function () {
                step("Verify the assignees information");
                expect(patentHeader.assignees.getText())
                    .toEqual("NCR CORPORATION");
            });

            it("should have the Inventors information displayed", function () {
                step("Verify the inventors information");
                expect(patentHeader.inventors.links.getText())
                    .toEqual([ 'Ingrassia, Michael I. Jr. ,', 'Shelton, James A.' ] )
            });

            // Following sections are removed as per new user story. These are moved to separate tabs

            // it("should display citation graph in a modal from citation link", function () {
            //     step("Click on the citation graph icon");
            //     patentHeader.citations.link.click();
            //     angularWait();
            //     step("Verify that citation graph is displayed from modal");
            //     expect(patentHeader.citations.chart.isDisplayed()).toBe(true, "Citations graph is not displayed");
            //     patentHeader.citations.closeModal();
            // });

            // it("should display assignments data in a modal from assignments link", function () {
            //     step("Click on the assignments graph icon");
            //     patentHeader.timeLine.link.click();
            //     angularWait();
            //     step("Verify that assignments graph is displayed from modal");
            //     expect(patentHeader.timeLine.chart.isDisplayed()).toBe(true, "Assignments graph is not displayed");
            //     patentHeader.timeLine.closeModal();
            // });

            // it("should display family graph in a modal from family link", function () {
            //     step("Click on the family graph icon");
            //     patentHeader.family.link.click();
            //     angularWait();
            //     step("Verify that family graph is displayed from modal");
            //     expect(patentHeader.family.chart.isDisplayed()).toBe(true, "Family graph is not displayed");
            //     patentHeader.family.closeModal();
            //     browser.sleep(2000);
            // });
        });

        describe("without annotations", function () {
            var patWithoutAnnotation = "5845746";
            beforeAll(function () {
                to(patentDetailsPage, patWithoutAnnotation);
                patentHeader.annotationTabs.select("Annotations");
            });
            beforeEach(function () {
                step("Navigate to patent details without annotation: " + patWithoutAnnotation + " and click on annotations tab");
            });

            it("should display 'No Patent Annotations' message", function () {
                step("Verify the message in annotations tab");
                expect(patentHeader.annotations.getMessage())
                    .toEqual('No Patent Annotations.');
            });

            it("should have 8 annotation types displayed in the create dropdown", function () {
                step("Verify that all 8 annotation types are available in create dropdown");
                expect(patentHeader.annotations.getAvailableCreateOptions())
                    .toEqual(['Analysts Notes', 'Comparables', 'Enforcement Review', 'File History Review',
                        'Patent Summary', 'Priority Research', 'SME Review', 'Spec Support'])
            });
        });

        describe("with annotations", function () {
            var patWithAnnotations = "7392348",patNumWithAnnotations="US 4,444,444 A";
            beforeAll(function () {
                to(patentDetailsPage, patNumWithAnnotations);
                patentHeader.annotationTabs.select("Annotations");
            });
            beforeEach(function () {
                step("Navigate to patent details without annotation: " + patWithAnnotations + " and click on annotations tab");
            });

            it("should have create option disabled", function () {
                step("Verify that create option is disabled");
                expect(patentHeader.annotations.isCreateDisabled())
                    .toBe(true, 'Create option is not disabled');
            });

            it("should display hidden annotations count on deselecting filters", function () {
                step("Deselect all annotation from filter");
                patentHeader.annotations.deselectAllFilterOptions();
                step("Verify the message displayed after deselecting all options");
                expect(patentHeader.annotations.getMessage())
                    .toEqual('8 Patent Annotations Hidden.');
            });

            var annotationTypes = ['Analysts Notes', 'Comparables', 'Enforcement Review', 'File History Review',
                'Patent Summary', 'Priority Research', 'SME Review', 'Spec Support'];

            using(annotationTypes, function (data) {
                it("should display '" + data + "' annotation when '" + data + "' filter is selected", function () {
                    step("De select all options from the filter");
                    patentHeader.annotations.deselectAllFilterOptions();
                    step("Select option: " + data + "from the filter");
                    patentHeader.annotations.selectFilterOption(data);
                    step("Verify that selected option is displayed");
                    patentHeader.annotations.getData().then(function (resultData) {
                        expect(Object.keys(resultData).length).toEqual(1);
                        expect(resultData[data]).not.toBeNull();
                    });
                });
            });
        });

        describe("without licensees", function () {
            var patIdWithoutLicensees = "5845746";
            beforeAll(function () {
                to(patentDetailsPage, patIdWithoutLicensees);
                patentHeader.annotationTabs.select("Licensees");
            });
            beforeEach(function () {
                step("Navigate to patent details without licensees: " + patIdWithoutLicensees + " and click on licensees tab");
            });

            it("should have 'No Licensees Found.' message displayed", function () {
                step("Verify the no data found message displayed");
                expect(patentHeader.licensees.noLicenseesMsg.getText())
                    .toEqual('No Licensees Found.');
            });

            /*it("should have auto suggest options displayed based on search text", function () {
                var searchText = 'alphabet inc';
                step("Search and verify for "+ searchText + " in licensees auto suggest");
                expect(patentHeader.licensees.searchSelect.getAutoSuggestOptions(searchText))
                    .toContain(searchText);
            });*/
        });

        describe("with licensees", function () {
            var patIdWithLicensees = "5158899" , patNumWithLicensees = "US 6,418,471 B1";
            beforeAll(function () {
                to(patentDetailsPage, patNumWithLicensees);
                patentHeader.annotationTabs.select("Licensees");
            });
            beforeEach(function () {
                step("Navigate to patent details without licensees: " + patIdWithLicensees + " and click on licensees tab");
            });

            it("should have 'Apply to Family' button displayed", function () {
                step("Verify that apply to family button is displayed");
                expect(patentHeader.licensees.applyToFamilyBtn.isDisplayed())
                    .toEqual(true, "Apply to Family button is not displayed");
            });
        });
    });
});