var loginPage = require("../../../pages/login.page"),
    patentDetailsPage = require("../../../pages/patent.details.page");

var patId = "14842305";
var patNum = "US 9,160,547 B2";
beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();    
});

describe("Patent details claim", function () {    
    beforeEach(function () {
        // to(patentDetailsPage, patId);
        // Changing URL navigation using patnum for UserStory : 1720
        to(patentDetailsPage, patNum);
        step("Login and navigate to patent details page: " + patId);        
        patentDetailsPage.patentClaims.clickClaim(0);
        step("Click on the first claim from details section");
    });

    it("should be able to edit priority date", function () {
        var editDate = "05/21/2034";
        step("Click on the priority date and edit the date");
        patentDetailsPage.patentClaims.priorityDate.edit(editDate);
        step("Verify that edited priority date is displayed");
        expect(patentDetailsPage.patentClaims.priorityDate.link.getText())
            .toEqual(editDate);
    });

    it("should be able to select Representative Claim checkbox", function () {
        step("Un check Representative claim check box");
        patentDetailsPage.patentClaims.representativeClaim.unCheck();
        step("Check the Representative Claim check box");
        patentDetailsPage.patentClaims.representativeClaim.check();
        step("Verify that representative claim check box is selected");
        expect(patentDetailsPage.patentClaims.representativeClaim.isChecked())
            .toEqual(true, "Check box is not checked");
    });

    it("should be able to de select Representative Claim checkbox", function () {
        step("Check the Representative Claim check box");
        patentDetailsPage.patentClaims.representativeClaim.check();
        step("Un check Representative claim check box");
        patentDetailsPage.patentClaims.representativeClaim.unCheck();
        step("Verify that representative claim check box is not selected");
        expect(patentDetailsPage.patentClaims.representativeClaim.isChecked())
            .toEqual(false, "Check box is checked");
    });

    it("should be able to select Stretch Claim checkbox", function () {
        step("Un check stretch claim check box");
        patentDetailsPage.patentClaims.stretchClaim.unCheck();
        step("Check the stretch Claim check box");
        patentDetailsPage.patentClaims.stretchClaim.check();
        step("Verify that stretch claim check box is selected");
        expect(patentDetailsPage.patentClaims.stretchClaim.isChecked())
            .toEqual(true, "Check box is not checked");
    });

    it("should be able to de select Stretch Claim checkbox", function () {
        step("Check the stretch Claim check box");
        patentDetailsPage.patentClaims.stretchClaim.check();
        step("Un check stretch claim check box");
        patentDetailsPage.patentClaims.stretchClaim.unCheck();
        step("Verify that stretch claim check box is not selected");
        expect(patentDetailsPage.patentClaims.stretchClaim.isChecked())
            .toEqual(false, "Check box is checked");
    });

    var tagName = "Test Free Form Tag";
    it("should be able to select options from free form search select", function () {
        step("Delete all available free form tags");
        patentDetailsPage.patentClaims.freeFormTags.deleteAll();
        step("Add free form tag: " + tagName);
        patentDetailsPage.patentClaims.freeFormAutoSuggest.select(tagName);
        angularWait();
        step("Verify that added free form tag is displayed");
        // expect(patentDetailsPage.patentClaims.freeFormTags.getTags())
        //     .toEqual([tagName]);
        expect(patentDetailsPage.patentClaims.freeFormTagsSpan.getText())
        .toEqual(tagName);
    });

    it("should be able to delete all free form tags", function () {
        step("Delete all free form tags");
        patentDetailsPage.patentClaims.freeFormTags.deleteAll();
        step("Verify that no free form tags are not displayed");
        expect(patentDetailsPage.patentClaims.freeFormTags.getTags())
            .toEqual([]);
    });

    var claimRatingEdit = {
        "Literal Relevance": 3,
        "Relevant Companies": 2,
        "Priority:": 3,
        "Detection": 2,
        "Claim Simplicity": 1,
        "Importance": 2,
        "101 Eligibility": 3,
        "112 Description": 1,
        "112 Enablement": 2,
        "112 Indefiniteness": 1
    };

    var expRatings = {
        "LITERAL RELEVANCE": { actual: 3, max: '4' },
        "RELEVANT COMPANIES": { actual: 2, max: '3' },
        "PRIORITY": { actual: 3, max: '3' },
        "DETECTION": { actual: 2, max: '3' },
        "CLAIM SIMPLICITY": { actual: 1, max: '3' },
        "IMPORTANCE": { actual: 2, max: '3' },
        "101 ELIGIBILITY": { actual: 3, max: '3' },
        "112 DESCRIPTION": { actual: 1, max: '2' },
        "112 ENABLEMENT": { actual: 2, max: '2' },
        "112 INDEFINITENESS": { actual: 1, max: '2' }
    };

    it("should be able to edit the claim rating", function () {
        step("Edit the claims star rating");
        patentDetailsPage.patentClaims.claimStarRating.setStarRatings(claimRatingEdit);
        step("Verify that edited star rating is displayed");
        expect(patentDetailsPage.patentClaims.claimStarRating.getRatingsObject()).toEqual(expRatings);
    });
});