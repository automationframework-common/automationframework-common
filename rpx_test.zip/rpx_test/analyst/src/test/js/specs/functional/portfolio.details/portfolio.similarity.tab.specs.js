var loginPage = require("../../../pages/login.page"),
    homePage = require("../../../pages/home.page"),
    portfolioDetailsPage = require("../../../pages/portfolio.details.page");

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
    at(homePage);
});

var portfolioId = "501118";
// var portfolioId = "7908"; This id has data on the chart
describe("Portfolio details", function () {
    beforeAll(function () {
        to(portfolioDetailsPage, portfolioId);
    });
    beforeEach(function () {
        step("Login and navigate to portfolio details");
    });

    describe("Similarity tab", function () {
        beforeAll(function () {
            portfolioDetailsPage.patentDataSubTabs.portfolio.select("Similarity");
        });
        beforeEach(function () {
            step("Click on Similarity tab");
        });

        it("should display the similarity high chart displayed", function () {
            step("Verify that similarities high chart is displayed");
            expect(portfolioDetailsPage.portfolioSimilarityTab.highChart.isDisplayed())
                .toEqual(true, "Similarity high chart is not displayed");
        });
    });
});
