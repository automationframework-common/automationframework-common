require("../../../helpers/custom.matcher.helper");

var loginPage = require("../../../pages/login.page"),
    homePage = require("../../../pages/home.page"),
    portfolioDetailsPage = require("../../../pages/portfolio.details.page"),
    salesForceSummaryPage = require("../../../pages/salesforce.summary");

var portfolioQ = require("../../../data/queries/portfolio.queries"),
    dbHelper = require("../../../helpers/db.helper");

var using = require("jasmine-data-provider");

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
    at(homePage);
});

describe("Portfolio_Patents", function () {
    var portfolioId = "7785";
    // portfolioTitleForRpxTab = "JSDQ LLC - OMA";

    beforeAll(function () {
        to(portfolioDetailsPage, portfolioId);

    });

    describe("Bulk-Tagging-No_Tags", function () {
        var patNumAlone = 'US 7,933,951 B2';

        beforeAll(function () {
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(patNumAlone);
            portfolioDetailsPage.patentClaims.clickClaim(0);

        });

        beforeEach(function () {
            step("Login and click on the PATENT " + patNumAlone + " from Portfolio");
        });


        // Checking with KeyPatent checkbox annotation
        it("verify bulk tagging modal pops up on clicking bulk-tagging icon", function () {
            step("Click the bulk-tagging icon at claim header");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Verify that bulk-taggin modal displayed");
            expect(portfolioDetailsPage.patentClaims.bulkTaggingModal.isBulkTagginModalPresent()).toEqual(true);
            step("Close the bulk tagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.closeBulkTaggingModal();
        });


        // check no tech tag message when no theory added

        it("verify No Tech Tags Found message in bulk-tagging modal", function () {
            step("Delete all Tech_tags of this patent " + patNumAlone);
            portfolioDetailsPage.patentClaims.deleteAllTechnologyTags();
            step("Click the bulk-tagging icon at claim header");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Verify that No Tech Tags Found message is displayed");
            expect(portfolioDetailsPage.patentClaims.bulkTaggingModal.getNoDataText("Tech Tags")).toEqual("No Tech Tags Found");
            step("Close the bulk tagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.closeBulkTaggingModal();
        });

        // check no theory  message when no theory added

        it("verify No Theory Found message in bulk-tagging modal", function () {
            step("Delete all theories of this patent " + patNumAlone);
            portfolioDetailsPage.patentClaims.deleteAllTheoryTags();
            step("Click the bulk-tagging icon at claim header");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Verify that No Theory Found message is displayed");
            expect(portfolioDetailsPage.patentClaims.bulkTaggingModal.getNoDataText("Theory")).toEqual("No Theory Found");
            step("Close the bulk tagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.closeBulkTaggingModal();
        });

        // check no PRC message when no theory added

        it("verify No PRC Found message in bulk-tagging modal", function () {
            step("Delete all PRCs of this patent " + patNumAlone);
            portfolioDetailsPage.patentClaims.deleteAllPrcTags();
            step("Click the bulk-tagging icon at claim header");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Verify that No PRC Found message is displayed");
            expect(portfolioDetailsPage.patentClaims.bulkTaggingModal.getNoDataText("PRC")).toEqual("No PRC Found");
            step("Close the bulk tagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.closeBulkTaggingModal();
        });

        // check no Licensees found message when no theory added

        it("verify No Licensees Found message in bulk-tagging modal", function () {
            step("Click the licensees tab in patent-header");
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(patNumAlone);
            portfolioDetailsPage.patentHeader.annotationTabs.select("Licensees");
            step("Delete all Licensees of this patent " + patNumAlone);
            portfolioDetailsPage.patentHeader.licensees.tags.deleteAll();
            step("Click the bulk-tagging icon at claim header");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Verify that No PRC Found message is displayed");
            expect(portfolioDetailsPage.patentClaims.bulkTaggingModal.getNoDataText("Licensees")).toEqual("No Licensees Found.");
            step("Close the bulk tagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.closeBulkTaggingModal();
        });



    });


    describe("Bulk-Tagging-Tech_Tags", function () {
        var sourcePatent = 'US 7,933,951 B2';
        var targetPatent1 = 'US 7,631,101 B2';
        var targetPatent2 = 'US 7,593,935 B2';
        // var techTag = 'Networking Cable Modem';
        var techTag = 'Network Protocol';

        beforeAll(function () {
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            portfolioDetailsPage.patentClaims.clickClaim(0);

        });

        beforeEach(function () {
            step("Login and click on the PATENT " + sourcePatent + " from Portfolio");
        });


        // adding tech-tag and checking that in Bulk-Tagging Modal
        it("Add tech tag and check that present in BulkTagging modal", function () {
            var techTagsRatingData = {
                // "Networking Cable Modem": "3"
                "Network Protocol": "3"
                
            };
            portfolioDetailsPage.patentClaims.deleteAllTechnologyTags();
            step("Add tech tag - " + techTag + " - from Search Select");
            portfolioDetailsPage.patentClaims.claimsTechnologyTab.searchSelect.select(techTag);
            step("Edit the star rating of the technology tag");
            portfolioDetailsPage.patentClaims.claimsTechnologyTab.tags.setData(techTagsRatingData);
            step("Click the bulk-tagging icon at claim header");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Verify that added Tech Tag " + techTag + " is available in BulkTagging Modal");
            // expect(portfolioDetailsPage.patentClaims.bulkTaggingModal.getTags("Tech Tags")).toEqual("[ '" + techTag + "' ]");
            expect(portfolioDetailsPage.patentClaims.bulkTaggingModal.getTags("Tech Tags")).toContain(techTag);
        });

        // Check the paddle switch present for the newly added tech tag
        it("Check the paddle switch present for the newly added tech tag", function () {
            step("Verify that paddle switch present for the newly added tech tag");
            expect(portfolioDetailsPage.patentClaims.bulkTaggingModal.toggleSwitchIsDisplayed(techTag)).toEqual(true);
            step("Close the bulk tagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.closeBulkTaggingModal();
        });




        // Add this tech tag to a claim of other patent in the portfolio using bulk tagging modal

        it("verify adding techtag to other patent claim using bulktagging", function () {
            var claim = 'Claim 8';
            step("navigate to target patent " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claim : claim 8");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("Delete all the tech tags available in the target patent");
            portfolioDetailsPage.patentClaims.deleteAllTechnologyTags();
            step("Navigate to the Source Patent " + sourcePatent);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            step("Click the bulk-tagging icon at claim header to open bulkTagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Select the TechTag " + techTag + " for bulk tagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.selectToggleOfTag(techTag);
            step("Click on the Next Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickNext();
            step("Expand all the items under patents grid in bulkTagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.bulkGridExpandAll();
            step("Select the " + claim + " under target patent " + targetPatent1);
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.clickSelectIconOfRow(claim);
            step("Click on Save Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickSave();
            angularWait();
            step("navigate to target patent again " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claim " + claim + " to check the added tech tag");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            // step("navigate to technology tab");
            // portfolioDetailsPage.patentClaims.claimTabs.select("Technology");
            step("check that added tech tag present under this claim's tab");
            expect(portfolioDetailsPage.patentClaims.claimsTechnologyTab.tags.getTagsText()).toContain(techTag);

        });

        // verify that tech tag star ratings not copied from bulk-tagging
        it("verify star-rating of tech tag not copied by bulk tagging", function () {
            var claim = 'Claim 8';
            var expTechTagsRatingData = [
                { "Network Protocol": { "actual": 0, "max": null } }];
            step("navigate to target patent" + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claim " + claim + " to check the added tech tag");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            // step("navigate to technology tab");
            // portfolioDetailsPage.patentClaims.claimTabs.select("Technology");
            step("Verify the star rating of the bulk tagged technology tag should be 0")
            expect(portfolioDetailsPage.patentClaims.claimsTechnologyTab.tags.getData())
                .toEqual(expTechTagsRatingData);

        });

        // Check that only selected tech tags from bulktagging modal get tagged at target patents
        it("verify only selected tags in bulktagging modal get tagged at target", function () {
            var claim = 'Claim 8';
            var techTagsList = [
                "Network Protocol",
                "Modem",
                "Mobile Apps"
            ];
            var selectedTags = ["Modem", "Mobile Apps"];
            var expectedTags = ['Software > Mobile Apps','Networking > Cable > Modem'];
            step("navigate to target patent " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claim : claim 8");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("Delete all the tech tags available in the target patent");
            portfolioDetailsPage.patentClaims.deleteAllTechnologyTags();
            step("Navigate to the Source Patent " + sourcePatent);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            step("Click the claim to add more tech tags");
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("Add 3 tech tags to the patent " + sourcePatent);
            portfolioDetailsPage.patentClaims.deleteAllTechnologyTags();
            portfolioDetailsPage.patentClaims.claimsTechnologyTab.searchSelect.select(techTagsList);
            step("Click the bulk-tagging icon at claim header to open bulkTagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            angularWait();
            step("UnSelect the TechTag " + techTagsList[1] + " for bulk tagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.deSelectToggleOfTag(techTagsList[1]);
            step("Click on the Next Button");

            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickNext();
            step("Expand all the items under patents grid in bulkTagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.bulkGridExpandAll();
            step("Select the " + claim + " under target patent " + targetPatent1);
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.clickSelectIconOfRow(claim);
            step("Click on Save Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickSave();
            angularWait();
            step("navigate to target patent again " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claim " + claim + " to check the added tech tag");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            // step("navigate to technology tab");
            // portfolioDetailsPage.patentClaims.claimTabs.select("Technology");
            step("check that added tech tag present under this claim's tab");
            expect(portfolioDetailsPage.patentClaims.claimsTechnologyTab.tags.getTagsText()).toEqual(selectedTags);
            


        });

        // Add this tech tag to a target patent in the portfolio using bulk tagging modal

        it("verify bulktagging a patent with tech-tag adds only to first of its claims", function () {
            var claim = 'Claim 8';
            var techTagsList = [
                "Network Protocol"
            ];
            step("navigate to target patent " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claims : claim 1");
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("Delete all the tech tags available in the target patent");
            portfolioDetailsPage.patentClaims.deleteAllTechnologyTags();
            step("Select the target claims : claim 8");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("Delete all the tech tags available in the target patent");
            portfolioDetailsPage.patentClaims.deleteAllTechnologyTags();
            step("Navigate to the Source Patent " + sourcePatent);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            step("Select the target claims : claim 1");
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("Delete all the tech tags available in the target patent");
            portfolioDetailsPage.patentClaims.deleteAllTechnologyTags();
            step("Add tech-tag " + techTagsList[0]);
            portfolioDetailsPage.patentClaims.claimsTechnologyTab.searchSelect.select(techTagsList);
            step("Click the bulk-tagging icon at claim header to open bulkTagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Select the TechTag " + techTag + " for bulk tagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.selectToggleOfTag(techTagsList[0]);
            step("Click on the Next Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickNext();
            step("Expand all the items under patents grid in bulkTagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.bulkGridExpandAll();
            step("Select the " + claim + " under target patent " + targetPatent1);
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.clickSelectIconOfRow(targetPatent1);
            step("Click on Save Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickSave();
            angularWait();
            step("navigate to target patent again " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claim " + claim + " to check the added tech tag");
            portfolioDetailsPage.patentClaims.clickClaim(0);
            // step("navigate to technology tab");
            // portfolioDetailsPage.patentClaims.claimTabs.select("Technology");
            step("check that added tech tag present under first claim " + claim + " 's tab");
            expect(portfolioDetailsPage.patentClaims.claimsTechnologyTab.tags.getTagsText()).toEqual(techTagsList);
            step("Select the target claim : claim 8");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("Verify now no tags should be displayed after bulk-tagging at patent level");
            step("The tags link display should return false");
            expect(portfolioDetailsPage.patentClaims.claimsTechnologyTab.tags.getTagsText()).toEqual(undefined);


        });
        // select all claims from bulk tagging and tag
        // TODO : include after the bug fix
        xit("verify bulktagging to all patents under portfolio", function () {

            var techTagsList = [
                "Network Protocol"
            ];
            step("Navigate to the Source Patent " + sourcePatent);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            step("Select the target claims : claim 1");
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("Delete all the tech tags available in the target patent");
            portfolioDetailsPage.patentClaims.deleteAllTechnologyTags();
            step("Add tech-tag " + techTagsList[0]);
            portfolioDetailsPage.patentClaims.claimsTechnologyTab.searchSelect.select(techTagsList);
            step("Click the bulk-tagging icon at claim header to open bulkTagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Select the TechTag " + techTag + " for bulk tagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.selectToggleOfTag(techTagsList[0]);
            step("Click on the Next Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickNext();
            step("Expand all the items under patents grid in bulkTagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.bulkGridExpandAll();
            step("Click the Select All tick in Bulk grid");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.selectAllRows();
            step("Click on Save Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickSave();
            angularWait();
            // Checking tags under target patent 1
            step("navigate to target patent 1 " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the first claim of patent : " + targetPatent1);
            portfolioDetailsPage.patentClaims.clickClaim(0);
            // step("navigate to technology tab");
            // portfolioDetailsPage.patentClaims.claimTabs.select("Technology");
            step("check that added tech tag present under claim 1's tab");
            expect(portfolioDetailsPage.patentClaims.claimsTechnologyTab.tags.getTagsText()).toContain(techTagsList[0]);
            step("Select the target second claim of patent: " + targetPatent1);
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("check that added tech tag present under Claim 8's tab");
            step("The tags link display should return false");
            expect(portfolioDetailsPage.patentClaims.claimsTechnologyTab.tags.getTagsText()).toContain(techTagsList[0]);

            // Checking tech tags under target patent 2
            step("navigate to target patent 2 " + targetPatent2);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent2);
            step("Select first claim of patent : " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(0);
            // step("navigate to technology tab");
            // portfolioDetailsPage.patentClaims.claimTabs.select("Technology");
            step("check that added tech tag present under claim 1's tab");
            expect(portfolioDetailsPage.patentClaims.claimsTechnologyTab.tags.getTagsText()).toContain(techTagsList[0]);

            step("Select the target second claim of patent: " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("check that added tech tag present under Claim 6's tab");
            step("The tags link display should return false");
            expect(portfolioDetailsPage.patentClaims.claimsTechnologyTab.tags.getTagsText()).toContain(techTagsList[0]);

            step("Select the target third claim of patent: " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(2);
            step("check that added tech tag present under Claim 7's tab");
            step("The tags link display should return false");
            expect(portfolioDetailsPage.patentClaims.claimsTechnologyTab.tags.getTagsText()).toContain(techTagsList[0]);

            step("Select the target second claim of patent: " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(3);
            step("check that added tech tag present under Claim 13's tab");
            step("The tags link display should return false");
            expect(portfolioDetailsPage.patentClaims.claimsTechnologyTab.tags.getTagsText()).toContain(techTagsList[0]);

            step("Select the target second claim of patent: " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(4);
            step("check that added tech tag present under Claim 15's tab");
            step("The tags link display should return false");
            expect(portfolioDetailsPage.patentClaims.claimsTechnologyTab.tags.getTagsText()).toContain(techTagsList[0]);

            step("Select the target second claim of patent: " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(5);
            step("check that added tech tag present under Claim 16's tab");
            step("The tags link display should return false");
            expect(portfolioDetailsPage.patentClaims.claimsTechnologyTab.tags.getTagsText()).toContain(techTagsList[0]);

        });
    });

// Bulk-tagging with theories
    describe("Bulk-Tagging-Theories", function () {
        var sourcePatent = 'US 7,933,951 B2';
        var targetPatent1 = 'US 7,631,101 B2';
        var targetPatent2 = 'US 7,593,935 B2';
        var theory = "BULK-TAGGING THEORY";

        beforeAll(function () {
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            portfolioDetailsPage.patentClaims.clickClaim(0);

        });

        beforeEach(function () {
            step("Login and click on the PATENT " + sourcePatent + " from Portfolio");
        });


        // adding tech-tag and checking that in Bulk-Tagging Modal
        it("Add theory and check that present in BulkTagging modal", function () {
            
            step("Delete existing theory tags and theory for first claim");
            portfolioDetailsPage.patentClaims.deleteAllTheoryTags();
            step("Add a theory: "+ theory +" to first claim");
            portfolioDetailsPage.patentClaims.claimsTheoryTab.add({ "theory": "BULK-TAGGING THEORY" });
            step("Click the bulk-tagging icon at claim header");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Verify that added theory " + theory + " is available in BulkTagging Modal");
            // expect(portfolioDetailsPage.patentClaims.bulkTaggingModal.getTags("Tech Tags")).toEqual("[ '" + techTag + "' ]");
            expect(portfolioDetailsPage.patentClaims.bulkTaggingModal.getTags("Theory")).toContain(theory);
        });

        // Check the paddle switch present for the newly added tech tag
        it("Check the paddle switch present for the newly added theory", function () {
            step("Verify that paddle switch present for the newly added theory");
            expect(portfolioDetailsPage.patentClaims.bulkTaggingModal.toggleSwitchIsDisplayed(theory)).toEqual(true);
            step("Close the bulk tagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.closeBulkTaggingModal();
        });

        // Add this theroy to a claim of other patent in the portfolio using bulk tagging modal

       it("verify adding theory to other patent claim using bulktagging", function () {
            var claim = 'Claim 8';
            step("navigate to target patent " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claim : claim 8");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("Delete all theories available in the target patent");
            portfolioDetailsPage.patentClaims.deleteAllTheoryTags();
            step("Navigate to the Source Patent " + sourcePatent);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            step("Click the bulk-tagging icon at claim header to open bulkTagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Select the Theory " + theory + " for bulk tagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.selectToggleOfTag(theory);
            step("Click on the Next Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickNext();
            step("Expand all the items under patents grid in bulkTagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.bulkGridExpandAll();
            step("Select the " + claim + " under target patent " + targetPatent1);
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.clickSelectIconOfRow(claim);
            step("Click on Save Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickSave();
            angularWait();
            step("navigate to target patent again " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claim " + claim + " to check the added theory");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("navigate to theory tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("Theory");
            step("check that added theory present under this claim's tab");
            expect(portfolioDetailsPage.patentClaims.claimsTheoryTab.tags.getTagsText()).toContain(theory);

        });
       

        // Check that only selected Theory from bulktagging modal get tagged at target patents
        it("verify only selected Theory in bulktagging modal get tagged at target", function () {
            var claim = 'Claim 8';
            var theory1 = {
                theory: "Bulk-tagging theory_1"
            };

            var theory2 = {
                theory: "Bulk-tagging theory_2"
            };
            var selectedTheory = ["Bulk-tagging theory_1","Bulk-tagging theory_2"]
            step("navigate to target patent " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claim : claim 8");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("Delete all the theories available in the target patent");
            portfolioDetailsPage.patentClaims.deleteAllTheoryTags();
            step("Navigate to the Source Patent " + sourcePatent);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            step("Click the claim to add more tech tags");
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("Add 2 theories to the patent " + sourcePatent);
            portfolioDetailsPage.patentClaims.deleteAllTheoryTags();
            portfolioDetailsPage.patentClaims.claimsTheoryTab.add(theory1);
            portfolioDetailsPage.patentClaims.claimsTheoryTab.add(theory2);
            step("Click the bulk-tagging icon at claim header to open bulkTagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            angularWait();
            step("DeSelect the theory " + selectedTheory[0] + " for bulk tagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.deSelectToggleOfTag(selectedTheory[0]);
            step("Click on the Next Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickNext();
            step("Expand all the items under patents grid in bulkTagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.bulkGridExpandAll();
            step("Select the " + claim + " under target patent " + targetPatent1);
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.clickSelectIconOfRow(claim);
            step("Click on Save Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickSave();
            angularWait();
            step("navigate to target patent again " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claim " + claim + " to check the added theory");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("navigate to Theory tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("Theory");
            step("check that added theory present under this claim's tab");
            expect(portfolioDetailsPage.patentClaims.claimsTheoryTab.tags.getTagsText()).toEqual(selectedTheory[1]);


        });

        // Add this tech tag to a target patent in the portfolio using bulk tagging modal

        it("verify bulktagging a patent with theory adds only to first of its claims", function () {
            // var claim = 'Claim 8';
            var theory1 = {
                theory: "Bulk-tagging theory_1"
            };
            step("navigate to target patent " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claims : claim 1");
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("Delete all the theories available in the target patent");
            portfolioDetailsPage.patentClaims.deleteAllTheoryTags();
            step("Select the target claims : claim 8");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("Delete all the theories available in the target patent");
            portfolioDetailsPage.patentClaims.deleteAllTheoryTags();
            step("Navigate to the Source Patent " + sourcePatent);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            step("Select the target claims : claim 1");
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("Delete all the theories available in the target patent");
            portfolioDetailsPage.patentClaims.deleteAllTheoryTags();
            step("Add tech-tag:  Bulk-tagging theory_1");
            portfolioDetailsPage.patentClaims.claimsTheoryTab.add(theory1);
            step("Click the bulk-tagging icon at claim header to open bulkTagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Select the TechTag " + techTag + " for bulk tagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.selectToggleOfTag("Bulk-tagging theory_1");
            step("Click on the Next Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickNext();
            step("Expand all the items under patents grid in bulkTagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.bulkGridExpandAll();
            step("Select the " + claim + " under target patent " + targetPatent1);
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.clickSelectIconOfRow(targetPatent1);
            step("Click on Save Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickSave();
            angularWait();
            step("navigate to target patent again " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claim " + claim + " to check the added theory");
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("navigate to Theory tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("Theory");
            step("check that added theory present under first claim " + claim + " 's tab");
            expect(portfolioDetailsPage.patentClaims.claimsTheoryTab.tags.getTagsText()).toEqual("Bulk-tagging theory_1");
            step("Select the target claim : claim 8");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("Verify now no theories should be displayed after bulk-tagging at patent level");
            step("The tags link display should return false");
            expect(portfolioDetailsPage.patentClaims.claimsTheoryTab.tags.getTagsText()).toEqual(undefined);


        });
        // select all claims from bulk tagging and tag
        // TODO:include after the bug fix
        xit("verify bulktagging to all patents under portfolio", function () {

            var theory1 = {
                theory: "Bulk-tagging theory_1"
            };
            step("Navigate to the Source Patent " + sourcePatent);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            step("Select the target claims : claim 1");
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("Delete all the theories available in the target patent");
            portfolioDetailsPage.patentClaims.deleteAllTheoryTags();
            step("Add tech-tag: Bulk-tagging theory_1");
            portfolioDetailsPage.patentClaims.claimsTheoryTab.add(theory1);
            step("Click the bulk-tagging icon at claim header to open bulkTagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Select the theory: Bulk-tagging theory_1 for bulk tagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.selectToggleOfTag("Bulk-tagging theory_1");
            step("Click on the Next Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickNext();
            step("Expand all the items under patents grid in bulkTagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.bulkGridExpandAll();
            step("Click the Select All tick in Bulk grid");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.selectAllRows();
            step("Click on Save Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickSave();
            angularWait();
            // Checking tags under target patent 1
            step("navigate to target patent 1 " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the first claim of patent : " + targetPatent1);
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("navigate to Theory tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("Theory");
            step("check that added theory present under claim 1's tab");
            expect(portfolioDetailsPage.patentClaims.claimsTheoryTab.tags.getTagsText()).toContain("Bulk-tagging theory_1");
            step("Select the target second claim of patent: " + targetPatent1);
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("navigate to Theory tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("Theory");
            step("check that added theory present under Claim 8's tab");
            expect(portfolioDetailsPage.patentClaims.claimsTheoryTab.tags.getTagsText()).toContain("Bulk-tagging theory_1");

            // Checking tech tags under target patent 2
            step("navigate to target patent 2 " + targetPatent2);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent2);
            step("Select first claim of patent : " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("navigate to Theory tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("Theory");
            step("check that added tech tag present under claim 1's tab");
            expect(portfolioDetailsPage.patentClaims.claimsTheoryTab.tags.getTagsText()).toContain("Bulk-tagging theory_1");

            step("Select the target second claim of patent: " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("navigate to Theory tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("Theory");
            step("check that added tech tag present under Claim 6's tab");            
            expect(portfolioDetailsPage.patentClaims.claimsTheoryTab.tags.getTagsText()).toContain("Bulk-tagging theory_1");

            step("Select the target third claim of patent: " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(2);
            step("navigate to Theory tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("Theory");
            step("check that added tech tag present under Claim 7's tab");            
            expect(portfolioDetailsPage.patentClaims.claimsTheoryTab.tags.getTagsText()).toContain("Bulk-tagging theory_1");

            step("Select the target second claim of patent: " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(3);
            step("navigate to Theory tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("Theory");
            step("check that added tech tag present under Claim 13's tab");            
            expect(portfolioDetailsPage.patentClaims.claimsTheoryTab.tags.getTagsText()).toContain("Bulk-tagging theory_1");

            step("Select the target second claim of patent: " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(4);
            step("navigate to Theory tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("Theory");
            step("check that added tech tag present under Claim 15's tab");            
            expect(portfolioDetailsPage.patentClaims.claimsTheoryTab.tags.getTagsText()).toContain("Bulk-tagging theory_1");

            step("Select the target second claim of patent: " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(5);
            step("navigate to Theory tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("Theory");
            step("check that added tech tag present under Claim 16's tab");            
            expect(portfolioDetailsPage.patentClaims.claimsTheoryTab.tags.getTagsText()).toContain("Bulk-tagging theory_1");

        });
    });
// Bulk tagging with PRC and its claims

    describe("Bulk-Tagging-PRCs", function () {
        var sourcePatent = 'US 7,933,951 B2';
        var targetPatent1 = 'US 7,631,101 B2';
        var targetPatent2 = 'US 7,593,935 B2';
        var prcEntities = ["Tesla Motors Incorporated", "Arrivalstar SA"];

        beforeAll(function () {
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            portfolioDetailsPage.patentClaims.clickClaim(0);

        });

        beforeEach(function () {
            step("Login and click on the PATENT " + sourcePatent + " from Portfolio");
        });


        // adding PRC and checking that in Bulk-Tagging Modal
        it("Add PRC and check that present in BulkTagging modal", function () {
           var actData= {
                "Tesla Motors Incorporated": {
                    "isCharted": false,
                    "tags": { "Networking Cable Modem": true },
                    "theory": { "Bulk-tagging theory_1": true },
                    "notes": "auto test notes"
                }
            };
            portfolioDetailsPage.patentClaims.deleteAllPrcTags();
            step("Add tech tag - " + prcEntities[0] + " - from Search Select");
            portfolioDetailsPage.patentClaims.claimsPrcTab.searchSelect.select(prcEntities[0]);
            step("Edit the claim chart to have tech tag, theory count");
            portfolioDetailsPage.patentClaims.claimsPrcTab.tags.setData(actData);
            step("Click the bulk-tagging icon at claim header");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Verify that added PRC " + prcEntities[0] + " is available in BulkTagging Modal");
            // expect(portfolioDetailsPage.patentClaims.bulkTaggingModal.getTags("Tech Tags")).toEqual("[ '" + techTag + "' ]");
            expect(portfolioDetailsPage.patentClaims.bulkTaggingModal.getTags("PRC")).toContain(prcEntities[0]);
        });

        // Check the paddle switch present for the newly added tech tag
        it("Check the paddle switch present for the newly added PRC", function () {
            step("Verify that paddle switch present for the newly added tech tag");
            expect(portfolioDetailsPage.patentClaims.bulkTaggingModal.toggleSwitchIsDisplayed(prcEntities[0])).toEqual(true);
            step("Close the bulk tagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.closeBulkTaggingModal();
        });




        // Add this tech tag to a claim of other patent in the portfolio using bulk tagging modal

        it("verify adding PRC to other patent claim using bulktagging", function () {
            var claim = 'Claim 8';
            step("navigate to target patent " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claim : claim 8");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("Delete all the PRCs available in the target patent");
            portfolioDetailsPage.patentClaims.deleteAllPrcTags();
            step("Navigate to the Source Patent " + sourcePatent);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            step("Click the bulk-tagging icon at claim header to open bulkTagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Select the PRC " + prcEntities[0] + " for bulk tagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.selectToggleOfTag(prcEntities[0]);
            step("Select the Claim chart of the PRC "+prcEntities[0]+" for bulk-Tagging");
            step("Click on the Next Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickNext();
            step("Expand all the items under patents grid in bulkTagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.bulkGridExpandAll();
            step("Select the " + claim + " under target patent " + targetPatent1);
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.clickSelectIconOfRow(claim);
            step("Click on Save Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickSave();
            angularWait();
            step("navigate to target patent again " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claim " + claim + " to check the added PRC");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("navigate to PRC tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("PRC");
            step("check that added tech tag present under this claim's tab");
            expect(portfolioDetailsPage.patentClaims.claimsPrcTab.tags.getTagsText()).toContain(prcEntities[0]);

        });

        // verify that tech tag star ratings not copied from bulk-tagging
        it("verify claimChart details of PRC not copied by bulk tagging", function () {
            var claim = 'Claim 8';
            expData= {
                prc: 'Tesla Motors Incorporated',
                modalContent: {
                    title: 'Tesla Motors Incorporated',
                    "tags": { "Networking Cable Modem": false },
                    "theory": { "Bulk-tagging theory_1": false },
                    notes: 'auto test notes'
                },
                claimCharted: false,
                theoryCount: '0',
                techTagCount: '0'
            };
            step("navigate to target patent" + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claim " + claim + " to check the added tech tag");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("navigate to PRC tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("PRC");
            step("Verify the Claim Chart of the bulk tagged technology tag should not be copied")
            expect(portfolioDetailsPage.patentClaims.claimsPrcTab.tags.getData()).toEqual([expData]);

        });

        // Check that only selected tech tags from bulktagging modal get tagged at target patents
        it("verify only selected PRCs in bulktagging modal get tagged at target", function () {
            var claim = 'Claim 8';
            var selectedPRCs = ["Arrivalstar SA"];
            step("navigate to target patent " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claim : claim 8");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("navigate to PRC tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("PRC");
            step("Delete all the PRCs available in the target patent");
            portfolioDetailsPage.patentClaims.deleteAllPrcTags();
            step("Navigate to the Source Patent " + sourcePatent);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            step("Click the claim to add more tech tags");
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("navigate to PRC tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("PRC");
            step("Add a PRC :"+prcEntities[1]+" to claim");
            portfolioDetailsPage.patentClaims.claimsPrcTab.searchSelect.select(prcEntities[1]);
            step("Click the bulk-tagging icon at claim header to open bulkTagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            angularWait();
            step("UnSelect the PRC " + prcEntities[0] + " for bulk tagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.deSelectToggleOfTag(prcEntities[0]);
            step("Click on the Next Button");

            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickNext();
            step("Expand all the items under patents grid in bulkTagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.bulkGridExpandAll();
            step("Select the " + claim + " under target patent " + targetPatent1);
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.clickSelectIconOfRow(claim);
            step("Click on Save Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickSave();
            angularWait();
            step("navigate to target patent again " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claim " + claim + " to check the added tech tag");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("navigate to PRC tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("PRC");
            step("check that added tech tag present under this claim's tab");
            expect(portfolioDetailsPage.patentClaims.claimsPrcTab.tags.getTagsText()).toEqual(selectedPRCs);


        });

        // Add this tech tag to a target patent in the portfolio using bulk tagging modal

        it("verify bulktagging a patent with PRCs adds only to first of its claims", function () {
            // var claim = 'Claim 8';
            var selectedPRCs = ["Arrivalstar SA"];
            step("navigate to target patent " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claims : claim 1");
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("Delete all the PRCs available in the target patent");
            portfolioDetailsPage.patentClaims.deleteAllPrcTags();
            step("Select the target claims : claim 8");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("Delete all the PRCs available in the target patent");
            portfolioDetailsPage.patentClaims.deleteAllPrcTags();
            step("Navigate to the Source Patent " + sourcePatent);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            step("Select the target claims : claim 1");
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("Delete all the PRCs available in the Source patent");
            portfolioDetailsPage.patentClaims.deleteAllPrcTags();
            step("Add PRC " + selectedPRCs[0]);
            portfolioDetailsPage.patentClaims.claimsPrcTab.searchSelect.select(selectedPRCs);
            step("Click the bulk-tagging icon at claim header to open bulkTagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Select the PRC " + selectedPRCs[0] + " for bulk tagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.selectToggleOfTag(selectedPRCs[0]);
            step("Click on the Next Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickNext();
            step("Expand all the items under patents grid in bulkTagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.bulkGridExpandAll();
            step("Select the claim 0 under target patent " + targetPatent1);
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.clickSelectIconOfRow(targetPatent1);
            step("Click on Save Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickSave();
            angularWait();
            step("navigate to target patent again " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the target claim to check the added PRC");
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("navigate to PRC tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("PRC");
            step("check that added PRC present under first claim: claim 0's tab");
            expect(portfolioDetailsPage.patentClaims.claimsPrcTab.tags.getTagsText()).toEqual(selectedPRCs);
            step("Select the target claim : claim 8");
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("navigate to PRC tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("PRC");
            step("Verify now no PRCs should be displayed after bulk-tagging at patent level");
            step("The tags link display should return false");
            expect(portfolioDetailsPage.patentClaims.claimsPrcTab.tags.getTagsText()).toEqual(undefined);


        });
        // select all claims from bulk tagging and tag
        // excluded - waiting for the bug to be fixed
        xit("verify bulktagging to all patents under portfolio", function () {

            var selectedPRCs = ["Arrivalstar SA"];
            step("Navigate to the Source Patent " + sourcePatent);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            step("Select the target claims : claim 1");
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("Delete all the PRCs available in the Source patent");
            portfolioDetailsPage.patentClaims.deleteAllPrcTags();
            step("Add PRC " + selectedPRCs[0]);
            portfolioDetailsPage.patentClaims.claimsPrcTab.searchSelect.select(selectedPRCs);
            step("Click the bulk-tagging icon at claim header to open bulkTagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Select the PRCs " + selectedPRCs[0] + " for bulk tagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.selectToggleOfTag(selectedPRCs[0]);
            step("Click on the Next Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickNext();
            step("Expand all the items under patents grid in bulkTagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.bulkGridExpandAll();
            step("Click the Select All tick in Bulk grid");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.selectAllRows();
            step("Click on Save Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickSave();
            angularWait();
            // Checking tags under target patent 1
            step("navigate to target patent 1 " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("Select the first claim of patent : " + targetPatent1);
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("navigate to PRCs tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("PRC");
            step("check that added PRC present under claim 1's tab");
            expect(portfolioDetailsPage.patentClaims.claimsPrcTab.tags.getTagsText()).toEqual([selectedPRCs[0]]);
            step("Select the target second claim of patent: " + targetPatent1);
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("navigate to PRCs tab");
            
            step("check that added PRC present under Claim 8's tab");            
            portfolioDetailsPage.patentClaims.claimTabs.select("PRC");            
            expect(portfolioDetailsPage.patentClaims.claimsPrcTab.tags.getTagsText()).toEqual([selectedPRCs[0]]);

            // Checking tech tags under target patent 2
            step("navigate to target patent 2 " + targetPatent2);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent2);
            step("Select first claim of patent : " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(0);
            step("navigate to PRCs tab");
            portfolioDetailsPage.patentClaims.claimTabs.select("PRC");
            step("check that added PRC present under claim 1's tab");
            expect(portfolioDetailsPage.patentClaims.claimsPrcTab.tags.getTagsText()).toEqual([selectedPRCs[0]]);

            step("Select the target second claim of patent: " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(1);
            step("check that added PRC present under Claim 6's tab");
            step("navigate to PRCs tab");
            // portfolioDetailsPage.patentClaims.claimTabs.select("PRC");
            
            expect(portfolioDetailsPage.patentClaims.claimsPrcTab.tags.getTagsText()).toEqual([selectedPRCs[0]]);

            step("Select the target third claim of patent: " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(2);
            step("navigate to PRCs tab");
            // portfolioDetailsPage.patentClaims.claimTabs.select("PRC");
            step("check that added PRC present under Claim 7's tab");
            
            expect(portfolioDetailsPage.patentClaims.claimsPrcTab.tags.getTagsText()).toEqual([selectedPRCs[0]]);

            step("Select the target second claim of patent: " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(3);
            step("navigate to PRCs tab");
            // portfolioDetailsPage.patentClaims.claimTabs.select("PRC");
            step("check that added PRC present under Claim 13's tab");
            
            expect(portfolioDetailsPage.patentClaims.claimsPrcTab.tags.getTagsText()).toEqual([selectedPRCs[0]]);

            step("Select the target second claim of patent: " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(4);
            step("navigate to PRCs tab");
            // portfolioDetailsPage.patentClaims.claimTabs.select("PRC");
            step("check that added PRC present under Claim 15's tab");
           
            expect(portfolioDetailsPage.patentClaims.claimsPrcTab.tags.getTagsText()).toEqual([selectedPRCs[0]]);

            step("Select the target second claim of patent: " + targetPatent2);
            portfolioDetailsPage.patentClaims.clickClaim(5);
            step("navigate to PRCs tab");
            // portfolioDetailsPage.patentClaims.claimTabs.select("PRC");
            step("check that added PRC present under Claim 16's tab");
            expect(portfolioDetailsPage.patentClaims.claimsPrcTab.tags.getTagsText()).toEqual([selectedPRCs[0]]);

        });
    });

// Bulk-tagging with Licensees
    describe("Bulk-Tagging-Licensees", function () {
        var sourcePatent = 'US 7,933,951 B2';
        var targetPatent1 = 'US 7,631,101 B2';
        var targetPatent2 = 'US 7,593,935 B2';
        var licensee = "Alphabet Inc.";

        beforeAll(function () {
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            // portfolioDetailsPage.patentClaims.clickClaim(0);

        });

        beforeEach(function () {
            step("Login and click on the PATENT " + sourcePatent + " from Portfolio");
        });


        // adding tech-tag and checking that in Bulk-Tagging Modal
        it("Add Licensee and check that present in BulkTagging modal", function () {            
            step("Delete existing Licensees of source patent: "+sourcePatent);
            portfolioDetailsPage.patentHeader.annotationTabs.select("Licensees");
            portfolioDetailsPage.patentHeader.licensees.tags.deleteAll();
            step("Add a Licensee: "+ licensee );
            portfolioDetailsPage.patentHeader.licensees.searchSelect.select(licensee);
            step("Click the bulk-tagging icon at claim header");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Verify that added Licensee " + licensee + " is available in BulkTagging Modal");
            // expect(portfolioDetailsPage.patentClaims.bulkTaggingModal.getTags("Tech Tags")).toEqual("[ '" + techTag + "' ]");
            expect(portfolioDetailsPage.patentClaims.bulkTaggingModal.getTags("Licensees")).toContain(licensee);
        });

        // Check the paddle switch present for the newly added tech tag
        it("Check the paddle switch present for the newly added theory", function () {
            step("Verify that paddle switch present for the newly added licensee");
            expect(portfolioDetailsPage.patentClaims.bulkTaggingModal.toggleSwitchIsDisplayed(licensee)).toEqual(true);
            step("Close the bulk tagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.closeBulkTaggingModal();
        });

        // Add this theroy to a claim of other patent in the portfolio using bulk tagging modal

        it("verify adding Licensee to other patent using bulktagging", function () {
            var claim = 'Claim 8';
            step("navigate to target patent " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("navigate to licensees tab");
            portfolioDetailsPage.patentHeader.annotationTabs.select("Licensees");           
            step("Delete all Licensees available in the target patent");
            portfolioDetailsPage.patentHeader.licensees.tags.deleteAll();
            step("Navigate to the Source Patent " + sourcePatent);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            step("Click the bulk-tagging icon at claim header to open bulkTagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Select the Licensee " + licensee + " for bulk tagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.selectToggleOfTag(licensee);
            step("Click on the Next Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickNext();
            step("Expand all the items under patents grid in bulkTagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.bulkGridExpandAll();
            step("Select the " + claim + " under target patent " + targetPatent1);
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.clickSelectIconOfRow(claim);
            step("Click on Save Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickSave();
            angularWait();
            step("navigate to target patent again " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);           
            step("navigate to Licensees tab");
            portfolioDetailsPage.patentHeader.annotationTabs.select("Licensees");           
            step("check that added Licensee present under this Patent's header");
            expect(portfolioDetailsPage.patentHeader.licensees.tags.getTags()).toContain(licensee);

        });
       

        // Check that only selected Theory from bulktagging modal get tagged at target patents
        it("verify only selected Licensee in bulktagging modal get tagged at target", function () {
            var claim = 'Claim 8';
            var licensees = ["Apple Inc.","Alphabet Inc."];
            step("navigate to target patent " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("navigate to licensees tab");
            portfolioDetailsPage.patentHeader.annotationTabs.select("Licensees");           
            step("Delete all Licensees available in the target patent");
            portfolioDetailsPage.patentHeader.licensees.tags.deleteAll();
            step("Navigate to the Source Patent " + sourcePatent);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);
            step("Add additional licensee "+licensees[0]+"to the patent " + sourcePatent);
            portfolioDetailsPage.patentHeader.annotationTabs.select("Licensees");    
            portfolioDetailsPage.patentHeader.licensees.searchSelect.select(licensees[0]);          
            step("Click the bulk-tagging icon at claim header to open bulkTagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            angularWait();
            step("DeSelect the licensee " + licensees[1] + " for bulk tagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.deSelectToggleOfTag(licensees[1]);
            step("Click on the Next Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickNext();
            step("Expand all the items under patents grid in bulkTagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.bulkGridExpandAll();
            step("Select the " + claim + " under target patent " + targetPatent1);
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.clickSelectIconOfRow(claim);
            step("Click on Save Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickSave();
            angularWait();
            step("navigate to target patent again " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);
            step("navigate to Licensees tab");
            portfolioDetailsPage.patentHeader.annotationTabs.select("Licensees");
            step("check that added licensee present under this patent's header");
            expect(portfolioDetailsPage.patentHeader.licensees.tags.getTags()).toEqual([licensees[0]]);


        });

       
        // select all claims from bulk tagging and tag
        it("verify bulktagging to all patents under portfolio", function () {
           
            step("Navigate to the target Patent1 " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);            
            step("navigate to licensees tab");
            portfolioDetailsPage.patentHeader.annotationTabs.select("Licensees");           
            step("Delete all Licensees available in the target patent");
            portfolioDetailsPage.patentHeader.licensees.tags.deleteAll();

            step("Navigate to the target Patent2 " + targetPatent2);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent2);            
            step("navigate to licensees tab");
            portfolioDetailsPage.patentHeader.annotationTabs.select("Licensees");           
            step("Delete all Licensees available in the target patent");
            portfolioDetailsPage.patentHeader.licensees.tags.deleteAll();

            step("Navigate to the source Patent " + sourcePatent);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(sourcePatent);            
            step("navigate to licensees tab");
            portfolioDetailsPage.patentHeader.annotationTabs.select("Licensees");           
            step("Delete all Licensees available in the source patent");
            portfolioDetailsPage.patentHeader.licensees.tags.deleteAll();

            step("Add a licensee: "+licensee+" to source patent: "+sourcePatent);
            portfolioDetailsPage.patentHeader.licensees.searchSelect.select(licensee); 
            
            step("Click the bulk-tagging icon at claim header to open bulkTagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.openBulkTaggingModal();
            step("Select the licensee: "+licensee+"  for bulk tagging");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.selectToggleOfTag(licensee);
            step("Click on the Next Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickNext();
            step("Expand all the items under patents grid in bulkTagging modal");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.bulkGridExpandAll();
            step("Click the Select All tick in Bulk grid");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.bulkGrid.selectAllRows();
            step("Click on Save Button");
            portfolioDetailsPage.patentClaims.bulkTaggingModal.clickSave();
            angularWait();

            // Checking tags under target patent 1
            step("navigate to target patent 1 " + targetPatent1);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent1);            
            step("navigate to Licensees tab");
            portfolioDetailsPage.patentHeader.annotationTabs.select("Licensees");
            step("check that added licensee present under this patent's header");
            expect(portfolioDetailsPage.patentHeader.licensees.tags.getTags()).toEqual([licensee]);

            //checking Licensees under target patent2
            step("navigate to target patent 1 " + targetPatent2);
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(targetPatent2);            
            step("navigate to Licensees tab");
            portfolioDetailsPage.patentHeader.annotationTabs.select("Licensees");
            step("check that added licensee present under this patent's header");
            expect(portfolioDetailsPage.patentHeader.licensees.tags.getTags()).toEqual([licensee]);
                      

        });
    });




});