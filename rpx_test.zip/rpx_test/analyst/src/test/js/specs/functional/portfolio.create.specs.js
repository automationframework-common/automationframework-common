var menu = require("../../pages/menu.partial"),
    homePage = require("../../pages/home.page"),
    loginPage = require("../../pages/login.page"),
    portfolioCreateModal = require("../../pages/modals/create.portfolio.modal"),
    portfolioDetailsPage = require("../../pages/portfolio.details.page");

var date = new Date();
var path = require("path");

var uploadFilePath = "./../../resources/portfolio_create.csv";

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe("From Portfolio Menu", function () {
    beforeEach(function () {
        step("Go to Home page");
        to(homePage);
        step("Click on the New + sub item from Portfolio menu");
        menu.dropDown("Portfolio").item("New +");
    });

    it("should be able to create new portfolio from copy paste option", function () {
        var portfolioName = "Auto_CopyPaste_Portfolio" + "_" + date.getDate() + "_" + date.getTime();
        var assetNumber = "US 5,975,403 A1";
        portfolioCreateModal.createFromCopyPaste(portfolioName, assetNumber);
        at(portfolioDetailsPage);
        expect(portfolioDetailsPage.title.getText()).toEqual(portfolioName);
        expect(portfolioDetailsPage.patentList.grid.getFirstPageColumn("Patent Number"))
            .toEqual([assetNumber]);
    });

    it("should be able to create new portfolio from upload option", function () {
        var portfolioName = "Auto_Upload_Portfolio" + "_" + date.getDate() + "_" + date.getTime();
        var assetNumbers = ["US 9,217,541 B2", "US 5,715,080 A1"];
        portfolioCreateModal.createFromUpload(portfolioName, path.resolve(__dirname, uploadFilePath));
        at(portfolioDetailsPage);
        expect(portfolioDetailsPage.title.getText()).toEqual(portfolioName);
        expect(portfolioDetailsPage.patentList.grid.getFirstPageColumn("Patent Number"))
            .toEqual(assetNumbers);
    });
});