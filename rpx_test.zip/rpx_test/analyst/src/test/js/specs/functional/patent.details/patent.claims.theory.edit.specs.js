var using = require("jasmine-data-provider");

var loginPage = require("../../../pages/login.page"),
    patentDetailsPage = require("../../../pages/patent.details.page"),
    patentClaims = require("../../../pages/patent.claims");

var theoryModal = require("../../../pages/modals/theory.modal");

var using = require('jasmine-data-provider');

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe("Patent Details", function () {

    var patId = "5896522" ;
    
    // var firstClaim = "198277991", secondClaim = "198277992";

    //Use patnum in navigation url , claim numbers. Slash at end used for Proper url formation
    var patNum = "US 5,985,712 A";
    var firstClaim = "1/", secondClaim = "2/";
    it("should not display theories created in one claim to another claim", function () {
        step("Navigate to first claim");
        to(patentDetailsPage, [patNum, firstClaim]);
        step("Delete existing theory tags and theory for first claim");
        patentClaims.deleteAllTheoryTags();
        step("Add a theory to first claim");
        patentClaims.claimsTheoryTab.add({ "theory": "test theory 1" });
        step("Navigate to second claim");
        to(patentDetailsPage, [patNum, secondClaim]);
        step("Select Theory tab and verify that tags are not displayed");
        patentClaims.claimTabs.select("Theory");
        expect(patentClaims.claimsTheoryTab.tags.getTags()).toEqual([]);
    });

    describe("Tech tags", function () {
        var theoryData = { theory: "tt_test" };
        var techTagsAdded = ["Modem"],expTagsAdded=['Networking > Cable > Modem'];

        beforeEach(function () {
            step("Navigate to patents details claim");
            to(patentDetailsPage, [patNum, firstClaim]);
            step("Delete all tech tags from technology tab");
            patentClaims.deleteAllTechnologyTags();
            step("Add tech tags in technology tab: " + techTagsAdded);
            patentClaims.claimsTechnologyTab.searchSelect.select(techTagsAdded);

            step("Delete all theory tags");
            patentClaims.deleteAllTheoryTags();
        });

        it("added from Technology tab should be reflected in theory modal", function () {
            step("Add a theory, data: " + JSON.stringify(theoryData));
            patentClaims.claimsTheoryTab.add(theoryData);
            step("Click on the created theory to load the modal");
            patentClaims.claimsTheoryTab.tags.clickTag(theoryData["theory"]);
            
            step("Verify that tech tags added from technology tab are displayed in the modal");
            expect(theoryModal.getTechTags().then(function (data) {
                return data["all"];
            })).toEqual(expTagsAdded);
        // expect(theoryModal.getUnselectedTags()).toEqual(expTagsAdded);
        });
    });

    describe("PRCs", function () {
        var theoryData = { theory: "prc_test" };
        var prcsAdded = ["Alphabet Inc.", "Tesla Motors Incorporated"]

        beforeEach(function () {
            step("Navigate to patent details claim");
            to(patentDetailsPage, [patNum, firstClaim]);
            step("Delete all existing PRCs");
            patentClaims.deleteAllPrcTags();
            step("Add the PRCs from PRC tab: " + prcsAdded);
            patentClaims.claimsPrcTab.searchSelect.select(prcsAdded);

            step("Delete all theory tags");
            patentClaims.deleteAllTheoryTags();
        });

        it("added from PRC tab should be reflected in theory modal", function () {
            step("Add a theory, data: " + JSON.stringify(theoryData));
            patentClaims.claimsTheoryTab.add(theoryData);
            step("Click on the created theory to load the modal");
            patentClaims.claimsTheoryTab.tags.clickTag(theoryData["theory"]);
            angularWait();
            step("Verify that tech tags added from technology tab are displayed in the modal");
            expect(theoryModal.getPrcs().then(function (data) {
                return data["all"];
            })).toEqual(prcsAdded);
        });
    });

    describe("claim", function () {
        var patentId = "15736461",patNum="US 9,546,212 B2", patentClaim = "344225529" ,patentClaimNum ="1/";
        beforeEach(function () {
            addArgument("pat_claim", patNum + "_" + patentClaim);
            step("Navigate to patent details claim");
            to(patentDetailsPage, [patNum, patentClaimNum]);

            step("Remove all technology tags");
            patentClaims.deleteAllTechnologyTags();
            step("Remove all PRC tags");
            patentClaims.deleteAllPrcTags();
        });

        var theoryCreateData = [
            {
                description: "should be able to create theory with theory name",
                data: {
                    theory: "thy1"
                }
            },
            {
                description: "should be able to create theory with theory name and credibility",
                data: {
                    theory: "th_cr",
                    credibility: "testc"
                }
            },
            {
                description: "should be able to create theory with theory name, credibility and PRC",
                data: {
                    theory: "th_cr_prc",
                    credibility: "test c",
                    prcs: [
                        {
                            name: "Alphabet Inc.",
                            claimCharted: true,
                            rating: "B9",
                            eou: "test eou"
                        }
                    ]
                }
            },
            {
                description: "should be able to create theory with theory name, credibility, PRC and Tech tags",
                data: {
                    theory: "th_cr_prc_tt",
                    credibility: "test c",
                    prcs: [
                        {
                            name: "Tesla Motors Incorporated",
                            claimCharted: true,
                            rating: "A7",
                            eou: "test eou"
                        }
                    ],
                    techTags: ["Storage Storage networking"]
                }
            }
        ];
        using(theoryCreateData, function (tcData) {
            it(tcData["description"], function () {
                var data = tcData["data"];
                var theory = data["theory"],
                    credibility = data["credibility"],
                    prcs = data["prcs"],
                    techTags = data["techTags"];


                if (techTags != undefined) {
                    step("From technology tab add the following tech tag: " + techTags[0]);
                    patentClaims.claimTabs.select("Technology");
                    patentClaims.claimsTechnologyTab.searchSelect.select(techTags[0]);
                }

                step("Add new theory: " + JSON.stringify(data));
                patentClaims.addTheory(data);
                step("Verify the data from created theory");
                patentClaims.claimsTheoryTab.tags.getData().then(function (value) {
                    assertTheories(value[0], data);
                }).catch(function (err) {
                    expect(err).toBeNull();
                });
            });
        });

        var theoryEditData = {
            createData: {
                theory: "1theory",
                credibility: "yes"
            },
            editData: {
                theory: "1theoryedit",
                credibility: "yesedited"
            }
        };
        it("should be able to edit the theory", function () {
            var createData = theoryEditData["createData"];
            var editData = theoryEditData["editData"];

            step("Add theory: " + JSON.stringify(createData));
            patentClaims.addTheory(createData);
            step("Click on the created theory to open the modal");
            patentClaims.claimsTheoryTab.tags.clickTagLink(0);
            step("Edit the theory from modal: " + JSON.stringify(editData));
            theoryModal.addTheory(editData);

            step("Verify the data for the edited theory");
            patentClaims.claimsTheoryTab.tags.getData().then(function (value) {
                assertTheories(value[0], editData);
            }).catch(function (err) {
                expect(err).toBeNull();
            });
        });

        it("should display PRC added from theory tab in PRC tab", function () {
            var theoryWithPRCs = {
                theory: "prc_from_theory",
                prcs: [
                    {
                        name: "Tesla Motors Incorporated",
                        claimCharted: true,
                        rating: "A7",
                        eou: "test eou"
                    }
                ]
            };
            var expectedPRCs = ["Tesla Motors Incorporated"];

            step("Add theory: " + JSON.stringify(theoryWithPRCs));
            patentClaims.addTheory(theoryWithPRCs);
            step("Select PRC tab and verify the PRC");
            patentClaims.claimTabs.select("PRC");
            expect(patentClaims.claimsPrcTab.tags.getTags()).toEqual(expectedPRCs);
        });

        it("should not delete PRCs from PRC tab when theories with PRCs are deleted", function() {
            var theoryData = {
                theory: "theory_with_prc",
                prcs: [
                    {
                        name: "Tesla Motors Incorporated",
                        claimCharted: true,
                        rating: "A7",
                        eou: "test eou"
                    }
                ]
            };
            var expectedPRCs = ["Tesla Motors Incorporated"];

            step("Add theory: " + JSON.stringify(theoryData));
            patentClaims.addTheory(theoryData);
            step("Delete the create theory");
            patentClaims.deleteAllTheoryTags();
            step("Select PRC tab and verify that PRC is not deleted");
            patentClaims.claimTabs.select("PRC");
            expect(patentClaims.claimsPrcTab.tags.getTags()).toEqual(expectedPRCs);           
        });

        it("should be able to add multiple theories", function () {
            var theory1 = {
                theory: "theory_1"
            };

            var theory2 = {
                theory: "theory_2"
            };

            step("Delete all theory tags");
            patentClaims.deleteAllTheoryTags();   
            step("Add theory: " + JSON.stringify(theory1));         
            patentClaims.claimsTheoryTab.add(theory1);
            step("Add theory: " + JSON.stringify(theory2));
            patentClaims.claimsTheoryTab.add(theory2);
            step("Verify that multiple theories are displayed");
            expect(patentClaims.claimsTheoryTab.tags.getTags()).toEqual(["theory_1", "theory_2"]); 
        });

        it("should be able to add duplicate theories", function () {
            var duplicateTheory = {
                theory: "duplicateTheory"
            };

            step("Delete all theory tags");
            patentClaims.deleteAllTheoryTags();   
            step("Add theory: " + JSON.stringify(duplicateTheory));         
            patentClaims.claimsTheoryTab.add(duplicateTheory);
            step("Add theory: " + JSON.stringify(duplicateTheory));
            patentClaims.claimsTheoryTab.add(duplicateTheory);
            step("Verify that duplicate theories are displayed");
            expect(patentClaims.claimsTheoryTab.tags.getTags()).toEqual(["duplicateTheory", "duplicateTheory"]); 
        });

        it("should display 'No Theories Found' after deleting theories", function () {
            step("Delete all theory tags");
            patentClaims.deleteAllTheoryTags();
            step("Verify that 'No Theories Found' message is displayed");
            expect(patentClaims.claimsTheoryTab.noTags.getText()).toEqual("No Theories Found");
        });
    });
});

//TODO enhance the assert to handle multiple PRCs and TechTags
//asserts the first record from PRCs and Tech Tags
var assertTheories = function (actual, expected) {
    expect(actual["theory"]).toEqual(expected["theory"]);

    var credibility = (expected["credibility"] == undefined ? '' : expected["credibility"]);
    expect(actual["credibility"]).toEqual(credibility);

    var expPrcs = (expected["prcs"] == undefined ? [] : [expected["prcs"][0]["name"]]);
    expect(actual["prcs"]["selected"]).toEqual(expPrcs);

    var expTechTags = (expected["techTags"] == undefined ? [] : expected["techTags"]);
    expect(actual["techTags"]["selected"]).toEqual(expTechTags);
};