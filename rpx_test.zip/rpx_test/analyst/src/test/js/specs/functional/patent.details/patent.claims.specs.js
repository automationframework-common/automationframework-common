require("../../../helpers/custom.matcher.helper");

var loginPage = require("../../../pages/login.page"),
    patentDetailsPage = require("../../../pages/patent.details.page"),
    patentClaims = require("../../../pages/patent.claims");

var using = require('jasmine-data-provider');

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe("patent details", function () {
    describe("claims", function () {
        var patId = "5158899";
        var patNum = "US 6,418,471 B1";
        beforeAll(function () {
           // to(patentDetailsPage, patId);
          // Changing URL navigation using patnum for UserStory : 1720
          to(patentDetailsPage, patNum);
        });
        beforeEach(function () {
            step("Navigate to patent details page: " + patNum);
        });

        it("should display the dependant claims on clicking Show Dependent Claims", function () {
            step("Click on Show dependent claims link");
            patentDetailsPage.patentClaims.showDependentClaims(0);
            step("Verify that dependent claims are displayed");
            expect(patentDetailsPage.patentClaims.getDependentClaimsCount(0)).toEqual(2);
        });

        it("should display hide the dependent claims on clicking hide dependent claims", function () {
            step("Click on hide dependent claims link");
            patentDetailsPage.patentClaims.hideDependentClaims(0);
            step("Verify that dependent claims are not displayed");
            expect(patentDetailsPage.patentClaims.getDependentClaimsCount(0)).toEqual(0);
        });

        describe("edit", function () {
            var actStarRatings;
            beforeAll(function () {
                patentDetailsPage.patentClaims.clickClaim(0);
                patentDetailsPage.patentClaims.claimStarRating.getRatings().then(function (starRatings) {                    
                    actStarRatings = starRatings;
                });
            });
            beforeEach(function () {
                step("Click on the first claim");
            });

            it("should highlight the terms on clicking enable term definition", function () {
                step("Click on the Enable Term Definition icon");
                patentDetailsPage.patentClaims.termDefinitions.click();
                angularWait();
                step("Verify that terms are highlighted");
                patentDetailsPage.patentClaims.highLights.count().then(function (count) {
                    expect(count > 1).toEqual(true, "Terms are not highlighted");
                });
            });

            it("should not highlight the terms on clicking disable term definition", function () {
                step("Click on the Disable Term Definition icon");
                patentDetailsPage.patentClaims.termDefinitions.click();
                angularWait();
                step("Verify that terms are not highlighted");
                patentDetailsPage.patentClaims.highLights.count().then(function (count) {
                    expect(count).toEqual(0, "Terms are not highlighted after enable term definitions");
                });
            });

            it("should display stripped pat num and the claim displayed in the breadcrumb", function () {
                step("Verify the stripped pat num and claim number from breadCrumb");
                expect(patentDetailsPage.patentClaims.breadcrumbsPatNum.getText()).toEqual("6,418,471");
                expect(patentDetailsPage.patentClaims.breadcrumbsClaimNo.getText()).toEqual("CLAIM - 1");
            });

            it("should have Open Patent Reference Icon displayed", function () {
                step("Verify that Open Patent Reference dialog icon is displayed");
                expect(patentDetailsPage.patentClaims.patentReferenceIcon.isDisplayed())
                    .toEqual(true, "Open Patent Reference Icon is not displayed");
            });

            it("should have Priority Date displayed", function () {
                step("Verify the priority date that is displayed");
                expect(patentDetailsPage.patentClaims.priorityDate.link.getText())
                    .toEqual("10/06/1997");
            });

            it("should have Representative Claim option displayed in checkbox", function () {
                step("Verify the representative claim option displayed");
                expect(patentDetailsPage.patentClaims.representativeClaim.isChecked())
                    .toEqual(true);
            });

            it("should have Stretch Claim option displayed in checkbox", function () {
                step("Verify the stretch claim option displayed");
                expect(patentDetailsPage.patentClaims.stretchClaim.isChecked())
                    .toEqual(false);
            });

            var expStarRatingData = [
                { "LITERAL RELEVANCE": { "actual": 3, "max": "4" } },
                { "RELEVANT COMPANIES": { "actual": 1, "max": "3" } },
                { "PRIORITY": { "actual": 2, "max": "3" } },
                { "DETECTION": { "actual": 2, "max": "3" } },
                { "CLAIM SIMPLICITY": { "actual": 2, "max": "3" } },
                { "IMPORTANCE": { "actual": 2, "max": "3" } },
                { "101 ELIGIBILITY": { "actual": 2, "max": "3" } },
                { "112 DESCRIPTION": { "actual": 0, "max": "2" } },
                { "112 ENABLEMENT": { "actual": 0, "max": "2" } },
                { "112 INDEFINITENESS": { "actual": 0, "max": "2" } }
            ]

            it("should have claim star ratings displayed ", function () {
                step("Verify the actual and expected claim star ratings");
                expect(actStarRatings).toEqual(expStarRatingData);
            });

            it("should have three claims tabs displayed", function () {
                step("Verify the tabs available in the claims section");
                expect(patentDetailsPage.patentClaims.claimTabs.getTabsList())
                    .toEqual(['TECHNOLOGY', 'THEORY', 'PRC']);
            });
        });
    });
});