var loginPage = require("../../../pages/login.page"),
    priorArtSearchResultsPage = require("../../../pages/prior.art.search.page");

var using = require('jasmine-data-provider');

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe("Prior Art Search - Filter", function () {
    beforeAll(function () {
        to(priorArtSearchResultsPage);
    });
    beforeEach(function () {
        step("Navigate to prior art results page");
        step("Click on filter icon from the grid to open the off screen modal");
        priorArtSearchResultsPage.openFilterSlide();
        step("Delete all existing rows in the off screen modal");
        priorArtSearchResultsPage.filterSearch.deleteAllRows();
    });

    var textRowCustomSearchData = [
        { filterName: "Text Search", searchTerm: "test" },
        { filterName: "Case Number", searchTerm: "IPR2017-01534" },
        { filterName: "Case Title", searchTerm: "709" },
        { filterName: "Patent Family Name", searchTerm: "drug" },
        { filterName: "Priorart Title", searchTerm: "Tramontano" },
        { filterName: "Priorart Title", searchTerm: "test" }
    ];

    using(textRowCustomSearchData, function (data) {
        var filterName = data["filterName"], searchTerm = data["searchTerm"];
        it("should filter prior art results with " + filterName + " filter for data: " + searchTerm, function () {
            step("Add " + filterName + " row and enter " + searchTerm + " from text row");
            // priorArtSearchResultsPage.filterSearch.textRowSearch(filterName, searchTerm);
            priorArtSearchResultsPage.filterSearch.textRowFilter(filterName, searchTerm);
            
            step("Verify that prior art results with selected filters are displayed");
            expect(priorArtSearchResultsPage.filterTags.getText()).toEqual(filterName);
        });
    });

    var checkBoxRowCustomSearchData = [
        { filterName: "Submitted From", option: "RPX" },
        { filterName: "Type", option: "Foreign Patent" },
        { filterName: "Is Instituted", option: "Yes" },
        { filterName: "Is Successfull", option: "No" },
        { filterName: "Jurisdiction", option: "PTAB" }
    ];

    using(checkBoxRowCustomSearchData, function (data) {
        var filterName = data["filterName"], option = data["option"];
        it("should filter prior art results with " + filterName + " filter for data: " + option, function () {
            step("Add " + filterName + " row and select option as " + option);
            // priorArtSearchResultsPage.filterSearch.checkBoxRowSearch(filterName, option);
            priorArtSearchResultsPage.filterSearch.checkBoxRowFilter(filterName, option);
            step("Verify that prior art results with selected filters are displayed");
            expect(priorArtSearchResultsPage.filterTags.getText()).toEqual(filterName);
        });
    });

    var dateRowCustomSearchData = [
        { filterName: "Qualification Date", fromDate: "01/18/2009", toDate: "01/18/2009" },
        { filterName: "Expiration Date", fromDate: "12/12/2015", toDate: "10/03/2015" },
        { filterName: "Filing Date", fromDate: "12/12/2015", toDate: "10/01/2017" },
        { filterName: "Issue Date", fromDate: "10/10/2014", toDate: "10/11/2015" },
        { filterName: "Priority Date", fromDate: "11/05/2001", toDate: "11/06/2010" }
    ];

    using(dateRowCustomSearchData, function (data) {
        var filterName = data["filterName"], fromDate = data["fromDate"], toDate = data["toDate"];
        it("should filter prior art results with " + filterName + " filter between dates: " + fromDate + " and " + toDate, function () {
            step("Add " + filterName + " row and select date between " + fromDate + " and " + toDate + " from date row");
            // priorArtSearchResultsPage.filterSearch.dateRowSearch(filterName, fromDate, toDate);
            priorArtSearchResultsPage.filterSearch.dateRowFilter(filterName, fromDate, toDate);
            step("Verify that prior art results with selected filters are displayed");
            expect(priorArtSearchResultsPage.filterTags.getText()).toEqual(filterName);
        });
    });

    var numericCustomSearchData = [
        { filterName: "# of Associations", type: "equals", value1: "1" },
        { filterName: "# of Claim Charts", type: "equals", value1: "0" },
        { filterName: "Analyst Sum", type: "equals", value1: "1" },
        { filterName: "PRC Count", type: "equals", value1: "3" },
        { filterName: "# of US Patents in Family", type: "equals", value1: "0" },
        { filterName: "# of Defendants", type: "equals", value1: "0" },
        { filterName: "Foreign Counterparts", type: "equals", value1: "1" },
        { filterName: "Open Continuances", type: "equals", value1: "2" },
        { filterName: "Alice Words", type: "equals", value1: "2" },
        { filterName: "Claim Originality", type: "equals", value1: "3" },
        { filterName: "Claims Length", type: "equals", value1: "1" },
        { filterName: "Defendant Score", type: "equals", value1: "1" },
        { filterName: "Examination Thoroughness", type: "equals", value1: "1" },
        { filterName: "Grant Time", type: "equals", value1: "7" },
        { filterName: "Limiting Language Score", type: "equals", value1: "0" },
        { filterName: "Litigation Likelihood", type: "equals", value1: "1" },
        { filterName: "Overall Score", type: "equals", value1: "2" },
        { filterName: "Preposition Score", type: "equals", value1: "1" },
        { filterName: "References - Backward", type: "equals", value1: "5" },
        { filterName: "References - Forward", type: "equals", value1: "6" },
        { filterName: "Shortest Claim Length", type: "equals", value1: "1" },
        { filterName: "Citations-Backward", type: "equals", value1: "3" },
        { filterName: "Citations-Forward", type: "equals", value1: "2" },
        { filterName: "Citing Assignees", type: "equals", value1: "1" },
        { filterName: "Citing Clusters", type: "equals", value1: "1" }
    ];

    using(numericCustomSearchData, function (data) {
        var filterName = data["filterName"], searchType = data["type"], value1 = data["value1"];
        it("should filter prior art results with " + filterName + " filter for data type: " + searchType, function () {
            step("Add " + filterName + " row and select " + searchType + " from numeric row");
            // priorArtSearchResultsPage.filterSearch.numericRowSearch(filterName, searchType, value1);
            priorArtSearchResultsPage.filterSearch.selectNumericFilter(filterName, searchType, value1);
            step("Verify that prior art results with selected filters are displayed");
            expect(priorArtSearchResultsPage.filterTags.getText()).toEqual(filterName);
        });
    });

    var facetCustomSearchData = [
        { filterName: "Prior Art Tech Tags", searchTerm: "Handsets" },
        { filterName: "Plaintiff", searchTerm: "IP Edge" },
        // { filterName: "Defendant", searchTerm: "AT&T, Inc." },
        { filterName: "Defendant", searchTerm: "AT&" },
        // { filterName: "Campaign", searchTerm: "Silver State Intellectual" },
        { filterName: "Campaign", searchTerm: "Silver" },
        /*{ filterName: "Accused Products", searchTerm: "iPhone 5" },*/
        // { filterName: "PRC", searchTerm: "Amazon" },
        { filterName: "PRC", searchTerm: "Ama" },
        { filterName: "Any Assignee", searchTerm: "JP Morgan" },
        { filterName: "Current Assignee", searchTerm: "Magna International" },
        { filterName: "Sponsoring Entity", searchTerm: "Nokia" },
        // { filterName: "CPC Mid Level", searchTerm: "G06Q" }, Need to move out
        { filterName: "Freeform Tags", searchTerm: "email" },
        { filterName: "IPC Class", searchTerm: "709/203" },
        { filterName: "Tech Tags", searchTerm: "Computers Laptops" },
        { filterName: "Topic Cluster", searchTerm: "web application" }
    ];

    using(facetCustomSearchData, function (data) {
        var filterName = data["filterName"], searchTerm = data["searchTerm"];
        it("should filter prior art results with " + filterName + " filter for data: " + searchTerm, function () {
            step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
            // priorArtSearchResultsPage.filterSearch.facetRowSearch(filterName, searchTerm);
            priorArtSearchResultsPage.filterSearch.selectfacetFilter(filterName, searchTerm);
            step("Verify that prior art results with selected filters are displayed");
            expect(priorArtSearchResultsPage.filterTags.getText()).toEqual(filterName);
        });
    });

    var radioCustomSearchData = [
        { filterName: "Has Representative Claim", option: "false" },
        { filterName: "Is Analyzed", option: "true" },
        { filterName: "Is Stretch Claim", option: "false" }
    ];

    using(radioCustomSearchData, function (data) {
        var filterName = data["filterName"], searchOption = data["option"];
        it("should filter prior art results with " + filterName + " filter for option: " + searchOption, function () {
            step("Add " + filterName + " row and select " + searchOption + " from radio group row");
            // priorArtSearchResultsPage.filterSearch.radioRowSearch(filterName, searchOption);
            priorArtSearchResultsPage.filterSearch.selectRadioFilter(filterName, searchOption);
            step("Verify that prior art results with selected filters are displayed");
            expect(priorArtSearchResultsPage.filterTags.getText()).toEqual(filterName);
        });
    });

    it("should filter prior art results with 'Associated to Patent' filter", function () {
        var patNum = "8331869";
        step("Search for patent number " + patNum + " from Associated to Patent text field");
        priorArtSearchResultsPage.filterSearch.associatedToPatent.enterSearchTerm(patNum);
        step("Click on done button from filter search");
        priorArtSearchResultsPage.filterSearch.doneBtn.click();
        angularWait();
        step("Verify that prior art results with selected filters are displayed");
        expect(priorArtSearchResultsPage.filterTags.getText()).toEqual("Associated to Patent");
    });
        //'Add Custom Filter (+)' option had modified to 'Filter Options'

        // Modified list of options on 17/01/2018- QA env reference{Added 2 more options "Predicted Campaigns","Predicted PRC"}
    var expCustomSearchFields = ['Filter Options', 'Priorart Title', 'Submitted From',
        'Qualification Date', 'Text Search', 'Type', '# of Associations', 'Prior Art Tech Tags',
        'Accused Products', 'Is Instituted', 'Is Successfull', 'Plaintiff', 'Defendant', 'Campaign',
        'Jurisdiction','Predicted Campaigns', 'Accused Products', 'Case Number', 'Case Title', '# of Claim Charts', '# of Defendants',
        'Analyst Sum', 'Has Representative Claim', 'Is Analyzed', 'Is Stretch Claim', 'PRC', 'PRC Count','Predicted PRC',
        '# of US Patents in Family', 'Foreign Counterparts', 'Open Continuances', 'Patent Family Name',
        'Alice Words', 'Citations-Backward', 'Citations-Forward', 'Citing Assignees', 'Citing Clusters',
        'Claim Originality', 'Claims Length', 'Defendant Score', 'Examination Thoroughness',
        'Limiting Language Score', 'Litigation Likelihood', 'Overall Score', 'Preposition Score',
        'Any Assignee', 'Current Assignee', 'Sponsoring Entity', 'CPC Mid Level', 'CPC Top Level',
        'Freeform Tags', 'IPC Class', 'Tech Tags', 'Topic Cluster', 'Expiration Date', 'Filing Date',
        'Issue Date', 'Priority Date', 'Grant Time', 'Patent Status', 'References - Backward', 'References - Forward',
        'Shortest Claim Length', 'Title'];

    xit("should have custom search options to select from", function () {
        step("Verify the options available in custom search drop down");
        expect(priorArtSearchResultsPage.filterSearch.customSearchDropDown.getAvailableOptions())
            .toEqual(expCustomSearchFields);
    });
});