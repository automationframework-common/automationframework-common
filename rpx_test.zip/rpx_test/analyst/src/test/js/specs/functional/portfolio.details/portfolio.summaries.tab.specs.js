require("../../../helpers/custom.matcher.helper");

var loginPage = require("../../../pages/login.page"),
    homePage = require("../../../pages/home.page"),
    portfolioDetailsPage = require("../../../pages/portfolio.details.page"),
    salesForceSummaryPage = require("../../../pages/salesforce.summary");

var portfolioQ = require("../../../data/queries/portfolio.queries"),
    dbHelper = require("../../../helpers/db.helper");

var using = require("jasmine-data-provider");

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
    at(homePage);
});

describe("Portfolio details", function () {
    describe("Summaries tab", function () {
        it("should have 3 sub navs to select from", function () {
            to(portfolioDetailsPage, "5917");
            step("Navigate to portfolio details and click on portfolio - summaries tab");
            portfolioDetailsPage.patentDataSubTabs.portfolio.select("Summaries");

            step("Verify the sub navs displayed for Portfolio - Summaries tab");
            expect(portfolioDetailsPage.patentDataTertirayNavs.summaries.getTabsList())
                .toEqual(['RPX', 'DEAL DATA', 'ANNOTATED PATENTS']);
        });

        describe("RPX nav", function () {
            var portfolioIdForRpxTab = "501336",
                portfolioTitleForRpxTab = "JSDQ LLC - OMA",
                analysisStatus;

            beforeAll(function () {
                to(portfolioDetailsPage, portfolioIdForRpxTab);
                portfolioDetailsPage.patentDataSubTabs.portfolio.select("Summaries");
                portfolioDetailsPage.patentDataTertirayNavs.summaries.select("RPX");

                // dbHelper.execute(portfolioQ.analysisStatus, portfolioIdForRpxTab).getSingleRow().then(function (dbData) {
                //     analysisStatus = dbData;
                // });
            });
            beforeEach(function () {
                step("Login and click on RPX nav from Portfolio - Summaries tab");
            });

            it("should have recommendation value displayed in the drop down", function () {
                step("Verify the default recommendation value in the drop down");
                expect(portfolioDetailsPage.portfolioSummariesTab.rpxTab.recommendation.getSelectedOption()).toEqual("Analyse");
            });

            it("should have recommendation field with 4 options to select from", function () {
                step("Verify the options available in the recommendation drop down");
                expect(portfolioDetailsPage.portfolioSummariesTab.rpxTab.recommendation.getAvailableOptions())
                    .toEqual(['Undefined', 'Analyse', 'Pass', 'Hold' ]);
            });

            it("should have market sector value displayed in the drop down", function () {
                step("Verify the default market sector value in the drop down");
                expect(portfolioDetailsPage.portfolioSummariesTab.rpxTab.marketSector.getSelectedOption()).toEqual("Networking");
            });

            var marketSectorOptions = ['Mobile Communications and Devices', 'Media Content and Distribution',
                'Consumer Electronics and PCs', 'E-Commerce and Software', 'Financial Services', 'Semiconductors',
                'Automotive', 'Networking', 'Medical', 'Other', 'Undefined', 'Consumer Products', 'Energy', 'Industrial',
                'Logistics', 'Manufacturing', 'Uncategorized'];

            it("should have market sector field with 17 options to select from", function () {
                step("Verify the options available in the market sector drop down");
                expect(portfolioDetailsPage.portfolioSummariesTab.rpxTab.marketSector.getAvailableOptions())
                    .toEqual(marketSectorOptions);
            });

            it("should direct the users to sales force summary page on clicking sf summary link", function () {
                step("Click on the SF summary link");
                portfolioDetailsPage.portfolioSummariesTab.rpxTab.salesForceSummaryLink.click();
                inNewWindow(function () {
                    at(salesForceSummaryPage);
                    step("Verify the title from the sales force summary page");
                    expect(salesForceSummaryPage.title.getText()).toEqual(portfolioTitleForRpxTab);
                });
            });

            describe("w/o annotations)", function () {
                var portfolioWOAnnotation;
                beforeAll(function () {
                    dbHelper.execute(portfolioQ.portfolioWOAnnotations).getSingleRow().then(function (dbData) {
                        portfolioWOAnnotation = dbData['portfolio_id'];
                        to(portfolioDetailsPage, portfolioWOAnnotation);
                        portfolioDetailsPage.patentDataSubTabs.portfolio.select("Summaries");
                        portfolioDetailsPage.patentDataTertirayNavs.summaries.select("RPX");
                    });
                });
                beforeEach(function () {
                    step("Login and click on RPX nav from Portfolio - Summaries tab");
                });

                it("should display 'No Portfolio Annotations' message for annotations", function () {
                    step("Verify that No Portfolio annotations message is displayed for portfolio w/o annotations");
                    expect(portfolioDetailsPage.portfolioSummariesTab.rpxTab.annotations.getMessage())
                        .toEqual('No Portfolio Annotations.');
                });

                it("should have 4 annotation types displayed in the create dropdown", function () {
                    step("Verify the annotation types in create drop down for portfolio w/o annotation");
                    expect(portfolioDetailsPage.portfolioSummariesTab.rpxTab.annotations.getAvailableCreateOptions())
                        .toEqual(['Executive Summary', 'Market Bullets', 'Portfolio Summary', 'Seller Research']);
                });
            });

            describe("w/ all annotation types)", function () {
                var portfolioWithAnnotations;
                beforeAll(function () {
                    dbHelper.execute(portfolioQ.portfolioWithAllAnnotations).getSingleRow().then(function (dbData) {
                        portfolioWithAnnotations = dbData['portfolio_id'];
                        to(portfolioDetailsPage, portfolioWithAnnotations);
                        portfolioDetailsPage.patentDataSubTabs.portfolio.select("Summaries");
                        portfolioDetailsPage.patentDataTertirayNavs.summaries.select("RPX");
                    });
                });
                beforeEach(function () {
                    step("Login and click on RPX nav from Portfolio - Summaries tab");
                });

                it("should have create option disabled", function () {
                    step("Verify that create options is displayed for portfolio with all annotation types");
                    expect(portfolioDetailsPage.portfolioSummariesTab.rpxTab.annotations.isCreateDisabled())
                        .toEqual(true, "Create option is not disabled for portfolio w/ all annotation types");
                });

                it("should display hidden annotations count on deselecting filters", function () {
                    step("Deselect all filter options");
                    portfolioDetailsPage.portfolioSummariesTab.rpxTab.annotations.deselectAllFilterOptions();
                    step("Verify the hidden annotation count after deselecting all filter options");
                    expect(portfolioDetailsPage.portfolioSummariesTab.rpxTab.annotations.getMessage()).toEqual('4 Portfolio Annotations Hidden.');
                });

                var annotationTypes = ['Executive Summary', 'Market Bullets', 'Portfolio Summary', 'Seller Research'];
                using(annotationTypes, function (data) {
                    it("should display '" + data + "' annotation when '" + data + "' filter is selected", function () {
                        step("De select all options from filter");
                        portfolioDetailsPage.portfolioSummariesTab.rpxTab.annotations.deselectAllFilterOptions();
                        step("Select " + data + " from the filer");
                        portfolioDetailsPage.portfolioSummariesTab.rpxTab.annotations.selectFilterOption(data);
                        step("Verify the annotation displayed");
                        portfolioDetailsPage.portfolioSummariesTab.rpxTab.annotations.getData().then(function (resultData) {
                            expect(Object.keys(resultData).length).toEqual(1);
                            expect(resultData[data]).not.toBeNull();
                        });
                    });
                });
            });
        });

        describe("Deal Data nav", function () {
            var portfolioWithDeal = "5917",
                dealDataDb,
                dealDataUI;

            beforeAll(function () {
                to(portfolioDetailsPage, portfolioWithDeal);
                portfolioDetailsPage.patentDataSubTabs.portfolio.select("Summaries");
                portfolioDetailsPage.patentDataTertirayNavs.summaries.select("Deal Data");
                dbHelper.execute(portfolioQ.dealData_m, portfolioWithDeal).getSingleRow().then(function (dbData) {
                    dealDataDb = dbData;
                    dealDataUI = portfolioDetailsPage.portfolioSummariesTab.dealTab.getDealItems();
                });
            });
            beforeEach(function () {
                step("Login and click on deal nav from Portfolio - Summaries tab");
            });

            var dealData = [
                {uiKey: "Portfolio Type", dbKey: "portfoliotype"}, {uiKey: "Seller/Broker", dbKey: "seller_broker"},
                {uiKey: "Intake Date", dbKey: "intakedate"}, {uiKey: "Priority", dbKey: "priority"},
                {uiKey: "Stage", dbKey: "stage"}, {uiKey: "Confidentiality", dbKey: "confidentiality"},
                {uiKey: "Seller Expectation(in 000's)", dbKey: "sellerexpectation"}, {uiKey: "Bids Due", dbKey: "bids_due"},
                {uiKey: "Rejected Deal Primary Reason", dbKey: "rejected_deal_primary_reason"}, {uiKey: "Reject Deal Secondary Reason", dbKey: "rejected_deal_secondary_reason"}
            ];

            using(dealData, function (data) {
                var uiKey = data["uiKey"], dbKey = data["dbKey"];
                it("should have '" + uiKey + "' displayed", function () {
                    step("Verify the deal data: " + uiKey + "displayed with database");
                    expect(dealDataUI[uiKey]).toEqual(dealDataDb[dbKey]);
                });
            });

            it("should have 'Seller Notes displayed", function () {
                var sellerNotes;
                step("Verify the seller notes displayed");
                portfolioDetailsPage.portfolioSummariesTab.dealTab.sellerNotes.getText().then(function (sellerNotes) {
                    expect(sellerNotes.startsWith(dealDataDb['seller_notes'])).toBe(true, "Seller notes not as expected");
                });
            });

            it("should have 'Public Deal Notes' displayed", function () {
                step("Verify the public deal notes displayed");
                portfolioDetailsPage.portfolioSummariesTab.dealTab.publicDealNotes.getText().then(function (publicDealNotes) {
                    expect(publicDealNotes.startsWith(dealDataDb['deal_notes'])).toBe(true, "Public deal notes not as expected");
                })
            });
        });
    });
});