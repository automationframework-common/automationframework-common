var loginPage = require("../../../pages/login.page"),
    portfolioDetailsPage = require("../../../pages/portfolio.details.page");

var using = require("jasmine-data-provider");

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

var portfolioId = "501952";
describe("Portfolio details Summaries tab", function () {
    beforeAll(function () {
        to(portfolioDetailsPage, portfolioId);
        portfolioDetailsPage.patentDataSubTabs.portfolio.select("Summaries");
        portfolioDetailsPage.patentDataTertirayNavs.summaries.select("RPX");
    });
    beforeEach(function () {
        step("Login and navigate to portfolio details page and select Summaries tab");
    });
    describe("RPX nav", function () {
        it("should be able to select Recommendation value", function () {
            var recommendationOption = "Analyse";
            step("Select " + recommendationOption + " option from recommendation drop down");
            portfolioDetailsPage.portfolioSummariesTab.rpxTab.recommendation.select(recommendationOption);
            step("Verify that " + recommendationOption + " value is displayed in recommendation drop down");
            expect(portfolioDetailsPage.portfolioSummariesTab.rpxTab.recommendation.getSelectedOption())
                .toEqual(recommendationOption);
        });

        it("should be able to select Market Sector value", function () {
            var marketSectorOption = "Networking";
            step("Select " + marketSectorOption + " option from market sector drop down");
            portfolioDetailsPage.portfolioSummariesTab.rpxTab.marketSector.select(marketSectorOption);
            step("Verify that " + marketSectorOption + " value is displayed in market sector drop down");
            expect(portfolioDetailsPage.portfolioSummariesTab.rpxTab.marketSector.getSelectedOption())
                .toEqual(marketSectorOption);
        });

        var summaryAnnotationData = [
            { type: "Executive Summary", value: "Executive Summary Test"},
            { type: "Market Bullets", value: "Market Bullets Test"},
            { type: "Portfolio Summary", value: "Portfolio Summary Test"},
            { type: "Seller Research", value: "Seller Research Test"}
        ];

        using(summaryAnnotationData, function (data) {
            var annotationType = data["type"], value = data["value"];
            it("should be able to create " + annotationType + " annotation", function () {
                step("Clear all existing annotations");
                portfolioDetailsPage.portfolioSummariesTab.rpxTab.annotations.clearAll();
                step("Save " + annotationType + " annotation with " + value);
                portfolioDetailsPage.portfolioSummariesTab.rpxTab.annotations.save(annotationType, value);
                step("Verify that saved annotation data is displayed");
                portfolioDetailsPage.portfolioSummariesTab.rpxTab.annotations.getData().then(function (annotations) {
                    expect(annotations[annotationType]).toEqual(value);
                });
            });
        });
    });
});