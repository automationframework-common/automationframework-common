var loginPage = require("../../../pages/login.page"),
    patentDetailsPage = require("../../../pages/patent.details.page"),
    patentHeader = require("../../../pages/patent.header");

var using = require("jasmine-data-provider");

var tags = require("../../../components/tags");

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe("Patent details header", function () {
    var patId = "14842305";
    var patNum = "US 9,160,547 B2";
    beforeAll(function () {
         // to(patentDetailsPage, patId);
          // Changing URL navigation using patnum for UserStory : 1720
          to(patentDetailsPage, patNum);
    });
    beforeEach(function () {
        step("Navigate to patent details page: " + patId);
    });

    describe("edit", function () {
        it("should be able to tag a sponsor as strong", function () {
            step("Select the checkbox to mark the sponsor as Strong");
            patentHeader.sponsor.edit(true);
            step("Verify that thumbs up icon is displayed for the sponsor");
            expect(patentHeader.sponsor.thumbsUp.isDisplayed())
                .toEqual(true, "Strong icon is not displayed for sponsor");
        });

        it("should be able to remove a sponsor from strong tag", function () {
            step("Click on the sponsor link and remove the Strong selection");
            patentHeader.sponsor.edit(false);
            step("Verify that the thumbs up icon is not displayed");
            expect(patentHeader.sponsor.thumbsUp.isDisplayed())
                .toEqual(false, "Strong icon is displayed for sponsor");
        });

        it("should be able to edit priority date", function () {
            var editDate = "05/21/2014";
            step("Click on the priority date and edit the date");
            patentHeader.priorityDate.edit(undefined, editDate);
            step("Verify that edited priority date is displayed");
            expect(patentHeader.priorityDate.link.getText()).toEqual(editDate);
        });

        it("should be able to tag priority date as verified", function () {
            step("Click on priority date and select the checkbox to mark priority date as verified");
            patentHeader.priorityDate.edit(true);
            step("Verify that verified icon is displayed for that priority date");
            expect(patentHeader.priorityDate.verifiedIcon.isDisplayed())
                .toEqual(true, "Verified icon is not displayed");
            step("Verify that not verified icon is not displayed for the priority date");
            expect(patentHeader.priorityDate.notVerifiedIcon.isPresent())
                .toEqual(false, "Not verified icon is present");
        });

        it("should be able to tag priority date as not verified", function () {
            step("Click on priority date and un check the checkbox to mark priority date as not verified");
            patentHeader.priorityDate.edit(false);
            step("Verify that not verified icon is displayed for the priority date");
            expect(patentHeader.priorityDate.notVerifiedIcon.isDisplayed())
                .toEqual(true, "Not verified icon is not displayed");
        });

        it("should be able to edit expiry date", function () {
            var editDate = "05/21/2034";
            step("Click on the expiry date and edit the date");
            patentHeader.expiryDate.edit(undefined, editDate);
            step("Verify that edited expiry date is displayed");
            expect(patentHeader.expiryDate.link.getText()).toEqual(editDate);
        });

        it("should be able to tag expiry date as verified", function () {
            step("Click on expiry date and select the checkbox to mark expiry date as verified");
            patentHeader.expiryDate.edit(true);
            step("Verify that verified icon is displayed for that expiry date");
            expect(patentHeader.expiryDate.verifiedIcon.isDisplayed())
                .toEqual(true, "Verified icon is not displayed");
            step("Verify that not verified icon is not displayed for the expiry date");
            expect(patentHeader.expiryDate.notVerifiedIcon.isPresent())
                .toEqual(false, "Not verified icon is present");
        });

        it("should be able to tag expiry date as not verified", function () {
            step("Click on expiry date and un check the checkbox to mark expiry date as not verified");
            patentHeader.expiryDate.edit(false);
            step("Verify that not verified icon is displayed for the expiry date");
            expect(patentHeader.expiryDate.notVerifiedIcon.isDisplayed())
                .toEqual(true, "Not verified icon is not displayed");
        });

        it("should be able to tag an inventor as strong", function () {
            step("Select the checkbox to mark the inventor as Strong");
            patentHeader.inventors.edit(0, true);
            step("Verify that thumbs up icon is displayed for the inventor");
            expect(patentHeader.inventors.thumbsUpIcon(0).isDisplayed())
                .toEqual(true, "Strong icon is not displayed for sponsor");
        });

        it("should be able to remove an inventor from strong tag", function () {
            refresh();
            step("Click on the inventor link and remove the Strong selection");
            patentHeader.inventors.edit(0, false);
            step("Verify that the thumbs up icon is not displayed");
            expect(patentHeader.inventors.thumbsUpIcon(0).isDisplayed())
                .toEqual(false, "Strong icon is displayed for sponsor");
        });
    });

    describe("annotations edit", function () {
        beforeAll(function () {
            patentHeader.annotationTabs.select("Annotations");
        });
        beforeEach(function () {
            step("Select Annotations tab from patent header edit");
        });

        var patentAnnotationsData = [
            { type: "Analysts Notes", value: "Analysts Notes Test"},
            { type: "Comparables", value: "Comparables Test"},
            { type: "Enforcement Review", value: "Enforcement Review Test"},
            { type: "File History Review", value: "File History Review Test"},
            { type: "Patent Summary", value: "Patent Summary Test"},
            { type: "SME Review", value: "SME Review Test" },
            { type: "Spec Support", value: "Spec Support Test" },
            { type: "Priority Research", value: "Priority Research Test" }
        ];

        using(patentAnnotationsData, function (data) {
            var annotationType = data["type"], value = data["value"];
            it("should be able to create " + annotationType + " annotation", function () {
                step("Clear all existing annotations");
                patentHeader.annotations.clearAll();
                step("Save " + annotationType + " annotation with " + value);
                patentHeader.annotations.save(annotationType, value);
                step("Verify that saved annotation data is displayed");
                expect( patentHeader.annotations.getData().then(function (annotations) {
                    return annotations[annotationType];
                })).toEqual(value);                
            });
        });

        it("should display 'New Association+' button on adding Priority Research annotations", function () {
            step("Clear all existing annotations");
            patentHeader.annotations.clearAll();
            step("Save Priority Research annotation");
            patentHeader.annotations.save("Priority Research", "Priority Research Test");
            step("Verify that New Association+ button is displayed");
            expect(patentHeader.priorityResearchNewAssociationBtn.isDisplayed())
                .toEqual(true, "New Association+ button is not displayed");
        });
    });

    describe("licensees edit", function () {
        beforeAll(function () {
            patentHeader.annotationTabs.select("Licensees");
            patentHeader.licensees.tags.deleteAll();
        });

        var licensee = "Alphabet Inc.";
        it("should be able to add company in licensees ", function () {
            step("Add company " + licensee + " as licensee");            
            patentHeader.licensees.searchSelect.select(licensee);
            step("Verify that added tag is displayed");
            expect(patentHeader.licensees.tags.getTags())
                .toEqual([licensee]);
        });

        var priorityDate = "12/12/2017", annotationNotes = "Test Annotation Notes";
        it("should be able to save priority date and licensees annotation to licensee", function () {
            step("Click the link from first tag");
            patentHeader.licensees.tags.clickTagLink(0);
            step("In the annotation modal, save by adding priority date and annotation notes");
            patentHeader.licensees.addAnnotationModal.save(priorityDate, annotationNotes);
            step("Click the link from first tag");
            patentHeader.licensees.tags.clickTagLink(0);
            step("Verify that saved annotation is displayed on accessing it again");
            patentHeader.licensees.addAnnotationModal.getData().then(function (value) {
                expect(value["licenseesAnnotation"].trim()).toEqual(annotationNotes);
            });
            patentHeader.licensees.addAnnotationModal.close();
            
        });
    });
});