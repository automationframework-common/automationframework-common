var loginPage = require("../../../pages/login.page"),
    sfSummaryPage = require("../../../pages/salesforce.summary");

var using = require('jasmine-data-provider');

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe("SF", function () {
    var sfId = "501673";
    beforeAll(function () {
        to(sfSummaryPage, sfId);
    });
    beforeEach(function () {
        step("Login and navigate to salesforce page");
        addArgument("salesforce id", sfId);
    });

    describe("Filter Modal", function () {
        var filterFromModalData = [
            {
                filterName: "PRC Name", filterOption: "Alpine Electronics Incorporated", expFilterTag: ["PRC Name"],
                expPrc: "29 Potentially Relevant Companies", expTechTag: "2 Tech Tags", expRepClaim: "1 Annotated Patent"
            },
            // {
            //     filterName: "Account Owner", filterOption: "Max Straube", expFilterTag: ["Account Owner"],
            //     expPrc: "61 Potentially Relevant Companies", expTechTag: "6 Tech Tags", expRepClaim: "4 Annotated Patents"
            // },
            {
                filterName: "Tech Tags", filterOption: "Comms Wireless GSM", expFilterTag: ["Tech Tags"],
                expPrc: "26 Potentially Relevant Companies", expTechTag: "8 Tech Tags", expRepClaim: "3 Annotated Patents"
            },
            // {
            //     filterName: "Type", filterOption: "Prospect", expFilterTag: ["Type"],
            //     expPrc: "129 Potentially Relevant Companies", expTechTag: "33 Tech Tags", expRepClaim: "39 Annotated Patents"
            // }
        ];
        using(filterFromModalData, function (data) {
            var filterName = data["filterName"], filterOption = data["filterOption"];
            it("should filter data based on " + filterName + " facet", function () {
                step("Open filter offscreen modal");
                sfSummaryPage.filter.openFilterOffscreen();
                step("Clear existing selected filters");
                sfSummaryPage.filter.modal.clickClearFiltersLink();
                step("Select " + filterOption + " option from " + filterName + " facet");
                sfSummaryPage.filter.modal.facetOptionsSearch(filterName, filterOption);

                assertTitles(data["expFilterTag"], data["expPrc"], data["expTechTag"], data["expRepClaim"]);
            });
        });
    });

    describe("PRC graph", function () {
        it("should display filtered data after data label selection", function () {
            step("Clear the existing filters");
            sfSummaryPage.filter.clearFilters();
            step("Select 'ZTE Corporation' from PRC Name");
            sfSummaryPage.prc.highChart.selectDataLabel("ZTE Corporation");

            assertTitles(["PRC Name"], "85 Potentially Relevant Companies", "21 Tech Tags", "25 Annotated Patents");
        });

        it("should reset the filter when data label is de selected", function () {
            step("Clear all existing filters");
            sfSummaryPage.filter.clearFilters();
            step("Deselect the selected option from PRC graph");
            sfSummaryPage.prc.highChart.selectDataLabel("ZTE Corporation");
            sfSummaryPage.prc.highChart.selectDataLabel("ZTE Corporation");

            assertTitles([], "133 Potentially Relevant Companies", "44 Tech Tags", "51 Annotated Patents");
        });
    });

    describe("PRC grid", function () {
        beforeEach(function () {
            step("Load grid view");
            sfSummaryPage.prc.loadGridView();
        });

        it("should filter data for selection from grid row", function () {
            step("Select second row from the grid view");
            sfSummaryPage.prc.grid.selectRow(1, "PRC Name"); //Nokia Corporation

            assertTitles(["PRC Name"], "37 Potentially Relevant Companies", "3 Tech Tags", "3 Annotated Patents");
        });

        it("should reset the filter when grid row is de selected", function () {
            step("De select second row( selected row ) from the grid view");
            sfSummaryPage.prc.grid.deSelectRow(1, "PRC Name"); //Nokia Corporation

            assertTitles([], "133 Potentially Relevant Companies", "44 Tech Tags", "51 Annotated Patents");
        });
    });

    describe("Tech Tags", function () {
        it("should filter data for data label selection", function () {
            step("Clear the existing filters");
            sfSummaryPage.filter.clearFilters();
            step("Select 'Software OS Mobile' from Tech tags graph");
            sfSummaryPage.techTags.highChart.selectDataLabel("Software OS Mobile");
            // angularWait();

            assertTitles(["Tech Tags"], "38 Potentially Relevant Companies", "44 Tech Tags", "5 Annotated Patents");
        });

        it("should reset the filter when data label is de selected", function () {
            step("Clear all existing filters");
            sfSummaryPage.filter.clearFilters();
            step("Deselect the selected option from 'Tech Tags' graph");
            // sfSummaryPage.techTags.highChart.selectDataLabel("Software OS Mobile");
            sfSummaryPage.techTags.highChart.selectDataLabel("Networking Cellular NodeB");

            assertTitles(["Tech Tags"], "28 Potentially Relevant Companies", "44 Tech Tags", "5 Annotated Patents");
        });
    });

    function assertTitles(filters, prcTitle, techTagTitle, repClaimTitle) {
        step("Verify filter tag, PRC, Tech Tags and Representative claims title");
        expect(sfSummaryPage.filter.tags.getText()).toEqual(filters);
        expect(sfSummaryPage.prc.title.getText()).toEqual(prcTitle);
        expect(sfSummaryPage.techTags.title.getText()).toEqual(techTagTitle);
        expect(sfSummaryPage.patentDetails.title.getText()).toEqual(repClaimTitle);
    }
});