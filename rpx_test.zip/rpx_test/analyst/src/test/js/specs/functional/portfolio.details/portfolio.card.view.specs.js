var loginPage = require("../../../pages/login.page"),
    portfolioDetailsPage = require("../../../pages/portfolio.details.page");

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe("Portfolio details - Card view", function () {
    var portfolioId = "9144";
    beforeEach(function () {
        to(portfolioDetailsPage, portfolioId);
        addArgument("page_id", portfolioId);
        step("Click on the card view icon to load card view");
        portfolioDetailsPage.patentList.view("card");
    });

    it("should display literal relevance, relevant companies, priority, detection, claim simplicity and importance ratings by default", function () {
        var expMetricKeys = ['literal_relevance_rating', 'relevant_companies_rating', 'priority_rating', 'detection_rating',
            'claim_simplicity', 'importance_rating'];
        step("Get metrics from cards and verify that default metric options are displayed");
        // assertCardMetricOptions(0, expMetricKeys);
        assertCardMetricNames(expMetricKeys);
    });
// MOdified options list. Added {"Predicted PRC","Predicted Campaigns"}. Reference QA 17/01/2018
    var metricOptions = ['Add Column (+)', '# of Claim Charts', '# of Defendants', 'Analyst Sum', 'Detection Rating',
        'Enforceability Rating', 'Has Representative Claim', 'Importance Rating', 'Is Analyzed', 'Is Stretch Claim',
        'Literal Relevance Rating', 'PRC', 'PRC Count','Predicted PRC', 'Priority Rating', 'Relevant Companies Rating', '# of US Patents in Family',
        'Foreign Counterparts', 'Open Continuances', 'Patent Family Name', 'Alice Words', 'Citations-Backward', 'Citations-Forward',
        'Citing Assignees', 'Citing Clusters', 'Claim Originality', 'Claim Simplicity', 'Claims Length', 'Defendant Score',
        'Examination Thoroughness', 'Limiting Language Score', 'Litigation Likelihood', 'Overall Score', 'Preposition Score',
        'Country Code', 'Freeform Tags', 'IPC Class', 'Tech Tags', 'Topic Cluster', 'Current Assignee', 'Sponsoring Entity',
        'Expiration Date', 'Filing Date', 'Grant Time', 'Patent Status', 'References - Backward', 'References - Forward',
        'Shortest Claim Length','Predicted Campaigns'];

    it("should have options to select from in card metrics selector", function () {
        step("Verify the metric options availabe");
        expect(portfolioDetailsPage.patentList.cards.metrics().getAvailableOptions()).toEqual(metricOptions);
    });

    it("should have Patent Number, Title, Claim, Priority and Issue date displayed after deselecting all metric options", function () {
        var cardsData;
        step("De select all the metric options");
        portfolioDetailsPage.patentList.cards.metrics().deSelectAll();
        step("Verify that Patent Number, Title, Claim, Priority and Issue dates are displayed");
        portfolioDetailsPage.patentList.cards.getData().then(function (data) {
            expect(data[0]["patent_number"]).toEqual("US 9,584,461 B2");
            expect(data[0]["patent_title"]).toEqual("Method and apparatus for transmitting electronic mail");
            expect(data[0]["claim"].includes("A method for providing e-mail communications between a recipient member of a group and a sender"))
                .toEqual(true, "Claim is not as expected");
            expect(data[0]["priority_date"]).toEqual("11/23/1999");
            expect(data[0]["issue_date"]).toEqual("02/28/2017");
        });
    });

    it("should be able to delete all metric options from modal", function () {
        step("De select all options from metrics selector");
        portfolioDetailsPage.patentList.cards.metrics().deSelectAll();
        step("Verify that there no metrics selected in the metrics selector modal");
        expect(portfolioDetailsPage.patentList.cards.metrics().getSelectedOptions()).toEqual([]);
        step("Verfiy that metrics are not displayed in cards");
        expect(portfolioDetailsPage.patentList.cards.getCardMetrics().then(function (resultArr) {
            return resultArr[0];
        })).toEqual({});
    });

    var options = ['# of Claim Charts', '# of Defendants', 'Analyst Sum', 'Detection Rating', 'Enforceability Rating',
        'Has Representative Claim', 'Importance Rating', 'Is Analyzed', 'Is Stretch Claim', 'Literal Relevance Rating', 'PRC',
        'PRC Count', 'Priority Rating', 'Relevant Companies Rating'];

    it("should display an alert message on selecting 14 options from metric selector", function () {
        deleteAndAddMetricOptions(options);
        step("Verify that alert message is displayed after selecting 14 options from modal")
        expect(portfolioDetailsPage.patentList.cards.metrics().getAlertMsg())
            .toEqual('You have reached the limit of allowed items.');
    });

    it("should display maximum of 7 options in compressed view", function () {
        var expOptionsInCompressedView = ['relevant_companies_rating', 'priority_rating', 'prc_count', 'prc',
            'literal_relevance_rating', 'is_stretch_claim', 'is_analyzed'];
        var temp_options = [ 'RELEVANT COMPANIES RATING','PRIORITY RATING','PRC COUNT','PRC','LITERAL RELEVANCE RATING','IS STRETCH CLAIM','IS ANALYZED'];

        deleteAndAddMetricOptions(options);
        step("Change the patent grid to compressed view");
        portfolioDetailsPage.patentList.compress();
        step("Verify that only 7 metric options are displayed in the compressed view");
        // assertCardMetricOptions(1, expOptionsInCompressedView);
        assertCardMetricNames(expOptionsInCompressedView);
    });

    it("should display maximum of 14 options in expanded view", function () {
        var expOptionsInExpandedView = ['relevant_companies_rating', 'priority_rating', 'prc_count', 'prc', 'literal_relevance_rating',
            'is_stretch_claim', 'is_analyzed', 'importance_rating', 'has_representative_claim', 'enforceability_rating',
            'detection_rating', 'analyst_sum', '#_of_defendants', '#_of_claim_charts'];

        step("Change the patent grid to expanded view");
        portfolioDetailsPage.patentList.expand();
        deleteAndAddMetricOptions(options);
        step("Verify that all 14 metric options are displayed in the expanded view");
        // assertCardMetricOptions(0, expOptionsInExpandedView);
        assertCardMetricNames(expOptionsInExpandedView);
    });

    it("should not be able to select more than 14 options", function () {
        var expOptions = ['relevant_companies_rating', 'priority_rating', 'prc_count', 'prc', 'literal_relevance_rating',
            'is_stretch_claim', 'is_analyzed', 'importance_rating', 'has_representative_claim', 'enforceability_rating',
            'detection_rating', 'analyst_sum', '#_of_defendants', '#_of_claim_charts'];

        step("Change the patent grid to expanded view");
        portfolioDetailsPage.patentList.expand();
        deleteAndAddMetricOptions(options);
        step("Add options more than 14 metric options");
        portfolioDetailsPage.patentList.cards.metrics().select(['Alice Words']);
        step("Verify that the displayed metric options from card should not include 15th option");
        // assertCardMetricOptions(0, expOptions);
        assertCardMetricNames(expOptions);
    });

    it("should be able to add metric options after deleting an option", function () {
        var metricOptionToBeDeleted = ["Has Representative Claim"];
        var expOptionsAfterDelete = ['relevant_companies_rating', 'priority_rating', 'prc_count', 'prc', 'literal_relevance_rating',
            'is_stretch_claim', 'is_analyzed', 'importance_rating', 'enforceability_rating', 'detection_rating', 'analyst_sum',
            '#_of_defendants', '#_of_claim_charts'
        ];
        var expOptionsAfterAdd = ['has_representative_claim', 'relevant_companies_rating', 'priority_rating', 'prc_count', 'prc',
            'literal_relevance_rating', 'is_stretch_claim', 'is_analyzed', 'importance_rating', 'enforceability_rating',
            'detection_rating', 'analyst_sum', '#_of_defendants', '#_of_claim_charts'];

        step("Change the patent grid to expanded view");
        portfolioDetailsPage.patentList.expand();
        deleteAndAddMetricOptions(options);
        step("Delete a metric option");
        portfolioDetailsPage.patentList.cards.metrics().deSelect(metricOptionToBeDeleted);
        step("Verify that deleted option is not displayed in the card");
        // assertCardMetricOptions(0, expOptionsAfterDelete);
        assertCardMetricNames(expOptionsAfterDelete);

        step("Add deleted option from metric options selector");
        portfolioDetailsPage.patentList.cards.metrics().select(metricOptionToBeDeleted);
        step("Verify that added option is displayed in the card");
        // assertCardMetricOptions(0, expOptionsAfterAdd);
        assertCardMetricNames(expOptionsAfterAdd);
        
    });

    it("should be able to load patent from card", function () {
        step("Click on first patent from the card view");
        portfolioDetailsPage.patentList.cards.loadPatent(0);
        angularWait();
        step("Verify that corresponding patent details section is loaded")
        expect(portfolioDetailsPage.patentHeader.patentNumber.getText())
            .toEqual('US 9,584,461 B2');
    });

    it("should retain the selected options on changing between views", function () {
        step("Change the patent grid to expanded view");
        portfolioDetailsPage.patentList.expand();
        deleteAndAddMetricOptions(["Tech Tags", "Analyst Sum"]);
        step("Change to grid view");
        portfolioDetailsPage.patentList.view("grid");
        step("Change to card view");
        portfolioDetailsPage.patentList.view("card");
        step("Verify that selected options are retained");
        // assertCardMetricOptions(0, ['tech_tags', 'analyst_sum']);
        assertCardMetricNames(['analyst_sum', 'tech_tags']);
    });
});

var assertCardMetricOptions = function (cardNo, expOptions) {
    expect(portfolioDetailsPage.patentList.cards.getCardMetricsNames().then(function (dataArr) {  
        console.log("DataArray: "+dataArr)      ;
        return Object.keys(dataArr[cardNo]);
        // return Object.keys(dataArr);
    })).toEqual(expOptions);
};

var assertCardMetricNames = function (expOptions){
    expect(portfolioDetailsPage.patentList.cards.getCardMetricsNames()).toEqual(expOptions);
};

var deleteAndAddMetricOptions = function (options) {
    step("De select all selected metric options");
    portfolioDetailsPage.patentList.cards.metrics().deSelectAll();
    step("Select " + options + " options from metric selector modal");
    portfolioDetailsPage.patentList.cards.metrics().select(options);
};