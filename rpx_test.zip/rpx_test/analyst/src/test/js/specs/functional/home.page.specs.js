var loginPage = require("../../pages/login.page.js"),
    homePage = require("../../pages/home.page.js"),
    portfolioDetailsPage = require("../../pages/portfolio.details.page"),
    portfolioSearchResults = require("../../pages/portfolio.results.page"),
    createPortfolioModal = require("../../pages/create.portfolio.modal"),
    searchResultsPage = require("../../pages/search.results.page");

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe('Home page', function () {
    var userName = browser.params.login.displayName;

    beforeEach(function () {
        step("Login and navigate to home page");
    });
    it('should have RPX Banner displayed', function () {
        step("Verify the RPX Banner displayed in the top nav");
        expect(homePage.bannerImage.isPresent()).toEqual(true);
    });

    it('should have user name displayed after login', function () {
        step("Verify the user name displayed in the top nav");
        expect(homePage.userLabel.getText()).toEqual('Welcome, Sharmila Renganathan');
    });

    it('should have Company name of the User displayed after login', function () {
        step("Verify the Company name of the User displayed in the top nav");
        expect(homePage.userCompanyLabel.getText()).toEqual('Company: RPX');
    });

    it('should have Dashboard Link displayed ', function () {
        step("Verify the Company name of the User displayed in the top nav");
        expect(homePage.dashBoardLink.isPresent()).toEqual(true);
    });

    it('should have Proper CopyRight Message at footer', function () {
        step("Verify the Copyright message in the footer ");
        expect(homePage.footerSection.getCopyRightText()).toEqual('Copyright © 2008-2018 RPX Corporation. All Rights Reserved.');
    });

    it('should have feedback link at footer', function () {
        step("Verify the Give Us Feedback link DISPLAYED in the footer ");
        expect(homePage.footerSection.feedBackLink.isPresent()).toEqual(true);
    });

    it('should popUp of ToS modal on clicking Terms of Service Link at footer', function () {
        step("click the Terms of Service link in the footer ");
        homePage.footerSection.clickLinkOf("Terms of Service");
        step("verify that ToS Modal is poped up by checking ToS header displayed");
        expect(homePage.footerSection.getToSHeaderText()).toEqual("RPX Analyst Beta Terms of Service");
    });
    it('- Clicking close btn of ToS pop up window shoud close the popup', function () {
        step("Click the close btn of ToS pop Up window");
        homePage.footerSection.clickCloseButton();
        step("verify that pop closed and homepage displayed back");
        expect(homePage.userLabel.isPresent()).toEqual(true);
    });
    it('should popUp of Privacy-Policy modal on clicking Terms of Service Link at footer', function () {
        step("click the Terms of Service link in the footer ");
        homePage.footerSection.clickLinkOf("Privacy Policy");
        step("verify that ToS Modal is poped up by checking ToS header displayed");
        expect(homePage.footerSection.getPrivacyPolicyHeaderText()).toEqual("RPX Privacy Policy");
    });
    it('- Clicking close btn of Privacy-Policy pop up window shoud close the popup', function () {
        step("Click the close btn of ToS pop Up window");
        homePage.footerSection.clickCloseButton();
        step("verify that pop closed and homepage displayed back");
        expect(homePage.userLabel.isPresent()).toEqual(true);
    });
    it('should redirect to RPX Corp Page on clicking RPX Corp link at footer', function () {
        step("Click RPX Corporate link in the footer ");
        homePage.footerSection.clickLinkOf("RPX Corporate");
        step("Verify the URL Loaded of RPX Corporate page");
        expect(getCurrentUrl()).toEqual("https://www.rpxcorp.com/");
        // step("Verify that RPX Corp Page loaded by checking its Header Displayed");
        // expect(homePage.footerSection.rpxCorpPageHeader.isPresent()).toEqual(true);
        to(homePage);
    });


    it("should not have recent activity displayed for first login", function () {
        step("Verify that recent portfolios section is not displayed");
        expect(homePage.recentActivity.panel.isDisplayed()).toEqual(false, "Recent portfolios displayed for first login");
    });

    describe("Recent Activity", function () {
        beforeEach(function () {
            to(homePage);
            step("Navigate to home page");
        });

        it("should have portfolio name displayed after valid portfolio search", function () {
            var searchTerm = "Pantech Bulk - OMA";

            step("Search in open portfolio with data: " + searchTerm);
            homePage.portfolioActions.openPortfolioAutoSuggest.select(searchTerm);
            at(portfolioDetailsPage);
            navigateBack();
            step("Verify that recently viewed portfolio is displayed in home page - recent activities");
            expect(homePage.recentActivity.content.getText()).toEqual(searchTerm);
        });

        it("should redirect the user to details page on accessing portolio link within panel", function () {
            var portfolioName = homePage.recentActivity.content.getText();
            step("Click on the first link from recent activities section");
            homePage.recentActivity.content.click();
            step("Verify that corresponding details page is displayed");
            at(portfolioDetailsPage);
            expect(portfolioDetailsPage.title.getText()).toEqual(portfolioName);
        });
    });

    describe("Portfolio actions", function () {
        beforeEach(function () {
            to(homePage);
            step("Navigate to home page");
        });

        it("should direct the users to search results on clicking 'View All Portfolios' button", function () {
            step("Click view all portfolios");
            homePage.portfolioActions.viewAllPortfolios();
            at(portfolioSearchResults);
            step("Verify the title from portfolio results page");
            expect(portfolioSearchResults.title.getText()).toEqual("Portfolios");
        });

        it("should display 'New Portfolio' modal on clicking 'Create New Portfolio' button", function () {
            step("Click create new portfolio button");
            homePage.portfolioActions.clickCreateNewPortfolioBtn();
            at(createPortfolioModal);
            step("Verify that new portfolio modal is displayed");
            expect(createPortfolioModal.modal.isDisplayed()).toEqual(true, "Create new portfolio modal is not displayed");
        });

        it("should direct the user to portfolio page when searched in open portfolio", function () {
            var searchTerm = "Joao - Lit";

            step("Search in open portfolio with data: " + searchTerm);
            homePage.portfolioActions.openPortfolioAutoSuggest.select(searchTerm);
            at(portfolioDetailsPage);
            step("Verify that " + searchTerm + "details page is displayed");
            expect(portfolioDetailsPage.title.getText()).toEqual(searchTerm);
        });
    });

    describe("Patent Search", function () {
        beforeEach(function () {
            to(homePage);
            step("Navigate to home page");
        });

        it("should direct the users to search results on valid patent search", function () {
            var patentNumber = "US7916648B2";

            step("Search for patent number in patent search");
            homePage.patentSearch.search(patentNumber);
            step("Verify that search results page is displayed");
            at(searchResultsPage);
            expect(searchResultsPage.title.getText()).toEqual("Search Results");
        });
    });
    // Pinned Portfollio
    describe("Pinned Portfolio", function () {
        var portfolioId = "6001", portfolioName = "Elia Data - Lit";
        beforeEach(function () {
            to(homePage);
            step("Navigate to home page");
        });

        it("- pin portfolio: " + portfolioName + " and verify it displayed in pinned portfolios", function () {
            step("Navigate to " + portfolioName + " Portfolio details page");
            to(portfolioDetailsPage, portfolioId);
            step("Select Pin to Dashboard action in portfolio Details Page");
            portfolioDetailsPage.patentList.selectActionItem("Pin to Dashboard");
            step("Navigate to Home page again");
            to(homePage);
            step("verify that " + portfolioName + " is displayed in Pinned Portfolios Pane ");
            expect(homePage.pinned_Portfolio.isPortfolioPinned(portfolioName)).toEqual(true);
        });
        it("- Unpin portfolio: " + portfolioName + " and verify it is NOT Displayed in pinned portfolios", function () {
            step("Navigate to " + portfolioName + " Portfolio details page");
            to(portfolioDetailsPage, portfolioId);
            step("Select UnPin from Dashboard action in portfolio Details Page");
            portfolioDetailsPage.patentList.selectActionItem("Unpin from Dashboard");
            step("Navigate to Home page again");
            to(homePage);
            step("verify that " + portfolioName + " is NOT Displayed in Pinned Portfolios Pane ");

            expect(homePage.pinned_Portfolio.isPortfolioPinned(portfolioName)).toEqual(false);
        });

        it("should display no pinned portfolio when all pinned portfolios are removed", function () {
            step("Unpin all the pinned portfolios displayed at home page");
            homePage.pinned_Portfolio.removeAllPinnedPortfolios();
            step("verify that No Pinned Portfolio Msg should be displayed");
            expect(homePage.pinned_Portfolio.noPortfolioTextMessage.getText()).toEqual("No Pinned Portfolios");
        });
    });
    // US Publications and Grants Section
    describe("US Publications and Grants", function () {
        beforeEach(function () {
            // to(homePage);
            step("Navigate to home page");
        });

        it("should display the US Publication Grants Section ", function () {
            step("verify that US Publications displayed is True");
            expect(homePage.uSPublicationsSection.publicationsPane.isPresent()).toEqual(true);

        });
        it("should display correct Publications value in Bar Graph for Past Years ", function () {
            pastPublications = ['329', '345', '345', '312', '231', '132'];
            step("verify the Publications Count in Graph for past years DISPLAYED CORRECTLY");
            expect(homePage.uSPublicationsSection.getDataArray('publications')).toEqual(pastPublications);


        });
        it("should display correct Grants value in Bar Graph for Past Years ", function () {
            pastGrants = ['245', '248', '224', '164', '104'];
            step("verify the Grants Count in Graph for past years DISPLAYED CORRECTLY");
            expect(homePage.uSPublicationsSection.getDataArray('grants')).toEqual(pastGrants);
        });
        it("should display all the Download menu options in context menu ", function () {
            menus = ['Print chart', 'Download PNG image', 'Download JPEG image', 'Download PDF document', 'Download SVG vector image'];
            step("Click the Context Menu");
            homePage.uSPublicationsSection.contextMenuButton.click();
            step("verify the download options in Context Menu DISPLAYED CORRECTLY");
            expect(homePage.uSPublicationsSection.getDataArray('menuOptions')).toEqual(menus);
        });

        it("should display publications,grants in bar graph by default ", function () {
            to(homePage);
            step("Navigate to home page");
            step("verify the VISIBILITY attribut of Publications in Graph is Visble by default");
            expect(homePage.uSPublicationsSection.getVisibilityProperty('publications')).toEqual('visible');
            step("verify the VISIBILITY attribut of Grants in Graph is Visble by default");
            expect(homePage.uSPublicationsSection.getVisibilityProperty('grants')).toEqual('visible');

        });
        it("should NOT display Publications in bar graph if publications deselected   ", function () {
            step("Deselect the Publications in Bar Graph display");
            homePage.uSPublicationsSection.selectViewOf('publications', 'no');
            step("verify the VISIBILITY attribute of Publications in Graph is HIDDEN now");
            expect(homePage.uSPublicationsSection.getVisibilityProperty('publications')).toEqual('hidden');
        });
        it("should NOT display Grants in bar graph if Grants deselected   ", function () {
            step("Deselect the Grants in Bar Graph display");
            homePage.uSPublicationsSection.selectViewOf('grants', 'no');
            step("verify the VISIBILITY attribute of Grants in Graph is HIDDEN now");
            expect(homePage.uSPublicationsSection.getVisibilityProperty('grants')).toEqual('hidden');
        });
        it("-User should be able to select Pubs,Grants to view in Bar Graph if Hidden", function () {
            step("Select the Publications in Bar Graph display");
            homePage.uSPublicationsSection.selectViewOf('publications', 'yes');
            step("verify the VISIBILITY attribute of Publications in Graph is VISIBLE now");
            expect(homePage.uSPublicationsSection.getVisibilityProperty('publications')).toEqual('visible');
            step("Select the Grants in Bar Graph display");
            homePage.uSPublicationsSection.selectViewOf('grants', 'yes');
            step("verify the VISIBILITY attribute of Grants in Graph is VISIBLE now");
            expect(homePage.uSPublicationsSection.getVisibilityProperty('grants')).toEqual('visible');
        });


    });


});