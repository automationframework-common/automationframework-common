require("../../../helpers/custom.matcher.helper");

var loginPage = require("../../../pages/login.page"),
    homePage = require("../../../pages/home.page"),
    portfolioDetailsPage = require("../../../pages/portfolio.details.page");

var using = require('jasmine-data-provider');

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
    to(homePage);
});

var portfolioId = "5818" , tempId="9386";
describe("Portfolio details", function () {
    beforeAll(function () {
        to(portfolioDetailsPage, portfolioId);
    });
    beforeEach(function () {
        step("Login and navigate to portfolio details");
    });

    describe("Litigation tab", function () {
        beforeAll(function () {
            portfolioDetailsPage.patentDataSubTabs.portfolio.select("Litigations");
        });
        beforeEach(function () {
            step("Click on Litigations tab");
        });

        it("should have 4 sub navs to select from", function () {
            step("Verify the sub navs displayed for Portfolio - Litigations tab");
            expect(portfolioDetailsPage.patentDataTertirayNavs.litigations.getTabsList())
                .toEqual(['CAMPAIGNS', 'DEFENDANTS', 'ACCUSED PRODUCTS', 'PATENT DEFENDANTS']);
        });

        describe("Campaigns Nav", function () {
            beforeAll(function () {
                portfolioDetailsPage.patentDataTertirayNavs.litigations.select("Litigations");
            });
            beforeEach(function () {
                step("Click on Campaign sub nav");
            });

            it("should have grid with 6 headers displayed", function () {
                step("Verify the headers displayed in the grid");
                expect(portfolioDetailsPage.portfolioLitigationsTab.campaignsTab.grid.getHeaders())
                    .toEqual(['Campaign Name', 'Start Date', 'Defendant Parents', 'Most Recent Case', 'Termination Date', 'Jurisdiction']);
            });

            var campaignsSortData = [
                { column: "Campaign Name", order: "ascending", type: "string"}, { column: "Campaign Name", order: "descending", type: "string"},
                { column: "Start Date", order: "ascending", type: "date"}, { column: "Start Date", order: "descending", type: "date"},
                { column: "Defendant Parents", order: "ascending", type: "alphaNum"}, { column: "Defendant Parents", order: "descending", type: "alphaNum"},
                { column: "Most Recent Case", order: "ascending", type: "string"}, { column: "Most Recent Case", order: "descending", type: "string"},
                { column: "Termination Date", order: "ascending", type: "date"}, { column: "Termination Date", order: "descending", type: "date"},
                { column: "Jurisdiction", order: "ascending", type: "string"}, { column: "Jurisdiction", order: "descending", type: "string"}
            ];
            using(campaignsSortData, function (data) {
                var columnName = data["column"], orderBy = data["order"], type = data["type"];

                it("should have " + columnName + " sortable by " + orderBy, function () {
                    step("Sort " + columnName + " by " + orderBy + " in campaigns and verify it for sort type " + type);
                    portfolioDetailsPage.portfolioLitigationsTab.campaignsTab.grid.sort(data["column"], data["order"]);
                    expect(portfolioDetailsPage.portfolioLitigationsTab.campaignsTab.grid.getFirstPageColumn(columnName)).toEqualSort({ order: orderBy, type: type });
                });
            });

            it("should redirect the users to portal campaign details on clicking link from Campaign Name column", function () {
                step("Click on first link in Campaign Name column");
                portfolioDetailsPage.portfolioLitigationsTab.campaignsTab.grid.clickColumn("Campaign Name", 0);
                inNewWindow(function() {
                    step("Verify that campaign detail page is loaded in new tab");
                    expect(getCurrentUrl()).toContain("/campaigns/");
                });
            });

            it("should display defendant modal on clicking link from Defendant Parent link", function () {
                step("Click on first link in Defendant Parent column");
                portfolioDetailsPage.portfolioLitigationsTab.campaignsTab.grid.clickColumn("Defendant Parents", 0);
                angularWait();
                step("Verify that defendant modal is displayed");
                expect(portfolioDetailsPage.defendantModal.container.isDisplayed()).toEqual(true, "Defendant modal is not displayed");
                portfolioDetailsPage.defendantModal.close();
            });

            it("should redirect the users to portal litigation details on clicking link from Most Recent Case column", function () {
                step("Click on first link in Most Recent Case column");
                portfolioDetailsPage.portfolioLitigationsTab.campaignsTab.grid.clickColumn("Most Recent Case", 0);
                inNewWindow(function() {
                    step("Verify that litigation details page is loaded in new tab");
                    expect(getCurrentUrl()).toContain("/lit/");
                });
            });
        });
//TODO 
// Check if this describe getting executed in jenkins run
        describe("Defendants nav", function () {
            beforeAll(function () {
                portfolioDetailsPage.patentDataTertirayNavs.litigations.select("Defendants");
            });
            beforeEach(function () {
                step("Click on Defendants sub nav");
            });

            it("should have grid with 5 headers displayed", function () {
                step("Verify the headers displayed in the grid");
                expect(portfolioDetailsPage.portfolioLitigationsTab.defendantsTab.grid.getHeaders())
                    .toEqual(['Defendant Parent', 'Defendants', 'Most Recent Case', 'Start Date', 'End Date']);
            });

            it("should direct the users to portal entity page on clicking first link from Defendant Parent column", function () {
                step("Click on first link in Defendant Parent column");
                portfolioDetailsPage.portfolioLitigationsTab.defendantsTab.grid.clickColumn("Defendant Parent", 0);
                inNewWindow(function() {
                    step("Verify that entity detail page is loaded in new tab");
                    expect(getCurrentUrl()).toContain("/ent/");
                });
            });

            it("should direct the users to portal entity page on clicking first link from Defendants column", function () {
                step("Click on first link in Defendants column");
                portfolioDetailsPage.portfolioLitigationsTab.defendantsTab.grid.clickColumn("Defendants", 0);
                inNewWindow(function() {
                    step("Verify that entity detail page is loaded in new tab");
                    expect(getCurrentUrl()).toContain("/ent/");
                });
            });

            it("should direct the users to portal ITC page on clicking first link from Most Recent Case column", function () {
                step("Click on first link in Defendants column");
                portfolioDetailsPage.portfolioLitigationsTab.defendantsTab.grid.clickColumn("Most Recent Case", 0);
                inNewWindow(function() {
                    step("Verify that itc detail page is loaded in new tab");
                    expect(getCurrentUrl()).toContain("/itc/");
                });
            });

            var defendantsSortData = [
                { column: "Defendant Parent", order: "ascending", type: "string"}, { column: "Defendant Parent", order: "descending", type: "string"},
                { column: "Defendants", order: "ascending", type: "string"}, { column: "Defendants", order: "descending", type: "string"},
                { column: "Most Recent Case", order: "ascending", type: "string"}, { column: "Most Recent Case", order: "descending", type: "string"},
                { column: "Start Date", order: "ascending", type: "date"}, { column: "Start Date", order: "descending", type: "date"},
                { column: "End Date", order: "ascending", type: "date"}, { column: "End Date", order: "descending", type: "date"}
            ];

            using(defendantsSortData, function (data) {
                var columnName = data["column"], orderBy = data["order"], type = data["type"];

                it("should have " + columnName + " sortable by " + orderBy, function () {
                    step("Sort " + columnName + " by " + orderBy + " in defendants and verify it for sort type " + type);
                    portfolioDetailsPage.portfolioLitigationsTab.defendantsTab.grid.sort(data["column"], data["order"]);
                    expect(portfolioDetailsPage.portfolioLitigationsTab.defendantsTab.grid.getFirstPageColumn(columnName)).toEqualSort({ order: orderBy, type: type });
                });
            });

            var defendantSearchData = ['Honeywell International, Inc.', 'ACTi Corporation'];
            using(defendantSearchData, function (data) {
                it("should allow the user to search with defendant data: " + data, function () {
                    portfolioDetailsPage.portfolioLitigationsTab.defendantsTab.search(data);
                    expect(portfolioDetailsPage.portfolioLitigationsTab.defendantsTab.grid.getFirstPageColumn("Defendant Parent"))
                        .toContain(data);
                });
            });
        });

        describe("Accused Products nav", function () {
            beforeAll(function () {
                portfolioDetailsPage.patentDataTertirayNavs.litigations.select("Accused Products");
            });
            beforeEach(function () {
                step("Click on Accused Products sub nav");
            });

            it("should have grid with 3 headers displayed", function () {
                step("Verify the headers displayed in the grid");
                expect(portfolioDetailsPage.portfolioLitigationsTab.accusedProductsTab.grid.getHeaders())
                    .toEqual(['Defendants', 'Accused Products', 'Litigations']);
            });

            it("should direct the users to portal entity page on clicking first link from Defendants column", function () {
                step("Click on first link in Defendants column");
                portfolioDetailsPage.portfolioLitigationsTab.accusedProductsTab.grid.clickColumn("Defendants", 0);
                inNewWindow(function() {
                    step("Verify that entity detail page is loaded in new tab");
                    expect(getCurrentUrl()).toContain("/ent/");
                });
            });

            it("should direct the users to portal litigation page on clicking first link from Litigations column", function () {
                step("Click on first link in Litigations column");
                portfolioDetailsPage.portfolioLitigationsTab.accusedProductsTab.grid.clickColumn("Litigations", 0);
                inNewWindow(function() {
                    step("Verify that litigation detail page is loaded in new tab");
                    expect(getCurrentUrl()).toContain("/lit/");
                });
            });

            var accusedProductsSortData = [
                { column: "Defandants", order: "ascending", type: "string"}, { column: "Defandants", order: "descending", type: "string"},
                { column: "Accused Products", order: "ascending", type: "alphaNum"}, { column: "Accused Products", order: "descending", type: "alphaNum"},
                { column: "Litigations", order: "ascending", type: "string"}, { column: "Litigations", order: "descending", type: "string"}
            ];

            using(accusedProductsSortData, function (data) {
                var columnName = data["column"], orderBy = data["order"], type = data["type"];

                it("should have " + columnName + " sortable by " + orderBy, function () {
                    step("Sort " + columnName + " by " + orderBy + " in accused products and verify it for sort type " + type);
                    portfolioDetailsPage.portfolioLitigationsTab.accusedProductsTab.grid.sort(data["column"], data["order"]);
                    expect(portfolioDetailsPage.portfolioLitigationsTab.accusedProductsTab.grid.getFirstPageColumn(columnName)).toEqualSort({ order: orderBy, type: type });
                });
            });
        });

        describe("Patent Defendants nav", function () {
            beforeAll(function () {
                portfolioDetailsPage.patentDataTertirayNavs.litigations.select("Patent Defendants");
            });
            beforeEach(function () {
                step("Click on Patent Defendants sub nav");
            });

            it("should have grid with 2 headers displayed", function () {
                step("Verify the headers displayed in the grid");
                expect(portfolioDetailsPage.portfolioLitigationsTab.patDefendantsTab.grid.getHeaders())
                    .toEqual([ 'Patent Number', 'Defendant Parents' ]);
            });

            it("should direct the users to portal patent page on clicking first link from Patent Number column", function () {
                step("Click on first link in Patent Number column");
                portfolioDetailsPage.portfolioLitigationsTab.patDefendantsTab.grid.clickColumn("Patent Number", 0);
                inNewWindow(function() {
                    step("Verify that patent detail page is loaded in new tab");
                    expect(getCurrentUrl()).toContain("/pat/");
                });
            });

            it("should display defendant modal on clicking link from Defendant Parents link", function () {
                step("Click on first link in Defendant Parents column");
                portfolioDetailsPage.portfolioLitigationsTab.patDefendantsTab.grid.clickColumn("Defendant Parents", 0);
                angularWait();
                step("Verify that defendant modal is displayed");
                expect(portfolioDetailsPage.defendantModal.container.isDisplayed()).toEqual(true, "Defendant modal is not displayed");
                portfolioDetailsPage.defendantModal.close();
            });

            var patDefSortData = [
                { column: "Patent Number", order: "ascending", type: "string"}, { column: "Patent Number", order: "descending", type: "string"},
                { column: "Defendant Parents", order: "ascending", type: "alphaNum"}, { column: "Defendant Parents", order: "descending", type: "alphaNum"}
            ];

            using(patDefSortData, function (data) {
                var columnName = data["column"], orderBy = data["order"], type = data["type"];

                it("should have " + columnName + " sortable by " + orderBy, function () {
                    step("Sort " + columnName + " by " + orderBy + " in patent defendants and verify it for sort type " + type);
                    portfolioDetailsPage.portfolioLitigationsTab.patDefendantsTab.grid.sort(data["column"], data["order"]);
                    expect(portfolioDetailsPage.portfolioLitigationsTab.patDefendantsTab.grid.getFirstPageColumn(columnName)).toEqualSort({ order: orderBy, type: type });
                });
            });

            it("should have sub grid with 4 headers displayed", function () {
                step("Expand the first sub grid");
                portfolioDetailsPage.portfolioLitigationsTab.patDefendantsTab.grid.subGrid().expandFirst();
                step("Verify the headers displayed in the sub grid");
                expect(portfolioDetailsPage.portfolioLitigationsTab.patDefendantsTab.grid.subGrid().getHeaders())
                    .toEqual([ 'Defendant Parent', 'Most Recent Case', 'Start Date', 'End Date' ]);
            });

            var patDefSubGridSortData = [
                { column: "Defendant Parent", order: "ascending", type: "string"}, { column: "Defendant Parent", order: "descending", type: "string"},
                { column: "Most Recent Case", order: "ascending", type: "string"}, { column: "Most Recent Case", order: "descending", type: "string"},
                { column: "Start Date", order: "ascending", type: "date"}, { column: "Start Date", order: "descending", type: "date"},
                { column: "End Date", order: "ascending", type: "date"}, { column: "End Date", order: "descending", type: "date"}
            ];

            using(patDefSubGridSortData, function (data) {
                var columnName = data["column"], orderBy = data["order"], type = data["type"];

                it("should have sub grid with " + columnName + " sortable by " + orderBy, function () {
                    step("Sort " + columnName + " by " + orderBy + " in patent defendants sub grid and verify it for sort type " + type);
                    portfolioDetailsPage.portfolioLitigationsTab.patDefendantsTab.grid.subGrid().sort(data["column"], data["order"]);
                    expect(portfolioDetailsPage.portfolioLitigationsTab.patDefendantsTab.grid.subGrid().getColumn(columnName)).toEqualSort({ order: orderBy, type: type });
                });
            });
        });

    });
});