require("../../../helpers/custom.matcher.helper");

var loginPage = require("../../../pages/login.page"),
    patentDetailsPage = require("../../../pages/patent.details.page");

var using = require("jasmine-data-provider");

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe("Patent details", function () {
    describe("info", function () {
        var patId = "2456528",
            patNumber = "US 7,427,806 B2",
            patentInfoPanelData;

        beforeAll(function () {
            // Navigation using Patnumber as per UserStory : 1720
            to(patentDetailsPage, patNumber);
            patentDetailsPage.info.patentDetailsPanel.getData().then(function (panelData) {
                patentInfoPanelData = panelData;
            });
        });
        beforeEach(function () {
            step("Navigate to patent details page " + patId);
        });

        it("should have the patent number displayed as title", function () {
            step("Verify that patent number is displayed as title");
            expect(patentDetailsPage.info.title.getText()).toEqual(patNumber);
        });

        it("should have star rating displayed", function() {
            step("Verify that star value displayed");
            expect(patentDetailsPage.info.starValue.getText()).toEqual("(30.79)");
        });

        var patentInfoData = [
            { label: "STATUS", expected: "Issued Patent" }, { label: "PRIORITY DATE", expected: "01/30/2003" },
            { label: "RELATION", expected: "Parent" }, { label: "FILE DATE", expected: "07/18/2005" },
            { label: "ASSIGNEE", expected: "OSRAM Licht AG;  " }, { label: "ISSUE DATE", expected: "09/23/2008" },
            { label: "SPONSOR", expected: "Oram GmbH ;  " }, { label: "EXPIRY DATE", expected: "01/30/2023" },
            { label: "INVENTORS", expected: "Bogner, Georg ;   Braune, Bert ;   Waitl, Gunter ;   Arndt, Karlheinz ;  " }
        ];
        using(patentInfoData, function (data) {
            var label = data["label"], expected = data["expected"];
            it("should have " + label + " information displayed", function () {
                step("Verify the data displayed for " + label);
                expect(patentInfoPanelData[label]).toEqual(expected);
            });
        });

        xit("should redirect the user to portal campaign page from litigation link", function () {
            step("Click on the litigation icon link");
            patentDetailsPage.info.litigation.link.click();
            inNewWindow(function() {
                step("Verify that portal campaign page is displayed in new tab");
                expect(getCurrentUrl()).toContain("/campaigns/");
            });
        });

        xit("should display citation graph in a modal from citation link", function () {
            step("Click on the citation graph icon");
            patentDetailsPage.info.citation.link.click();
            angularWait();
            step("Verify that citation graph is displayed from modal");
            expect(patentDetailsPage.info.citation.chart.isDisplayed()).toBe(true, "Citations graph is not displayed");
            patentDetailsPage.info.citation.closeModal();
        });

        xit("should display assignments data in a modal from assignments link", function () {
            step("Click on the assignments graph icon");
            patentDetailsPage.info.timeLine.link.click();
            angularWait();
            step("Verify that assignments graph is displayed from modal");
            expect(patentDetailsPage.info.timeLine.chart.isDisplayed()).toBe(true, "Assignments graph is not displayed");
            patentDetailsPage.info.timeLine.closeModal();
        });

        xit("should display family graph in a modal from family link", function () {
            step("Click on the family graph icon");
            patentDetailsPage.info.family.link.click();
            angularWait();
            step("Verify that family graph is displayed from modal");
            expect(patentDetailsPage.info.family.chart.isDisplayed()).toBe(true, "Family graph is not displayed");
            patentDetailsPage.info.family.closeModal();
            browser.sleep(2000);
        });

        it("should have patent info grid with 4 columns", function () {
            step("Verify the columns available in patent list");
            expect(patentDetailsPage.info.grid.getHeaders()).toEqual([ 'Portfolio Name', 'Owner', 'Date Created', 'Assets' ]);
        });

        var patentInfoGridSortData = [
            { column: "Portfolio Name", order: "ascending", type: "string"}, { column: "Portfolio Name", order: "descending", type: "string"},
            { column: "Owner", order: "ascending", type: "string"}, { column: "Owner", order: "descending", type: "string"},
            { column: "Date Created", order: "ascending", type: "date"}, { column: "Date Created", order: "descending", type: "date"},
            { column: "Assets", order: "ascending", type: "numeric"}, { column: "Assets", order: "descending", type: "numeric"}
        ];
        using(patentInfoGridSortData, function (data) {
            var columnName = data["column"], orderBy = data["order"], type = data["type"];

            it("should have " + columnName + " in patent info grid sortable by " + orderBy, function () {
                step("Sort " + columnName + " by " + orderBy + " and verify for sort type " + type);
                patentDetailsPage.info.grid.sort(data["column"], data["order"]);
                expect(patentDetailsPage.info.grid.getFirstPageColumn(columnName)).toEqualSort({order: orderBy, type: type});
            });
        });
    });
});