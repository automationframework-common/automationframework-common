require("../../../helpers/custom.matcher.helper");

var loginPage = require("../../../pages/login.page"),
    priorArtSearchPage = require("../../../pages/prior.art.search.page"),
    priorArtDetailsPage = require("../../../pages/prior.art.details.page");

var using = require('jasmine-data-provider');

beforeAll(function() {
    to(loginPage);
    loginPage.loginAsAdmin();
    to(priorArtSearchPage);
});

describe("Prior Art Search", function () {

    beforeEach(function () {
        feature("Priot Art Search");
        step("From prior art search page");
    });

    it("should have button that expands the view to single column layout", function () {
        step("Expand the layout");
        priorArtSearchPage.expandLayoutBtn.click();
        angularWait();
        step("Verify collpase icon is displayed after expand");
        expect(priorArtSearchPage.collapseLayoutBtn.isDisplayed()).toEqual(true,
            "Collpase layout icon is not displayed after expanding the grid");
    });

    it("should have button that collapse the view to double column layout", function () {
        step("Collapse the layout");
        priorArtSearchPage.collapseLayoutBtn.click();
        angularWait();
        step("Verify expand icon is displayed after collpase");
        expect(priorArtSearchPage.expandLayoutBtn.isDisplayed()).toEqual(true,
            "Expand layout icon is not displayed after collapsing the laput");
    });

    describe("Grid", function () {
        it("should have five columns displayed by default", function () {
            var expectedHeaders = ["Title", "Type", "Qualification Date", "Source", "Associations"];

            step("Get and verify prior art headers");
            expect(priorArtSearchPage.priorArtGrid.getHeaders()).toEqual(expectedHeaders);
        });

        var priorArtGridSortData = [
            { column: "Title", order: "ascending", type: "alphaNum"}, { column: "Title", order: "descending", type: "alphaNum"},
            { column: "Type", order: "ascending", type: "string"}, { column: "Type", order: "descending", type: "string"},
            { column: "Qualification Date", order: "ascending", type: "date"}, { column: "Qualification Date", order: "descending", type: "date"},
            { column: "Source", order: "ascending", type: "string"}, { column: "Source", order: "descending", type: "string"},
            { column: "Associations", order: "ascending", type: "numeric"}/*, { column: "Associations", order: "descending", type: "numeric"}*/
        ];

        using(priorArtGridSortData, function (data) {
            var columnName = data["column"], orderBy = data["order"], type = data["type"];

            it("should have " + columnName + " sortable by " + orderBy, function () {
                step("Sort " + columnName + " by " + orderBy + " in prior art grid and verify it for sort type " + type);
                priorArtSearchPage.priorArtGrid.sort(data["column"], data["order"]);
                expect(priorArtSearchPage.priorArtGrid.getFirstPageColumn(columnName)).toEqualSort({ order: orderBy, type: type });
            });
        });

        it("should display Association tab on clicking grid row", function() {
            step("Click on first row from prior art grid");
            var prefix = "Prior Art:";
            priorArtSearchPage.priorArtGrid.clickRowAndGetCellData(0, "Title").then(function (cellValue) {
                step("Verify Assocaition tab is displayed");
                expect(priorArtSearchPage.paInfoAssociationTab.getText()).toEqual("ASSOCIATIONS");
                step("Verify the title in associations tab - summaries section title");
                expect(priorArtSearchPage.associationsTab.summary.title.getText()).toEqual(prefix+cellValue);
            });
        });
    });
});