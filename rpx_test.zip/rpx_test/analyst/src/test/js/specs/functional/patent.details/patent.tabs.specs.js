var loginPage = require("../../../pages/login.page"),
    patentDetailsPage = require("../../../pages/patent.details.page");

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe("Patent details", function () {
    var patId = "2456528";
        var patNum = "US 7,427,806 B2";
        beforeAll(function () {
             // to(patentDetailsPage, patId);
          // Changing URL navigation using patnum for UserStory : 1720
          to(patentDetailsPage, patNum);
        });

    describe("tabs", function () {
        
        beforeEach(function () {
            step("Navigate to patent details page: " + patId);
        });

        it("should have metrics graph displayed in Metrics tab", function () {
            step("Click on the Metrics tab");
            patentDetailsPage.patentTabs.select("Metrics");
            step("Verify that metrics graph is displayed");
            expect(patentDetailsPage.metricsTab.chart.isDisplayed())
                .toEqual(true, "Metrics graph is not displayed");
        });

        it("should have similarity graph displayed in Similarity tab", function () {
            step("Click on the Timeline tab");
            patentDetailsPage.patentTabs.select("Similarity");
            step("Verify that timeline graph is displayed");
            expect(patentDetailsPage.similarityTab.chart.isDisplayed()).toEqual(true, "Similarity graph is not displayed");
        });

        it("should have 3 tabs displayed in Prior Art tab", function () {
            step("Click on Prior Art tab");
            patentDetailsPage.patentTabs.select("Prior Art");
            step("Verfiy the tabs displayed within Prior Art section");
            expect(patentDetailsPage.priorArtTab.secondaryTabs.getTabsList()).toEqual([ 'Priority Research', 'Timeline', 'Associations' ]);
        });
    });

    describe("Viewer Tabs",function(){
        beforeEach(function () {
            step("Navigate to patent details page: " + patId);
        });
        it("should display all the tabs as expected", function () {
            step("Verify the tabs under claims pane");
            // patentDetailsPage.patentClaimTabsRightScrollArrow.click();
           expect(patentDetailsPage.patentClaimTabs.getTabsList()).toEqual(['CLAIMS','ABSTRACT','IMAGES','FAMILY','CITATIONS','ASSIGNMENTS','TRANSACTIONS','LITIGATIONS','METRICS','SIMILAR','PRIOR ART']);
        });

        it("should have Abstract content displayed in Abstract tab", function () {
            step("Click on the ABSTRACT tab");
            patentDetailsPage.patentClaimTabs.select("ABSTRACT");
            step("Verify that Abstract content is displayed");
            expect(patentDetailsPage.abstractTab.abstractContent.isDisplayed())
                .toEqual(true, "Abstract content is not displayed");
        });

        it("should have Images Thumbnails displayed in IMAGES tab", function () {
            step("Click on the IMAGES tab");
            patentDetailsPage.patentClaimTabs.select("IMAGES");
            step("Verify that Images Thumbnails is displayed");
            expect(patentDetailsPage.imagesTab.imageThumbs.isDisplayed())
                .toEqual(true, "Images Thumbnails  is not displayed");
        });

        it("should have loaded Image displayed in IMAGES tab", function () {
            step("Click on the IMAGES tab");
            patentDetailsPage.patentClaimTabs.select("IMAGES");
            step("Verify that loaded Image is displayed");
            expect(patentDetailsPage.imagesTab.loadedImage.isDisplayed())
                .toEqual(true, "loaded Image is not displayed");
        });

        it("should have NextImage Pointer displayed in IMAGES tab", function () {
            step("Click on the IMAGES tab");
            patentDetailsPage.patentClaimTabs.select("IMAGES");
            step("Verify that NextImage Pointer is displayed");
            expect(patentDetailsPage.imagesTab.nextImagePointer.isDisplayed())
                .toEqual(true, "NextImage Pointer is not displayed");
        });

        it("should have PrevImage Pointer displayed in IMAGES tab", function () {
            step("Click on the IMAGES tab");
            patentDetailsPage.patentClaimTabs.select("IMAGES");
            step("Verify that PrevImage Pointer is displayed");
            expect(patentDetailsPage.imagesTab.prevImagePointer.isDisplayed())
                .toEqual(true, "PrevImage Pointer is not displayed");
        });

        it("should have family-tree displayed in FAMILY tab", function () {
            step("Click on the FAMILY tab");
            patentDetailsPage.patentClaimTabs.select("FAMILY");
            step("Verify that family-tree is displayed");
            expect(patentDetailsPage.familyTab.familySankey.isDisplayed())
                .toEqual(true, "family-tree is not displayed");
        });
        it("should have family-header Text displayed in FAMILY tab", function () {
            step("Click on the FAMILY tab");
            patentDetailsPage.patentClaimTabs.select("FAMILY");
            step("Verify that family-header Text is displayed");
            expect(patentDetailsPage.familyTab.familyHeader.isDisplayed())
                .toEqual(true, "family-header Text is not displayed");
        });
        it("should have PatentCitation-Button displayed in CITATIONS tab", function () {
            step("Click on the CITATIONS tab");
            patentDetailsPage.patentClaimTabs.select("CITATIONS");
            step("Verify that citation-selection-Buttons is displayed");
            expect(patentDetailsPage.citationsTab.patentCitationButton.isDisplayed())
                .toEqual(true, "citation-selection-Buttons is not displayed");
        });
        it("should have FamilyReference-Button displayed in CITATIONS tab", function () {
            step("Click on the CITATIONS tab");
            patentDetailsPage.patentClaimTabs.select("CITATIONS");
            step("Verify that FamilyReference-Button is displayed");
            expect(patentDetailsPage.citationsTab.familyReferencesButton.isDisplayed())
                .toEqual(true, "FamilyReference-Button is not displayed");
        });
        it("should have Citation-Timeline displayed in CITATIONS tab", function () {
            step("Click on the CITATIONS tab");
            patentDetailsPage.patentClaimTabs.select("CITATIONS");
            step("Verify that Citation-Timeline is displayed");
            expect(patentDetailsPage.citationsTab.citationTimeline.isDisplayed())
                .toEqual(true, "Citation-Timeline is not displayed");
        });
        it("should have Citations-Filters-Grid displayed in CITATIONS tab", function () {
            step("Click on the CITATIONS tab");
            patentDetailsPage.patentClaimTabs.select("CITATIONS");
            step("Verify that Citation-Timeline is displayed");
            expect(patentDetailsPage.citationsTab.citationTimelineFiltersGrid.isDisplayed())
                .toEqual(true, "Citations-Filters-Grid is not displayed");
        });

        it("should have Assignments-Chart displayed in ASSIGNMENTS tab", function () {
            step("Click on the ASSIGNMENTS tab");
            patentDetailsPage.patentClaimTabs.select("ASSIGNMENTS");
            step("Verify that Citation-Timeline is displayed");
            expect(patentDetailsPage.assignmentsTab.assignmentChart.isDisplayed())
                .toEqual(true, "Assignments-Chart is not displayed");
        });

        it("should have Timeline-TopGraph displayed in ASSIGNMENTS tab", function () {
            step("Click on the ASSIGNMENTS tab");
            patentDetailsPage.patentClaimTabs.select("ASSIGNMENTS");
            step("Verify that Timeline-TopGraph is displayed");
            expect(patentDetailsPage.assignmentsTab.timelineTopGraph.isDisplayed())
                .toEqual(true, "Timeline-TopGraph is not displayed");
        });

        it("should have Timeline-BottomGraph displayed in ASSIGNMENTS tab", function () {
            step("Click on the ASSIGNMENTS tab");
            patentDetailsPage.patentClaimTabs.select("ASSIGNMENTS");
            step("Verify that Timeline-BottomGraph is displayed");
            expect(patentDetailsPage.assignmentsTab.timelineBottomGraph.isDisplayed())
                .toEqual(true, "Timeline-BottomGraph is not displayed");
        });

        it("should have TransactionsHistory_table_Header displayed in TRANSACTIONS tab", function () {
            step("Click on the TRANSACTIONS tab");
            patentDetailsPage.patentClaimTabs.select("TRANSACTIONS");
            step("Verify that TransactionsHistory_table_Header is displayed");
            expect(patentDetailsPage.transactionsTab.transactionsTableHeader.isDisplayed())
                .toEqual(true, "TransactionsHistory_table_Header is not displayed");
        });

        it("should have TransactionsHistory_Filters displayed in TRANSACTIONS tab", function () {
            step("Click on the TRANSACTIONS tab");
            patentDetailsPage.patentClaimTabs.select("TRANSACTIONS");
            step("Verify that TransactionsHistory_Filters is displayed");
            expect(patentDetailsPage.transactionsTab.flexrowFilter.isDisplayed())
                .toEqual(true, "TransactionsHistory_Filters is not displayed");
        });



    });
});