require("../../../helpers/custom.matcher.helper");

var loginPage = require("../../../pages/login.page"),
    homePage = require("../../../pages/home.page"),
    portfolioDetailsPage = require("../../../pages/portfolio.details.page");

var using = require("jasmine-data-provider");

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
    at(homePage);
});

var portfolioId = "9386";
var patentNumber;

describe("Portfolio details", function () {
    describe("Patent tab", function () {
        beforeAll(function () {
            to(portfolioDetailsPage, portfolioId);
            portfolioDetailsPage.patentList.grid.clickCell(0, "Patent Number").then(function (patNum) {
                patentNumber = patNum;
            });
            portfolioDetailsPage.patentDataTabs.select("Patent");
        });
        beforeEach(function () {
            step("Navigate to portfolio details and click on first row in patent list to load patent tab")
        });

        describe("Info nav", function () {
            var patentInfoPanelData;
            beforeAll(function () {
                portfolioDetailsPage.patentDataSubTabs.patent.select("Info");
                portfolioDetailsPage.patentInfoTab.patentDetailsPanel.getData().then(function (values) {
                    patentInfoPanelData = values;
                });
            });
            beforeEach(function () {
                step("Click on Info tab from Patent tab");
            });

            it("should have the patent number displayed as title", function () {
                step("Verify that patent number is displayed as title");
                expect(portfolioDetailsPage.patentInfoTab.title.getText()).toEqual(patentNumber);
            });

          it("should have star rating displayed", function() {
                step("Verify that star value displayed");
                expect(portfolioDetailsPage.patentInfoTab.starValue.getText()).toEqual("(98)");
            });

            var patentInfoData = [
                { label: "STATUS", expected: "Inactive" }, { label: "PRIORITY DATE", expected: "10/01/1993" },
                { label: "RELATION", expected: "Division of US 6,594,688 B2" }, { label: "FILE DATE", expected: "03/04/2003" },
                { label: "ASSIGNEE", expected: "Pragmatus;  " }, { label: "ISSUE DATE", expected: "10/25/2005" },
                { label: "SPONSOR", expected: "Collaboration Properties, Inc.;  " }, { label: "EXPIRY DATE", expected: "11/11/2013" },
                { label: "INVENTORS", expected: "Lauwers, J. Chris;  Ludwig, Lester F.;  " }
            ];
            using(patentInfoData, function (data) {
                var label = data["label"], expected = data["expected"];
                it("should have " + label + " information displayed", function () {
                    step("Verify the data displayed for " + label);
                    expect(patentInfoPanelData[label]).toEqual(expected);
                });
            });

            // The following cases are commented based on PAP-5294

            // it("should redirect the user to portal campaign page from litigation link", function () {
            //     step("Click on the litigation icon link");
            //     portfolioDetailsPage.patentInfoTab.litigation.link.click();
            //     inNewWindow(function() {
            //         step("Verify that portal campaign page is displayed in new tab");
            //         expect(getCurrentUrl()).toContain("/campaigns/");
            //     });
            // });

            // it("should display citation graph in a modal from citation link", function () {
            //     step("Click on the citation graph icon");
            //     portfolioDetailsPage.patentInfoTab.citation.link.click();
            //     angularWait();
            //     step("Verify that citation graph is displayed from modal");
            //     expect(portfolioDetailsPage.patentInfoTab.citation.chart.isDisplayed()).toBe(true, "Citations graph is not displayed");
            //     portfolioDetailsPage.patentInfoTab.citation.closeModal();
            // });

            // it("should display assignments data in a modal from assignments link", function () {
            //     step("Click on the assignments graph icon");
            //     portfolioDetailsPage.patentInfoTab.timeLine.link.click();
            //     angularWait();
            //     step("Verify that assignments graph is displayed from modal");
            //     expect(portfolioDetailsPage.patentInfoTab.timeLine.chart.isDisplayed()).toBe(true, "Assignments graph is not displayed");
            //     portfolioDetailsPage.patentInfoTab.timeLine.closeModal();
            // });

            // it("should display family graph in a modal from family link", function () {
            //     step("Click on the family graph icon");
            //     portfolioDetailsPage.patentInfoTab.family.link.click();
            //     angularWait();
            //     step("Verify that family graph is displayed from modal");
            //     expect(portfolioDetailsPage.patentInfoTab.family.chart.isDisplayed()).toBe(true, "Family graph is not displayed");
            //     portfolioDetailsPage.patentInfoTab.family.closeModal();
            //     browser.sleep(2000);
            // });

            it("should have patent info grid with 4 columns", function () {
                step("Verify the columns available in patent list");
                expect(portfolioDetailsPage.patentInfoTab.grid.getHeaders()).toEqual([ 'Portfolio Name', 'Owner', 'Date Created', 'Assets' ]);
            });

            var patentInfoGridSortData = [
                { column: "Portfolio Name", order: "ascending", type: "string"}, { column: "Portfolio Name", order: "descending", type: "string"},
                { column: "Owner", order: "ascending", type: "string"}, { column: "Owner", order: "descending", type: "string"},
                { column: "Date Created", order: "ascending", type: "date"}, { column: "Date Created", order: "descending", type: "date"},
                { column: "Assets", order: "ascending", type: "numeric"}, { column: "Assets", order: "descending", type: "numeric"}
            ];
            using(patentInfoGridSortData, function (data) {
                var columnName = data["column"], orderBy = data["order"], type = data["type"];

                it("should have " + columnName + " in patent info grid sortable by " + orderBy, function () {
                    step("Sort " + columnName + " by " + orderBy + " and verify for sort type " + type);
                    portfolioDetailsPage.patentInfoTab.grid.sort(data["column"], data["order"]);
                    expect(portfolioDetailsPage.patentInfoTab.grid.getFirstPageColumn(columnName)).toEqualSort({order: orderBy, type: type});
                });
            });
        });

        describe("Metrics nav", function () {
            beforeAll(function () {
                portfolioDetailsPage.patentDataSubTabs.patent.select("Metrics");
            });
            beforeEach(function () {
                step("Click on Metrics tab from Patent tab");
            });

            it("should have metrics high chart displayed", function () {
                step("Verify that metrics chart is loaded");
                expect(portfolioDetailsPage.patentMetricsTab.chart.isDisplayed()).toBe(true, "Patent metrics chart is not displayed");
            });
        });

        describe("Similarity nav", function () {
            beforeAll(function () {
                portfolioDetailsPage.patentDataSubTabs.patent.select("Similarity");
            });
            beforeEach(function () {
                step("Click on Similarity tab from Patent tab");
            });

            it("should have similarities high chart displayed", function () {
                step("Verify that similarity chart is loaded");
                expect(portfolioDetailsPage.patentSimilarityTab.chart.isDisplayed()).toBe(true, "Similarity chart is not displayed");
            });
        });

        describe("Prior Art", function () {
            beforeAll(function () {
                portfolioDetailsPage.patentDataSubTabs.patent.select("Prior Art");
            });
            beforeEach(function () {
                step("Click on Prior Art tab from Patent tab");
            });

            it("should have 3 sub navs to select from", function () {
                step("Verify the tabs available under prior art tab");
                expect(portfolioDetailsPage.patentDataTertirayNavs.priorArt.getTabsList())
                    .toEqual([ 'Priority Research', 'Timeline', 'Associations' ]);
            });
        });
    });
});