require("../../../helpers/custom.matcher.helper");

var loginPage = require("../../../pages/login.page.js"),
    homePage = require("../../../pages/home.page.js"),
    salesForceSummaryPage = require("../../../pages/salesforce.summary"),
    patentDetailsPage = require("../../../pages/patent.details.page");

var using = require('jasmine-data-provider');

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe("SF", function () {
    describe("Portfolio Summary", function () {
        var sfIdWithAllData = "20235";
        beforeAll(function () {
            to(salesForceSummaryPage, sfIdWithAllData);
        });
        beforeEach(function () {
            step("Login and navigate to sf summary page");
            addArgument("salesforce id", sfIdWithAllData);
        });

        it("should have portfolio name displayed as title", function () {
            step("Verify the title displayed in the sf summary page");
            expect(salesForceSummaryPage.title.getText()).toEqual("PB 2 OMA Test SC");
        });

        it("should have recommendation value displayed", function () {
            step("Verify the recommendation displayed");
            expect(salesForceSummaryPage.summary.recommendation.getText()).toEqual("Analyse");
        });

        it("should have market sector value displayed", function () {
            step("Verify the market sector displayed");
            expect(salesForceSummaryPage.summary.marketSector.getText()).toEqual("E-Commerce and Software");
        });

        it("should have all Licensees displayed", function () {
            step("Verify the licensees displayed");
            expect(getAllData(salesForceSummaryPage.summary.licensees).then(function (values) {
                return values.sort();
            })).toEqual(["Macy's Incorporated", "Sears Holdings Corporation", "Singapore Airlines Limited"]);
        });

        //TODO TEST CASE FOR SF WITHOUT LICENSEES

        it("should have executive summary annotation displayed in Executive Summary tab", function () {
            step("Click Executive Summary tab");
            salesForceSummaryPage.summaryTabs.select("Executive Summary");
            step("Verify the content displayed in Executive Summay tab");
            expect(salesForceSummaryPage.executiveSummaryTab.content.getText().then(function (value) {
                return value.replace(/(\r\n|\n|\r)/gm, "");
            })).toEqual("AVThis is a PB edit for Executive Summary made at 6:53PM 12-17NLNL*2");
        });

        it("should have market bullets annotation displayed in Market Bullets tab", function () {
            step("Click Market Bullets tab");
            salesForceSummaryPage.summaryTabs.select("Market Bullets");
            step("Verify the content displayed in Market Bullets tab");
            expect(salesForceSummaryPage.marketBulletsTabs.content.getText().then(function (value) {
                return value.replace(/(\r\n|\n|\r)/gm, "");
            })).toEqual("AV");
        });

        it("should have portfolio summary annotation displayed in Portfolio Summary tab", function () {
            step("Click Portfolio Summary tab");
            salesForceSummaryPage.summaryTabs.select("Portfolio Summary");
            step("Verify the content displayed in Portfolio Summary tab");
            expect(salesForceSummaryPage.portfolioSummaryTab.content.getText().then(function (value) {
                return value.replace(/(\r\n|\n|\r)/gm, "");
            })).toEqual("AV90009This is a PB edit for Phase 0 Analysis made at 6:53PM 12-17NLNL*2");
        });

        it("should have seller research annotation displayed in Seller Research tab", function () {
            step("Click Seller Research tab");
            salesForceSummaryPage.summaryTabs.select("Seller Research");
            step("Verify the content displayed in Seller Research tab");
            expect(salesForceSummaryPage.sellerResearchTab.content.getText().then(function (value) {
                return value.replace(/(\r\n|\n|\r)/gm, "");
            })).toEqual("This is a PB edit for Seller Research made at 6:53PM 12-17NLNL*2");
        });
    });

    describe("without annotations", function () {
        it("should not display the annotation tabs for portfolio without annotation", function () {
            step("Navigate to SF without annotations");
            to(salesForceSummaryPage, "500199");
            step("Verify that annotation tabs are not displayed");
            expect(salesForceSummaryPage.summaryTabs.getTabsList()).toEqual([], "Annotation tabs are displayed");
        });
    });

    describe("without Other Portfolios", function () {
        it("should not have the section displayed", function () {
            step("Navigate to SF summary without portfolios");
            to(salesForceSummaryPage, "501732");
            step("Verify that Other Portfolios section is not displayed");
            expect(salesForceSummaryPage.otherPortfolios.grid.isDisplayed()).toEqual(true);
        });
    });

    describe("with Other Portfolios", function () {
        var sfWithOtherPortfolios = "501171";

        beforeAll(function () {
            to(salesForceSummaryPage, sfWithOtherPortfolios);
        });

        it("should have four columns displayed", function () {
            step("Verify the headers in the grid");
            expect(salesForceSummaryPage.otherPortfolios.grid.getHeaders())
                .toEqual(["Opportunity Name", "Analyst Name", "Created Date", "Assets"]);
        });

        var otherPortfolioSort = [
            { column: "Opportunity Name", order: "ascending", type: "string" }, { column: "Opportunity Name", order: "descending", type: "string" },
            { column: "Analyst Name", order: "ascending", type: "string" }, { column: "Analyst Name", order: "descending", type: "string" },
            { column: "Created Date", order: "ascending", type: "date" }, { column: "Created Date", order: "descending", type: "date" },
            { column: "Assets", order: "ascending", type: "numeric" }, { column: "Assets", order: "descending", type: "numeric" }
        ];

        using(otherPortfolioSort, function (data) {
            var columnName = data["column"], orderBy = data["order"], type = data["type"];

            it("should have " + columnName + " sortable by " + orderBy, function () {
                step("Sort " + columnName + " by " + orderBy + " and verify it for sort type " + type);
                salesForceSummaryPage.otherPortfolios.grid.sort(data["column"], data["order"]);
                expect(salesForceSummaryPage.otherPortfolios.grid.getFirstPageColumn(columnName)).toEqualSort({ order: orderBy, type: type });
            });
        });
    });

    describe("with PRCs", function () {
        var sfWithPRC = "21241";
        beforeAll(function () {
            to(salesForceSummaryPage, sfWithPRC);
        });
        beforeEach(function () {
            step("Login and navigate to sales force summary page");
            addArgument("salesforce id", sfWithPRC);
        });

        it("should display the count of PRCs in the title", function () {
            step("Verify the title for PRCs");
            expect(salesForceSummaryPage.prc.title.getText()).toEqual("15 Potentially Relevant Companies");
        });

        it("should have PRC chart display as default", function () {
            step("Verify that chart display icon is selected");
            expect(salesForceSummaryPage.prc.chartDisplayIconActive.isDisplayed())
                .toBe(true, "Chart display icon is not active by default");
        });

        describe("chart", function () {
            var prcDataLabels = [
                'Sanyo', 'NXP Semiconductors NV', 'JVC Kenwood Corporation', 'Fujitsu Ten Limited',
                'Panasonic Corporation', 'LG Innotek Company Limited',
                'Continental Automotive Systems US Incorporated', 'Alpine Electronics Incorporated',
                'Harman International Industries Incorporated', 'Delphi Automotive Systems LLC',
                'Visteon Corporation', 'Pioneer Corporation', 'Mitsubishi Electric Corporation',
                'Dongbu Daewoo Electronics Corporation', 'Clarion Corporation of America'
            ];

            it("should have all the PRCs displayed", function () {
                step("Verify the PRC names displayed in the graph");
                expect(salesForceSummaryPage.prc.highChart.getDataLabels().then(function (dataLabels) {
                    return dataLabels.sort();
                })).toEqual(prcDataLabels.sort());
            });

            var prcToolTipData = [
                'Sanyo: 3 patents', 'NXP Semiconductors NV: 3 patents', 'JVC Kenwood Corporation: 3 patents',
                'Fujitsu Ten Limited: 3 patents', 'Panasonic Corporation: 3 patents', 'LG Innotek Company Limited: 3 patents',
                'Continental Automotive Systems US Incorporated: 3 patents', 'Alpine Electronics Incorporated: 3 patents',
                'Harman International Industries Incorporated: 3 patents', 'Delphi Automotive Systems LLC: 3 patents',
                'Visteon Corporation: 3 patents', 'Pioneer Corporation: 3 patents',
                'Mitsubishi Electric Corporation: 3 patents', 'Dongbu Daewoo Electronics Corporation: 3 patents',
                'Clarion Corporation of America: 3 patents'
            ];

            it("should display the number of patents in tool tips", function () {
                step("Hover on the data labels and verify tool tip data");
                expect(salesForceSummaryPage.prc.highChart.getToolTipData().then(function (data) {
                    return data.sort();
                })).toEqual(prcToolTipData.sort());
            });
        });

        describe("grid", function () {
            beforeEach(function () {
                step("Click the table display icon");
                salesForceSummaryPage.prc.gridDisplayIcon.click();
                angularWait();
            });

            it("should have 3 columns in grid displayed by default", function () {
                step("Verify the headers in the grid");
                
                // expect(salesForceSummaryPage.prc.grid.getHeaders())
                //     .toEqual(["PRC Name", "Account Owner", "Type", "Claim Charted", "Patents"]);
                expect(salesForceSummaryPage.prc.grid.getHeaders())
                .toEqual(["", "PRC Name", "CC"]);
            });

            it("should have Patents column sorted in desc by default", function () {
                step("Verify that by default 'Patents' column is sorted by default");
                expect(salesForceSummaryPage.prc.grid.getFirstPageColumn("Patents"))
                    .toEqualSort({ order: "descending", type: "numeric" });
            });

            var prcSortData = [
                { column: "PRC Name", order: "ascending", type: "string" }];//, { column: "PRC Name", order: "descending", type: "string" },
                // { column: "Account Owner", order: "ascending", type: "string" }, { column: "Account Owner", order: "descending", type: "string" },
                // { column: "Type", order: "ascending", type: "string" }, { column: "Type", order: "descending", type: "string" },
                // { column: "Claim Charted", order: "ascending", type: "string" }, { column: "Claim Charted", order: "descending", type: "string" },
                // { column: "Patents", order: "ascending", type: "numeric" }, { column: "Patents", order: "descending", type: "numeric" }
            // ];
            using(prcSortData, function (data) {
                var columnName = data["column"], orderBy = data["order"], type = data["type"];

                it("should have " + columnName + " sortable by " + orderBy, function () {
                   
                    step("Sort " + columnName + " by " + orderBy + " and verify it for sort type " + type);
                    salesForceSummaryPage.prc.grid.sort(data["column"], data["order"]);
                  
                  
                  
                    expect(salesForceSummaryPage.prc.grid.getFirstPageColumn(columnName)).toEqualSort({ order: orderBy, type: type });
              
                });
            });
        });
    });

    describe("without PRCs", function () {
        var sfWithoutPRC = "17424";
        beforeAll(function () {
            to(salesForceSummaryPage, sfWithoutPRC);
        });
        beforeEach(function () {
            step("Login and navigate to sales force summary page");
            addArgument("salesforce id", sfWithoutPRC);
        });

        it("should display title as 'No Potentially Relevant Companies' ", function () {
            step("Verify the title displayed");
            expect(salesForceSummaryPage.prc.title.getText()).toEqual("No Potentially Relevant Companies");
        });

        it("should display no data message instead of the graph/table", function () {
            step("Verify the message displayed for sf without PRCs");
            expect(salesForceSummaryPage.prc.noDataMsg.getText()).toEqual("No Data Found");
        });

        it("should not display the graph and table view icons", function () {
            step("Verify that graph and table icons are not displayed");
            expect(salesForceSummaryPage.prc.chartDisplayIcon.isDisplayed())
                .toBe(false, "Chart display icon is displayed");
            expect(salesForceSummaryPage.prc.gridDisplayIcon.isDisplayed())
                .toBe(false, "Table display icon is displayed");
        });
    });

    describe("with TechTags", function () {
        var sfWithTechTags = "21241";
        beforeAll(function () {
            to(salesForceSummaryPage, sfWithTechTags);
        });
        beforeEach(function () {
            step("Login and navigate to salesforce summary page");
            addArgument("salesforce id", sfWithTechTags);
        });

        it("should display the count of tags in title", function () {
            step("Veriy the tech tags title");
            expect(salesForceSummaryPage.techTags.title.getText())
                .toEqual("13 Tech Tags")
        });

        var techTagsLabel = [
            'Automotive Vehicle Systems', 'Computers Laptops', 'Computers Tablet',
            'Networking Cellular Radio Network Controller (RNC)', 'Networking Set top boxes (STB/DVR)',
            'Semi Communications', 'Semi DSP', 'Semi Microcontroller', 'Semi Microprocessors', 'Semi RF',
            'Services Content Radio', 'Services Content Streaming A/V', 'Services ISP (Internet service provider)'
        ];

        it("should display all the techtags in donut graph", function () {
            step("Verify the donut chart tech tag labels");
            expect(salesForceSummaryPage.techTags.highChart.getDataLabels())
                .toEqual(techTagsLabel);
        });

        it("should display the tech tags in ascending order", function () {
            step("Verify that tech tags from donut graph is displayed in ascending order");
            expect(salesForceSummaryPage.techTags.highChart.getDataLabels())
                .toEqualSort({ order: "ascending", type: "alphaNumeric" });
        });

        var techTagsToopTipData = [
            'Automotive Vehicle Systems: 7.7%(3 patents.)', 'Computers Laptops: 7.7%(3 patents.)',
            'Computers Tablet: 7.7%(3 patents.)', 'Networking Cellular Radio Network Controller (RNC): 7.7%(3 patents.)',
            'Networking Set top boxes (STB/DVR): 7.7%(3 patents.)', 'Semi Communications: 7.7%(3 patents.)',
            'Semi DSP: 7.7%(3 patents.)', 'Semi Microcontroller: 7.7%(3 patents.)', 'Semi Microprocessors: 7.7%(3 patents.)',
            'Semi RF: 7.7%(3 patents.)', 'Services Content Radio: 7.7%(3 patents.)', 'Services Content Streaming A/V: 7.7%(3 patents.)',
            'Services ISP (Internet service provider): 7.7%(3 patents.)'
        ];
        it("should have patent count & percentage displayed on hovering over data labels", function () {
            step("Verify the tool tip data from donut data");
            expect(salesForceSummaryPage.techTags.highChart.getToolTipData())
                .toEqual(techTagsToopTipData);
        });
    });

    describe("without TechTags", function () {
        var sfWithoutTechTags = "17424";
        beforeAll(function () {
            to(salesForceSummaryPage, sfWithoutTechTags);
        });
        beforeEach(function () {
            step("Login and navigate to sales force summary page");
            addArgument("salesforce id", sfWithoutTechTags);
        });

        it("should display No Tech Tags as title", function () {
            step("Verify the title displayed for sf without tech tags");
            expect(salesForceSummaryPage.techTags.title.getText()).toEqual("No Tech Tags");
        });

        it("should display No Data Found message in place of donut graph", function () {
            step("Verify the message displayed for no tech tags");
            expect(salesForceSummaryPage.techTags.noDataMsg.getText()).toEqual("No Data Found");
        });
    });

    describe("w/ annotated patents", function () {
        var sfWithAnnotatedPatents = "8599";
        beforeAll(function () {
            to(salesForceSummaryPage, sfWithAnnotatedPatents);
            angularWait();
        });
        beforeEach(function () {
            step("Login and navigate to SF page");
            addArgument("salesforce id", sfWithAnnotatedPatents);
        });

        it("should display the count of annotated patents in title", function () {
            step("Verify that title has annotated patents count");
            expect(salesForceSummaryPage.patentDetails.title.getText())
                .toEqual("40 Annotated Patents");
        });

        var expAnnotatedPatents = ['US 6,677,952 B1', 'US 6,950,350 B1', 'US 7,518,616 B1', 'US 6,744,438 B1', 'US 6,038,031 A1',
            'US 6,476,816 B1', 'US 6,577,316 B2', 'US 6,587,113 B1', 'US 6,650,333 B1', 'US 5,764,243 A1', 'US 5,764,228 A1',
            'US 5,727,192 A1', 'US 6,025,853 A1', 'US 6,154,223 A1', 'US 7,061,500 B1', 'US 5,852,372 A1','US 7,616,200 B1',
            'US 5,798,770 A1','US 6,642,928 B1','US 6,535,216 B1','US 6,184,666 B1','US 6,188,410 B1','US 6,243,107 B1',
            'US 6,157,393 A1','US 6,377,266 B1','US 6,433,787 B1','US 6,480,913 B1','US 6,948,087 B2','US 6,597,628 B1',
            'US 6,628,288 B1','US 6,667,930 B1','US 8,144,156 B1','US 7,187,383 B2','US 6,111,584 A1','US 5,835,096 A1',
            'US 5,831,637 A1','US 6,977,649 B1','US 6,683,615 B1','US 7,050,061 B1','US 7,710,425 B1'];
            
       
        it("should display all annotated patents", function () {
            step("Verify that all annotated patents are displayed");
            expect(salesForceSummaryPage.patentDetails.keyPatents.getPatents())
                .toEqual(expAnnotatedPatents);
        });

        it("should direct the users to patent details page on clicking external link", function () {
            step("Click on the external patent link from first patent");
            var patNumFromSf = salesForceSummaryPage.patentDetails.keyPatents.openPatentInNewWindow(0);
            step("In new window verify the title for that patent that is displayed");
            inNewWindow(function () {
                at(patentDetailsPage);
                expect(patentDetailsPage.info.title.getText()).toEqual(patNumFromSf);
            });
        });
    });

    describe("w/o annotated patents", function () {
        var sfWOAnnotatedPatents = "17424";
        beforeAll(function () {
            to(salesForceSummaryPage, sfWOAnnotatedPatents);
        });
        beforeEach(function () {
            step("Login and navigate to sales force summary page");
            addArgument("salesforce id", sfWOAnnotatedPatents);
        });

        it("should have title as 'No Annotated Patents'", function () {
            step("Verify the title displayed for sf without annotated patents");
            expect(salesForceSummaryPage.patentDetails.title.getText())
                .toEqual("No Annotated Patents");
        });

        it("should display message No Data Found", function () {
            step("Verify that No Data Found is displayed");
            expect(salesForceSummaryPage.patentDetails.noDataMsg.getText()).toEqual("No Data Found");
        });
    });
 // UI: Add a section for missing family members in SF summary (User story:PAP-3840)
    //Added by APV
    
    xdescribe("Missing family Members modal validations", function () {
        var portfolioWithMissingfamilyMembers = "5818";
        beforeAll(function () {
            to(salesForceSummaryPage, portfolioWithMissingfamilyMembers);
        });
        beforeEach(function () {
            step("Login and navigate to sales force summary page");
            addArgument("salesforce id", portfolioWithMissingfamilyMembers);
        });

        //Test case 1 : Check that missing family members widget present in SF's portfolio page
        it("Should display the Missing family members widget", function () {
            step("Verify Missing family members widget is displayed");
            expect(salesForceSummaryPage.missingFamilyMebersWidget.tittle.isDisplayed()).toEqual(true);

        });
        //Test case 2: Missing family members count should display correctly
        it("Should display the missing family members count correctly", function () {
            var missingMembersCount = "24";
            step("Verify Missing family members count in the widget should display correct info");
            expect(salesForceSummaryPage.missingFamilyMebersWidget.count.getText()).toEqual(missingMembersCount);

        });
        //Test case 3: Clicking the widget should open the Missing family members grid modal
        it("Clicking the widget should launch the Missing family members grid modal", function () {
            step("Verify Clicking the widget should launch the Missing family members grid modal ");
            salesForceSummaryPage.missingFamilyMebersWidget.loadModal();
            expect(salesForceSummaryPage.missingFamilyMebersGridModal.tittle.getText()).toEqual("Family Members not in Portfolio");
        });
        //Test case 4: Clicking the Patent link in the Grid Modal should take us Patent details page
        it("should direct the users to patent details page on clicking Patent link in the Grid Modal", function () {
            step("Click on the first patent link from Missing family Members Grid");
            var patentNumberInGrid = salesForceSummaryPage.missingFamilyMebersGridModal.firstPatentLink.getText();
            
            // salesForceSummaryPage.missingFamilyMebersGridModal.clickFirstPatentLink();
            step("In new window verify the title for that patent that is displayed");
            // inNewWindow(function () {
                // at(patentDetailsPage);
                patentNumberInGrid.then(function (text) {
                    // expect(salesForceSummaryPage.missingFamilyMebersGridModal.getPatentNumberColomData().length).toEqual("7");
                    
                    salesForceSummaryPage.missingFamilyMebersGridModal.pinnedSubGrid.getPatentFamilyColomElements().then(function(elems){
                        console.log("Array item: "+elems);
                    });
                    
                    
                    // salesForceSummaryPage.missingFamilyMebersGridModal.clickFirstPatentLink();
                    // expect(patentDetailsPage.patentHeader.patentNumber.getText()).toEqual(text);
                    // expect("US 9,196,800 B2").toEqual(text);
                });
                
            // });
        });

    });




});