require("../../helpers/custom.matcher.helper");

var loginPage = require("../../pages/login.page"),
    portfolioListPage = require("../../pages/portfolio.list.page"),
    portfolioDetailsPage = require("../../pages/portfolio.details.page");

var using = require('jasmine-data-provider');

beforeAll(function() {
    to(loginPage);
    loginPage.loginAsAdmin();    
});

describe("Portfolio list page", function () {
    beforeAll(function () {
        to(portfolioListPage);
    });

    it("should have title as Portfolios", function () {
        step("Verify the title in portfolio list page");
        expect(portfolioListPage.title.getText()).toEqual("Portfolios");
    });

    describe("grid", function () {
        it("should have four columns displayed by default", function () {
            var expectedHeaders = [ "Opportunity Name", "Analyst Name", "Quick Recommendation", "Patents" ];

            step("Verify the portfolio list header");
            expect(portfolioListPage.grid.getHeaders()).toEqual(expectedHeaders);
        });

        var expColumns = [];
        it("should have nine options to select from the column selector", function () {
            step("Verify all columns available from the column selector");
            expect(portfolioListPage.grid.columnSelector().getAvailableColumns())
                .toEqual([ '', '  Account Name', '  Analyst Name', '  Intake Date', '  Market Sector',
                    '  Patents', '  Priority', '  Quick Recommendation', '  Stage', '  Type' ]);
        });

        it("should have 'Opportunity Column' displayed after removing all columns from column selector", function () {
            step("Remove all columns from grid");
            portfolioListPage.grid.columnSelector().deSelectAllColumns();
            step("Verify that Opportnity Column is displayed in the grid");
            expect(portfolioListPage.grid.getHeaders()).toEqual(["Opportunity Name"])
        });

        it("should be able to select all columns from column selector", function () {
            step("Select all columns from column selector");
            portfolioListPage.grid.columnSelector().selectAllColumns();
            step("Verify that all columns are available in the grid");
            expect(portfolioListPage.grid.getHeaders())
                .toEqual(['Opportunity Name', 'Analyst Name', 'Quick Recommendation', 'Patents', 'Priority', 'Market Sector', 'Stage', 'Intake Date', 'Account Name', 'Type']);
        });

        var portfolioListSortData = [
            { column: "Opportunity Name", order: "ascending", type: "alphaNum"}, { column: "Opportunity Name", order: "descending", type: "alphaNum"},
            { column: "Analyst Name", order: "ascending", type: "string"}, { column: "Analyst Name", order: "descending", type: "string"},
            { column: "Patents", order: "ascending", type: "numeric"}, { column: "Patents", order: "descending", type: "numeric"},
            { column: "Priority", order: "ascending", type: "string"}, { column: "Priority", order: "descending", type: "string"},
            { column: "Market Sector", order: "ascending", type: "string"}, { column: "Market Sector", order: "descending", type: "string"},
            { column: "Stage", order: "ascending", type: "string"}, { column: "Stage", order: "descending", type: "string"},
            { column: "Intake Date", order: "ascending", type: "date"}, { column: "Intake Date", order: "descending", type: "date"},
            { column: "Account Name", order: "ascending", type: "alphaNum"}, { column: "Account Name", order: "descending", type: "alphaNum"}
        ];

        using(portfolioListSortData, function (data) {
            var columnName = data["column"], orderBy = data["order"], type = data["type"];

            it("should have " + columnName + " sortable by " + orderBy, function () {
                step("Sort " + columnName + " by " + orderBy + " in prior art grid");
                portfolioListPage.grid.sort(data["column"], data["order"]);
                step("Get column data for first page and verify it for sort type " + type);
                expect(portfolioListPage.grid.getFirstPageColumn(columnName)).toEqualSort({order: orderBy, type: type});
            });
        });

        it("should redirect the user to portfolio details page on clicking link from Opportunity Name column", function () {
            step("Click on the first link from Opportunity Name column");
            portfolioListPage.grid.clickColumn("Opportunity Name", 0);
            at(portfolioDetailsPage);
            navigateBack();
        });
    });
});