var using = require("jasmine-data-provider");

var loginPage = require("../../../pages/login.page"),
    patentDetailsPage = require("../../../pages/patent.details.page"),
    patentClaims = require("../../../pages/patent.claims");

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe("Patent Details", function () {
    var patId = "5896522";
    var patNum ="US 5,985,712 A";
    beforeAll(function () {
        // to(patentDetailsPage, patId);
          // Changing URL navigation using patnum for UserStory : 1720
          to(patentDetailsPage, patNum);
        patentDetailsPage.patentClaims.clickClaim(0);
        patentClaims.deleteAllTechnologyTags();
        patentClaims.deleteAllTheoryTags();
    });

    describe("Claims(1)[PRC]", function () {
        beforeEach(function () {
            step("Delete all existing PRC tags");
            patentClaims.deleteAllPrcTags();
        });

        it("should display 'No PRC Found' message for claims w/o prc tags", function () {
            step("Verify the message displayed without PRCs");
            expect(patentClaims.claimsPrcTab.noTags.getText())
                .toEqual("No PRC Found");
        });

        it("should be able to add entities from search select", function () {
            var prcEntities = ["Tesla Motors Incorporated", "Arrivalstar SA"];
            var expPrcTagData = [
                {
                    prc: 'Arrivalstar SA',
                    modalContent: { title: 'Arrivalstar SA', tags: {}, theory: {}, notes: '' },
                    claimCharted: false,
                    theoryCount: '0',
                    techTagCount: '0'
                },
                {
                    prc: 'Tesla Motors Incorporated',
                    modalContent: { title: 'Tesla Motors Incorporated', tags: {}, theory: {}, notes: '' },
                    claimCharted: false,
                    theoryCount: '0',
                    techTagCount: '0'
                }
            ];

            step("Add entities from PRC search select");
            patentClaims.claimsPrcTab.searchSelect.select(prcEntities);
            step("Verify that PRC entities are displayed witout any tag count");
            expect(patentClaims.claimsPrcTab.tags.getData()).toEqual(expPrcTagData);
        });

        it("should be able to delete the entities added", function () {
            var prcEntities = ["Amazon Digital Services Incorporated", "FedEx Corporation"];
            step("Add multiple entities as PRCs");
            patentClaims.claimsPrcTab.searchSelect.select(prcEntities);
            step("Delete all added PRCs");
            patentClaims.claimsPrcTab.tags.deleteAll();
            step("Verify that PRCs are not displayed");
            expect(patentClaims.claimsPrcTab.tags.getTags()).toEqual([]);
        });

        it("should display the added entities sorted alphabetically", function () {
            var prcs = ["SAMSUNG ELECTRONICS CO. LTD.", "HP INC.", "TOshiba CORPORATION", "sales"];
            var expPRCs = ["HP Inc.", "Salesforce.com, Inc.", "Samsung Electronics Co. Ltd.", "Toshiba Corporation"]
            step("Add the few entities as PRCs");
            patentClaims.claimsPrcTab.searchSelect.select(prcs);
            step("Verify that added PRCs are displayed in alphabetical order");
            expect(patentClaims.claimsPrcTab.tags.getTags()).toEqual(expPRCs);
        });
    });

    describe("Claim(1)[PRC]", function () {
        var techTags = ["Modem"];//Networking Cable 
        var theory = { theory: "claim 1 - theory" };

        beforeAll(function () {
            patentClaims.createTechnologyTags(techTags);
            patentClaims.addTheory(theory);
        });

        beforeEach(function () {
            step("Add theory and tech tags and delete all existing PRCs");
            patentClaims.deleteAllPrcTags();
        });

        var prcCreationData = [
            {
                actData: {
                    "Tesla Motors Incorporated": {
                        "isCharted": true,
                        "tags": { "Networking > Cable > Modem": false },
                        "theory": { "claim 1 - theory": false },
                        "notes": "auto test notes"
                    }
                }, expData: {
                    prc: 'Tesla Motors Incorporated',
                    modalContent: {
                        title: 'Tesla Motors Incorporated',
                        "tags": { "Networking > Cable > Modem": false },
                        "theory": { "claim 1 - theory": false },
                        notes: 'auto test notes'
                    },
                    claimCharted: true,
                    theoryCount: '0',
                    techTagCount: '0'
                }
            },
            {
                actData: {
                    "Tesla Motors Incorporated": {
                        "isCharted": false,
                        "tags": { "Networking > Cable > Modem": true },
                        "theory": { "claim 1 - theory": false },
                        "notes": "auto test notes"
                    }
                }, expData: {
                    prc: 'Tesla Motors Incorporated',
                    modalContent: {
                        title: 'Tesla Motors Incorporated',
                        "tags": { "Networking > Cable > Modem": true },
                        "theory": { "claim 1 - theory": false },
                        notes: 'auto test notes'
                    },
                    claimCharted: false,
                    theoryCount: '0',
                    techTagCount: '1'
                }
            },
            {
                actData: {
                    "Tesla Motors Incorporated": {
                        "isCharted": true,
                        "tags": { "Networking > Cable > Modem": false },
                        "theory": { "claim 1 - theory": true },
                        "notes": "auto test notes"
                    }
                }, expData: {
                    prc: 'Tesla Motors Incorporated',
                    modalContent: {
                        title: 'Tesla Motors Incorporated',
                        "tags": { "Networking > Cable > Modem": false },
                        "theory": { "claim 1 - theory": true },
                        notes: 'auto test notes'
                    },
                    claimCharted: true,
                    theoryCount: '1',
                    techTagCount: '0'
                }
            },
            {
                actData: {
                    "Tesla Motors Incorporated": {
                        "isCharted": false,
                        "tags": { "Networking > Cable > Modem": true },
                        "theory": { "claim 1 - theory": true },
                        "notes": "auto test notes"
                    }
                }, expData: {
                    prc: 'Tesla Motors Incorporated',
                    modalContent: {
                        title: 'Tesla Motors Incorporated',
                        "tags": { "Networking > Cable > Modem": true },
                        "theory": { "claim 1 - theory": true },
                        notes: 'auto test notes'
                    },
                    claimCharted: false,
                    theoryCount: '1',
                    techTagCount: '1'
                }
            }
        ];

        using(prcCreationData, function (data) {
            var actualData = data["actData"]; var expData = data["expData"];
            it("should be able to add theory and tech tags info", function () {
                patentClaims.claimsPrcTab.searchSelect.select(expData.prc);
                patentClaims.claimsPrcTab.tags.setData(actualData);
                expect(patentClaims.claimsPrcTab.tags.getData()).toEqual([expData]);
            });
        });

        var prcEditData = {
            actualPrc: {
                "Tesla Motors Incorporated": {
                    "isCharted": false,
                    "tags": { "Networking > Cable > Modem": true },
                    "theory": { "claim 1 - theory": true },
                    "notes": "auto test notes"
                }
            },
            editPrc: {
                "Tesla Motors Incorporated": {
                    "isCharted": false,
                    "tags": { "Networking > Cable > Modem": false },
                    "theory": { "claim 1 - theory": false },
                    "notes": "auto test notes after edit"
                }
            },
            expDataAfterEdit: {
                prc: 'Tesla Motors Incorporated',
                modalContent: {
                    title: 'Tesla Motors Incorporated',
                    "tags": { "Networking > Cable > Modem": false },
                    "theory": { "claim 1 - theory": false },
                    notes: 'auto test notes after edit'
                },
                claimCharted: false,
                theoryCount: '0',
                techTagCount: '0'
            }
        };

        it("should be able to edit the added entity information", function () {
            step("Add an entity as PRC");
            patentClaims.claimsPrcTab.searchSelect.select(prcEditData.expDataAfterEdit.prc);
            step("Add theory and tech tags to the added PRC entity");
            patentClaims.claimsPrcTab.tags.setData(prcEditData.actualPrc);
            step("Edit the information added in PRC");
            patentClaims.claimsPrcTab.tags.setData(prcEditData.editPrc);
            step("Verify that edited information is displayed in the tag and modal");
            expect(patentClaims.claimsPrcTab.tags.getData()).toEqual([prcEditData.expDataAfterEdit]);
        });
    });
});