require("../../../helpers/custom.matcher.helper");

var loginPage = require("../../../pages/login.page"),
    homePage = require("../../../pages/home.page"),
    portfolioDetailsPage = require("../../../pages/portfolio.details.page"),
    salesForceSummaryPage = require("../../../pages/salesforce.summary");

var portfolioQ = require("../../../data/queries/portfolio.queries"),
    dbHelper = require("../../../helpers/db.helper");

var using = require("jasmine-data-provider");

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
    at(homePage);
});

xdescribe("Portfolio", function () {
    var portfolioIdForRpxTab = "502772";//"6678",6667,502736
        // portfolioTitleForRpxTab = "JSDQ LLC - OMA";Test-Portfolio-AnnotatedPatents

    beforeAll(function () {
        to(portfolioDetailsPage, portfolioIdForRpxTab);
        portfolioDetailsPage.patentDataSubTabs.portfolio.select("Summaries");
        portfolioDetailsPage.patentDataTertirayNavs.summaries.select("ANNOTATED PATENTS");
    });

    describe("Annotated Patents(claim edit)", function () {
        var patNumAlone = 'US 8,615,896 B2';

        beforeAll(function () {
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(patNumAlone);
            portfolioDetailsPage.patentClaims.clickClaim(0);

        });

        beforeEach(function () {
            step("Login and click on ANNOTATED PATENTS nav from Portfolio - Summaries tab");
        });


        // Checking with KeyPatent checkbox annotation
        it("Annotate KeyPatent CheckBox and Verify", function () {
            step("Check that Patent " + patNumAlone + " is not in Annotated Patents initially");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
            step("Mark the Patent " + patNumAlone + " as key patent by selecting KeyPatent checkBox");
            portfolioDetailsPage.patentClaims.keyPatentCheckBox.check();
            refresh();
            step("Verify that Patent " + patNumAlone + " is now listed under Annotated Patent List");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(true);

        });

        it("Verify KeyPatent index and KeyPatent flag for KeyPatents", function () {
            step("Verify that KeyPatent " + patNumAlone + " should be listed first among Annotated Patents");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.getPatentIndex(patNumAlone)).toEqual(0);
            step("Verify that Patent " + patNumAlone + " has keypatent flag checked in Annotated Patents lits");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isKeyPatent(patNumAlone)).toEqual(true);
        });

        it("Uncheck keypatent checkbox and check Annotated PatentList", function () {
            step("Uncheck the KeyPatent CheckBox in the Patent " + patNumAlone + " claim");
            portfolioDetailsPage.patentClaims.keyPatentCheckBox.unCheck();
            refresh();
            step("Check that Patent " + patNumAlone + " is not in Annotated Patent List");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
        });

        // Checking with star rating annotation

        var claimRatingEdit = {
            "Literal Relevance": 3,// "Relevant Companies": 2,"Priority:": 3,"Detection": 2,"Claim Simplicity": 1,      // "Importance": 2,
            // "101 Eligibility": 3,"112 Description": 1,"112 Enablement": 2,"112 Indefiniteness": 1
        };
        it("annotate star-rating and Verify", function () {
            step("Check that Patent " + patNumAlone + " is not in Annotated Patents initially");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
            step("Change the star rating RELEVANCE to value of 3");
            portfolioDetailsPage.patentClaims.claimStarRating.setStarRatings(claimRatingEdit);
            step("Verify that now this Patent listed under annotatedPatents")
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(true);
        });
        it("verify the annotated star-rating value matches", function () {
            step("Check that annotated patent " + patNumAlone + " has same value for RELEVANCE stars");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.getStarRatingOfCompetency(patNumAlone, "Relevance")).toEqual(3);
        });
        it("removing ratings and check annotated patent list", function () {
            var claimRatingEdit = { "Literal Relevance": 0 };
            step("Set star rating for RELEVANCE to value 0");
            portfolioDetailsPage.patentClaims.claimStarRating.setStarRatings(claimRatingEdit);
            step("Verify that now this Patent is not in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);

        });
        // Checking with Representative claim checkbox
        it("annotate Representative-Claim checkbox and Verify", function () {
            step("Check that Patent " + patNumAlone + " is not in Annotated Patents initially");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
            step("Check the Representative-Claim checkBox in Patent claim");
            portfolioDetailsPage.patentClaims.representativeClaim.check();
            step("Verify that now this Patent listed under annotatedPatents");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(true);
        });
        // TODO : fix the errors
        xit("verify claim notes matching in claim detail and annotated patent", function () {
            var actualText, expectedText;
            step("Click the Show details link in the annotated Patent " + patNumAlone);
            portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.showDetailsOfPatentClaim(patNumAlone);
            step("Verify that claim description matches");
            expect(portfolioDetailsPage.patentClaims.getClaimDescription()).toEqual(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.getClaimTextInAnnotatedPatent(patNumAlone));

        });
        it("revoke representativeClaim and check annotated patent list", function () {
            var claimRatingEdit = { "Literal Relevance": 0 };
            step("Uncheck the Representative claim checkbox");
            portfolioDetailsPage.patentClaims.representativeClaim.unCheck();
            step("Verify that now this Patent is not in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
        });

        // Checking the Stretch Claim checkbox and its behavior on annotated patents

        it("annotate Stretch-Claim checkbox and Verify", function () {
            step("Check that Patent " + patNumAlone + " is not in Annotated Patents initially");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
            step("Check the Stretch-Claim checkBox in Patent claim");
            portfolioDetailsPage.patentClaims.stretchClaim.check();
            step("Verify that now this Patent listed under annotatedPatents")
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(true);
        });
        it("revoke Stretch-Claim and check annotated patent list", function () {
            step("Uncheck the Stretch claim checkbox");
            portfolioDetailsPage.patentClaims.stretchClaim.unCheck();
            step("Verify that now this Patent is not in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
        });
        // Adding and removing free form tag in Patent claims{Portfolio details page}

        it("add freeform tags and check annotated patents list", function () {
            var tagName = "Test Free Form Tag - claim Header";
            step("Check that Patent " + patNumAlone + " is not in Annotated Patents initially");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
            step("Delete all available free form tags");
            portfolioDetailsPage.patentClaims.freeFormTags.deleteAll();
            step("Add free form tag: " + tagName);
            portfolioDetailsPage.patentClaims.freeFormAutoSuggest.select(tagName);
            angularWait();
            step("Verify that now this Patent Should PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(true);
        });

        it("Remove freeform tags and check annotated patents list", function () {
            step("Remove all the freeform tags in Patent Header");
            portfolioDetailsPage.patentClaims.freeFormTags.deleteAll();
            step("Verify that now this Patent Should NOT PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
        });

        // edit tech tags and check the annotated patent list

        it("annotate TechTags and verify annotated-patents", function () {
            var techTag = "Network Protocol";
            step("Check that Patent " + patNumAlone + " is not in Annotated Patents initially");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
            portfolioDetailsPage.patentClaims.deleteAllTechnologyTags();
            step("Add tech tag - " + techTag + " - from Search Select");
            portfolioDetailsPage.patentClaims.claimsTechnologyTab.searchSelect.select(techTag);
            step("Verify that now this Patent listed under annotatedPatents");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(true);
        });

        it("check tech-tags matches in claim and annotated patents-claim", function () {
            // setting representative claim makes claim details visible in annotated patents
            step("Select this claim as representative claim");
            portfolioDetailsPage.patentClaims.representativeClaim.check();
            refresh();
            step("Click the Show details link in the annotated Patent " + patNumAlone);
            portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.showDetailsOfPatentClaim(patNumAlone);
            step("verify the tech-tags in claim and annotated-patents claim matching");
            expect(portfolioDetailsPage.patentClaims.claimsTechnologyTab.tags.getTagsText()).toEqual(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.getTechTagText(patNumAlone));

        });

        it("remove tech-tags and check annotated-patents", function () {
            // uncheck representative claim as the validation of tech tags matchin over
            step("Unselect this claim from representative claim");
            portfolioDetailsPage.patentClaims.representativeClaim.unCheck();
            step("delete all the tech-tags from the claim that we added");
            portfolioDetailsPage.patentClaims.claimsTechnologyTab.tags.deleteAll();
            step("Verify that now this Patent is not in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);

        });

        // annotating PRC in claims and checking that in annotated patents list

        it("annotate PRC in claims and verify annotated-patents", function () {
            var prcEntities = "Amazon Digital Services Incorporated";
            step("Check that Patent " + patNumAlone + " is not in Annotated Patents initially");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
            portfolioDetailsPage.patentClaims.deleteAllPrcTags();
            step("Select and add -" + prcEntities + " - PRC in the claim");
            portfolioDetailsPage.patentClaims.claimsPrcTab.searchSelect.select(prcEntities);
            step("Verify that now this Patent listed under annotatedPatents");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(true);
        });

        it("check PRCs matches in claim and annotated patents-claim", function () {
            // setting representative claim makes claim details visible in annotated patents
            step("Select this claim as representative claim");
            portfolioDetailsPage.patentClaims.representativeClaim.check();
            refresh();
            step("Click the Show details link in the annotated Patent " + patNumAlone);
            portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.showDetailsOfPatentClaim(patNumAlone);
            step("verify the PRcs in claim and annotated-patents claim matching");
            portfolioDetailsPage.patentClaims.claimTabs.select("PRC");
            expect(portfolioDetailsPage.patentClaims.claimsPrcTab.tags.getTagsText()).toEqual(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.getPRCText(patNumAlone));
            // expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.getPRCText(patNumAlone)).toEqual("Amazon.com, Inc.");

        });

        it("remove PRCs and check annotated-patents", function () {
            // uncheck representative claim as the validation of tech tags matchin over
            step("Unselect this claim from representative claim");
            portfolioDetailsPage.patentClaims.representativeClaim.unCheck();
            step("delete all the tech-tags from the claim that we added");
            portfolioDetailsPage.patentClaims.deleteAllPrcTags();
            step("Verify that now this Patent is not in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);

        });


        // Adding theory under Claims and check in annotated patents(theory annotation has no effect)

        it("annotate Theory in claims and verify annotated-patents", function () {
            step("Check that Patent " + patNumAlone + " is not in Annotated Patents initially");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
            portfolioDetailsPage.patentClaims.deleteAllTheoryTags();
            step("Add theory to this claim");
            portfolioDetailsPage.patentClaims.claimsTheoryTab.add({ "theory": "test theory 1" });
            step("Verify that now this Patent SHOULD  listed under annotatedPatents");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(true);
        });

        it("check Theory matches in claim and annotated patents-claim", function () {
            // setting representative claim makes claim details visible in annotated patents
            step("Select this claim as representative claim");
            portfolioDetailsPage.patentClaims.representativeClaim.check();
            refresh();
            step("Click the Show details link in the annotated Patent " + patNumAlone);
            portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.showDetailsOfPatentClaim(patNumAlone);
            step("verify the Theory in claim and annotated-patents claim matching");
            //Navigating to theory tab
            portfolioDetailsPage.patentClaims.claimTabs.select("Theory");
            expect(portfolioDetailsPage.patentClaims.claimsTheoryTab.tags.getTagsText()).toEqual(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.getTheoryOfRelevanceText(patNumAlone));

        });

        it("remove Theory and check annotated-patents", function () {
            // uncheck representative claim as the validation of tech tags matchin over
            step("Unselect this claim from representative claim");
            portfolioDetailsPage.patentClaims.representativeClaim.unCheck();
            step("delete all the theories from the claim that we added");
            portfolioDetailsPage.patentClaims.deleteAllTheoryTags();
            step("Verify that now this Patent is not in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);

        });
        xit("annotate claim-priority date and check annotated patents", function () {
            var editDate = "05/21/2024";//03/10/2004 
            step("Check that Patent " + patNumAlone + " is not in Annotated Patents initially");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
            step("Click on the priority date and edit the date");
            portfolioDetailsPage.patentClaims.priorityDate.edit(editDate);
            step("Verify that now this Patent Should NOT PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
        });

        xit("verify ordering of keypatents based on claimRatings", function () {
            var keyPatent1 = 'US 7,327,373 B2',
                keyPatent2 = 'US 7,538,752 B2';
            step("verify that Pat1 " + keyPatent1 + " has rating more than Pat2 " + keyPatent2);
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.getStarRatingOfCompetency(keyPatent1, "Relevance")).toBeGreaterThan(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.getStarRatingOfCompetency(keyPatent2, "Relevance"));
            step("verify that Pat1 " + keyPatent1 + " ordered before than Pat2" + keyPatent2);
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.getPatentIndex(keyPatent1)).toBeLessThan(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.getPatentIndex(keyPatent2));

        });

    });
    xdescribe("Annotated Patents(Patent-Header Edit )", function () {
        var patNumAlone = 'US 8,616,200 B2';

        beforeAll(function () {
            portfolioDetailsPage.patentList.grid.clickCellWithTextOf(patNumAlone);
        });
        // Editing sponsor link as strong in the Patent header{Portfolio details page}
        it("annotate sponsors and check annotated patents list", function () {
            step("Check that Patent " + patNumAlone + " is not in Annotated Patents initially");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
            step("Select the checkbox and mark the sponsor as Strong");
            portfolioDetailsPage.patentHeader.sponsor.edit(true);
            step("Verify that now this Patent is PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(true);
        });

        it("Remove sponsor strong flag and check annotated patents list", function () {
            step("Click on the sponsor link and remove the Strong selection");
            portfolioDetailsPage.patentHeader.sponsor.edit(false);
            step("Verify that now this Patent SHOULD NOT PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
        });

        // Adding and removing free form tag in Patent Header{Portfolio details page}

        it("add freeform tags and check annotated patents list", function () {
            var tagName = "Test Free Form Tag - Patent header";
            step("Check that Patent " + patNumAlone + " is not in Annotated Patents initially");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
            step("Delete all available free form tags");
            portfolioDetailsPage.patentHeader.freeFormTags.deleteAll();
            step("Add free form tag: " + tagName);
            portfolioDetailsPage.patentHeader.freeFormAutoSuggest.select(tagName);
            angularWait();
            step("Verify that now this Patent Should PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(true);
        });

        it("Remove freeform tags and check annotated patents list", function () {
            step("Remove all the freeform tags in Patent Header");
            portfolioDetailsPage.patentHeader.freeFormTags.deleteAll();
            step("Verify that now this Patent Should NOT PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
        });

        // Editing inventors link as strong in the Patent header{Portfolio details page}
        it("annotate inventors and check annotated patents list", function () {
            step("Check that Patent " + patNumAlone + " is not in Annotated Patents initially");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
            step("Select the checkbox and mark the inventors as Strong");
            portfolioDetailsPage.patentHeader.inventors.edit(0, true);
            step("Verify that now this Patent is PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(true);
        });

        it("Remove inventors strong flag and check annotated patents list", function () {
            step("Click on the sponsor link and remove the Strong selection");
            portfolioDetailsPage.patentHeader.inventors.edit(0, false);
            step("Verify that now this Patent is NOT PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
        });

        // Annotate priority date in Patent header{portfolio details page}
        it("annotate priority-date verified flag and check annotated patent list", function () {
            step("Check that Patent " + patNumAlone + " is not in Annotated Patents initially");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
            step("Select Verified checkbox and mark the Priority-date as Verified");
            portfolioDetailsPage.patentHeader.priorityDate.edit(true);
            step("Verify that now this Patent is PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(true);
        });
        it("Remove PriorityDate-verified flag and check annotated patents list", function () {
            step("Click on the PriorityDate link and remove the verified selection");
            portfolioDetailsPage.patentHeader.priorityDate.edit(false);
            step("Verify that now this Patent Should NOT PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
        });


        // Annotate expiry date in Patent header{portfolio details page}
        it("annotate expiry-date verified flag and check annotated patent list", function () {
            step("Check that Patent " + patNumAlone + " is not in Annotated Patents initially");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
            step("Select Verified checkbox and mark the expiry-date as Verified");
            portfolioDetailsPage.patentHeader.expiryDate.edit(true);
            step("Verify that now this Patent is PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(true);
        });
        it("Remove ExpiryDate-verified flag and check annotated patents list", function () {
            step("Click on the ExpiryDate link and remove the verified selection");
            portfolioDetailsPage.patentHeader.expiryDate.edit(false);
            step("Verify that now this Patent Should NOT PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
        });


        // annotate patent-memo in patent-header {portfolio details page}
        var annotationType = "Patent Summary", value = "Analysts Notes Test-Newly Added";
        it("add patent memo and check in annotated patents", function () {
            step("Check that Patent " + patNumAlone + " is not in Annotated Patents initially");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
            step("Save " + annotationType + " annotation with " + value);
            portfolioDetailsPage.patentHeader.annotations.save(annotationType, value);
            step("Verify that now this Patent Should PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(true);

        });
        it("check Patent-memo  in patent-header matches with annotated patent details", function () {

            step("Click the Show details link in the annotated Patent " + patNumAlone);
            portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.showDetailsOfPatentClaim(patNumAlone);
            step("Verify the patent-memo added in patent header matches with patent memo in annotated patents list");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.getMemoTextInAnnotatedPatent(patNumAlone, annotationType)).toEqual("Analysts Notes Test-Newly Added");

        });
        it("remove patent-memo in patent header and check annotated patents list", function () {
            // step("Select Annotations tab from patent header edit");
            // portfolioDetailsPage.patentHeader.annotationTabs.select("Annotations");
            step("Clear all existing annotations");
            portfolioDetailsPage.patentHeader.annotations.clearAll();
            step("Verify that now this Patent Should NOT PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
        });

        // annotate licensees in patent header and check the changes in annotated patents-list
        var licensee = "Alphabet Inc.";
        it("add licensees in patent-header and check in annotated patents", function () {
            step("Navigate to Licensees tab");
            portfolioDetailsPage.patentHeader.annotationTabs.select("Licensees");
            step("Clear all licensees tags if exists");
            portfolioDetailsPage.patentHeader.licensees.tags.deleteAll();
            step("Add company " + licensee + " as licensee");
            portfolioDetailsPage.patentHeader.licensees.searchSelect.select(licensee);
            step("Verify that now this Patent Should PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(true);
        });

        it("remove the licensees in patent-header and check in annotated-patents", function () {
            step("Navigate to Licensees tab");
            portfolioDetailsPage.patentHeader.annotationTabs.select("Licensees");
            step("Clear all licensees tags if exists");
            portfolioDetailsPage.patentHeader.licensees.tags.deleteAll();
            step("Verify that now this Patent Should NOT PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
        });

        xit("Change the priority date and check in annotated patent list", function () {
            var editDate = "05/21/2014" , patNum = 'US 7,782,957 B2';
            step("Check that Patent " + patNum + " is not in Annotated Patents initially");
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNum)).toEqual(false);
            step("Click on the priority date and edit the date");
            portfolioDetailsPage.patentHeader.priorityDate.edit(undefined, editDate);
            step("Verify that now this Patent Should PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNum)).toEqual(true);
        });


        xit("Change the Expiry date and check in annotated patent list", function () {
            var editDate = "05/21/2036",patNum = 'US 7,782,957 B2';
            // step("Check that Patent " + patNumAlone + " is not in Annotated Patents initially");
            // expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNumAlone)).toEqual(false);
            step("Click on the Expiry date and edit the date");
            portfolioDetailsPage.patentHeader.expiryDate.edit(false, editDate);
            step("Verify that now this Patent Should  PRESENT in Annotated Patent List");
            refresh();
            expect(portfolioDetailsPage.portfolioSummariesTab.annotedPatentsTab.isAnnotatedPatent(patNum)).toEqual(true);
        });

    });



});