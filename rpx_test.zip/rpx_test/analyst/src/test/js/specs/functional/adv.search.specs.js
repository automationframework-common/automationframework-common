var loginPage = require("../../pages/login.page"),
    homePage = require("../../pages/home.page"),
    searchResults = require("../../pages/search.results.page"),
    portfolioDetailsPage = require("../../pages/portfolio.details.page");

var using = require('jasmine-data-provider');

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
    at(homePage);
});

describe("Home Page - Patent Advanced Search", function () {
    beforeEach(function () {
        to(homePage);
        step("Open advanced search modal from 'Patent Search' in home page");
        homePage.patent.openAdvancedSearchModal();
        homePage.patent.advancedSearch.deleteAllRows();
    });

    // var expCustomSearchFields = ['Search Options', 'Plaintiff', 'Defendant', 'Campaign',
    //     'Jurisdiction', '# of Claim Charts', '# of Defendants', 'Analyst Sum', 'Has Representative Claim', 'Is Analyzed',
    //     'Is Stretch Claim', 'PRC', 'PRC Count', '# of US Patents in Family', 'Foreign Counterparts',
    //     'Open Continuances', 'Patent Family Name', 'Alice Words', 'Citations-Backward', 'Citations-Forward',
    //     'Citing Assignees', 'Citing Clusters', 'Claim Originality', 'Claims Length', 'Defendant Score',
    //     'Examination Thoroughness', 'Limiting Language Score', 'Litigation Likelihood', 'Overall Score',
    //     'Preposition Score', 'Any Assignee', 'Current Assignee', 'Sponsoring Entity', 'CPC Mid Level',
    //     'CPC Top Level', 'Freeform Tags', 'IPC Class', 'Tech Tags', 'Topic Cluster', 'Expiration Date',
    //     'Filing Date', 'Issue Date', 'Priority Date', 'Grant Time', 'Patent Status', 'References - Backward',
    //     'References - Forward', 'Shortest Claim Length', 'Title'];

    // it("should have custom search options to select from", function () {
    //     step("Verify the options available in custom search drop down");
    //     expect(homePage.patent.advancedSearch.customSearchDropDown.getAvailableOptions()).toEqual(expCustomSearchFields);
    // });

    it("should have the country code filter selected by default", function () {
        step("Without selecting any filter click on done");
        homePage.patent.advancedSearch.doneBtn.click();
        step("Verify that search results with Country Code filter is displayed");
        at(searchResults);
        expect(searchResults.filterTags.getText()).toEqual("Country Code");
    });

    // it("should redirect users to search results with Patent Number filter", function () {
    //     step("Enter valid patent number in Patent Number text row");
    //     homePage.patent.advancedSearch.patentNumber.enterSearchTerm("6959322");
    //     step("Click on done button");
    //     homePage.patent.advancedSearch.doneBtn.click();
    //     step("Verify that search results with selected filter is displayed");
    //     at(searchResults);
    //     expect(searchResults.secondfilterTags.getText()).toEqual("Patent Number");
    // });

    // var searchTerm = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u"];
    // xit("should display an error message after entering 20 search terms", function () {
    //     step("Enter 21 search terms in 'Term Search' field");
    //     homePage.patent.advancedSearch.termSearch.inputSearchTermWithEnterKey(searchTerm);
    //     step("Verify that search results are displayed with selected filters are displayed");
    //     expect(homePage.patent.advancedSearch.termSearchError.isDisplayed()).toEqual(true);
    // });

    // var termSearchData = [
    //     { dataArr: ["sensors"] },
    //     { dataArr: ["sensors", "light"] }
    // ];

    // using(termSearchData, function (data) {
    //     var dataArr = data["dataArr"];
    //     xit("should redirect the user to search results with Term Search filter for data: " + dataArr, function () {
    //         step("Enter the search term: " + dataArr + " in 'Term Search");
    //         homePage.patent.advancedSearch.termSearch.inputSearchTermWithEnterKey(dataArr);
    //         step("Click on 'Done' button in advanced search modal");
    //         homePage.patent.advancedSearch.doneBtn.click();
    //         at(searchResults);
    //         step("Verify that search results are displayed with selected filters are displayed");
    //         expect(searchResults.secondfilterTags.getText()).toEqual("Term Search");
    //     });
    // });

    it("should redirect users to search details with Portfolio Name filter", function () {
        var portfolioName = "Subbian - Acq";

        step("Enter valid portfolio in Portfolio Name auto suggest");
        homePage.patent.advancedSearch.selectFromFacetAutoSuggest("Portfolio Names", portfolioName);
        homePage.patent.advancedSearch.clickDoneBtn();
        step("Verify that search results with selected filters are displayed");
        at(searchResults);
        expect(searchResults.secondfilterTags.getText()).toEqual("Portfolio Names");
    });

    // var facetCustomSearchData = [
    //     { filterName: "Plaintiff", searchTerm: "Apple" },
    //     { filterName: "Defendant", searchTerm: "Apple" },
    //     { filterName: "Campaign", searchTerm: "Rothschild Conn" },
    //     { filterName: "Any Assignee", searchTerm: "Tesla Motors Inc" },
    //     { filterName: "Current Assignee", searchTerm: "RPX Corporation" },
    //     { filterName: "Sponsoring Entity", searchTerm: "Citigroup" },
    //     { filterName: "IPC Class", searchTerm: "709/232" },
    //     { filterName: "PRC", searchTerm: "Amazon" },
    //     { filterName: "Tech Tags", searchTerm: "Semi RF" },
    //     { filterName: "Sub Cluster", searchTerm: "engines" },
    //     { filterName: "Super Cluster", searchTerm: "servers" },
    //     { filterName: "Freeform Tags", searchTerm: "Autonomous Cars" }
    // ];

    // using(facetCustomSearchData, function (data) {
    //     var filterName = data["filterName"], searchTerm = data["searchTerm"];
    //     xit("should redirect users to search results for " + filterName + " filter with data: " + searchTerm, function () {
    //         step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
    //         // homePage.patent.advancedSearch.facetRowSearch(filterName, searchTerm);

    //         homePage.patent.advancedSearch.selectfacetFilter(filterName, searchTerm);
    //         step("Verify that search results with selected filters are displayed");
    //         at(searchResults);
    //         expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
    //     });
    // });
    // // Clearing filter tags should remove the filter selections in Filter Slide
    // using(facetCustomSearchData, function (data) {
    //     var filterName = data["filterName"], searchTerm = data["searchTerm"];
    //     xit("Verify that removing filtertag" + filterName + " clears the filter selection in filterslide", function () {
    //         step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
    //         // homePage.patent.advancedSearch.facetRowSearch(filterName, searchTerm);
    //         homePage.patent.advancedSearch.selectfacetFilter(filterName, searchTerm);
    //         step("Verify that search results with selected filters are displayed");
    //         at(searchResults);
    //         expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
    //         step("Clear the filter " + filterName);
    //         searchResults.clearFilterTag(filterName);
    //         step("Open the filter slide");
    //         searchResults.openFilterSlide();
    //         step("verify that Selected FacetFilter " + filterName + " is not displayed");
    //         expect(searchResults.filterScreen.isFacetSearchValuePresent(filterName)).toEqual(false);
    //     });
    // });

    // // Clearing filter tags should update the result patent count to its initial value selections in Filter Slide
    // using(facetCustomSearchData, function (data) {
    //     var filterName = data["filterName"], searchTerm = data["searchTerm"];
    //     var updatedPatentCount;
    //     xit("Verify the Patent count changes by applying and removing filter: " + filterName, function () {
    //         step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
    //         // homePage.patent.advancedSearch.facetRowSearch(filterName, searchTerm);
    //         homePage.patent.advancedSearch.selectfacetFilter(filterName, searchTerm);
    //         step("Verify that search results with selected filters are displayed");
    //         at(searchResults);
    //         updatedPatentCount = searchResults.getPatentCount();
    //         step("Resulting Patent count with Filter " + filterName + " is :" + updatedPatentCount);
    //         step("clear the filter tag " + filterName);
    //         searchResults.clearFilterTag(filterName);

    //         step("Verify that patent count get updated and not equal to initial value");
    //         expect(searchResults.patentCountText.getText()).not.toEqual(updatedPatentCount);
    //     });
    // });

    // // verify that clearing filter remove the tags added
    // using(facetCustomSearchData, function (data) {
    //     var filterName = data["filterName"], searchTerm = data["searchTerm"];
    //     xit("Verify the filter tags cleared by removing filter: " + filterName, function () {
    //         step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
    //         // homePage.patent.advancedSearch.facetRowSearch(filterName, searchTerm);
    //         homePage.patent.advancedSearch.selectfacetFilter(filterName, searchTerm);
    //         step("Verify that search results with selected filters are displayed");
    //         at(searchResults);
    //         expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
    //         step("Clear the filter " + filterName);
    //         searchResults.clearFilterTag(filterName);
    //         step("verify that Selected filter " + filterName + "  TAG is NOT DISPLAYED");
    //         expect(searchResults.isFilterTagPresent(filterName)).toEqual(false);
    //     });
    // });
    var numericCustomSearchData = [
        // { filterName: "# of Claim Charts", type: "equals", value1: "2" },
        { filterName: "# of Defendants", type: "equals", value1: "1" },
        { filterName: "Analyst Sum", type: "equals", value1: "1" },
        { filterName: "PRC Count", type: "equals", value1: "3" },
        { filterName: "# of US Patents in Family", type: "equals", value1: "1" },
        { filterName: "Foreign Counterparts", type: "equals", value1: "2" },
        { filterName: "Open Continuances", type: "equals", value1: "4" },
        { filterName: "Alice Words", type: "equals", value1: "2" },
        { filterName: "Claim Originality", type: "equals", value1: "3" },
        { filterName: "Claims Length", type: "equals", value1: "1" },
        { filterName: "Defendant Score", type: "equals", value1: "1" },
        { filterName: "Examination Thoroughness", type: "equals", value1: "1" },
        { filterName: "Grant Time", type: "equals", value1: "7" },
        { filterName: "Limiting Language Score", type: "equals", value1: "1" },
        { filterName: "Litigation Likelihood", type: "equals", value1: "1" },
        { filterName: "Overall Score", type: "equals", value1: "2" },
        { filterName: "Preposition Score", type: "equals", value1: "1" },
        { filterName: "References - Backward", type: "equals", value1: "5" },
        { filterName: "References - Forward", type: "equals", value1: "6" },
        { filterName: "Shortest Claim Length", type: "equals", value1: "1" },
        { filterName: "Citations-Backward", type: "equals", value1: "5" },
        { filterName: "Citations-Forward", type: "equals", value1: "2" },
        { filterName: "Citing Assignees", type: "equals", value1: "1" },
        { filterName: "Citing Clusters", type: "equals", value1: "1" }
    ];

    using(numericCustomSearchData, function (data) {
        var filterName = data["filterName"], searchType = data["type"], value1 = data["value1"];
        it("should redirect users to search results for " + filterName + " filter with data: " + searchType, function () {
            step("Add " + filterName + " row and select " + searchType + " from numeric row");
            // homePage.patent.advancedSearch.numericRowSearch(filterName, searchType, value1);
            homePage.patent.advancedSearch.selectNumericFilter(filterName, searchType, value1);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
        });
    });
    // Clearing filter tags should remove the filter selections in Filter Slide
    using(numericCustomSearchData, function (data) {
        var filterName = data["filterName"], searchType = data["type"], value1 = data["value1"];
        it("Verify that removing filtertag" + filterName + " clears the filter selection in filterslide", function () {
            step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
            homePage.patent.advancedSearch.selectNumericFilter(filterName, searchType, value1);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
            step("Clear the filter " + filterName);
            searchResults.clearFilterTag(filterName);
            step("Open the filter slide");
            searchResults.openFilterSlide();
            step("verify that Selected FacetFilter " + filterName + " is not displayed");
            expect(searchResults.filterScreen.isNumericSearchValuePresent(filterName)).toEqual(false);
        });
    });

    // Clearing filter tags should update the result patent count to its initial value selections in Filter Slide
    using(numericCustomSearchData, function (data) {
        var filterName = data["filterName"], searchType = data["type"], value1 = data["value1"];
        var updatedPatentCount;
        it("Verify the Patent count changes by applying and removing filter: " + filterName, function () {
            step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
            // homePage.patent.advancedSearch.facetRowSearch(filterName, searchTerm);
            homePage.patent.advancedSearch.selectNumericFilter(filterName, searchType, value1);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            updatedPatentCount = searchResults.getPatentCount();
            step("Resulting Patent count with Filter " + filterName + " is :" + updatedPatentCount);
            step("clear the filter tag " + filterName);
            searchResults.clearFilterTag(filterName);
            step("Verify that patent count get updated and not equal to initial value");
            expect(searchResults.patentCountText.getText()).not.toEqual(updatedPatentCount);
        });
    });

    // verify that clearing filter remove the tags added
    using(numericCustomSearchData, function (data) {
        var filterName = data["filterName"], searchType = data["type"], value1 = data["value1"];
        it("Verify the filter tags cleared by removing filter: " + filterName, function () {
            step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
            // homePage.patent.advancedSearch.facetRowSearch(filterName, searchTerm);
            homePage.patent.advancedSearch.selectNumericFilter(filterName, searchType, value1);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
            step("Clear the filter " + filterName);
            searchResults.clearFilterTag(filterName);
            step("verify that Selected filter " + filterName + "  TAG is NOT DISPLAYED");
            expect(searchResults.isFilterTagPresent(filterName)).toEqual(false);
        });
    });
    var radioCustomSearchData = [
        // { filterName: "Has Representative Claim", option: "false" },
        { filterName: "Is Analyzed", option: "true" },
        { filterName: "Is Stretch Claim", option: "false" }
    ];

    using(radioCustomSearchData, function (data) {
        var filterName = data["filterName"], searchOption = data["option"];
        it("should redirect users to search results for " + filterName + " filter with option: " + searchOption, function () {
            step("Add " + filterName + " row and select " + searchOption + " from radio group row");
            // homePage.patent.advancedSearch.radioRowSearch(filterName, searchOption);
            homePage.patent.advancedSearch.selectRadioFilter(filterName, searchOption);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
        });
    });
    // Clearing filter tags should remove the filter selections in Filter Slide
    using(radioCustomSearchData, function (data) {
        var filterName = data["filterName"], searchOption = data["option"];
        it("Verify that removing filtertag" + filterName + " clears the filter selection in filterslide", function () {
            step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
            homePage.patent.advancedSearch.selectRadioFilter(filterName, searchOption);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
            step("Clear the filter " + filterName);
            searchResults.clearFilterTag(filterName);
            step("Open the filter slide");
            searchResults.openFilterSlide();
            step("verify that Selected FacetFilter " + filterName + " is not displayed");
            expect(searchResults.filterScreen.isNumericSearchValuePresent(filterName)).toEqual(false);
        });
    });

    // Clearing filter tags should update the result patent count to its initial value selections in Filter Slide
    using(radioCustomSearchData, function (data) {
        var filterName = data["filterName"], searchOption = data["option"];
        var updatedPatentCount;
        it("Verify the Patent count changes by applying and removing filter: " + filterName, function () {
            step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
            // homePage.patent.advancedSearch.facetRowSearch(filterName, searchTerm);
            homePage.patent.advancedSearch.selectRadioFilter(filterName, searchOption);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            updatedPatentCount = searchResults.getPatentCount();
            step("Resulting Patent count with Filter " + filterName + " is :" + updatedPatentCount);
            step("clear the filter tag " + filterName);
            searchResults.clearFilterTag(filterName);
            step("Verify that patent count get updated and not equal to initial value");
            expect(searchResults.patentCountText.getText()).not.toEqual(updatedPatentCount);
        });
    });

    // verify that clearing filter remove the tags added
    using(radioCustomSearchData, function (data) {
        var filterName = data["filterName"], searchOption = data["option"];
        it("Verify the filter tags cleared by removing filter: " + filterName, function () {
            step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
            // homePage.patent.advancedSearch.facetRowSearch(filterName, searchTerm);
            homePage.patent.advancedSearch.selectRadioFilter(filterName, searchOption);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
            step("Clear the filter " + filterName);
            searchResults.clearFilterTag(filterName);
            step("verify that Selected filter " + filterName + "  TAG is NOT DISPLAYED");
            expect(searchResults.isFilterTagPresent(filterName)).toEqual(false);
        });
    });
    var textRowCustomSearchData = [
        // { filterName: "Patent Family Name", searchTerm: "Physical Fitness" }, Issue exists
        { filterName: "Title", searchTerm: "drugs" }
    ];

    using(textRowCustomSearchData, function (data) {
        var filterName = data["filterName"], searchTerm = data["searchTerm"];
        it("should redirect users to search results for " + filterName + " filter with data: " + searchTerm, function () {
            step("Add " + filterName + " row and enter " + searchTerm + " from text row");
            // homePage.patent.advancedSearch.textRowSearch(filterName, searchTerm);
            homePage.patent.advancedSearch.textRowFilter(filterName, searchTerm);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
        });
    });
    // Clearing filter tags should remove the filter selections in Filter Slide
    using(textRowCustomSearchData, function (data) {
        var filterName = data["filterName"], searchTerm = data["searchTerm"];
        it("Verify that removing filtertag" + filterName + " clears the filter selection in filterslide", function () {
            step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
            homePage.patent.advancedSearch.textRowFilter(filterName, searchTerm);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
            step("Clear the filter " + filterName);
            searchResults.clearFilterTag(filterName);
            step("Open the filter slide");
            searchResults.openFilterSlide();
            step("verify that Selected FacetFilter " + filterName + " is not displayed");
            expect(searchResults.filterScreen.isNumericSearchValuePresent(filterName)).toEqual(false);
        });
    });

    // Clearing filter tags should update the result patent count to its initial value selections in Filter Slide
    using(textRowCustomSearchData, function (data) {
        var filterName = data["filterName"], searchTerm = data["searchTerm"];
        var updatedPatentCount;
        it("Verify the Patent count changes by applying and removing filter: " + filterName, function () {
            step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
            // homePage.patent.advancedSearch.facetRowSearch(filterName, searchTerm);
            homePage.patent.advancedSearch.textRowFilter(filterName, searchTerm);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            updatedPatentCount = searchResults.getPatentCount();
            step("Resulting Patent count with Filter " + filterName + " is :" + updatedPatentCount);
            step("clear the filter tag " + filterName);
            searchResults.clearFilterTag(filterName);
            step("Verify that patent count get updated and not equal to initial value");
            expect(searchResults.patentCountText.getText()).not.toEqual(updatedPatentCount);
        });
    });

    // verify that clearing filter remove the tags added
    using(textRowCustomSearchData, function (data) {
        var filterName = data["filterName"], searchTerm = data["searchTerm"];
        it("Verify the filter tags cleared by removing filter: " + filterName, function () {
            step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
            // homePage.patent.advancedSearch.facetRowSearch(filterName, searchTerm);
            homePage.patent.advancedSearch.textRowFilter(filterName, searchTerm);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
            step("Clear the filter " + filterName);
            searchResults.clearFilterTag(filterName);
            step("verify that Selected filter " + filterName + "  TAG is NOT DISPLAYED");
            expect(searchResults.isFilterTagPresent(filterName)).toEqual(false);
        });
    });

    var dateRowCustomSearchData = [
        { filterName: "Expiration Date", fromDate: "12/12/2014", toDate: "10/03/2015" },
        { filterName: "Filing Date", fromDate: "12/12/2016", toDate: "10/01/2017" },
        { filterName: "Issue Date", fromDate: "10/10/2015", toDate: "10/11/2015" },
        // { filterName: "Priority Date", fromDate: "11/05/2000", toDate: "11/06/2000" }
    ];

    using(dateRowCustomSearchData, function (data) {
        var filterName = data["filterName"], fromDate = data["fromDate"], toDate = data["toDate"];
        it("should redirect users to search results for " + filterName + " filter between dates: " + fromDate + " and " + toDate, function () {
            step("Add " + filterName + " row and select date between " + fromDate + " and " + toDate + " from date row");
            // homePage.patent.advancedSearch.dateRowSearch(filterName, fromDate, toDate);
            homePage.patent.advancedSearch.dateRowFilter(filterName, fromDate, toDate);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
        });
    });
    // Clearing filter tags should remove the filter selections in Filter Slide
    using(dateRowCustomSearchData, function (data) {
        var filterName = data["filterName"], fromDate = data["fromDate"], toDate = data["toDate"];
        it("Verify that removing filtertag" + filterName + " clears the filter selection in filterslide", function () {
            step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
            homePage.patent.advancedSearch.dateRowFilter(filterName, fromDate, toDate);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
            step("Clear the filter " + filterName);
            searchResults.clearFilterTag(filterName);
            step("Open the filter slide");
            searchResults.openFilterSlide();
            step("verify that Selected FacetFilter " + filterName + " is not displayed");
            expect(searchResults.filterScreen.isNumericSearchValuePresent(filterName)).toEqual(false);
        });
    });

    // Clearing filter tags should update the result patent count to its initial value selections in Filter Slide
    using(dateRowCustomSearchData, function (data) {
        var filterName = data["filterName"], fromDate = data["fromDate"], toDate = data["toDate"];
        var updatedPatentCount;
        it("Verify the Patent count changes by applying and removing filter: " + filterName, function () {
            step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
            // homePage.patent.advancedSearch.facetRowSearch(filterName, searchTerm);
            homePage.patent.advancedSearch.dateRowFilter(filterName, fromDate, toDate);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            updatedPatentCount = searchResults.getPatentCount();
            step("Resulting Patent count with Filter " + filterName + " is :" + updatedPatentCount);
            step("clear the filter tag " + filterName);
            searchResults.clearFilterTag(filterName);
            step("Verify that patent count get updated and not equal to initial value");
            expect(searchResults.patentCountText.getText()).not.toEqual(updatedPatentCount);
        });
    });

    // verify that clearing filter remove the tags added
    using(dateRowCustomSearchData, function (data) {
        var filterName = data["filterName"], fromDate = data["fromDate"], toDate = data["toDate"];
        it("Verify the filter tags cleared by removing filter: " + filterName, function () {
            step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
            // homePage.patent.advancedSearch.facetRowSearch(filterName, searchTerm);
            homePage.patent.advancedSearch.dateRowFilter(filterName, fromDate, toDate);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
            step("Clear the filter " + filterName);
            searchResults.clearFilterTag(filterName);
            step("verify that Selected filter " + filterName + "  TAG is NOT DISPLAYED");
            expect(searchResults.isFilterTagPresent(filterName)).toEqual(false);
        });
    });

    var jurisdictionOption = "PTAB";
    it("should redirect users to search results for Jurisdiction filter for option " + jurisdictionOption, function () {
        step("Add Jurisdiction row and select option as " + jurisdictionOption);
        homePage.patent.advancedSearch.checkBoxRowSearch("Jurisdiction", jurisdictionOption);
        step("Verify that search results with selected filters are displayed");
        at(searchResults);
        expect(searchResults.secondfilterTags.getText()).toEqual("Jurisdiction");
    });
    // priority date filter cases

    // Verify the newly added priority date in advanced search modal
    it("should redirect users to search results for Priority Date filter", function () {
        var filterName = "Priority Date", fromDate = "11/01/2000", toDate = "11/12/2015";
        step("Add " + filterName + " row and select date between " + fromDate + " and " + toDate + " from date row");
        // homePage.patent.advancedSearch.dateRowSearch(filterName, fromDate, toDate);
        homePage.patent.advancedSearch.prioritydateRowFilter(filterName, fromDate, toDate);
        step("Verify that search results with selected filters are displayed");
        at(searchResults);
        expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
    });

    // Clearing filter tags should remove the filter selections in Filter Slide

    it("Verify that removing filtertag Priority Date clears the filter selection in filterslide", function () {
        var filterName = "Priority Date", fromDate = "11/01/2000", toDate = "11/12/2015";
        step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
        homePage.patent.advancedSearch.prioritydateRowFilter(filterName, fromDate, toDate);
        step("Verify that search results with selected filters are displayed");
        at(searchResults);
        expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
        step("Clear the filter " + filterName);
        searchResults.clearFilterTag(filterName);
        step("Open the filter slide");
        searchResults.openFilterSlide();
        step("verify that Selected FacetFilter " + filterName + " is not displayed");
        expect(searchResults.filterScreen.isNumericSearchValuePresent(filterName)).toEqual(false);
    });


    // Clearing filter tags should update the result patent count to its initial value selections in Filter Slide


    it("Verify the Patent count changes by applying and removing Priority Date filter", function () {
        var filterName = "Priority Date", fromDate = "11/01/2000", toDate = "11/12/2015";
        step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
        var updatedPatentCount;
        // homePage.patent.advancedSearch.facetRowSearch(filterName, searchTerm);
        homePage.patent.advancedSearch.prioritydateRowFilter(filterName, fromDate, toDate);
        step("Verify that search results with selected filters are displayed");
        at(searchResults);
        updatedPatentCount = searchResults.getPatentCount();
        step("Resulting Patent count with Filter " + filterName + " is :" + updatedPatentCount);
        step("clear the filter tag " + filterName);
        searchResults.clearFilterTag(filterName);
        step("Verify that patent count get updated and not equal to initial value");
        expect(searchResults.patentCountText.getText()).not.toEqual(updatedPatentCount);
    });


    // verify that clearing filter remove the tags added

    it("Verify the filter tags cleared by removing Priority Date filter", function () {
        var filterName = "Priority Date", fromDate = "11/01/2000", toDate = "11/12/2015";
        step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
        // homePage.patent.advancedSearch.facetRowSearch(filterName, searchTerm);
        homePage.patent.advancedSearch.prioritydateRowFilter(filterName, fromDate, toDate);
        step("Verify that search results with selected filters are displayed");
        at(searchResults);
        expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
        step("Clear the filter " + filterName);
        searchResults.clearFilterTag(filterName);
        step("verify that Selected filter " + filterName + "  TAG is NOT DISPLAYED");
        expect(searchResults.isFilterTagPresent(filterName)).toEqual(false);
    });


    var facetSearchData = [
        { filterName: "Any Assignee", searchTerm: "Tesla Motors Inc" },
        { filterName: "Current Assignee", searchTerm: "RPX Corporation" },
        { filterName: "Tech Tags", searchTerm: "Services" },
    ];

    using(facetSearchData, function (data) {
        var filterName = data["filterName"], searchTerm = data["searchTerm"];
        it("should redirect users to search results for " + filterName + " filter with data: " + searchTerm, function () {
            step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
            // homePage.patent.advancedSearch.facetRowSearch(filterName, searchTerm);

            homePage.patent.advancedSearch.selectfacets(filterName, searchTerm);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
        });
    });
    // Clearing filter tags should update the result patent count to its initial value selections in Filter Slide
    using(facetSearchData, function (data) {
        var filterName = data["filterName"], searchTerm = data["searchTerm"];
        var updatedPatentCount;
        it("Verify the Patent count changes by applying and removing filter: " + filterName, function () {
            step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
            // homePage.patent.advancedSearch.facetRowSearch(filterName, searchTerm);
            homePage.patent.advancedSearch.selectfacets(filterName, searchTerm);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            updatedPatentCount = searchResults.getPatentCount();
            step("Resulting Patent count with Filter " + filterName + " is :" + updatedPatentCount);
            step("clear the filter tag " + filterName);
            searchResults.clearFilterTag(filterName);

            step("Verify that patent count get updated and not equal to initial value");
            expect(searchResults.patentCountText.getText()).not.toEqual(updatedPatentCount);
        });
    });

    // verify that clearing filter remove the tags added
    using(facetSearchData, function (data) {
        var filterName = data["filterName"], searchTerm = data["searchTerm"];
        it("Verify the filter tags cleared by removing filter: " + filterName, function () {
            step("Add " + filterName + " row and select " + searchTerm + " from autosuggest");
            // homePage.patent.advancedSearch.facetRowSearch(filterName, searchTerm);
            homePage.patent.advancedSearch.selectfacets(filterName, searchTerm);
            step("Verify that search results with selected filters are displayed");
            at(searchResults);
            expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
            step("Clear the filter " + filterName);
            searchResults.clearFilterTag(filterName);
            step("verify that Selected filter " + filterName + "  TAG is NOT DISPLAYED");
            expect(searchResults.isFilterTagPresent(filterName)).toEqual(false);
        });
    });

    // selecting patent status filter

    // Verify the newly added patent status in advanced search modal
    it("should redirect users to search results for patent status Date filter", function () {
        var filterName = 'Patent Status';
        step("Select patent status filter with value Abandoned Application");
        homePage.patent.advancedSearch.selectPatentByStatus("Abandoned Application");
        step("Verify that search results with selected filters are displayed");
        at(searchResults);
        expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
    });

    // Clearing filter tags should update the result patent count to its initial value selections in Filter Slide


    it("Verify the Patent count changes by applying and removing filter: Patent Status", function () {
        var filterName = 'Patent Status', updatedPatentCount;
        step("Select patent status filter with value Abandoned Application");
        homePage.patent.advancedSearch.selectPatentByStatus("Abandoned Application");
        step("Verify that search results with selected filters are displayed");
        at(searchResults);
        updatedPatentCount = searchResults.getPatentCount();
        step("Resulting Patent count with Filter " + filterName + " is :" + updatedPatentCount);
        step("clear the filter tag " + filterName);
        searchResults.clearFilterTag(filterName);
        step("Verify that patent count get updated and not equal to initial value");
        expect(searchResults.patentCountText.getText()).not.toEqual(updatedPatentCount);
    });


    // verify that clearing filter remove the tags added

    it("Verify the filter tags cleared by removing filter: Patent Status", function () {
        var filterName = 'Patent Status';
        step("Select patent status filter with value Abandoned Application");
        homePage.patent.advancedSearch.selectPatentByStatus("Abandoned Application");
        step("Verify that search results with selected filters are displayed");
        at(searchResults);
        expect(searchResults.secondfilterTags.getText()).toEqual(filterName);
        step("Clear the filter " + filterName);
        searchResults.clearFilterTag(filterName);
        step("verify that Selected filter " + filterName + "  TAG is NOT DISPLAYED");
        expect(searchResults.isFilterTagPresent(filterName)).toEqual(false);
    });



});