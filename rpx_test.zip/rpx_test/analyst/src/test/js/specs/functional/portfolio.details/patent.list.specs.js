require("../../../helpers/custom.matcher.helper");

var loginPage = require("../../../pages/login.page"),
    homePage = require("../../../pages/home.page"),
    portfolioDetailsPage = require("../../../pages/portfolio.details.page");

var using = require('jasmine-data-provider');

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

var portfolioId = "5818";
describe("Portfolio details", function () {
    beforeAll(function () {
        to(portfolioDetailsPage, portfolioId);
    });
    beforeEach(function () {
        addArgument("portfolioId", portfolioId);
        step("Login to the application and go to portfolio details");
    });

    it("should have grid display selected by default", function () {
        step("Verify that grid view is displayed by default");
        expect(portfolioDetailsPage.patentList.gridViewIcon.getAttribute("class")).toEqual("button tiny active-button");
    });

    it("should be able to expand the patent grid", function () {
        step("Expand the layout and verify that compress button is displayed");
        portfolioDetailsPage.detailsPanelExpandIcon.click();
        expect(portfolioDetailsPage.detailsPanelCollapseIcon.isDisplayed()).toEqual(true, "Collapse icon not displayed after expanding the view");
    });

    it("should be able to collapse the patent grid", function () {
        step("Collpase the layout and verify that compress button is displayed");
        portfolioDetailsPage.detailsPanelCollapseIcon.click();
        expect(portfolioDetailsPage.detailsPanelExpandIcon.isDisplayed()).toEqual(true, "Expand icon not displayed after expanding the view");
    });

    describe("Patent Grid", function () {
        it("should load patent details on clicking patent number from the grid", function () {
            step("Click on first patent number from the grid");
            portfolioDetailsPage.patentList.grid.clickCell(0, "Patent Number").then(function (expPatNum) {
                step("Verify title of the patent details loaded");
                expect(portfolioDetailsPage.patentDetailsHeader.title.getText()).toEqual(expPatNum);
            });
        });

        it("should load patents tab on clicking patent number from the grid", function () {
            step("click on first patent number from grid");
            portfolioDetailsPage.patentList.grid.clickCell(0, "Patent Number");
            expect(portfolioDetailsPage.patentDataTabs.getTabsList()).toEqual(['PORTFOLIO', 'PATENT']);
        });

        it("should have 'Patent Number', 'Alice Words', 'Priority Date' & 'Topic Cluster' columns displayed by default", function () {
            step("Verify the default columns displayed in patent grid");
            expect(portfolioDetailsPage.patentList.grid.getHeaders()).toEqual(['Patent Number', 'Alice Words', 'Priority Date', 'Topic Cluster']);
        });

        var patentGridSortData = [
            { column: "Patent Number", order: "ascending", type: "string" }, { column: "Patent Number", order: "descending", type: "string" },
            { column: "Alice Words", order: "ascending", type: "numeric" }, { column: "Alice Words", order: "descending", type: "numeric" },
            { column: "Priority Date", order: "ascending", type: "date" }, { column: "Priority Date", order: "descending", type: "date" },
            { column: "Topic Cluster", order: "ascending", type: "string" }, { column: "Topic Cluster", order: "descending", type: "string" }
        ];

        using(patentGridSortData, function (data) {
            var columnName = data["column"], orderBy = data["order"], type = data["type"];

            it("should have " + columnName + " sortable by " + orderBy, function () {
                step("Sort " + columnName + " by " + orderBy + " in patent grid and verify it for sort type " + type);
                portfolioDetailsPage.patentList.grid.sort(data["column"], data["order"]);
                expect(portfolioDetailsPage.patentList.grid.getFirstPageColumn(columnName)).toEqualSort({ order: orderBy, type: type });
            });
        });

        var allPatentGridColumns = [
            'Add Column (+)', '# of Claim Charts', 'Analyst Sum', 'Detection Rating', 'Enforceability Rating', 'Has Representative Claim', 'Importance Rating',
            'Is Analyzed', 'Is Stretch Claim', 'Literal Relevance Rating', 'PRC', 'PRC Count', 'Priority Rating', 'Relevant Companies Rating',
            '# of US Patents in Family', 'Foreign Counterparts', 'Open Continuances', 'Patent Family Name', 'Alice Words', 'Citations-Backward',
            'Citations-Forward', 'Citing Assignees', 'Citing Clusters', 'Claim Originality', 'Claim Simplicity', 'Claims Length', 'Defendant Score',
            'Examination Thoroughness', 'Limiting Language Score', 'Litigation Likelihood', 'Overall Score', 'Preposition Score', 'Expiration Date',
            'Filing Date', 'Issue Date', 'Priority Date', 'Freeform Tags', 'IPC Class', 'Tech Tags', 'Topic Cluster', 'Grant Time', 'References - Backward',
            'References - Forward', 'Shortest Claim Length', 'Title'
        ];

        it("should have column selector with 42 options to select from", function () {
            step("Verify the options available to select from column selector");
            expect(portfolioDetailsPage.patentList.grid.columnSelector().getAvailableColumns()).toEqual(allPatentGridColumns);
        });

        it("should be able to de select all columns except patent number column", function () {
            step("Remove all the columns from patent grid");
            portfolioDetailsPage.patentList.grid.columnSelector().deSelectAllColumns();
            step("Verify that 'Patent Number' column is displayed after removing all columns");
            expect(portfolioDetailsPage.patentList.grid.getHeaders()).toEqual(["Patent Number"]);
        });

        var expHeadersAfterAllOptions = [
            'Patent Number', '# Of Claim Charts', '# Of U S Patents In Family', 'Alice Words', 'Analyst Sum', 'Citations-Backward', 'Citations-Forward',
            'Citing Assignees', 'Citing Clusters', 'Claim Originality', 'Claim Simplicity', 'Claims Length', 'Defendant Score'
        ];

        it("should be able to select all columns from column selector", function () {
            step("Add all available columns from column selector");
            portfolioDetailsPage.patentList.grid.columnSelector().selectAllColumns();
            expect(portfolioDetailsPage.patentList.grid.getHeaders()).toEqual(expHeadersAfterAllOptions);
        });
    });

    describe("Patent Grid - Actions", function () {
        beforeEach(function () {
            step("Select first row from patent grid");
            portfolioDetailsPage.patentList.grid.selectRow(0);
        });

        it("should display modal on accessing 'View family members not in portfolio' option from actions", function () {
            step("Select 'View Family Members not in Portfolio' option from the actions menu");
            portfolioDetailsPage.patentList.selectActionItem("View Family Members not in Portfolio");
            step("Verify that family members not in portfolio modal is displayed");
            expect(portfolioDetailsPage.familyMemberNotInPortfolio.modal.isDisplayed()).toEqual(true, "Family members not in portfolio modal not displayed");
            portfolioDetailsPage.familyMemberNotInPortfolio.close();
        });

        it("should display create portfolio modal on accessing 'Create Portfolio' option from actions", function () {
            step("Select 'Create Portfolio' option from the actions menu");
            portfolioDetailsPage.patentList.selectActionItem("Create Portfolio");
            step("Verify that 'Create Portfolio' modal is displayed");
            expect(portfolioDetailsPage.createPortfolio.modal.isDisplayed()).toEqual(true, "Create Portfolio modal not displayed");
            portfolioDetailsPage.createPortfolio.close();
        });

        it("should display add to portfolio modal on accessing 'Add to Portfolio' option from actions", function () {
            step("Select 'Add to Portfolio' option from the actions menu");
            portfolioDetailsPage.patentList.selectActionItem("Add to Portfolio");
            step("Verify that 'Add to Portfolio' modal is displayed");
            expect(portfolioDetailsPage.addToPortfolio.modal.isDisplayed()).toEqual(true, "Add to Portfolio modal not displayed");
            portfolioDetailsPage.addToPortfolio.close();
        });

        it("should display custom export modal on accessing 'Custom Export' option from actions", function () {
            step("Select 'Custom Export' option from the actions menu");
            portfolioDetailsPage.patentList.selectActionItem("Custom Export");
            step("Verify that 'Custom Export' modal is displayed");
            expect(portfolioDetailsPage.customExport.modal.isDisplayed()).toEqual(true, "Custom Export modal not displayed");
            portfolioDetailsPage.customExport.close();
        });
    });

    describe("Card view", function () {
        it("should have an option to view the patents in card view", function () {
            step("Click on the card view icon");
            portfolioDetailsPage.patentList.cardViewIcon.click();
            angularWait();
            step("verify that patents are displayed in card view");
            expect(portfolioDetailsPage.patentList.cardView.isDisplayed()).toEqual(true, "Card View is not displayed");
        });
    });
});