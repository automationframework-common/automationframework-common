require("../../../helpers/custom.matcher.helper");

var loginPage = require("../../../pages/login.page"),
    homePage = require("../../../pages/home.page"),
    portfolioDetailsPage = require("../../../pages/portfolio.details.page");

var using = require('jasmine-data-provider');

beforeAll(function () {
   to(loginPage);
   loginPage.loginAsAdmin();
   at(homePage);
});

var portfolioId = "5818";
describe("Portfolio details", function () {
    beforeAll(function () {
        to(portfolioDetailsPage, portfolioId);
    });
    beforeEach(function () {
        step("Login and navigate to portfolio details");
    });

    describe("Petitions tab", function () {
        beforeAll(function () {
            portfolioDetailsPage.patentDataSubTabs.portfolio.select("Petitions");
        });
        beforeEach(function () {
            step("Click on Petitions tab");
        });

        it("should have 3 sub navs to select from", function () {
            step("Verify the sub navs displayed for Portfolio - Petitions tab");
            expect(portfolioDetailsPage.patentDataTertirayNavs.petitions.getTabsList())
                .toEqual(['PETITIONS', 'PETITIONERS', 'PATENTS']);
        });

        describe("Petitions nav", function () {
            beforeAll(function () {
                portfolioDetailsPage.patentDataTertirayNavs.petitions.select("Petitions");
            });
            beforeEach(function () {
                step("Click on Petitions sub nav");
            });

            it("should have grid with 6 headers displayed", function () {
                step("Verify the headers displayed in the grid");
                expect(portfolioDetailsPage.portfolioPetitionsTab.petitionsTab.grid.getHeaders())
                    .toEqual(['Date Filed', 'Patent Number', 'Case Number', 'Petitioners', 'Status', 'Institution Decision Date']);
            });

            it("should direct the users to portal patent page on clicking first link from Patent Number column", function () {
                step("Click on first link in Patent Number column");
                portfolioDetailsPage.portfolioPetitionsTab.petitionsTab.grid.clickColumn("Patent Number", 0);
                inNewWindow(function() {
                    step("Verify that patent detail page is loaded in new tab");
                    expect(getCurrentUrl()).toContain("/pat/");
                });
            });

            it("should direct the users to portal ptab page on clicking first link from Case Number column", function () {
                step("Click on first link in Case Number column");
                portfolioDetailsPage.portfolioPetitionsTab.petitionsTab.grid.clickColumn("Case Number", 0);
                inNewWindow(function() {
                    step("Verify that ptab detail page is loaded in new tab");
                    expect(getCurrentUrl()).toContain("/ptabs/");
                });
            });

            it("should direct the users to portal ent page on clicking first link from Petitioners column", function () {
                step("Click on first link in Petitioners column");
                portfolioDetailsPage.portfolioPetitionsTab.petitionsTab.grid.clickColumn("Petitioners", 0);
                inNewWindow(function() {
                    step("Verify that entity detail page is loaded in new tab");
                    expect(getCurrentUrl()).toContain("/ent/");
                });
            });

            var petitionsSortData = [
                { column: "Date Filed", order: "ascending", type: "date"}, { column: "Date Filed", order: "descending", type: "date"},
                { column: "Patent Number", order: "ascending", type: "string"}, { column: "Patent Number", order: "descending", type: "string"},
                { column: "Case Number", order: "ascending", type: "string"}, { column: "Case Number", order: "descending", type: "string"},
                { column: "Petitioners", order: "ascending", type: "string"}, { column: "Petitioners", order: "descending", type: "string"},
                { column: "Status", order: "ascending", type: "string"}, { column: "Status", order: "descending", type: "string"},
                { column: "Institution Decision Date", order: "ascending", type: "date"}, { column: "Institution Decision Date", order: "descending", type: "date"}
            ];

            using(petitionsSortData, function (data) {
                var columnName = data["column"], orderBy = data["order"], type = data["type"];

                it("should have " + columnName + " sortable by " + orderBy, function () {
                    step("Sort " + columnName + " by " + orderBy + " in petitions and verify it for sort type " + type);
                    portfolioDetailsPage.portfolioPetitionsTab.petitionsTab.grid.sort(data["column"], data["order"]);
                    expect(portfolioDetailsPage.portfolioPetitionsTab.petitionsTab.grid.getFirstPageColumn(columnName)).toEqualSort({ order: orderBy, type: type });
                });
            });
        });

        describe("Petitioners nav", function () {
            beforeAll(function () {
                portfolioDetailsPage.patentDataTertirayNavs.petitions.select("Petitioners");
            });
            beforeEach(function () {
                step("Click on Petitioners sub nav");
            });

            it("should have grid with 2 headers displayed", function () {
                step("Verify the headers displayed in the grid");
                expect(portfolioDetailsPage.portfolioPetitionsTab.petitionersTab.grid.getHeaders())
                    .toEqual(['Petitioners', 'No. Of Petitions']);
            });

            it("should direct the users to portal ent page on clicking first link from Petitioners column", function () {
                step("Click on first link in Petitioners column");
                portfolioDetailsPage.portfolioPetitionsTab.petitionersTab.grid.clickColumn("Petitioners", 0);
                inNewWindow(function() {
                    step("Verify that entity detail page is loaded in new tab");
                    expect(getCurrentUrl()).toContain("/ent/");
                });
            });

            var petitionersSortData = [
                { column: "Petitioners", order: "ascending", type: "string"}, { column: "Petitioners", order: "descending", type: "string"},
                { column: "No. Of Petitions", order: "ascending", type: "string"}, { column: "No. Of Petitions", order: "descending", type: "string"}
            ];

            using(petitionersSortData, function (data) {
                var columnName = data["column"], orderBy = data["order"], type = data["type"];

                it("should have " + columnName + " sortable by " + orderBy, function () {
                    step("Sort " + columnName + " by " + orderBy + " in petitioners and verify it for sort type " + type);
                    portfolioDetailsPage.portfolioPetitionsTab.petitionersTab.grid.sort(data["column"], data["order"]);
                    expect(portfolioDetailsPage.portfolioPetitionsTab.petitionersTab.grid.getFirstPageColumn(columnName)).toEqualSort({ order: orderBy, type: type });
                });
            });

            it("should have sub grid with 4 headers displayed", function () {
                step("Expand the first sub grid");
                portfolioDetailsPage.portfolioPetitionsTab.petitionersTab.grid.subGrid().expandFirst();
                step("Verify the headers displayed in the sub grid");
                expect(portfolioDetailsPage.portfolioPetitionsTab.petitionersTab.grid.subGrid().getHeaders())
                    .toEqual([ 'Date Filed', 'Case Number', 'Case Name', 'Status' ]);
            });

            var petitionersSubGridSortData = [
                { column: "Date Filed", order: "ascending", type: "string"}, { column: "Date Filed", order: "descending", type: "string"},
                { column: "Case Number", order: "ascending", type: "string"}, { column: "Case Number", order: "descending", type: "string"},
                { column: "Case Name", order: "ascending", type: "string"}, { column: "Case Name", order: "descending", type: "string"},
                { column: "Status", order: "ascending", type: "string"}, { column: "Status", order: "descending", type: "string"}
            ];

            using(petitionersSubGridSortData, function (data) {
                var columnName = data["column"], orderBy = data["order"], type = data["type"];

                it("should have sub grid with " + columnName + " sortable by " + orderBy, function () {
                    step("Sort " + columnName + " by " + orderBy + " in petitioners sub grid and verify it for sort type " + type);
                    portfolioDetailsPage.portfolioPetitionsTab.petitionersTab.grid.subGrid().sort(data["column"], data["order"]);
                    expect(portfolioDetailsPage.portfolioPetitionsTab.petitionersTab.grid.subGrid().getColumn(columnName)).toEqualSort({ order: orderBy, type: type });
                });
            });
        });

        describe("Patents nav", function () {
            beforeAll(function () {
                portfolioDetailsPage.patentDataTertirayNavs.petitions.select("Patents");
            });
            beforeEach(function () {
                step("Click on Patents sub nav");
            });

            it("should have grid with 2 headers displayed", function () {
                step("Verify the headers displayed in the grid");
                expect(portfolioDetailsPage.portfolioPetitionsTab.patentsTab.grid.getHeaders())
                    .toEqual(['Patent', 'No. Of Petitions']);
            });

            it("should direct the users to portal pat page on clicking first link from Patent column", function () {
                step("Click on first link in Patent column");
                portfolioDetailsPage.portfolioPetitionsTab.patentsTab.grid.clickColumn("Patent", 0);
                inNewWindow(function() {
                    step("Verify that patent detail page is loaded in new tab");
                    expect(getCurrentUrl()).toContain("/pat/");
                });
            });

            var patentSortData = [
                { column: "Patent", order: "ascending", type: "string"}, { column: "Patent", order: "descending", type: "string"},
                { column: "No. Of Petitions", order: "ascending", type: "string"}, { column: "No. Of Petitions", order: "descending", type: "string"}
            ];

            using(patentSortData, function (data) {
                var columnName = data["column"], orderBy = data["order"], type = data["type"];

                it("should have " + columnName + " sortable by " + orderBy, function () {
                    step("Sort " + columnName + " by " + orderBy + " in patents and verify it for sort type " + type);
                    portfolioDetailsPage.portfolioPetitionsTab.patentsTab.grid.sort(data["column"], data["order"]);
                    expect(portfolioDetailsPage.portfolioPetitionsTab.patentsTab.grid.getFirstPageColumn(columnName)).toEqualSort({ order: orderBy, type: type });
                });
            });

            it("should have sub grid with 4 headers displayed", function () {
                step("Expand the first sub grid");
                portfolioDetailsPage.portfolioPetitionsTab.patentsTab.grid.subGrid().expandFirst();
                step("Verify the headers displayed in the sub grid");
                expect(portfolioDetailsPage.portfolioPetitionsTab.patentsTab.grid.subGrid().getHeaders())
                    .toEqual([ 'Date Filed', 'Case Number', 'Case Name', 'Status' ]);
            });

            var patentsSubGridSortData = [
                { column: "Date Filed", order: "ascending", type: "date"}, { column: "Date Filed", order: "descending", type: "date"},
                { column: "Case Number", order: "ascending", type: "string"}, { column: "Case Number", order: "descending", type: "string"},
                { column: "Case Name", order: "ascending", type: "string"}, { column: "Case Name", order: "descending", type: "string"},
                { column: "Status", order: "ascending", type: "string"}, { column: "Status", order: "descending", type: "string"}
            ];

            using(patentsSubGridSortData, function (data) {
                var columnName = data["column"], orderBy = data["order"], type = data["type"];

                it("should have sub grid with " + columnName + " sortable by " + orderBy, function () {
                    step("Sort " + columnName + " by " + orderBy + " in patents sub grid and verify it for sort type " + type);
                    portfolioDetailsPage.portfolioPetitionsTab.patentsTab.grid.subGrid().sort(data["column"], data["order"]);
                    expect(portfolioDetailsPage.portfolioPetitionsTab.patentsTab.grid.subGrid().getColumn(columnName)).toEqualSort({ order: orderBy, type: type});
                });
            });
        });

    });
});