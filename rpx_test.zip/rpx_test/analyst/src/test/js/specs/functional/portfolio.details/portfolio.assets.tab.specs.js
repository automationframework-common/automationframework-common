var loginPage = require("../../../pages/login.page"),
    portfolioDetailsPage = require("../../../pages/portfolio.details.page");

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

var portfolioId = "5818";
describe("Portfolio details", function () {
    beforeAll(function () {
        to(portfolioDetailsPage, portfolioId);
    });
    beforeEach(function () {
        step("Login and navigate to portfolio details");
    });

    describe("Assets tab", function () {
        it("should have 5 sub navs to select from", function () {
            step("Verify the sub navs displayed for Portfolio - Assets tab");
            expect(portfolioDetailsPage.patentDataTertirayNavs.assets.getTabsList())
                .toEqual(['OVERVIEW', 'LANDSCAPE', 'CLUSTERS', 'TECHTAGS', 'CPC']);
        });

        describe("Overview nav", function () {
            beforeAll(function () {
                portfolioDetailsPage.patentDataTertirayNavs.assets.select("Overview");
                portfolioDetailsPage.expandDetailsPanel();
            });
            beforeEach(function () {
                step("Click on Overview sub nav and expand the details panel");
            });

            it("should have grants count displayed", function () {
                step("Verify the grants count displayed");
                expect(portfolioDetailsPage.portfolioAssetsTab.overview.grantsCount.getText()).toEqual("34");
            });

            it("should have applications count displayed", function () {
                step("Verify the applications count displayed");
                expect(portfolioDetailsPage.portfolioAssetsTab.overview.applicationsCount.getText()).toEqual("0");
            });

            it("should have litigated count displayed", function () {
                step("Verify the litigated count displayed");
                expect(portfolioDetailsPage.portfolioAssetsTab.overview.litigationsCount.getText()).toEqual("34");
            });

            it("should have patents challenged count displayed", function () {
                step("Verify the patents challenged count displayed");
                expect(portfolioDetailsPage.portfolioAssetsTab.overview.patentsChallengedCount.getText()).toEqual("7");
            });

            it("should have PA references count displayed", function () {
                step("Verify the potential art references count displayed");
                expect(portfolioDetailsPage.portfolioAssetsTab.overview.potentialReferencesCount.getText()).toEqual("9");
            });
        });

        describe("Landscape nav", function () {
            beforeAll(function () {
                portfolioDetailsPage.patentDataTertirayNavs.assets.select("Landscape");
            });
            beforeEach(function () {
                step("Click on Landscape sub nav");
            });

            it("should have landscape high chart displayed", function () {
                step("Verify that landscape high chart is displayed");
                expect(portfolioDetailsPage.portfolioAssetsTab.landscape.highChart.isDisplayed())
                    .toEqual(true, "Landscape high chart is not displayed");
            });
        });

        describe("Clusters nav", function () {
            beforeAll(function () {
                portfolioDetailsPage.patentDataTertirayNavs.assets.select("Clusters");
            });
            beforeEach(function () {
                step("Click on Clusters sub nav");
            });

            it("should have clusters donut high chart displayed", function () {
                step("Verify that clusters donut high chart is displayed");
                expect(portfolioDetailsPage.portfolioAssetsTab.clusters.highChart.isDisplayed())
                    .toEqual(true, "Clusters donut high chart is not displayed");
            });
        });

        describe("TechTags nav", function () {
            beforeAll(function () {
                portfolioDetailsPage.patentDataTertirayNavs.assets.select("TechTags");
            });
            beforeEach(function () {
                step("Click on TechTags sub nav");
            });

            it("should have TechTags donut high chart displayed", function () {
                step("Verify that TechTags donut high chart is displayed");
                expect(portfolioDetailsPage.portfolioAssetsTab.techTags.highChart.isDisplayed())
                    .toEqual(true, "TechTags donut high chart is not displayed");
            });
        });

        describe("CPC nav", function () {
            beforeAll(function () {
                portfolioDetailsPage.patentDataTertirayNavs.assets.select("cpc");
            });
            beforeEach(function () {
                step("Click on CPC sub nav");
            });

            it("should have CPC donut high chart displayed", function () {
                step("Verify that CPC donut high chart is displayed");
                expect(portfolioDetailsPage.portfolioAssetsTab.cpc.highChart.isDisplayed())
                    .toEqual(true, "CPC donut high chart is not displayed");
            });
        });
    });
});