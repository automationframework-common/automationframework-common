var loginPage = require("../../../pages/login.page"),
    patentDetailsPage = require("../../../pages/patent.details.page"),
    patentClaims = require("../../../pages/patent.claims");  

beforeAll(function () {
    to(loginPage);
    loginPage.loginAsAdmin();
});

describe("Patent details", function () {
    var patId = "14667048";
    var patNum = "US 9,083,394 B2";
    beforeAll(function () {
         // to(patentDetailsPage, patId);
          // Changing URL navigation using patnum for UserStory : 1720
          to(patentDetailsPage, patNum);
    });

    describe("Claim(1)[Technology]", function () {
        beforeEach(function () {
            addArgument("pat_id", patNum);
            step("Click on first claim of the patent");
            patentClaims.clickClaim(0);
            step("Delete all existing technology tags");
            patentClaims.deleteAllTechnologyTags();
        });

        it("should display 'No Tech Tags Found' w/o tech tags", function () {
            step("Verify that 'No Tech Tags Found' message is displayed for w/o tech tags");
            expect(patentClaims.claimsTechnologyTab.noTags.getText())
                .toEqual("No Tech Tags Found")
        });

        var techTags = [
            "Modem",
            // "Networking Wireless Components",
            "Network Protocol"
        ];
        var expectedResults = ['Networking > Cable > Modem','Network Protocol'];
        it("should be able to add tags from search select", function () {
            step("Add technology from search select");
            patentClaims.claimsTechnologyTab.searchSelect.select(techTags);
            step("Verify that added technology tag is displayed");
            expect(patentClaims.claimsTechnologyTab.tags.getTags()).toEqual(expectedResults);
        });

        var techTagsRatingData = {
            "Modem": "3",
            "Network Protocol": "2"
        };
        var expTechTagsRatingData = [
            { "Networking > Cable > Modem": { "actual": 3, "max": null } },
            { "Network Protocol": { "actual": 2, "max": null } }
        ];
        it("should be able to edit the star rarting", function () {
            step("Add technology tags for " + techTags);
            patentClaims.createTechnologyTags(techTags);
            step("Edit the star rating of the technology tag");
            patentClaims.claimsTechnologyTab.tags.setData(techTagsRatingData);
            step("Verify the star rating of the edited technology tag")
            expect(patentClaims.claimsTechnologyTab.tags.getData())
                .toEqual(expTechTagsRatingData);
        });

        it("should display 'No Tech Tags Found' after deleting all tech tags", function () {
            step("Add multiple technology tags");
            patentClaims.createTechnologyTags(techTags);
            step("Delete all the technology tags");
            patentClaims.claimsTechnologyTab.tags.deleteAll();
            step("Verify that 'No Tech Tags Founs' message is displayed after deleting all tags");
            expect(patentClaims.claimsTechnologyTab.noTags.isDisplayed())
                .toBe(true, "'No Tech Tags Found' message is not displayed after deleting all tags");
        });

        var techTagsForSort = [
            "Tablet",
            "Enterprise Manufacturing"
        ];
        var expectedtechTagsForSort = [
            "Application > Enterprise Manufacturing",
            "Computer > Tablet"
        ];
        it("should display the tags sorted by tag name ascending", function () {
            step("Add multiple technology tags");
            patentClaims.claimsTechnologyTab.searchSelect.select(techTagsForSort);
            step("Verify that added tech tags are displayed in sorted order");
            expect(patentClaims.claimsTechnologyTab.tags.getTags()).
                toEqual(expectedtechTagsForSort.sort());
        });
    });

    describe("Technology tags", function () {
        var patIdWithMultiClaims = "5896522" , patNumWithMultiClaims = "US 5,985,712 A1";
        beforeEach(function () {
            to(patentDetailsPage, patNumWithMultiClaims);
            addArgument("pat_id", patNumWithMultiClaims);
            step("Click on second claim of the patent and delete all existing tech tags");
            patentDetailsPage.patentClaims.clickClaim(0);
            patentClaims.deleteAllTechnologyTags();
            step("Click on first claim of the patent and delete all existing tech tags");
            patentDetailsPage.patentClaims.clickClaim(0);
            patentClaims.deleteAllTechnologyTags();
        });

        it("for a claim should not be displayed in another claim", function () {
            step("Add technology tags for first claim");
            patentClaims.createTechnologyTags("ERP");
            step("Access second claim and verify that first claim tech tags are not displayed");
            patentDetailsPage.patentClaims.clickClaim(1);
            expect(patentClaims.claimsTechnologyTab.tags.getTags()).toEqual([]);
        });
    });
});

describe("Technology-tags", function () {
    var patId = "6690";
    var patNum = "US 8,478,754 B2";
    beforeAll(function () {
         // to(patentDetailsPage, patId);
          // Changing URL navigation using patnum for UserStory : 1720
          to(patentDetailsPage, patNum);
          step("Click on first claim of the patent");
            patentClaims.clickClaim(0);
            step("Delete all existing technology tags");
            patentClaims.deleteAllTechnologyTags();
    });

});
