package com.savvas.sm.utils.sql.helper;

import java.sql.Timestamp;

/***
 * This class represents the DB_table- assignment
 * 
 * @author madhan.nagarathinam
 *
 */
public class AssignmentTable {
    // define column names from table as variables
    private int assignment_id;
    private String assignment_owner_id;
    private int cttype_id;
    private int content_base_id;
    private String assignment_title;
    private Timestamp assignment_start_time;
    private Timestamp assignment_end_time;
    private Timestamp assigned_date;
    private int is_deleted;
    private int is_inprogress;
    private String description;
    private Timestamp date_updated;
    private Timestamp date_created;

    /**
     * No-arg constructor
     */
    public AssignmentTable() {

    }

    /**
     * Constructor used to create Objects for assignment table
     * (Insert/Update/Retrieve)
     * 
     * @param assignment_id
     * @param assignment_owner_id
     * @param cttype_id
     * @param content_base_id
     * @param assignment_title
     * @param assignment_start_time
     * @param assignment_end_time
     * @param assigned_date
     * @param is_deleted
     * @param is_inprogress
     * @param description
     * @param date_updated
     * @param date_created
     * 
     */
    public AssignmentTable( int assignment_id, String assignment_owner_id, int cttype_id, int content_base_id, String assignment_title, Timestamp assignment_start, Timestamp assignment_end, Timestamp assigned_date, int is_deleted, int is_inprogress,
            String description, Timestamp date_upd, Timestamp date_create ) {
        this.assignment_id = assignment_id;
        this.assignment_owner_id = assignment_owner_id;
        this.cttype_id = cttype_id;
        this.content_base_id = content_base_id;
        this.assignment_title = assignment_title;
        this.assignment_start_time = assignment_start;
        this.assignment_end_time = assignment_end;
        this.assigned_date = assigned_date;
        this.is_deleted = is_deleted;
        this.is_inprogress = is_inprogress;
        this.description = description;
        this.date_updated = date_upd;
        this.date_created = date_create;
    }

    /**
     * This inner class represents the DB_table- assignments. Used by the BFF-
     * GET Assignment (Mastery)
     * 
     * @author madhan.nagarathinam
     *
     */
    public class AssignmentMastery {
        // define fields from BFF - Assignment response
        private String assignmentId;
        private String assignmentName;

        /**
         * Constructor used to create Objects for Assignment table. By
         * accommodating the response fields of BFF- Assignments Mastery
         * response
         * 
         * @param assignmentId
         * @param assignmentName
         */
        public AssignmentMastery( String assignment_Id, String assignment_Name ) {
            this.assignmentId = assignment_Id;
            this.assignmentName = assignment_Name;
        }

        /**
         * Getter method for assignmentId
         * 
         * @return assignmentId
         */
        public String getAssignmentId() {
            return this.assignmentId;
        }

        /**
         * Getter method for assignmentName
         * 
         * @return assignmentName
         */
        public String getAssignmentName() {
            return this.assignmentName;
        }

    }
}