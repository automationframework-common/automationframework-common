package com.savvas.sm.utils;

import com.learningservices.utils.Log;
import com.savvas.sm.log.api.LogAPIResponse;
import org.apache.commons.lang3.StringUtils;
import org.apache.hc.client5.http.classic.methods.*;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.Header;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.apache.hc.core5.http.message.BasicHeader;
import org.apache.hc.core5.net.URIBuilder;
import org.apache.http.client.methods.HttpUriRequest;
import org.testng.Assert;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class RestHttpClientUtil {

    /**
     * @param baseURL
     * @param headers
     * @param inputParameters
     * @param resource
     * @param body
     * @return
     * @throws Exception
     */
    public static HashMap<String, String> POST(String baseURL, Map<String, String> headers, Map<String, String> inputParameters, String resource, String body) throws Exception {
        Log.message("POST Command URL:" + baseURL + File.separator + resource + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Params : \n" + inputParameters);
        return getResponseMap("POST", baseURL+resource, headers.get("user-id"), putOrPost(baseURL, resource, new HttpPost(baseURL), headers, inputParameters, body));
    }

    /**
     * @param baseURL
     * @param headers
     * @param inputParameters
     * @param resource
     * @param body
     * @return
     * @throws Exception
     */
    public static HashMap<String, String> PUT(String baseURL, Map<String, String> headers, Map<String, String> inputParameters, String resource, String body) throws Exception {
        Log.message("PUT Command URL:" + baseURL + File.separator + resource + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Params : \n" + inputParameters);
        HttpPut httpPut = new HttpPut(baseURL + resource);

        CloseableHttpClient httpClient = HttpClients.createDefault();

        for (Entry<String, String> header : headers.entrySet()) {

            httpPut.addHeader(header.getKey(), header.getValue());
        }

        if (StringUtils.isNotBlank(body)) {
            StringEntity entity = new StringEntity(body);
            httpPut.setEntity(entity);
        }
        CloseableHttpResponse httpResponse = httpClient.execute(httpPut);
        return getResponseMap("PUT", baseURL+resource, headers.get("user-id"), httpResponse);
    }

    /**
     * @param baseURL
     * @param headers
     * @param inputParameters
     * @param resource
     * @param body
     * @return
     * @throws Exception
     */
    public static HashMap<String, String> PATCH(String baseURL, Map<String, String> headers, Map<String, String> inputParameters, String resource, String body) throws Exception {
        Log.message("PATCH Command URL:" + baseURL + File.separator + resource + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Params : \n" + inputParameters);
        HttpPatch httpPatch = new HttpPatch(baseURL + resource);
        HttpClientUtilsService service = new HttpClientUtilsService();
        CloseableHttpClient httpClient = HttpClients.createDefault();

        for (Entry<String, String> header : headers.entrySet()) {

            httpPatch.addHeader(header.getKey(), header.getValue());
        }

        if (StringUtils.isNotBlank(body)) {
            StringEntity entity = new StringEntity(body);
            httpPatch.setEntity(entity);
        }
        CloseableHttpResponse httpResponse = httpClient.execute(httpPatch);
        return getResponseMap("PATCH", baseURL+resource, headers.get("user-id"), httpResponse);
    }

    /**
     * @param baseURL
     * @param headers
     * @param inputParameters
     * @param resource
     * @param body
     * @return
     * @throws Exception
     */
    public static HashMap<String, String> DELETE(String baseURL, Map<String, String> headers, Map<String, String> inputParameters, String resource, String body) throws Exception {

        Log.message("DELETE Command URL:" + baseURL + File.separator + resource + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Params : \n" + inputParameters);
        HttpDelete httpDelete = new HttpDelete(baseURL + resource);

        CloseableHttpClient httpClient = HttpClients.createDefault();

        for (Entry<String, String> header : headers.entrySet()) {

            httpDelete.addHeader(header.getKey(), header.getValue());
        }

        if (StringUtils.isNotBlank(body)) {
            StringEntity entity = new StringEntity(body);

            Log.message("entity: " + entity);
            httpDelete.setEntity(entity);
        }
        CloseableHttpResponse httpResponse = httpClient.execute(httpDelete);
        return getResponseMap("DELETE", baseURL+resource, headers.get("user-id"), httpResponse);
    }

    private static CloseableHttpResponse putOrPost(String baseURL, String resource, HttpPost httpRequest, Map<String, String> headers, Map<String, String> inputParameters, String body) throws Exception {
        Log.message("POST Command URL:" + baseURL + File.separator + resource + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Params : \n" + inputParameters);
        HttpPost httpPost = new HttpPost(baseURL + resource);
        HttpClientUtilsService service = new HttpClientUtilsService();
        CloseableHttpClient httpClient = HttpClients.createDefault();

        for (Entry<String, String> header : headers.entrySet()) {

            httpPost.addHeader(header.getKey(), header.getValue());
        }

        if (StringUtils.isNotBlank(body)) {
            StringEntity entity = new StringEntity(body);
            httpPost.setEntity(entity);
        }
        CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
        return httpResponse;
    }

    /**
     * @param baseURL
     * @param resource
     * @param headers
     * @param inputParameters
     * @return
     * @throws Exception
     */
    public static HashMap<String, String> GET(String baseURL, String resource, Map<String, String> headers, Map<String, String> inputParameters) throws Exception {
        Log.message("GET Command URL:" + baseURL + File.separator + resource + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Params : \n" + inputParameters);
        HashMap<String, String> responseMap = new HashMap<>();
        try {
            CloseableHttpClient httpClient = HttpClients.createDefault();
            URIBuilder uriBuilder = new URIBuilder(baseURL);
            uriBuilder.setPath(resource);
            if (!inputParameters.isEmpty()) {
                for (Entry<String, String> params : inputParameters.entrySet()) {
                    uriBuilder.addParameter(params.getKey(), params.getValue());
                }
            }
            HttpGet httpGet = new HttpGet(uriBuilder.build());
            for (Entry<String, String> header : headers.entrySet()) {
                httpGet.addHeader(header.getKey(), header.getValue());
            }
            CloseableHttpResponse httpResponse = httpClient.execute(httpGet);

            responseMap = getResponseMap("GET", baseURL+resource, headers.get("user-id"), httpResponse);
        } catch (Exception e) {
            Log.message("Exception " + e.getMessage());
        }
        return responseMap;
    }

    /**
     * @param baseURL
     * @param resource
     * @param headers
     * @param inputParameters
     * @return
     * @throws Exception
     */
    public static HashMap<String, String> DELETE(String baseURL, String resource, Map<String, String> headers, Map<String, String> inputParameters) throws Exception {
        Log.message("DELETE Command URL:" + baseURL + File.separator + resource + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Params : \n" + inputParameters);
        HttpDelete httpDel = new HttpDelete(baseURL + resource);
        HttpClientUtilsService service = new HttpClientUtilsService();
        CloseableHttpClient httpClient = HttpClients.createDefault();
        for (Entry<String, String> header : headers.entrySet()) {

            httpDel.addHeader(header.getKey(), header.getValue());
        }

        CloseableHttpResponse httpResponse = httpClient.execute(httpDel);
        return getResponseMap("DELETE", baseURL+resource, headers.get("user-id"), httpResponse);
    }

    public static URI getUrl(String baseUrl, String resource, Map<String, String> inputParameters) throws Exception {
        StringBuilder requestUrl = new StringBuilder(baseUrl).append(resource);
        URIBuilder uriBuilder = new URIBuilder();
        try {
            uriBuilder.setPath(requestUrl.toString());
            if (!inputParameters.isEmpty()) {
                for (Entry<String, String> params : inputParameters.entrySet()) {
                    uriBuilder.addParameter(params.getKey(), params.getValue());
                }
            }
            return uriBuilder.build();
        } catch (URISyntaxException e) {
            Log.exception(e);
            Assert.fail();
        }
        return null;
    }

    public static HashMap<String, String> getResponseMap(String method, String url, String userId, CloseableHttpResponse httpResponse) throws Exception {
        org.apache.hc.core5.http.HttpEntity entity = httpResponse.getEntity();
        String inputLine;
        StringBuffer responseBody = new StringBuffer();
        if (entity != null) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(entity.getContent()));
            while ((inputLine = reader.readLine()) != null) {
                responseBody.append(inputLine);
            }
            reader.close();
        }
        HashMap<String, String> responseMap = new HashMap<String, String>();
        responseMap.put("statusCode", Integer.toString(httpResponse.getCode()));
        responseMap.put("body", responseBody.toString());
        Log.message("Status Code: " + responseMap.get("statusCode") + "\n");
        LogAPIResponse.log(method, url, userId, responseBody.toString());
        return responseMap;
    }

    /**
     * @param baseURL
     * @param resource
     * @param headers
     * @param inputParameters
     * @return
     * @throws Exception
     */
    public static org.apache.http.client.methods.CloseableHttpResponse GET_HttpResponse(String baseURL, String resource, Map<String, String> headers, Map<String, String> inputParameters) throws Exception {
        HttpClientUtilsService service = new HttpClientUtilsService();
        org.apache.http.impl.client.CloseableHttpClient httpClient = service.getCloseableHttpClient();
        HttpGet httpGet = new HttpGet(getUrl(baseURL, resource, inputParameters));

        for (Entry<String, String> header : headers.entrySet()) {
            Header head = new BasicHeader(header.getKey(), header.getValue());
            httpGet.addHeader(head);
        }

        org.apache.http.client.methods.CloseableHttpResponse httpResponse = httpClient.execute((HttpUriRequest) httpGet);
        return httpResponse;
    }
}