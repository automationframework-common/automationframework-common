package com.savvas.sm.utils.sme187.teacher.api.reports;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.DemographicFilters;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportAdminConstants;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportFilters;

import io.restassured.response.Response;

public class ReportAPI extends EnvProperties {
    /**
     * To get the teacher details from the Organizations
     * 
     * @param userId
     * @param orgIds
     * @param accessToken
     * @return
     */
    public HashMap<String, String> getTeachersList( String userId, List<String> orgIds, String accessToken ) {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        // Input Params
        HashMap<String, String> params = new HashMap<>();

        // Request Body
        StringBuffer requestBody = new StringBuffer();
        requestBody = requestBody.append( String.format( AdminConstants.FILTER_QUERY_REPORT, userId ) );
        for ( int i = 0; i < orgIds.size(); i++ ) {
            requestBody.append( orgIds.get( i ) );
            if ( i != orgIds.size() - 1 ) {
                requestBody.append( "\\\",\\\"" );
            } else {
                requestBody.append( "\\\"" );
            }
        }
        requestBody.append( AdminConstants.TEACHER_FILTER );

        // Makes a POST call
        Log.message( "Making Post call for Teacher List BFF for parameter: UserId: " + userId + " OrgId List: " + orgIds.toString() + "Access Token: " + accessToken );
        Log.message( "Request Body is \n" + requestBody.toString() );
        HashMap<String, String> postResponse = null;

        try {
            postResponse = RestHttpClientUtil.POST( AdminConstants.ADMIN_REPORT_BFF, headers, params, AdminConstants.GRAPHQL_ENDPOINT, requestBody.toString() );
            Log.message( "The received Response is: " + postResponse.toString() );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return postResponse;
    }

    /**
     * This method is used to GET an Grade listing BFF
     * 
     * @param smUrl
     * @param headers
     * @param userId
     * @param orgId
     * @param queryItems
     * @return
     */
    public HashMap<String, String> getGradeList( String userId, List<String> orgIds, String accessToken ) {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        // Input Params
        HashMap<String, String> params = new HashMap<>();

        // Request Body
        StringBuffer requestBody = new StringBuffer();
        requestBody.append( "{\"query\":\"query {  getOptionalFilters( userId:\\\"" + userId + "\\\" ,  orgIds: [  \\\"" );
        for ( int i = 0; i < orgIds.size(); i++ ) {
            requestBody.append( orgIds.get( i ) );
            if ( i != orgIds.size() - 1 ) {
                requestBody.append( "\\\",\\\"" );
            } else {
                requestBody.append( "\\\"" );
            }
        }
        requestBody.append( "] ) {    grades {      gradeName     gradeId     displayOrder gradeValue }}}\",\"variables\": {}}" );

        Log.message( "request body" + requestBody );

        // Makes a POST call
        Log.message( "Making Post call for Grade List BFF for parameter: UserId: " + userId + " OrgId List: " + orgIds.toString() + "Access Token: " + accessToken );
        HashMap<String, String> postResponse = null;

        try {
            postResponse = RestHttpClientUtil.POST( AdminConstants.GRADE_LISTING_BFF, headers, params, AdminConstants.GRAPHQL_ENDPOINT, requestBody.toString() );
            Log.message( "The received Response is: " + postResponse.toString() );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return postResponse;
    }

    /**
     * This method is used to GET an Course listing BFF
     * 
     * @param orgIds
     * @param API Details
     * @return
     */

    public HashMap<String, String> getCourseList( List<String> orgIds, HashMap<String, String> apiDetails, String reportType ) {

        //headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.AUTHORIZATION, "Bearer " + apiDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.USERID_SM_HEADER, apiDetails.get( Constants.USERID_HEADER ) );
        headers.put( Constants.ORGID_SM_HEADER, apiDetails.get( Constants.ORGANIZATION_ID ) );

        //Input Params
        HashMap<String, String> params = new HashMap<>();

        // Generating Request Body
        StringBuffer requestBody = new StringBuffer();
        requestBody.append( "{\"query\":\"query {  getCourseList(subjectTypeId:\\\"" + apiDetails.get( Constants.SUBJECT_TYPE_ID ) + "\\\", reportType:\\\"" + reportType + "\\\", userId:\\\"" + apiDetails.get( Constants.USERID_HEADER ) + "\\\" ,orgId:\\\""
                + apiDetails.get( Constants.ORGANIZATION_ID ) + "\\\",  orgIds: [  \\\"" );
        for ( int i = 0; i < orgIds.size(); i++ ) {
            requestBody.append( orgIds.get( i ) );
            if ( i != orgIds.size() - 1 ) {
                requestBody.append( "\\\",\\\"" );
            } else {
                requestBody.append( "\\\"" );
            }
        }

        // Hitting POST call
        requestBody.append( "] ) {courseList {assignmentId assignmentTitle assignerId organizationId assignerFirstName assignerLastName assignerMiddleName productId contentBaseId }}}\",\"variables\":{}}" );
        HashMap<String, String> postResponse = null;
        try {
            postResponse = RestHttpClientUtil.POST( AdminConstants.ADMIN_REPORT_BFF, headers, params, AdminConstants.GRAPHQL_ENDPOINT, requestBody.toString() );
            Log.message( "The received Response is: " + postResponse.toString() );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return postResponse;
    }

    /**
     * This method will return courses for given organization based on the
     * student selected
     * 
     * @param envUrl
     * @param userId
     * @param orgId
     * @param accessToken
     * @param subjectId
     * @param studentList
     * @return
     */
    public HashMap<String, String> getCourseListingforOrg( String envUrl, String userId, String orgIdHeader, String schoolID, String accessToken, String subjectId, List<String> studentList ) {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, orgIdHeader );

        // Input Params
        HashMap<String, String> params = new HashMap<>();
        params.put( AdminConstants.SUBJECT_TYPE_ID, subjectId );

        JSONObject jsonBody = new JSONObject();
        JSONArray organizationArray = new JSONArray();
        JSONArray studentArray = new JSONArray();
        organizationArray.put( schoolID );

        for ( String student : studentList ) {
            studentArray.put( student );
        }
        jsonBody.put( "orgIds", organizationArray );
        jsonBody.put( "studentIds", studentArray );

        Log.message( "request body" + jsonBody.toString() );

        // Makes a POST call
        HashMap<String, String> postResponse = null;
        try {
            postResponse = RestHttpClientUtil.POST( envUrl, headers, params, AdminConstants.GET_COURSE_LISTING, jsonBody.toString() );
            Log.message( "The received Response is: " + postResponse.toString() );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return postResponse;
    }

    /***
     * 
     * @author madhan.nagarathinam
     * 
     *         getGroupAndStudentDetails() -> This method get the details for
     *         groups and students
     *
     * 
     * @param graphQLBaseUrl - The URL can be nightly/prod:
     *            https://successmaker-report-bff-service-nightly.smdemo.info
     *            :nightly
     * 
     * @param headers - headers must contains org-id, user-id and authorization
     * 
     * @param requestBody - the requestBody should contain input query params
     * 
     * @return
     * 
     * @return response -> The Post Call(Graphql) response will be given as a
     *         static Response
     * @throws Exception
     */

    public Response getGroupAndStudentDetails( String graphQLBaseUrl, Map<String, String> headers, Map<String, Object> requestBody ) throws Exception {
        return RestAssuredAPIUtil.POST_REQ( graphQLBaseUrl, headers, requestBody, GetGroupAndStudentDetailsConstant.GROUP_AND_STUDENT_DETAILS_ENDPOINT );

    }

    /**
     * This method will hit the AFG BFF output Response
     * 
     * @param headers
     * @param filters
     * @return
     */
    public Response getAFGAdminReportData( Map<String, String> headers, Map<String, String> filters ) {
        String payload = ReportAdminConstants.AFG_PAYLOAD;
        payload = String.format( payload, headers.get( Constants.USERID_SM_HEADER ), headers.get( Constants.ORGID_SM_HEADER ) );
        for ( String filter : ReportAdminConstants.AFG_FILTERS ) {
            if ( !Objects.isNull( filters.get( filter ) ) ) {
                payload = payload.replace( filter, filters.get( filter ) );
            } else {
                if ( filter.equals( ReportAdminConstants.DATE_AT_RISK ) ) {
                    payload = payload.replace( filter, "10400" ); // 10400 - Default Value(Since IP)
                }
                payload = payload.replace( "\\\"" + filter + "\\\"", "" );
            }
        }
        Log.message( "Headers :" + headers );
        Log.message( "Payload : " + payload );
        return RestAssuredAPIUtil.POSTGraphQl( ReportAdminConstants.REPORT_BFF, headers, payload, AdminConstants.GRAPHQL_ENDPOINT );
    }

    /**
     * This method used to fetch report data from SEU grapphql
     * 
     * @param username
     * @param password
     * @param userId
     * @param userOrgId
     * @param schoolId
     * @param subject
     * @param filerValues - pass the optional filter values in HashMap
     * @return
     * @throws Exception
     */
    public static Response getSEUReport( String username, String password, String userId, String userOrgId, String schoolId, String subject, Map<String, String> filerValues ) throws Exception {

        // Add headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, userOrgId );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        // Set payload
        String payLoad = ReportAdminConstants.SEU_REPORT_PAYLOAD;
        payLoad = String.format( payLoad, userId, userOrgId, schoolId, subject );
        for ( Map.Entry<String, String> values : filerValues.entrySet() ) {
            if ( values.getKey().equals( ReportFilters.ADDITIONAL_GROUP_ID_VALUE ) ) {
                payLoad = payLoad.replace( values.getKey(), values.getValue() ); // Adding Additional Grouping value in
                                                                                 // payload in number format
            } else {
                payLoad = payLoad.replace( values.getKey(), "\\\"" + values.getValue() + "\\\"" ); // adding id value in
                                                                                                   // payload in string
                                                                                                   // format
            }
        }
        Log.message( "Headers :" + headers );
        Log.message( "Payload : " + payLoad );
        payLoad = payLoad.replace( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "0" ).replace( ReportFilters.TEACHER_ID_VALUE, "" ).replace( ReportFilters.GRADE_ID_VALUE, "" ).replace( ReportFilters.GROUP_ID_VALUE, "" ).replace( ReportFilters.ASSIGNMENT_ID,
                "" ).replace( DemographicFilters.DISABILITY_STATUS, "" ).replace( DemographicFilters.ENGLISH_PROFICIENCY, "" ).replace( DemographicFilters.GENDER, "" ).replace( DemographicFilters.MIGRANT_STATUS, "" ).replace( DemographicFilters.RACE,
                        "" ).replace( DemographicFilters.ETHNICITY, "" ).replace( DemographicFilters.SOCIO_STATUS, "" ).replace( DemographicFilters.SPECIAL_SERVICES, "" );
        Log.message( "Payload: " + payLoad );

        // Getting SEU repport response
        Response response = RestAssuredAPIUtil.POSTGraphQl( ReportAdminConstants.REPORT_BFF, headers, payLoad, AdminConstants.GRAPHQL_ENDPOINT );
        Log.message( "Response: " + response.getBody().asString() );
        return response;
    }

    /**
     * This method used to fetch report data from SPR graphql
     * 
     * @param username
     * @param password
     * @param userId
     * @param userOrgId
     * @param schoolId
     * @param subject
     * @param filerValues
     * @return
     * @throws Exception
     */
    public static Response getSPRReportBFF( String username, String password, String userId, String userOrgId, String schoolId, String subject, Map<String, String> filerValues ) throws Exception {

        // Add headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, userOrgId );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
        Log.message( "Generated Bearer Token : " + headers.get( Constants.AUTHORIZATION ) );
        Log.message( "Generated Org Id : " + userOrgId );
        Log.message( "Generated User Id : " + userId );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        // Set payload 
        String SPRPayload = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getSPReportData(\\n studentId: \\\"\\\"\\n  language: {language}\\n    subject: \\\"%s\\\"\\n    courseList: [{assignmentId}]\\n    includePerformanceSummary: true\\n    includePerformanceByStrand: true\\n    includeAreasOfDifficulty: true\\n    includeRecentHistoryData: {dateAtRisk}\\n    filterBySchool: [\\\"%s\\\"]\\n    filterByTeacher: [{teacherId}]\\n    filterByGrade: [{grade}]\\n    filterByGroup: [{groupId}]\\n  ) {\\n    students {\\n      reportRun\\n      studentId\\n      studentName\\n      studentUsername\\n      courses {\\n        course {\\n          name\\n          school\\n          teacher\\n          grade\\n          group\\n          assignedCourseLevel\\n          currentCourseLevel\\n          ipmStatusID\\n          fluencyStatus\\n          grammarStatus\\n          proficiencyStatus\\n          ipLevel\\n          IPMCorrect\\n          IPMAttempted\\n          IPPercent\\n          IPTimeSpent\\n          IPPlaced\\n          k2IpmTotalCorrect\\n          k2IpmTotalAttempts\\n          gain\\n          exerCorrect\\n          exerAttempted\\n          cri\\n          skillsMastered\\n          skillsAssessed\\n          helpUsed\\n          audioRepeatsUsed\\n          reportCardViews\\n          glossaryUsed\\n          timeSpent\\n          totalSessions\\n          averageSessionTime\\n          computationStrands {\\n            name\\n            level\\n            skillsMastered\\n            skillsAssessed\\n            strandOn\\n            strandStatus\\n                      }\\n          applicationStrands {\\n            name\\n            level\\n            skillsMastered\\n            skillsAssessed\\n            strandOn\\n            strandStatus\\n                      }\\n          readingStrand {\\n            name\\n            level\\n            exercisesCorrect\\n            exercisesAttempted\\n            toppedOut\\n                      }\\n          skillsDelayed {\\n            strand\\n            level\\n            description\\n            dateAtRisk\\n                      }\\n          skillsNotMastered {\\n            strand\\n            level\\n            description\\n            dateAtRisk\\n                      }\\n          otherPerformance {\\n            IndependentPractice {\\n              exerCorrect\\n              exerAttempted\\n                          }\\n            Remediation {\\n              exerCorrect\\n              exerAttempted\\n                          }\\n                      }\\n                  }\\n              }\\n          }\\n      }\\n}\\n\"}";
        String payLoad = String.format( SPRPayload, subject, schoolId );

        for ( Map.Entry<String, String> values : filerValues.entrySet() ) {
            if ( values.getKey().equals( "{dateAtRisk}" ) ) {
                payLoad = payLoad.replace( values.getKey(), values.getValue() ); // Adding Additional Grouping value in
            } else {
                payLoad = payLoad.replace( values.getKey(), "\\\"" + values.getValue() + "\\\"" ); // adding id value in
            }
        }

        payLoad = payLoad.replace( ReportFilters.TEACHER_ID_VALUE, "" ).replace( ReportFilters.GRADE_ID_VALUE, "" ).replace( ReportFilters.GROUP_ID_VALUE, "" ).replace( ReportFilters.ASSIGNMENT_ID, "" ).replace( "{courseList}", "" ).replace( "{studentId}",
                "\\\"\\\"" ).replace( "{language}", "\\\"en\\\"" ).replace( "{dateAtRisk}", "10400" );

        Log.message( "Payload: " + payLoad );
        Log.message( "Headers :" + headers );
        // Getting SPR report response
        Response response = RestAssuredAPIUtil.POSTGraphQl( ReportAdminConstants.REPORT_BFF, headers, payLoad, AdminConstants.GRAPHQL_ENDPOINT );
        Log.message( "Response: " + response.getBody().asString() );
        return response;
    }

    public HashMap<String, HashMap<String, HashMap<String, String>>> getAllTeachersOfAnOrganization( String userId, String districtId, String adminUsername, List<String> selectedOrgIds ) {

        String payload = "{\"query\":\"query { getOptionalFilters(orgIds: {organizationId}, userId:\\\"{userID}\\\"){ teachers { organizationId userId userName firstName lastName } } }\",\"variables\":{}}";
        payload = payload.replace( Constants.ORG_ID, selectedOrgIds.stream().map( org -> "\\\"" + org + "\\\"" ).collect( Collectors.toList() ).toString() ).replace( Constants.USER_ID_VALUE, userId );

        Map<String, String> headers = new HashMap<>();
        headers.put( "Content-Type", "application/json" );
        headers.put( "org-id", districtId );
        headers.put( "user-id", userId );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( adminUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        String endPoint = AdminConstants.GRAPHQL_ENDPOINT;
        Response response = RestAssuredAPIUtil.POST( ReportAdminConstants.REPORT_BFF + endPoint, headers, payload );

        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "getOptionalFilters" );
        String responseArray = SMUtils.getKeyValueFromResponse( keyValueFromResponse, "teachers" );
        JSONArray jsonArray = new JSONArray( responseArray );

        HashMap<String, HashMap<String, HashMap<String, String>>> teacherDetailsByOrgId = new HashMap<>();
        selectedOrgIds.stream().forEach( org -> {
            HashMap<String, HashMap<String, String>> teacherDetails = new HashMap<>();
            IntStream.range( 0, jsonArray.length() ).forEach( itr -> {
                JSONObject jsonObject = jsonArray.getJSONObject( itr );
                if ( jsonObject.get( "organizationId" ).toString().replace( "[", "" ).replace( "]", "" ).replace( "\"", "" ).contains( org ) ) {
                    HashMap<String, String> teacher = new HashMap<>();
                    teacher.put( Constants.USER_NAME, jsonObject.get( "userName" ).toString() );
                    teacher.put( Constants.FIRSTNAME, jsonObject.get( "firstName" ).toString() );
                    teacher.put( Constants.LASTNAME, jsonObject.get( "lastName" ).toString() );
                    teacherDetails.put( jsonObject.get( "userId" ).toString(), teacher );
                }
            } );
            teacherDetailsByOrgId.put( org, teacherDetails );
        } );
        return teacherDetailsByOrgId;
    }

}
