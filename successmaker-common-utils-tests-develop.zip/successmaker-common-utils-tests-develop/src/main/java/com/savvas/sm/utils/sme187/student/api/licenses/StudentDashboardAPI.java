package com.savvas.sm.utils.sme187.student.api.licenses;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;

import io.restassured.response.Response;

public class StudentDashboardAPI {

    /**
     * To Create and get the session Id for given student
     * 
     * @param userId
     * @param orgId
     * @param studentUsername
     * @param password
     * @param assignemntUserId
     * @return
     */
    public String getSessionId( String smUrl, String userId, String orgId, String studentUsername, String password, String assignmentUserId ) {
        String endPoint = LicenseConstants.STUDENT_ASSIGNMENT_LAUNCH_DATA_ENDPOINT;
        List<String> pathParamsList = new ArrayList<>();
        HashMap<String, String> header = new HashMap<>();
        header.put( Constants.ORGID_SM_HEADER, orgId );
        header.put( Constants.USERID_SM_HEADER, userId );
        try {
            header.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( studentUsername, password ) );
        } catch ( Exception e ) {
            Log.fail( "Issue in getting the accesstoken for student - " + studentUsername );
        }
        pathParamsList.add( assignmentUserId );
        HashMap<String, String> pathParams = SMUtils.setPathParametersFromEndpoint( endPoint, pathParamsList );
        Response response = RestAssuredAPIUtil.GET( smUrl, header, endPoint, pathParams );
        String sessionId = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "sessionId" );
        Log.message( "Session ID  - " + sessionId );
        return sessionId;
    }

    /**
     * To release license after student completed the assignment
     * 
     * @param smUrl
     * @param userId
     * @param orgId
     * @param studentUsername
     * @param password
     * @param assignemntUserId
     * @param sessionId
     * @return
     */
    public Response releaseLicense( String smUrl, String userId, String orgId, String studentUsername, String password, String assignemntUserId, String sessionId ) {
        String endPoint = LicenseConstants.LICENSE_RELEASE_END_POINT.replace( "{auId}", assignemntUserId );
        Map<String, String> header = new HashMap<>();
        header.put( Constants.ORGID_SM_HEADER, orgId );
        header.put( Constants.USERID_SM_HEADER, userId );
        header.put( "session-id", sessionId );
        try {
            header.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( studentUsername, password ) );
        } catch ( Exception e ) {
            Log.fail( "Issue in getting the accesstoken for student - " + studentUsername );
        }
        return RestAssuredAPIUtil.PUT( smUrl + endPoint, header );
    }
    
    public Map<String, String> checkAssignmentSessionExist( String envUrl, HashMap<String, String> assignmentDetails ) throws Exception {

        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + assignmentDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );

        String orgID = assignmentDetails.get( Constants.ORGID_SM_HEADER );
        String studentID = assignmentDetails.get( Constants.USERID_SM_HEADER );

        headers.put( Constants.USERID_SM_HEADER, studentID );
        headers.put( Constants.ORGID_SM_HEADER, orgID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = LicenseConstants.CHECK_MULTI_ASSIGNMENT_SESSION;
        endPoint = endPoint.replace( LicenseConstants.AU_ID, assignmentDetails.get( Constants.ASSIGNMENT_USER_ID ) );

        return RestHttpClientUtil.GET( envUrl, endPoint, headers, params );
    }

}
