package com.savvas.sm.utils.sql.helper;

public interface SQLConstants {

    public interface Course {

        String SKILL_OBJECT_DESCRIPTION = "skill_obj_description";
        String SKILL_OBJECTIVE_ID = "skill_objective_id";
        String LEARNING_OBJECTIVE_ID = "objectId";
        String LO_OBJECT_DESCRIPTION = "objectDescription";
        String CATALOG_NUMBER = "catalogNum";

    }

}
