package com.savvas.sm.utils.sme187.admin.api.audithistory;

import java.util.List;
import java.util.Map;

import io.restassured.response.Response;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.constants.AdminConstants;

public class AuditHistroyBFF {

    /**
     * This method is used to GET an Audit History Assignments
     * 
     * @param smUrl
     * @param headers
     * @param userId
     * @param orgId
     * @param queryItems
     * @return
     */
    public Response getAuditHistoryBFF( Map<String, String> headers, String selectedOrgId, String userId, String orgId, List<String> queryItems ) {

        String query = AdminConstants.GET_AUDIT_HISTORY_PAYLOAD;
        query = query.replace( AdminConstants.SELECTED_ORG_ID, selectedOrgId );
        query = query.replace( Constants.USER_ID_VALUE, userId );
        query = query.replace( Constants.ORG_ID, orgId );
        StringBuilder frameQuery = new StringBuilder();
        frameQuery.append( "{" );
        queryItems.forEach( querItem -> {
            if ( frameQuery.toString().equals( "{" ) ) {
                frameQuery.append( querItem );
            } else {
                frameQuery.append( "," + querItem );
            }
        } );
        frameQuery.append( "}" );

        query = query.replace( AdminConstants.QUERY_ITEM, frameQuery.toString() );
        return RestAssuredAPIUtil.POSTGraphQl( AdminConstants.ADMIN_DASHBOARD_BFF, headers, query, AdminConstants.GRAPHQL_ENDPOINT );
    }
}
