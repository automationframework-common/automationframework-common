package com.savvas.sm.utils.constants;

import java.util.Objects;

import com.learningservices.utils.EnvironmentPropertiesReader;

public interface RBSDataSetupConstants {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    String ADMIN_USERANME_PREFIX = Objects.nonNull( configProperty.getProperty( "AdminUsernamePrefix" ) ) ? configProperty.getProperty( "AdminUsernamePrefix" ) : "";
    String SCHOOL_ADMIN_USERNAME = ADMIN_USERANME_PREFIX + "smautoexecschooladmin@%s";
    String MULTI_SCHOOL_ADMIN_USERNAME = ADMIN_USERANME_PREFIX + "smautoexecmultischooladmin@%s";
    String DISTRICT_ADMIN_USERNAME = ADMIN_USERANME_PREFIX + "smautoexecdistrictadmin@%s";
    String SUBDISTRICT_ADMIN_USERNAME = ADMIN_USERANME_PREFIX + "smautoexecsubdistrictadmin@%s";
    String SUBDISTRICT_WITH_SCHOOL_ADMIN_USERNAME = ADMIN_USERANME_PREFIX + "smautoexecsubwithschdistrictadmin@%s";
    String SAVVAS_ADMIN_USERNAME = ADMIN_USERANME_PREFIX + "smautoexecsavvasadmin@%s";

    String SCHOOL_ADMIN_USERNAME_CUSTOMIZED = "smAutoexecSchoolAdminCustom%s@%s";
    String MULTI_SCHOOL_ADMIN_USERNAME_CUSTOMIZED = "smAutoexecMultischoolAdmin%s@%s";
    String DISTRICT_ADMIN_USERNAME_CUSTOMIZED = "smAutoexecDistrictAdmin%s@%s";
    String SUBDISTRICT_ADMIN_USERNAME_CUSTOMIZED = "smAutoexecSubdistrictAdmin%s@%s";
    String SUBDISTRICT_WITH_SCHOOL_ADMIN_USERNAME_CUSTOMIZED = "smAutoexecSubwithschDistrictadmin%s@%s";
    String SAVVAS_ADMIN_USERNAME_CUSTOMIZED = "smAutoexecSavvasSdmin%s@%s";

    //Create User Parameters
    public static String CREATED_BY = "createdBy";
    public static String EMAIL = "email";
    public static String FIRSTNAME = "firstName";
    public static String LASTNAME = "lastName";
    public static String MIDDLENAME = "middleName";
    public static String USERNAME = "userName";
    public static String ORGANIZATIONIDS = "organizationIds";
    public static String PASSWORD = "password";
    public static String ROLE = "role";
    public static String SEND_EMAIL_NOTIFICATION = "sendEmailNotification";
    public static String DISPLAY_NAME = "displayName";
    public static String ORG_ROLE = "orgRole";
    public static String TITLE = "title";
    public static String TITLE_DEFAULT = "Mr.";
    public static String TEACHER_ID = "teacherId";
    public static String CLASS_ID = "classId";
    public static String SECTION_ID = "sectionId";
    public static String STUDENT_ID = "studentId";
    public static String GRADE_ID = "gradeId";

    //License Parameters
    public static String PRODUCT_ID_FIELD = "productId";

    //Create Org Parameters
    public static String ORGANIZATION_NAME = "OrganizationName";
    public static String ORGANIZATION_TYPE = "OrganizationType";
    public static String IDENTIFIER_ID = "IdentifierID";
    public static String DISTRICT_ID = "DistrictID";
    public static String SCHOOL_ID = "SchoolIDs";

    //Automation users

    public static String USER_NAME_VALUE = "smtestautosch%st%s@%s";
    public static String STUDENT_USER_NAME_VALUE = "smtestautosch%st%sS%s@%s";

    public static String CA_USER_NAME_VALUE = "SmAutoCA_";
    public static String SA_USER_NAME_VALUE = "SmAutoSA_";

    public static String DEFAULT_PASSWORD = "testing123$";
    public static String TEACHER_ROLE = "T";
    public static String STUDENT_ROLE = "S";
    public static String ADMIN_ROLE = "CA";
    public static String PEARSON_ADMIN_ROLE = "PA";

    public static String ORGANIZATION_NAME_VALUE = "Successmaker Automation School ";
    public static String SUBDISRICT_NAME_VALUE = "Successmaker Automation SubDistrict ";
    public static String UNKNOWN_NAME_VALUE = "Successmaker Automation Unknown ";
    public static String ORGANIZATION_TYPE_SCHOOL = "School";
    public static String ORGANIZATION_TYPE_DISTRICT = "District";
    public static String ORGANIZATION_TYPE_SUBDISTRICT = "Subdistrict";
    public static String ORGANIZATION_TYPE_UNKNOWN = "Unknown";

    //Class creation Payload Keys
    public static String SECTION_NAME = "sectionName";
    public static String ORGANIZATION_ID = "organizationId";
    public static String STAFF_PI_ID = "staffPiId";
    public static String STUDENT_PI_ID = "studentPiId";
    public static String USERID = "userId";
    public static String SECTION = "section";

    public static String BEARER_TOKEN = "token";

    //Product related Payload keys
    public static String PRODUCT_ID = "ProductId";
    public static String PRODUCT_ENTITY_ID = "ProductEntityID";
    public static String ORDER_LINE_ID = "OrderLineId";
    public static String START_DATE = "startDate";
    public static String END_DATE = "EndDate";
    public static String QUANTITY = "Quantity";

    //SOAP call values
    public static String SOAP_ENVELOP = "soapenv:Envelope";
    public static String SOAP_BODY = "soapenv:Body";

    //SOLR elements
    public static String QUERY = "q";
    public static String ENCODE_TYPE = "UTF-8";
    public static String RESPONSE = "response";
    public static String ROWS = "rows";
    public static String RESULT = "result";
    public static String DOC = "doc";
    public static String STR = "str";
    public static String CONTENT = "content";
    public static String NAME = "name";
    public static String NAME_FIELD = "Name";
    public static String PARENT_ORGANIZATION = "ParentOrganization";
    public static String ORG_ID_SOLR = "OrganizationId";
    public static String PRODUCT_ID_SOLR = "ProductId";
    public static String USER_NAME_SOLR = "UserName";
    public static String USER_ID_SOLR = "UserId";
    public static String POLICY = "policy";
    public static String STATUS_ACTIVE = "active";
    public static String ORG_AFFILIATION_PAYLOAD = "<ns:AffiliationInfo><ns:AffiliationType>U</ns:AffiliationType><ns:AffiliationStatus>Confirmed</ns:AffiliationStatus><ns:OrgRole>%s</ns:OrgRole><ns:OrganizationId>%s</ns:OrganizationId></ns:AffiliationInfo>";

    //Fixup functions
    public static String FIXUP_FUNCTION_API = "/lms/web/api/v1/demoserver/dbfunctions/invoke";
    public static String[] FIXUP_FUNCTIONS_LIST = { "msh_date_fixup", "maod_date_fixup", "raod_date_fixup", "rsh_date_fixup" };

    //Enum for schools selection
    public static enum Schools {
        MATH_SCHOOL, //Only Math licensed school
        READING_SCHOOL, //Only Reading Licensed school
        MATH_FOCUS_SCHOOL, //Only Math focus Licensed school
        READING_FOCUS_SCHOOL, //Only Reading focus licensed school
        FLEX_SCHOOL // Flex licensed School(Full license - Math,Reading,Math Focus, Reading Focus)
    }

    public static enum Admins {
        DISTRICT_ADMIN,
        SCHOOL_ADMIN,
        SUBDISTRICTWITHOUTSCHOOL_ADMIN,
        SUBDISTRICTWITHSCHOOL_ADMIN,
        MULTI_SCHOOL_ADMIN,
        SAVVAS_ADMIN
    }

}
