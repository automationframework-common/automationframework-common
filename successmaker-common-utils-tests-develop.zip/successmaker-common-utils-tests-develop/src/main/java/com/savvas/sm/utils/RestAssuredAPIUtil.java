package com.savvas.sm.utils;

import com.learningservices.utils.Log;
import com.savvas.sm.log.api.LogAPIResponse;
import io.restassured.RestAssured;
import io.restassured.config.ConnectionConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class RestAssuredAPIUtil {

    /**
     * setBaseURL method sets baseURL
     *
     * @param baseURL
     */
    public static void setBaseURL(String baseURL) {
        try {
            if (!baseURL.isEmpty() || !baseURL.contains(null)) {
                RestAssured.baseURI = baseURL;
            }
        } catch (NullPointerException e) {
            System.out.println("Base URL is set as null");
        }
    }

    /**
     * Returns response of GET API method execution
     *
     * @param baseURL
     * @param username
     * @param password
     * @param contentType
     * @param url
     * @return Response of GET command
     */
    public static Response GET(String baseURL, String username, String password, String contentType, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().auth().preemptive().basic(username, password).get(url);
        Log.message("GET Command URL:" + baseURL + File.separator + url + "\n" + "username : \n" + username + "\n" + "password : \n" + password + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: " + resp.getTime() + " milli second");
        LogAPIResponse.log("GET", baseURL+url, username, resp);
        return resp;
    }

    /**
     * Returns response of GET API method execution
     *
     * @param baseURL
     * @param headers
     * @param username
     * @param password
     * @param contentType
     * @param url
     * @return Response of GET command
     */
    public static Response GET(String baseURL, Map<String, String> headers, String username, String password, String contentType, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().auth().basic(username, password).headers(headers).contentType(contentType).get(url);

        Log.message("GET Command URL:" + baseURL + File.separator + url + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: \n" + resp.getTime() + " milli second\n");
        LogAPIResponse.log("GET", baseURL+url, username, resp);
        return resp;
    }

    public static Response GETWithDigestAuth(String baseURL, Map<String, String> headers, String username, String password, String contentType, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().auth().digest(username, password).headers(headers).contentType(contentType).get(url);
        LogAPIResponse.log("GET", baseURL+url, username, resp);
        return resp;
    }

    /**
     * Returns response of GET API method execution for Encoded string
     *
     * @param baseURL
     * @param headers
     * @param username
     * @param password
     * @param contentType
     * @param url
     * @return Response of GET command
     */
    public static Response GETWithEncodedString(String baseURL, Map<String, String> headers, String username, String password, String contentType, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().urlEncodingEnabled(false).auth().basic(username, password).headers(headers).contentType(contentType).get(url);

        Log.message("GET Command URL: \n" + baseURL + File.separator + url + "\n");
        Log.message("Header: \n" + resp.getHeaders().toString() + "\n");
        Log.message("Status Code: \n" + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: \n" + resp.getTime() + " milli second\n");
        LogAPIResponse.log("GET", baseURL+url, username, resp);
        return resp;
    }

    /**
     * Returns response of GET API method execution based on provided query
     * parameters
     *
     * @param baseURL
     * @param headers
     * @param queryParam
     * @param contentTypeJson
     * @param body
     * @param url
     * @return
     */
    public static Response GET(String baseURL, Map<String, String> headers, Map<String, String> queryParam, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().params(queryParam).headers(headers).get(url);
        RestAssured.given().params(queryParam).headers(headers).get(url);
        Log.message("GET Command URL:" + baseURL + File.separator + url + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: " + resp.getTime() + " milli second");
        LogAPIResponse.log("GET", baseURL+url, headers.get("user-id"), resp);
        return resp;
    }

    /**
     * To get using basic Auth
     *
     * @param baseURL
     * @param headers
     * @param queryParam
     * @param endPoint
     * @param username
     * @param password
     * @return
     */
    public static Response GETWithBasicAuth(String baseURL, Map<String, String> headers, Map<String, String> queryParam, String endPoint, String username, String password) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().auth().preemptive().basic(username, password).params(queryParam).headers(headers).get(endPoint);
        LogAPIResponse.log("GET", baseURL+endPoint, username, resp);
        return resp;
    }

    /***
     * Returns response of GET API method execution based on provided path
     * parameters
     *
     * @param baseURL
     * @param headers
     * @param url
     * @param pathParams
     * @return
     */
    public static Response GET(String baseURL, Map<String, String> headers, String url, Map<String, String> pathParams) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().pathParams(pathParams).headers(headers).get(url);
        Log.message("GET Command URL:" + baseURL + File.separator + url + "\n" + "Request Headers: \n" + headers.toString() + "Path params: \n" + pathParams.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: " + resp.getTime() + " milli second");
        LogAPIResponse.log("GET", baseURL+url, headers.get("user-id"), resp);
        return resp;
    }

    /***
     * Returns response of GET API method execution based on provided path and
     * query parameters
     *
     * @param baseURL
     * @param headers
     * @param url
     * @param pathParams
     * @param queryParams
     * @return
     */
    public static Response GET(String baseURL, Map<String, String> headers, String url, Map<String, String> pathParams, Map<String, String> queryParams) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().pathParams(pathParams).queryParams(queryParams).headers(headers).get(url);
        Log.message("GET Command URL:" + baseURL + File.separator + url + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: " + resp.getTime() + " milli second");
        LogAPIResponse.log("GET", baseURL+url, headers.get("user-id"), resp);
        return resp;
    }

    public static Response PIGET(String baseURL, Map<String, String> headers, Map<String, String> queryParam, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().params(queryParam).headers(headers).get(url);
        LogAPIResponse.log("GET", baseURL+url, headers.get("user-id"), resp);
        return resp;
    }

    public static Response GET(String baseURL, Map<String, String> headers, Map<String, String> queryParam, String url, Boolean LongResponse) {

        if (LongResponse)
            return GET(baseURL, headers, queryParam, url);

        setBaseURL(baseURL);
        Response resp = RestAssured.given().params(queryParam).headers(headers).get(url);
        Log.message("GET Command URL:" + baseURL + File.separator + url + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        LogAPIResponse.log("GET", baseURL+url, headers.get("user-id"), resp);
        return resp;
    }

    /**
     * Returns response of POST API method execution
     *
     * @param headerKey
     * @param headerValue
     * @param contentTypeJson
     * @param body
     * @param url
     * @return Response of POST command
     */
    public static Response POST(String baseURL, Map<String, String> headers, String username, String password, String contentType, String body, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().auth().basic(username, password).headers(headers).contentType(contentType).body(body).post(url).andReturn();
        Log.message("POST Command URL:" + baseURL + File.separator + url + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Header \n" + resp.getHeaders().toString());
        Log.message("Time taken to get response is \n" + resp.getTime() + " milli second");
        LogAPIResponse.log("POST", baseURL+url, username, resp);
        return resp;
    }

    /**
     * Returns response of POST API method execution
     *
     * @param baseURL
     * @param headers
     * @param body
     * @return Response of POST command
     */
    /**
     * Returns response of POST API method execution
     *
     * @param baseURL
     * @param headers
     * @param body
     * @return
     */
    public static Response POST(String baseURL, Map<String, String> headers, String body) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().headers(headers).body(body).post().andReturn();
        Log.message("POST Command URL:" + baseURL + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: " + resp.getTime() + " milli second");
        LogAPIResponse.log("POST", baseURL, headers.get("user-id"), resp);
        return resp;
    }

    /**
     * Returns response of POST API method execution
     *
     * @param headerKey
     * @param body
     * @param url
     * @return Response of POST command
     */
    public static Response POST(String baseURL, Map<String, String> headers) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().headers(headers).post().andReturn();
        Log.message("POST Command URL:" + baseURL + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: " + resp.getTime() + " milli second");
        LogAPIResponse.log("POST", baseURL, headers.get("user-id"), resp);
        return resp;
    }

    /**
     * @param baseURL
     * @param url
     * @param headers
     * @param queryParam
     * @return This is specific to EPS Search POST call
     */
    public static Response EPS_POST(String baseURL, String url, Map<String, String> headers, String queryParam) {
        setBaseURL(baseURL);
        Map<String, String> inputData = new HashMap<String, String>();

        // Load query param map
        String payload = "";
        String[] qParamArray = queryParam.split("&");
        for (int qIndex = 0; qIndex < qParamArray.length; qIndex++) {
            if (qParamArray[qIndex].split("=")[0].equals("where")) {
                payload = qParamArray[qIndex];
            } else {
                inputData.put(qParamArray[qIndex].split("=")[0], qParamArray[qIndex].split("=")[1]);
            }
        }

        Response resp = RestAssured.given().headers(headers).body(payload).queryParams(inputData).post(url).andReturn();
        Log.message("Running POST command...");
        Log.message("Request: " + baseURL + File.separator + url + "?" + queryParam);
        Log.message("Time taken to get response is: " + resp.getTime() + " milli second");
        LogAPIResponse.log("POST", baseURL+url, headers.get("user-id"), resp);
        return resp;

    }

    /**
     * Returns response of POST API method execution
     *
     * @param baseURL
     * @param headers
     * @param inputData
     * @param body
     * @param url
     * @return Response of POST command
     */
    public static Response POST(String baseURL, Map<String, String> headers, Map<String, String> inputData, String body, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().headers(headers).body(body).queryParams(inputData).post(url).andReturn();
        Log.message("POST Command URL:" + baseURL + File.separator + url + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Params : \n" + inputData.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: " + resp.getTime() + " milli second");
        LogAPIResponse.log("POST", baseURL+url, headers.get("user-id"), resp);
        return resp;

    }

    /**
     * Returns response of POST API method execution
     *
     * @param baseURL
     * @param headers
     * @param inputData
     * @param body
     * @param url
     * @return Response of POST command
     */
    public static Response POSTWITHPATHPARAM(String baseURL, Map<String, String> headers, Map<String, String> inputData, String body, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().headers(headers).body(body).pathParams(inputData).post(url).andReturn();
        Log.message("POST Command URL:" + baseURL + File.separator + url + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        LogAPIResponse.log("POST", baseURL+url, headers.get("user-id"), resp);
        return resp;

    }

    public static Response PIPOST(String baseURL, Map<String, String> headers, Map<String, String> inputData, String body, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().headers(headers).body(body).queryParams(inputData).post(url).andReturn();
        Log.message("POST Command URL:" + baseURL + File.separator + url + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        LogAPIResponse.log("POST", baseURL+url, headers.get("user-id"), resp);
        return resp;

    }

    /**
     * The Publisher APIs require File to be uploaded, so the given API is
     * specific to POST Publisher APIs
     *
     * @param headerKey
     * @param headerValue
     * @param contentTypeJson
     * @param controlname
     * @param path
     * @param url
     * @return Response of API execution
     * @throws Exception
     */
    public static Response POSTPublisher(String baseURL, Map<String, String> headers, String username, String password, String contentTypeJson, String path, String url) throws Exception {
        setBaseURL(baseURL);
        Response resp = null;
        try {
            File file = new File(path);
            resp = RestAssured.given().headers(headers).auth().basic(username, password).headers(headers).multiPart("files", file).contentType(contentTypeJson).when().post(url);
            Log.message("POST Command URL:" + baseURL + File.separator + url + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
            Log.message("Header \n" + resp.getHeaders().toString());
            Log.message("Time taken to get response is \n" + resp.getTime() + " milli second");
            LogAPIResponse.log("POST", baseURL+url, username, resp);
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("something went wrong while running POSTPublisher");
        }

        return resp;
    }

    /**
     * Returns response of PUT API method execution based on query parameters
     *
     * @param headers
     * @param url
     * @return
     */
    public static Response PUT(String baseURL, Map<String, String> headers) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().headers(headers).put().andReturn();
        Log.message("PUT Command URL:" + baseURL + "\n" + "Request Headers: \n" + headers.toString() + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: " + resp.getTime() + " milli second");
        LogAPIResponse.log("PUT", baseURL, headers.get("user-id"), resp);
        return resp;

    }

    /**
     * Returns response of PUT API method execution
     *
     * @param headerKey
     * @param headerValue
     * @param contentTypeJson
     * @param body
     * @param url
     * @return Response of PUT command
     */
    public static Response PUT(String baseURL, Map<String, String> headers, String username, String password, String contentTypeJson, String body, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().headers(headers).auth().basic(username, password).contentType(contentTypeJson).body(body).put(url).andReturn();
        Log.message("PUT Command URL:" + baseURL + File.separator + url + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: " + resp.getTime() + " milli second");
        LogAPIResponse.log("PUT", baseURL+url, headers.get("user-id"), resp);
        return resp;

    }

    /*
     * Returns response of PUT API method execution
     *
     * @param baseUrl
     *
     * @param pathParams
     *
     * @param content Type
     *
     * @param payLoad
     *
     * @param endpoint
     *
     */
    public static Response PUT(String baseUrl, Map<String, String> headers, String contentType, String payload, String endPoint, Map<String, String> pathParams) {
        Response resp = RestAssured.given().baseUri(baseUrl).headers(headers).pathParams(pathParams).contentType(contentType).body(payload).put(endPoint);
        Log.message("PUT Command URL:" + baseUrl + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: " + resp.getTime() + " milli second");
        LogAPIResponse.log("PUT", baseUrl+endPoint, headers.get("user-id"), resp);
        return resp;
    }

    /**
     * Returns response of PUT API method execution based on query parameters
     *
     * @param baseURL
     * @param headers
     * @param inputData
     * @param contentTypeJson
     * @param body
     * @param url
     * @return
     */
    public static Response PUT(String baseURL, Map<String, String> headers, Map<String, String> inputData, String body, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().headers(headers).params(inputData).body(body).put(url).andReturn();
        Log.message("PUT Command URL:" + baseURL + File.separator + url + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Params :" + inputData.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: " + resp.getTime() + " milli second");
        LogAPIResponse.log("PUT", baseURL+url, headers.get("user-id"), resp);
        return resp;

    }

    /**
     * Returns response of PUT API method execution based on path parameters
     *
     * @param baseURL
     * @param headers
     * @param inputData
     * @param contentTypeJson
     * @param body
     * @param url
     * @return
     */

    public static Response PUTWITHPATHPARAMS(String baseURL, Map<String, String> headers, Map<String, String> inputData, String body, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().headers(headers).pathParams(inputData).body(body).put(url).andReturn();
        Log.message("PUT Command URL:" + baseURL + File.separator + url + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Header \n" + resp.getHeaders().toString());
        Log.message("Time taken to get response is \n" + resp.getTime() + " milli second");
        LogAPIResponse.log("PUT", baseURL+url, headers.get("user-id"), resp);
        return resp;

    }

    /**
     * Returns response of DELETE API method execution
     *
     * @param headerKey
     * @param headerValue
     * @param contentTypeJson
     * @param body
     * @param url
     * @return Response of DELETE command
     */
    public static Response DELETE(String baseURL, Map<String, String> headers, String username, String password, String contentTypeJson, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().headers(headers).delete(url);
        Log.message("DELETE Command URL:" + baseURL + File.separator + url + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: " + resp.getTime() + " milli second");
        LogAPIResponse.log("DELETE", baseURL+url, headers.get("user-id"), resp);
        return resp;

    }

    /**
     * @param baseURL
     * @param headers
     * @param inputData
     * @param url
     * @return
     */
    public static Response POST(String baseURL, Map<String, String> headers, Map<String, String> inputData, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().headers(headers).formParams(inputData).post(url).andReturn();
        Log.message("POST Command URL:" + baseURL + File.separator + url + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Input Data: \n" + inputData.toString() + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: " + resp.getTime() + " milli second");
        LogAPIResponse.log("POST", baseURL+url, headers.get("user-id"), resp);
        return resp;

    }

    /**
     * Returns response of POST API method execution
     *
     * @param baseURL
     * @param headers
     * @param body
     * @param url
     * @return Response of POST command
     */
    public static Response POST_REQ(String baseURL, Map<String, String> headers, Map<String, Object> body, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().headers(headers).body(body).post(url).andReturn();
        Log.message("POST Command URL:" + baseURL + File.separator + url + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Header \n" + resp.getHeaders().toString());
        Log.event("Response body \n" + resp.asString());
        Log.message("Time taken to get response is \n" + resp.getTime() + " milli second");
        LogAPIResponse.log("POST", baseURL+url, headers.get("user-id"), resp);
        return resp;

    }

    /**
     * verifyStatus methods verify status of the request sent
     *
     * @param headers
     * @param userName
     * @param password
     * @param contentTypeJson
     * @param URL
     * @param expectedValue
     * @return responseFlag true or false
     */
    public static boolean verifyStatus(Map<String, String> headers, String userName, String password, String contentTypeJson, String URL, int expectedValue) {
        boolean responseFlag = false;
        Response resp = GET("", headers, userName, password, contentTypeJson, URL);
        if (resp.getStatusCode() == expectedValue) {
            responseFlag = true;
        }
        return responseFlag;

    }

    /**
     * closeConnection method would be closing idle Connection
     */
    public static void closeConnection() {
        RestAssured.config = RestAssuredConfig.newConfig().connectionConfig(ConnectionConfig.connectionConfig().closeIdleConnectionsAfterEachResponse());
    }

    public static Response DELETE(String baseURL, Map<String, String> headers, Map<String, String> queryParam, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().params(queryParam).headers(headers).delete(url);
        Log.message("DELETE Command URL:" + baseURL + File.separator + url + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "\n" + "Input Data: \n" + queryParam.toString() + "\nStatus Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: " + resp.getTime() + " milli second");
        LogAPIResponse.log("DELETE", baseURL+url, headers.get("user-id"), resp);
        return resp;
    }

    public static Response DELETE(String baseURL, Map<String, String> headers, String inputpara, String contentType, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().headers(headers).queryParam(inputpara).contentType(contentType).delete(url);
        Log.message("DELETE Command URL:" + baseURL + File.separator + url + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        LogAPIResponse.log("DELETE", baseURL+url, headers.get("user-id"), resp);
        return resp;
    }

    /**
     * Standard DELETE
     *
     * @param baseUrl
     * @param headers
     * @param path     parameter
     * @param endpoint
     */
    public static Response delete(String baseURL, Map<String, String> headers, Map<String, String> pathParams, String endpoint) {
        Response resp = RestAssured.given().baseUri(baseURL).headers(headers).pathParams(pathParams).delete(endpoint);
        Log.message("DELETE Command URL:" + baseURL + File.separator + endpoint + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: " + resp.getTime() + " milli second");
        LogAPIResponse.log("DELETE", baseURL+endpoint, headers.get("user-id"), resp);
        return resp;
    }

    /**
     * Standard DELETE
     *
     * @param baseUrl
     * @param headers
     * @param path     parameter
     * @param query    parameter
     * @param endpoint
     */
    public static Response delete(String baseURL, Map<String, String> headers, Map<String, String> queryParams, Map<String, String> pathParams, String endpoint) {
        Response resp = RestAssured.given().baseUri(baseURL).headers(headers).params(queryParams).pathParams(pathParams).delete(endpoint);
        Log.message("DELETE Command URL:" + baseURL + File.separator + endpoint + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: \n" + resp.getTime() + " milli second\n");
        LogAPIResponse.log("DELETE", baseURL+endpoint, headers.get("user-id"), resp);
        return resp;
    }

    /**
     * Standard GET with baseUrl, headers, query parameters, endpoint
     */
    public static Response get(String baseUrl, Map<String, String> headers, Map<String, String> queryParams, String endPoint) {
        Log.message("GET Command URL:" + baseUrl + File.separator + endPoint + "\n" + "Request Headers: \n" + headers.toString());
        Response resp = RestAssured.given().baseUri(baseUrl).headers(headers).queryParams(queryParams).get(endPoint);
        LogAPIResponse.log("GET", baseUrl+endPoint, headers.get("user-id"), resp);
        return resp;
    }

    /**
     * verifyStatus methods verify status of the request sent
     *
     * @param baseUrl
     * @param headers
     * @param path     parameter
     * @param endpoint
     */
    public static Response get(String baseUrl, Map<String, String> headers, Map<String, String> pathParams, String endPoint, String type) {
        Response resp = RestAssured.given().baseUri(baseUrl).headers(headers).pathParams(pathParams).get(endPoint);
        Log.message("GET Command URL:" + baseUrl + File.separator + endPoint + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: \n" + resp.getTime() + " milli second\n");
        LogAPIResponse.log("GET", baseUrl+endPoint, headers.get("user-id"), resp);
        return resp;
    }

    /**
     * Standard POST with baseUrl, headers, query parameters, payLoad, endpoint
     */
    public static Response post(String baseUrl, Map<String, String> headers, Map<String, String> queryParams, String payload, String endPoint) {
        Log.message("POST Command URL:" + baseUrl + File.separator + endPoint + "\n" + "Request Headers: \n" + headers.toString());
        Response resp = RestAssured.given().baseUri(baseUrl).headers(headers).queryParams(queryParams).body(payload).post(endPoint);
        LogAPIResponse.log("POST", baseUrl+endPoint, headers.get("user-id"), resp);
        return resp;
    }

    /**
     * Get the jessionID and failover value for any realize
     * user[Admin/Teacher/Student] from any environment
     *
     * @param baseURL  base realize url of any environment Example:
     *                 https://cert-www.realizedev.com
     * @param rumbaURL rumba URL of the environment
     * @param userName can be teacher / student/ admin Example: realize_pa_user
     * @return jsessionID and failover valve
     * @throws Exception
     */
    public static String getJSessionIDAccess(String realizeBaseURL, String rumbaURL, String userName, String password) {
        // Query Params and Headers - Declaration
        Map<String, String> inputData1Login = new HashMap<String, String>();
        Map<String, String> inputData2Auth1 = new HashMap<String, String>();
        Map<String, String> inputData2Auth2 = new HashMap<String, String>();

        Map<String, String> headers1Login = new HashMap<String, String>();
        Map<String, String> headers1Auth1 = new HashMap<String, String>();
        Map<String, String> headers1Auth2 = new HashMap<String, String>();

        // Query Params for Login
        inputData1Login.put("profile", "realize");
        inputData1Login.put("k12int", "true");
        inputData1Login.put("service", "" + realizeBaseURL + "/community/j_spring_cas_security_check");

        // Query Params for Auth1
        inputData2Auth1.put("execution", "e1s1");
        inputData2Auth1.put("profile", "realize");
        inputData2Auth1.put("k12int", "true");
        inputData2Auth1.put("service", "" + realizeBaseURL + "/community/j_spring_cas_security_check");

        // Making Login GET Call
        Response respLogin = get(rumbaURL, headers1Login, inputData1Login, "/sso/login");

        // Extracting Response Cookies - JSESSION and
        // BIGipServerrumba-int-cluster-01
        Map<String, String> cookies = respLogin.cookies();
        StringBuffer cookieHeader = new StringBuffer();
        for (String cookie : cookies.keySet()) {
            cookieHeader.append(cookie + "=" + cookies.get(cookie) + ";");
        }

        // Setting Request header cookie for Auth1 POST Call
        headers1Auth1.put("Cookie", cookieHeader.toString());
        headers1Auth1.put("Content-Type", "application/x-www-form-urlencoded");
        String LoginPayload = "username=" + userName + "&password=" + password + "&_eventId=submit";

        // Making Auth1 POST Call
        Response respAuth1 = post(rumbaURL, headers1Auth1, inputData2Auth1, LoginPayload, "/sso/login");

        // Extracting CASTGC for Auth 2 POST call
        String castgc = respAuth1.getCookie("CASTGC");

        // Extracting Location for Auth 2 POST call
        String baseURLforAuth2 = respAuth1.getHeader("Location").split("\\?")[0].split(".com")[0] + ".com";
        String endPointURLforAuth2 = respAuth1.getHeader("Location").split("\\?")[0].split("\\.com")[1];
        String ticketParam = respAuth1.getHeader("Location").split("\\?")[1].split("=")[1];
        inputData2Auth2.put("ticket", ticketParam);

        // Setting Query params for Auth2 POST Call
        headers1Auth2.put("Cookie", cookieHeader.toString() + "CASTGC=" + castgc);

        // Setting Request Cookies for Auth2 POST Call
        headers1Auth2.put("Content-Type", "application/x-www-form-urlencoded");

        Response respAuth2 = post(baseURLforAuth2, headers1Auth2, inputData2Auth2, LoginPayload, endPointURLforAuth2);
        Log.event(">>>> Auth 2 " + userName + " Cookies: \nJSESSIONID=" + respAuth2.getCookies().get("JSESSIONID") + ";__failover=" + respAuth2.getCookies().get("__failover"));
        return "JSESSIONID=" + respAuth2.getCookies().get("JSESSIONID") + ";__failover=" + respAuth2.getCookies().get("__failover");
    }

    /**
     * Get the cookies value for any realize user[Admin/Teacher/Student] from
     * any environment
     *
     * @param baseURL  base realize url of any environment Example:
     *                 https://cert-www.realizedev.com
     * @param rumbaURL rumba URL of the environment
     * @param userName can be teacher / student/ admin Example: realize_pa_user
     * @return jsessionID and failover valve
     * @throws Exception
     */
    public static Map<String, String> getCookieMap(String realizeBaseURL, String rumbaURL, String userName) throws Exception {
        String sessionID = getJSessionIDAccess(realizeBaseURL, rumbaURL, userName, "testing123$") + ";";
        return Arrays.stream(new String[]{"JSESSIONID", "__failover"}).collect(Collectors.toMap(Function.identity(), tag -> getTag(tag, sessionID)));
    }

    /**
     * Get the Tag value from map
     *
     * @param tag
     * @param link
     * @return Tag value
     */
    public static String getTag(String tag, String link) {
        String valueToReturn = null;
        Pattern pattern = Pattern.compile(tag + "=(.*?);");
        Matcher matcher = pattern.matcher(link);
        if (matcher.find()) {
            valueToReturn = matcher.group(1);
        }
        return valueToReturn;
    }

    /**
     * Returns response of POST API method execution
     *
     * @param baseURL
     * @param headers
     * @param body
     * @param url
     * @return Response of POST command
     */
    public static Response POST(String baseURL, Map<String, String> headers, String body, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().headers(headers).body(body).post(url).andReturn();
        Log.message("POST Command URL:" + baseURL + File.separator + url + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: \n" + resp.getTime() + " milli second\n");
        LogAPIResponse.log("POST", baseURL+url, headers.get("user-id"), resp);
        return resp;
    }

    /**
     * Returns response of GET API method execution based on provided query
     * parameters
     *
     * @param baseURL
     * @param headers
     * @param body
     * @param url
     * @return
     */
    public static Response GET(String baseURL, Map<String, String> headers, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().headers(headers).get(url);
        Log.message("GET Command URL:" + baseURL + File.separator + url + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        Log.message("Time taken to get response is: \n" + resp.getTime() + " milli second\n");
        LogAPIResponse.log("GET", baseURL+url, headers.get("user-id"), resp);
        return resp;
    }

    /**
     * This method is used to call POST request
     *
     * @param baseURL
     * @param header
     * @param body
     * @param endPoint
     * @return response
     * @throws Exception
     */
    public String callPOSTApi(String baseURL, Map<String, String> header, String body, String endPoint, String userName, String password) {

        //Initializes the return variable
        String response = null;

        try {

            //Sets the base URL to be called
            RestAssured.baseURI = baseURL;

            Response resp;

            //Call the POST method with the required parameters
            resp = RestAssured.given().auth().preemptive().basic(userName, password).headers(header).and().body(body).when().post(endPoint).then().statusCode(200).and().log().all().extract().response();

            //Converts the response as a string
            response = resp.asString();
            LogAPIResponse.log("POST", baseURL+endPoint, userName, resp);
            Log.message("POST Command URL:" + baseURL + File.separator + endPoint + "\n" + "Request Headers: \n" + header.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } //End catch

        //Returns the response data to the calling method
        return response;

    } //End callPOSTApi

    /**
     * This method is used to call PUT request
     *
     * @param baseURL
     * @param header
     * @param body
     * @param endPoint
     * @return response
     * @throws Exception
     */
    public String callPUTApi(String baseURL, Map<String, String> header, String body, String endPoint, String userName, String password) {

        //Initializes the return variable
        String response = null;

        try {

            //Sets the base URL to be called
            RestAssured.baseURI = baseURL;

            //Call the PUT method with the required parameters
            Response resp = RestAssured.given().auth().preemptive().basic(userName, password).headers(header).and().body(body).when().put(endPoint).then().statusCode(200).and().log().all().extract().response();

            //Converts the response as a string
            response = resp.asString();
            LogAPIResponse.log("PUT", baseURL+endPoint, userName, resp);
            Log.message("PUT Command URL:" + baseURL + File.separator + endPoint + "\n" + "Request Headers: \n" + header.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } //End catch

        //Returns the response data to the calling method
        return response;

    } //End callPUTApi

    /**
     * This method is used to call GET request
     *
     * @param baseURL
     * @param header
     * @param body
     * @param endPoint
     * @return response
     * @throws Exception
     */
    public String callGETApi(String baseURL, Map<String, String> header, String body, String endPoint, String userName, String password) {

        //Initializes the return variable
        String response = null;

        try {

            //Sets the base URL to be called
            RestAssured.baseURI = baseURL;

            //Call the GET method with the required parameters
            Response resp = RestAssured.given().auth().preemptive().basic(userName, password).headers(header).and().body(body).when().get(endPoint).then().statusCode(200).and().log().all().extract().response();

            //Converts the response as a string
            response = resp.asString();
            LogAPIResponse.log("GET", baseURL+endPoint, userName, resp);
            Log.message("GET Command URL:" + baseURL + File.separator + endPoint + "\n" + "Request Headers: \n" + header.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } //End catch

        //Returns the response data to the calling method
        return response;

    } //End callGETApi

    /**
     * This method is used to call POST request
     *
     * @param baseURL
     * @param header
     * @param body
     * @param endPoint
     * @return response
     * @throws Exception
     */
    public String callDigestAuthPOSTApi(String baseURL, Map<String, String> header, String body, String endPoint, String userName, String password) {

        //Initializes the return variable
        String response = null;

        try {

            //Sets the base URL to be called
            RestAssured.baseURI = baseURL;

            Response resp;

            //Call the POST method with the required parameters
            resp = RestAssured.given().auth().digest(userName, password).headers(header).and().body(body).when().post(endPoint);

            //Converts the response as a string
            response = resp.asString();
            LogAPIResponse.log("POST", baseURL+endPoint, userName, resp);
            Log.message("POST Command URL:" + baseURL + File.separator + endPoint + "\n" + "Request Headers: \n" + header.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } //End catch

        //Returns the response data to the calling method

        return response;

    } //End callDigestAuthPOSTApi

    // ***************GraphQL methods************

    public static Response POSTGraphQl(String baseURL, Map<String, String> headers, String body, String url) {
        RestAssured.baseURI = baseURL;
        Response resp = RestAssured.given().headers(headers).body(body).post(url).andReturn();
        Log.message("POST Command URL:" + baseURL + File.separator + url + "\n" + "Request Headers: \n" + headers.toString() + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        LogAPIResponse.log("POST", baseURL+url, headers.get("user-id"), resp);
        return resp;

    }

    /**
     * Returns response of GET call with Digest auth
     *
     * @param baseURL
     * @param username
     * @param password
     * @param contentType
     * @param url
     * @return
     */
    public static Response GETWithDigest(String baseURL, String username, String password, String contentType, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().auth().digest(username, password).get(url);
        Log.message("GET Command URL:" + baseURL + File.separator + url + "\n" + "Status Code: " + resp.getStatusCode() + "\n");
        LogAPIResponse.log("GET", baseURL+url, username, resp);
        return resp;
    }
    
    /**
     * This method is used to call POST request
     *
     * @param baseURL
     * @param header
     * @param queryParam
     * @param endPoint
     * @return response
     * @throws Exception
     */

    public static Response POSTWithQueryParam(String baseURL, Map<String, String> headers, Map<String, String> inputData, String url) {
        setBaseURL(baseURL);
        Response resp = RestAssured.given().headers(headers).queryParams(inputData).post(url).andReturn();
        Log.message( "running POST command" );
        Log.message( "URL \n" + url );
        Log.message( "Header \n" + resp.getHeaders().toString());
        Log.message( "Response body \n" + resp.asString());
        Log.message( "Time taken to get response is \n" + resp.getTime() + " milli second" );
        return resp;
    }
    
}