package com.savvas.sm.utils.sme187.teacher.api.homepage;

import com.savvas.sm.config.EnvProperties;

public class HomePageConstants extends EnvProperties {

    public interface UsageGoal {
        String POST_USAGE_GOALS_STUDENT_LIST = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/usageGoalsStudentList";
        String ASSIGNMENT_USER_IDS = "assignmentUserIds";
        String EDIT_USAGE_GOAL="/lms/web/api/v1/usageGoalsSettings";
    }

}
