package com.savvas.sm.utils.sql.helper;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;

// To split the assignment data

public class FixupFunction extends EnvProperties {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private static String envUrl;
    private static String requestBody = "{\"orgRumbaId\":\"{orgID}\",\"dbFunctionName\":\"{functionName}\"" + "}";
    private static String requestBodyMT = "{\"orgRumbaId\":\"{orgID}\", \"dbFunctionName\":\"{functionName}\", \"tenantId\":\"{tenantID}\", \"nyrDate\":\"{nyrDate}\"}";

    /**
     * To Execute fixup functions at Org level
     * 
     * @param orgRumbaId
     */

    public static void executeFixupFunctions( String orgRumbaId ) {

        if ( Objects.nonNull( configProperty.getProperty( "isMTExecution" ) ) ) {
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            String endPoint = RBSDataSetupConstants.FIXUP_FUNCTION_API;
            envUrl = configProperty.getProperty( "SMAppUrl" );
            String url = envUrl + endPoint;
            for ( int i = 0; i < RBSDataSetupConstants.FIXUP_FUNCTIONS_LIST.length; i++ ) {
                if ( Objects.nonNull( Boolean.valueOf( configProperty.getProperty( "isMTExecution" ) ) ) ) {
                    Map<String, String> mtDetails = new SqlHelperOrganization().getNYRdateAandTeanantId();
                    String nyrDate = mtDetails.get( "nyr_date" ).toString();
                    String tenantID = mtDetails.get( "tenant_id" ).toString();
                    requestBodyMT = requestBodyMT.replace( "{orgID}", orgRumbaId ).replace( "{functionName}", RBSDataSetupConstants.FIXUP_FUNCTIONS_LIST[i] ).replace( "{tenantID}", tenantID ).replace( "{nyrDate}", nyrDate );
                    Response response = RestAssured.given().auth().preemptive().basic( "user1", "user1pass" ).headers( headers ).body( requestBodyMT ).put( url ).then().extract().response();
                    Log.message( response.getBody().asString() + "" );
                    Log.assertThat( response.getStatusCode() == 200, "Fixup Function Executed Successfully", "Fixup Function not Executed" );
                    Log.message( "Executed Function: " + RBSDataSetupConstants.FIXUP_FUNCTIONS_LIST[i] );
                } else {
                    requestBody = requestBody.replace( "{orgID}", orgRumbaId ).replace( "{functionName}", RBSDataSetupConstants.FIXUP_FUNCTIONS_LIST[i] );
                    Response response = RestAssured.given().auth().preemptive().basic( "user1", "user1pass" ).headers( headers ).body( requestBody ).put( url ).then().extract().response();
                    Log.assertThat( response.getStatusCode() == 200, "Fixup Function Executed Successfully", "Fixup Function not Executed" );
                    Log.message( "Executed Function: " + RBSDataSetupConstants.FIXUP_FUNCTIONS_LIST[i] );
                }
            }
        } else {
            Log.fail( "Please add \"isMTExecution\" flag in config property file." );
        }
    }
}
