package com.savvas.sm.utils.sme187.teacher.api.course;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.sme7.DataSetupProcessor;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPIConstants.SCOTYPE;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

public class CourseAPI extends EnvProperties {

    public static String isItMt = configProperty.getProperty( "isMTExecution" );

    DataSetupProcessor dataprocess = new DataSetupProcessor();

    /**
     * This method is used to set the headers
     * <p>
     * userreqDetails - It should include accept type,content
     * type,authorization,user-id and the org-id which we need to send as the
     * headers for an API call
     * 
     * @param userreqDetails
     * 
     * @return headers
     * 
     * @throws Exception
     */

    public Map<String, String> getHeaders( HashMap<String, String> userreqDetails ) {
        //Headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + userreqDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, userreqDetails.get( AssignmentAPIConstants.TEACHER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, userreqDetails.get( AssignmentAPIConstants.ORG_ID ) );
        return headers;
    }

    /**
     * This method gets the course that has been assigned to the student and are
     * present at the home page.
     * <p>
     * envUrl - The SM instance URL
     * <p>
     * dashboardCourseListDetails - It should include
     * orgId,teacherId,bearerToken
     * <p>
     * assignedCourseStatus - It is query param which accepts boolean values
     * 
     * @param envUrl
     * @param dashboardCourseListDetails
     * @param assignedCourseStatus
     * @return response
     * 
     * @throws Exception
     */
    public HashMap<String, String> getCoursesAtDashboardLevel( String envUrl, Map<String, String> dashboardCourseListDetails, String assignedCourseStatus ) throws Exception {

        //Headers
        Map<String, String> headers = new HashMap<String, String>();
        String orgID = dashboardCourseListDetails.get( CourseAPIConstants.ORG_ID );
        String teacherID = dashboardCourseListDetails.get( CourseAPIConstants.TEACHER_ID );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + dashboardCourseListDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, teacherID );
        headers.put( Constants.ORGID_SM_HEADER, orgID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        params.put( CourseAPIConstants.ASSIGNED_COURSE, assignedCourseStatus );

        //Input Path Parameters
        String endPoint = CourseAPIConstants.GET_COURSES_AT_DASHBOARD_LEVEL_API;

        if ( dashboardCourseListDetails.containsKey( CourseAPIConstants.INVALID_ORG_ID ) ) {
            String invalidOrgId = dashboardCourseListDetails.get( CourseAPIConstants.INVALID_ORG_ID );
            endPoint = endPoint.replace( "{organizationId}", invalidOrgId );
        } else {
            endPoint = endPoint.replace( "{organizationId}", orgID );
        }

        return RestHttpClientUtil.GET( envUrl, endPoint, headers, params );
    }

    /**
     * This method gets the course setting of the course
     * <p>
     * envUrl - The SM instance URL
     * <p>
     * dashboardCourseListDetails - It should include
     * orgId,teacherId,bearerToken
     * <p>
     * assignedCourseStatus - It is query param which accepts boolean values
     * <p>
     * courseId - The id of the course of which we want the setting details
     * 
     * @param envUrl
     * @param courseSettings
     * @param assignedCourseStatus
     * @param courseId
     * @return response
     * 
     * @throws Exception
     */
    public HashMap<String, String> getCoursesSettings( String envUrl, HashMap<String, String> courseSettings, String assignedCourseStatus, String courseId ) throws Exception {

        //Headers
        Map<String, String> headers = new HashMap<String, String>();
        String orgID = courseSettings.get( CourseAPIConstants.ORG_ID );
        String teacherID = courseSettings.get( CourseAPIConstants.TEACHER_ID );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + courseSettings.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, teacherID );
        headers.put( Constants.ORGID_SM_HEADER, orgID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        params.put( CourseAPIConstants.ASSIGN, assignedCourseStatus );

        //Input Path Parameters
        String endPoint = CourseAPIConstants.GET_COURSE_SETTING_API;

        if ( courseSettings.containsKey( CourseAPIConstants.INVALID_ORG_ID ) ) {
            String invalidOrgId = courseSettings.get( CourseAPIConstants.INVALID_ORG_ID );
            endPoint = endPoint.replace( "{organizationId}", invalidOrgId );
        } else {
            endPoint = endPoint.replace( "{organizationId}", orgID );
        }
        endPoint = endPoint.replace( "{staffId}", teacherID );
        endPoint = endPoint.replace( "{courseId}", courseId );

        HashMap<String, String> response = RestHttpClientUtil.GET( envUrl, endPoint, headers, params );

        return response;
    }

    /**
     * This method gets the courses at the org level
     * <p>
     * envUrl - The SM instance URL
     * <p>
     * dashboardCourseListDetails - It should include
     * orgId,teacherId,bearerToken
     * 
     * @param envUrl
     * @param dashboardCourseListDetails
     * @return
     * 
     * @throws Exception
     */
    public Map<String, String> getCoursesAtOrgLevel( String envUrl, Map<String, String> dashboardCourseListDetails ) throws Exception {

        //Headers
        Map<String, String> headers = new HashMap<String, String>();
        //Parameters
        HashMap<String, String> params = new HashMap<>();
        //Input Path Parameters
        String endPoint = CourseAPIConstants.GET_COURSES_AT_ORG_LEVEL_API;
        String orgId = null;

        String teacherId = dashboardCourseListDetails.get( CourseAPIConstants.TEACHER_ID );
        if ( dashboardCourseListDetails.containsKey( CourseAPIConstants.INVALID_ORG_ID ) ) {
            orgId = dashboardCourseListDetails.get( CourseAPIConstants.INVALID_ORG_ID );
        } else {
            orgId = dashboardCourseListDetails.get( CourseAPIConstants.ORG_ID );
        }
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + dashboardCourseListDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, teacherId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        if ( dashboardCourseListDetails.containsKey( CourseAPIConstants.INVALID_ORG_ID ) ) {
            String invalidOrgId = dashboardCourseListDetails.get( CourseAPIConstants.INVALID_ORG_ID );
            endPoint = endPoint.replace( "{organizationId}", invalidOrgId );
        } else {
            endPoint = endPoint.replace( "{organizationId}", orgId );
        }

        HashMap<String, String> response = RestHttpClientUtil.GET( envUrl, endPoint, headers, params );

        return response;
    }

    /**
     * This method is used to get the skill hierarchy
     * <p>
     * envUrl - The SM instance URL
     * <p>
     * skillsHierarchyDetails - It should include
     * orgId,teacherId,courseId,cttype-id,level,includeLos. cttypeId,level and
     * includeLos are query params.
     * 
     * @param envUrl
     * @param skillsHierarchyDetails
     * 
     * @return response
     * 
     * @throws Exception
     */
    public HashMap<String, String> getSkillsHierarchy( String envUrl, HashMap<String, String> skillsHierarchyDetails ) throws Exception {

        //Headers
        Map<String, String> headers = getHeaders( skillsHierarchyDetails );

        String orgID = skillsHierarchyDetails.get( CourseAPIConstants.ORG_ID );
        String teacherID = skillsHierarchyDetails.get( CourseAPIConstants.TEACHER_ID );
        String courseId = skillsHierarchyDetails.get( CourseAPIConstants.COURSE_ID );
        String cttypeID = skillsHierarchyDetails.get( CourseAPIConstants.CTTYPE_ID );
        String level = skillsHierarchyDetails.get( CourseAPIConstants.LEVEL );
        String includeLOs = skillsHierarchyDetails.get( CourseAPIConstants.INCLUDE_LOS );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        params.put( CourseAPIConstants.CTTYPE_ID_PARAM, cttypeID );
        params.put( CourseAPIConstants.LEVEL_PARAM, level );
        params.put( CourseAPIConstants.INCLUDE_LOS_PARAM, includeLOs );

        //Input Path Parameters
        String endPoint = CourseAPIConstants.GET_SKILLS_HIERARCHY;

        endPoint = endPoint.replace( "{organizationId}", orgID ).replace( "{staffId}", teacherID ).replace( "{courseID}", courseId );

        HashMap<String, String> response = RestHttpClientUtil.GET( envUrl, endPoint, headers, params );

        return response;
    }

    /**
     * This method is used to get the standard hierarchy
     * <p>
     * envUrl - The SM instance URL
     * <p>
     * skillsHierarchyDetails - It should include
     * orgId,teacherId,courseId,bankId,level,includeLos. bankId,level and
     * includeLos are query params
     * 
     * @param envUrl
     * @param skillsHierarchyDetails
     * 
     * @return response
     * 
     * @throws Exception
     */
    public HashMap<String, String> getStandardHierarchy( String envUrl, HashMap<String, String> standardsHierarchyDetails ) throws Exception {

        //Headers
        Map<String, String> headers = getHeaders( standardsHierarchyDetails );

        String orgID = standardsHierarchyDetails.get( CourseAPIConstants.ORG_ID );
        String teacherID = standardsHierarchyDetails.get( CourseAPIConstants.TEACHER_ID );
        String courseId = standardsHierarchyDetails.get( CourseAPIConstants.COURSE_ID );
        String bankID = standardsHierarchyDetails.get( CourseAPIConstants.BANK_ID );
        String level = standardsHierarchyDetails.get( CourseAPIConstants.LEVEL );
        String includeLOs = standardsHierarchyDetails.get( CourseAPIConstants.INCLUDE_LOS );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        params.put( CourseAPIConstants.BANK_ID_PARAM, bankID );
        params.put( CourseAPIConstants.LEVEL_PARAM, level );
        params.put( CourseAPIConstants.INCLUDE_LOS_PARAM, includeLOs );

        //Input Path Parameters
        String endPoint = CourseAPIConstants.GET_STANDARD_HIERARCHY;

        endPoint = endPoint.replace( "{organizationId}", orgID ).replace( "{staffId}", teacherID ).replace( "{courseID}", courseId );

        HashMap<String, String> response = RestHttpClientUtil.GET( envUrl, endPoint, headers, params );

        return response;
    }

    /**
     * This method is used to get the assignment owner list
     * <p>
     * envUrl - The SM instance URL
     * <p>
     * assignmentOwnerDetails - It should include orgId,teacherId and courseId
     * 
     * @param envUrl
     * @param dashboardCourseListDetails
     * @param assignedCourseStatus
     * 
     * @return
     * 
     * @throws Exception
     */
    public HashMap<String, String> getAssignmentOwnerListDetails( String envUrl, HashMap<String, String> assignmentOwnerDetails ) throws Exception {

        //Headers
        Map<String, String> headers = getHeaders( assignmentOwnerDetails );
        //Parameters
        HashMap<String, String> params = new HashMap<>();
        //Input Path Parameters
        String endPoint = CourseAPIConstants.GET_ASSIGNMENT_OWNER_LIST;

        String orgID = assignmentOwnerDetails.get( CourseAPIConstants.ORG_ID );
        String teacherID = assignmentOwnerDetails.get( CourseAPIConstants.TEACHER_ID );
        String courseId = assignmentOwnerDetails.get( CourseAPIConstants.COURSE_ID );

        endPoint = endPoint.replace( "{organizationId}", orgID ).replace( "{staffId}", teacherID ).replace( "{courseId}", courseId );

        HashMap<String, String> response = RestHttpClientUtil.GET( envUrl, endPoint, headers, params );

        return response;
    }

    /**
     * This method is to create a course based on standards
     * <p>
     * envUrl - The SM instance URL
     * <p>
     * customCourseBasedOnStandardDetails - It should include orgId,teacherId
     * and courseId
     * 
     * @param envUrl
     * @param customCourseBasedOnStandardDetails
     * 
     * @return response_post
     * 
     * @throws Exception
     */
    public Map<String, String> createCourseBasedOnStandards( String envUrl, Map<String, String> customCourseBasedOnStandardDetails ) throws Exception {
        Map<String, String> response_post = new HashMap<>();
        try {
            String orgId = null;
            String staffId = null;
            //Headers
            Map<String, String> headers = new HashMap<String, String>();
            // Input Params
            HashMap<String, String> params = new HashMap<>();
            // EndPoint Details
            String endPoint_post = CourseAPIConstants.CREATE_CUSTOM_COURSE;

            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + customCourseBasedOnStandardDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
            headers.put( Constants.USERID_SM_HEADER, customCourseBasedOnStandardDetails.get( Constants.USERID_SM_HEADER ) );
            headers.put( Constants.ORGID_SM_HEADER, customCourseBasedOnStandardDetails.get( Constants.ORGID_SM_HEADER ) );

            if ( customCourseBasedOnStandardDetails.containsKey( CourseAPIConstants.INVALID_ORG_ID ) ) {
                orgId = customCourseBasedOnStandardDetails.get( CourseAPIConstants.INVALID_ORG_ID );
            } else {
                orgId = customCourseBasedOnStandardDetails.get( CourseAPIConstants.ORG_ID );
            }

            if ( customCourseBasedOnStandardDetails.containsKey( CourseAPIConstants.INVALID_STAFF_ID ) ) {
                staffId = customCourseBasedOnStandardDetails.get( CourseAPIConstants.INVALID_STAFF_ID );
            } else {
                staffId = customCourseBasedOnStandardDetails.get( CourseAPIConstants.TEACHER_ID );
            }
            endPoint_post = endPoint_post.replace( Constants.COURSE_ID, customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_ID ) );
            endPoint_post = endPoint_post.replace( Constants.ORG_ID, orgId );
            endPoint_post = endPoint_post.replace( Constants.STAFF_ID, staffId );

            HashMap<String, String> courseDetails = new HashMap<String, String>();
            courseDetails.put( Constants.COURSENAME_VALUE, customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_NAME ) );
            String requestBody = null;
            List<String> standardDetails = new ArrayList<>();

            if ( customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_ID ).equals( CourseAPIConstants.STRING_ONE ) || customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_ID ).equals( CourseAPIConstants.STRING_THREE ) ) {
                standardDetails = UserSqlHelper.getRandomStandardGradeID( CommonAPIConstants.TEACHER, DataSetupConstants.MATH, isItMt.equalsIgnoreCase( "true" ) );
            } else if ( customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_ID ).equals( CourseAPIConstants.STRING_TWO ) || customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_ID ).equals( CourseAPIConstants.STRING_FIFTEEN ) ) {
                standardDetails = UserSqlHelper.getRandomStandardGradeID( CommonAPIConstants.TEACHER, DataSetupConstants.READING, isItMt.equalsIgnoreCase( "true" ) );
            } else {
                standardDetails = UserSqlHelper.getRandomStandardGradeID( CommonAPIConstants.TEACHER, DataSetupConstants.READING, isItMt.equalsIgnoreCase( "true" ) );
            }

            List<String> listLO = UserSqlHelper.getLOIDsRandomStandard( CommonAPIConstants.TEACHER, standardDetails.get( 0 ), standardDetails.get( 1 ), isItMt.equalsIgnoreCase( "true" ) );
            if ( customCourseBasedOnStandardDetails.containsKey( CourseAPIConstants.STANDARD_FRAMEWORK_ID ) ) {
                courseDetails.put( Constants.STANDARDFRAMEWORK_ID, customCourseBasedOnStandardDetails.get( CourseAPIConstants.STANDARD_FRAMEWORK_ID ) );
            } else {
                courseDetails.put( Constants.STANDARDFRAMEWORK_ID, standardDetails.get( 0 ) );
            }
            if ( customCourseBasedOnStandardDetails.containsKey( CourseAPIConstants.GRADE_ID ) ) {
                courseDetails.put( Constants.GRADE_ID, customCourseBasedOnStandardDetails.get( CourseAPIConstants.GRADE_ID ) );
            } else {
                courseDetails.put( Constants.GRADE_ID, standardDetails.get( 1 ) );
            }

            courseDetails.put( Constants.BANKID, listLO.get( 0 ).split( "_" )[3] ); //To get Bank ID from LO

            if ( customCourseBasedOnStandardDetails.containsKey( CourseAPIConstants.LO ) ) {
                courseDetails.put( Constants.LOID, customCourseBasedOnStandardDetails.get( CourseAPIConstants.LO ) );
            } else {
                courseDetails.put( Constants.LOID, listLO.get( 0 ) );
            }

            if ( customCourseBasedOnStandardDetails.containsKey( CourseAPIConstants.CONTENT_BASE_TYPE ) ) {
                courseDetails.put( Constants.CONTENT_BASE_TYPE, customCourseBasedOnStandardDetails.get( CourseAPIConstants.CONTENT_BASE_TYPE ) );
            } else {
                courseDetails.put( Constants.CONTENT_BASE_TYPE, CourseAPIConstants.STRING_FOUR );
            }

            if ( !customCourseBasedOnStandardDetails.containsKey( CourseAPIConstants.PAYLOAD ) ) {
                if ( customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_ID ).equals( CourseAPIConstants.STRING_ONE ) ) {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_MATH ), courseDetails );
                } else if ( customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_ID ).equals( CourseAPIConstants.STRING_THREE ) ) {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_FOCUS_MATH_THREE ), courseDetails );
                } else if ( customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_ID ).equals( CourseAPIConstants.STRING_FIFTEEN ) ) {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_FOCUS_READING_FIFTEEN ), courseDetails );
                } else {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_READING ), courseDetails );
                }
            } else {
                requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_MATH_INVALID ), courseDetails );
            }

            try {
                response_post = RestHttpClientUtil.POST( envUrl, headers, params, endPoint_post, requestBody );
            } catch ( Exception e ) {
                Log.message( "Issue while executing the post command" );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response_post;
    }

    /**
     * This method is used to create a course based on different configurations
     * like custom by settings,standards and skills. The courseType defines the
     * type of course you want to create.
     * <p>
     * envUrl - The SM instance URL
     * <p>
     * token - This the bearer token
     * <p>
     * subject - This the subject type you want it can be Math or Reading
     * <p>
     * teacherID - This is the user-id of the teacher
     * <p>
     * orgId - This the org-id the school which the teacher belongs to
     * <p>
     * courseType - This defines the type of course you want. It can be
     * Settings,Skills or Standards
     * <p>
     * courseName - This is the name of the course that is being newly created
     * 
     * @param smUrl
     * @param token
     * @param subject
     * @param teacherId
     * @param orgId
     * @param courseType
     * @param courseName
     * 
     * @return response_post
     * 
     * @throws Exception
     */
    public String createCourse( String envUrl, String token, String subject, String teacherId, String orgId, String courseType, String courseName ) throws Exception {
        HashMap<String, String> response_post = new HashMap<>();
        int itr = 0;
        // Input Params
        HashMap<String, String> params = new HashMap<>();
        // EndPoint Details
        String endPoint_post = CourseAPIConstants.CREATE_CUSTOM_COURSE;
        try {
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + token );
            headers.put( Constants.USERID_SM_HEADER, teacherId );
            headers.put( Constants.ORGID_SM_HEADER, orgId );

            if ( subject.contentEquals( DataSetupConstants.MATH ) ) {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "1" );
            } else {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "2" );
            }

            endPoint_post = endPoint_post.replace( Constants.ORG_ID, orgId );
            endPoint_post = endPoint_post.replace( Constants.STAFF_ID, teacherId );

            HashMap<String, String> courseDetails = new HashMap<String, String>();
            courseDetails.put( Constants.COURSE_NAME, courseName );
            String requestBody = null;
            if ( courseType.equalsIgnoreCase( DataSetupConstants.SETTINGS ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SETTING_GENERIC_MATH ), courseDetails );
                } else {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SETTING_GENERIC_READING ), courseDetails );
                }
            }
            //TODO To get RandomSkills
            else if ( courseType.equalsIgnoreCase( DataSetupConstants.SKILL ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SKILLS_GENERIC_MATH ), courseDetails );
                } else {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SKILLS_GENERIC_READING ), courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.STANDARD ) ) {
                List<String> standardDetails = new ArrayList<>();

                Log.message( "isItMT flag is " + isItMt );

                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    standardDetails = UserSqlHelper.getRandomStandardGradeID( CommonAPIConstants.TEACHER, DataSetupConstants.MATH, isItMt.equalsIgnoreCase( "true" ) );
                } else {
                    standardDetails = UserSqlHelper.getRandomStandardGradeID( CommonAPIConstants.TEACHER, DataSetupConstants.READING, isItMt.equalsIgnoreCase( "true" ) );
                }

                List<String> listLO = UserSqlHelper.getLOIDsRandomStandard( CommonAPIConstants.TEACHER, standardDetails.get( 0 ), standardDetails.get( 1 ), isItMt.equalsIgnoreCase( "true" ) );
                courseDetails.put( Constants.STANDARDFRAMEWORK_ID, standardDetails.get( 0 ) );
                courseDetails.put( Constants.GRADE_ID, standardDetails.get( 1 ) );
                courseDetails.put( Constants.BANKID, listLO.get( 0 ).split( "_" )[3] ); //To get Bank ID from LO
                courseDetails.put( Constants.LOID, listLO.get( 0 ) );
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_MATH ), courseDetails );
                } else {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_READING ), courseDetails );
                }

            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.ONE_LO ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = new RBSUtils().generateRequestBody( DataSetupConstants.CUSTOM_BY_SKILL_ONE_LO, courseDetails );
                }
            }

            while ( itr < 3 ) {
                response_post = RestHttpClientUtil.POST( envUrl, headers, params, endPoint_post, requestBody );
                if ( response_post.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                    break;
                }
                itr++;
            }
            if ( response_post.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                return SMUtils.getKeyValueFromResponse( response_post.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.REPORT_COURSEID );
            } else {
                return response_post.get( Constants.REPORT_BODY );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response_post.get( Constants.REPORT_BODY );
    }

    /**
     * This method is used to delete the course
     * <p>
     * envUrl - The SM instance URL
     * <p>
     * userName - This is the username of the teacher
     * <p>
     * password - This the password of the teacher
     * <p>
     * userId - This is the user-id of the teacher
     * <p>
     * orgId - This the org-id the school which the teacher belongs to
     * <p>
     * courseId - This is the id of the course which you want to delete
     * 
     * @param envUrl
     * @param username
     * @param password
     * @param userId
     * @param orgId
     * @param courseId
     * 
     * @return
     * 
     * @throws Exception
     */
    public Map<String, String> deleteCourse( String envUrl, String username, String password, String userId, String orgId, String courseId ) throws Exception {

        Map<String, String> headers = new HashMap<>();
        // Input Params
        HashMap<String, String> params = new HashMap<>();
        String endPoint = CourseAPIConstants.DELETE_COURSE_API;

        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( username, password ) );
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        endPoint = endPoint.replace( Constants.ORG_ID, orgId );
        endPoint = endPoint.replace( Constants.STAFF_ID, userId );
        endPoint = endPoint.replace( Constants.COURSE_ID, courseId );
        return RestHttpClientUtil.DELETE( envUrl, endPoint, headers, params );
    }

    /**
     * This method is used to create a course based on skills. The courseType
     * defines the type of course you want to create.
     * <p>
     * envUrl - The SM instance URL
     * <p>
     * token - This the bearer token
     * <p>
     * subject - This the subject type you want it can be Math or Reading
     * <p>
     * teacherID - This is the user-id of the teacher
     * <p>
     * orgId - This the org-id the school which the teacher belongs to
     * <p>
     * courseType - This defines the type of course you want. It can be Skills
     * <p>
     * courseName - This is the name of the course that is being newly created
     * 
     * @param smUrl
     * @param token
     * @param subject
     * @param teacherId
     * @param orgId
     * @param courseType
     * @param courseName
     * 
     * @return response_post
     */

    public String createCourseBySkill( String envUrl, String token, String subject, String teacherId, String orgId, String courseType, String courseName ) throws Exception {
        HashMap<String, String> response_post = new HashMap<>();
        String requestBody = null;
        // Input Params
        HashMap<String, String> params = new HashMap<>();
        // EndPoint Details
        String endPoint_post = CourseAPIConstants.CREATE_CUSTOM_COURSE;
        try {
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + token );
            headers.put( Constants.USERID_SM_HEADER, teacherId );
            headers.put( Constants.ORGID_SM_HEADER, orgId );
            HashMap<String, String> courseDetails = new HashMap<String, String>();
            courseDetails.put( Constants.COURSE_NAME, courseName );
            if ( subject.contentEquals( DataSetupConstants.MATH ) ) {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "1" );
                requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SKILLS_SINGLE_LO_MATH ), courseDetails );
                Log.message( "Request Body is " + requestBody.toString() );
            } else {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "2" );
                requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SKILLS_SINGLE_LO_READ ), courseDetails );
            }
            endPoint_post = endPoint_post.replace( Constants.ORG_ID, orgId );
            endPoint_post = endPoint_post.replace( Constants.STAFF_ID, teacherId );
            response_post = RestHttpClientUtil.POST( envUrl, headers, params, endPoint_post, requestBody );
            if ( response_post.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                return SMUtils.getKeyValueFromResponse( response_post.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.REPORT_COURSEID );
            } else {
                return response_post.get( Constants.REPORT_BODY );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response_post.get( Constants.REPORT_BODY );
    }

    /**
     * To get the Course List Details API response
     * 
     * @param envUrl
     * @param apiDetails
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getCourseList( String envUrl, HashMap<String, String> apiDetails ) throws Exception {

        // Endpoints
        String endPoint = CourseAPIConstants.GET_COURSE_LIST_FOR_GROUP_ID;

        String orgId = apiDetails.get( CourseAPIConstants.ORG_HYPEN_ID );
        String staffId = apiDetails.get( CourseAPIConstants.USER_HYPEN_ID );
        String groupId = apiDetails.get( CourseAPIConstants.GROUP_ID );

        // invalid org Id
        if ( apiDetails.containsKey( CourseAPIConstants.INVALID_ORG_ID ) ) {
            String invalidOrgId = apiDetails.get( CourseAPIConstants.INVALID_ORG_ID );
            endPoint = endPoint.replace( Constants.ORG_ID, invalidOrgId );
        } else {
            endPoint = endPoint.replace( Constants.ORG_ID, orgId );

        }
        // invalid staff ID
        if ( apiDetails.containsKey( CourseAPIConstants.INVALID_STAFF_ID ) ) {
            String invalidStaffId = apiDetails.get( CourseAPIConstants.INVALID_STAFF_ID );
            endPoint = endPoint.replace( Constants.STAFF_ID, invalidStaffId );
        } else {
            endPoint = endPoint.replace( Constants.STAFF_ID, staffId );
        }
        endPoint = endPoint.replace( Constants.GROUPID, groupId );

        //Headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + apiDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, staffId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        //Parameters
        HashMap<String, String> params = new HashMap<>();
        if ( apiDetails.containsKey( CourseAPIConstants.GROUP_PROGRESS_ASSIGNMENTS ) ) {
            params.put( CourseAPIConstants.GROUP_PROGRESS_ASSIGNMENTS, apiDetails.get( CourseAPIConstants.GROUP_PROGRESS_ASSIGNMENTS ) );
        }

        HashMap<String, String> response = null;
        try {
            Log.message( " Making GET call for API to return the course list for the given group ID" + "\n The Request details is: " + apiDetails.toString() );
            response = RestHttpClientUtil.GET( envUrl, endPoint, headers, params );
            Log.message( "Received Response is: " + response.toString() );
            return response;
        } catch ( Exception e ) {
            e.getStackTrace();
            return null;
        }

    }

    public static ArrayList<String> getKeyValues( JSONObject json, String key ) {
        ArrayList<String> arrayListofString = new ArrayList<>();

        boolean exists = json.has( key );
        Iterator<?> keys;
        String nextKeys;
        if ( !exists ) {
            keys = json.keys();
            while ( keys.hasNext() ) {
                nextKeys = (String) keys.next();
                try {
                    if ( json.get( nextKeys ) instanceof JSONObject ) {
                        if ( exists == false ) {
                            getKeyValues( json.getJSONObject( nextKeys ), key );
                        }

                    } else if ( json.get( nextKeys ) instanceof JSONArray ) {
                        JSONArray jsonarray = json.getJSONArray( nextKeys );
                        for ( int i = 0; i < jsonarray.length(); i++ ) {
                            String jsonarrayString = jsonarray.get( i ).toString();
                            JSONObject innerJSOn = new JSONObject( jsonarrayString );
                            if ( exists == false ) {
                                getKeyValues( innerJSOn, key );
                            }
                        }
                    }

                } catch ( Exception e ) {
                    Log.message( key + " The key is not found " );
                }
            }

        } else {
            arrayListofString.add( json.get( key ).toString() );
        }
        return arrayListofString;
    }

    /**
     * To get the shared courses
     *
     * @param smUrl
     * @param username
     * @param password
     * @param userId
     * @param orgId
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getSharedCourses( String smUrl, String username, String password, String userId, String orgId ) throws Exception {
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( username, password ) );
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        // Input Params
        HashMap<String, String> params = new HashMap<>();

        String endPoint = AdminConstants.GET_SHARE_COURSE;
        return RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
    }

    /**
     * To edit the the shared courses
     * 
     * @param smUrl
     * @param username
     * @param password
     * @param userId
     * @param orgId
     * @param courseId
     * @param schoolIds
     * @return
     * @throws Exception
     */
    public Map<String, String> editSharedCourses( String smUrl, String username, String password, String userId, String orgId, String courseId, List<String> schoolIds ) throws Exception {
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( username, password ) );
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        // Input Params
        HashMap<String, String> params = new HashMap<>();

        String organizationIds = "";
        for ( String schoolId : schoolIds ) {
            organizationIds += schoolId.concat( "\",\"" );
        }
        organizationIds = organizationIds.substring( 0, organizationIds.length() - 3 );

        Map<String, String> requestDetails = new HashMap<>();
        requestDetails.put( Constants.COURSE_ID, courseId );
        requestDetails.put( Constants.ORG_ID, organizationIds );

        String requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "editSharedCourse.json" ), requestDetails );

        String endPoint = AdminConstants.GET_SHARED_COURSE;
        return RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, requestBody );
    }

    /**
     * To create a custom course
     * 
     * @param smUrl
     * @param token
     * @param subject
     * @param teacherID
     * @param orgID
     * @param courseType
     * @param courseName
     * @param jsonFileName
     * @return
     * @throws Exception
     */
    public String createSharedCourse( String smUrl, String token, String subject, String teacherID, String orgID, String courseType, String courseName, String jsonFileName ) throws Exception {
        HashMap<String, String> response_post = new HashMap<>();
        try {
            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + token );
            headers.put( Constants.USERID_SM_HEADER, teacherID );
            headers.put( Constants.ORGID_SM_HEADER, orgID );
            // Input Params
            HashMap<String, String> params = new HashMap<>();

            // EndPoint Details
            String endPoint_post = CourseAPIConstants.CUSTOM_COURSE_SETTINGS;
            if ( subject.contentEquals( DataSetupConstants.MATH ) ) {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "1" );
            } else {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "2" );
            }

            endPoint_post = endPoint_post.replace( Constants.ORG_ID, orgID );
            endPoint_post = endPoint_post.replace( Constants.STAFF_ID, teacherID );

            Map<String, String> courseDetails = new HashMap<String, String>();
            courseDetails.put( Constants.COURSE_NAME, courseName );
            String requestBody = null;
            if ( courseType.equalsIgnoreCase( DataSetupConstants.SETTINGS ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                } else {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.SKILL ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                } else {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.STANDARD ) ) {
                List<String> standardDetails = new ArrayList<>();

                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    standardDetails = SqlHelperAssignment.getRandomStandardGradeID( DataSetupConstants.MATH, isItMt.equalsIgnoreCase( "true" ) );
                } else {
                    standardDetails = SqlHelperAssignment.getRandomStandardGradeID( DataSetupConstants.READING, isItMt.equalsIgnoreCase( "true" ) );
                }

                List<String> listLO = SqlHelperAssignment.getLOIDsRandomStandard( standardDetails.get( 0 ), standardDetails.get( 1 ), isItMt.equalsIgnoreCase( "true" ) );
                courseDetails.put( Constants.STANDARDFRAMEWORK_ID, standardDetails.get( 0 ) );
                courseDetails.put( Constants.GRADE_ID, standardDetails.get( 1 ) );
                courseDetails.put( Constants.BANKID, listLO.get( 0 ).split( "_" )[3] ); //To get Bank ID from LO
                courseDetails.put( Constants.LOID, listLO.get( 0 ) );
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                } else {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                }

            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.ONE_LO ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( DataSetupConstants.CUSTOM_BY_SKILL_ONE_LO, courseDetails );
                }
            }
            response_post = RestHttpClientUtil.POST( smUrl, headers, params, endPoint_post, requestBody );
            if ( response_post.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                return SMUtils.getKeyValueFromResponse( response_post.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.REPORT_COURSEID );
            } else {
                return response_post.get( Constants.REPORT_BODY );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response_post.get( Constants.REPORT_BODY );
    }

    public String createCustomBySettingIPMOnCourse( String envUrl, String token, String subject, String teacherId, String orgId, String courseName ) throws Exception {
        HashMap<String, String> response_post = new HashMap<>();
        // Input Params
        HashMap<String, String> params = new HashMap<>();
        // EndPoint Details
        String endPoint_post = CourseAPIConstants.CREATE_CUSTOM_COURSE;
        try {
            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + token );
            headers.put( Constants.USERID_SM_HEADER, teacherId );
            headers.put( Constants.ORGID_SM_HEADER, orgId );

            if ( subject.contentEquals( DataSetupConstants.MATH ) ) {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "1" );
            } else {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "2" );
            }

            endPoint_post = endPoint_post.replace( Constants.ORG_ID, orgId );
            endPoint_post = endPoint_post.replace( Constants.STAFF_ID, teacherId );

            HashMap<String, String> courseDetails = new HashMap<String, String>();
            courseDetails.put( Constants.COURSE_NAME, courseName );
            String requestBody = null;
            if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SETTING_GENERIC_MATH_IPM_ON ), courseDetails );
            } else {
                requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SETTING_GENERIC_READING_IPM_ON ), courseDetails );
            }
            response_post = RestHttpClientUtil.POST( envUrl, headers, params, endPoint_post, requestBody );
            if ( response_post.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                return SMUtils.getKeyValueFromResponse( response_post.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.REPORT_COURSEID );
            } else {
                return response_post.get( Constants.REPORT_BODY );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response_post.get( Constants.REPORT_BODY );
    }

    /**
     * To create the reading course based on sco type ( Fluency Scos, Video Scos
     * and Comprehension )
     * 
     * @param envUrl
     * @param token
     * @param teacherId
     * @param orgId
     * @param courseName
     * @param scoTypes
     * @return
     */
    public String createReadingCourseBasedOnSCO( String envUrl, String token, String teacherId, String orgId, String courseName, List<SCOTYPE> scoTypes ) {

        // Input Params
        HashMap<String, String> params = new HashMap<>();

        // EndPoint Details
        String endPoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
        HashMap<String, String> response = null;

        try {
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + token );
            headers.put( Constants.USERID_SM_HEADER, teacherId );
            headers.put( Constants.ORGID_SM_HEADER, orgId );

            //Course Id - 2 for reading
            endPoint = endPoint.replace( Constants.COURSE_ID, "2" );

            endPoint = endPoint.replace( Constants.ORG_ID, orgId );
            endPoint = endPoint.replace( Constants.STAFF_ID, teacherId );

            HashMap<String, String> courseDetails = new HashMap<String, String>();
            courseDetails.put( Constants.COURSE_NAME, courseName );
            String requestBody = null;

            //To get the fluency skill
            requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SKILLS_DYNAMIC_READING ), courseDetails );

            List<Map<String, String>> scoDetails = new ArrayList<>();
            scoTypes.forEach( scoType -> {
                try {
                    scoDetails.add( getReadingScos( envUrl, orgId, teacherId, token, scoType ) );
                } catch ( Exception e ) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            } );

            //To set the bank Id and grade Id
            requestBody = JSONUtil.setProperty( requestBody, CourseAPIConstants.GRADE_ID, scoDetails.get( 0 ).get( CourseAPIConstants.GRADE_ID ) );

            JSONObject jsonObject = new JSONObject();
            for ( Map<String, String> scoDetail : scoDetails ) {
                if ( jsonObject.toString().contains( scoDetail.get( CourseAPIConstants.BANK_ID_PARAM ) ) ) {
                    List<String> scoIds = ( (List<String>) jsonObject.get( scoDetail.get( CourseAPIConstants.BANK_ID_PARAM ) ) );
                    scoIds.add( scoDetail.get( CourseAPIConstants.SCOID ) );
                    jsonObject.put( scoDetail.get( CourseAPIConstants.BANK_ID_PARAM ), scoIds );
                } else {
                    jsonObject.put( scoDetail.get( CourseAPIConstants.BANK_ID_PARAM ), new ArrayList<String>( Arrays.asList( scoDetail.get( CourseAPIConstants.SCOID ) ) ) );
                }
            }

            requestBody = JSONUtil.setProperty( requestBody, "mapLoTaxonomyIdMap", jsonObject );

            Log.message( "request Body -" + requestBody );
            response = RestHttpClientUtil.POST( envUrl, headers, params, endPoint, requestBody );
            if ( response.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                return SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.REPORT_COURSEID );
            } else {
                return response.get( Constants.REPORT_BODY );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * To get the Reading Scos
     * 
     * @param envUrl
     * @param orgId
     * @param teacherId
     * @param token
     * @param scoType
     * @return
     * @throws Exception
     */
    public Map<String, String> getReadingScos( String envUrl, String orgId, String teacherId, String token, SCOTYPE scoType ) throws Exception {

        String loId = null;
        String bankId = null;
        String gradeId = null;
        HashMap<String, String> skillsHierarchyDetails = new HashMap<>();
        skillsHierarchyDetails.put( CourseAPIConstants.ORG_ID, orgId );
        skillsHierarchyDetails.put( CourseAPIConstants.TEACHER_ID, teacherId );
        skillsHierarchyDetails.put( CourseAPIConstants.COURSE_ID, "2" );
        skillsHierarchyDetails.put( CourseAPIConstants.CTTYPE_ID, "-1" );
        skillsHierarchyDetails.put( CourseAPIConstants.LEVEL, "0" );
        skillsHierarchyDetails.put( CourseAPIConstants.INCLUDE_LOS, "false" );

        skillsHierarchyDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        HashMap<String, String> skillsHierarchy = new CourseAPI().getSkillsHierarchy( envUrl, skillsHierarchyDetails );

        if ( skillsHierarchy.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
            ObjectMapper objectMapper = new ObjectMapper();
            HashMap<String, Object> skillsHierarchyResponse = objectMapper.convertValue( objectMapper.readTree( skillsHierarchy.get( Constants.REPORT_BODY ) ), HashMap.class );

            Collection<Object> values = ( (HashMap<String, Object>) ( (HashMap<String, Object>) skillsHierarchyResponse.get( "data" ) ).get( "taxonomyOrStandardIdToHierarchyNodes" ) ).values();

            for ( Object value : values ) {
                if ( ( (HashMap<String, String>) value ).get( "name" ).equalsIgnoreCase( "Grade K" ) ) {
                    gradeId = ( (HashMap<String, String>) value ).get( CourseAPIConstants.ID );
                    break;
                }
            }

            if ( Objects.nonNull( gradeId ) ) {
                skillsHierarchyDetails.put( CourseAPIConstants.CTTYPE_ID, gradeId );
                skillsHierarchyDetails.put( CourseAPIConstants.LEVEL, "-1" );
                skillsHierarchy = new CourseAPI().getSkillsHierarchy( envUrl, skillsHierarchyDetails );

                if ( skillsHierarchy.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                    objectMapper = new ObjectMapper();
                    skillsHierarchyResponse = objectMapper.convertValue( objectMapper.readTree( skillsHierarchy.get( Constants.REPORT_BODY ) ), HashMap.class );

                    HashMap<String, Object> hirerachies = ( (HashMap<String, Object>) ( (HashMap<String, Object>) skillsHierarchyResponse.get( "data" ) ).get( "taxonomyOrStandardIdToHierarchyNodes" ) );
                    Collection<Object> hierarchy = hirerachies.values();
                    String id = null;
                    for ( Object hirerarchy : hierarchy ) {
                        if ( ( scoType.equals( SCOTYPE.videoSco ) && ( (String) ( (HashMap<String, Object>) hirerarchy ).get( "name" ) ).equalsIgnoreCase( SCOTYPE.Comprehension.name() ) )
                                || ( ( (String) ( (HashMap<String, Object>) hirerarchy ).get( "name" ) ).equalsIgnoreCase( scoType.name() ) ) ) {
                            id = ( (String) ( (HashMap<String, Object>) hirerarchy ).get( CourseAPIConstants.ID ) );
                            break;
                        }
                    }

                    do {
                        ArrayList<HashMap<String, String>> LoIdsDetail = ( (ArrayList<HashMap<String, String>>) ( (HashMap<String, Object>) ( (HashMap<String, Object>) hirerachies ).get( id ) ).get( "childNodeIds" ) );
                        for ( HashMap<String, String> loIdDeatil : LoIdsDetail ) {
                            if ( ( scoType.equals( SCOTYPE.videoSco ) && loIdDeatil.get( "type" ).equalsIgnoreCase( "LO_NODE" ) && loIdDeatil.get( CourseAPIConstants.ID ).contains( "smre_di" ) )
                                    || ( loIdDeatil.get( "type" ).equalsIgnoreCase( "LO_NODE" ) && !loIdDeatil.get( CourseAPIConstants.ID ).contains( "smre_di" ) ) ) {
                                bankId = id;
                                loId = loIdDeatil.get( CourseAPIConstants.ID );
                                break;
                            } else if ( loIdDeatil.get( "type" ).equalsIgnoreCase( "HIERARCHY_NODE" ) ) {
                                id = loIdDeatil.get( CourseAPIConstants.ID );
                                break;
                            }
                        }
                    } while ( Objects.isNull( loId ) );

                    Log.message( "grade id - " + gradeId );
                    Log.message( "BankId - " + bankId );
                    Log.message( "Lo ID- " + loId );
                } else {
                    Log.failsoft( "Getting issue while get the skill hirerarchy!!!" );
                }
            } else {
                Log.failsoft( "Getting issue while get the grade id from skill hirerarchy!!!" );
            }
        } else {
            Log.failsoft( "Getting issue while get the skill hirerarchy!!!" );
        }
        Map<String, String> scoDetails = new HashMap<>();

        scoDetails.put( CourseAPIConstants.GRADE_ID, gradeId );
        scoDetails.put( CourseAPIConstants.BANK_ID_PARAM, bankId );
        scoDetails.put( CourseAPIConstants.SCOID, loId );
        return scoDetails;
    }

}
