package com.savvas.sm.utils.sme187.student.api.licenses;

import java.util.Map;

import io.restassured.response.Response;
import com.savvas.sm.utils.RestAssuredAPIUtil;

public class LaunchDataStudentAssignment {
    /***
     * 
     * @author madhan.nagarathinam
     * 
     *         getStudentAssignmentLaunchData() -> This method get the details
     *         for student assignments when he has access[licenses] to launch
     *         the course
     *
     * 
     * @param smUrl - The URL can be basic, auto and MSMN. Basic:
     *            https://nightly-next-basic.smdemo.info Auto:
     *            https://nightly-next-auto.smdemo.info MSMN:
     *            https://nightly-next-automsmn.smdemo.info
     * 
     * @param headers - headers must contains org-id, user-id and authorization
     * 
     * @param pathParams - Path params must contain the assignment-userId
     * @return
     * 
     * @return response -> The Get Call response will be given as a static
     *         Response
     * @throws Exception
     */

    public static Response getStudentAssignmentLaunchData( String smUrl, Map<String, String> headers, Map<String, String> pathParams ) throws Exception {
        return RestAssuredAPIUtil.GET( smUrl, headers, LicenseConstants.STUDENT_ASSIGNMENT_LAUNCH_DATA_ENDPOINT, pathParams );
    }

}
