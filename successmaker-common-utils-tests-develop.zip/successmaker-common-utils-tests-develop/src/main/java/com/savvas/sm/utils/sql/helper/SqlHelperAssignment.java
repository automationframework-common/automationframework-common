package com.savvas.sm.utils.sql.helper;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TimeZone;

import javax.sql.rowset.CachedRowSet;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.CommonAPIConstants.DBQueryFor;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sql.helper.AssignmentTable.AssignmentMastery;

/**
 * For Getting Assignment Details from DB
 * 
 * @author madhan.nagarathinam
 *
 */
public class SqlHelperAssignment {

    public static List<AssignmentMastery> getAssignments( String bySubject, String userId ) throws SQLException {
        // define variables required
        List<AssignmentMastery> objToReturn = new ArrayList<AssignmentMastery>();

        // define query
        String queryToExecute = "null";

        // frame query to execute
        if ( bySubject.contains( "MATH" ) ) {
            queryToExecute = String.format( com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI.Assignment.QUERY_TO_GET_ASSIGNMENT_MATH, userId );
        } else if ( bySubject.contains( "READING" ) ) {
            queryToExecute = String.format( com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI.Assignment.QUERY_TO_GET_ASSIGNMENT_READING, userId );
        }

        CachedRowSet resultSet = SQLUtil.executeQueryAndReturnTable( queryToExecute );
        // process query results
        while ( resultSet.next() ) {
            String assignmentId = resultSet.getString( com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI.Assignment.ASSIGNMENT_ID );
            String assignmentName = resultSet.getString( com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI.Assignment.ASSIGNMENT_NAME );
            AssignmentTable assignment = new AssignmentTable();
            AssignmentMastery assignmentMastery = assignment.new AssignmentMastery( assignmentId, assignmentName );
            objToReturn.add( assignmentMastery );
        }
        return objToReturn;
    }

    public Map<String, Map<String, String>> getAuditHistoryAssignments( String orgId ) {
        String queryString = "select deleted_by,assignment_title,student_or_group_name,record_type,assigned_by,course_name,date_created from audit_assignment_history where organization_id = '" + orgId + "'";
        List<Object[]> listItems = null;
        listItems = SQLUtil.executeQuery( queryString );

        Map<String, Map<String, String>> auditHistory = new HashMap<>();
        listItems.forEach( eachItem -> {
            if ( Objects.nonNull( eachItem[2] ) ) {
                Map<String, String> sharedCourse = new HashMap<String, String>();
                sharedCourse.put( "deletedBy", eachItem[0].toString() );
                sharedCourse.put( "assignmentTitle", eachItem[1].toString() );
                sharedCourse.put( "studentOrGroupName", eachItem[2].toString() );
                sharedCourse.put( "recordType", eachItem[3].toString() );
                sharedCourse.put( "assignedBy", eachItem[4].toString() );
                sharedCourse.put( "courseName", eachItem[5].toString() );
                auditHistory.put( eachItem[1].toString() + " , " + eachItem[2].toString(), sharedCourse );
            }
        } );
        return auditHistory;
    }

    public Map<String, Map<String, String>> getSkillsTested( String assignmentUserID, String subject, boolean lastSession, String currentDate ) {
        TimeZone de = TimeZone.getDefault();

        TimeZone.setDefault( TimeZone.getTimeZone( "GMT-7" ) );
        Map<String, Map<String, String>> math_LO_session = new HashMap<>();
        Map<String, Map<String, String>> read_LO_session = new HashMap<>();
        if ( subject.equals( DataSetupConstants.MATH ) ) {
            if ( lastSession && currentDate.equals( "" ) ) {
                String query = "select Distinct math_lo_session.learning_object_id,math_lo_session.curr_completed_lo_attempts,math_lo_session.curr_completed_lo_correct,learning_object.title_tag,learning_object.lobj_description,math_lo_session.date_updated from math_lo_session inner join learning_object using (learning_object_id)  where assignment_user_id='"
                        + assignmentUserID + "'";
                List<Object[]> executeQuery = SQLUtil.executeQuery( query );
                executeQuery.forEach( eachItem -> {
                    if ( Objects.nonNull( eachItem[0] ) ) {
                        Map<String, String> loSessionhistory = new HashMap<String, String>();
                        loSessionhistory.put( "skillId", eachItem[0].toString() );
                        loSessionhistory.put( "skillName", eachItem[4].toString() );
                        loSessionhistory.put( "completedTotalLoAttempts", eachItem[1].toString() );
                        loSessionhistory.put( "completedTotalLoCorrect", eachItem[2].toString() );
                        loSessionhistory.put( "percentageCorrect", Integer.toString( (int) ( ( Integer.parseInt( eachItem[2].toString() ) / (double) Integer.parseInt( eachItem[1].toString() ) ) * 100 ) ) );
                        loSessionhistory.put( "catalogNum", eachItem[3].toString() );

                        try {
                            loSessionhistory.put( "lastSessionDate", new SimpleDateFormat( "MM/dd/yyyy" ).format( new SimpleDateFormat( "yyyy-MM-dd" ).parse( eachItem[5].toString().split( " " )[0] ) ) );
                        } catch ( ParseException e ) {
                            e.printStackTrace();
                        }

                        math_LO_session.put( eachItem[0].toString(), loSessionhistory );
                    }

                } );
            } else {
                String query = "select Distinct math_lo_session.learning_object_id,math_lo_session.curr_completed_lo_attempts,math_lo_session.curr_completed_lo_correct,learning_object.title_tag,learning_object.lobj_description,math_lo_session.date_updated from math_lo_session inner join learning_object using (learning_object_id)  where assignment_user_id='"
                        + assignmentUserID + "'";
                List<Object[]> executeQuery = SQLUtil.executeQuery( query );
                executeQuery.forEach( eachItem -> {
                    if ( Objects.nonNull( eachItem[0] ) ) {
                        Map<String, String> loSessionhistory = new HashMap<String, String>();
                        loSessionhistory.put( "skillId", eachItem[0].toString() );
                        loSessionhistory.put( "skillName", eachItem[4].toString() );
                        loSessionhistory.put( "completedTotalLoAttempts", eachItem[1].toString() );
                        loSessionhistory.put( "completedTotalLoCorrect", eachItem[2].toString() );
                        loSessionhistory.put( "percentageCorrect", Integer.toString( (int) ( ( Integer.parseInt( eachItem[2].toString() ) / (double) Integer.parseInt( eachItem[1].toString() ) ) * 100 ) ) );
                        loSessionhistory.put( "catalogNum", eachItem[3].toString() );
                        math_LO_session.put( eachItem[0].toString(), loSessionhistory );
                    }

                } );

            }
            return math_LO_session;
        } else {
            if ( lastSession && currentDate.equals( "" ) ) {
                String query = "select Distinct read_session_skill.skill_objective_id,read_session_skill.curr_skill_attempts,read_session_skill.curr_skill_correct,read_session_skill.date_updated,learning_object.catalog_num,learning_object.lobj_description,skill_objectives.skill_objective_name from read_session_skill  inner join learning_object using (learning_object_id) inner join skill_objectives using (skill_objective_id) where assignment_user_id = '"
                        + assignmentUserID + "' ";
                List<Object[]> executeQuery = SQLUtil.executeQuery( query );
                executeQuery.forEach( eachItem -> {
                    Map<String, String> loSessionhistory = new HashMap<String, String>();
                    if ( Objects.nonNull( eachItem[0] ) ) {
                        if ( read_LO_session.containsKey( eachItem[0].toString() ) ) {
                            Map<String, String> map = read_LO_session.get( eachItem[0].toString() );
                            map.put( "completedTotalLoAttempts", ( Integer.parseInt( map.get( "completedTotalLoAttempts" ) ) + Integer.parseInt( eachItem[1].toString() ) ) + "" );
                            map.put( "completedTotalLoCorrect", ( Integer.parseInt( map.get( "completedTotalLoCorrect" ) ) + Integer.parseInt( eachItem[2].toString() ) ) + "" );
                            map.put( "percentageCorrect", ( (int) ( ( Integer.parseInt( map.get( "completedTotalLoCorrect" ) ) / (double) Integer.parseInt( map.get( "completedTotalLoAttempts" ) ) ) * 100 ) + "" ) );
                            map.put( "catalogNum", map.get( "catalogNum" ) + "," + eachItem[4].toString() );
                        } else {
                            loSessionhistory.put( "skillId", eachItem[0].toString() );
                            loSessionhistory.put( "skillName", eachItem[6].toString() );
                            loSessionhistory.put( "completedTotalLoAttempts", eachItem[1].toString() );
                            loSessionhistory.put( "completedTotalLoCorrect", eachItem[2].toString() );
                            loSessionhistory.put( "percentageCorrect", Integer.toString( (int) ( ( Integer.parseInt( eachItem[2].toString() ) / (double) Integer.parseInt( eachItem[1].toString() ) ) * 100 ) ) );
                            loSessionhistory.put( "catalogNum", eachItem[4].toString() );
                            //                             loSessionhistory.put( "objectDescription", eachItem[5].toString() );
                            try {
                                loSessionhistory.put( "lastSessionDate", new SimpleDateFormat( "MM/dd/yyyy" ).format( new SimpleDateFormat( "yyyy-MM-dd" ).parse( eachItem[3].toString().split( " " )[0] ) ) );
                            } catch ( ParseException e ) {
                                e.printStackTrace();
                            }
                            read_LO_session.put( eachItem[0].toString(), loSessionhistory );
                        }
                    }

                } );
            } else {
                String query = "select Distinct read_session_skill.skill_objective_id,read_session_skill.curr_skill_attempts,read_session_skill.curr_skill_correct,read_session_skill.date_updated,learning_object.catalog_num,learning_object.lobj_description,skill_objectives.skill_objective_name from read_session_skill  inner join learning_object using (learning_object_id) inner join skill_objectives using (skill_objective_id) where assignment_user_id = '"
                        + assignmentUserID + "' ";
                List<Object[]> executeQuery = SQLUtil.executeQuery( query );
                executeQuery.forEach( eachItem -> {
                    Map<String, String> loSessionhistory = new HashMap<String, String>();
                    if ( Objects.nonNull( eachItem[0] ) ) {
                        if ( read_LO_session.containsKey( eachItem[0].toString() ) ) {
                            Map<String, String> map = read_LO_session.get( eachItem[0].toString() );
                            map.put( "completedTotalLoAttempts", ( Integer.parseInt( map.get( "completedTotalLoAttempts" ) ) + Integer.parseInt( eachItem[1].toString() ) ) + "" );
                            map.put( "completedTotalLoCorrect", ( Integer.parseInt( map.get( "completedTotalLoCorrect" ) ) + Integer.parseInt( eachItem[2].toString() ) ) + "" );
                            map.put( "percentageCorrect", ( (int) ( ( Integer.parseInt( map.get( "completedTotalLoCorrect" ) ) / (double) Integer.parseInt( map.get( "completedTotalLoAttempts" ) ) ) * 100 ) + "" ) );
                            map.put( "catalogNum", map.get( "catalogNum" ) + "," + eachItem[4].toString() );
                        } else {
                            loSessionhistory.put( "skillId", eachItem[0].toString() );
                            loSessionhistory.put( "skillName", eachItem[6].toString() );
                            loSessionhistory.put( "completedTotalLoAttempts", eachItem[1].toString() );
                            loSessionhistory.put( "completedTotalLoCorrect", eachItem[2].toString() );
                            loSessionhistory.put( "percentageCorrect", Integer.toString( (int) ( ( Integer.parseInt( eachItem[2].toString() ) / (double) Integer.parseInt( eachItem[1].toString() ) ) * 100 ) ) );
                            loSessionhistory.put( "catalogNum", eachItem[4].toString() );
                            //                             loSessionhistory.put( "objectDescription", eachItem[5].toString() );
                            read_LO_session.put( eachItem[0].toString(), loSessionhistory );
                        }
                    }

                } );

            }
            return read_LO_session;

        }
    }

    /**
     * This method is used to Delete the Assignments by rumbaID
     * 
     * @param rumbaID
     * @throws IOException
     * @throws InterruptedException
     */

    public static void deleteAssignmntsByRumbaID( String rumbaID ) throws IOException, InterruptedException {
        String query = SMUtils.getDBQuery( DBQueryFor.TEACHER, "deleteDefaultAssignments.sql" );

        query = query.replace( "<rumbaID>", rumbaID );
        boolean assignmentDeleted = false;
        int iter = 0;
        while ( ( !assignmentDeleted ) && iter < 3 ) {
            try {
                assignmentDeleted = SQLUtil.executeInsDelQueryWithoutResult( query );
            } catch ( Exception e ) {
                if ( iter == 2 ) {
                    Log.message( "Issue in deleting the assignment for the teacher - " + rumbaID + "." + e.getMessage() );
                } else {
                    Log.message( "Issue in deleting the assignment for the teacher - " + rumbaID + ".Retrying...." );
                    Thread.sleep( 10000 );
                }

            } finally {
                iter++;
            }
        }
        if ( assignmentDeleted ) {
            Log.message( "Assignments Deleted for the Teacher: " + rumbaID );
        } else {
            Log.message( "Issue in deleting the assignment for the teacher - " + rumbaID );
        }

    }

    /**
     * To get Assignment ID, title & ownerID
     * 
     * @param assignmentID
     * @return
     * @throws IOException
     */
    public static List<String> getAssignmentDetails( String assignmentID ) throws IOException {
        List<String> details = new ArrayList<String>();
        String query = SMUtils.convertFileToString( SMUtils.getQueryDirPath() + "getAssignmentDetails.sql" );
        query = query.replace( "<assignmentID>", assignmentID );

        List<Object[]> result = SQLUtil.executeQuery( query );
        for ( Object[] list : result ) {
            if ( list.length > 0 ) {
                details.add( list[0].toString() );
                details.add( list[1].toString() );
                details.add( list[2].toString() );

            }
        }
        return details;

    }

    /**
     * This method is used to get assignment user id from DB.
     * 
     * @param personID
     * @param assignmentID
     */
    public static String getAssignmentUserID( String personID, String assignmentID ) {
        String assignmentUserID = null;
        String queryString = "select assignment_user_id from school.assignment_user where person_id='" + personID + "' AND assignment_id='" + assignmentID + "' AND isdeleted=0";
        List<Object[]> listItems = SQLUtil.executeQuery( queryString );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : listItems ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        assignmentUserID = arrList.get( 0 );
        return assignmentUserID;
    }

    /**
     * This method is used to get assignment user id from assignmentID.
     * 
     * @param assignmentID
     */
    public static String getAssignmentUserId( String assignmentID ) {
        String assignmentUserId = null;
        String queryString = "select assignment_user_id from assignment_user where assignment_id='" + assignmentID + "'";
        List<Object[]> listItems = SQLUtil.executeQuery( queryString );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : listItems ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        assignmentUserId = arrList.get( 0 );
        return assignmentUserId;
    }

    /**
     * To get the Assignment Listing Details
     * 
     * @param staffid
     * @return
     */
    public static HashMap<String, List<String>> getAssignmentListingDetails( String staffid ) {
        String queryString = "select assignment_id,content_base_id,assignment_title from school.assignment where assignment_owner_id=" + "'" + staffid + "'";
        List<Object[]> listItems = null;
        listItems = SQLUtil.executeQuery( queryString );
        HashMap<String, List<String>> arrMap = null;
        arrMap = new HashMap<String, List<String>>();

        List<String> assignment_id = new ArrayList<>();
        List<String> content_base_id = new ArrayList<>();
        List<String> assignment_name = new ArrayList<>();
        for ( int i = 0; i < listItems.size(); i++ ) {

            if ( listItems != null && listItems.size() > 0 ) {

                assignment_id.add( listItems.get( i )[0].toString() );
                content_base_id.add( listItems.get( i )[1].toString() );
                assignment_name.add( listItems.get( i )[2].toString() );

            }
        }

        arrMap.put( AssignmentAPIConstants.CONTENT_BASE_ID, content_base_id );
        arrMap.put( AssignmentAPIConstants.ASSIGNMENT_ID, assignment_id );
        arrMap.put( AssignmentAPIConstants.ASSIGNMENT_NAME, assignment_name );
        return arrMap;
    }

    /**
     * To get the students Active count
     * 
     * @param assignmentId
     * @return
     */

    public static String getStudentCountForAssignment( String assignmentId ) {
        String queryString = "select count(*) from school.assignment_user where active=1 and assignment_id =" + assignmentId;
        List<Object[]> listItems = null;
        listItems = SQLUtil.executeQuery( queryString );
        HashMap<String, String> arrMap = null;
        if ( listItems != null && listItems.size() > 0 ) {
            arrMap = new HashMap<String, String>();
            arrMap.put( AssignmentAPIConstants.STUDENT_COUNT, listItems.get( 0 )[0].toString() );
        }
        return arrMap.get( AssignmentAPIConstants.STUDENT_COUNT );
    }

    /**
     * To get the Recent assignment listing details (in Home Page)
     * 
     * @param staffid
     * @return
     */
    public static HashMap<String, List<String>> getRecentAssignmentListingDetails( String staffid ) {

        String queryString = "select assignment_id,content_base_id,assignment_title from school.assignment where assignment_owner_id=" + "'" + staffid + "'" + " order by date_updated desc limit 4";
        List<Object[]> listItems = null;
        listItems = SQLUtil.executeQuery( queryString );
        HashMap<String, List<String>> arrMap = null;
        arrMap = new HashMap<String, List<String>>();

        List<String> assignment_id = new ArrayList<>();
        List<String> content_base_id = new ArrayList<>();
        List<String> assignment_name = new ArrayList<>();
        for ( int i = 0; i < listItems.size(); i++ ) {

            if ( listItems != null && listItems.size() > 0 ) {

                assignment_id.add( listItems.get( i )[0].toString() );
                content_base_id.add( listItems.get( i )[1].toString() );
                assignment_name.add( listItems.get( i )[2].toString() );

            }
        }

        arrMap.put( AssignmentAPIConstants.CONTENT_BASE_ID, content_base_id );
        arrMap.put( AssignmentAPIConstants.ASSIGNMENT_ID, assignment_id );
        arrMap.put( AssignmentAPIConstants.ASSIGNMENT_NAME, assignment_name );
        return arrMap;
    }

    /**
     * 
     * @return
     * @throws IOException
     */
    public static List<String> getRandomStandardGradeID( String courseType, Boolean isMTInstance ) throws IOException {
        Log.message( "isMTInstance in UserSqlHelper for getRandomStandardGradeID methods is " + isMTInstance );
        String query = null;
        if ( Boolean.TRUE.equals( isMTInstance ) ) {
            query = SMUtils.convertFileToString( SMUtils.getQueryDirPath() + "getRandomStandards_mt.sql" );
        } else {
            query = SMUtils.convertFileToString( SMUtils.getQueryDirPath() + "getRandomStandards.sql" );
        }

        List<String> standardDetails = new ArrayList<String>();
        if ( courseType.equalsIgnoreCase( "MATH" ) ) {
            query = query.replace( "<subjectID>", "1" );
        } else {
            query = query.replace( "<subjectID>", "4" );
        }

        List<Object[]> result = SQLUtil.executeQuery( query );

        for ( Object[] list : result ) {
            if ( list.length > 0 ) {
                standardDetails.add( list[0].toString() );
                standardDetails.add( list[1].toString() );

            }
        }
        Log.message( "Selected Standard => " + standardDetails.get( 0 ) );
        return standardDetails;
    }

    /**
     * To get LOID with bankID for the random standards
     * 
     * @param loCountforCourse
     * @return
     * @throws IOException
     */
    public static List<String> getLOIDsRandomStandard( String standID, String gradeID, Boolean isMTInstance ) throws IOException {
        String bankID = "";
        String loID = "";
        String query = null;
        if ( Boolean.TRUE.equals( isMTInstance ) ) {
            query = SMUtils.convertFileToString( SMUtils.getQueryDirPath() + "getLObyStandard_mt.sql" );
        } else {
            query = SMUtils.convertFileToString( SMUtils.getQueryDirPath() + "getLObyStandard.sql" );
        }
        List<String> loIds = new ArrayList<String>();
        query = query.replace( "<standard_id>", standID ).replace( "<grade_id>", gradeID );
        List<Object[]> result = SQLUtil.executeQuery( query );
        for ( Object[] list : result ) {
            if ( list.length > 0 ) {
                bankID = list[0].toString();
                loID = list[1].toString();
            }
        }
        String[] splitIndividualID = loID.split( ";" );
        for ( int loCount = 0; loCount < 1; loCount++ ) {
            loIds.add( splitIndividualID[loCount] + "_" + bankID );
        }
        Log.message( "LO id is " + loIds.get( 0 ) );
        return loIds;
    }

    /**
     * This method is used to get session-id of a student.
     * 
     * @param assignmentUserID
     */
    public static String getSessionId( String assignmentUserID ) {
        String sessioID = null;
        String queryString = "select session_id from assignment_session where assignment_user_id=" + assignmentUserID + "";
        List<Object[]> listItems = SQLUtil.executeQuery( queryString );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : listItems ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        sessioID = arrList.get( 0 );
        return sessioID;
    }

    /**
     * To get assignment status at group level
     * 
     * @param assignmentID
     * @return
     * @throws IOException
     */
    public static String getGroupAssignmentStatus( String assignmentID ) throws IOException {
        String isDeleted = null;
        String query = "select isdeleted from  assignment_group where assignment_id = <assignmentID>";
        query = query.replace( "<assignmentID>", assignmentID );
        List<Object[]> result = SQLUtil.executeQuery( query );
        for ( Object[] list : result ) {
            isDeleted = list[0].toString();
        }
        return isDeleted;
    }

    /**
     * To get Performance report details from DB
     * 
     * @param assignmentID
     * @return
     * @throws IOException
     */
    public static Map<String, String> getPerformanceReport( List<String> studentIds, String courseTypeId ) {

        String query = SMUtils.getDBQuery( DBQueryFor.ADMIN, FileConstants.PERFORMANCE_REPORT_QUERY );
        query = query.replace( "studentIds", "'" + studentIds.toString().substring( 1, studentIds.toString().length() - 1 ).replace( ", ", "', '" ) + "'" );
        query = query.replace( "courseTypeId", courseTypeId );
        List<Object[]> result = SQLUtil.executeQuery( query );
        Map<String, String> performanceData = new HashMap<>();
        if ( Objects.nonNull( result.get( 0 )[0] ) ) {
            DecimalFormat formatter = new DecimalFormat( "#.##" );
            if ( String.valueOf( Double.valueOf( result.get( 0 )[0].toString() ) ).substring( 1 ).equals( ".0" ) ) {
                performanceData.put( "currentLevel", String.valueOf( Double.valueOf( result.get( 0 )[0].toString() ) ).substring( 0, 1 ) );
            } else {
                performanceData.put( "currentLevel", String.valueOf( Double.valueOf( result.get( 0 )[0].toString() ) ) );
            }
            if ( String.valueOf( Double.valueOf( result.get( 0 )[1].toString() ) ).substring( 1 ).equals( ".0" ) ) {
                performanceData.put( "ipLevel", String.valueOf( Double.valueOf( result.get( 0 )[1].toString() ) ).substring( 0, 1 ) );
            } else {
                performanceData.put( "ipLevel", String.valueOf( Double.valueOf( result.get( 0 )[1].toString() ) ) );
            }
            double ipLevel = Double.valueOf( result.get( 0 )[2].toString() );
            if ( String.valueOf( ipLevel ).substring( 1 ).equals( ".0" ) ) {
                performanceData.put( "gain", String.valueOf( ipLevel ).substring( 0, 1 ) );
            } else if ( String.valueOf( ipLevel ).length() > 4 ) {
                if ( Integer.parseInt( String.valueOf( ipLevel ).substring( 4, 5 ) ) > 4 ) {
                    performanceData.put( "gain", String.valueOf( Double.valueOf( String.valueOf( ipLevel ).substring( 0, 4 ) ) + 0.01 ) );
                } else {
                    performanceData.put( "gain", String.valueOf( Double.valueOf( String.valueOf( ipLevel ).substring( 0, 4 ) ) ) );
                }
            } else {
                performanceData.put( "gain", String.valueOf( ipLevel ) );
            }

        } else {
            performanceData.put( "currentLevel", "null" );
            performanceData.put( "ipLevel", "null" );
            performanceData.put( "gain", "null" );
        }
        return performanceData;

    }

    /**
     * To get the assignment details for the given student
     * 
     * @param studentId
     * @return
     */
    public static Map<String, Map<String, String>> getAssignmentsDetailsForStudent( String studentId ) {
        String query = "Select au.asmt_assigner_id as creatorId, \r\n" + "        au.assignment_user_id as assignmentUserId,\r\n" + "        au.assignment_id as assignmentId,\r\n" + "        cb.content_base_name as courseName,\r\n"
                + "        cb.subject_id as subjectId,\r\n" + "        cb.content_type_base_id as courseType,\r\n" + "        cb.product_id as productId\r\n"
                + "        from assignment_user au inner join assignment a USING (assignment_id) inner join content_base cb USING ( content_base_id) where \r\n" + "            au.person_id = '{studentId}'\r\n" + "            and au.isdeleted = 0\r\n"
                + "            and au.active = 1";
        query = query.replace( "{studentId}", studentId );
        List<Object[]> result = SQLUtil.executeQuery( query );

        Map<String, Map<String, String>> assignments = new HashMap<>();
        result.forEach( obj -> {
            Map<String, String> assignment = new HashMap<>();
            assignment.put( "creatorId", obj[0].toString() );
            assignment.put( "assignmentUserId", obj[1].toString() );
            assignment.put( "assignmentId", obj[2].toString() );
            assignment.put( "courseName", obj[3].toString() );
            assignment.put( "subjectId", obj[4].toString() );
            assignment.put( "courseType", obj[5].toString() );
            assignment.put( "productId", obj[6].toString() );
            assignments.put( obj[1].toString(), assignment );
        } );

        return assignments;
    }

}
