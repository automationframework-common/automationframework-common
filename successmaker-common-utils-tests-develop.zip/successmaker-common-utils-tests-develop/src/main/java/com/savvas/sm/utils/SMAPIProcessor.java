package com.savvas.sm.utils;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.everit.json.schema.Schema;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.By;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPIConstants;

public class SMAPIProcessor extends DataSetup {

    public static int maxElementWait = 3;
    public static By pageBody = By.cssSelector( "body" );
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    public String smUrl = configProperty.getProperty( "SMAppUrl" );
    public ArrayList<String> arrayListofString = new ArrayList<>();


    /**
     * To Validate response schema
     * 
     * @param serviceName
     * @param statusCode
     * @param response
     * @return
     * @throws IOException
     */
    public boolean isSchemaValid( String serviceName, String statusCode, String response ) throws IOException {
        boolean isSchemaValid = false;
        String basePath = new File( "." ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata";
        String SchemaJson = "";

        if ( statusCode.startsWith( "2" ) ) {
            SchemaJson = basePath + File.separator + "schemaJson" + File.separator + serviceName + ".json";
        } else if ( statusCode.startsWith( "4" ) ) {
            SchemaJson = basePath + File.separator + "schemaJson" + File.separator + "400_Schema.json";
        } else {
            SchemaJson = basePath + File.separator + "schemaJson" + File.separator + "500_Schema.json";
        }

        FileReader reader = new FileReader( SchemaJson );

        JSONObject jsonSchema = new JSONObject( new JSONTokener( reader ) );
        Schema schema = SchemaLoader.load( jsonSchema );

        try {
            schema.validate( new JSONObject( response ) );
            isSchemaValid = true;
            Log.message( serviceName + "_" + statusCode + "-Schema is valid" );
        } catch ( Exception e ) {
            Log.message( "Schema validation Exception: " + e.toString() );
        }
        return isSchemaValid;
    }

    /**
     * This method will check for the list of GraphQl query Params in the
     * response
     * 
     * @param response
     * @param responseParams
     * @return
     */
    public boolean isGraphQlResponseIncludesGivenParams( String response, List<String> responseParams ) {
        boolean returnParam = false;

        for ( String item : responseParams ) {
            if ( response.contains( item ) )
                returnParam = true;
            else {
                returnParam = false;
                Log.fail( "ResponseParam - " + item + " is missing in response" );
                break;
            }
        }
        return returnParam;
    }

    /**
     * for the List for Json
     * 
     * @param values
     * @return
     */
    public String formatListForJSON( List<String> values ) {
        StringBuffer strBuffer = new StringBuffer();
        for ( int i = 0; i < values.size(); i++ ) {
            if ( i != 0 ) {
                strBuffer.append( "\"" + "," + "\"" );
                strBuffer.append( values.get( i ) );
            } else {
                strBuffer.append( values.get( i ) );
            }
        }
        return strBuffer.toString();
    }

    /**
     * It will return all the value for the matching key as a arraylist
     * 
     * @param json -input json data
     * @param key - key name
     * @return return all the values as arrayList else emptyList if not found
     *         any
     * 
     */
    public ArrayList<String> getKeyValues( JSONObject json, String key ) {

        boolean exists = json.has( key );
        Iterator<?> keys;
        String nextKeys;
        if ( !exists ) {
            keys = json.keys();
            while ( keys.hasNext() ) {
                nextKeys = (String) keys.next();
                try {
                    if ( json.get( nextKeys ) instanceof JSONObject ) {
                        if ( exists == false ) {
                            getKeyValues( json.getJSONObject( nextKeys ), key );
                        }

                    } else if ( json.get( nextKeys ) instanceof JSONArray ) {
                        JSONArray jsonarray = json.getJSONArray( nextKeys );
                        for ( int i = 0; i < jsonarray.length(); i++ ) {
                            String jsonarrayString = jsonarray.get( i ).toString();
                            JSONObject innerJSOn = new JSONObject( jsonarrayString );
                            if ( exists == false ) {
                                getKeyValues( innerJSOn, key );
                            }
                        }
                    }

                } catch ( Exception e ) {
                    Log.message( key+" The key is not found " );
                }
            }

        } else {
            arrayListofString.add( json.get( key ).toString() );
        }
        return arrayListofString;
    }

    /**
     * This method generates the request body required for API.
     * 
     * @param requestBodyTemplate
     * @param requestDetails
     * @return
     */
    public String generateRequestBody( String requestBodyTemplate, Map<String, String> requestDetails ) {
        String requestBody = requestBodyTemplate;
        if ( requestBody.contains( Constants.GROUPNAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.GROUPNAME_VALUE, requestDetails.get( Constants.GROUP_NAME ) );
        }
        if ( requestBody.contains( Constants.STUDENT_IDS_VALUE ) ) {
            requestBody = requestBody.replace( Constants.STUDENT_IDS_VALUE, requestDetails.get( Constants.STUDENT_ID ) );
        }
        if ( requestBody.contains( Constants.GROUP_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.GROUP_ID_VALUE, requestDetails.get( Constants.GROUP_ID ) );
        }
        if ( requestBody.contains( Constants.SCHOOL_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.SCHOOL_ID_VALUE, requestDetails.get( Constants.SCHOOL_ID ) );
        }
        if ( requestBody.contains( Constants.FIRST_NAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.FIRST_NAME_VALUE, requestDetails.get( Constants.FIRSTNAME ) );
        }
        if ( requestBody.contains( Constants.MIDDLE_NAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.MIDDLE_NAME_VALUE, requestDetails.get( Constants.MIDDLENAME ) );
        }
        if ( requestBody.contains( Constants.LAST_NAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.LAST_NAME_VALUE, requestDetails.get( Constants.LASTNAME ) );
        }
        if ( requestBody.contains( Constants.USERNAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.USERNAME_VALUE, requestDetails.get( Constants.USER_NAME ) );
        }
        if ( requestBody.contains( Constants.TEACHER_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.TEACHER_ID_VALUE, requestDetails.get( Constants.TEACHER_ID ) );
        }
        if ( requestBody.contains( Constants.USERID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.USERID_VALUE, requestDetails.get( Constants.USER_ID ) );
        }
        if ( requestBody.contains( Constants.GRADE_VALUE ) ) {
            requestBody = requestBody.replace( Constants.GRADE_VALUE, requestDetails.get( Constants.GRADE ) );
        }
        if ( requestBody.contains( Constants.COURSENAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.COURSENAME_VALUE, requestDetails.get( Constants.COURSE_NAME ) );
        }
        if ( requestBody.contains( Constants.ASSIGNMENT_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.ASSIGNMENT_ID_VALUE, requestDetails.get( Constants.ASSIGNMENT_ID ) );
        }
        if ( requestBody.contains( Constants.ASSIGNMENT_USER_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.ASSIGNMENT_USER_ID_VALUE, requestDetails.get( Constants.ASSIGNMENT_USER_ID ) );
        }
        if ( requestBody.contains( Constants.GRADE_ID ) ) {
            requestBody = requestBody.replace( Constants.GRADE_ID, requestDetails.get( Constants.GRADE_ID ) );
        }
        if ( requestBody.contains( Constants.STANDARDFRAMEWORK_ID ) ) {
            requestBody = requestBody.replace( Constants.STANDARDFRAMEWORK_ID, requestDetails.get( Constants.STANDARDFRAMEWORK_ID ) );
        }
        if ( requestBody.contains( Constants.BANKID ) ) {
            requestBody = requestBody.replace( Constants.BANKID, requestDetails.get( Constants.BANKID ) );
        }
        if ( requestBody.contains( Constants.LOID ) ) {
            requestBody = requestBody.replace( Constants.LOID, requestDetails.get( Constants.LOID ) );
        }
        if ( requestBody.contains( Constants.SUBJECT_TYPE_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.SUBJECT_TYPE_ID_VALUE, requestDetails.get( Constants.SUBJECT_ID ) );
        }
        if ( requestBody.contains( Constants.PAYLOAD_ASSIGNMENT_USER_IDS ) ) {
            requestBody = requestBody.replace( Constants.PAYLOAD_ASSIGNMENT_USER_IDS, requestDetails.get( Constants.ASSIGNMENT_USER_ID ) );
        }
        if ( requestBody.contains( Constants.PAYLOAD_SUBJECT_TYPE_ID ) ) {
            requestBody = requestBody.replace( Constants.PAYLOAD_SUBJECT_TYPE_ID, requestDetails.get( Constants.SUBJECT_ID ) );
        }

        if ( requestBody.contains( Constants.COURSE_ID ) ) {
            requestBody = requestBody.replace( Constants.COURSE_ID, requestDetails.get( Constants.COURSE_ID ) );
        }
        if ( requestBody.contains( Constants.COURSE_ID ) ) {
            requestBody = requestBody.replace( Constants.COURSE_ID, requestDetails.get( Constants.COURSE_ID ) );
        }
        if ( requestBody.contains( Constants.ORG_ID ) ) {
            requestBody = requestBody.replace( Constants.ORG_ID, requestDetails.get( Constants.ORG_ID ) );
        }
        if ( requestBody.contains( Constants.CONTENT_BASE_TYPE ) ) {
            requestBody = requestBody.replace( Constants.CONTENT_BASE_TYPE, requestDetails.get( CourseAPIConstants.CONTENT_BASE_TYPE ) );
        }
        if ( requestBody.contains( Constants.SESSION_LENGTH_ID ) ) {
            requestBody = requestBody.replace( Constants.SESSION_LENGTH_ID, requestDetails.get( CourseAPIConstants.SESSION_LENGTH_ID ) );
        }
        if ( requestBody.contains( Constants.SESSION_LENGTH_NAME ) ) {
            requestBody = requestBody.replace( Constants.SESSION_LENGTH_NAME, requestDetails.get( CourseAPIConstants.SESSION_LENGTH_NAME ) );
        }
        if ( requestBody.contains( Constants.SESSION_LENGTH_VALUE ) ) {
            requestBody = requestBody.replace( Constants.SESSION_LENGTH_VALUE, requestDetails.get( CourseAPIConstants.SESSION_LENGTH_VALUE ) );
        }
        if ( requestBody.contains( Constants.IDLE_TIME_ID ) ) {
            requestBody = requestBody.replace( Constants.IDLE_TIME_ID, requestDetails.get( CourseAPIConstants.IDLE_TIME_ID ) );
        }
        if ( requestBody.contains( Constants.IDLE_TIME_NAME ) ) {
            requestBody = requestBody.replace( Constants.IDLE_TIME_NAME, requestDetails.get( CourseAPIConstants.IDLE_TIME_NAME ) );
        }
        if ( requestBody.contains( Constants.IDLE_TIME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.IDLE_TIME_VALUE, requestDetails.get( CourseAPIConstants.IDLE_TIME_VALUE ) );
        }
        return requestBody;
    }

}