package com.savvas.sm.utils.sme187.teacher.api.course;

public interface CourseAPIConstants {

    //End Points
    public String GET_COURSES_AT_ORG_LEVEL_API = "/lms/web/api/v1/organizations/{organizationId}/courses";
    public String GET_COURSES_AT_DASHBOARD_LEVEL_API = "/lms/web/api/v1/organizations/{organizationId}/courses";
    public String GET_COURSE_SETTING_API = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/settings";
    public String DELETE_COURSE_API = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}";
    public String GET_COURSE_SETTING_API_COURSE_TYPE_ID = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/settings?assign=false&courseTypeId={courseId}";
    public String POST_STANDARD_COURSE_COPY = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/copy";
    public String GET_SKILLS_HIERARCHY = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/skills/{courseID}/hierarchy";
    public String CREATE_CUSTOM_COURSE = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/copy";
    public String GET_STANDARD_HIERARCHY = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/standards/{courseID}/hierarchy";
    public String CUSTOM_COURSE_SETTINGS = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/settings";
    public String UPDATE_CUSTOM_COURSE_BY_STANDARDS = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}";
    public String GET_ASSIGNMENT_OWNER_LIST = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/assignments/owners";
    public String GET_COURSE_LIST_FOR_GROUP_ID = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/groups/{groupId}/assignments";
    public String SAVE_SAVE_SESSION_START_TIME = "/lms/web/assignments/sessionstart";
    public String SAVE_SCO_START_TIME = "/lms/web/assignments/scostart";

    //Attributes
    public String USERS_TYPE = "users";
    public String GROUPS_TYPE = "groups";
    public String COURSE_ID = "courseID";
    public String ASSIGNMENT_USER_ID = "assignmentUserID";
    public String ASSIGNED_COURSE = "assignedCourses";
    public String COURSE_START_TIME = "courseStartTime";
    public String STANDARD_FRAMEWORK_ID = "standardFrameworkId";
    public String GRADE_ID = "gradeId";
    public String CONTENT_BASE_TYPE = "contentBaseType";
    public String MAP_LO_TAXONOMY = "mapLoTaxonomy";
    public String LO = "lo";
    public String PAYLOAD = "payload";
    public String ASSIGN = "assign";
    public String COURSE_TYPE_ID = "courseTypeId";
    public String CTTYPE_ID = "cttypeID";
    public String BANK_ID = "bankID";
    public String LEVEL = "level";
    public String INCLUDE_LOS = "includeLos";
    public String CONTENT_BASE_ID = "contentBaseTypeId";

    //Course Settings
    public String SESSION_LENGTH_ID = "sessionLengthId";
    public String SESSION_LENGTH_NAME = "sessionLengthName";
    public String SESSION_LENGTH_VALUE = "sessionLengthValue";
    public String IDLE_TIME_ID = "idleTimeId";
    public String IDLE_TIME_NAME = "idleTimeName";
    public String IDLE_TIME_VALUE = "idleTimeValue";
    public String NAME = "name";
    public String CURRENT_VALUE = "currentValue";
    public String SESSION_LENGTH = "SESSION_LENGTH";
    public String IDLE_TIME = "IDLE_TIME";

    //Course IDs
    public String STRING_ONE = "1";
    public String STRING_TWO = "2";
    public String STRING_THREE = "3";
    public String STRING_FOUR = "4";
    public String STRING_SIX = "6";
    public String STRING_SEVEN = "7";
    public String STRING_NINE = "9";
    public String STRING_THIRTEEN = "13";
    public String STRING_FOURTEEN = "14";
    public String STRING_FIFTEEN = "15";
    public String STRING_EIGHTEEN = "18";

    //Course product description
    public String SUCCESSMAKER_DEFAULT_MATH = "SuccessMaker Default Math";
    public String SUCCESSMAKER_DEFAULT_READING = "SuccessMaker Default Reading";
    public String SUCCESSMAKER_FOCUS_MATH = "SuccessMaker Focus Math";
    public String SUCCESSMAKER_FOCUS_READING = "SuccessMaker Focus Reading";
    public String SUCCESSMAKER_COURSE_CREATED_BY_TEACHER = "Courses created by teachers";

    //Course constants
    public String PRODUCT_DESCRIPTION = "productDescription";
    public String TEACHER = "teacher";
    public String TEACHER_ID = "teacherID";
    public String ORG_ID = "orgID";
    public String STUDENT_RUMBA_IDS = "studentRumbaIds";
    public String STUDENT_RUMBA_GRADE_IDS = "studentRumbaIds_Grades";
    public String STATUS = "status";
    public String INVALID_ORG_ID = "invalidOrgID";
    public String INVALID_TEACHER_ID = "invalidteacherID";
    public String INVALID_STAFF_ID = "invalidStaffID";
    public String GROUP_PROGRESS_ASSIGNMENTS = "groupProgressAssignments";

    //Query params
    public String CTTYPE_ID_PARAM = "cttypeId";
    public String BANK_ID_PARAM = "bankId";
    public String LEVEL_PARAM = "level";
    public String INCLUDE_LOS_PARAM = "includeLos";

    //Shared course constants
    public String ID = "id";
    public String OWNER_ORG_ID = "ownerOrgId";
    public String SHARED_ORG_COUNT = "sharedOrgCount";
    public String PARENT_NODE = "parentNode";
    public String CHILD_NODE = "childNode";
    public String SUBJECT = "subject";
    public String COURSE_TYPE = "courseType";
    public String COURSE_NAME = "courseName";
    public String STATUS_CODE = "statuCode";
    public String VALID = "valid";
    public String TRUE = "true";
    public String USER_HYPEN_ID = "user-id";
    public String ORG_HYPEN_ID = "org-id";
    public String GROUP_ID = "groupId";

    //Invalid
    public String INVALID = "invalid";

    //Non-existing
    public String NON_EXISTING = "nonexisting";

    //Null
    public String NULL = "null";

    //Course Constants
    public String SESSION_STRENGTH_ID = "sessionStrengthId";
    public String SESSION_STRENGTH_NAME = "sessionStrengthName";
    public String SESSION_STRENGTH_VALUE = "sessionStrengthValue";

    public String SCOID = "scoId";

    public enum SCOTYPE {
        Comprehension,
        videoSco,
        Fluency
    }
}
