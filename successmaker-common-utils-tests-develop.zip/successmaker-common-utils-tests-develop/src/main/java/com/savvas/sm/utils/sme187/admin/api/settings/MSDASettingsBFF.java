package com.savvas.sm.utils.sme187.admin.api.settings;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.IntStream;

import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.constants.AdminConstants;

import io.restassured.response.Response;

public class MSDASettingsBFF {

    /**
     * This method is used to GET MSDA ON/OFF Settings
     * 
     * @param smUrl
     * @param headers
     * @param userId
     * @param orgId
     * @param queryItems
     * @return
     */
    public Response getMSDASettingsBFF( Map<String, String> headers, String userId, String orgId, String selectedOrgId ) {

        String query = AdminConstants.GET_MSDA_SETTINGS_PAYLOAD;
        query = query.replace( Constants.USER_ID_VALUE, userId );
        query = query.replace( Constants.ORG_ID, orgId );
        query = query.replace( AdminConstants.SELECTED_ORG_ID, selectedOrgId );
        return RestAssuredAPIUtil.POSTGraphQl( AdminConstants.ADMIN_DASHBOARD_BFF, headers, query, AdminConstants.GRAPHQL_ENDPOINT );
    }

    /**
     * This method is used to save MSDA settings for given organizations
     * 
     * @param headers
     * @param orgIdAndSettings
     * @param userId
     * @return
     */
    public Response saveMSDASettingsBFF( Map<String, String> headers, HashMap<String, String> orgIdAndSettings, String userId ) {
        String query = AdminConstants.SAVE_MSDA_SETTINGS_PAYLOAD;
        query = query.replace( Constants.USER_ID_VALUE, userId );
        String msdaSetting = "{organizationId:\\\"{organizationId}\\\",orgSettings:{isDiagnosticEnabled:\\\"{trueOrFalse}\\\"}}";
        StringBuilder frameQuery = new StringBuilder();
        IntStream.range( 0, orgIdAndSettings.keySet().size() ).forEach( itr -> {
            if ( frameQuery.toString().equals( "" ) ) {
                frameQuery.append( msdaSetting.replace( "{organizationId}", new ArrayList<>( orgIdAndSettings.keySet() ).get( itr ) ).replace( "{trueOrFalse}", new ArrayList<>( orgIdAndSettings.values() ).get( itr ) ) );
            } else {
                frameQuery.append( "," + msdaSetting.replace( "{organizationId}", new ArrayList<>( orgIdAndSettings.keySet() ).get( itr ) ).replace( "{trueOrFalse}", new ArrayList<>( orgIdAndSettings.values() ).get( itr ) ) );
            }
        } );
        query = query.replace( "MSDASettings", frameQuery.toString() );
        return RestAssuredAPIUtil.POSTGraphQl( AdminConstants.ADMIN_DASHBOARD_BFF, headers, query, AdminConstants.GRAPHQL_ENDPOINT );
    }

}
