package com.savvas.sm.utils.sme187.teacher.api.mastery;

public interface MasteryPerformanceConstant {

    String MASTERY_PERFORMANCE_ENDPOINT = "/lms/web/api/v1/mastery/performanceDetails";

}