package com.savvas.sm.utils.sme187.admin.api.dashboard;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.constants.AdminConstants;

import io.restassured.response.Response;

public class OrganizationListBFF {

    public Response getOrganizationListBFF( Map<String, String> headers, String userId, String orgId, String selectedOrgId, List<String> queryItems ) {

        String query = AdminConstants.GET_ORGANIZATION_LIST_PAYLOAD;
        query = query.replace( Constants.USER_ID_VALUE, userId );
        query = query.replace( Constants.ORG_ID, orgId );
        if ( Objects.isNull( selectedOrgId ) ) {
            query = query.replace( AdminConstants.SELECTED_ORG_ID, "" );
        } else {
            query = query.replace( AdminConstants.SELECTED_ORG_ID, selectedOrgId );
        }
        StringBuilder frameQuery = new StringBuilder();
        frameQuery.append( "{" );
        queryItems.forEach( querItem -> {
            if ( frameQuery.toString().equals( "{" ) ) {
                frameQuery.append( querItem );
            } else {
                frameQuery.append( "," + querItem );
            }
        } );
        frameQuery.append( "}" );

        query = query.replace( AdminConstants.QUERY_ITEM, frameQuery.toString() );
        Log.message( query );
        return RestAssuredAPIUtil.POSTGraphQl( AdminConstants.ADMIN_DASHBOARD_BFF, headers, query, AdminConstants.GRAPHQL_ENDPOINT );
    }
}
