package com.savvas.sm.utils.sql.helper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.DBQueryFor;

/**
 * This class used to execute the query and functions in database.
 * 
 * @author ajith.mohan
 *
 */
public class UserSqlHelper {

    /**
     * This method used to create the teacher.
     * 
     * @param firstName
     * @param lastName
     * @param userName
     * @param password
     * @param schoolId
     * @return teacher ID.
     */
    public Integer createTeacher( String firstName, String lastName, String userName, String password, Integer schoolId ) {
        //"guid", "personTypeId", "firstName", "middleName", "lastName", "titleId", "username", "password", "isDefault", "orgId", "staffId", "email", "genderId"
        return createAdmin( firstName, lastName, userName, password, schoolId, Constants.TEACHER_PERSON_TYPE_ID, Constants.RUMBA_ID );
    }

    /**
     * This method used to create the teacher via the stored procedure.
     * 
     * @param firstName
     * @param lastName
     * @param userName
     * @param password
     * @param schoolId
     * @param personTypeId
     * @param rumbaId
     * @return staff ID.
     */
    private Integer createAdmin( String firstName, String lastName, String userName, String password, Integer schoolId, Integer personTypeId, String rumbaId ) {
        Object[] paramValues = { UUID.randomUUID().toString(), personTypeId, firstName, "", lastName, 4, userName, password, Constants.DEFAULT_SCHOOL_ID, schoolId, userName, "", Constants.MALE_GENDER_ID, "" };
        return SQLUtil.executeFunction( "{call successmaker.create_admin(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}", paramValues );
    }

    /**
     * This method is used to delete the user from DB.
     * 
     * @param userName
     * @param functionName
     */
    public void deleteUser( String userName, String functionName ) {
        List<Object[]> data = SQLUtil.executeQuery( "SELECT person_id FROM school.person WHERE username='" + userName + "'" );
        if ( data != null && !data.isEmpty() && data.get( 0 ).length > 0 ) {
            Integer[] paramValues = {};
            SQLUtil.executeFunction( "{call successmaker." + functionName + "(ARRAY[" + Integer.valueOf( data.get( 0 )[0].toString() ) + "])}", paramValues );
        }
    }

    /**
     * THis method is used to delete the teacher.
     * 
     * @param userName
     */
    public void deleteTeacher( String userName ) {
        deleteUser( userName, "delete_teacher" );
    }

    /**
     * This method is used to get assignment user id from DB.
     * 
     * @param personID
     * @param assignmentID
     */
    public String getAssignmentUserID( String personID, String assignmentID ) {
        String assignmentUserID = null;
        String queryString = "select assignment_user_id from school.assignment_user where person_id='" + personID + "' AND assignment_id='" + assignmentID + "' AND isdeleted=0";
        List<Object[]> listItems = SQLUtil.executeQuery( queryString );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : listItems ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        assignmentUserID = arrList.get( 0 );
        return assignmentUserID;
    }

    public Integer createStudent( String firstName, String lastName, String userName, String password, Integer schoolId, Integer teacherId, Integer grade ) {
        Faker fakeName = new Faker();
        String stuMiddleName = fakeName.name().nameWithMiddle().substring( 1, 2 ).toUpperCase();
        Object[] paramValues = { UUID.randomUUID().toString(), firstName, stuMiddleName, lastName, userName, password, DataSetupConstants.MALE_GENDER_ID, grade == null ? 3 : grade, DataSetupConstants.DEFAULT_SCHOOL_ID, schoolId, userName,
                teacherId == null ? null : teacherId, userName, DataSetupConstants.DEFULT_DEMOGRAPHIC_ID, DataSetupConstants.DEFULT_DEMOGRAPHIC_ID, DataSetupConstants.DEFULT_DEMOGRAPHIC_ID, DataSetupConstants.DEFULT_DEMOGRAPHIC_ID,
                DataSetupConstants.DEFULT_DEMOGRAPHIC_ID, DataSetupConstants.DEFULT_DEMOGRAPHIC_ID, "" };
        return SQLUtil.executeFunction( "{call successmaker.create_student(?,?,?,?,?,?, date '2001-10-05',?,?,?,?,?,?,?,?,?,?,?,?,?,?)}", paramValues );
    }

    public Integer createGroup( String groupName, Integer groupTypeId, Integer ownerPersonId, String descriptionText, String rumbaId, Integer organization_id ) {
        Object[] paramValues = { groupName, groupTypeId, ownerPersonId, descriptionText, rumbaId, organization_id };
        return SQLUtil.executeFunction( "{call create_group(?,?,?,?,?,?)}", paramValues );
    }

    /**
     * This method is used to get the person ID from DB
     * 
     * @param userName
     */
    public String getPersonID( String userName ) {
        List<Object[]> person_id = SQLUtil.executeQuery( "SELECT person_id FROM school.person WHERE username='" + userName + "'" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : person_id ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String personID = arrList.get( 0 );
        return personID;
    }

    /*
     * Get Org Id from the given personId
     * 
     * @param personId
     */
    public String getOrgId( String personId ) {
        List<Object[]> org_id = SQLUtil.executeQuery( "SELECT organization_id FROM SCHOOL.PERSON_ORGANIZATION WHERE PERSON_ID =" + personId );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : org_id ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String Oroganization_ID = arrList.get( 0 );
        return Oroganization_ID;
    }

    /*
     * This method will fetch all the Group ID from the given Teacher Id
     * excluded the homeGroup
     * 
     * @param persondId
     */
    public List<String> getGroupIdFromTeacher( String personId ) {
        List<Object[]> groupIds = SQLUtil.executeQuery( "select  group_id from school.group where owner_person_id ='" + personId + "' and group_type_id not in (2)" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : groupIds ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        return arrList;
    }

    /*
     * Get groupName from the given teacherId
     * 
     * @param groupName
     */
    public String getGroupId( String groupName ) {
        List<Object[]> groupIds = SQLUtil.executeQuery( "select  group_id from school.group where group_name ='" + groupName + "'" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : groupIds ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String groupID = arrList.get( 0 );
        return groupID;
    }

    /*
     * Get all the StudentId from given teacherId
     * 
     * @param teacherId
     */
    public ArrayList<String> getStudentIDs( String teacherId ) {
        List<Object[]> result = SQLUtil.executeQuery( "select person_id from  school.person where person_id in (select person_id from school.person_group where group_id = (select group_id  from school.group where owner_person_id = "
                + "(select person_id from school.person where person_id = '" + teacherId + "') and group_type_id =2 ))" );
        List<String> studentIds = new ArrayList<String>();
        for ( Object[] list : result ) {
            if ( list.length > 0 ) {
                studentIds.add( list[0].toString() );
            }
        }
        return (ArrayList<String>) studentIds;
    }

    public String getGroupID( String groupName ) {
        String groupId = null;
        String queryString = "select group_id from school.group where group_name='" + groupName + "'";
        List<Object[]> listItems = SQLUtil.executeQuery( queryString );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : listItems ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        groupId = arrList.get( 0 );
        return groupId;
    }

    /**
     * @param dashboard
     * @param courseType
     * 
     * @return
     * @throws IOException
     */
    public static List<String> getRandomStandardGradeID( String dashboard, String courseType, Boolean isMTInstance ) throws IOException {
        Log.message( "isMTInstance in UserSqlHelper for getRandomStandardGradeID methods is "+ isMTInstance);
        String query = null;
        if ( dashboard.equalsIgnoreCase( CommonAPIConstants.ADMIN ) ) {
            if ( Boolean.TRUE.equals( isMTInstance ) ) {
                query = SMUtils.getDBQuery( DBQueryFor.ADMIN, "getRandomStandards_mt.sql" );
            } else {
                query = SMUtils.getDBQuery( DBQueryFor.ADMIN, "getRandomStandards.sql" );
            }
        } else {
            if ( Boolean.TRUE.equals( isMTInstance ) ) {
                query = SMUtils.getDBQuery( DBQueryFor.TEACHER, "getRandomStandards_mt.sql" );
            } else {
                query = SMUtils.getDBQuery( DBQueryFor.TEACHER, "getRandomStandards.sql" );
            }
        }
        List<String> standardDetails = new ArrayList<String>();
        if ( courseType.equalsIgnoreCase( "MATH" ) ) {
            query = query.replace( "<subjectID>", "1" );
        } else {
            query = query.replace( "<subjectID>", "4" );
        }

        List<Object[]> result = SQLUtil.executeQuery( query );
        for ( Object[] list : result ) {
            if ( list.length > 0 ) {
                standardDetails.add( list[0].toString() );
                standardDetails.add( list[1].toString() );
            }
        }
        Log.message( "Selected Standard => " + standardDetails.get( 0 ) );
        return standardDetails;
    }

    /**
     * To get LOID with bankID for the random standards
     * 
     * @param dashboard
     * @param standID
     * @param gradeID
     * 
     * @return
     * @throws IOException
     */
    public static List<String> getLOIDsRandomStandard( String dashboard, String standID, String gradeID, Boolean isMTInstance ) throws IOException {
        String query = null;
        
        Log.message( "isMTInstance in UserSqlHelper for getLOIDsRandomStandard methods is "+ isMTInstance);
        if ( dashboard.equalsIgnoreCase( CommonAPIConstants.ADMIN ) ) {
            if ( Boolean.TRUE.equals( isMTInstance ) ) {
                query = SMUtils.getDBQuery( DBQueryFor.ADMIN, "getLObyStandard_mt.sql" );
            } else {
                query = SMUtils.getDBQuery( DBQueryFor.ADMIN, "getLObyStandard.sql" );
            }
        } else {
            if ( Boolean.TRUE.equals( isMTInstance ) ) {
                query = SMUtils.getDBQuery( DBQueryFor.TEACHER, "getLObyStandard_mt.sql" );
            } else {
                query = SMUtils.getDBQuery( DBQueryFor.TEACHER, "getLObyStandard.sql" );
            }
        }
        String bankID = "";
        String loID = "";
        List<String> loIds = new ArrayList<String>();
        query = query.replace( "<standard_id>", standID ).replace( "<grade_id>", gradeID );
        List<Object[]> result = SQLUtil.executeQuery( query );
        for ( Object[] list : result ) {
            if ( list.length > 0 ) {
                bankID = list[0].toString();
                loID = list[1].toString();
            }
        }
        String[] splitIndividualID = loID.split( ";" );
        for ( int loCount = 0; loCount < 1; loCount++ ) {
            loIds.add( splitIndividualID[loCount] + "_" + bankID );
        }
        return loIds;
    }

}
