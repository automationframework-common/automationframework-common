package com.savvas.sm.log.api;

import com.learningservices.utils.EnvironmentPropertiesReader;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.Instant;


public class LogAPIResponse {

    public static Logger logger = LogManager.getLogger("LogAPIResponse");

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    public static Boolean isLogApiResponseEnabled = false;
    public static String smUrl = "";

    static {
        logger.info("==== Log API Response Initialized at "+ Instant.now() +" ====");
        logger.info("Method ## API Endpoint ## UserId/Username ## API Response");
        if (null != configProperty.getProperty("isLogApiResponseEnabled")
                && configProperty.getProperty("isLogApiResponseEnabled").equalsIgnoreCase("true")) {
            isLogApiResponseEnabled = true;
            smUrl = configProperty.getProperty("SMAppUrl");
            logger.info("==== API Response Logging Enabled "+ Instant.now() +"====");
        }
    }

    public static void log(String method, String url, String userId, String responseBody) {
        if (isLogApiResponseEnabled && url.contains(smUrl)) {
            try {
                logger.info(method + " ## " + url + " ## " + userId + " ## " + responseBody);
            } catch (Exception e) {
                logger.error("Unable to log API Response");
            }
        }
    }

    public static void log(String method, String url, String userId, Response response) {
        if (isLogApiResponseEnabled && url.contains(smUrl)) {
            try {
                logger.info(method + " ## " + url + " ## " + userId + " ## " + response.body().toString());
            } catch (Exception e) {
                logger.error("Unable to log API Response");
            }
        }
    }
}
