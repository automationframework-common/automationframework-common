package com.savvas.sm.utils.sme187.admin.api.restoreassignment;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPIConstants;

import io.restassured.response.Response;

public class RestoreAssignment extends EnvProperties {

    /**
     * To restore deleted user assignment
     *
     * @param envUrl
     * @param assignmentDetails
     * @param endpoint
     * @return
     * @throws Exception
     */
    public HashMap<String, String> restoreDeletedAssignment( String envUrl, HashMap<String, String> userDetails, String endpoint ) throws Exception {
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + userDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, userDetails.get( Constants.USERID_SM_HEADER ) );
        headers.put( Constants.ORGID_SM_HEADER, userDetails.get( Constants.ORGID_SM_HEADER ) );

        // Parameters
        HashMap<String, String> params = new HashMap<>();

        AtomicReference<String> requestBody = new AtomicReference<>();

        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "restoreDeletedAssignment.json" ) );

        requestBody.set( requestBody.get().replace( "{assignmentUserId}", userDetails.get( AssignmentAPIConstants.ASSIGNMENT_USER_ID ) ) );

        Log.message( "Request Body: " + requestBody.get() );

        if ( endpoint.equalsIgnoreCase( CourseAPIConstants.NULL ) ) {
            endpoint = AssignmentAPIConstants.RESTORE_DELETED_ASSIGNMENTS;
        }

        return RestHttpClientUtil.PUT( envUrl, headers, params, endpoint, requestBody.get() );
    }

    /**
     * This method is used to restore the deleted assignment
     * 
     * @param headers
     * @param assignmentUserId
     * @param userId
     * @param orgId
     * @return
     */
    public Response restoreAssignmentBFF( Map<String, String> headers, String assignmentUserId, String userId, String orgId, String selectedOrgId ) {
        String query = AdminConstants.SAVE_RESTORE_ASSIGNMENT_PAYLOAD;
        query = query.replace( AdminConstants.ASSIGNMENT_USER_ID, assignmentUserId );
        query = query.replace( Constants.USER_ID_VALUE, userId );
        query = query.replace( Constants.ORG_ID, orgId );
        query = query.replace( AdminConstants.SELECTED_ORG_ID, selectedOrgId );
        return RestAssuredAPIUtil.POSTGraphQl( AdminConstants.ADMIN_DASHBOARD_BFF, headers, query, AdminConstants.GRAPHQL_ENDPOINT );
    }

    /**
     * This method is used to GET the deleted assignment
     * 
     * @param smUrl
     * @param headers
     * @param userId
     * @param orgId
     * @param queryItems
     * @return
     */
    public Response getRestoreAssignmentBFF( Map<String, String> headers, String selectedOrgId, String userId, String orgId ) {
        String query = AdminConstants.GET_RESTORE_ASSIGNMENT_PAYLOAD;
        query = query.replace( AdminConstants.SELECTED_ORG_ID, selectedOrgId );
        query = query.replace( Constants.USER_ID_VALUE, userId );
        query = query.replace( Constants.ORG_ID, orgId );
        return RestAssuredAPIUtil.POSTGraphQl( AdminConstants.ADMIN_DASHBOARD_BFF, headers, query, AdminConstants.GRAPHQL_ENDPOINT );
    }

}
