package com.savvas.sm.utils.sql.helper;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.CommonAPIConstants.DBQueryFor;
import com.savvas.sm.utils.constants.FileConstants;

public class SqlHelperReports {

    /**
     * To get the AFG report skills
     * 
     * @param assignmentIds
     * @param subject
     * @return
     */
    public Map<String, Map<String, String>> getAFGSkillsFromDB( String assignmentIds, String subject ) {
        Map<String, Map<String, String>> SkilsFromDB = new HashMap<>();
        if ( subject.equals( Constants.MATH ) ) {
            String query = SMUtils.getDBQuery( DBQueryFor.ADMIN, FileConstants.AFG_REPORT_MATH );
            query = query.replace( "{assignmentId}", assignmentIds );
            List<Object[]> listItems = SQLUtil.executeQuery( query );
            listItems.forEach( object -> {
                Map<String, String> skill = new HashMap<>();
                try {
                    skill.put( "Targeted Lesson", object[8].toString() + ". " + object[9].toString() );
                } catch ( NullPointerException e ) {
                    skill.put( "Targeted Lesson", "" );
                }

                skill.put( "Skill Description", object[7].toString() + " - " + object[5].toString() );
                DecimalFormat decimalFormat = new DecimalFormat( "0.00" );
                String level = new DecimalFormat( "0.000" ).format( Double.valueOf( object[4].toString() ) );
                if ( level.charAt( level.length() - 1 ) == '5' ) {
                    level = level.substring( 0, level.length() - 1 );
                    level = decimalFormat.format( Double.valueOf( level ) + 0.01 );
                } else {
                    level = decimalFormat.format( Double.valueOf( object[4].toString() ) );
                }
                skill.put( "Level", level );
                skill.put( "Strand", object[1].toString() );
                SkilsFromDB.put( level + "-" + skill.get( "Skill Description" ), skill );
            } );
        } else {
            String query = SMUtils.getDBQuery( DBQueryFor.ADMIN, FileConstants.AFG_REPORT_READING );
            query = query.replace( "{assignmentId}", assignmentIds );
            List<Object[]> listItems = SQLUtil.executeQuery( query );
            listItems.forEach( object -> {
                Map<String, String> skill = new HashMap<>();
                try {
                    skill.put( "Targeted Lesson", object[8].toString() + ". " + object[9].toString() );
                } catch ( NullPointerException e ) {
                    skill.put( "Targeted Lesson", "" );
                }
                skill.put( "Skill Description", object[3].toString() );
                DecimalFormat decimalFormat = new DecimalFormat( "0.00" );
                String level = new DecimalFormat( "0.000" ).format( Double.valueOf( object[1].toString() ) );
                if ( level.charAt( level.length() - 1 ) == '5' ) {
                    level = level.substring( 0, level.length() - 1 );
                    level = decimalFormat.format( Double.valueOf( level ) + 0.01 );
                } else {
                    level = decimalFormat.format( Double.valueOf( object[1].toString() ) );
                }
                skill.put( "Level", level );
                skill.put( "Strand", object[0].toString() );
                SkilsFromDB.put( level + "-" + skill.get( "Skill Description" ), skill );
            } );
        }
        return SkilsFromDB;
    }

    /**
     * To get AFG Skills with student List
     * 
     * @param assignmentIds
     * @param subject
     * @return
     */
    public Map<String, List<String>> getAFGSkillsWithStudentsListFromDB( String assignmentIds, String subject ) {
        Map<String, List<String>> studentsFromDB = new HashMap<>();
        if ( subject.equals( Constants.MATH ) ) {
            String query = SMUtils.getDBQuery( DBQueryFor.ADMIN, FileConstants.AFG_REPORT_MATH );
            query = query.replace( "{assignmentId}", assignmentIds );
            List<Object[]> listItems = SQLUtil.executeQuery( query );
            listItems.forEach( object -> {
                DecimalFormat decimalFormat = new DecimalFormat( "0.00" );
                String level = new DecimalFormat( "0.000" ).format( Double.valueOf( object[4].toString() ) );
                if ( level.charAt( level.length() - 1 ) == '5' ) {
                    level = level.substring( 0, level.length() - 1 );
                    level = decimalFormat.format( Double.valueOf( level ) + 0.01 );
                } else {
                    level = decimalFormat.format( Double.valueOf( object[4].toString() ) );
                }
                if ( Objects.nonNull( studentsFromDB.get( level + "-" + object[7].toString() + " - " + object[5].toString() ) ) ) {
                    List<String> assignments = studentsFromDB.get( level + "-" + object[7].toString() + " - " + object[5].toString() );
                    assignments.add( object[0].toString() + "," + object[6].toString().substring( 0, 10 ) );
                    studentsFromDB.put( level + "-" + object[7].toString() + " - " + object[5].toString(), assignments );
                } else {
                    List<String> assignments = new ArrayList<>();
                    assignments.add( object[0].toString() + "," + object[6].toString().substring( 0, 10 ) );
                    studentsFromDB.put( level + "-" + object[7].toString() + " - " + object[5].toString(), assignments );
                }
            } );
        } else {
            String query = SMUtils.getDBQuery( DBQueryFor.ADMIN, FileConstants.AFG_REPORT_READING );
            query = query.replace( "{assignmentId}", assignmentIds );
            List<Object[]> listItems = SQLUtil.executeQuery( query );
            listItems.forEach( object -> {
                DecimalFormat decimalFormat = new DecimalFormat( "0.00" );
                String level = new DecimalFormat( "0.000" ).format( Double.valueOf( object[1].toString() ) );
                if ( level.charAt( level.length() - 1 ) == '5' ) {
                    level = level.substring( 0, level.length() - 1 );
                    level = decimalFormat.format( Double.valueOf( level ) + 0.01 );
                } else {
                    level = decimalFormat.format( Double.valueOf( object[1].toString() ) );
                }
                if ( Objects.nonNull( studentsFromDB.get( level + "-" + object[3].toString() ) ) ) {
                    List<String> assignments = studentsFromDB.get( level + "-" + object[3].toString() );
                    assignments.add( object[0].toString() + "," + object[6].toString().substring( 0, 10 ) );
                    studentsFromDB.put( level + "-" + object[3].toString(), assignments );
                } else {
                    List<String> assignments = new ArrayList<>();
                    assignments.add( object[0].toString() + "," + object[6].toString().substring( 0, 10 ) );
                    studentsFromDB.put( level + "-" + object[3].toString(), assignments );
                }

            } );

        }
        return studentsFromDB;
    }

}
