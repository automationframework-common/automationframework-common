package com.savvas.sm.utils.sme187.admin.api.reports;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.reports.ReportConstants.SPReportConstants;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.DemographicFilters;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportAdminConstants;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportFilters;

import io.restassured.response.Response;

public class Reports extends EnvProperties {

    /**
     * BFF - To get the demographics List for Reports
     * 
     * @param headers
     * @param userId
     * @param orgId
     * @return
     */
    public Response getDemographicsList( Map<String, String> headers, String userId, String orgId ) {
        String query = ReportConstants.GET_DEMOGRAHICS_LIST_PAYLOAD;
        query = query.replace( Constants.USER_ID_VALUE, userId );
        query = query.replace( Constants.ORG_ID, orgId );
        return RestAssuredAPIUtil.POSTGraphQl( ReportConstants.REPORT_BFF, headers, query, ReportConstants.GRAPHQL_ENDPOINT );
    }

    /**
     * BFF - To Get Student performance report output data
     * 
     * @param headers
     * @param reportDetails
     * @return
     */
    public Response getSPReportData( Map<String, String> headers, HashMap<String, String> reportDetails ) {
        String query = SPReportConstants.GET_SPREPORTS_OUTPUT_PAYLOAD;
        query = query.replace( SPReportConstants.STUDENT_ID_VALUE, reportDetails.get( SPReportConstants.STUDENT_ID ) );
        query = query.replace( SPReportConstants.SUBJECT_VALUE, reportDetails.get( SPReportConstants.SUBJECT ) );
        query = query.replace( SPReportConstants.LANGUAGE_VALUE, SPReportConstants.ENGLISH );
        return RestAssuredAPIUtil.POSTGraphQl( ReportConstants.REPORT_BFF, headers, query, ReportConstants.GRAPHQL_ENDPOINT );
    }

    /**
     * This method used to fetch Admin LS Report data
     * 
     * @param username
     * @param password
     * @param userId
     * @param userOrgId
     * @param schoolId
     * @param subject
     * @param filerValues
     * @return
     * @throws Exception
     */
    public static Response getLSReport( String username, String password, String userId, String userOrgId, String schoolId, String subject, Map<String, String> filerValues ) throws Exception {

        // Add headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, userOrgId );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( username, password ) );
        Log.message( "Generted Dynamic Bearer Token : " + new RBSUtils().getAccessToken( username, password ) );
        Log.message( "Generted Dynamic Org Id : " + userOrgId );
        Log.message( "Generted Dynamic User Id : " + userId );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        // Set payload
        String payLoad = String.format( ReportConstants.ADMIN_LSR_PAYLOAD, subject, schoolId, userId, userOrgId );
        for ( Map.Entry<String, String> values : filerValues.entrySet() ) {
            if ( values.getKey().contains( ReportFilters.ADDITIONAL_GROUP_ID_VALUE ) ) {
                payLoad = payLoad.replace( values.getKey(), values.getValue() ); // Adding Additional Grouping value in
            } else {
                payLoad = payLoad.replace( values.getKey(), "\\\"" + values.getValue() + "\\\"" ); // adding id value in
            }
        }

        payLoad = payLoad.replace( ReportFilters.ADDITIONAL_GROUP_ID_VALUE, "0" ).replace( ReportFilters.TEACHER_ID_VALUE, "" ).replace( ReportFilters.GRADE_ID_VALUE, "" ).replace( ReportFilters.GROUP_ID_VALUE, "" ).replace( ReportFilters.ASSIGNMENT_ID,
                "" ).replace( DemographicFilters.DISABILITY_STATUS, "" ).replace( DemographicFilters.ENGLISH_PROFICIENCY, "" ).replace( DemographicFilters.GENDER, "" ).replace( DemographicFilters.MIGRANT_STATUS, "" ).replace( DemographicFilters.RACE,
                        "" ).replace( DemographicFilters.ETHNICITY, "" ).replace( DemographicFilters.SOCIO_STATUS, "" ).replace( DemographicFilters.SPECIAL_SERVICES, "" ).replace( "{courseList}", "" );
        Log.message( "Payload: " + payLoad );

        // Getting LSR repport response
        Response response = RestAssuredAPIUtil.POSTGraphQl( ReportAdminConstants.REPORT_BFF, headers, payLoad, AdminConstants.GRAPHQL_ENDPOINT );
        Log.message( "Response: " + response.getBody().asString() );
        return response;
    }

    /**
     * This method used to fetch Admin Mastery Report data
     * 
     * @param headers
     * @param selectedOrgId
     * @param standId
     * @param subjectId
     * @return
     * @throws Exception
     */
    public Response postMasteryReport( Map<String, String> headers, String selectedOrgId, String standId, int subjectId ) throws Exception {

        // Generate Payload
        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "AdminMasteryRequestBody.json" ) );

        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.organizationId", selectedOrgId ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.subjectId", subjectId ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.standardId", standId ) );

        Response getResponse = RestAssuredAPIUtil.POST( ReportAdminConstants.REPORT_BFF + AdminConstants.GRAPHQL_ENDPOINT, headers, requestBody.get() );
        return getResponse;
    }
        /**
     * To save the CP Report Option
     * 
     * @param adminUserId
     * @param adminorgId
     * @param adminBearerToken
     * @param selectedOrgIds
     * @param subjectId
     * @param optionalFilters
     * @throws Exception
     * 
     * @return
     */
    public static Response saveAdminCPReportOption( Map<String, String> headers, List<String> selectedOrgIds, String subjectId, Map<String, Object> optionalFilters, boolean ispersonReport, String filterName ) throws Exception {

        // Generate Payload
        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "AdminCPSaveReportSubQueryPayload.json" ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "organizations", selectedOrgIds ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "subject", subjectId ) );

        if ( Objects.nonNull( optionalFilters ) ) {
            optionalFilters.keySet().stream().forEach( fieldName -> {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), fieldName, optionalFilters.get( fieldName ) ) );
            } );
        }
        String subQuery = requestBody.get();
        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "AdminCPSaveReportOptionPayload.json" ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.userId", headers.get( Constants.USERID_SM_HEADER ) ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.orgId", headers.get( Constants.ORGID_SM_HEADER ) ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.filterName", filterName ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.personReport", ispersonReport ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.reportParameters", subQuery ) );

        Response response = RestAssuredAPIUtil.POST( ReportAdminConstants.REPORT_BFF, headers, requestBody.get(), AdminConstants.GRAPHQL_ENDPOINT );

        return response;
    }

    /**
     * To split the requestId from the response
     * 
     * @param response
     * @return
     */
    public static String getRequestIdFromResponse( String response ) {
        String requestId = null;
        try {
            requestId = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response, "data" ), "saveReportOption" ), "requestId" );
        } catch ( Exception e ) {
            Log.message( "Getting issue while split the request Id from the response -" + response );
        }
        return requestId;
    }

    /**
     * To save the CPA Report Option
     * 
     * @param headers
     * @param selectedOrgIds
     * @param subjectId
     * @param optionalFilters
     * @return
     * @throws Exception
     */
    public static Response saveAdminCPAReportOption( Map<String, String> headers, List<String> selectedOrgIds, String subjectId, Map<String, Object> optionalFilters, boolean ispersonReport, String filterName ) throws Exception {

        // Generate Payload
        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "AdminCPASaveReportSubQueryPayload.json" ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "organizations", selectedOrgIds ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "subject", subjectId ) );

        if ( Objects.nonNull( optionalFilters ) ) {
            optionalFilters.keySet().stream().forEach( fieldName -> {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), fieldName, optionalFilters.get( fieldName ) ) );
            } );
        }
        String subQuery = requestBody.get();
        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "AdminCPASaveReportOptionPayload.json" ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.userId", headers.get( Constants.USERID_SM_HEADER ) ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.orgId", headers.get( Constants.ORGID_SM_HEADER ) ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.filterName", filterName ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.personReport", ispersonReport ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.reportParameters", subQuery ) );

        Response response = RestAssuredAPIUtil.POST( ReportAdminConstants.REPORT_BFF, headers, requestBody.get(), AdminConstants.GRAPHQL_ENDPOINT );

        return response;
    }

    /**
     * 
     * @param headers
     * @param selectedOrgIds
     * @param subjectId
     * @param optionalFilters
     * @param ispersonReport
     * @param filterName
     * @return
     * @throws Exception
     */
    public Response saveAdminAFGReportOption( Map<String, String> headers, String selectedOrgIds, String subjectId, Map<String, Object> optionalFilters, boolean ispersonReport, String filterName ) throws Exception {

        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "AdminAFGSaveReportSubQueryPayload.json" ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "organizations", selectedOrgIds ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "subject", subjectId ) );

        if ( Objects.nonNull( optionalFilters ) ) {
            optionalFilters.keySet().stream().forEach( fieldName -> {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), fieldName, optionalFilters.get( fieldName ) ) );
            } );
        }
        String subQuery = requestBody.get();
        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "AdminCPASaveReportOptionPayload.json" ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.userId", headers.get( Constants.USERID_SM_HEADER ) ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.orgId", headers.get( Constants.ORGID_SM_HEADER ) ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.filterName", filterName ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.personReport", ispersonReport ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.reportParameters", subQuery ) );

        Response response = RestAssuredAPIUtil.POST( ReportAdminConstants.REPORT_BFF, headers, requestBody.get(), AdminConstants.GRAPHQL_ENDPOINT );

        return response;
    }

    public static Response saveAdminMasteryReportOption( Map<String, String> headers, String selectedOrgIds, String subjectId, String standardSelected, String stdId ) throws Exception {

        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "AdminMasterySaveReportSubQueryPayload.json" ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.orgId", headers.get( Constants.ORGID_SM_HEADER ) ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.userId", headers.get( Constants.USERID_SM_HEADER ) ) );

        String stdReportparam = "{\\\"subjectId\\\":{subId},\\\"standardSelected\\\":{standardSelected},\\\"standardId\\\":{stdId},\\\"organization\\\":\\\"{orgId}\\\"}";
        stdReportparam = stdReportparam.replace( "{subId}", subjectId );
        stdReportparam = stdReportparam.replace( "{standardSelected}", standardSelected );
        stdReportparam = stdReportparam.replace( "{stdId}", stdId );

        if ( standardSelected.equals( "true" ) ) {
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.reportParameters", stdReportparam ) );
        } else {
            stdReportparam = "{\"subjectId\":{subId},\"standardSelected\":{standardSelected},\"organization\":\"{orgId}\"}";
            stdReportparam = stdReportparam.replace( "{subId}", subjectId );
            stdReportparam = stdReportparam.replace( "{standardSelected}", standardSelected );
            stdReportparam = stdReportparam.replace( "{orgId}", selectedOrgIds );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.reportParameters", stdReportparam ) );
        }

        Response response = RestAssuredAPIUtil.POST( "https://sm-mastery-bff-srv-stack-stage.smdemo.info/graphql", headers, requestBody.get(), AdminConstants.GRAPHQL_ENDPOINT );

        return response;
    }
    /**
     * 
     * @param headers
     * @param selectedOrgIds
     * @param subjectId
     * @param optionalFilters
     * @param ispersonReport
     * @param filterName
     * @return
     * @throws Exception
     */
    public Response saveAdminSPReportOption( Map<String, String> headers, String selectedOrgIds, String subjectId, Map<String, Object> optionalFilters, boolean ispersonReport, String filterName ) throws Exception {

        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN,  "AdminSPRSaveReportSubQueryPayload.json" ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "organizations", selectedOrgIds ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "subject", subjectId ) );

        if ( Objects.nonNull( optionalFilters ) ) {
            optionalFilters.keySet().stream().forEach( fieldName -> {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), fieldName, optionalFilters.get( fieldName ) ) );
            } );
        }
        String subQuery = requestBody.get();
        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "AdminCPASaveReportOptionPayload.json" ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.userId", headers.get( Constants.USERID_SM_HEADER ) ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.orgId", headers.get( Constants.ORGID_SM_HEADER ) ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.filterName", filterName ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.personReport", ispersonReport ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.reportParameters", subQuery ) );
        Response response = RestAssuredAPIUtil.POST( ReportAdminConstants.REPORT_BFF, headers, requestBody.get(), AdminConstants.GRAPHQL_ENDPOINT );
        Log.message( response.getBody().asString() );
        return response;
    }
    /**
     * 
     * @param headers
     * @param selectedOrgIds
     * @param subjectId
     * @param optionalFilters
     * @param ispersonReport
     * @param filterName
     * @return
     * @throws Exception
     */
    public Response saveAdminLSReportOption( Map<String, String> headers, String selectedOrgIds, String subjectId, Map<String, Object> optionalFilters, boolean ispersonReport, String filterName ) throws Exception {


        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "AdminLSRSaveReportSubQueryPayload.json" ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "organizations", selectedOrgIds ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "subject", subjectId ) );

        if ( Objects.nonNull( optionalFilters ) ) {
            optionalFilters.keySet().stream().forEach( fieldName -> {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), fieldName, optionalFilters.get( fieldName ) ) );
            } );
        }
        String subQuery = requestBody.get();
        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "AdminCPASaveReportOptionPayload.json" ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.userId", headers.get( Constants.USERID_SM_HEADER ) ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.orgId", headers.get( Constants.ORGID_SM_HEADER ) ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.filterName", filterName ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.personReport", ispersonReport ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.reportParameters", subQuery ) );

        Response response = RestAssuredAPIUtil.POST( ReportAdminConstants.REPORT_BFF, headers, requestBody.get(), AdminConstants.GRAPHQL_ENDPOINT );

        return response;
    }

    /**
     * To get the organizations Name List
     * 
     * @param smUrl
     * @param headers
     * @param orgId
     * @return
     */
    public Response getOrgNameList( String smUrl, HashMap<String, String> headers, String orgId ) {

        String body = ReportConstants.MULTI_ORG_LIST_BODY;
        body = body.replace( "{orgId}", orgId.toString() );
        String endpoint = "/graphql";
        Response response = RestAssuredAPIUtil.POST( smUrl + endpoint, headers, body );
        Log.message( "Response Body" + response.body().asString() );
        return response;
    }
}
