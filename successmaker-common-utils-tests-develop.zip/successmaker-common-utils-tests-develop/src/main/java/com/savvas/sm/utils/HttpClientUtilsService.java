package com.savvas.sm.utils;

import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContexts;

import javax.annotation.PostConstruct;

@SuppressWarnings ( "deprecation" )
public class HttpClientUtilsService {

    HttpClientConnectionManager httpClientConnectionManager;

    @PostConstruct
    public void init() {
        httpClientConnectionManager = new PoolingHttpClientConnectionManager();
    }

    public CloseableHttpClient getCloseableHttpClient() {
        javax.net.ssl.SSLContext sslcontext = SSLContexts.createSystemDefault();
        HttpClientBuilder builder = HttpClientBuilder.create();
        SSLConnectionSocketFactory sslConnectionFactory = new SSLConnectionSocketFactory( sslcontext, SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER );
        builder.setSSLSocketFactory( sslConnectionFactory );
        builder.setConnectionManager( httpClientConnectionManager );
        return builder.build();
    }
}
