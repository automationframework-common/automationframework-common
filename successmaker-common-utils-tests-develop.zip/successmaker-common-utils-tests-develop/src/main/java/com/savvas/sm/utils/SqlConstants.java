package com.savvas.sm.utils;

public interface SqlConstants {

    /**
     * Mastery Sql constants Table - standard_version
     */
    public interface Mastery {

        /**
         * Table - standard_version
         */
        public String STANDARD_VERSION_ID = "standard_version_id";
        public String STANDARD_VERSION = "standard_version";
        public String STATE_VERSION_ID = "state_version_id";
        public String PCS_SUBJECT_ID = "pcs_subject_id";
        public String STANDARD_VERSION_SHORT_NAME = "standard_version_short_name";
        public String DATE_INS = "date_ins";
        public String DATE_UPD = "date_upd";
    }

    public interface StudentProgress {

        public String CURRENT_LEVEL = "currentLevel";
        public String IP_LEVEL = "ipLevel";
        public String ASSIGNED_LEVEL = "AssignedLevel";
        public String IP_COMPLETED_DATE = "IPCompletedDate";
        public String MATH_PROGRESS_QUERY = "select au.assignment_current_level,au.ipm_end_level,au.assignment_start_level ,ms.ipm_complete_time as gain from school.assignment_user as au join school.math_session_history as ms on au.assignment_user_id= ms.assignment_user_id where au.assignment_user_id= %s and ms.ipm_complete_time is not null";
        public String READING_PROGRESS_QUERY = "select au.assignment_current_level,au.ipm_end_level,au.assignment_start_level ,ms.ipm_complete_time as gain from school.assignment_user as au join school.read_session_history as ms on au.assignment_user_id= ms.assignment_user_id where au.assignment_user_id= %s and ms.ipm_complete_time is not null";
    }
}
