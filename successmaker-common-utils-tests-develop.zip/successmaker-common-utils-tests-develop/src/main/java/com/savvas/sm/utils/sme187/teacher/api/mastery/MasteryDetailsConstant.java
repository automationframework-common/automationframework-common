package com.savvas.sm.utils.sme187.teacher.api.mastery;

public interface MasteryDetailsConstant {

    String MASTERY_DETAILS_ENDPOINT = "/lms/web/api/v1/mastery/detail";

}