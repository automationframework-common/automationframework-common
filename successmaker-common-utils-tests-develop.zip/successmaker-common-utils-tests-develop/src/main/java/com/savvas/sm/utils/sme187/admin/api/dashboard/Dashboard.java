package com.savvas.sm.utils.sme187.admin.api.dashboard;

import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.commons.io.IOUtils;
import org.json.JSONObject;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonParser;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;

import io.restassured.response.Response;

public class Dashboard extends EnvProperties {

    /***
     * postOrganizationUsage() -> This method is used to get the organization
     * Usage for students.
     * 
     * @param smUrl - The URL can be basic, auto and MSMN. Basic:
     *            https://nightly-next-basic.smdemo.info Auto:
     * 
     * 
     * @param headers - Headers must contain the content-type, orgId, userId &
     *            Authorization The Keys to be given as follows:
     *            Constants.CONTENT_TYPE OrganizationAPIConstants.ORGID
     *            OrganizationAPIConstants.USERID
     *            OrganizationAPIConstants.AUTHORISATION
     * @param studentIds
     * 
     * @return response -> The post Call response will be given as a
     *         HashMap<String,String>
     * @throws Exception
     */
    public Map<String, String> postOrganizationUsage( String smUrl, Map<String, String> headers, List<String> studentIds ) throws Exception {
        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "postOrganizationUsage.json" ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), AdminConstants.STUDENTIDS, studentIds ) );
        return RestHttpClientUtil.POST( smUrl, headers, new HashMap<>(), AdminConstants.POST_ORGANIZATION_USAGE, requestBody.get() );
    }

    /**
     * This method is used to get the organization Usage BFF
     * 
     * @param headers
     * @param userId
     * @param orgId
     * @return
     */
    public Response postOrganizationUsageBFF( Map<String, String> headers, List<String> selectedOrgId, String userId, String orgId, boolean isInvalidQuery ) {

        String query = AdminConstants.ORGANIZATION_USAGE_PAYLOAD;
        query = query.replace( AdminConstants.SELECTED_ORG_ID, selectedOrgId.toString().replace( "]", "" ).replace( "[", "" ) );
        query = query.replace( Constants.USER_ID_VALUE, userId );
        query = query.replace( Constants.ORG_ID, orgId );
        if ( isInvalidQuery ) {
            query = query.replace( "lastWeekMins", "lastWeekMinsInvalid" );
        }
        return RestAssuredAPIUtil.POSTGraphQl( AdminConstants.ADMIN_DASHBOARD_BFF, headers, query, AdminConstants.GRAPHQL_ENDPOINT );
    }

    /***
     * postOrganizationUsageGoal() -> This method is used to get the
     * organization Usage goal
     * 
     * @param smUrl - The URL can be basic, auto and MSMN. Basic:
     *            https://nightly-next-basic.smdemo.info Auto:
     * 
     * 
     * @param headers - Headers must contain the content-type, orgId, userId &
     *            Authorization The Keys to be given as follows:
     *            Constants.CONTENT_TYPE OrganizationAPIConstants.ORGID
     *            OrganizationAPIConstants.USERID
     *            OrganizationAPIConstants.AUTHORISATION
     * @param studentIds
     * 
     * @return response -> The post Call response will be given as a
     *         HashMap<String,String>
     * @throws Exception
     */
    public Map<String, String> postOrganizationUsageGoal( String smUrl, Map<String, String> headers, List<String> studentIds ) throws Exception {
        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "postOrganizationUsage.json" ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), AdminConstants.STUDENTIDS, studentIds ) );
        return RestHttpClientUtil.POST( smUrl, headers, new HashMap<>(), AdminConstants.POST_ORGANIZATION_USAGE_GOAL, requestBody.get() );
    }

    /**
     * This method is used to get the organization Usage goal BFF
     * 
     * @param headers
     * @param userId
     * @param orgId
     * @return
     */
    public Response postOrganizationUsageGoalBFF( Map<String, String> headers, List<String> selectedOrgId, String userId, String orgId, boolean isInvalidQuery ) {

        String query = AdminConstants.ORGANIZATION_USAGE_GOAL_PAYLOAD;
        query = query.replace( AdminConstants.SELECTED_ORG_ID, selectedOrgId.toString().replace( "]", "" ).replace( "[", "" ) );
        query = query.replace( Constants.USER_ID_VALUE, userId );
        query = query.replace( Constants.ORG_ID, orgId );
        return RestAssuredAPIUtil.POSTGraphQl( AdminConstants.ADMIN_DASHBOARD_BFF, headers, query, AdminConstants.GRAPHQL_ENDPOINT );
    }

    /**
     * Post - Peformance Report -> This Method is used to get the Performance
     * Report For given schools
     * 
     * @throws Exception
     * @return response -> The post Call response will be given as a
     *         HashMap<String,String>
     */
    public Map<String, String> postPerformanceReport( String smUrl, Map<String, String> headers, Map<String, List<String>> studentIds, String subjectTypeId ) throws Exception {
        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "PostPerformanceReportPayload.json" ) );
        studentIds.entrySet().stream().forEach( entry -> requestBody.set( JSONUtil.setProperty( requestBody.get(), entry.getKey(), entry.getValue() ) ) );
        Map<String, String> params = new HashMap<>();
        //params.put( AdminConstants.SUBJECT_TYPE_ID, subjectTypeId );
        String endPoint = AdminConstants.POST_PERFORMANCE_REPORT;
        endPoint = String.format( endPoint, subjectTypeId );
        return RestHttpClientUtil.POST( smUrl, headers, params,endPoint, requestBody.get() );

    }

    /**
     * This method is used to get the performance report BFF
     * 
     * @param headers
     * @param userId
     * @param selectedOrgId
     * @param orgId
     * @return
     */
    public Response postPerformanceReportBFF( Map<String, String> headers, List<String> selectedOrgId, String userId, String orgId, String subjectTypeId ) {
        String query = AdminConstants.PERFORMANCE_REPORT_PAYLOAD;
        query = query.replace( AdminConstants.SELECTED_ORG_ID, selectedOrgId.toString().replace( "]", "" ).replace( "[", "" ) );
        query = query.replace( Constants.USER_ID_VALUE, userId );
        query = query.replace( Constants.ORG_ID, orgId );
        query = query.replace( "{" + AdminConstants.SUBJECT_TYPE_ID + "}", subjectTypeId );
        return RestAssuredAPIUtil.POSTGraphQl( AdminConstants.ADMIN_DASHBOARD_BFF, headers, query, AdminConstants.GRAPHQL_ENDPOINT );
    }
    
    /**
     * This method is used to convert the Json format to map value
     * 
     * @param filename
     * @return
     */
    public Map<String, Object> getJsonMapFromFile(String fileName) throws IOException{
		StringWriter writer = new StringWriter();
		IOUtils.copy(JsonParser.class.getResourceAsStream("/testdata/schemaJson/" +  fileName), writer, StandardCharsets.UTF_8);
		JsonParser.parseString(writer.toString()).getAsJsonObject();
		return new ObjectMapper().readValue(writer.toString(), new TypeReference<Map<String, Object>>(){});
	}
    
    /**
     * This method is used to replace values in the given payload
     * 
     * @param payload
     * @param key
     * @param value
     * @return
     */
	@SuppressWarnings("unchecked")
	public Map<String, Object> replaceValue( Map<String, Object> map, String key, Object value ) {
		if ( key.contains( "." ) ) {
			List<String> keyLst = Arrays.asList( key.split( "\\.", 2 ) );
			if(map.keySet().contains( keyLst.get( 0 ) )){
				replaceValue( (Map<String, Object>) map.get( keyLst.get( 0 ) ), keyLst.get( 1 ), value );
			}else{
				map.put( keyLst.get( 0 ),new HashMap<String, Object>());
				replaceValue( (Map<String, Object>) map.get( keyLst.get( 0 ) ), keyLst.get( 1 ), value );
			}
		} else {
				map.put( key, value );
		}
		return map;
	}

	/**
     * This method is used to convert the mapped payload to Json
     * 
     * @param payload
     * @return
     */
	public String convertMapToJson(Map<String, Object> jsonMap){
		return new JSONObject(jsonMap).toString();
	}

}
