package com.savvas.sm.utils.sme187.teacher.api.assignment;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;

public class SkillTested {
    /**
     * This method post the details and get the skills tested by a student for a
     * particular assignment
     * 
     * @param smUrl
     * @param orgId
     * @param teacherId
     * @param token
     * @param studentID
     * @param assignmentID
     * @param subjectType
     * @param assignmentUserID
     * @param lastSessionFlag
     * @param sessionDates
     * @return
     * @throws Exception
     */
    public Map<String, String> postSkillsTestedForAssignment( String smUrl, String orgId, String teacherId, String token, String studentID, String assignmentID, String subjectType, String assignmentUserID, Boolean lastSessionFlag,
            List<String> sessionDates ) throws Exception {
        // Creating endpoint for the API call
        String endPoint = "/lms/web/api/v1/organizations/" + orgId + "/staffs/" + teacherId + "/assignments/" + assignmentID + "/students/" + studentID + "/skillsTestedReport";
        Log.message( endPoint );
        // Creating headers for the API call
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( Constants.USERID_SM_HEADER, teacherId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );
        // Setting payload
        String subject = subjectType.equals( DataSetupConstants.MATH ) ? "1" : "2";
        String payload = "{ \"subjectTypeId\": subjectID,  \"assignmentUserId\": assignmentUserid,  \"sessionDates\": dates, \"lastSessionFlag\": lsBoolean}";
        payload = payload.replace( "subjectID", subject ).replace( "assignmentUserid", assignmentUserID ).replace( "dates", sessionDates.toString() ).replace( "lsBoolean", lastSessionFlag.toString() );
        Log.message( payload );
        return RestHttpClientUtil.POST( smUrl, headers, new HashMap<>(), endPoint, payload );

    }
}
