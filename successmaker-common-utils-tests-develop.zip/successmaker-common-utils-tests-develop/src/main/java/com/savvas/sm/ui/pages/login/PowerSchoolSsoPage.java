package com.savvas.sm.ui.pages.login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.SMUtils;

/**
 * PowerSchool SSO Page appears when user selects the plus District in the WAYF
 * portal and the user navigates to Teacher and student login portal when users
 * clicks on respective link
 * 
 * @author madhan.nagarathinam
 */

public class PowerSchoolSsoPage extends LoadableComponent<PowerSchoolSsoPage> {
    private WebDriver driver;
    boolean isPageLoaded;

    //********Elements in PowerSchool Single Sign in Page *****

    @FindBy ( css = "div#branding-powerschool" )
    WebElement powerSchoolLogo;

    @FindBy ( linkText = "Sign in as a Teacher" )
    WebElement lnkSignInAsTeacher;

    @FindBy ( linkText = "Sign in as a Student" )
    WebElement lnkSignInAsStudent;

    /**
     * constructor of the class
     * 
     * @param driver
     */
    public PowerSchoolSsoPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
    }

    @Override
    protected void isLoaded() {

        if ( !isPageLoaded ) {
            Assert.fail();
        }

        if ( !driver.getCurrentUrl().toLowerCase().contains( "powerschool" ) ) {
            Log.fail( "PowerSchool Single Sign on Page did not open up. Site might be down.", driver );
        }

    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.fluentWaitForElement( driver, powerSchoolLogo );
    }

    /**
     * To Click Sign in as a TeacherLink on PowerSchool Single Sign-on login
     * page
     * 
     * @param screenShot
     */
    public PowerSchoolTeacherLoginPage navigateToPowerSchoolTeacherLoginPage( boolean screenshot ) {
        Log.event( "Clicking on 'Sign in as a Teacher' link" );
        SMUtils.waitForElement( driver, lnkSignInAsTeacher );
        SMUtils.click( driver, lnkSignInAsTeacher );
        Log.message( "Clicked on 'Sign in as a Teacher' link in PowerSchool Single Sign-on login page", driver );

        return new PowerSchoolTeacherLoginPage( driver ).get();
    }

    /**
     * To Click Sign in as a TeacherLink on PowerSchool Single Sign-on login
     * page
     * 
     * @param screenShot
     */
    public PowerSchoolStudentLoginPage navigateToPowerSchoolStudentLoginPage( boolean screenshot ) {
        Log.event( "Clicking on 'Sign in as a Student' link" );
        SMUtils.waitForElement( driver, lnkSignInAsStudent );
        SMUtils.click( driver, lnkSignInAsStudent );
        Log.message( "Clicked on 'Sign in as a Student' link in PowerSchool Single Sign-on login page", driver );

        return new PowerSchoolStudentLoginPage( driver ).get();
    }
}
