package com.savvas.sm.utils.sme187.teacher.api.users;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.IntStream;

import org.json.JSONObject;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentDetailsForGivenTeacherConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentSearchUsingSolar;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentSkillAssesedConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentUsage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.UpdateStudentProfileConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.UserAPIEndPoints;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.getDemographicsConstants;

public class UserAPI extends EnvProperties {
    public static String smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );

    /**
     * To get the Student Details for Teacher
     * 
     * @param teacherId
     * @param orgId
     * @param accessToken
     * @return
     */
    public HashMap<String, String> getStudentDetailsForTeacher( String teacherId, String orgId, String accessToken ) {

        HashMap<String, String> response = null;

        // InputParams
        HashMap<String, String> params = new HashMap<>();
        params.put( Constants.ORGANIZATION_ID, orgId );

        // headers
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
        headers.put( UserConstants.StudentDetailsForGivenTeacherConstants.user_id_TEXT, teacherId );
        headers.put( UserConstants.StudentDetailsForGivenTeacherConstants.ORG_ID, orgId );

        // Endpoints
        String endPoint = UserConstants.StudentDetailsForGivenTeacherConstants.GET_STUDENTS_DETAILS_FOR_TEACHERID;
        endPoint = endPoint.replace( UserConstants.StudentDetailsForGivenTeacherConstants.TEACHER_ID, teacherId );

        try {
            response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
        } catch ( Exception e ) {
            Log.message( response.toString() );
            e.printStackTrace();
        }
        return response;
    }

    /**
     * This method update the details of the teacher.
     * 
     * @param envUrl
     * 
     * @param staffDetails
     * 
     * @return
     * 
     * @throws Exception
     */
    public HashMap<String, String> updateStaffProfile( String envUrl, HashMap<String, String> staffDetails ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + staffDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, staffDetails.get( UserConstants.USERID ) );
        headers.put( Constants.ORGID_SM_HEADER, staffDetails.get( UserConstants.ORGID ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = UserAPIEndPoints.UPDATE_STAFF_PROFILE_API;

        endPoint = endPoint.replace( UserConstants.STAFFID_ENDPOINT, staffDetails.get( UserConstants.STAFFID ) );
        String requestBody = SMUtils.getPayload( PayloadFor.RBS, FileConstants.UPDATE_STAFF_PROFILE );
        Iterator iterator = staffDetails.entrySet().iterator();
        while ( iterator.hasNext() ) {
            Map.Entry pair = (Map.Entry) iterator.next();
            requestBody = new RBSUtils().generateRequestBodyString( requestBody, pair.getKey().toString(), pair.getValue().toString() );
            iterator.remove();
        }

        HashMap<String, String> response = RestHttpClientUtil.PUT( envUrl, headers, params, endPoint, requestBody );
        return response;
    }

    /**
     * To update the student Profile for API
     * 
     * @param details
     * @return
     */
    public HashMap<String, String> updateStudentProfile( String smUrl, HashMap<String, String> userDetails ) {
        HashMap<String, String> response = null;
        String endPoint = UpdateStudentProfileConstants.PUT_UPDATE_STUDENT_PROFILE_ENDPOINT;

        // InputParams
        HashMap<String, String> inputParameters = new HashMap<>();

        HashMap<String, String> headers = new HashMap<String, String>();
        String body = null;
        try {
            // headers
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + userDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
            headers.put( UserConstants.USERID, userDetails.get( UserConstants.TEACHER_ID ) );
            headers.put( UserConstants.ORGID, userDetails.get( UserConstants.SCHOOLID ) );

            // Endpoints
            endPoint = endPoint.replace( UpdateStudentProfileConstants.STUDENT_ID, userDetails.get( UserConstants.UpdateStudentProfileConstants.STUDENT_ID ) );

            // Request body
            body = SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.UPDATE_STUDENT_PROFILE );
            Iterator iterator = userDetails.entrySet().iterator();
            while ( iterator.hasNext() ) {
                Map.Entry pair = (Map.Entry) iterator.next();
                body = new RBSUtils().generateRequestBodyString( body, pair.getKey().toString(), pair.getValue().toString() );
                iterator.remove();
            }
            try {
                response = RestHttpClientUtil.PUT( smUrl, headers, inputParameters, endPoint, body );
                if ( !response.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                    Log.event( "Status Code: " + response.get( Constants.STATUS_CODE ) );
                    Log.event( "Response body :" + response.get( Constants.REPORT_BODY ) );
                    throw new Exception();
                }
            } catch ( Exception e ) {
                Log.message( "Getting issue while update the student profile.Retrying....." );
                Thread.sleep( 3000 );
                response = RestHttpClientUtil.PUT( smUrl, headers, inputParameters, endPoint, body );
            }
        } catch ( Exception e ) {
            Log.message( response.toString() );
            e.printStackTrace();
        }
        return response;
    }

    /**
     * API to create the student in successmaker For student creation we have to
     * give firstName,Middlename,lastname,grade,organizationID,teacher
     * ID,demographic values like below
     * 
     * 
     *
     * @param envUrl
     * @param studentDetails
     * @return
     * @throws Exception
     */
    public HashMap<String, String> createStudent( String envUrl, HashMap<String, String> studentDetails ) throws Exception {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + studentDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, studentDetails.get( UserConstants.TEACHER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, studentDetails.get( UserConstants.SCHOOLID ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = UserConstants.UserAPIEndPoints.CREATE_STUDENT_ENDPOINT;

        String requestBody = SMUtils.getPayload( PayloadFor.RBS, FileConstants.CREATE_STUDENT_PAYLOAD );
        //        String requestBody = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + FileConstants.CREATE_STUDENT_PAYLOAD );

        if ( studentDetails.containsKey( UserConstants.INVALID_ORG ) ) {
            studentDetails.put( UserConstants.SCHOOLID, studentDetails.get( UserConstants.INVALID_ORG ) );
        }
        if ( studentDetails.containsKey( UserConstants.INVALID_TEACHER ) ) {
            studentDetails.put( UserConstants.TEACHER_ID, studentDetails.get( UserConstants.INVALID_TEACHER ) );
        }

        if ( !studentDetails.containsKey( UserConstants.GRADE ) ) {
            JSONObject requestBodyString = new JSONObject( requestBody );
            requestBodyString.remove( UserConstants.GRADE );
            requestBody = requestBodyString.toString();
        }

        Iterator iterator = studentDetails.entrySet().iterator();
        while ( iterator.hasNext() ) {
            Map.Entry pair = (Map.Entry) iterator.next();
            requestBody = new RBSUtils().generateRequestBodyString( requestBody, pair.getKey().toString(), pair.getValue().toString() );
            iterator.remove();
        }

        HashMap<String, String> response = RestHttpClientUtil.POST( envUrl, headers, params, endPoint, requestBody );

        return response;
    }

    public HashMap<String, String> studentProgressGraphAPI( String envUrl, HashMap<String, String> apiDetails ) throws Exception {

        Map<String, String> headers = new HashMap<String, String>();
        String orgID = apiDetails.get( UserConstants.ORG_ID );
        String teacherID = apiDetails.get( UserConstants.TEACHER_ID );

        // Headers
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.USERID_SM_HEADER, apiDetails.get( Constants.USERID ) );
        headers.put( Constants.ORGID_SM_HEADER, apiDetails.get( Constants.GROUP_ORG_ID ) );
        headers.put( Constants.AUTHORIZATION, "Bearer " + apiDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();
        params.put( Constants.SUBJECT_TYPE_ID, apiDetails.get( Constants.SUBJECT_TYPE_ID ) );

        //Endpoints
        String endPoint = UserAPIEndPoints.GET_STUDENT_PROGRESS_API;
        endPoint = endPoint.replace( Constants.ORG_ID, apiDetails.get( Constants.ORGANIZATION_ID ) );
        endPoint = endPoint.replace( Constants.USER_ID_VALUE, apiDetails.get( Constants.TEACHER_ID ) );
        endPoint = endPoint.replace( Constants.ASSIGNMENT_ID_VALUE, apiDetails.get( Constants.ASSIGNMENT_ID ) );
        endPoint = endPoint.replace( Constants.STUDENT_IDS_VALUE, apiDetails.get( Constants.STUDENT_ID ) );

        HashMap<String, String> response = RestHttpClientUtil.GET( envUrl, endPoint, headers, params );
        return response;

    }

    /**
     * Get skill Tested Details for student API details should contain ORG ID,
     * Staff ID, Student ID, Assignment ID, Assignment User ID, Last Session
     * Flag, Session Dates
     * 
     * @param smUrl
     * @param apiDetails
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getStudentSkillTested( String smUrl, HashMap<String, String> apiDetails ) throws Exception {
        HashMap<String, String> response = null;

        try {
            String assignmentUserId = null;
            if ( apiDetails.containsKey( StudentSkillAssesedConstants.INVALID_ASSIGMENT_USER_ID ) ) {
                assignmentUserId = apiDetails.get( StudentSkillAssesedConstants.INVALID_ASSIGMENT_USER_ID );
            } else {
                assignmentUserId = apiDetails.get( StudentSkillAssesedConstants.ASSIGNMENT_USER_ID );
                Log.message( "assignmentUID" + assignmentUserId );
                Log.message( "assignmentUIDField" + StudentSkillAssesedConstants.ASSIGNMENT_USER_ID );

            }
            String body = "{" + "\"subjectTypeId\":" + apiDetails.get( StudentSkillAssesedConstants.SUBJECT_TYPE_ID ) + ",\"assignmentUserId\":" + assignmentUserId + ",\"sessionDates\":" + apiDetails.get( StudentSkillAssesedConstants.SESSION_DATES )
                    + ",\"lastSessionFlag\":" + apiDetails.get( StudentSkillAssesedConstants.LAST_SESSION_FLAG ) + "}";
            Log.message( "body" + body );
            Log.message( "apiDetails" + apiDetails );

            String staffId = apiDetails.get( Constants.STAFF_ID_VALUE );
            String studentId = apiDetails.get( Constants.ASSIGNMENT_ID );
            String assignmentId = apiDetails.get( StudentSkillAssesedConstants.ASSIGNMENT_USER_ID );

            String orgId = apiDetails.get( Constants.ORGANIZATION_ID );

            String endpoint = UserConstants.UserAPIEndPoints.POST_LAST_SESSION_SKILLS_STUDENT_API;

            if ( apiDetails.containsKey( UserConstants.INVALID_TEACHER ) ) {
                endpoint = endpoint.replace( UserConstants.INVALID_TEACHER, staffId );
            } else {
                endpoint = endpoint.replace( Constants.STAFF_ID_VALUE, staffId );
            }
            endpoint = endpoint.replace( Constants.STUDENT_ID, studentId );

            if ( apiDetails.containsKey( StudentSkillAssesedConstants.INVALID_ASSIGMENT_ID ) ) {
                endpoint = endpoint.replace( StudentSkillAssesedConstants.INVALID_ASSIGMENT_ID, orgId );
            } else {
                endpoint = endpoint.replace( Constants.ASSIGNMENT_ID, assignmentId );
            }

            if ( apiDetails.containsKey( GroupConstants.INVALID_ORG ) ) {
                endpoint = endpoint.replace( Constants.ORGANIZATION_ID, apiDetails.get( GroupConstants.INVALID_ORG ) );
            } else {
                endpoint = endpoint.replace( Constants.ORGANIZATION_ID, orgId );
            }
            Log.message( "endpoint" + endpoint );

            Map<String, String> headers = new HashMap<String, String>();

            // headers
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + apiDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
            headers.put( UserConstants.USERID, staffId );
            headers.put( UserConstants.ORGID, orgId );

            // Body

            // Input Params
            HashMap<String, String> params = new HashMap<>();
            response = RestHttpClientUtil.POST( smUrl, headers, params, endpoint, body );
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
        return response;
    }

    /**
     * <<<<<<< HEAD Create Multi Org Students
     * 
     * @param orgIds
     * @param student username
     * @return
     * @throws Exception
     */
    public String createMultiOrgStudent( List<String> orgIds, String studentName ) throws Exception {
        return createStudentAndResetPassword( new SMAPIProcessor().formatListForJSON( orgIds ), studentName );

    }

    /**
     * Create shared student present in two two teachers group
     * 
     * @param studentName
     * @param teacherId1
     * @param accessCodeOfT1
     * @param teacherId2
     * @param accessCodeOfT2
     * @param orgId
     * @return
     */
    public String createSharedStudent( String studentName, String teacherId1, String accessCodeOfT1, String teacherId2, String accessCodeOfT2, String orgId ) {

        String classId1 = null;
        String classId2 = null;
        try {
            String studentId = new UserAPI().createMultiOrgStudent( Arrays.asList( orgId ), studentName );
            classId1 = new GroupAPI().createGroupWithCustomization( "Shared student Group with Teacher 1 ", teacherId1, Arrays.asList( studentId ), orgId, accessCodeOfT1 );
            classId2 = new GroupAPI().createGroupWithCustomization( "Shared student Group with Teacher 2 ", teacherId2, Arrays.asList( studentId ), orgId, accessCodeOfT2 );

            if ( classId1 != null && classId2 != null ) {
                return studentId;
            } else {
                Log.failsoft( "Error in Creating Shared Student" );
                return null;
            }
        } catch ( Exception e ) {
            return null;
        }

    }

    /**
     * Create Student and and reset password to get access token
     * 
     * @param orgId
     * @param studentName
     * @return
     * @throws Exception
     */
    public String createStudentAndResetPassword( String orgId, String studentName ) throws Exception {
        HashMap<String, String> userDetails = new HashMap<>();
        String secondOrgTeacher = studentName;
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, secondOrgTeacher );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgId );
        String teacherdetails = new RBSUtils().createUser( userDetails );
        String teacherID = SMUtils.getKeyValueFromResponse( teacherdetails, RBSDataSetupConstants.USERID );
        new RBSUtils().resetPassword( orgId, RBSDataSetupConstants.DEFAULT_PASSWORD, teacherID );
        return teacherID;
    }

    /**
     * 
     * @param envUrl
     * @param teacherDetails
     * @param scenario
     * 
     * @return
     * @throws Exception
     */

    public HashMap<String, String> returnStudentListNotPartOfCourse( String envUrl, HashMap<String, String> teacherDetails, String scenario ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        String orgID = teacherDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = teacherDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String courseID = teacherDetails.get( AssignmentAPIConstants.COURSE_ID );

        // Headers
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.USERID_SM_HEADER, teacherID );
        headers.put( Constants.ORGID_SM_HEADER, orgID );
        headers.put( Constants.AUTHORIZATION, "Bearer " + teacherDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        //Endpoints
        String endPoint = UserAPIEndPoints.RETURN_STUDENT_ENDPOINT;
        if ( scenario.equals( UserConstants.VALID ) ) {
            endPoint = endPoint.replace( Constants.ORG_ID, orgID );
            endPoint = endPoint.replace( Constants.USER_ID_VALUE, teacherID );
            endPoint = endPoint.replace( Constants.COURSE_ID, courseID );
        } else if ( scenario.equals( UserConstants.INVALID_ORG_ID ) ) {
            endPoint = endPoint.replace( Constants.ORG_ID, "23564" );
            endPoint = endPoint.replace( Constants.USER_ID_VALUE, teacherID );
            endPoint = endPoint.replace( Constants.COURSE_ID, courseID );
        } else if ( scenario.equals( UserConstants.INVALID_TEACHER_ID ) ) {
            endPoint = endPoint.replace( Constants.ORG_ID, orgID );
            endPoint = endPoint.replace( Constants.USER_ID_VALUE, teacherID + "#$" );
            endPoint = endPoint.replace( Constants.COURSE_ID, courseID );
        } else if ( scenario.equals( UserConstants.INVALID_COURSE_ID ) ) {
            endPoint = endPoint.replace( Constants.ORG_ID, orgID );
            endPoint = endPoint.replace( Constants.USER_ID_VALUE, teacherID );
            endPoint = endPoint.replace( Constants.COURSE_ID, courseID + "$#%gfst" );
        }

        HashMap<String, String> response = RestHttpClientUtil.GET( envUrl, endPoint, headers, params );
        return response;

    }

    /**
     * Create Multi Org Teacher
     * 
     * @param orgIds
     * @param TeacherName
     * @return
     * @throws Exception
     */
    public String createMultiOrgTeacher( List<String> orgIds, String TeacherName ) throws Exception {
        try {
            return createTeacherAndResetPassword( new SMAPIProcessor().formatListForJSON( orgIds ), TeacherName );

        } catch ( Exception e ) {
            return null;
        }

    }

    /**
     * To create a user with custom values
     * 
     * @param userName
     * @param Role
     * @param orgIds
     * @return
     */
    public String createUserWithCustomization( String userName, String Role, List<String> orgIds ) {
        HashMap<String, String> userDetails = new HashMap<>();
        try {
            String secondOrgTeacher = userName;
            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
            userDetails.put( RBSDataSetupConstants.USERNAME, secondOrgTeacher );
            userDetails.put( RBSDataSetupConstants.ROLE, Role );
            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, new SMAPIProcessor().formatListForJSON( orgIds ) );
            userDetails.put( RBSDataSetupConstants.EMAIL, UserConstants.SPCL_CHARACTER_USER_EMAIL_ID );

            String teacherdetails = new RBSUtils().createUser( userDetails );
            String teacherID = SMUtils.getKeyValueFromResponse( teacherdetails, RBSDataSetupConstants.USERID );
            new RBSUtils().resetPassword( new SMAPIProcessor().formatListForJSON( orgIds ), RBSDataSetupConstants.DEFAULT_PASSWORD, teacherID );
            return teacherdetails;
        } catch ( Exception e ) {
            return null;
        }
    }

    /**
     * return studentId's of School given
     * 
     * @param orgUsed
     * @return
     */
    public ArrayList<String> getStudentIds( String orgUsed ) {
        ArrayList<String> studentRumbaIds = new ArrayList<String>();
        IntStream.rangeClosed( 1, Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) ) ).forEach( index -> {
            studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student" + index ), StudentDetailsForGivenTeacherConstants.userId_TEXT ) );
        } );
        return studentRumbaIds;
    }

    /**
     * return student UserNames 's of School given
     * 
     * @param orgUsed
     * @return
     */
    public ArrayList<String> getStudentUNs( String orgUsed ) {
        ArrayList<String> studentRumbaIds = new ArrayList<String>();
        IntStream.rangeClosed( 1, Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) ) ).forEach( index -> {
            studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student" + index ), UpdateStudentProfileConstants.USERNAME_REQBODY ) );
        } );
        return studentRumbaIds;
    }

    /**
     * Create teacher and and reset password to get access token
     * 
     * @param orgId
     * @return
     * @throws Exception
     */
    public String createTeacherAndResetPassword( String orgId, String teacherName ) throws Exception {
        HashMap<String, String> userDetails = new HashMap<>();
        try {
            String secondOrgTeacher = teacherName;
            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
            userDetails.put( RBSDataSetupConstants.USERNAME, secondOrgTeacher );
            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgId );
            String teacherdetails = new RBSUtils().createUser( userDetails );
            String teacherID = SMUtils.getKeyValueFromResponse( teacherdetails, RBSDataSetupConstants.USERID );
            new RBSUtils().resetPassword( orgId, RBSDataSetupConstants.DEFAULT_PASSWORD, teacherID );
            return teacherID;
        } catch ( Exception e ) {
            return null;
        }

    }

    /**
     * To get the user details Using User Service
     * 
     * @param userId
     * @param orgId
     * @param accessToken
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getUserDetailByUserService( String userId, String orgId, String accessToken ) throws Exception {
        HashMap<String, String> response = null;
        try {
            // Endpoint
            String endPoint = UserAPIEndPoints.GET_USER_DETAILS;
            endPoint = endPoint.replace( UserConstants.USERID, userId );

            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
            headers.put( UserConstants.ORGID, orgId );
            headers.put( UserConstants.USERID, userId );

            // InputParams
            HashMap<String, String> params = new HashMap<>();

            Log.message( "Making GET Call to return user details using User Service API - " + configProperty.getProperty( "SMAppUrl" ) + endPoint );

            response = RestHttpClientUtil.GET( configProperty.getProperty( "SMAppUrl" ), endPoint, headers, params );
            return response;

        } catch ( Exception e ) {
            Log.failsoft( "Issues with API Get User Detail By UserService" );
            return null;

        }
    }

    /**
     * To get the Student Details from the student id
     * 
     * @param studentId
     * @param teacherId
     * @param orgId
     * @param accessToken
     * @return
     */
    public HashMap<String, String> getStudentDetailsByStudentId( String studentId, String teacherId, String orgId, String accessToken ) {

        // Endpoints
        String endPoint = UserAPIEndPoints.GET_STUDENT_DETAILS;
        endPoint = endPoint.replace( UserConstants.STUDENT_ID_FIELD, studentId );

        // InputParams
        HashMap<String, String> params = new HashMap<>();

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
        headers.put( UserConstants.USERID, teacherId );
        headers.put( UserConstants.ORGID, orgId );

        // Response
        try {
            return RestHttpClientUtil.GET( configProperty.getProperty( ConfigConstants.SM_APP_URL ), endPoint, headers, params );
        } catch ( Exception e ) {
            return null;
        }
    }

    /**
     * To Get the student usage Details
     * 
     * @param smUrl
     * @param headers
     * @param staffId
     * @param orgId
     * @param assignmentIds
     * @param StudentId
     * @param groupId
     * 
     * @return
     * @throws Exception
     */
    public Map<String, String> getStudentUsage( String smUrl, Map<String, String> headers, String staffId, String orgId, List<String> assignmentIds, String studentId, String groupId ) throws Exception {
        HashMap<String, String> response = null;

        try {

            // Input Params
            HashMap<String, String> params = new HashMap<>();

            String body = "{}";
            if ( !Objects.isNull( studentId ) && !studentId.isEmpty() ) {
                params.put( StudentUsage.STUDENTID, studentId );
            } else if ( !Objects.isNull( groupId ) && !groupId.isEmpty() ) {
                params.put( StudentUsage.GROUPID, groupId );
            } else {
                body = "{" + "\"" + StudentUsage.ASSIGNMENTIDS + "\":" + assignmentIds.toString() + "}";
            }

            String endpoint = StudentUsage.POST_STUDENTUSAGE;
            endpoint = endpoint.replace( "{" + Constants.STAFF_ID_VALUE + "}", staffId );
            endpoint = endpoint.replace( "{" + Constants.ORGANIZATION_ID + "}", orgId );

            //Hitting Post call for student usage
            response = RestHttpClientUtil.POST( smUrl, headers, params, endpoint, body );
            Log.message( "The response is : " + response.toString() );
            return response;

        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }

    }

    /**
     * To Get Demographics for Organization
     * 
     * @param smUrl
     * @param userDetails
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getDemographics( String smUrl, HashMap<String, String> userDetails ) throws Exception {
        HashMap<String, String> response = null;
        try {

            // InputParams
            HashMap<String, String> params = new HashMap<>();

            // headers
            HashMap<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + userDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
            headers.put( Constants.USERID_SM_HEADER, userDetails.get( UserConstants.USERID ) );
            headers.put( Constants.ORGID_SM_HEADER, userDetails.get( UserConstants.ORGID ) );
            // Endpoints
            String endPoint = getDemographicsConstants.endpoint;

            //Hitting GET Call
            response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
            Log.message( "The response is : " + response.toString() );
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
        return response;
    }

    /**
     * To get the Students from the whole org using solar search
     * 
     * @param apiDetails
     * @param userDetails
     * 
     * @return
     */

    public Map<String, String> studentSearchUsingSolar( String smUrl, HashMap<String, String> apiDetails, HashMap<String, String> userDetails ) throws Exception {
        HashMap<String, String> response = null;
        String body;
        try {
            // Headers
            HashMap<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + apiDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
            headers.put( Constants.USERID_SM_HEADER, apiDetails.get( UserConstants.USERID ) );
            headers.put( Constants.ORGID_SM_HEADER, apiDetails.get( UserConstants.ORGID ) );

            // Input Params
            HashMap<String, String> params = new HashMap<>();

            String endpoint = StudentSearchUsingSolar.STUDENT_SOLAR_SEARCH;

            body = SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.STUDENT_SOLAR_SEARCH );

            Iterator iterator = userDetails.entrySet().iterator();
            while ( iterator.hasNext() ) {
                Map.Entry pair = (Map.Entry) iterator.next();
                body = new RBSUtils().generateRequestBodyString( body, pair.getKey().toString(), pair.getValue().toString() );
                iterator.remove();
            }

            //Hitting Post call for Student Search Using Solar
            response = RestHttpClientUtil.POST( smUrl, headers, params, endpoint, body );

            Log.message( "The response is : " + response.toString() );
            return response;

        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }

    }
}
