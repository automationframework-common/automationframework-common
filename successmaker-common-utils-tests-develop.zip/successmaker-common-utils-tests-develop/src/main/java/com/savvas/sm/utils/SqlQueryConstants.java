package com.savvas.sm.utils;

public interface SqlQueryConstants {

    /**
     * Mastery Sql constants
     */
    public interface Mastery {

        /**
         * Table - standard_version
         */
        public String QUERY_TO_GET_STANDARDS = "SELECT * FROM successmaker.standard_version";
        public String QUERY_TO_GET_STANDARDS_BY_MATH = "SELECT * FROM successmaker.standard_version WHERE pcs_subject_id=1";
        public String QUERY_TO_GET_STANDARDS_BY_READING = "SELECT * FROM successmaker.standard_version WHERE pcs_subject_id=4";
    }

}
