package com.savvas.sm.utils.constants;


public interface CommonAPIConstants {

    String STATUS_CODE_CREATED = "201";
    String STATUS_CODE_OK = "200";
    String STATUS_CODE_BAD_REQUEST = "400";
    String STATUS_CODE_FORBIDDAN = "403";
    String STATUS_CODE_UNAUTHORIZED = "401";
    String STATUS_CODE_NOTFOUND = "404";

    String STATUS_STRING = "status";
    String SUCCESS_STRING = "Success";
    String BODY = "body";
    String DATA = "data";

    //Exceptions
    public static String BUSINESS_RULE_VIOLATION = "com.savvas.core.exceptions.BusinessRuleViolationException";
    public static String MISMATCH_SERVLET_EXCEPTION = "org.springframework.web.bind.MissingServletRequestParameterException";
    public static String AUTHENTICATION_EXCEPTION = "java.lang.Exception";
    public static String FORBIDDAN_EXCEPTION = "org.springframework.security.access.AccessDeniedException";
    public static String BAD_REQUEST_EXCEPTION = "org.springframework.web.client.HttpClientErrorException$BadRequest";
    public static String DATA_NOT_FOUND_EXCEPTION = "com.savvas.core.exceptions.DataNotFoundException";
    public static String NO_CMS_CLASS_EXCEPTION = "org.springframework.web.client.HttpClientErrorException$NotFound";
    public String METHOD_ARGUMENT_TYPE_MISMATCH = "org.springframework.web.method.annotation.MethodArgumentTypeMismatchException";
    public String NULL_POINTER_EXCEPTION = "java.lang.NullPointerException";

    public String ACCESS_DENIED_EXCEPTION = "org.springframework.security.access.AccessDeniedException";
    public String JAVA_LANG_EXCEPTION = "java.lang.Exception";
    public String MESSAGE_NOT_READABLE_EXCEPTION = "org.springframework.http.converter.HttpMessageNotReadableException";

    public static String METHOD_EXCEPTION = "org.springframework.web.HttpRequestMethodNotSupportedException";
    public static String BAD_REQUEST_EXCEPTION_METHOD = "org.springframework.web.method.annotation.MethodArgumentTypeMismatchException";
    public static String NULL_EXCEPTION = "org.springframework.web.bind.MissingPathVariableException";

    public String HTTP_MESSAGE_NOTREADABLE_EXCEPTION = "org.springframework.http.converter.HttpMessageNotReadableException";

    public String VALIDATION_EXCEPTION = "com.pst.exceptions.ValidationException";
    public String NOTFOUND_EXCEPTION = "org.springframework.web.client.HttpClientErrorException$NotFound";
    public String NUMBER_FORMAT_EXCEPTION = "java.lang.NumberFormatException";

    //messages
    public static String INVALID_AUTHENTICATION_MESSAGE = "Authentication Failed";
    public static String FORBIDDAN_MESSAGE = "Access is denied";
    public static String EMPTY_END_DATE ="For usage goals update, target goal end date cannot be null or blank or invalid";
    //Constants
    public String FLEX_LICENSE_SCHOOL = "flexLicensesSchool";
    public String MATH_LICENSE_SCHOOL = "mathLicensesSchool";
    public String READING_LICENSE_SCHOOL = "redaingLicensesSchool";
    public String FOCUS_MATH_LICENSE_SCHOOL = "focusMathLicensesSchool";
    public String FOCUS_READING_LICENSE_SCHOOL = "focusReadingLicensesSchool";
    public String ADD_PRODUCT = "addProductToClassGraphQL.json";
    public String BODY_FIELD = "body";
    String CHILD_ORGANIZATION_FROM_ORGSERVICE = "/org-service/v1/organizations/{organizationId}/childtree";
    String GET_CLASS_CMS = "/roster-service/v1/sections/%s";
    String GET_GROUP_LIST_CMS = "/cms/v1/students/%s/sections";
    String ROSTER_DELETE_STUDENT_FROM_SECTION = "/v2/sections/{sectionId}/students";
    String DELETE_CLASS_CMS = "/roster-service/v2/sections/%s";

    String CMS_ADMIN_USERNAME = "absavvasadmin";
    String CMS_ADMIN_PASSWORD = "password1";

    public static Integer LICENSE_COUNT = 500;
    String MATH = "Math";
    String READING = "Reading";
    String FLEX = "Flex";
    String MATH_FOCUS = "MathFocus";
    String READING_FOCUS = "ReadingFocus";
    String TEACHER = "Teacher";
    String ADMIN = "Admin";

    //MATH_PRODUCT is refers Math and focus product together
    String MATH_PRODUCT = "mathOnlyProduct";

    //READING_PRODUCT is refers Reading and focus product together
    String READING_PRODUCT = "readingOnlyProduct";

    //Only Focus products
    String MATH_FOCUS_ONLY_PRODUCT = "mathFocusOnlyProduct";
    String READING_FOCUS_ONLY_PRODUCT = "readingFocusOnlyProduct";

    //Flexible license
    String FLEX_PRODUCT = "flexProduct";

    /**
     * This enum is used to get the payload folder with respective functionality
     * 
     * @author ajith.mohan
     *
     */
    public enum PayloadFor {
        ADMIN,
        TEACHER,
        STUDENT,
        RBS
    }

    /**
     * This enum is used to get the DBQ
     * 
     *
     */
    public enum DBQueryFor {
        ADMIN,
        TEACHER,
        COMMON
    }
}
