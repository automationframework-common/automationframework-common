package com.savvas.sm.utils.sme187.teacher.api.reports;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.learningservices.utils.EnvironmentPropertiesReader;

public class ReportConstants {

    public interface ReportAdminConstants {
        public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
        String REPORT_BFF = configProperty.getProperty( "AdminReportBFF" );
        String STUDENT_BFF = configProperty.getProperty( "StudentDashboardBff" );
        String AFG_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getAFGAdminReportData(\\n    filterParams: {subject: \\\"{subject}\\\", courseList: [\\\"{courses}\\\"], additionalGrouping: {additionalGrouping}, datesAtRisk: {dateAtRisk} , filterBySchool: [\\\"{orgId}\\\"], filterByTeacher: [\\\"{teachers}\\\"], filterByGroup: [\\\"{groups}\\\"], filterByGrade: [\\\"{grade}\\\"], filterByDemographics: {disabilityStatus: [\\\"{disabilityStatus}\\\"], englishLanguageProficiency: [\\\"{language}\\\"], gender: [\\\"{gender}\\\"], migrantStatus: [\\\"{migrantStatus}\\\"], race: [\\\"{race}\\\"], ethnicity: [\\\"{ethnicity}\\\"], socioeconomicStatus: [\\\"{socioStatus}\\\"], specialServices: [\\\"{specialServices}\\\"]}}\\n    userId: \\\"%s\\\"\\n    organizationId: \\\"%s\\\"\\n  ) {\\n    reportRun\\n    orgRows {\\n      organizationName\\n      teacherTitle\\n      teacherFirstName\\n      teacherLastName\\n      teacherName\\n      teacherUsername\\n      grade\\n      gradeDisplayOrder\\n      groupName\\n      groupID\\n      assignmentTitle\\n      assignmentID\\n      strandSkillRows {\\n        strandName\\n        strandLevel\\n        catalogNum\\n        objectiveID\\n        loDescription\\n        lessonNumber\\n        lessonTitle\\n        studentRows {\\n          username\\n          studentName\\n          studentFirstName\\n          studentLastName\\n          studentId\\n          personID\\n          failedDate\\n          masteryStatus\\n        }\\n      }\\n    }\\n  }\\n}\\n\"}";
        String SEU_REPORT_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getSEUAdminReportData( userId: \\\"%s\\\"\\n    organizationId: \\\"%s\\\"\\n filterParams: { filterBySchool: [\\\"%s\\\"], subject: \\\"%s\\\", additionalGrouping: {additionalGroupId}, filterByGroup: [{groupId}], filterByGrade: [{grade}], filterByTeacher: [{teacherId}], filterByDemographics: {disabilityStatus: [{disabilityStatus}], englishLanguageProficiency: [{language}], gender: [{gender}], migrantStatus: [{migrantStatus}], race: [{race}], ethnicity: [{ethnicity}], socioeconomicStatus: [{socioStatus}], specialServices: [{specialServices}]}}\\n ) {\\n reportRun\\n subject\\n organizationName\\n organizationId\\n teacherName\\n teacherId\\n teacherTitle\\n teacherFirstName\\n teacherLastName\\n teacherUserName\\n grade\\n groupName\\n groupId\\n students {\\n personId\\n studentName\\n studentFirstName\\n studentLastName\\n studentUsername\\n studentID\\n sumDefaultMathTime\\n sumDefaultMathSessions\\n sumDefaultReadingTime\\n sumDefaultReadingSessions\\n sumCustomTotalTime\\n sumCustomTotalSessions\\n sumTotalTime\\n sumTotalSessions\\n avgTotalTimePerSession\\n maxLastSessionDate\\n customAssignedCount\\n defaultMathRunCount\\n defaultReadingRunCount\\n customMathRunCount\\n customReadingRunCount\\n defaultMathAssignedCount\\n defaultReadingAssignedCount\\n }\\n  }\\n}\\n\"}";

        String SUBJECT = "{subject}";
        String COURSES = "{courses}";
        String ADDITIONAL_GROUPING = "{additionalGrouping}";
        String DATE_AT_RISK = "{dateAtRisk}";
        String ORG_ID = "{orgId}";
        String Grade = "{grade}";
        List<String> AFG_FILTERS = Arrays.asList( "{subject}", "{courses}", "{additionalGrouping}", "{dateAtRisk}", "{orgId}", "{grade}", "{teachers}", "{groups}", "{disabilityStatus}", "{language}", "{gender}", "{migrantStatus}", "{race}", "{ethnicity}",
                "{socioStatus}", "{specialServices}" );
    }

    public interface ReportFilters {
        public static String SCHOOL_ID_VALUE = "{schoolId}";
        public static String USER_ID_VALUE = "{userId}";
        public static String DISTRICT_ID_VALUE = "{districtId}";
        public static String ADDITIONAL_GROUP_ID_VALUE = "{additionalGroupId}";
        public static String TEACHER_ID_VALUE = "{teacherId}";
        public static String GROUP_ID_VALUE = "{groupId}";
        public static String GRADE_ID_VALUE = "{grade}";
        public static String ASSIGNMENT_ID = "{assignmentId}";
    }

    public interface DemographicFilters {
        String DISABILITY_STATUS = "{disabilityStatus}";
        String ENGLISH_PROFICIENCY = "{language}";
        String GENDER = "{gender}";
        String MIGRANT_STATUS = "{migrantStatus}";
        String RACE = "{race}";
        String ETHNICITY = "{ethnicity}";
        String SOCIO_STATUS = "{socioStatus}";
        String SPECIAL_SERVICES = "{specialServices}";
    }

    public interface DemographicValues {
        String NOT_SPECIFIED = "NOT_SPECIFIED";
        ArrayList<String> RACE = new ArrayList<String>( Arrays.asList( "WHITE", "BLACK_OR_AFRICAN_AMERICAN", "ASIAN", "AMERICAN_NATIVE_OR_ALASKAN_NATIVE", "NATIVE_HAWAIIAN_OR_PACIFIC_ISLANDER", "UNKNOWN", "NOT_SPECIFIED" ) );
        ArrayList<String> ETHNICITY = new ArrayList<String>( Arrays.asList( "HISPANIC_OR_LATINO", "NOT_HISPANIC_OR_LATINO", "NOT_SPECIFIED" ) );
        ArrayList<String> SPECIAL_SERVICES = new ArrayList<String>( Arrays.asList( "PLAN_504", "GIFTED_TALENTED", "IEP", "OTHER", "NO_SPECIAL_SERVICES", "NOT_SPECIFIED" ) );
        ArrayList<String> DISABILITY_STATUS = new ArrayList<String>( Arrays.asList( "YES", "NO", "NOT_SPECIFIED" ) );
        ArrayList<String> GENDER = new ArrayList<String>( Arrays.asList( "MALE", "FEMALE" ) );
        ArrayList<String> SOCIOECONOMIC_STATUS = new ArrayList<String>( Arrays.asList( "ECONOMICALLY_DISADVANTAGED", "NOT_ECONOMICALLY_DISADVANTAGED", "NOT_SPECIFIED" ) );
        ArrayList<String> ENGLISH_LANGUAGE = new ArrayList<String>( Arrays.asList( "ENGLISH", "ENGLISH_LANGUAGE_LEARNER", "NOT_SPECIFIED" ) );
        ArrayList<String> MIGRANT_STATUS = new ArrayList<String>( Arrays.asList( "MIGRANT", "NON_MIGRANT", "NOT_SPECIFIED" ) );
    }

}
