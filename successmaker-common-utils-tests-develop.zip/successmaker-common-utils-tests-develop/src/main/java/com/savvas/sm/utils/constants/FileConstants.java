package com.savvas.sm.utils.constants;

public interface FileConstants {
    String ADD_STUDENT_SECTION_PAYLOAD = "addStudentintoSection.json";
    String DELETE_STUDENT_SECTION_PAYLOAD = "deleteStudentFromSection.json";
    String CREATE_GRP_PAYLOAD_NAME2 = "createGroupAPIPayload2.json";
    String CREATE_USER_BY_USERSERVICE = "createUserByUserService.json";
    String UPDATE_USER_BY_USERSERVICE = "updateUserByUserService.json";
    String ADD_STUDENT_TO_GROUP_PAYLOAD = "addStudentToGroupPayload.json";
    String CREATE_GROUP_PAYLOAD = "createGroupAPIPayload.json";
    String GROUP_USAGE_PAYLOAD = "groupUsagePayload.json";

    String UPDATE_STAFF_PROFILE = "updateStaffProfilePayload.json";
    String UPDATE_STUDENT_PROFILE = "updateStudentProfilePayload.json";
    String CREATE_STUDENT_PAYLOAD = "createStudentPayload.json";
    String UPDATE_USER_ORG_PAYLOAD = "updateOrganizationlForUser.xml";

    String RBS_PAYLOAD_FOLDER = "payload/RbsPayload/";
    String ADMIN_PAYLOAD_FOLDER = "payload/AdminPayload/";
    String TEACHER_PAYLOAD_FOLDER = "payload/TeacherPayload/";
    String STUDENT_PAYLOAD_FOLDER = "payload/StudentPayload/";

    String ADMIN_DBQUERIES_FOLDER = "dbQueries/Admin/";
    String TEACHER_DBQUERIES_FOLDER = "dbQueries/Teacher/";
    String COMMON_DBQUERIES_FOLDER = "dbQueries/Common/";

    //Assignments Payload
    String ASSIGN_ASSIGNMENT_PAYLOAD = "createAssignmentPayload.json";
    String PAUSE_RESUME_PAYLOAD = "assignmentPauseResumePayload.json";
    String ASSIGN_MULTIPLE_ASSIGNMENT_PAYLOAD = "assignMultipleAssignmentPayload.json";
    String MATH_UPDATE_USERSETTINGS = "UpdateAssignmentUserSettingsForMathCourse.json";
    String READING_UPDATE_USERSETTINGS = "UpdateAssignmentUserSettingsForReadingCourse.json";
    String ASSIGNMENTS_BY_SUBJECT_PAYLOAD = "getAssignmentBySubjectID.json";

    //Courses Payload
    String CUSTOM_BY_STANDARDS_MATH = "customByStandardsRandom_MATH.json";
    String CUSTOM_BY_STANDARDS_FOCUS_MATH_THREE = "customByStandardsRandom_FOCUS_MATH_THREE.json";
    String CUSTOM_BY_STANDARDS_FOCUS_READING_FIFTEEN = "customByStandardsRandom_FOCUS_READING_FIFTEEN.json";
    String CUSTOM_BY_STANDARDS_READING = "customByStandardsRandom_READING.json";
    String CUSTOM_BY_STANDARDS_MATH_INVALID = "customByStandardsRandom_MATH_INVALID.json";
    String CUSTOM_BY_SETTING_GENERIC_MATH = "customBySettings_MATH.json";
    String CUSTOM_BY_SETTING_GENERIC_READING = "customBySettings_READING.json";
    String CUSTOM_BY_SKILLS_GENERIC_MATH = "customBySkills_MATH.json";
    String CUSTOM_BY_SKILLS_GENERIC_READING = "customBySkills_READING.json";
    String CUSTOM_BY_SKILLS_DYNAMIC_READING = "customBySkills_READING_DynamicSCO.json";
    String CUSTOM_BY_SETTING_SHARED_MATH = "customBySettingsShared_MATH.json";
    String CUSTOM_BY_SETTING_SHARED_READING = "customBySettingsShared_READING.json";
    String CUSTOM_BY_SKILLS_SHARED_MATH = "customBySkillsShared_MATH.json";
    String CUSTOM_BY_SKILLS_SHARED_READING = "customBySkillsShared_READING.json";
    String CUSTOM_BY_STANDARDS_SHARED_MATH = "customByStandardsRandomShared_MATH.json";
    String CUSTOM_BY_STANDARDS_SHARED_READING = "customByStandardsRandomShared_READING.json";
    String CUSTOM_BY_SKILLS_SINGLE_LO_MATH = "MathSingleLoSkillCourse.json";
    String CUSTOM_BY_SKILLS_SINGLE_LO_READ = "ReadSingleLoSkillCourse.json";

    String UPDATE_USER_BY_USERSERVICE_DEMO = "updateUserwithDemographics.json";
    String SINGLE_TEACHER_JSON = "singleTeacher.json";
    String SINGLE_STUDENT_JSON = "singleStudent.json";
    String CREATE_CLASS_PAYLOAD2 = "createClassPayload2.json";
    String UPDATE_GRADE = "updateStudentGrade.json";
    String STUDENT_SOLAR_SEARCH = "StudentSearchUsingSolarPayLoad.json";
    String USAGE_GOALS_STUDENT_LIST = "UsageGoalsStudentList.json";

    String GET_ALL_STUDENTS_FROM_ORG = "getAllUserFromOrg.xml";
    String CREATE_ORG_SETTING = "createOrgSettings.json";
    String PERFORMANCE_REPORT_QUERY = "getPerformanceReportDetails.sql";
    String CUSTOM_BY_SETTING_GENERIC_MATH_IPM_ON = "customBySettingsIpmOnMath.json";
    String CUSTOM_BY_SETTING_GENERIC_READING_IPM_ON = "customBySettingsIpmOnReading.json";
    String AFG_REPORT_MATH = "AFGReportMath.sql";
    String AFG_REPORT_READING = "AFGReportReading.sql";
    String GET_SESSION_THIS_WEEK_USAGE = "getSessionThisWeekUsage.json";
    String SESSION_THIS_WEEK_USAGE_BFFF = "sessionThisWeekUsageBFFPayload.json";

}
