package com.savvas.sm.utils.sme187.teacher.api.assignment;

import java.util.HashMap;

public interface AssignmentAPIConstants {

    //End Points
    public static String CREATE_ASSIGNMENT_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/courses/{courseID}/assign";
    public static String GET_ASSIGNMENTS_LIST = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/assignments";
    public static String GET_RECENT_ASSIGNMENTS_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/assignments/home";
    public static String GET_ASSIGNMENT_SETTINGS_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/courses/{courseID}/settings";
    public static String PAUSE_RESUME_ASSIGNMENT_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/assignmentusers/{AssignmentUserId}/status";
    public static String GET_ASSIGNMENT_VIEW = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/courseassignments/{contentbaseId}/students";

    public static String GET_ASSIGNMENTS_BY_SUBJECTID_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/assignments/assigned";

    public static String GET_GROUP_ASSIGNMENTS_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/groups/{groupID}/assignments";

    public static String DELETE_ASSIGNMENT_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/courseassignments/{contentbaseId}";

    public static String PAUSE_RESUME_ASSIGNMENT_ALL_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/courseassignments/{contentbaseId}/status";
    public static String ASSIGN_MULTIPLE_ASSIGNMENTS_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/courses/assign";
    public static String DELETE_ASSIGNMENT_GROUP_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/groups/{groupID}/courseassignments/{contentbaseId}";
    public static String REMOVE_STUDENT_FROM_ASSIGNMENT_API = "/lms/web/api/v1/assignmentusers/{assignmentUserID}";
    public static String PAUSE_RESUME_GROUPASSIGNMENT_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/groups/{groupID}/courseassignments/{contentbaseId}/status";
    public static String DELETE_STUDENT_ASSIGNMENT_API = "/lms/web/api/v1/assignmentusers/{assignmentUserID}";
    public static String UPDATE_ASSIGNMENT_USERSETTINGS_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/assignmentusers/{assignmentUserID}/settings";
    public static String GET_USER_ASSIGNMENT_SETTINGS_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/students/{studentId}/assignments/{assignmentId}/settings";
    public static String GET_STUDENT_ASSIGNMENT_DETAILS_BY_STUDENT_ID = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/students/{studentID}/assignments";
    public static String RESTORE_DELETED_ASSIGNMENTS = "/lms/web/api/v1/assignments/restore";
    public static String GET_ASSIGNMENTS_UNASSIGNED_STUDENTS = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/assignments/unassigned";
    public static String SCHOOL_MOTION_ON = "/lms/web/api/v1/organizations/settings/motionlogs";
    public static String GET_GROUP_ASSIGNMENT_SETTINGS_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/groups/{groupID}/courseassignments/{courseID}/settings";
    public static String PUT_GROUP_ASSIGNMENT_SETTINGS_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/groups/{groupID}/courseassignments/{courseID}/settings";
    public static String GROUP_ASSIGNMNETS_GROUP="/lms/web/api/v1/staffs/{teacherID}/groups/students/assignments/autoassign";
    public static String UPDATE_MATH_EXIT_DATA = "/lms/web/assignments/exitdata/math/{assignmentUserIDValue}";
    public static String ASSIGNMENT_SKILL_LEVEL = "/lms/web/assignments/k2ipm/skilllevel/";

    //Headers7
    public static String TEACHER_ID = "teacherID";
    public static String ORG_ID = "orgID";
    public static String STUDENT_RUMBA_IDS = "studentRumbaIds";
    public static String STUDENT_RUMBA_GRADE_IDS = "studentRumbaIds_Grades";
    public static String STATUS = "status";
    public static String GROUP_ID = "groupID";
    public static String TEACHER_ID_ENDPOINT = "teacherIDEndPoint";
    public static String ASSIGNMENT_IDS = "assignementIds";
    public static String COURSE_IDS = "courseIds";
    public static String STUDENT_ID = "studnetID";
    public static String AUTHORIZATION = "Authorization";

    //Attributes
    public static String USERS_TYPE = "users";
    public static String GROUPS_TYPE = "groups";
    public static String COURSE_ID = "courseID";
    public static String ASSIGNMENT_USER_ID = "assignmentUserID";
    public static String STATUS_ACTIVE = "ACTIVE";
    public static String STATUS_INACTIVE = "INACTIVE";
    public static String STATUS_INACTIVE_LCASE = "inactive";
    public static String REQUEST_BODY_TYPE = "{type}";
    public static String REQUEST_BODY_STUDENT_ID = "{studentRumbaIds}";
    public static String CAPTURE_RESEARCH_DATA = "captureResearchData";

    //CourseType and ID
    public static String DEFAULT_MATH = "1";
    public static String DEFAULT_READING = "2";
    public static String FOCUS_MATH_1 = "3";
    public static String FOCUS_MATH_2 = "4";
    public static String FOCUS_MATH_3 = "5";
    public static String FOCUS_READING_1 = "11";
    public static String INVALID_ASSIGMENT_ID = "$$";
    public static String NON_EXISTING_ASSIGMENT_ID = "65456475474575";
    public static String INVALID_STUDENT_ID = "ffffffff6241ac185f481b4ef9cebfb";

    //Course IDs
    public String MATH = "1";
    public String READING = "2";
    public String FOCUS_READING = "5";
    public String FOCUS_MATH = "3";

    // Default Course Name
    public String MATH_COURSE = "Math";
    public String READING_COURSE = "Reading";
    public String FOCUS = "FOCUS";
    public String STANDARD_COURSE = "STANDARD";
    public String SKILL_COURSE = "SKILL";
    public String SETTINGS_COURSE = "SETTINGS";
    public static String SCHOOL_ADMIN_ID = "schoolAdminId";

    //Response body
    public static String EXCEPTIONNULL = "null";
    public static String ERRORMESSAGESUCCEEDED = "Operation succeeded!";

    //Fields
    public static String BODY_FIELD = "body";

    //DB Constants

    public static String ASSIGNMENT_ID = "assignment_id";
    public static String CONTENT_BASE_ID = "content_base_id";
    public static String SUBJECT_ID = "subject_id";
    public static String SUBJECT_NAME = "subject_name";
    public static String ASSIGNMENT_NAME = "assignemnt_name";
    public static String PRODUCT_ID = "product_id";
    public static String STUDENT_COUNT = "student_count";
    public static String BUSINESS_VIOLATION_EXCEPTION = "exception:com.savvas.core.exceptions.BusinessRuleViolationException";

    public static String GROUP_ID_VALUE = "{groupIDValue}";
    public static String GROUP_NAME_VALUE = "{groupNameValue}";
    public static String DESC_VALUE = "{descValue}";
    public static String ORG_ID_VALUE = "{orgID}";
    public static String TEACHER_ID_VALUE = "{teacherID}";
    public static String CONTENT_BASE_ID_ENDPOINT = "{contentbaseId}";
    public String OWNER_ORG_ID = "ownerOrgId";

    //Enrollment options with default values (Math course) - Assignment User Settings 
    HashMap<String, String> DEFAULTMATHSSIGNMENTSETTINGS = new HashMap<String, String>() {
        {
            put( "SESSION_LENGTH", "6" );
            put( "IDLE_TIME", "5" );
            put( "PROGRESS_REPORT_LIMIT", "3" );
            put( "INITIAL_PLACEMENT", "TRUE" );
            put( "CALCULATOR", "FALSE" );
            put( "TRANSLATE", "FALSE" );
            put( "AVAILABLE_LANGUAGES", "SPANISH" );
            put( "DISPLAY_LO_INFORMATION", "TRUE" );
            put( "SCRATCHPAD", "TRUE" );
            put( "SHOW_ANSWER", "TRUE" );
            put( "SHOW_EXIT_BUTTON", "TRUE" );
            put( "SHARED_COURSES", "FALSE" );
            put( "SPEED_GAMES", "TRUE" );
            put( "SPEED_GAMES_TIME_PER_QUESTION", "2" );
            put( "SPEED_GAMES_TOTAL_TIME", "1" );
            put( "MANUALLY_SET_COURSE_LEVEL", "FALSE" );
            put( "MANUALLY_SET_COURSE_LEVEL_SLIDER", "0" );
            put( "LOW", "0" );
        }
    };

    //Enrollment options with default values (Reading course) - Assignment User Settings 
    HashMap<String, String> DEFAULTREADINGASSIGNMENTSETTINGS = new HashMap<String, String>() {
        {
            put( "SESSION_LENGTH", "6" );
            put( "IDLE_TIME", "5" );
            put( "PROGRESS_REPORT_LIMIT", "3" );
            put( "INITIAL_PLACEMENT", "TRUE" );
            put( "DISPLAY_LO_INFORMATION", "TRUE" );
            put( "HELP_ICON_ACTIVE", "TRUE" );
            put( "SHOW_EXIT_BUTTON", "TRUE" );
            put( "SPANISH_GLOS5SARY", "FALSE" );
            put( "GRAMMAR_STRAND", "FALSE" );
            put( "SUPPRESS_AUDIO", "FALSE" );
            put( "SHARED_COURSES", "FALSE" );
            put( "TRANSLATE", "FALSE" );
            put( "SHARED_COURSES", "FALSE" );
            put( "FLUENCY", "FALSE" );
            put( "FLUENCY_RECORDING_TIME", "5" );
            put( "MANUALLY_SET_COURSE_LEVEL", "FALSE" );
            put( "MANUALLY_SET_COURSE_LEVEL_SLIDER", "0" );
            put( "LOW", "0" );
        }
    };
}
