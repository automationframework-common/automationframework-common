package com.savvas.sm.utils;

import org.apache.commons.io.filefilter.WildcardFileFilter;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystem;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public class FileUtil {

    public static int runJar( String filePath, String optionStr ) {
        int exitValue = -1;
        try {
            System.out.println( "running Jar: java -jar \"" + filePath + "\" " + optionStr );
            Process pr = Runtime.getRuntime().exec( "java -jar \"" + filePath + "\" " + optionStr, null, new File( new File( filePath ).getParent() ) );
            pr.waitFor();
            exitValue = pr.exitValue();
        } catch ( IOException | InterruptedException e ) {
            e.printStackTrace();
            return exitValue;
        }
        return exitValue;
    }

    public static Process runJarPassThrough( String filePath ) {
        return runJarPassThrough( filePath, "" );
    }

    public static Process runJarPassThrough( String filePath, String optionStr ) {
        Process pr = null;
        try {
            System.out.println( "running Jar: java -jar \"" + filePath + "\" " + optionStr );
            pr = Runtime.getRuntime().exec( "java -jar \"" + filePath + "\" " + optionStr, null, new File( new File( filePath ).getParent() ) );
        } catch ( IOException e ) {
            e.printStackTrace();
        }
        return pr;
    }

    public static boolean downloadFile( String url, String pathToSave ) {
        URLConnection connection;
        try {
            connection = new URL( url ).openConnection();
            InputStream stream;
            try {
                stream = connection.getInputStream();
                BufferedInputStream in = new BufferedInputStream( stream );
                FileOutputStream file = new FileOutputStream( pathToSave );
                BufferedOutputStream out = new BufferedOutputStream( file );
                int i;
                while ( ( i = in.read() ) != -1 ) {
                    out.write( i );
                }
                out.flush();
                out.close();
            } catch ( IOException e ) {
                e.printStackTrace();
                return false;
            }

        } catch ( IOException e ) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static String readTextFile( String filename ) {
        return readTextFile( new File( filename ) );
    }

    public static String readTextFile( File file ) {
        StringBuffer contents = new StringBuffer();
        BufferedReader reader = null;
        try {
            /*
             * if(isRunningOnJar()){ //System.out.println("fileSource:"+new
             * FileUtil().getClass().getResourceAsStream(file.getPath().
             * replace("\\", "/"))); reader = new BufferedReader(new
             * InputStreamReader(new
             * FileUtil().getClass().getResourceAsStream(file.getPath().
             * replace("\\", "/")))); } else { reader = new BufferedReader(new
             * FileReader(file));
             * //System.out.println("fileSource:"+file.getAbsolutePath()); }
             */

            try {
                if ( isRunningOnJar() ) {
                    reader = new BufferedReader( new InputStreamReader( new FileUtil().getClass().getResourceAsStream( file.getPath().replace( "\\", "/" ) ) ) );
                } else {
                    reader = new BufferedReader( new FileReader( file ) );
                }
            } catch ( NullPointerException e ) {
                if ( isRunningOnJar() ) {
                    reader = new BufferedReader( new FileReader( file ) );
                } else {
                    e.printStackTrace();
                }
            }

            String text = null;
            // repeat until all lines is read
            while ( ( text = reader.readLine() ) != null ) {
                contents.append( text ).append( System.getProperty( "line.separator" ) );
            }
        } catch ( FileNotFoundException e ) {
            e.printStackTrace();
        } catch ( IOException e ) {
            e.printStackTrace();
        } finally {
            try {
                if ( reader != null ) {
                    reader.close();
                }
            } catch ( IOException e ) {
                e.printStackTrace();
            }
        }

        return contents.toString();
    }

    public static boolean writeTextFileln( String path, String file, String text ) {
        return writeTextFile( path, file, text + "\r\n", false );
    }

    public static boolean writeTextFileln( String path, String file, String text, boolean append ) {
        return writeTextFile( path, file, text + "\r\n", append );
    }

    public static boolean writeTextFile( String path, String file, String text ) {
        return writeTextFile( path, file, text, false );
    }

    public static boolean writeTextFile( String path, String file, String text, boolean append ) {
        OutputStreamWriter out;
        try {
            String workDir = new File( "." ).getAbsolutePath() + "/" + path;
            if ( !FileUtil.fileExists( workDir ) ) {
                FileUtil.mkdir( workDir );
            }

            out = new OutputStreamWriter( new FileOutputStream( workDir + "/" + file, append ), StandardCharsets.UTF_8 );
            out.append( text.trim() );

            out.flush();
            out.close();
        } catch ( IOException e ) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static boolean fileExists( String file ) {
        return new File( file ).isFile();
    }

    public static boolean deleteFile( String file ) {
        if ( fileExists( file ) ) {
            return new File( file ).delete();
        }
        return false;
    }

    public static boolean deleteDir( String dir ) {
        return deleteDir( new File( dir ) );
    }

    public static boolean deleteDir( File dir ) {
        if ( !dir.exists() )
            return true;
        if ( dir.isDirectory() ) {
            String[] children = dir.list();
            for ( int i = 0; i < children.length; i++ ) {
                boolean success = deleteDir( new File( dir, children[i] ) );
                if ( !success ) {
                    return false;
                }
            }
        }
        // The directory is now empty so delete it
        // System.out.println(dir.getAbsolutePath());
        return dir.delete();
    }

    public static void copyFile( String fromFileName, String toFileName ) throws IOException {
        boolean debug = false;
        File fromFile = new File( fromFileName );
        File toFile = new File( toFileName );
        if ( !fromFile.exists() )
            throw new IOException( "FileCopy: " + "no such source file: " + fromFileName );
        if ( !fromFile.isFile() )
            throw new IOException( "FileCopy: " + "can't copy directory: " + fromFileName );
        if ( !fromFile.canRead() )
            throw new IOException( "FileCopy: " + "source file is unreadable: " + fromFileName );

        if ( toFile.isDirectory() )
            toFile = new File( toFile, fromFile.getName() );

        if ( toFile.exists() ) {
            if ( !toFile.canWrite() )
                throw new IOException( "FileCopy: " + "destination file is unwriteable: " + toFileName );
            if ( debug )
                System.out.print( "Overwrite existing file " + toFile.getName() + "? (Y/N): " );
            if ( debug )
                System.out.flush();
            BufferedReader in = new BufferedReader( new InputStreamReader( System.in ) );
            String response = in.readLine();
            if ( !response.equals( "Y" ) && !response.equals( "y" ) )
                throw new IOException( "FileCopy: " + "existing file was not overwritten." );
        } else {
            String parent = toFile.getParent();
            if ( parent == null )
                parent = System.getProperty( "user.dir" );
            File dir = new File( parent );
            if ( !dir.exists() )
                throw new IOException( "FileCopy: " + "destination directory doesn't exist: " + parent );
            if ( dir.isFile() )
                throw new IOException( "FileCopy: " + "destination is not a directory: " + parent );
            if ( !dir.canWrite() )
                throw new IOException( "FileCopy: " + "destination directory is unwriteable: " + parent );
        }

        FileInputStream from = null;
        FileOutputStream to = null;
        try {
            from = new FileInputStream( fromFile );
            to = new FileOutputStream( toFile );
            byte[] buffer = new byte[4096];
            int bytesRead;

            while ( ( bytesRead = from.read( buffer ) ) != -1 )
                to.write( buffer, 0, bytesRead ); // write
        } finally {
            if ( from != null )
                try {
                    from.close();
                } catch ( IOException e ) {
                    ;
                }
            if ( to != null )
                try {
                    to.close();
                } catch ( IOException e ) {
                    ;
                }
        }
    }

    public static boolean mkdir( String dir ) {
        return new File( dir ).mkdirs();
    }

    public static File[] getFileList( String dir, String wildcard ) {
        return new File( dir ).listFiles( (FileFilter) new WildcardFileFilter( wildcard ) );
    }

    public static File[] getFileOrderedList( String dir, String wildcard, boolean orderByAsc ) {
        File[] orderedList = new File( dir ).listFiles( (FileFilter) new WildcardFileFilter( wildcard ) );
        if ( orderByAsc )
            Arrays.sort( orderedList );
        else
            Arrays.sort( orderedList, Collections.reverseOrder() );
        return orderedList;
    }

    public static boolean existsFile( String dir, String wildcard ) {
        File[] files = getFileList( dir, wildcard );
        return ( files != null && files.length > 0 ) ? true : false;
    }

    public static boolean existsFileWaitFor( String dir, String wildcard, int checktime, int timeout ) {
        return existsFileWaitFor( dir, wildcard, checktime, timeout, null );
    }

    public static boolean existsFileWaitFor( String dir, String wildcard, int checktime, int timeout, String msg ) {
        boolean found = true;
        long startTime = System.currentTimeMillis();
        while ( !existsFile( dir, wildcard ) ) {
            if ( System.currentTimeMillis() - startTime > ( timeout * 1000 ) ) {
                System.err.println( "FileNotFound in time: " + dir + "" + wildcard );
                found = false;
                break;
            }
            if ( msg != null )
                System.out.println( msg );
            try {
                Thread.sleep( checktime * 1000 );
            } catch ( InterruptedException e ) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                found = false;
            }
        }
        return found;
    }

    public static void waitFor( int secs ) {
        try {
            Thread.sleep( secs * 1000 );
        } catch ( InterruptedException e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public static void msg( String className, String msg ) {
        System.out.println( " [" + className + "/" + new SimpleDateFormat( "MMMdd HH:mm" ).format( new Date() ) + "] " + msg );
    }

    public static File[] getListOfFolders( String path ) {
        return getListOfFolders( path, null );
    }

    public static File[] getListOfFolders( String path, String filter ) {
        File folder = new File( path );
        File[] listOfFiles = folder.listFiles();
        ArrayList<File> folders = new ArrayList<File>();
        if ( listOfFiles instanceof File[] ) {
            for ( int i = 0; i < listOfFiles.length; i++ ) {
                if ( listOfFiles[i].isDirectory() ) {
                    if ( ( filter == null ) || ( filter != null && filter.length() > 0 && listOfFiles[i].getName().matches( filter ) ) ) {
                        folders.add( listOfFiles[i] );
                    }
                }
            }
        }
        return folders.toArray( new File[] {} );
    }

    public static String getJarPath() {
        String path = FileUtil.class.getProtectionDomain().getCodeSource().getLocation().getPath();
        try {
            return URLDecoder.decode( path, "UTF-8" );
        } catch ( UnsupportedEncodingException e ) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean isRunningOnJar() {
        String jarPath = getJarPath();
        return jarPath == null | jarPath.toLowerCase().contains( ".jar" );
    }

    public static boolean copyJarDirectoryToDirectory( String srcDir, String destDir ) {
        JarFile jf = null;
        try {
            if ( !srcDir.endsWith( "/" ) )
                srcDir += "/";
            jf = new JarFile( getJarPath() );
            Enumeration<JarEntry> entries = jf.entries();
            while ( entries.hasMoreElements() ) {
                JarEntry je = entries.nextElement();
                if ( je.getName().startsWith( srcDir ) ) {
                    System.out.println( je.getName() );
                }
            }
        } catch ( IOException ex ) {
            ex.printStackTrace();
        } finally {
            try {
                jf.close();
            } catch ( Exception e ) {}
        }
        return true;
    }

    // ##########################################################################
    public static String printDirectoryTree( File folder ) {
        if ( !folder.isDirectory() ) {
            throw new IllegalArgumentException( "folder is not a Directory" );
        }
        int indent = 0;
        StringBuilder sb = new StringBuilder();
        printDirectoryTree( folder, indent, sb );
        return sb.toString();
    }

    private static void printDirectoryTree( File folder, int indent, StringBuilder sb ) {
        if ( !folder.isDirectory() ) {
            throw new IllegalArgumentException( "folder is not a Directory" );
        }
        sb.append( getIndentString( indent ) );
        sb.append( "+--" );
        sb.append( folder.getName() );
        sb.append( "/" );
        sb.append( "\n" );
        for ( File file : folder.listFiles() ) {
            if ( file.isDirectory() ) {
                printDirectoryTree( file, indent + 1, sb );
            } else {
                printFile( file, indent + 1, sb );
            }
        }

    }

    private static void printFile( File file, int indent, StringBuilder sb ) {
        sb.append( getIndentString( indent ) );
        sb.append( "+--" );
        sb.append( file.getName() );
        sb.append( "\n" );
    }

    private static String getIndentString( int indent ) {
        StringBuilder sb = new StringBuilder();
        for ( int i = 0; i < indent; i++ ) {
            sb.append( "|  " );
        }
        return sb.toString();
    }

    public static String safeFilename( String name ) {
        return name.replaceAll( "[^a-zA-Z0-9_\\-\\.]", "_" );
    }

    /**
     * @param path
     * @param file
     * @returns bolean true if created Empty ZIP fle is created
     */
    public static boolean createEmptyZip( String path, String file ) {
        final byte[] EmptyZip = { 80, 75, 05, 06, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00 };
        try {
            String workDir = new File( "." ).getAbsolutePath() + "/" + path;
            if ( !FileUtil.fileExists( workDir ) ) {
                FileUtil.mkdir( workDir );
            }
            FileOutputStream fos = new FileOutputStream( new File( ( workDir + "/" + file ) ) );
            fos.write( EmptyZip, 0, 22 );
            fos.flush();
            fos.close();
        } catch ( IOException e ) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static String bulkReplace( String text, HashMap<String, String> map ) {
        if ( text != null ) {
            for ( String k : map.keySet() ) {
                while ( text.contains( k ) ) {
                    text = text.replace( k, map.get( k ) );
                }
            }
        }
        return text.trim();
    }

    public String getTestResource( String fileName ) {
        return FileUtil.readTextFile( fileName );
    }

    public static void modifyTextFileInZip( String zipPath, String txtToReplace, String replaceStr ) throws IOException {

        Path zipFilePath = Paths.get( zipPath );
        try (FileSystem fs = FileSystems.newFileSystem( zipFilePath, null )) {
            Path source = fs.getPath( zipFilePath + "/CODE_DISTRICT.txt" );
            Path temp = fs.getPath( zipFilePath + "/___CODE___DISTRICT.txt" );
            if ( Files.exists( temp ) ) {
                throw new IOException( "temp file exists, generate another name" );
            }
            Files.move( source, temp );
            streamCopy( temp, source, txtToReplace, replaceStr );
            Files.delete( temp );
        }
    }

    public static void streamCopy( Path src, Path dst, String txtToReplace, String replaceStr ) throws IOException {
        try (BufferedReader br = new BufferedReader( new InputStreamReader( Files.newInputStream( src ) ) ); BufferedWriter bw = new BufferedWriter( new OutputStreamWriter( Files.newOutputStream( dst ) ) )) {

            String line;
            while ( ( line = br.readLine() ) != null ) {
                line = line.replace( "XXX", replaceStr );
                bw.write( line );
                bw.newLine();
            }
        }
    }
}
