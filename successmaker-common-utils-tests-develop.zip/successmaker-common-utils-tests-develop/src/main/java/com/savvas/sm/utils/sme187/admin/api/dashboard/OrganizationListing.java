package com.savvas.sm.utils.sme187.admin.api.dashboard;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.constants.AdminConstants;

public class OrganizationListing {
    /***
     * getOrganizationList() -> This method get the child organization for the
     * parent organization given.
     * 
     * @param smUrl - The URL can be basic, auto and MSMN. Basic:
     *            https://nightly-next-basic.smdemo.info Auto:
     *            https://nightly-next-auto.smdemo.info MSMN:
     *            https://nightly-next-automsmn.smdemo.info
     * 
     * @param headers - Headers must contain the content-type, orgId, userId &
     *            Authorization The Keys to be given as follows:
     *            Constants.CONTENT_TYPE OrganizationAPIConstants.ORGID
     *            OrganizationAPIConstants.USERID
     *            OrganizationAPIConstants.AUTHORISATION
     * 
     * @return response -> The Get Call response will be given as a
     *         HashMap<String,String>
     * @throws Exception
     */

    public Map<String, String> getOrganizationList( String smUrl, Map<String, String> headers ) throws Exception {
        Map<String, String> params = new HashMap<>();
        if ( Objects.nonNull( headers.get( AdminConstants.SELECTED_ORGANIZATION_ID ) ) ) {
            params.put( AdminConstants.SELECTED_ORGANIZATION_ID, headers.get( AdminConstants.SELECTED_ORGANIZATION_ID ) );
        } else {
            params.put( AdminConstants.SELECTED_ORGANIZATION_ID, "" );
        }
        Log.message( "Selected Organization ID - " + params.get( AdminConstants.SELECTED_ORGANIZATION_ID ) );
        return RestHttpClientUtil.GET( smUrl, AdminConstants.GET_CHILD_ORGANIZATIONS, headers, params );
    }
}
