package com.savvas.sm.data;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

public class CreateAdmins extends EnvProperties {
    public static List<String> usernamesInOrg = null;
    public static HashMap<Admins, String> adminUserNames = new HashMap<>();
    public static HashMap<Admins, String> adminAllDetails = new HashMap<>();

    public static String subDistrictwithoutSchool_name = null;
    public static String subDistrictwithSchool_name = null;
    public static String subDistrictOrgId_with_school = null;
    public static String subDistrictOrgId_without_school = null;
    public static String school_under_subDistrictwithSchool_name = null;

    public void intializeVariables() {
        subDistrictwithoutSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[0];
        subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[1];
        Log.message( "subDistrictwithoutSchool_name is " + subDistrictwithoutSchool_name );
        subDistrictOrgId_with_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim(), subDistrictwithSchool_name );
        subDistrictOrgId_without_school = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim(), subDistrictwithoutSchool_name );
        school_under_subDistrictwithSchool_name = configProperty.getProperty( "Rumba_subDistrictSchool" );
    }

    /**
     * Created School Admin
     * 
     * @param smUrl - The SM instance you want to create school admin for
     * @param typeOfSchool - FLEX_SCHOOL,MATH_SCHOOL,READIN_SCHOOL,etc
     * @param orgIdForAdminCreation - District Id under which the school is
     *            present
     * @param adminNumber - Random Number
     * 
     * @return adminAllDetails
     */
    public String createSchoolAdmin( String smUrl, Schools typeOfSchool, String orgIdForAdminCreation, String adminNumber ) throws Exception {
        intializeVariables();
        List<Boolean> isAdminsCreated = new ArrayList<>();
        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        String usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );
        try {
            usernamesInOrg = new RBSUtils().getAllUserNamesFromOrg( orgIdForAdminCreation );
        } catch ( Exception e2 ) {
            e2.printStackTrace();
        }

        //School Admin
        HashMap<String, String> adminDetails = new HashMap<>();
        adminDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, RBSDataSetup.getSchools( typeOfSchool ) );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( typeOfSchool ) ) );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SCHOOL );
        adminDetails.put( RBSDataSetupConstants.USERNAME, String.format( "smAutoexecSchoolAdminCustom%s@%s", adminNumber, usernameSuffixTest ) );

        try {
            if ( !RBSDataSetup.isUserExist( usernamesInOrg, adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) {
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.SCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                    Log.message( "Created School Admin - " + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                } else {
                    new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) );
                    new RBSUtils().createCAUserWithAccess( adminDetails, true );
                    adminUserNames.put( Admins.SCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                    Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                }
            } else {
                Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                adminUserNames.put( Admins.SCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) );
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.SCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                }
            }
        } catch ( Exception e1 ) {
            e1.printStackTrace();
            isAdminsCreated.add( false );
        }

        String message = isAdminsCreated.get( 0 ) ? "School Admin is created" : "School Admin is not created";
        Log.message( message );
        new RBSUtils().resetPassword( new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( typeOfSchool ) ), RBSDataSetupConstants.DEFAULT_PASSWORD,
                new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) );
        return new RBSUtils().getUser( new RBSUtils().getUserIDByUserName( adminUserNames.get( Admins.SCHOOL_ADMIN ) ) );

    }

    /**
     * Created Multi-School Admin
     * 
     * @param smUrl - The SM instance you want to create school admin for
     * @param typeOfSchool - FLEX_SCHOOL,MATH_SCHOOL,READIN_SCHOOL,etc
     * @param orgIdForAdminCreation - District Id under which the school is
     *            present
     * @param adminNumber - Random Number
     * 
     * @return adminAllDetails
     */
    public String createMultiSchoolAdmin( String smUrl, Schools typeOfSchool, String orgIdForAdminCreation, String adminNumber ) throws Exception {
        intializeVariables();
        List<Boolean> isAdminsCreated = new ArrayList<>();
        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        String usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );
        //        HashMap<String, String> organizationIDs = null;
        try {
            usernamesInOrg = new RBSUtils().getAllUserNamesFromOrg( orgIdForAdminCreation );
        } catch ( Exception e2 ) {
            e2.printStackTrace();
        }

        //School Admin
        HashMap<String, String> adminDetails = new HashMap<>();
        adminDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, RBSDataSetup.getSchools( typeOfSchool ) );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( typeOfSchool ) ) );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SCHOOL );
        adminDetails.put( RBSDataSetupConstants.USERNAME, String.format( "smAutoexecMultischoolAdmin%s@%s", adminNumber, usernameSuffixTest ) );

        try {
            if ( !RBSDataSetup.isUserExist( usernamesInOrg, adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) {
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.MULTI_SCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                    List<String> orgIds = new ArrayList<>();
                    orgIds.add( new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( typeOfSchool ) ) );
                    new RBSUtils().updateUserOrgId( new RBSUtils().getUser( new RBSUtils().getUserIDByUserName( adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN ) ) ), RBSDataSetupConstants.ADMIN_ROLE, orgIds );
                    Log.message( "Created Multi School Admin - " + adminDetails.get( RBSDataSetupConstants.USERNAME ) );

                } else {
                    new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) );
                    new RBSUtils().createCAUserWithAccess( adminDetails, true );
                    adminUserNames.put( Admins.MULTI_SCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                    Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                }
            } else {
                Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                adminUserNames.put( Admins.MULTI_SCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) );
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.MULTI_SCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                }
            }
        } catch ( Exception e1 ) {
            e1.printStackTrace();
            isAdminsCreated.add( false );
        }
        new RBSUtils().resetPassword( new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( typeOfSchool ) ), RBSDataSetupConstants.DEFAULT_PASSWORD,
                new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) );
        String message = isAdminsCreated.get( 0 ) ? "Multi-School Admin is created" : "Multi-School Admin is not created";
        Log.message( message );
        return new RBSUtils().getUser( new RBSUtils().getUserIDByUserName( adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN ) ) );

    }

    /**
     * Created District Admin
     * 
     * @param smUrl - The SM instance you want to create school admin for
     * @param orgIdForAdminCreation - District Id under which the school is
     *            present
     * @param adminNumber - Random Number
     * 
     * @return adminAllDetails
     */
    public String createDistrictAdmin( String smUrl, String orgIdForAdminCreation, String adminNumber ) throws Exception {
        intializeVariables();
        List<Boolean> isAdminsCreated = new ArrayList<>();
        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        String usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );
        try {
            usernamesInOrg = new RBSUtils().getAllUserNamesFromOrg( orgIdForAdminCreation );
        } catch ( Exception e2 ) {
            e2.printStackTrace();
        }

        HashMap<String, String> adminDetails = new HashMap<>();
        String districtDetails = new RBSUtils().getOrg( configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
        String districtName = SMUtils.getKeyValueFromResponse( districtDetails, RBSDataSetupConstants.NAME );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, districtName );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_DISTRICT );
        adminDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        adminDetails.put( RBSDataSetupConstants.USERNAME, String.format( "smAutoexecDistrictAdmin%s@%s", adminNumber, usernameSuffixTest ) );

        try {
            if ( !RBSDataSetup.isUserExist( usernamesInOrg, adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) {
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.DISTRICT_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                    Log.message( "Created District Admin - " + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                } else {
                    new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) );
                    new RBSUtils().createCAUserWithAccess( adminDetails, true );
                    adminUserNames.put( Admins.DISTRICT_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                    Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                }
            } else {
                Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                adminUserNames.put( Admins.DISTRICT_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) );
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.DISTRICT_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                }
            }
        } catch ( Exception e1 ) {
            e1.printStackTrace();
            isAdminsCreated.add( false );
        }

        String message = isAdminsCreated.get( 0 ) ? "District Admin is created" : "District Admin is not created";
        new RBSUtils().resetPassword( orgIdForAdminCreation, RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) );
        Log.message( message );
        return new RBSUtils().getUser( new RBSUtils().getUserIDByUserName( adminUserNames.get( Admins.DISTRICT_ADMIN ) ) );
    }

    /**
     * Need to be tested Created Sub-District Admin without school
     * 
     * @param smUrl - The SM instance you want to create school admin for
     * @param orgIdForAdminCreation - District Id under which the school is
     *            present
     * @param adminNumber - Random Number
     * 
     * @return adminAllDetails
     */
    public String createSubDistrictAdminWithoutSchool( String smUrl, String orgIdForAdminCreation, String adminNumber ) throws Exception {
        intializeVariables();
        List<Boolean> isAdminsCreated = new ArrayList<>();
        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        String usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );
        try {
            usernamesInOrg = new RBSUtils().getAllUserNamesFromOrg( orgIdForAdminCreation );
        } catch ( Exception e2 ) {
            e2.printStackTrace();
        }

        HashMap<String, String> adminDetails = new HashMap<>();
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, subDistrictwithoutSchool_name );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithoutSchool_name ) );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SUBDISTRICT );
        adminDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        adminDetails.put( RBSDataSetupConstants.USERNAME, String.format( "smAutoexecSubdistrictAdmin%s@%s", adminNumber, usernameSuffixTest ) );

        try {
            if ( !RBSDataSetup.isUserExist( usernamesInOrg, adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) {
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.SUBDISTRICTWITHOUTSCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                    Log.message( "Created Sub-District Admin without school- " + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                } else {
                    new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) );
                    new RBSUtils().createCAUserWithAccess( adminDetails, true );
                    adminUserNames.put( Admins.SUBDISTRICTWITHOUTSCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                    Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                }
            } else {
                Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                adminUserNames.put( Admins.SUBDISTRICTWITHOUTSCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) );
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.SUBDISTRICTWITHOUTSCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                }
            }
        } catch ( Exception e1 ) {
            e1.printStackTrace();
            isAdminsCreated.add( false );
        }

        String message = isAdminsCreated.get( 0 ) ? "Sub-District Admin without school is created" : "Sub-District Admin without school is not created";
        new RBSUtils().resetPassword( orgIdForAdminCreation, RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) );
        Log.message( message );
        return new RBSUtils().getUser( new RBSUtils().getUserIDByUserName( adminUserNames.get( Admins.SUBDISTRICTWITHOUTSCHOOL_ADMIN ) ) );
    }

    /**
     * Need to be tested Created Sub-District Admin with school
     * 
     * @param smUrl - The SM instance you want to create school Sub-District
     *            Admin with school for
     * @param orgIdForAdminCreation - District Id under which the school is
     *            present
     * @param adminNumber - Random Number
     * 
     * @return adminAllDetails
     */
    public String createSubDistrictAdminWithSchool( String smUrl, String orgIdForAdminCreation, String adminNumber ) throws Exception {
        intializeVariables();
        List<Boolean> isAdminsCreated = new ArrayList<>();
        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        String usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );
        try {
            usernamesInOrg = new RBSUtils().getAllUserNamesFromOrg( orgIdForAdminCreation );
        } catch ( Exception e2 ) {
            e2.printStackTrace();
        }

        HashMap<String, String> adminDetails = new HashMap<>();
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, subDistrictwithSchool_name );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), subDistrictwithSchool_name ) );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SUBDISTRICT );
        adminDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        adminDetails.put( RBSDataSetupConstants.USERNAME, String.format( "smautoexecsubwithschdistrictadmin%s@%s", adminNumber, usernameSuffixTest ) );

        try {
            if ( !RBSDataSetup.isUserExist( usernamesInOrg, adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) {
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.SUBDISTRICTWITHSCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                    Log.message( "Created Sub-District Admin without school- " + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                } else {
                    new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) );
                    new RBSUtils().createCAUserWithAccess( adminDetails, true );
                    adminUserNames.put( Admins.SUBDISTRICTWITHSCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                    Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                }
            } else {
                Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                adminUserNames.put( Admins.SUBDISTRICTWITHSCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) );
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.SUBDISTRICTWITHSCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                }
            }
        } catch ( Exception e1 ) {
            e1.printStackTrace();
            isAdminsCreated.add( false );
        }

        String message = isAdminsCreated.get( 0 ) ? "Sub-District Admin with School createad" : "Sub-District Admin with School is not createad";
        new RBSUtils().resetPassword( orgIdForAdminCreation, RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) );
        Log.message( message );
        return new RBSUtils().getUser( new RBSUtils().getUserIDByUserName( adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ) ) );

    }

    /**
     * Need to be tested Savvas Admin
     * 
     * @param smUrl - The SM instance you want to create Savvas Admin for
     * @param orgIdForAdminCreation - District Id under which the school is
     *            present
     * @param adminNumber - Random Number
     * 
     * @return adminAllDetails
     */
    public String createSavvasAdmin( String smUrl, String orgIdForAdminCreation, String adminNumber ) throws Exception {
        intializeVariables();
        List<Boolean> isAdminsCreated = new ArrayList<>();
        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        String usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );
        try {
            usernamesInOrg = new RBSUtils().getAllUserNamesFromOrg( orgIdForAdminCreation );
        } catch ( Exception e2 ) {
            e2.printStackTrace();
        }

        HashMap<String, String> adminDetails = new HashMap<>();
        String districtDetails = new RBSUtils().getOrg( configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
        String districtName = SMUtils.getKeyValueFromResponse( districtDetails, RBSDataSetupConstants.NAME );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, districtName );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
        adminDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.PEARSON_ADMIN_ROLE );
        adminDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        adminDetails.put( RBSDataSetupConstants.USERNAME, String.format( "smAutoexecSavvasSdmin%s@%s", adminNumber, usernameSuffixTest ) );

        try {
            if ( !RBSDataSetup.isUserExist( usernamesInOrg, adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) {
                new RBSUtils().createUser( adminDetails );
                adminUserNames.put( Admins.SAVVAS_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                isAdminsCreated.add( true );
                Log.message( "Created Savvas Admin - " + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
            } else {
                Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                adminUserNames.put( Admins.SAVVAS_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) );
                new RBSUtils().createUser( adminDetails );
                adminUserNames.put( Admins.SAVVAS_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                isAdminsCreated.add( true );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }

        String message = isAdminsCreated.get( 0 ) ? "School Admin is created" : "School Admin is not created";
        new RBSUtils().resetPassword( orgIdForAdminCreation, RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) );
        Log.message( message );
        return new RBSUtils().getUser( new RBSUtils().getUserIDByUserName( adminUserNames.get( Admins.SAVVAS_ADMIN ) ) );
    }

}
