package com.savvas.sm.utils.constants;

public interface ConfigConstants {

    String BASIC_AUTH = "basic_Auth";
    String BROWSER_PLATFORM_TO_RUN = "BrowserPlatformToRun";
    String SM_APP_URL = "SMAppUrl";
    String ADMIN_ID = "admin_id";
    String DISTRICT_ID = "district_ID";
    String CASTGC_AUTH = "CASTGC_auth";
    String CLIENT_ID = "clientID";
    String GC_BASIC_USER = "GC_User_Basic";
    String GC_BASIC_SCHOOL = "GC_School_Basic";
    String GC_BASIC_TEACHER_ID = "GC_User_ID_Basic";
    String GC_BASIC_STUDENT_ID = "GC_Student_ID_Basic";
    String RBS_LOGIN_URL = "rbsLoginURL";
    String CASTGC_ENDPOINT = "castGCEndpoint";
    String TOKEN_URL = "tokenURL";
    String TOKEN_ENDPOINT = "tokenEndpoint";
    String SSO_URL = "ssoURL";
    String ROSTER_SERVICE = "roster_service";
    String CREATE_CLASS_ENDPOINT = "createClassEndpoint";
    String RBS_ORG_SERVICE = "rbsOrg_Service";

    String ORG_SERVICE = "org_service";
    String ORG_SERVICE_ENDPOINT = "org_service_endPoint";
    String GET_ORG_ENDPOINT = "getOrg_endpoint";

    String USER_SERVICE = "user_service";
    String USER_SERVICE_ENDPOINT = "user_service_endPoint";
    String USER_SERVICE_UPDATE_ENDPOINT = "user_service_Update_endPoint";
    String ORDER_LIFECYCLE_URL = "order_lifecycle_URL";
    String ORDER_LIFECYCLE_ENDPOINT = "order_lifecycle_endPoint";
    String LICENSE_LIFECYCLE_URL = "license_lifecycle_URL";
    String LICENSE_LIFECYCLE_ENDPOINT = "license_lifecycle_endPoint";
    String AE_USER_SERVICE = "ae_user_service";
    String AE_USER_SERVICE_DELETE_ENDPOINT = "ae_user_service_delete_endpoint";
    String ROSTER_SERVICE_URL = "roster_service_url";

    String USER_DETAILS_BY_USER_SERVICES = "user_service_details_for_user";
    String AE_USER_SERVICE_GET_ENDPOINT = "ae_get_user_endpoint";
    String USER_LIFECYCLE_ENDPOINT = "user_lifecycle_endpoint";
    String LICENSE_SERVICE = "license_service";
    String GET_LICENSED_PRODUCT = "org_licensed_product_endpoint";

    String SRS_SERVICE = "srs_service";
    String SRS_ASR_CREATE_ADMIN_ENDPOINT = "srs_create_asr_endpoint";

    String AE_USER_SERVICE_SUSPEND_ENDPOINT = "ae_user_service_suspend_endpoint";
    String CMS_URL = "cms_url";
    String CMS_USERNAME = "cms_userName";
    String CMS_PASSWORD = "cms_password";

    String SM_SCHOOLS = "Rumba_schools";
    String SOLR_URL = "solr_url";
    String SOLR_ENDPOINT_ORG = "solr_endpoint_Org";
    String SOLR_ENDPOINT_LICENSE = "solr_endpoint_License";
    String SOLR_ENDPOINT_USER = "solr_endpoint_User";
    String SOLR_USERNAME = "solr_username";
    String SOLR_PASSWORD = "solr_password";

    String ULC_URL = "user_lifecycle_URL";
    String ULC_READ_ENDPOINT = "user_lifecycle_read";
    String SM_APP_AUTO_INSTANCE = "SMAppAutoUrl";

    String CREATE_USER_BY_USER_SERVICE_ENDPOINT = "CREATE_USER_BY_USER_SERVICE_ENDPOINT";
    String FLEXPRODUCT = "flexProduct";
    String AUTO__TEACHER_USER_NAME = "AUTO__TEACHER_USER_NAME";
    String GOOGLE_TEACH_USERNAME = "GoogleTeachusername";
    String GOOGLE_TEACH_USERID = "GoogleTeachrumbaId";
    String GOOGLE_TEACH_ORG_ID = "GoogleTeachOrgId";
    String GET_SECTION_DETAILS_FOR_TEACHER_ID = "get_section_details_for_teacher";
    String GET_CHILD_ORG_ENDPOINT = "getChildOrg_endpoint";

    String CLASS_SERVICE_GRAPHQL = "class_service_graphql";
    String GET_USER_SERVIVE_URL = "get_user_user_service_URL";
    String GET_USER_SERVIVE_ENDPOINT = "get_user_endpoint";
    String GET_GROUPLIST_USERSERVICE_REPORTS = "group_list_graphql";

    String TEACHER_COUNT = "teacherCount";
    String OTHER_SCHOOLS_TEACHER_PERCENTAGE = "otherSchoolTeachersPercentage";
    String STUDENT_COUNT = "studentCount";
    String GROUP_COUNT = "groupCount";
    String IS_UI_TEST = "isUITesting";
    String IS_REPORT_TEST_EXECUTION = "isReportTestExecution";
    String TEACHER_USERNAME = "teacher_username";
    String STUDENT_USERNAME = "student_username";
    String IS_SCHOOL_CREATION_RESTRICTED = "isSchoolCreationRestricted";

}
