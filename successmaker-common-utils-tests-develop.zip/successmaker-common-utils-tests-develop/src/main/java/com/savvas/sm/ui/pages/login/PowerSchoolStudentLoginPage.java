package com.savvas.sm.ui.pages.login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.SMUtils;

/**
 * This class contains the PowerSchool Teacher Sign-In Page POM
 * 
 * @author madhan.nagarathinam
 */

public class PowerSchoolStudentLoginPage extends LoadableComponent<PowerSchoolStudentLoginPage> {

    private final WebDriver driver;
    boolean isPageLoaded;

    //*******WebElement for PowerSchool Students Sign In Page *******

    @FindBy ( css = "input#fieldAccount" )
    WebElement txtBoxUserName;

    @FindBy ( css = "input#fieldPassword" )
    WebElement txtBoxPassword;

    @FindBy ( css = "button#btn-enter-sign-in" )
    WebElement btnSignIn;

    /**
     * constructor of the class
     * 
     * @param driver
     */
    public PowerSchoolStudentLoginPage( WebDriver driver ) {

        this.driver = driver;
        PageFactory.initElements( driver, this );
    }

    @Override
    protected void isLoaded() {

        if ( !isPageLoaded ) {
            Assert.fail();
        }

        if ( !driver.getCurrentUrl().toLowerCase().contains( "public" ) ) {
            Log.fail( "'PowerSchool Students Sign In' Page did not open up. Site might be down.", driver );
        }

    }

    @Override
    protected void load() {
        isPageLoaded = true;
    }

    //***Methods for login to PowerSchool Student Page

    /**
     * To enter the user name in user name field on PowerSchoolStudentSignInPage
     * 
     * @param userName as string
     * @param screenshot
     */
    public void enterUserName( String userName, boolean screenshot ) {

        SMUtils.fluentWaitForElement( driver, txtBoxUserName );
        txtBoxUserName.clear();
        txtBoxUserName.sendKeys( userName );
        Log.message( "Entered the UserName: '" + userName + "'", driver, screenshot );
    }

    /**
     * To enter the password in password field on PowerSchoolStudentSignInPage
     * 
     * @param pwd as string
     * @param screenshot
     */
    public void enterPassword( String pwd, boolean screenshot ) {
        SMUtils.fluentWaitForElement( driver, txtBoxPassword );
        txtBoxPassword.clear();
        txtBoxPassword.sendKeys( pwd );
        Log.message( "Entered the Password: '" + pwd + "'", driver, screenshot );

    }

    /**
     * To click the sign in button on PowerSchoolStudentSignInPage login page
     * 
     * @param screenshot
     */
    public void clickSignInButton( boolean screenshot ) {
        SMUtils.fluentWaitForElement( driver, btnSignIn );
        SMUtils.click( driver, btnSignIn );
        Log.message( "Clicked on 'SignIn' button on PowerSchool Student SignIn Page", driver, screenshot );

    }

    /**
     * Sign in the given user to the PowerSchool Student application
     * 
     * @param username
     * @param password
     * @return
     */
    public void signInToSuccessMakerAsStudent( String username, String password ) {
        enterUserName( username, false );
        enterPassword( password, false );
        clickSignInButton( true );
       // return new StudentDashboardPage( driver ).get();
    }

}
