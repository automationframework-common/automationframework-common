package com.savvas.sm.utils.sme187.admin.api.reports;

import com.learningservices.utils.EnvironmentPropertiesReader;

public interface ReportConstants {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    //BFF payload
    String REPORT_BFF = configProperty.getProperty( "AdminReportBFF" );;
    String GRAPHQL_ENDPOINT = "/graphql";

    String GET_DEMOGRAHICS_LIST_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getDemographics(\\n    orgId: \\\"{organizationId}\\\"\\n    userId: \\\"{userID}\\\"\\n  ) {\\n    GENDER {\\n      id\\n      name\\n      displayOrder\\n      demographicValue\\n    }\\n    DISABILITY_STATUS {\\n      id\\n      name\\n      displayOrder\\n      demographicValue\\n    }\\n    MIGRANT_STATUS {\\n      id\\n      name\\n      displayOrder\\n      demographicValue\\n    }\\n    SOCIOECONOMIC_STATUS {\\n      id\\n      name\\n      displayOrder\\n      demographicValue\\n    }\\n    RACE {\\n      id\\n      name\\n      displayOrder\\n      demographicValue\\n    }\\n    ETHNICITY {\\n      id\\n      name\\n      displayOrder\\n      demographicValue\\n    }\\n    SPECIAL_SERVICES {\\n      id\\n      name\\n      displayOrder\\n      demographicValue\\n    }\\n    ENGLISH_LANGUAGE {\\n      id\\n      name\\n      displayOrder\\n      demographicValue\\n    }\\n  }\\n}\\n\"}";
    String ADMIN_LSR_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getLSAdminReportData(\\n    filterParams: {subject: \\\"%s\\\", courseList: [{courseList}], additionalGrouping: {additionalGroupId}, filterBySchool: [\\\"%s\\\"], filterByTeacher: [{teacherId}], filterByGroup: [{groupId}], filterByGrade: [{grade}], filterByDemographics: {disabilityStatus: [{disabilityStatus}], englishLanguageProficiency: [{language}], gender: [{gender}], migrantStatus: [{migrantStatus}], race: [{race}], ethnicity: [{ethnicity}], socioeconomicStatus: [{socioStatus}], specialServices: [{specialServices}]}}\\n    userId: \\\"%s\\\"\\n    organizationId: \\\"%s\\\"\\n  ) {\\n    organizationName\\n    grade\\n    assignmentTitle\\n    groupName\\n    teacherID\\n    teacherName\\n   studentID\\n    studentName\\n  studentUsername\\n    studentFirstName\\n    studentMiddleName\\n    studentLastName\\n    currentCourseLevel\\n  ipmStatusID\\n  rawPerformance {\\n      exercisesCorrect\\n      exercisesAttempted\\n      exercisesPercentCorrect\\n    }\\n    usage {\\n      helpUsed\\n      timeSpent\\n      totalSessions\\n      sessionDate\\n    }\\n    exercisesCorrectedAttempted {\\n      instructionalCorrect\\n      instructionalAttempted\\n      independentPracticeCorrect\\n      independentPracticeAttempted\\n      remediationCorrect\\n      remediationAttempted\\n    }\\n  }\\n}\\n\"}";
    String MULTI_ORG_LIST_BODY="{\"operationName\":\"GetOrganizationNameList\",\"variables\":{\"organizationIds\":[{orgId}]},\"query\":\"query GetOrganizationNameList($organizationIds: [String!]!) {\\n  getOrganizationNameList(organizationIds: $organizationIds) {\\n    orgId\\n    orgName\\n    __typename\\n  }\\n}\\n\"}";

    //Student Performance Report Constants
    public interface SPReportConstants {

        public static String STUDENT_ID_VALUE = "{studentId}";
        public static String STUDENT_ID = "studentId";
        public static String STUDENT_NAME = "studenName";
        public static String COURSES = "courses";
        public static String SUBJECT = "subject";
        public static String LANGUAGE_VALUE = "{language}";
        public static String SUBJECT_VALUE = "{subject}";
        public static String ENGLISH = "en";
        public static String COURSE_VALUES = "[\\\"1234\\\", \\\"5678\\\"]";
        String GET_SPREPORTS_OUTPUT_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getSPReportData(\\n    spReportRequest: {\\n      studentId: \\\"{studentId}\\\"\\n      language: \\\"{language}\\\"\\n      subject: \\\"{subject}\\\"\\n      courseList: [\\\"1234\\\", \\\"5678\\\"]\\n      includePerformanceSummary: true\\n      includePerformanceByStrand: true\\n      includeAreasOfDifficulty: true\\n      includeRecentHistoryData: true\\n      filterBySchool: []\\n      filterByTeacher: []\\n      filterByGrade: []\\n      filterByGroup: []\\n    }\\n  ) {\\n    studentId\\n    studenName\\n    courses {\\n      course {\\n        name\\n        school\\n        teacher\\n        grade\\n        group\\n        assignedCourseLevel\\n        currentCourseLevel\\n        ipLevel\\n        gain\\n        exerCorrect\\n        exerAttempted\\n        cri\\n        skillsMastered\\n        skillsAssessed\\n        helpUsed\\n        audioRepeatsUsed\\n        reportCardViews\\n        glossaryUsed\\n        timeSpent\\n        totalSessions\\n        averageSessionTime\\n        computationStrands {\\n          name\\n          level\\n          skillsMastered\\n          skillsAssessed\\n        }\\n        applicationStrands {\\n          name\\n          level\\n          skillsMastered\\n          skillsAssessed\\n        }\\n        skillsDelayed {\\n          strand\\n          level\\n          description\\n        }\\n        skillsNotMastered {\\n          strand\\n          level\\n          description\\n        }\\n      }\\n    }\\n  }\\n}\\n\"}";
        public static String MATH = "math";
    }

}