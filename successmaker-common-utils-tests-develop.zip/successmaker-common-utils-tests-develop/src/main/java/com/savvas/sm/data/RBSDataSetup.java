package com.savvas.sm.data;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.apache.commons.lang3.RandomStringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeSuite;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.learningservices.utils.StopWatch;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

/**
 * Data setup for RBS integrations
 *
 * @author ajith.mohan
 */
public class RBSDataSetup extends EnvProperties {

    public static HashMap<String, String> organizationIDs = null;
    public static HashMap<String, String> teacherDetails = null;
    public static HashMap<String, String> studentDetails = null;
    public static List<String> usernamesInOrg = null;
    public static HashMap<String, HashMap<String, String>> orgTeacherDetails = new HashMap<>();
    public static HashMap<String, HashMap<String, String>> orgStudentDetails = new HashMap<>();
    public static HashMap<String, HashMap<String, String>> orgTeacherDetailsLocal = new HashMap<>();
    public static HashMap<String, HashMap<String, String>> orgStudentDetailsLocal = new HashMap<>();
    public static HashMap<String, String> errorTeacherDetails = new HashMap<>();

    public static HashMap<String, HashMap<String, String>> teacherStudentMap = null;

    public static HashMap<String, HashMap<String, HashMap<String, String>>> teacherStudentRelation = new HashMap<>();
    public static HashMap<String, HashMap<String, HashMap<String, HashMap<String, String>>>> teacherStudentRelationDuplicate = new HashMap<>();

    public static List<String> teacherInfo = new ArrayList<>();
    public static HashMap<Admins, String> adminUserNames = new HashMap<>();

    public static HashMap<Admins, String> adminDetails = new HashMap<>();

    public static String subDistrictwithoutSchool = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[0];
    public static String subDistrictwithSchool = configProperty.getProperty( "Rumba_subDistrict" ).split( "," )[1];
    public static String SchoolUnderSubDistrict = configProperty.getProperty( "Rumba_subDistrictSchool" );
    public static String subDistrictwithoutSchoolId = null;
    public static String subDistrictwithSchoolId = null;
    public static String schoolUnderSubDistrict_SchoolId = null;
    private String smUrl;
    CourseAPI coursesMethod = new CourseAPI();
    AssignmentAPI assignmentMethod = new AssignmentAPI();
    private int flexTeacherCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.TEACHER_COUNT ) );
    private int otherSchoolTeacherCountPercentage = Objects.nonNull( configProperty.getProperty( ConfigConstants.OTHER_SCHOOLS_TEACHER_PERCENTAGE ) ) ? Integer.parseInt( configProperty.getProperty( ConfigConstants.OTHER_SCHOOLS_TEACHER_PERCENTAGE ) ) : 10;
    private int otherSchoolTeacherCount = ( otherSchoolTeacherCountPercentage * flexTeacherCount ) / 100;
    private int teacherCount = otherSchoolTeacherCount;
    private int studentCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) );
    private int groupsCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.GROUP_COUNT ) );
    private int currentSchool;
    private long startTime;

    /**
     * This constructor loads the necessary details when it is invoked.
     */
    public RBSDataSetup() {}

    /**
     * starting test data setup
     *
     * @throws Exception
     */
    @BeforeSuite ( alwaysRun = true )
    public void testDataSetup() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        setupData();
    }

    /**
     * Setting up the data
     *
     * @throws Exception
     */
    public void setupData() throws Exception {
        loadData();
    }

    /**
     * Data creation based on the configuration
     */
    public void loadData() {

        organizationIDs = new HashMap<>();
        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        String usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );
        boolean isUITesting = Boolean.parseBoolean( configProperty.getProperty( ConfigConstants.IS_UI_TEST ) );
        boolean isReportTestExecution = Objects.nonNull( configProperty.getProperty( ConfigConstants.IS_REPORT_TEST_EXECUTION ) ) ? Boolean.parseBoolean( configProperty.getProperty( ConfigConstants.IS_REPORT_TEST_EXECUTION ) ) : false;

        List<String> schools = new ArrayList<>();
        for ( String school : configProperty.getProperty( ConfigConstants.SM_SCHOOLS ).split( "," ) ) {
            if ( !school.equals( "" ) || ( !school.isEmpty() ) ) {
                schools.add( school );
            }

        }

        if ( isUITesting ) {
            startTime = StopWatch.startTime();
            schools.clear();
            schools.add( getSchools( Schools.FLEX_SCHOOL ) );
            Log.message( "***************** UI Test data creation started ***************" );
        } else {
            Log.message( "***************** API Test Data creation Started for EPIC - 187 *************" );
        }

        Log.message( "" );
        Log.message( "Total flex Teachers : " + flexTeacherCount );
        Log.message( "Total other schools teacher count : " + otherSchoolTeacherCount );
        Log.message( "Total Students per teacher : " + studentCount );
        Log.message( "Total Groups per teacher : " + groupsCount );

        usernamesInOrg = new ArrayList<>();
        if ( !new RBSUtils().isOrganizationExist( configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim(), subDistrictwithoutSchool ) ) {
            HashMap<String, String> orgDetails = new HashMap<>();
            orgDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, subDistrictwithoutSchool );
            orgDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SUBDISTRICT );
            Log.message( "Created SubDistrict - " + orgDetails.get( RBSDataSetupConstants.ORGANIZATION_NAME ) );
            orgDetails.put( RBSDataSetupConstants.SCHOOL_ID, new RBSUtils().createOrg( orgDetails ) );
            orgDetails.put( RBSDataSetupConstants.DISTRICT_ID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim() );
            new RBSUtils().relateOrganization( orgDetails );
            subDistrictwithoutSchoolId = orgDetails.get( RBSDataSetupConstants.SCHOOL_ID );
        } else {
            Log.message( "Sub district already there!" );
            subDistrictwithoutSchoolId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim(), subDistrictwithoutSchool );
        }

        if ( !new RBSUtils().isOrganizationExist( configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim(), subDistrictwithSchool ) ) {
            HashMap<String, String> orgDetails = new HashMap<>();
            orgDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, subDistrictwithSchool );
            orgDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SUBDISTRICT );
            Log.message( "Created SubDistrict - " + orgDetails.get( RBSDataSetupConstants.ORGANIZATION_NAME ) );
            orgDetails.put( RBSDataSetupConstants.SCHOOL_ID, new RBSUtils().createOrg( orgDetails ) );
            orgDetails.put( RBSDataSetupConstants.DISTRICT_ID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim() );
            new RBSUtils().relateOrganization( orgDetails );
            subDistrictwithSchoolId = orgDetails.get( RBSDataSetupConstants.SCHOOL_ID );
        } else {
            Log.message( "Sub district already there!" );
            subDistrictwithSchoolId = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim(), subDistrictwithSchool );
        }

        if ( !new RBSUtils().isOrganizationExist( subDistrictwithSchoolId, SchoolUnderSubDistrict ) ) {
            HashMap<String, String> orgDetails = new HashMap<>();
            orgDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, SchoolUnderSubDistrict );
            orgDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SCHOOL );
            Log.message( "Created School UnderSubDistrict - " + orgDetails.get( RBSDataSetupConstants.ORGANIZATION_NAME ) );
            orgDetails.put( RBSDataSetupConstants.SCHOOL_ID, new RBSUtils().createOrg( orgDetails ) );
            orgDetails.put( RBSDataSetupConstants.DISTRICT_ID, subDistrictwithSchoolId );
            new RBSUtils().relateOrganization( orgDetails );
            schoolUnderSubDistrict_SchoolId = orgDetails.get( RBSDataSetupConstants.SCHOOL_ID );
            try {
                addLicenseToSchool( SchoolUnderSubDistrict, schoolUnderSubDistrict_SchoolId );
            } catch ( Exception e1 ) {
                e1.printStackTrace();
            }
        } else {
            Log.message( "school under Sub district already there!" );
            schoolUnderSubDistrict_SchoolId = new RBSUtils().getOrganizationIDByName( subDistrictwithSchoolId, SchoolUnderSubDistrict );
            try {
                addLicenseToSchool( SchoolUnderSubDistrict, schoolUnderSubDistrict_SchoolId );
            } catch ( Exception e1 ) {
                e1.printStackTrace();
            }
        }

        schools.stream().forEach( school -> {
            teacherStudentMap = new HashMap<>();
            for ( Schools sch : Schools.values() ) {
                if ( school.equalsIgnoreCase( getSchools( sch ) ) ) {
                    currentSchool = sch.ordinal();
                }
            }

            if ( school.equalsIgnoreCase( getSchools( Schools.FLEX_SCHOOL ) ) ) {
                teacherCount = flexTeacherCount;
            } else {
                teacherCount = otherSchoolTeacherCount;
            }

            if ( new RBSUtils().isOrganizationExist( configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim(), school ) ) {
                teacherDetails = new HashMap<>();
                errorTeacherDetails = new HashMap<>();
                Log.message( "*********School is already there!! Proceeding with user creation*********" );
                organizationIDs.put( school, new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim(), school ) );
                HashMap<String, String> userDetails = new HashMap<>();
                HashMap<String, String> groupDetails = new HashMap<>();

                try {
                    usernamesInOrg = new RBSUtils().getAllUserNamesFromOrg( organizationIDs.get( school ) );
                } catch ( Exception e2 ) {
                    e2.printStackTrace();
                }

                try {
                    addLicenseToSchool( school, organizationIDs.get( school ) );
                } catch ( Exception e1 ) {
                    e1.printStackTrace();
                }

                List<String> teacherRumbaIdsForExistingSchools = new ArrayList<String>();

                IntStream.rangeClosed( 1, teacherCount ).forEach( teacherCount -> {
                    studentDetails = new HashMap<>();

                    HashMap<String, String> localTeacherDetails = new HashMap<>();
                    List<String> studentRumbaIdsForExistingSchools = new ArrayList<>();
                    List<String> groupIds = new ArrayList<>();
                    HashMap<String, String> assignmentDeatilsForNewSchool = new HashMap<>();
                    userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );

                    if ( isUITesting ) {
                        userDetails.put( RBSDataSetupConstants.USERNAME, String.format( configProperty.getProperty( ConfigConstants.TEACHER_USERNAME ) + "_UI", currentSchool + 1, teacherCount, usernameSuffixTest ) );
                    } else {
                        userDetails.put( RBSDataSetupConstants.USERNAME, String.format( configProperty.getProperty( ConfigConstants.TEACHER_USERNAME ), currentSchool + 1, teacherCount, usernameSuffixTest ) );
                    }
                    userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                    userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, organizationIDs.get( school ) );
                    List<String> courseIdsForExistingSchools = new ArrayList<String>();

                    try {

                        if ( isUserExist( usernamesInOrg, userDetails.get( RBSDataSetupConstants.USERNAME ) ) ) {
                            String userId = new RBSUtils().getUserIDByUserName( userDetails.get( RBSDataSetupConstants.USERNAME ) );
                            Log.message( userDetails.get( RBSDataSetupConstants.USERNAME ) + "is already there in A&E! Loading the teacher details" );
                            // For Admin reports related users Course & Assignment Details wont be dlete
                            if ( userDetails.get( RBSDataSetupConstants.USERNAME ).contains( "adminteachers" ) ) {
                                Log.message( "Teacher belongs to Admin reports data, so course & assignment will not  be deleted" );
                            } else {
                                try {
                                    SqlHelperAssignment.deleteAssignmntsByRumbaID( userId );
                                    SqlHelperCourses.deleteCustomCourseByRumbaID( userId );
                                } catch ( Exception e ) {
                                    Log.message( "Getting issue while delete the assignment!!!" );
                                    errorTeacherDetails.put( "Teacher" + teacherCount, userDetails.get( RBSDataSetupConstants.USERNAME ) );
                                }
                            }
                            localTeacherDetails.put( "Teacher" + teacherCount, new RBSUtils().getUserWithUserService( userId ) );
                        } else {
                            String userId = new RBSUtils().createUserByUserService( userDetails );
                            localTeacherDetails.put( "Teacher" + teacherCount, new RBSUtils().getUserWithUserService( userId ) );
                            Log.message( "Created Teacher - " + userDetails.get( RBSDataSetupConstants.USERNAME ) );
                            try {
                                //new RBSUtils().resetPassword( organizationIDs.get( school ), RBSDataSetupConstants.DEFAULT_PASSWORD, SMUtils.getKeyValueFromResponse( localTeacherDetails.get( "Teacher" + teacherCount ), "userId" ) );
                            } catch ( Exception e ) {
                                Log.message( "Username is already exist! or Issue in resetting password!" );
                            }
                        }
                        teacherDetails.put( "Teacher" + teacherCount, localTeacherDetails.get( "Teacher" + teacherCount ) );

                        //Creation of course for each teacher
                        String teacherBearertoken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( localTeacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                        String teacherUserId = SMUtils.getKeyValueFromResponse( localTeacherDetails.get( "Teacher" + teacherCount ), "userId" );
                        teacherRumbaIdsForExistingSchools.add( teacherUserId );

                        IntStream.rangeClosed( 1, studentCount ).forEach( studentCount -> {
                            HashMap<String, String> localStudentDetails = new HashMap<>();
                            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );

                            if ( isUITesting ) {
                                userDetails.put( RBSDataSetupConstants.USERNAME, String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ) + "_UI", currentSchool + 1, teacherCount, studentCount, usernameSuffixTest ) );

                            } else {
                                userDetails.put( RBSDataSetupConstants.USERNAME, String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ), currentSchool + 1, teacherCount, studentCount, usernameSuffixTest ) );

                            }

                            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, organizationIDs.get( school ) );
                            try {

                                if ( isUserExist( usernamesInOrg, userDetails.get( RBSDataSetupConstants.USERNAME ) ) ) {
                                    String userId = new RBSUtils().getUserIDByUserName( userDetails.get( RBSDataSetupConstants.USERNAME ) );
                                    Log.message( userDetails.get( RBSDataSetupConstants.USERNAME ) + "is already there in A&E! Loading the Student details" );
                                    String studentDetail = new RBSUtils().getUserWithUserService( userId );
                                    if ( Objects.nonNull( studentDetail ) ) {
                                        localStudentDetails.put( "Student" + studentCount, studentDetail );
                                    }
                                } else {
                                    Log.message( "Student - " + userDetails.get( RBSDataSetupConstants.USERNAME ) );
                                    String userId = new RBSUtils().createUserByUserService( userDetails );
                                    String studentDetail = new RBSUtils().getUserWithUserService( userId );
                                    if ( Objects.nonNull( studentDetail ) ) {
                                        localStudentDetails.put( "Student" + studentCount, studentDetail );
                                        try {
                                            HashMap<String, String> studentInfo = new HashMap<>();
                                            studentInfo = generateRequestValues( localStudentDetails.get( "Student" + studentCount ), studentInfo, UserConstants.SCHOOLID, organizationIDs.get( school ) );
                                            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                                            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERID ) );
                                            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN,
                                                    new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                                            Log.message( "Updating grade..." );
                                            new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
                                            //new RBSUtils().resetPassword( organizationIDs.get( school ), RBSDataSetupConstants.DEFAULT_PASSWORD, SMUtils.getKeyValueFromResponse( localStudentDetails.get( "Student" + studentCount ), "userId" ) );
                                        } catch ( Exception e ) {
                                            Log.message( "Student Username is already exist ! or issue in updating the student password" );
                                        }
                                    }
                                }
                                studentDetails.put( "Student" + studentCount, localStudentDetails.get( "Student" + studentCount ) );
                                studentRumbaIdsForExistingSchools.add( SMUtils.getKeyValueFromResponse( localStudentDetails.get( "Student" + studentCount ), "userId" ) );
                            } catch ( Exception e ) {
                                e.printStackTrace();
                            }
                        } );

                        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( localTeacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERID ) );
                        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                        groupDetails.put( GroupConstants.STAFF_ID, SMUtils.getKeyValueFromResponse( teacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERID ) );

                        HashMap<String, String> groupListingForTeacherID = new GroupAPI().getGroupListingForTeacherID( smUrl, groupDetails );
                        deleteAllGroupUnderTeacher( groupListingForTeacherID.get( Constants.REPORT_BODY ), groupDetails.get( GroupConstants.GROUP_OWNER_ID ), groupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ),
                                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( localTeacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                        for ( int groupCount = 1; groupCount <= groupsCount; groupCount++ ) {
                            //Creating a group
                            String groupName = "Successmaker Group " + groupCount;
                            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                                    new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( localTeacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                            groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERID ) );
                            groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                            groupDetails.put( GroupConstants.GROUP_NAME, groupName );
                            groupDetails.put( GroupConstants.STAFF_ID, SMUtils.getKeyValueFromResponse( teacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERID ) );

                            HashMap<String, String> createGroup = new HashMap<>();

                            boolean groupCreated = false;
                            createGroup = new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIdsForExistingSchools );
                            if ( createGroup.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                                groupIds.add( SMUtils.getKeyValueFromResponse( createGroup.get( Constants.REPORT_BODY ), "data,groupId" ) );
                                Log.message(
                                        "Group ( " + groupDetails.get( GroupConstants.GROUP_NAME ) + " ) created for the teacher " + SMUtils.getKeyValueFromResponse( localTeacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERNAME ) );
                                groupCreated = true;
                            }
                            int maxCount = 5; //To retry 5 times 
                            while ( !groupCreated && maxCount != 0 ) {
                                createGroup = new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIdsForExistingSchools );
                                if ( createGroup.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                                    groupIds.add( SMUtils.getKeyValueFromResponse( createGroup.get( Constants.REPORT_BODY ), "data,groupId" ) );
                                    Log.message( "Group ( " + groupDetails.get( GroupConstants.GROUP_NAME ) + " ) created for the teacher "
                                            + SMUtils.getKeyValueFromResponse( localTeacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERNAME ) );
                                    groupCreated = true;
                                    break;
                                } else {
                                    Thread.sleep( 5000 );
                                    Log.message( "groupDetails - " + groupDetails );
                                    Log.message( "studentRumbaIdsForExistingSchools - " + studentRumbaIdsForExistingSchools );
                                    Log.message( "Group creation is throwing error! Retrying - " + maxCount );
                                    maxCount--;
                                    if ( maxCount == 0 ) {
                                        errorTeacherDetails.put( "Teacher" + teacherCount, userDetails.get( RBSDataSetupConstants.USERNAME ) );
                                    }
                                }

                            }
                        }

                        if ( !isReportTestExecution ) {
                            //Custom Math and Reading Courses
                            if ( school.equalsIgnoreCase( getSchools( Schools.READING_SCHOOL ) ) ) {
                                courseIdsForExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.READING, teacherUserId, organizationIDs.get( school ), DataSetupConstants.SETTINGS,
                                        String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.READING, teacherUserId, organizationIDs.get( school ), DataSetupConstants.SKILL,
                                        String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.READING, teacherUserId, organizationIDs.get( school ), DataSetupConstants.STANDARD,
                                        String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                            } else if ( school.equalsIgnoreCase( getSchools( Schools.MATH_SCHOOL ) ) ) {
                                courseIdsForExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.MATH, teacherUserId, organizationIDs.get( school ), DataSetupConstants.SETTINGS,
                                        String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.MATH, teacherUserId, organizationIDs.get( school ), DataSetupConstants.SKILL,
                                        String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.MATH, teacherUserId, organizationIDs.get( school ), DataSetupConstants.STANDARD,
                                        String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                            } else if ( school.equalsIgnoreCase( getSchools( Schools.FLEX_SCHOOL ) ) ) {
                                courseIdsForExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.MATH, teacherUserId, organizationIDs.get( school ), DataSetupConstants.SETTINGS,
                                        String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.MATH, teacherUserId, organizationIDs.get( school ), DataSetupConstants.SKILL,
                                        String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.MATH, teacherUserId, organizationIDs.get( school ), DataSetupConstants.STANDARD,
                                        String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.READING, teacherUserId, organizationIDs.get( school ), DataSetupConstants.SETTINGS,
                                        String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.READING, teacherUserId, organizationIDs.get( school ), DataSetupConstants.SKILL,
                                        String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.READING, teacherUserId, organizationIDs.get( school ), DataSetupConstants.STANDARD,
                                        String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                            }

                            //Assigning the assignment
                            if ( Boolean.FALSE.equals( courseIdsForExistingSchools.isEmpty() ) ) {
                                assignmentDeatilsForNewSchool.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                                assignmentDeatilsForNewSchool.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERID ) );
                                assignmentDeatilsForNewSchool.put( RBSDataSetupConstants.BEARER_TOKEN, teacherBearertoken );
                                assignmentMethod.assignMultipleAssignments( smUrl, assignmentDeatilsForNewSchool, studentRumbaIdsForExistingSchools, courseIdsForExistingSchools );
                            }
                        }

                        String tchUsernameValue = SMUtils.getKeyValueFromResponse( teacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERNAME );
                        teacherStudentMap.put( tchUsernameValue, studentDetails );

                        Log.message( "Below Students are created successfully for the teacher - " + tchUsernameValue );
                        studentDetails.entrySet().stream().forEach( entry -> {
                            Log.message( SMUtils.getKeyValueFromResponse( entry.getValue(), RBSDataSetupConstants.USERNAME ) );
                        } );
                        teacherStudentRelation.put( school, teacherStudentMap );

                    } catch ( Exception e ) {
                        e.printStackTrace();
                    }
                } );

                teacherStudentRelationDuplicate.put( school, teacherStudentRelation );
                errorTeacherDetails.entrySet().stream().forEach( entry -> teacherDetails.remove( entry.getKey() ) );
                Log.message( "######## Below teachers had issue with creation #########\n" );
                errorTeacherDetails.entrySet().stream().forEach( entry -> Log.message( entry.getValue() + ", " ) );
                Log.message( "###### Below Teachers are created successfully ###########\n" );
                teacherDetails.entrySet().stream().forEach( entry -> Log.message( SMUtils.getKeyValueFromResponse( entry.getValue(), RBSDataSetupConstants.USERNAME ) + ", " ) );
                orgTeacherDetails.put( school, teacherDetails );
                orgStudentDetails.put( school, studentDetails );
                orgTeacherDetailsLocal.putAll( orgTeacherDetails );
                orgStudentDetailsLocal.putAll( orgStudentDetails );
                Collections.synchronizedMap( orgTeacherDetailsLocal );
                Collections.synchronizedMap( teacherStudentRelationDuplicate );
                Collections.synchronizedMap( orgStudentDetailsLocal );

            } else {
                Log.message( "*********School is not present in Rumba! Proceeding with school creation*******" );

                teacherDetails = new HashMap<>();
                errorTeacherDetails = new HashMap<>();
                studentDetails = new HashMap<>();
                List<String> teacherRumbaIdsForExistingSchools = new ArrayList<String>();

                HashMap<String, String> orgDetails = new HashMap<>();
                HashMap<String, String> userDetails = new HashMap<>();
                HashMap<String, String> groupDetails = new HashMap<>();
                orgDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, school );
                orgDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SCHOOL );
                orgDetails.put( RBSDataSetupConstants.SCHOOL_ID, new RBSUtils().createOrg( orgDetails ) );
                Log.message( "Created School - " + orgDetails.get( RBSDataSetupConstants.ORGANIZATION_NAME ) );
                orgDetails.put( RBSDataSetupConstants.DISTRICT_ID, configProperty.getProperty( "district_ID" ) );

                new RBSUtils().relateOrganization( orgDetails );

                try {
                    addLicenseToSchool( school, orgDetails.get( RBSDataSetupConstants.SCHOOL_ID ) );
                } catch ( Exception e1 ) {

                    e1.printStackTrace();
                }

                organizationIDs.put( school, orgDetails.get( RBSDataSetupConstants.SCHOOL_ID ) );

                IntStream.rangeClosed( 1, teacherCount ).forEach( teacherCount -> {
                    studentDetails = new HashMap<>();
                    HashMap<String, String> localTeacherDetails = new HashMap<>();
                    List<String> studentRumbaIdsForNonExistingSchools = new ArrayList<>();
                    List<String> groupIds = new ArrayList<>();
                    HashMap<String, String> assignmentDeatilsForNewSchool = new HashMap<>();
                    userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );

                    if ( isUITesting ) {
                        userDetails.put( RBSDataSetupConstants.USERNAME, String.format( configProperty.getProperty( ConfigConstants.TEACHER_USERNAME ) + "_UI", currentSchool + 1, teacherCount, usernameSuffixTest ) );
                    } else {
                        userDetails.put( RBSDataSetupConstants.USERNAME, String.format( configProperty.getProperty( ConfigConstants.TEACHER_USERNAME ), currentSchool + 1, teacherCount, usernameSuffixTest ) );
                    }

                    userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                    userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, organizationIDs.get( school ) );
                    List<String> courseIdsForNonExistingSchools = new ArrayList<String>();

                    try {

                        if ( isUserExist( usernamesInOrg, userDetails.get( RBSDataSetupConstants.USERNAME ) ) ) {
                            String userId = new RBSUtils().getUserIDByUserName( userDetails.get( RBSDataSetupConstants.USERNAME ) );
                            Log.message( userDetails.get( RBSDataSetupConstants.USERNAME ) + "is already there in A&E! Loading the teacher details" );
                            localTeacherDetails.put( "Teacher" + teacherCount, new RBSUtils().getUserWithUserService( userId ) );
                        } else {
                            String userId = new RBSUtils().createUserByUserService( userDetails );
                            localTeacherDetails.put( "Teacher" + teacherCount, new RBSUtils().getUserWithUserService( userId ) );
                            Log.message( "Created Teacher - " + userDetails.get( RBSDataSetupConstants.USERNAME ) );
                            try {
                                //new RBSUtils().resetPassword( organizationIDs.get( school ), RBSDataSetupConstants.DEFAULT_PASSWORD, SMUtils.getKeyValueFromResponse( localTeacherDetails.get( "Teacher" + teacherCount ), "userId" ) );
                            } catch ( Exception e ) {
                                Log.message( "Username already exist ! Or issue in resetting password!" );
                            }
                        }
                        teacherDetails.put( "Teacher" + teacherCount, localTeacherDetails.get( "Teacher" + teacherCount ) );

                        //Creation of course for each teacher
                        String teacherBearertoken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( localTeacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                        String teacherUserId = SMUtils.getKeyValueFromResponse( localTeacherDetails.get( "Teacher" + teacherCount ), "userId" );
                        teacherRumbaIdsForExistingSchools.add( teacherUserId );

                        IntStream.rangeClosed( 1, studentCount ).forEach( studentCount -> {
                            HashMap<String, String> localStudentDetails = new HashMap<>();
                            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );

                            if ( isUITesting ) {
                                userDetails.put( RBSDataSetupConstants.USERNAME, String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ) + "_UI", currentSchool + 1, teacherCount, studentCount, usernameSuffixTest ) );
                            } else {
                                userDetails.put( RBSDataSetupConstants.USERNAME, String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ), currentSchool + 1, teacherCount, studentCount, usernameSuffixTest ) );
                            }
                            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, organizationIDs.get( school ) );

                            try {
                                if ( isUserExist( usernamesInOrg, userDetails.get( RBSDataSetupConstants.USERNAME ) ) ) {
                                    String userId = new RBSUtils().getUserIDByUserName( userDetails.get( RBSDataSetupConstants.USERNAME ) );
                                    Log.message( userDetails.get( RBSDataSetupConstants.USERNAME ) + "is already there in A&E! Loading the Student details" );
                                    String studentDetail = new RBSUtils().getUserWithUserService( userId );
                                    if ( Objects.nonNull( studentDetail ) ) {
                                        localStudentDetails.put( "Student" + studentCount, studentDetail );
                                    }
                                } else {
                                    Log.message( "Student - " + userDetails.get( RBSDataSetupConstants.USERNAME ) );
                                    String userId = new RBSUtils().createUserByUserService( userDetails );
                                    String studentDetail = new RBSUtils().getUserWithUserService( userId );
                                    if ( Objects.nonNull( studentDetail ) ) {
                                        localStudentDetails.put( "Student" + studentCount, studentDetail );
                                        try {
                                            HashMap<String, String> studentInfo = new HashMap<>();
                                            studentInfo = generateRequestValues( localStudentDetails.get( "Student" + studentCount ), studentInfo, UserConstants.SCHOOLID, organizationIDs.get( school ) );
                                            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                                            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERID ) );
                                            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN,
                                                    new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                                            Log.message( "Updating grade..." );
                                            new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
                                            // new RBSUtils().resetPassword( organizationIDs.get( school ), RBSDataSetupConstants.DEFAULT_PASSWORD, SMUtils.getKeyValueFromResponse( localStudentDetails.get( "Student" + studentCount ), "userId" ) );

                                        } catch ( Exception e ) {
                                            Log.message( "Username already exist! or issue in updating student grade!" );
                                        }
                                    }
                                }
                                studentDetails.put( "Student" + studentCount, localStudentDetails.get( "Student" + studentCount ) );
                                studentRumbaIdsForNonExistingSchools.add( SMUtils.getKeyValueFromResponse( localStudentDetails.get( "Student" + studentCount ), "userId" ) );
                            } catch ( Exception e ) {
                                e.printStackTrace();
                            }
                        } );

                        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( localTeacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERID ) );
                        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                        groupDetails.put( GroupConstants.STAFF_ID, SMUtils.getKeyValueFromResponse( teacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERID ) );

                        HashMap<String, String> groupListingForTeacherID = new GroupAPI().getGroupListingForTeacherID( smUrl, groupDetails );
                        deleteAllGroupUnderTeacher( groupListingForTeacherID.get( Constants.REPORT_BODY ), groupDetails.get( GroupConstants.GROUP_OWNER_ID ), groupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ),
                                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( localTeacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                        for ( int groupCount = 1; groupCount <= groupsCount; groupCount++ ) {
                            //Creating a group
                            String groupName = "Successmaker Group " + groupCount;
                            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherBearertoken );
                            groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERID ) );
                            groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                            groupDetails.put( GroupConstants.GROUP_NAME, groupName );
                            groupDetails.put( GroupConstants.STAFF_ID, SMUtils.getKeyValueFromResponse( teacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERID ) );

                            HashMap<String, String> createGroup = new HashMap<>();
                            boolean groupCreated = false;
                            createGroup = new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIdsForNonExistingSchools );
                            if ( createGroup.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                                groupIds.add( SMUtils.getKeyValueFromResponse( createGroup.get( Constants.REPORT_BODY ), "data,groupId" ) );
                                Log.message(
                                        "Group ( " + groupDetails.get( GroupConstants.GROUP_NAME ) + " ) created for the teacher " + SMUtils.getKeyValueFromResponse( localTeacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERNAME ) );
                                groupCreated = true;
                            }

                            int maxCount = 3; //To retry 3 times 
                            while ( !groupCreated && maxCount != 0 ) {
                                createGroup = new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIdsForNonExistingSchools );
                                if ( createGroup.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                                    groupIds.add( SMUtils.getKeyValueFromResponse( createGroup.get( Constants.REPORT_BODY ), "data,groupId" ) );
                                    Log.message( "Group ( " + groupDetails.get( GroupConstants.GROUP_NAME ) + " ) created for the teacher "
                                            + SMUtils.getKeyValueFromResponse( localTeacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERNAME ) );
                                    groupCreated = true;
                                    break;
                                } else {
                                    Thread.sleep( 5000 );
                                    Log.message( "groupDetails - " + groupDetails );
                                    Log.message( "studentRumbaIdsForExistingSchools - " + studentRumbaIdsForNonExistingSchools );
                                    Log.message( "Group creation is throwing error! Retrying - " + maxCount );
                                    maxCount--;
                                    if ( maxCount == 0 ) {
                                        errorTeacherDetails.put( "Teacher" + teacherCount, userDetails.get( RBSDataSetupConstants.USERNAME ) );
                                    }
                                }

                            }

                        }

                        if ( !isReportTestExecution ) {
                            //Custom Math and Reading Courses
                            if ( school.equalsIgnoreCase( getSchools( Schools.READING_SCHOOL ) ) ) {
                                courseIdsForNonExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.READING, teacherUserId, organizationIDs.get( school ), DataSetupConstants.SETTINGS,
                                        String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForNonExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.READING, teacherUserId, organizationIDs.get( school ), DataSetupConstants.SKILL,
                                        String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForNonExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.READING, teacherUserId, organizationIDs.get( school ), DataSetupConstants.STANDARD,
                                        String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                            } else if ( school.equalsIgnoreCase( getSchools( Schools.MATH_SCHOOL ) ) ) {
                                courseIdsForNonExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.MATH, teacherUserId, organizationIDs.get( school ), DataSetupConstants.SETTINGS,
                                        String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForNonExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.MATH, teacherUserId, organizationIDs.get( school ), DataSetupConstants.SKILL,
                                        String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForNonExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.MATH, teacherUserId, organizationIDs.get( school ), DataSetupConstants.STANDARD,
                                        String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                            } else if ( school.equalsIgnoreCase( getSchools( Schools.FLEX_SCHOOL ) ) ) {
                                courseIdsForNonExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.MATH, teacherUserId, organizationIDs.get( school ), DataSetupConstants.SETTINGS,
                                        String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForNonExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.MATH, teacherUserId, organizationIDs.get( school ), DataSetupConstants.SKILL,
                                        String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForNonExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.MATH, teacherUserId, organizationIDs.get( school ), DataSetupConstants.STANDARD,
                                        String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForNonExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.READING, teacherUserId, organizationIDs.get( school ), DataSetupConstants.SETTINGS,
                                        String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForNonExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.READING, teacherUserId, organizationIDs.get( school ), DataSetupConstants.SKILL,
                                        String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                                courseIdsForNonExistingSchools.add( coursesMethod.createCourse( smUrl, teacherBearertoken, DataSetupConstants.READING, teacherUserId, organizationIDs.get( school ), DataSetupConstants.STANDARD,
                                        String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, RandomStringUtils.randomAlphabetic( 5 ) ) ) );
                            }

                            //Assigning the assignment
                            if ( Boolean.FALSE.equals( courseIdsForNonExistingSchools.isEmpty() ) ) {
                                assignmentDeatilsForNewSchool.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                                assignmentDeatilsForNewSchool.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERID ) );
                                assignmentDeatilsForNewSchool.put( RBSDataSetupConstants.BEARER_TOKEN, teacherBearertoken );
                                assignmentMethod.assignMultipleAssignments( smUrl, assignmentDeatilsForNewSchool, studentRumbaIdsForNonExistingSchools, courseIdsForNonExistingSchools );
                            }
                        }

                        String tchUsernameValue = SMUtils.getKeyValueFromResponse( teacherDetails.get( "Teacher" + teacherCount ), RBSDataSetupConstants.USERNAME );
                        teacherStudentMap.put( tchUsernameValue, studentDetails );
                        Log.message( "Below Students are created successfully for the teacher - " + tchUsernameValue );
                        studentDetails.entrySet().stream().forEach( entry -> {
                            Log.message( SMUtils.getKeyValueFromResponse( entry.getValue(), RBSDataSetupConstants.USERNAME ) );
                        } );
                        teacherStudentRelation.put( school, teacherStudentMap );

                    } catch ( Exception e ) {
                        e.printStackTrace();
                    }
                } );

                teacherStudentRelationDuplicate.put( school, teacherStudentRelation );
                errorTeacherDetails.entrySet().stream().forEach( entry -> teacherDetails.remove( entry.getKey() ) );
                Log.message( "######## Below teachers had issue with creation #########\n" );
                errorTeacherDetails.entrySet().stream().forEach( entry -> System.out.print( entry.getValue() + ", " ) );
                Log.message( "######### Below Teachers are created successfully ###########\n" );
                teacherDetails.entrySet().stream().forEach( entry -> System.out.print( SMUtils.getKeyValueFromResponse( entry.getValue(), RBSDataSetupConstants.USERNAME ) + ", " ) );
                orgTeacherDetails.put( school, teacherDetails );
                orgStudentDetails.put( school, studentDetails );
                orgTeacherDetailsLocal.putAll( orgTeacherDetails );
                orgStudentDetailsLocal.putAll( orgStudentDetails );
                Collections.synchronizedMap( teacherStudentRelationDuplicate );
                Collections.synchronizedMap( orgTeacherDetailsLocal );
                Collections.synchronizedMap( orgStudentDetailsLocal );
            }

        } );
        createAdmins();
        adminDetails.put( Admins.DISTRICT_ADMIN, appendOrgIdInAdminDetails( new RBSUtils().getUserWithUserService( new RBSUtils().getUserIDByUserName( adminUserNames.get( Admins.DISTRICT_ADMIN ) ) ) ) );
        adminDetails.put( Admins.SCHOOL_ADMIN, appendOrgIdInAdminDetails( new RBSUtils().getUserWithUserService( new RBSUtils().getUserIDByUserName( adminUserNames.get( Admins.SCHOOL_ADMIN ) ) ) ) );
        adminDetails.put( Admins.MULTI_SCHOOL_ADMIN, appendOrgIdInAdminDetails( new RBSUtils().getUserWithUserService( new RBSUtils().getUserIDByUserName( adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN ) ) ) ) );
        adminDetails.put( Admins.SUBDISTRICTWITHOUTSCHOOL_ADMIN, appendOrgIdInAdminDetails( new RBSUtils().getUserWithUserService( new RBSUtils().getUserIDByUserName( adminUserNames.get( Admins.SUBDISTRICTWITHOUTSCHOOL_ADMIN ) ) ) ) );
        adminDetails.put( Admins.SUBDISTRICTWITHSCHOOL_ADMIN, appendOrgIdInAdminDetails( new RBSUtils().getUserWithUserService( new RBSUtils().getUserIDByUserName( adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ) ) ) ) );
        adminDetails.put( Admins.SAVVAS_ADMIN, appendOrgIdInAdminDetails( new RBSUtils().getUserWithUserService( new RBSUtils().getUserIDByUserName( adminUserNames.get( Admins.SAVVAS_ADMIN ) ) ) ) );

        try {
            resetPassword( adminUserNames );
        } catch ( Exception e ) {
            e.printStackTrace();
        }

        Log.message( "***Data setup ends here***" );
        long totalTime = StopWatch.elapsedTime( startTime );
        long sec = totalTime % 60;
        long min = ( totalTime / 60 );
        Log.message( "=====================================================" );
        Log.message( "Data Setup Ran for: " + min + " minute (s)" + ":" + sec + " seconds (s)" );

    }

    /**
     * To get the school Name
     *
     * @param schoolForTest
     * @return
     */
    public static String getSchools( Schools schoolForTest ) {
        try {

            return configProperty.getProperty( ConfigConstants.SM_SCHOOLS ).split( "," )[schoolForTest.ordinal()];
        } catch ( Exception e ) {
            Log.message( "Give all the schools required in config.properties! " );
            return null;
        }
    }

    /**
     * To get the Teacher from multiple class
     *
     * @param school
     * @return
     */
    public static String getMyTeacher( String school ) {
        AtomicReference<String> teacher = new AtomicReference<>();

        if ( ( school.length() > 0 ) ) {
            synchronized ( orgTeacherDetailsLocal.get( school ) ) {
                String accesstoken = null;
                do {
                    if ( orgTeacherDetailsLocal.get( school ).size() > 0 ) {
                        Map.Entry<String, String> entry = orgTeacherDetailsLocal.get( school ).entrySet().iterator().next();
                        teacher.set( entry.getValue() );
                        orgTeacherDetailsLocal.get( school ).remove( entry.getKey() );
                        try {
                            accesstoken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacher.get(), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                            if ( Objects.isNull( accesstoken ) ) {
                                throw new NullPointerException();
                            }
                        } catch ( NullPointerException e ) {
                            Log.event( "Unable to create the access token for the teacher - " + SMUtils.getKeyValueFromResponse( teacher.get(), RBSDataSetupConstants.USERNAME ) );
                            Log.event( "Trying to get another teacher in the same school!!!!" );
                        }
                    } else {
                        Log.message( "There is no enough teacher! Please increase the Teacher count" );
                        break;
                    }
                } while ( Objects.isNull( accesstoken ) );
            }
        } else {
            Log.failsoft( "School Name is empty!!!Please give the required school Names" );
        }
        return teacher.get();
    }

    /**
     * To get the students from school
     *
     * @param school
     * @return
     * @throws Exception
     */
    public static String getMyStudent( String school, String tchUsername ) {
        AtomicReference<String> student = new AtomicReference<>();

        if ( ( school.length() > 0 ) ) {
            synchronized ( teacherStudentRelation.get( school ).get( tchUsername ) ) {
                String accesstoken = null;
                String grade = null;
                do {
                    accesstoken = null;
                    grade = null;
                    if ( teacherStudentRelation.get( school ).get( tchUsername ).size() > 0 ) {
                        Map.Entry<String, String> entry = teacherStudentRelation.get( school ).get( tchUsername ).entrySet().iterator().next();
                        student.set( entry.getValue() );
                        teacherStudentRelation.get( school ).get( tchUsername ).remove( entry.getKey() );
                        orgTeacherDetailsLocal.get( school ).remove( entry.getKey() );
                        try {
                            accesstoken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( student.get(), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                            if ( Objects.isNull( accesstoken ) ) {
                                throw new NullPointerException();
                            }
                        } catch ( NullPointerException e ) {
                            Log.event( "Unable to create the access token for the student - " + SMUtils.getKeyValueFromResponse( student.get(), RBSDataSetupConstants.USERNAME ) );
                            Log.event( "Trying to get another student in the same school!!!!" );
                        }

                        try {
                            String user = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( student.get(), RBSDataSetupConstants.USERID ) );
                            grade = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( user, "userMetaData,grade" ), "defaultGradeLevel" );
                        } catch ( Exception e ) {
                            try {
                                String user = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( student.get(), RBSDataSetupConstants.USERID ) );
                                grade = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( user, "userMetaData,grade" ), "defaultGradeLevel" );
                            } catch ( Exception e1 ) {
                                Log.event( "Unable to get the grade for student - " + SMUtils.getKeyValueFromResponse( student.get(), RBSDataSetupConstants.USERID ) + ". -" + e1.getMessage() );
                            }
                        } finally {
                            boolean isGradeUpdated = false;
                            if ( Objects.nonNull( grade ) ) {
                                isGradeUpdated = !grade.equalsIgnoreCase( "OTHER" );
                            }

                            if ( isGradeUpdated ) {
                                HashMap<String, String> studentInfo = new HashMap<>();
                                studentInfo = generateRequestValues( student.get(), studentInfo, UserConstants.SCHOOLID, organizationIDs.get( school ) );
                                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, new RBSUtils().getUserIDByUserName( tchUsername ) );
                                try {
                                    studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( tchUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                                } catch ( Exception e ) {
                                    Log.message( "Unable to get the access token for the given teacher -" + tchUsername );
                                }
                                Log.message( "Updating grade..." );
                                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
                            }
                        }
                    } else {
                        Log.message( "There is no enough students! Please increase the Students count" );
                        break;
                    }
                } while ( Objects.isNull( accesstoken ) );
            }
        } else {
            Log.message( "School Name is empty!" );
        }

        return student.get();

    }

    /**
     * To create the multiple admins
     *
     * @return
     */
    public void createAdmins() {
        List<Boolean> isAdminsCreated = new ArrayList<>();
        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        String usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );

        //School Admin
        HashMap<String, String> adminDetails = new HashMap<>();
        adminDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, getSchools( Schools.FLEX_SCHOOL ) );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, organizationIDs.get( getSchools( Schools.FLEX_SCHOOL ) ) );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SCHOOL );
        adminDetails.put( RBSDataSetupConstants.USERNAME, String.format( RBSDataSetupConstants.SCHOOL_ADMIN_USERNAME, usernameSuffixTest ) );

        try {
            usernamesInOrg = new RBSUtils().getAllUserNamesFromOrg( adminDetails.get( RBSDataSetupConstants.ORGANIZATIONIDS ) );
            if ( !isUserExist( usernamesInOrg, adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) {
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.SCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                    Log.message( "Created School Admin - " + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                } else {
                    Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                    if ( new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) ) ) {
                        Log.message( "Deleted admin -" + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    }
                    new RBSUtils().createCAUserWithAccess( adminDetails, true );
                    adminUserNames.put( Admins.SCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );

                }
            } else {
                Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                adminUserNames.put( Admins.SCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                if ( new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) ) ) {
                    Log.message( "Deleted admin -" + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                }
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.SCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                }
            }
        } catch ( Exception e1 ) {
            e1.printStackTrace();
            isAdminsCreated.add( false );
        }

        //Multi-school admin
        adminDetails.put( RBSDataSetupConstants.USERNAME, String.format( RBSDataSetupConstants.MULTI_SCHOOL_ADMIN_USERNAME, usernameSuffixTest ) );
        try {
            usernamesInOrg = new RBSUtils().getAllUserNamesFromOrg( adminDetails.get( RBSDataSetupConstants.ORGANIZATIONIDS ) );
            if ( !isUserExist( usernamesInOrg, adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) {
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.MULTI_SCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                    new RBSUtils().resetPassword( new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim(), getSchools( Schools.FLEX_SCHOOL ) ), RBSDataSetupConstants.DEFAULT_PASSWORD,
                            new RBSUtils().getUserIDByUserName( adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN ) ) );
                    List<String> orgIds = new ArrayList<>();
                    orgIds.add( organizationIDs.get( getSchools( Schools.FLEX_SCHOOL ) ) );
                    new RBSUtils().updateUserOrgId( new RBSUtils().getUserWithUserService( new RBSUtils().getUserIDByUserName( adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN ) ) ), RBSDataSetupConstants.ADMIN_ROLE, orgIds );
                    Log.message( "Created Multi School Admin - " + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                } else {
                    Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                    if ( new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) ) ) {
                        Log.message( "Deleted admin -" + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    }
                    new RBSUtils().createCAUserWithAccess( adminDetails, true );
                    adminUserNames.put( Admins.MULTI_SCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                }
            } else {
                Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                adminUserNames.put( Admins.MULTI_SCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                if ( new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) ) ) {
                    Log.message( "Deleted admin -" + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                }
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.MULTI_SCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                }
            }
        } catch ( Exception e1 ) {
            e1.printStackTrace();
            isAdminsCreated.add( false );
        }

        //District admin creation
        String districtDetails = new RBSUtils().getOrg( configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim() );
        String districtName = SMUtils.getKeyValueFromResponse( districtDetails, RBSDataSetupConstants.NAME );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, districtName );
        adminDetails.put( RBSDataSetupConstants.USERNAME, String.format( RBSDataSetupConstants.DISTRICT_ADMIN_USERNAME, usernameSuffixTest ) );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim() );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_DISTRICT );

        try {
            usernamesInOrg = new RBSUtils().getAllUserNamesFromOrg( adminDetails.get( RBSDataSetupConstants.ORGANIZATIONIDS ) );
            if ( !isUserExist( usernamesInOrg, adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) {
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.DISTRICT_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                    Log.message( "Created District Admin - " + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                } else {
                    Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                    if ( new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) ) ) {
                        Log.message( "Deleted admin -" + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    }
                    new RBSUtils().createCAUserWithAccess( adminDetails, true );
                    adminUserNames.put( Admins.DISTRICT_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );

                }
            } else {
                Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                adminUserNames.put( Admins.DISTRICT_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) );
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.DISTRICT_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                }
            }
        } catch ( Exception e1 ) {
            e1.printStackTrace();
            isAdminsCreated.add( false );
        }

        //Sub District admin creation
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, subDistrictwithoutSchool );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, subDistrictwithoutSchoolId );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SUBDISTRICT );
        adminDetails.put( RBSDataSetupConstants.USERNAME, String.format( RBSDataSetupConstants.SUBDISTRICT_ADMIN_USERNAME, usernameSuffixTest ) );

        try {
            usernamesInOrg = new RBSUtils().getAllUserNamesFromOrg( adminDetails.get( RBSDataSetupConstants.ORGANIZATIONIDS ) );
            if ( !isUserExist( usernamesInOrg, adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) {
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.SUBDISTRICTWITHOUTSCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                    Log.message( "Created SubDistrict Admin - " + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                } else {
                    if ( new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) ) ) {
                        Log.message( "Deleted admin -" + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    }
                    new RBSUtils().createCAUserWithAccess( adminDetails, true );
                    adminUserNames.put( Admins.SUBDISTRICTWITHOUTSCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                    Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                }
            } else {
                Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                adminUserNames.put( Admins.SUBDISTRICTWITHOUTSCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) );
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    Log.message( "Created SubDistrict Admin - " + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    adminUserNames.put( Admins.SUBDISTRICTWITHOUTSCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                }
            }
        } catch ( Exception e1 ) {
            e1.printStackTrace();
            isAdminsCreated.add( false );
        }

        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, subDistrictwithSchool );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, subDistrictwithSchoolId );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SUBDISTRICT );
        adminDetails.put( RBSDataSetupConstants.USERNAME, String.format( RBSDataSetupConstants.SUBDISTRICT_WITH_SCHOOL_ADMIN_USERNAME, usernameSuffixTest ) );

        try {
            usernamesInOrg = new RBSUtils().getAllUserNamesFromOrg( adminDetails.get( RBSDataSetupConstants.ORGANIZATIONIDS ) );
            if ( !isUserExist( usernamesInOrg, adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) {
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.SUBDISTRICTWITHSCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                    Log.message( "Created SubDistrict Admin - " + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                } else {
                    Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                    new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) );
                    new RBSUtils().createCAUserWithAccess( adminDetails, true );
                    adminUserNames.put( Admins.SUBDISTRICTWITHSCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                }
            } else {
                Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                adminUserNames.put( Admins.SUBDISTRICTWITHSCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                if ( new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) ) ) {
                    Log.message( "Deleted admin -" + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                }
                if ( new RBSUtils().createCAUserWithAccess( adminDetails, true ) ) {
                    adminUserNames.put( Admins.SUBDISTRICTWITHSCHOOL_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                }
            }
        } catch ( Exception e1 ) {
            e1.printStackTrace();
            isAdminsCreated.add( false );
        }

        //Savvas Admin
        HashMap<String, String> userDetails = new HashMap<>();
        districtDetails = new RBSUtils().getOrg( configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim() );
        districtName = SMUtils.getKeyValueFromResponse( districtDetails, RBSDataSetupConstants.NAME );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, districtName );
        adminDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );
        adminDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.PEARSON_ADMIN_ROLE );
        adminDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim() );
        adminDetails.put( RBSDataSetupConstants.USERNAME, String.format( RBSDataSetupConstants.SAVVAS_ADMIN_USERNAME, usernameSuffixTest ) );
        try {
            usernamesInOrg = new RBSUtils().getAllUserNamesFromOrg( adminDetails.get( RBSDataSetupConstants.ORGANIZATIONIDS ) );
            if ( !isUserExist( usernamesInOrg, adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) {
                if ( !new RBSUtils().createUser( adminDetails ).trim().equals( "" ) ) {
                    adminUserNames.put( Admins.SAVVAS_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    isAdminsCreated.add( true );
                    Log.message( "Created Savvas Admin - " + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                } else {
                    Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                    if ( new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) ) ) {
                        Log.message( "Deleted admin -" + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    }
                    if ( !new RBSUtils().createUser( adminDetails ).trim().equals( "" ) ) {
                        isAdminsCreated.add( true );
                        Log.message( "Created Savvas Admin - " + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                    }
                    adminUserNames.put( Admins.SAVVAS_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                }
            } else {
                Log.message( adminDetails.get( RBSDataSetupConstants.USERNAME ) + " is already there! Loading the details" );
                if ( new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( adminDetails.get( RBSDataSetupConstants.USERNAME ) ) ) ) ) {
                    Log.message( "Deleted admin -" + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                }
                if ( !new RBSUtils().createUser( adminDetails ).trim().equals( "" ) ) {
                    isAdminsCreated.add( true );
                    Log.message( "Created Savvas Admin - " + adminDetails.get( RBSDataSetupConstants.USERNAME ) );
                }
                adminUserNames.put( Admins.SAVVAS_ADMIN, adminDetails.get( RBSDataSetupConstants.USERNAME ) );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    public static void resetPassword( HashMap<Admins, String> adminDetails ) throws Exception {
        new RBSUtils().resetPassword( configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim(), RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( adminDetails.get( Admins.DISTRICT_ADMIN ) ) );
        new RBSUtils().resetPassword( organizationIDs.get( getSchools( Schools.FLEX_SCHOOL ) ), RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( adminDetails.get( Admins.SCHOOL_ADMIN ) ) );
        new RBSUtils().resetPassword( configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim(), RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( adminDetails.get( Admins.MULTI_SCHOOL_ADMIN ) ) );
        new RBSUtils().resetPassword( subDistrictwithoutSchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( adminDetails.get( Admins.SUBDISTRICTWITHOUTSCHOOL_ADMIN ) ) );
        new RBSUtils().resetPassword( subDistrictwithSchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ) ) );
        new RBSUtils().resetPassword( configProperty.getProperty( ConfigConstants.DISTRICT_ID ).trim(), RBSDataSetupConstants.DEFAULT_PASSWORD, new RBSUtils().getUserIDByUserName( adminDetails.get( Admins.SAVVAS_ADMIN ) ) );
    }

    /**
     * To add the License to school
     *
     * @param school
     * @param schoolID
     * @throws Exception
     */
    public static void addLicenseToSchool( String school, String schoolID ) throws Exception {
        if ( school.equalsIgnoreCase( getSchools( Schools.MATH_SCHOOL ) ) ) {
            new RBSUtils().addSuccessmakerLicense( schoolID, CommonAPIConstants.MATH, CommonAPIConstants.LICENSE_COUNT );
        } else if ( school.equalsIgnoreCase( getSchools( Schools.READING_SCHOOL ) ) ) {
            new RBSUtils().addSuccessmakerLicense( schoolID, CommonAPIConstants.READING, CommonAPIConstants.LICENSE_COUNT );
        } else if ( school.equalsIgnoreCase( getSchools( Schools.MATH_FOCUS_SCHOOL ) ) ) {
            new RBSUtils().addSuccessmakerLicense( schoolID, CommonAPIConstants.MATH_FOCUS, CommonAPIConstants.LICENSE_COUNT );
        } else if ( school.equalsIgnoreCase( getSchools( Schools.READING_FOCUS_SCHOOL ) ) ) {
            new RBSUtils().addSuccessmakerLicense( schoolID, CommonAPIConstants.READING_FOCUS, CommonAPIConstants.LICENSE_COUNT );
        } else {
            new RBSUtils().addSuccessmakerLicense( schoolID, CommonAPIConstants.FLEX, CommonAPIConstants.LICENSE_COUNT );
        }
    }

    public static HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value ) {

        HashMap<String, String> generatedStudentDetails = newDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

        return generatedStudentDetails;
    }

    /**
     * To verify the user exist in A&E
     * 
     * @param usernames
     * @param username
     * @return
     */
    public static boolean isUserExist( List<String> usernames, String username ) {
        boolean isUserExist = false;
        for ( String usernameTemp : usernames ) {
            if ( usernameTemp.equalsIgnoreCase( username ) ) {
                isUserExist = true;
            }
        }
        return isUserExist;
    }

    /**
     * To verify the group is exist under user
     * 
     * @param groupListingForTeacherID
     * @param groupName
     * @return
     */
    public boolean isGroupExistUnderTeacher( String groupListingForTeacherID, String groupName ) {
        boolean isGroupExist = false;

        JSONObject groups = new JSONObject( groupListingForTeacherID );
        JSONArray groupArray = new JSONArray();
        try {
            groupArray = groups.getJSONArray( Constants.DATA );

            for ( Object group : groupArray ) {
                JSONObject groupdetails = new JSONObject( group.toString() );
                String groupNameValue = groupdetails.getString( "groupName" );
                if ( groupNameValue.equalsIgnoreCase( groupName ) ) {
                    isGroupExist = true;
                    break;
                }
            }
        } catch ( Exception e ) {
            Log.message( "No Groups present under teacher!" );
            isGroupExist = false;
        }

        return isGroupExist;
    }

    public void deleteAllGroupUnderTeacher( String groupListingForTeacherID, String groupOwnerId, String GroupOwnerOrgID, String token ) {
        JSONObject groups = new JSONObject( groupListingForTeacherID );

        try {
            JSONArray groupArray = groups.getJSONArray( Constants.DATA );
            for ( Object group : groupArray ) {
                JSONObject groupdetails = new JSONObject( group.toString() );
                new GroupAPI().deleteGroup( groupdetails.getString( "groupId" ), groupOwnerId, GroupOwnerOrgID, token );
            }
            Log.message( "Deleted all groups under teacher!" );
        } catch ( Exception e ) {
            Log.message( "No Group present under teacher!" );
        }
    }

    /**
     * Get the group by group name
     * 
     * @param groupListingForTeacherID
     * @param groupName
     * @return
     */
    public String getGroupIdByGroupNameUnderTeacher( String groupListingForTeacherID, String groupName ) {
        String groupId = null;
        JSONObject groups = new JSONObject( groupListingForTeacherID );

        JSONArray groupArray = groups.getJSONArray( Constants.DATA );

        for ( Object group : groupArray ) {
            JSONObject groupdetails = new JSONObject( group.toString() );
            String groupNameValue = groupdetails.getString( "groupName" );
            if ( groupNameValue.equalsIgnoreCase( groupName ) ) {
                groupId = groupdetails.getString( "groupId" );
                break;
            }
        }

        return groupId;
    }

    /**
     * To append the primaryOrgId and primaryOrgIds in the admin details
     * 
     * @param adminDetails
     * @return
     */
    private String appendOrgIdInAdminDetails( String adminDetails ) {
        JSONArray affiliationArray = new JSONObject( adminDetails ).getJSONArray( "affiliationInfo" );
        List<String> orgIds = new ArrayList<>();
        affiliationArray.forEach( jsonObject -> orgIds.add( SMUtils.getKeyValueFromResponse( jsonObject.toString(), "organizationId" ) ) );

        JSONObject jsonObject = new JSONObject( adminDetails );
        jsonObject.put( "primaryOrgId", orgIds.get( 0 ) );
        jsonObject.put( "primaryOrgIds", orgIds );
        return jsonObject.toString();
    }

}
