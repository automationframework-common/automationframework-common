package com.savvas.sm.ui.pages.login;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.StopWatch;
import com.savvas.sm.utils.SMUtils;

/**
 * EBPlus And Auto LoginPage is used for SM teacher, student and admin. District
 * will only appear in Auto login page if it has a supported Pearson
 * integration.
 * 
 */

public class EBPlusAndAutoDistrictPage extends LoadableComponent<EBPlusAndAutoDistrictPage> {

    private final WebDriver driver;
    private boolean isPageLoaded;
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    // *************** Input fields in EBPlus And AutoLoginPage ****************
    @FindBy ( id = "orgName" )
    WebElement fldDistrict;

    @FindBy ( css = "ul:not([class*='hide'])[class*='dropdown-menu'] li a" )
    List<WebElement> drpDistrict;

    @FindBy ( className = "btn-submit" )
    WebElement btnGo;

    // ******************Input fields in CAT login page ************************
    @FindBy ( id = "username" )
    WebElement fldUserName;

    @FindBy ( id = "password" )
    WebElement fldPassword;

    @FindBy ( className = "btn-submit" )
    WebElement btnSignIn;

    // psn
    @FindBy ( linkText = "Sign in as a Teacher" )
    WebElement lnkSignInAsTeacher;

    @FindBy ( linkText = "Sign in as a Student" )
    WebElement lnkSignInAsStudent;

    /**
     * constructor of the class
     * 
     * @param driver
     */
    public EBPlusAndAutoDistrictPage( WebDriver driver ) {

        this.driver = driver;
        PageFactory.initElements( driver, this );
    }

    @Override
    protected void isLoaded() {

        if ( !isPageLoaded ) {
            Assert.fail();
        }

        if ( !driver.getCurrentUrl().toLowerCase().contains( "sso.view" ) ) {
            Log.fail( "EBPlus & Auto Login Page did not open up. Site might be down.", driver );
        }

    }

    @Override
    protected void load() {
        isPageLoaded = true;
    }

    /**
     * To accept SSL Certification Error
     */
    public void acceptSSLCertificationError() {

        // If IE browser ignoring the certificate warning by clicking the
        // continue link
        if ( ( configProperty.getProperty( "BrowserPlatformToRun" ).matches( ".*explore.*" ) ) ) {
            try {
                if ( driver.getTitle().contains( "Certificate Error: Navigation Blocked" ) ) {
                    driver.get( "javascript:document.getElementById('overridelink').click();" );
                }
            } catch ( Exception e ) {
                Log.event( "Override link not found, no certification issues" );
            }
        } else if ( ( configProperty.getProperty( "BrowserPlatformToRun" ).matches( ".*firefox.*" ) ) ) {
            try {
                if ( driver.getTitle().contains( "Warning: Potential Security Risk Ahead" ) ) {
                    driver.get( "javascript:document.getElementById('advancedButton').click();" );
                    driver.get( "javascript:document.getElementById('exceptionDialogButton').click();" );
                }
            } catch ( Exception e ) {
                Log.event( "Override link not found, no certification issues" );
            }
        } else if ( ( ( configProperty.getProperty( "BrowserPlatformToRun" ).toLowerCase().matches( ".*edge.*" ) ) ) ) {
            try {
                if ( driver.getTitle().contains( "Certificate error" ) ) {
                    driver.get( "javascript:document.getElementById('invalidcert_continue').click();" );
                }
            } catch ( Exception e ) {
                Log.event( "Continue link not found, no certification issues" );
            }
        } else if ( ( configProperty.getProperty( "BrowserPlatformToRun" ).toLowerCase().matches( ".*safari.*" ) ) ) {
            driver.switchTo().alert().accept();
        } else if ( ( configProperty.getProperty( "BrowserPlatformToRun" ).toLowerCase().matches( ".*chrome.*" ) ) ) {
            try {
                if ( driver.getTitle().contains( "Privacy error" ) ) {
                    ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('details-button').click();" );
                    ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('proceed-link').click();" );
                }
            } catch ( Exception e ) {
                Log.event( "Privacy error, cannot continue to powerschool login page" );
            }
        }
    }

    // ************* Methods to enter and select the values in Auto login page
    // *********************
    /**
     * To enter the district name in district field on EBPlus And Auto login
     * Page
     * 
     * @param districtName as string
     * @param screenshot
     */
    public void enterDistrictName( String districtName, boolean screenshot ) {
        SMUtils.fluentWaitForElement( driver, fldDistrict );
        fldDistrict.clear();
        fldDistrict.sendKeys( districtName );
        if ( drpDistrict.size() > 0 )
            SMUtils.waitForElement( driver, drpDistrict.get( 0 ) );
        Log.message( "Entered the District Name: '" + districtName + "'", driver, screenshot );
    }

    /**
     * To Select given district from District dropdown
     * 
     * @param districtName
     * @param screenshot to capture screenshot
     * @throws Exception
     */

    public void selectDistrictFromDropDown( String districtName, boolean screenshot ) throws Exception {
        SMUtils.fluentWaitForElement( driver, fldDistrict );
        boolean found = false;
        SMUtils.nap( 1 );
        for ( WebElement element : drpDistrict ) {
            if ( element.getAttribute( "title" ).equals( districtName ) ) {
                element.click();
                Log.message( "Selected '" + districtName + "' in District dropdown", driver, screenshot );
                found = true;
                break;
            }
        }
        if ( !found ) {
            throw new Exception( "District " + districtName + " is not found in the District dropdown" );
        }
    }

    /**
     * To click the Go button on EBPlus & Auto Login Page
     * 
     * @param screenshot
     */
    public void clickGoButton( boolean screenshot ) {
        Log.event( "Clicking 'Go' button on EBPlus& Auto LoginPage" );
        SMUtils.fluentWaitForElement( driver, btnGo );
        SMUtils.click( driver, btnGo );
        Log.message( "Clicked 'Go' button on EBPlus & Auto LoginPage", driver, screenshot );
    }

    /**
     * Selects the given district and navigates to sign in page
     * 
     * @param districtName
     * @return
     */
    public EBPlusAndAutoSignInPage chooseDistrict( String districtName ) {
        try {
            enterDistrictName( districtName, true );
            selectDistrictFromDropDown( districtName, true );
            clickGoButton( false );
        } catch ( Exception e ) {

        }
        return new EBPlusAndAutoSignInPage( driver ).get();
    }

    /**
     * Selects the given plus district and navigates to sign in page
     * 
     * @param districtName
     * @return
     */
    public PowerSchoolSsoPage chooseDistrictName( String districtName ) {
        try {
            enterDistrictName( districtName, true );
            selectDistrictFromDropDown( districtName, true );
            clickGoButton( false );
        } catch ( Exception e ) {

        }
        return new PowerSchoolSsoPage( driver ).get();
    }

    /**
     * Clicks on SignIn as teacher link
     * 
     * @param screenshot
     */
    public void clickSignInAsTeacher( boolean screenshot ) {

        Log.event( "Clicked on 'Sign in as a Teacher' link" );
        lnkSignInAsTeacher.click();
        Log.message( "Clicked on 'Sign in as a Teacher' link", driver, screenshot );
    }

    /**
     * Clicks on SignIn as Student link
     * 
     * @param screenshot
     */
    public void clickSignInAsStudent( boolean screenshot ) {

        Log.event( "Clicked on 'Sign in as a Student' link" );
        lnkSignInAsStudent.click();
        Log.message( "Clicked on 'Sign in as a Student' link", driver, screenshot );
    }

    /**
     * To click the sign in button on CAT login page
     * 
     * @param screenshot
     */
    public void clickSignInButtonWithoutLoad( boolean screenshot ) {
        Log.event( "Clicking on 'SignIn' button on CAT Login Page" );
        final long startTime = StopWatch.startTime();
        SMUtils.fluentWaitForElement( driver, btnSignIn );
        SMUtils.click( driver, btnSignIn );

        Log.event( "Clicked on 'SignIn' button on CAT Login Page", StopWatch.elapsedTime( startTime ) );
        Log.message( "Clicked on 'SignIn' button on CAT Login Page", driver, screenshot );
    }

    /**
     * @param districtName district name to get suggestion
     * @param screenshot true to take screenshot
     * @throws Exception
     * @return true if dropdown appears and contains the district name
     */
    public boolean verifyDistrictNameSuggestionInDropdown( String districtName, boolean screenshot ) throws Exception {
        boolean status = false;
        try {
            Log.event( "Verifying district name suggestions shows in dropdown" );
            for ( WebElement element : drpDistrict ) {
                if ( element.getAttribute( "title" ).contains( districtName ) ) {
                    Log.event( "District names suggestions are shown in dropdown" );
                    status = true;
                    break;
                }
            }
        } catch ( Exception e ) {
            Log.event( "Dropdown didnt showed up" );
        }

        return status;
    }

}