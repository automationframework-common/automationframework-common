package com.savvas.sm.utils.sme187.teacher.api.reports;

public interface GetGroupAndStudentDetailsConstant {

    String GROUP_AND_STUDENT_DETAILS_ENDPOINT = "/graphql";

}