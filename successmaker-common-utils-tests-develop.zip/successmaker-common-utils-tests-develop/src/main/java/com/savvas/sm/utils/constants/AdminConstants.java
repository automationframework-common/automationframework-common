package com.savvas.sm.utils.constants;

import com.learningservices.utils.EnvironmentPropertiesReader;

public interface AdminConstants {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    String GET_HOLIDAY_SCHEDULER = "/lms/web/api/v1/holidayScheduler/getHolidays";
    String PUT_HOLIDAY_SCHEDULER = "/lms/web/api/v1/holidayScheduler/addHolidays";
    String DELETE_HOLIDAY_SCHEDULER = "/lms/web/api/v1/holidayScheduler/deleteHolidays";
    String GET_CHILD_ORGANIZATIONS = "/lms/web/api/v1/organizations/getChildren";
    String GET_SHARED_COURSE = "/lms/web/api/v1/sharedCourse";
    String CUSTOM_COURSE = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/copy";
    String DELETE_COURSE_API = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}";
    String GET_SHARED_COURSE_ORG_LIST = "/lms/web/api/v1/sharedCourse/courseId/{courseId}";
    String POST_ORGANIZATION_USAGE = "/lms/web/api/v1/organizationStudentUsage";
    String GET_SHARE_COURSE = "/lms/web/api/v1/sharedCourse";
    String GET_COURSE_LISTING = "/lms/web/api/v1/admin/courses";
    //HolidayScheduler
    String START_DATE = "startDate";
    String END_DATE = "endDate";
    String DESCRIPTION = "description";

    //ShareCourse
    String ORGANIZATION_IDS = "organizationIds";
    String COURSE_ID = "courseId";
    String ID = "id";
    String OWNER_ORG_ID = "ownerOrgId";
    String SHARED_ORG_COUNT = "sharedOrgCount";
    String OWNER_ORG_NAME = "ownerOrgName";
    String COURSE_NAME = "courseName";
    String SUBJECT_TYPE_ID = "subjectTypeId";
    String SELECTED_ORGANIZATION_ID = "selectedOrgId";
    //Organization Usage
    String STUDENTIDS = "studentIds";

    //Organization Usage goal
    String POST_ORGANIZATION_USAGE_GOAL = "/lms/web/api/v1/adminUsageGoals";
    String POST_PERFORMANCE_REPORT = "/lms/web/api/v1/adminProgressMonitoring?subjectTypeId=%s";

    //Organization Performance API Endpoint
    String POST_ADMIN_ORGANIZATION_PERFORMACE = "/lms/web/api/v1/mastery/adminPerformanceDetails";

    enum Subject {
        MATH,
        READING
    }

    enum CourseType {
        SKILLS,
        STANDARDS,
        SETTINGS
    }

    // BFF Payload
    String ADMIN_DASHBOARD_BFF = configProperty.getProperty( "AdminDashboardBFF" );
    String SHARED_COURSE_BFF = configProperty.getProperty( "SharedCourseBFF" );
    String ADMIN_REPORT_BFF = configProperty.getProperty( "AdminReportBFF" );
    String GRAPHQL_ENDPOINT = "/graphql";
    String SHARED_COURSE_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n getSharedCourseList(\\n userId: \\\"{userID}\\\"\\n selectedOrgId: \\\"{selectedOrgId}\\\"\\n organizationId: \\\"{organizationId}\\\"\\n ) {queryItem}\\n}\\n\"}";
    String INSTANCE_URL = "{instanceUrl}";
    String QUERY_ITEM = "{queryItem}";
    String COURSE_SHARED_ORGANIZATIONS_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n getCourseSharedOrganization(\\n userId: \\\"{userID}\\\"\\n selectedOrgId: \\\"{selectedOrgId}\\\"\\n organizationId: \\\"{organizationId}\\\"\\n courseId: \\\"{courseId}\\\"\\n ) {queryItem}\\n}\\n\"}";

    String DELETED_BY = "deletedBy";
    String EDIT_SHARED_COURSE_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\" mutation {\\n saveSharedCourses(\\n userId: \\\"{userID}\\\"\\n selectedOrgId:\\\"{selectedOrgId}\\\"\\n organizationId: \\\"{organizationId}\\\"\\n courseId: \\\"{courseId}\\\"\\n sharedOrgIds: [{sharedOrgIds}]\\n) {queryItems}\\n}\\n\"}";
    String SHARED_ORG_IDS = "{sharedOrgIds}";
    String COUNT = "{count}";
    String TOTAL_RECORDS = "totalRecords";
    String QUERY_ITEMS = "queryItems";
    String USER_LIST = "userList";
    String GRADE = "grade";
    String GRADE_NAME = "gradeName";

    // BFF payload for Audit History
    String GET_AUDIT_HISTORY_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n getAssignmentAudits(\\n selectedOrgId: \\\"{selectedOrgId}\\\"\\n userId: \\\"{userID}\\\"\\n organizationId: \\\"{organizationId}\\\"\\n ) {queryItem}\\n}\\n\"}";
    String SELECTED_ORG_ID = "{selectedOrgId}";
    String SAVE_HOLIDAY_SCHEDULER_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\" mutation {\\n saveHolidayScheduler(\\n subRoleType: \\\"{subRoleType}\\\"\\n selectedOrgId : \\\"{selectedOrgId}\\\"\\n userId: \\\"{userID}\\\"\\n organizationId: \\\"{organizationId}\\\"\\n saveHolidayData: [holidayData]\\n) {{queryItem}}\\n}\\n\"}";
    String GET_HOLIDAY_SCHEDULER_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n getHolidayScheduler(\\n subRoleType: \\\"{subRoleType}\\\"\\n selectedOrgId : \\\"{selectedOrgId}\\\"\\n  userId: \\\"{userID}\\\"\\n organizationId: \\\"{organizationId}\\\"\\n ) {queryItem}\\n}\\n\"}";
    String DELETE_HOLIDAY_SCHEDULER_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\" mutation {\\n deleteHolidayScheduler(\\n subRoleType: \\\"{subRoleType}\\\"\\n  selectedOrgId : \\\"{selectedOrgId}\\\"\\n userId: \\\"{userID}\\\"\\n organizationId: \\\"{organizationId}\\\"\\n deleteHolidayData: [holidayData]\\n) {{queryItem}}\\n}\\n\"}";
    String SUBROLETYPE_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getSubOrgRoleType(\\n    userId: \\\"{userID}\\\"\\n    organizationId: \\\"{orgID}\\\"\\n  selectedOrgId: \\\"{selectedOrgId}\\\"\\n  role: \\\"{role}\\\"\\n  ) {\\n    subRoleType\\n  }\\n}\\n\"}";
    // BFF payload for Organization Listing
    String GET_ORGANIZATION_LIST_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n getOrganizationList(\\n userId: \\\"{userID}\\\"\\n organizationId: \\\"{organizationId}\\\"\\n selectedOrgId: \\\"{selectedOrgId}\\\"\\n) {queryItem}\\n}\\n\"}";

    //Organization usage
    String ORGANIZATION_USAGE_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getOrganizationUsage(\\n    selectedOrg: \\\"{selectedOrgId}\\\"\\n   userId: \\\"{userID}\\\"\\n    organizationId: \\\"{organizationId}\\\"\\n  ) {\\n    lastWeekMins\\n    thisWeekMins\\n    totalMinutes\\n    studentUsageData {\\n      week\\n      mathMins\\n      readingMins\\n    }\\n  }\\n}\\n\"}";
    String ORGANIZATION_USAGE_GOAL_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getUsageGoals(\\n    selectedOrg: \\\"{selectedOrgId}\\\"\\n   userId: \\\"{userID}\\\"\\n    organizationId: \\\"{organizationId}\\\"\\n  ) {\\n    math {\\n  totalStudentsOnTrack\\n      totalStudentsOnTrackPercentage\\n      totalStudentsToWatchClosely\\n      totalStudentsToWatchCloselyPercentage\\n      totalStudentsFallingBehind\\n      totalStudentsFallingBehindPercentage\\n  }\\n    reading {\\n   totalStudentsOnTrack\\n      totalStudentsOnTrackPercentage\\n      totalStudentsToWatchClosely\\n      totalStudentsToWatchCloselyPercentage\\n      totalStudentsFallingBehind\\n      totalStudentsFallingBehindPercentage\\n  }\\n  }\\n}\\n\"}";

    // MSDA Settings
    String GET_MSDA_SETTINGS_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n getMSDAOrgList(\\n userId: \\\"{userID}\\\"\\n  selectedOrgId: \\\"{selectedOrgId}\\\"\\n organizationId: \\\"{organizationId}\\\"\\n ) {\\n organizationId \\n organizationName \\n orgSettings {\\n isDiagnosticEnabled \\n isAutoAssignEnabled \\n } \\n } \\n}\\n\"}";
    String SAVE_MSDA_SETTINGS_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"mutation{\\nsaveMSDADiagnosticSettings(\\nmsdaSettings:[MSDASettings]\\nuserId:\\\"{userID}\\\"\\n){\\norganizationId\\nmessage\\n}\\n}\\n\"}";
    String IS_DIAGNOSTIC_ENABLED = "isDiagnosticEnabled";
    String IS_AUTO_ASSIGN_ENABLED = "isAutoAssignEnabled";

    // BFF Payload for grade listing
    String GRADE_LISTING_BFF = "https://successmaker-report-bff-service-nightly.smdemo.info";
    String GET_GRADE_LISTING_PAYLOAD = "query {\r\n  getOptionalFilters(\r\n    userId: \"ffffffff626280dcbcb4bb002f1eacce\"\r\n    orgIds: [\r\n      \"8a72008680f2e2fb0180fb0ac2cd011d\"\r\n    ]\r\n  ) {\r\n      grades {\r\n      gradeName\r\n      gradeId\r\n      displayOrder\r\n      gradeValue\r\n    }\r\n  }\r\n}\r\n";
    String INVALID_INPUT = "ABCD";

    // Restore assignment
    String SAVE_RESTORE_ASSIGNMENT_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\" mutation {\\n saveRestoreAssignments(\\n assignmentUserId: {assignmentUserId} \\n userId: \\\"{userID}\\\"\\n selectedOrgId: \\\"{selectedOrgId}\\\"\\n organizationId: \\\"{organizationId}\\\"\\n ) {status}\\n}\\n\"}";
    String ASSIGNMENT_USER_ID = "{assignmentUserId}";
    String GET_RESTORE_ASSIGNMENT_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n getRestoreAssignments(\\n selectedOrgId:\\\"{selectedOrgId}\\\"\\n userId:\\\"{userID}\\\"\\n organizationId:\\\"{organizationId}\\\"\\n){\\n assignmentName\\n assignmentUserId\\n deletedDate\\n createdDate\\n studentFirstName\\n studentLastName\\n teacherFirstName\\n teacherLastName\\n studentUsername\\n}\\n}\\n\"}";

    String AFFILIATION_INFO = "tns:AffiliationInfo";
    String ORG_ROLE = "tns:OrgRole";
    String FILTER_QUERY_REPORT = "{\"query\":\"query {  getOptionalFilters( userId:\\\"%s\\\" ,  orgIds: [  \\\"";
    String TEACHER_FILTER = "] ) {    teachers {     userId      userName     firstName         lastName }}}\",\"variables\": {}}";

    // Report query 
    String COURSE_LISTING_DB_QUERY_FILENAME = "gerCourseForOrg.sql";
    String DEFAULT_COURSE_LISTING_DB_QUERY_FILENAME = "getDefaultCourseForStudent.sql";

    //Performance Report
    String PERFORMANCE_REPORT_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getPerformanceReport(\\n    subjectTypeId: {subjectTypeId}\\n    selectedOrg: \\\"{selectedOrgId}\\\"\\n    userId: \\\"{userID}\\\"\\n    organizationId: \\\"{organizationId}\\\"\\n  ) {\\n    grade_k {\\n      currentLevel\\n      ipLevel\\n      gain\\n    }\\n    grade_1 {\\n      currentLevel\\n      ipLevel\\n      gain\\n    }\\n    grade_2 {\\n      currentLevel\\n      ipLevel\\n      gain\\n    }\\n    grade_3 {\\n      currentLevel\\n      ipLevel\\n      gain\\n    }\\n    grade_4 {\\n      currentLevel\\n      ipLevel\\n      gain\\n    }\\n    grade_5 {\\n      currentLevel\\n      ipLevel\\n      gain\\n    }\\n    grade_6 {\\n      currentLevel\\n      ipLevel\\n      gain\\n    }\\n    grade_7 {\\n      currentLevel\\n      ipLevel\\n      gain\\n    }\\n    grade_8 {\\n      currentLevel\\n      ipLevel\\n      gain\\n    }\\n    grade_9 {\\n      currentLevel\\n      ipLevel\\n      gain\\n    }\\n    grade_10 {\\n      currentLevel\\n      ipLevel\\n      gain\\n    }\\n    grade_11 {\\n      currentLevel\\n      ipLevel\\n      gain\\n    }\\n    grade_12 {\\n      currentLevel\\n      ipLevel\\n      gain\\n    }\\n  }\\n}\\n\"}";
    String GET_ALL_STUDENTS_FROM_ORGANIZATION_PAYLOAD = "{\"includeUnassignedStudents\": true, \"organizationId\": \"%s\",  \"searchString\": \"\", \"offset\":{count}}";
    String GET_STUDENT_END_POINT = "/lms/web/api/v1/search/user";
}
