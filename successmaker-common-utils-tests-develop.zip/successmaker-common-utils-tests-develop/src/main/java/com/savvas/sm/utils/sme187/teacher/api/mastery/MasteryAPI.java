package com.savvas.sm.utils.sme187.teacher.api.mastery;

import java.util.Map;

import io.restassured.response.Response;
import com.savvas.sm.utils.RestAssuredAPIUtil;

public class MasteryAPI {

    /***
     * 
     * @author madhan.nagarathinam
     * 
     *         getMasterySummarySkillStandard() -> This method get the details
     *         for mastery Listing
     *
     * 
     * @param smUrl - The URL can be basic, auto and MSMN. Basic:
     *            https://nightly-next-basic.smdemo.info Auto:
     *            https://nightly-next-auto.smdemo.info MSMN:
     *            https://nightly-next-automsmn.smdemo.info
     * 
     * @param headers - headers must contains org-id, user-id and authorization
     * 
     * @param requestBody - the requestBody should contain subjectId, studentId
     *            as the mandatory parameter
     * @return
     * 
     * @return response -> The Post Call response will be given as a static
     *         Response
     * @throws Exception
     */

    public Response getMasterySummary( String smUrl, Map<String, String> headers, Map<String, Object> requestBody ) throws Exception {
        return RestAssuredAPIUtil.POST_REQ( smUrl, headers, requestBody, MasterySummaryConstant.MASTERY_SUMMARY_ENDPOINT );

    }

    /***
     * 
     * @author madhan.nagarathinam
     * 
     *         getMasteryDetailsSkillStandard() -> This method get the details
     *         for mastery Listing
     *
     * 
     * @param smUrl - The URL can be basic, auto and MSMN. Basic:
     *            https://nightly-next-basic.smdemo.info Auto:
     *            https://nightly-next-auto.smdemo.info MSMN:
     *            https://nightly-next-automsmn.smdemo.info
     * 
     * @param headers - headers must contains org-id, user-id and authorization
     * 
     * @param requestBody - the requestBody should contain learningObjectId,
     *            skillObjectId, assignmentUserIds as the mandatory parameter
     * 
     * @return response -> The Post Call response will be given as a static
     *         Response
     * @throws Exception
     */

    public Response getMasteryDetails( String smUrl, Map<String, String> headers, Map<String, Object> requestBody ) throws Exception {
        return RestAssuredAPIUtil.POST_REQ( smUrl, headers, requestBody, MasteryDetailsConstant.MASTERY_DETAILS_ENDPOINT );

    }
    
    public Response getMasteryPerformance( String smUrl, Map<String, String> headers, Map<String, Object> requestBody ) throws Exception {
        return RestAssuredAPIUtil.POST_REQ( smUrl, headers, requestBody, MasteryPerformanceConstant.MASTERY_PERFORMANCE_ENDPOINT);

    }

}