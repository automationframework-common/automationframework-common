package com.savvas.sm.utils;

import com.learningservices.utils.Log;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

/**
 *
 */
public class SQLUtilTest {

    @Test(testName = "Verify DB Connection Basic Test")
    public void verifyDBConnectionBasicTest(){
        List<Object[]> results = SQLUtil.executeQuery("select now()");
        Log.message("Current time now");
        results.forEach(objects -> Log.message(Arrays.toString(objects)));
        Assert.assertEquals(results.size(), 1);
    }

    @Test(testName = "Verify MT DB Connection Test")
    public void verifyMTDBConnectionTest() {
        List<Object[]> results = SQLUtil.executeQuery("select * from school.organization_tenant");
        Log.message("Organization Tenants");
        results.forEach(objects -> Log.message(Arrays.toString(objects)));
        Assert.assertNotEquals(results.size(), 0);
    }


    @Test(testName = "Verify DB Connection Basic Test - Parallel Execution #1")
    public void verifyDBConnectionBasicTest1(){
        List<Object[]> results = SQLUtil.executeQuery("select now()");
        Log.message("Current time now");
        results.forEach(objects -> Log.message(Arrays.toString(objects)));
        Assert.assertEquals(results.size(), 1);
    }

    @Test(testName = "Verify MT DB Connection Test - Parallel Execution #2")
    public void verifyMTDBConnectionTest2() {
        List<Object[]> results = SQLUtil.executeQuery("select * from school.organization_tenant");
        Log.message("Organization Tenants");
        results.forEach(objects -> Log.message(Arrays.toString(objects)));
        Assert.assertNotEquals(results.size(), 0);
    }
    @Test(testName = "Verify DB Connection Basic Test - Parallel Execution #3")
    public void verifyDBConnectionBasicTest3(){
        List<Object[]> results = SQLUtil.executeQuery("select now()");
        Log.message("Current time now");
        results.forEach(objects -> Log.message(Arrays.toString(objects)));
        Assert.assertEquals(results.size(), 1);
    }

    @Test(testName = "Verify MT DB Connection Test - Parallel Execution #4")
    public void verifyMTDBConnectionTest4() {
        List<Object[]> results = SQLUtil.executeQuery("select * from school.organization_tenant");
        Log.message("Organization Tenants");
        results.forEach(objects -> Log.message(Arrays.toString(objects)));
        Assert.assertNotEquals(results.size(), 0);
    }

}
