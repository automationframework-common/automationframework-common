package com.savvas.sm.utils.rbs;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.learningservices.utils.RestAssuredAPI;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.json.JsonUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.UserAPIEndPoints;

import io.restassured.response.Response;

public class RBSUtils extends EnvProperties {

    String teacherDetails = null;
    String studentDetails = null;
    public ArrayList<String> schoolLeafIds = new ArrayList<String>();
    private static Map<String, String> usersAccessToken = new HashMap<>();

    /**
     * To add successmaker product alone with given config Example Math - Math
     * product alone will be added Reading - Reading product alone will be added
     * MathFocus - Math Focus product alone will be added ReadingFocus - Reading
     * Focus product alone will be added Flex - Flex product alone will be added
     * 
     * @param schoolId
     * @param Subject
     * @param count
     * @throws Exception
     */
    public void addSuccessmakerLicense( String schoolId, String subject, Integer count ) throws Exception {
        List<String> productIds = new ArrayList<String>();
        String[] productId = null;
        if ( subject.equalsIgnoreCase( CommonAPIConstants.MATH ) ) {
            productId = configProperty.getProperty( CommonAPIConstants.MATH_PRODUCT ).split( "," );
        } else if ( subject.equalsIgnoreCase( CommonAPIConstants.READING ) ) {
            productId = configProperty.getProperty( CommonAPIConstants.READING_PRODUCT ).split( "," );
        } else if ( subject.equalsIgnoreCase( CommonAPIConstants.MATH_FOCUS ) ) {
            productId = configProperty.getProperty( CommonAPIConstants.MATH_FOCUS_ONLY_PRODUCT ).split( "," );
        } else if ( subject.equalsIgnoreCase( CommonAPIConstants.READING_FOCUS ) ) {
            productId = configProperty.getProperty( CommonAPIConstants.READING_FOCUS_ONLY_PRODUCT ).split( "," );
        } else if ( subject.equalsIgnoreCase( CommonAPIConstants.FLEX ) ) {
            productId = configProperty.getProperty( CommonAPIConstants.FLEX_PRODUCT ).split( "," );
        }

        for ( String product : productId ) {
            productIds.add( product );
            if ( isLicenseExist( schoolId, product ) ) {
                productIds.remove( product );
            }
        }
        if ( !productIds.isEmpty() ) {
            addLicenseToOrg( schoolId, productIds, count );
        } else {
            Log.message( "Given product is already there! There is no new products to add!" );
        }
    }

    /**
     * To create the user in Rumba
     * 
     * @param userDetails should have createdBy,userName,Role and organization
     *            ID
     * @return the response of create user
     * @throws Exception
     */
    public String createUser( HashMap<String, String> userDetails ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        //Generating request body
        String requestBody = SMUtils.getPayload( PayloadFor.RBS, "createRumbaUser.json" );
        requestBody = generateRequestBody( requestBody, userDetails );

        //Hitting post call
        HashMap<String, String> response;
        try {
            response = RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.USER_SERVICE ), headers, params, configProperty.getProperty( ConfigConstants.USER_SERVICE_ENDPOINT ), requestBody );
            if ( !response.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                throw new Exception();
            }
        } catch ( Exception e ) {
            Log.message( "Getting issue while create the user. Retrying..." );
            Thread.sleep( 3000 );
            response = RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.USER_SERVICE ), headers, params, configProperty.getProperty( ConfigConstants.USER_SERVICE_ENDPOINT ), requestBody );
        }

        teacherDetails = response.get( Constants.REPORT_BODY );
        return teacherDetails;

    }

    /**
     * To create the user in Rumba
     * 
     * @param userDetails should have createdBy,userName,OrgName, OrgType, and
     *            organization ID
     * @return the response of create user
     * @throws Exception
     */
    public boolean createCAUserWithAccess( HashMap<String, String> adminDetails, boolean ebAccess ) throws Exception {
        boolean isAdminCreated = false;
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        //Generating request body
        String requestBody = SMUtils.getPayload( PayloadFor.RBS, "createCAWithAccess.json" );
        requestBody = generateRequestBody( requestBody, adminDetails );

        if ( !ebAccess ) {
            JSONObject adminReq = new JSONObject( requestBody );
            JSONArray accesses = adminReq.getJSONArray( RBSDataSetupConstants.POLICY );

            for ( Object access : accesses ) {
                JSONObject accessStatus = new JSONObject( access );
                accessStatus.put( RBSDataSetupConstants.STATUS_ACTIVE, false );
            }

        }

        //Hitting post call
        HashMap<String, String> response;
        try {
            response = RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.SRS_SERVICE ), headers, params, configProperty.getProperty( ConfigConstants.SRS_ASR_CREATE_ADMIN_ENDPOINT ), requestBody );
            if ( !response.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                throw new Exception();
            }
        } catch ( Exception e ) {
            Log.message( "Getting issue while create the user with access. Retrying..." );
            Thread.sleep( 3000 );
            response = RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.SRS_SERVICE ), headers, params, configProperty.getProperty( ConfigConstants.SRS_ASR_CREATE_ADMIN_ENDPOINT ), requestBody );
        }

        if ( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( CommonAPIConstants.STATUS_CODE_OK ) ) {

            isAdminCreated = true;
        }

        return isAdminCreated;
    }

    /**
     * To verify the product is associated with Org or not
     * 
     * @param orgId
     * @param productId
     * @return
     * @throws Exception
     */
    public boolean isLicenseExist( String orgId, String productId ) throws Exception {
        AtomicBoolean licenseExist = new AtomicBoolean( false );

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();
        //Hitting post call
        HashMap<String, String> response;
        try {
            response = RestHttpClientUtil.GET( configProperty.getProperty( ConfigConstants.LICENSE_SERVICE ), String.format( configProperty.getProperty( ConfigConstants.GET_LICENSED_PRODUCT ), orgId ), headers, params );
            if ( !response.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                throw new Exception();
            }
        } catch ( Exception e ) {
            Log.message( "Getting issue while License Exist or not. Retrying..." );
            Thread.sleep( 3000 );
            response = RestHttpClientUtil.GET( configProperty.getProperty( ConfigConstants.LICENSE_SERVICE ), String.format( configProperty.getProperty( ConfigConstants.GET_LICENSED_PRODUCT ), orgId ), headers, params );
        }

        //List<String> productList = helper.getKeyValues( new JSONObject( response.get( Constants.REPORT_BODY ) ), "productId" );

        JSONArray productList = new JSONArray( response.get( Constants.REPORT_BODY ) );

        for ( Object product : productList ) {
            JSONObject productIdFromResponse = new JSONObject( product.toString() );
            if ( productIdFromResponse.get( RBSDataSetupConstants.PRODUCT_ID_FIELD ).toString().equalsIgnoreCase( productId ) ) {
                licenseExist.set( true );
            }
        }

        return licenseExist.get();
    }

    /**
     * To create only subdistrict and school in Rumba(A&E). District creation is
     * restricted
     * 
     * @param orgDetails should be organization name, organization type.
     * @return organization ID
     */
    public String createOrg( HashMap<String, String> orgDetails ) {
        String orgID = null;
        if ( Objects.nonNull( configProperty.getProperty( ConfigConstants.IS_SCHOOL_CREATION_RESTRICTED ) ) ? configProperty.getProperty( ConfigConstants.IS_SCHOOL_CREATION_RESTRICTED ).equalsIgnoreCase( "false" ) : true ) {
            try {
                if ( !orgDetails.get( RBSDataSetupConstants.ORGANIZATION_TYPE ).equalsIgnoreCase( RBSDataSetupConstants.ORGANIZATION_TYPE_DISTRICT ) ) {
                    // headers
                    Map<String, String> headers = new HashMap<String, String>();
                    headers.put( Constants.ACCEPT_TYPE, Constants.SOAP_CONTENT_TYPE );
                    headers.put( Constants.CONTENT_TYPE, Constants.SOAP_CONTENT_TYPE );

                    //input params
                    HashMap<String, String> params = new HashMap<>();

                    //Generating body
                    String SOAPBody = SMUtils.getPayload( PayloadFor.RBS, "createOrg.xml" );
                    SOAPBody = generateRequestBody( SOAPBody, orgDetails );
                    HashMap<String, String> response = RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.ORG_SERVICE ), headers, params, configProperty.getProperty( ConfigConstants.ORG_SERVICE_ENDPOINT ), SOAPBody );

                    //Parsing XML to get the org ID
                    JSONObject xmlJSONObj = XML.toJSONObject( response.get( Constants.RESPONSE_BODY ) );
                    String jsonXML = xmlJSONObj.toString();
                    String responseLevel1 = SMUtils.getKeyValueFromResponse( jsonXML, RBSDataSetupConstants.SOAP_ENVELOP + "," + RBSDataSetupConstants.SOAP_BODY );
                    String responseLevel2 = SMUtils.getKeyValueFromResponse( responseLevel1, "ns6:CreateOrganizationResponse,ns6:ServiceResponseType" );
                    if ( responseLevel2.contains( "ns4" ) ) {
                        orgID = SMUtils.getKeyValueFromResponse( responseLevel2, "ns4:returnValue" );
                    } else {
                        orgID = SMUtils.getKeyValueFromResponse( responseLevel2, "ns3:returnValue" );
                    }

                    return orgID;
                } else {
                    Log.message( "District creation is restricted!" );
                }
            } catch ( Exception e ) {
                e.printStackTrace();
            }
        } else {
            Log.fail( "School creation is restricted. please give the organization which is already present under the district" );
        }
        return orgID;
    }

    /**
     * To get the user details by username
     * 
     * @param userName
     * @return
     */
    public String getUserIDByUserName( String userName ) {
        String userId = null;

        try {

            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.SOAP_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.SOAP_CONTENT_TYPE );

            //input params
            HashMap<String, String> params = new HashMap<>();

            //Generating body
            String SOAPBody = SMUtils.getPayload( PayloadFor.RBS, "getUserByUserName.xml" );

            HashMap<String, String> userDetails = new HashMap<>();
            userDetails.put( RBSDataSetupConstants.USERNAME, userName );

            SOAPBody = generateRequestBody( SOAPBody, userDetails );

            HashMap<String, String> response;
            try {
                response = RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.ULC_URL ), headers, params, configProperty.getProperty( ConfigConstants.ULC_READ_ENDPOINT ), SOAPBody );
            } catch ( Exception e ) {
                Log.message( "Getting issue while get user Id by username. Retrying..." );
                Thread.sleep( 3000 );
                response = RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.ULC_URL ), headers, params, configProperty.getProperty( ConfigConstants.ULC_READ_ENDPOINT ), SOAPBody );
            }

            //Parsing XML to get the org ID
            JSONObject xmlJSONObj = XML.toJSONObject( response.get( Constants.REPORT_BODY ) );
            if ( response.get( Constants.STATUS_CODE ).equals( "200" ) ) {
                userId = xmlJSONObj.getJSONObject( RBSDataSetupConstants.SOAP_ENVELOP ).getJSONObject( RBSDataSetupConstants.SOAP_BODY ).getJSONObject( "tns:GetUserByUserNameResponseElement" ).getJSONObject( "tns:User" ).get( "tns:UserId" ).toString();
            }

        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return userId;

    }

    /**
     * To get the organization ID by organization name
     * 
     * @param parentOrgId
     * @param organizationName
     * @return organization ID
     */
    public String getOrganizationIDByName( String parentOrgId, String organizationName ) {
        AtomicReference<String> orgId = new AtomicReference<>();

        try {
            String childrens = getChildOrganization( parentOrgId );
            JSONArray childOrgs = new JSONArray( childrens );
            childOrgs.forEach( child -> {
                JSONObject childOrg = new JSONObject( child.toString() );
                if ( childOrg.get( RBSDataSetupConstants.NAME ).toString().equalsIgnoreCase( organizationName ) ) {
                    orgId.set( childOrg.get( RBSDataSetupConstants.ORGANIZATION_ID ).toString() );
                }
            } );

        } catch ( Exception e ) {
            e.printStackTrace();
        }

        return orgId.get();
    }

    /**
     * To find the organization is exist in Rumba
     * 
     * @param organizationName
     * @return boolean true or false
     */
    public boolean isOrganizationExist( String parentOrgId, String searchOrganizationName ) {
        AtomicBoolean exist = new AtomicBoolean( false );

        try {
            String childrens = getChildOrganization( parentOrgId );
            JSONArray childOrgs = new JSONArray( childrens );
            childOrgs.forEach( child -> {
                JSONObject childOrg = new JSONObject( child.toString() );
                if ( childOrg.get( RBSDataSetupConstants.NAME ).toString().equalsIgnoreCase( searchOrganizationName ) ) {
                    exist.set( true );
                }
            } );

            if ( exist.get() ) {
                Log.message( searchOrganizationName + " already present under " + parentOrgId );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }

        return exist.get();

    }

    /**
     * TO add the products to school.
     * 
     * @param schoolID
     * @param productIds should be rumba IDs
     * @param licenseCount
     * @return
     */
    public String addLicenseToOrg( String schoolID, List<String> productIds, Integer licenseCount ) throws IOException {
        String orgID = null;
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.SOAP_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.SOAP_CONTENT_TYPE );

            //input params
            HashMap<String, String> params = new HashMap<>();

            IntStream.range( 0, productIds.size() ).forEach( product -> {
                HashMap<String, String> productDetails = new HashMap<>();
                productDetails.put( RBSDataSetupConstants.PRODUCT_ID, productIds.get( product ) );
                String SOAPBody = null;
                SOAPBody = SMUtils.getPayload( PayloadFor.RBS, "getProductDetails.xml" );
                SOAPBody = generateRequestBody( SOAPBody, productDetails );
                HashMap<String, String> response = null;
                try {
                    response = RestHttpClientUtil.POST( configProperty.getProperty( "product_lifecycle_URL" ), headers, params, configProperty.getProperty( "product_lifecycle_endPoint" ), SOAPBody );
                } catch ( Exception e ) {
                    e.printStackTrace();
                }

                JSONObject xmlJSONObj = XML.toJSONObject( response.get( Constants.RESPONSE_BODY ) );
                JSONObject firstLevelJson = xmlJSONObj.getJSONObject( RBSDataSetupConstants.SOAP_ENVELOP ).getJSONObject( RBSDataSetupConstants.SOAP_BODY ).getJSONObject( "ns2:GetProductDetailsResponse" ).getJSONObject( "ns2:Product" );
                String entityId = SMUtils.getKeyValueFromResponse( firstLevelJson.toString(), "ns2:ProductEntityId" );
                productDetails.put( RBSDataSetupConstants.PRODUCT_ENTITY_ID, entityId );
                SOAPBody = SMUtils.getPayload( PayloadFor.RBS, "createOrder.xml" );
                SOAPBody = generateRequestBody( SOAPBody, productDetails );
                try {
                    HashMap<String, String> orderResponse = RestHttpClientUtil.POST( configProperty.getProperty( "order_lifecycle_URL" ), headers, params, configProperty.getProperty( "order_lifecycle_endPoint" ), SOAPBody );
                    xmlJSONObj = XML.toJSONObject( orderResponse.get( Constants.RESPONSE_BODY ) );

                    try {
                        firstLevelJson = xmlJSONObj.getJSONObject( RBSDataSetupConstants.SOAP_ENVELOP ).getJSONObject( RBSDataSetupConstants.SOAP_BODY ).getJSONObject( "ns2:CreateOrderResponse" ).getJSONObject( "ns2:Order" ).getJSONObject(
                                "ns2:OrderLineItems" ).getJSONObject( "ns2:OrderLine" );
                        String orderLineItemId = SMUtils.getKeyValueFromResponse( firstLevelJson.toString(), "ns2:OrderLineId" );
                        productDetails.put( RBSDataSetupConstants.ORDER_LINE_ID, orderLineItemId );
                    } catch ( Exception e ) {
                        Log.message( "Getting different namespace for createOrder. Trying another way!" );
                        firstLevelJson = xmlJSONObj.getJSONObject( RBSDataSetupConstants.SOAP_ENVELOP ).getJSONObject( RBSDataSetupConstants.SOAP_BODY ).getJSONObject( "CreateOrderResponse" ).getJSONObject( "Order" ).getJSONObject(
                                "OrderLineItems" ).getJSONObject( "OrderLine" );
                        String orderLineItemId = SMUtils.getKeyValueFromResponse( firstLevelJson.toString(), "OrderLineId" );
                        productDetails.put( RBSDataSetupConstants.ORDER_LINE_ID, orderLineItemId );

                    }
                } catch ( Exception e ) {
                    e.printStackTrace();
                }

                SOAPBody = SMUtils.getPayload( PayloadFor.RBS, "createLicense.xml" );
                Date date = new Date();

                String todayDate = new SimpleDateFormat( "yyyy-MM-dd" ).format( date );

                productDetails.put( RBSDataSetupConstants.START_DATE, todayDate );
                productDetails.put( RBSDataSetupConstants.END_DATE, LocalDate.parse( todayDate, DateTimeFormatter.ofPattern( "yyyy-MM-dd" ) ).plusYears( 1 ).toString() );
                productDetails.put( RBSDataSetupConstants.QUANTITY, licenseCount.toString() );
                productDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, schoolID );
                SOAPBody = generateRequestBody( SOAPBody, productDetails );
                try {
                    HashMap<String, String> orderResponse = RestHttpClientUtil.POST( configProperty.getProperty( "license_lifecycle_URL" ), headers, params, configProperty.getProperty( "license_lifecycle_endPoint" ), SOAPBody );
                    xmlJSONObj = XML.toJSONObject( orderResponse.get( Constants.RESPONSE_BODY ) );
                    if ( xmlJSONObj.toString().contains( "SUCCESS" ) ) {
                        Log.message( "License " + productIds.get( product ) + " added for the school - " + schoolID );
                    } else {
                        Log.message( "Issue in adding the license to school  - " + orderResponse.get( Constants.RESPONSE_BODY ) );
                    }
                } catch ( Exception e ) {
                    e.printStackTrace();
                }

            } );

        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return orgID;
    }

    /**
     * To relate the organization with district
     * 
     * @param orgRelationDetails should be District ID and school ID.
     * @return
     */
    public String relateOrganization( HashMap<String, String> orgRelationDetails ) {
        String orgID = null;
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.SOAP_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.SOAP_CONTENT_TYPE );

            //input params
            HashMap<String, String> params = new HashMap<>();

            //Generating body
            String SOAPBody = SMUtils.getPayload( PayloadFor.RBS, "orgRelation.xml" );
            SOAPBody = generateRequestBody( SOAPBody, orgRelationDetails );
            HashMap<String, String> response = RestHttpClientUtil.POST( configProperty.getProperty( "org_service" ), headers, params, configProperty.getProperty( "org_service_endPoint" ), SOAPBody );

            //Parsing XML to get the org ID
            JSONObject xmlJSONObj = XML.toJSONObject( response.get( Constants.RESPONSE_BODY ) );
            String jsonXML = xmlJSONObj.toString();
            if ( jsonXML.contains( "SUCCESS" ) ) {
                Log.message( "School is associated with District! - " + orgRelationDetails.get( RBSDataSetupConstants.DISTRICT_ID ) );
            } else {
                Log.message( "Issue in associating school with District!" );
            }

            return orgID;
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return orgID;
    }

    /**
     * To get the user details based on rumba ID.
     * 
     * @param userID
     * @return response of get user
     */
    public String getUser( String userID ) {

        HashMap<String, String> response = new HashMap<>();
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );
            headers.put( Constants.USERID_HEADER, userID );
            headers.put( Constants.USERIDS_HEADER, userID );

            HashMap<String, String> params = new HashMap<>();

            try {
                response = RestHttpClientUtil.GET( configProperty.getProperty( ConfigConstants.USER_SERVICE ), configProperty.getProperty( "user_service_endPoint" ), headers, params );
                if ( !response.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                    throw new Exception();
                }
            } catch ( Exception e ) {
                Log.message( "Getting issue while try to get the user details using user Id!!!" );
                Thread.sleep( 3000 );
                response = RestHttpClientUtil.GET( configProperty.getProperty( ConfigConstants.USER_SERVICE ), configProperty.getProperty( "user_service_endPoint" ), headers, params );
            }
            return response.get( Constants.RESPONSE_BODY );

        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response.get( Constants.RESPONSE_BODY );
    }

    /**
     * Get organization details by ID
     * 
     * @param orgId
     * @return
     */
    public String getOrg( String orgId ) {

        HashMap<String, String> response = new HashMap<>();
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );

            HashMap<String, String> params = new HashMap<>();
            try {
                response = RestHttpClientUtil.GET( configProperty.getProperty( ConfigConstants.RBS_ORG_SERVICE ), String.format( configProperty.getProperty( ConfigConstants.GET_ORG_ENDPOINT ), orgId ), headers, params );
                if ( !response.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                    throw new Exception();
                }
            } catch ( Exception e ) {
                Log.message( "Getting issue while try to get the org details using org Id!!!" );
                Thread.sleep( 3000 );
                response = RestHttpClientUtil.GET( configProperty.getProperty( ConfigConstants.USER_SERVICE ), configProperty.getProperty( "user_service_endPoint" ), headers, params );
            }
            return response.get( Constants.RESPONSE_BODY );

        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response.get( Constants.RESPONSE_BODY );
    }

    /**
     * To get the orgDetail details based on District ID/ Org ID.
     * 
     * @param districtId/orgId
     * @return response of get user
     */
    public String getOrganizationChildren( String districtId ) {

        HashMap<String, String> response = new HashMap<>();
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );

            HashMap<String, String> params = new HashMap<>();

            String orgService = configProperty.getProperty( "rbsOrg_Service" );
            String orgServiceEndPoint = CommonAPIConstants.CHILD_ORGANIZATION_FROM_ORGSERVICE;

            orgServiceEndPoint = orgServiceEndPoint.replace( "{organizationId}", districtId );
            response = RestHttpClientUtil.GET( orgService, orgServiceEndPoint, headers, params );
            return response.get( Constants.RESPONSE_BODY );

        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response.get( Constants.RESPONSE_BODY );
    }

    /**
     * To get the access token using username and password
     * 
     * @param userId
     * @param password
     * @return access token
     * @throws Exception
     */
    public String getAccessToken( String userId, String password ) {

        if ( Objects.isNull( userId ) || Objects.isNull( password ) ) {
            Log.message( "The Given username or password is empty." + "\nusername : " + userId + "\npassword : " + password );
            return null;
        }

        String accessTokenForExistingUser = isAccessTokenPresentForUser( userId );
        if ( Objects.nonNull( accessTokenForExistingUser ) ) {
            return accessTokenForExistingUser;
        }

        try {
            String rbsLoginURL = configProperty.getProperty( "rbsLoginURL" );
            String castGCEndpoint = configProperty.getProperty( "castGCEndpoint" );
            String tokenURL = configProperty.getProperty( "rbsLoginURL" );
            String tokenEndpoint = configProperty.getProperty( "tokenEndpoint" );

            Log.event( "Username - " + userId );

            Map<String, String> accessTokenHeaders = new HashMap<>();
            Map<String, String> inputData = new HashMap<>();
            accessTokenHeaders.put( "Content-Type", "application/json" );
            String body = "\n" + "{\n" + "  \"username\": \"" + userId + "\",\n" + "  \"password\": \"" + password + "\"\n" + "}";
            JSONObject responseContent = null;
            String castgcToken = null;

            try {
                Response postResponseMap = RestAssuredAPI.post( rbsLoginURL, accessTokenHeaders, inputData, body, castGCEndpoint );
                Log.event( "Response: " + postResponseMap.getBody().asString() + "Status code : " + postResponseMap.getStatusCode() );
                responseContent = new JSONObject( postResponseMap.getBody().asString() );
                castgcToken = (String) responseContent.getJSONObject( "cookies" ).get( "CASTGC" );
                Log.event( "CastgcToken: " + castgcToken );
            } catch ( Exception e ) {
                try {
                    Log.event( "Expection in generating castgc for (Retrying for same user after 30 sec) " + body );
                    Thread.sleep( 30000 );
                    Response postResponseMap = RestAssuredAPI.post( rbsLoginURL, accessTokenHeaders, inputData, body, castGCEndpoint );
                    Log.event( "Response: " + postResponseMap.getBody().asString() + "Status code : " + postResponseMap.getStatusCode() );
                    responseContent = new JSONObject( postResponseMap.getBody().asString() );
                    castgcToken = (String) responseContent.getJSONObject( "cookies" ).get( "CASTGC" );
                } catch ( Exception e1 ) {
                    Log.event( "Getting issue while get the CASTGC!!!!. Might be username or password is invalid. " + body );
                }
                Log.event( "CastgcToken: " + castgcToken );
            }

            accessTokenHeaders.put( "Authorization", configProperty.getProperty( "CASTGC_auth" ) );
            JSONObject postBody = new JSONObject();
            postBody.put( "scope", "test" );
            postBody.put( "userId", responseContent.get( "identityId" ) );
            postBody.put( "clientId", configProperty.getProperty( "clientID" ) );
            postBody.put( "grant_type", "custom_castgc" );
            accessTokenHeaders.put( "Castgc", castgcToken );

            try {
                Response postResponseMap = RestAssuredAPI.post( tokenURL, accessTokenHeaders, inputData, postBody.toString(), tokenEndpoint );
                responseContent = new JSONObject( postResponseMap.getBody().asString() );
                String accessToken = (String) responseContent.get( "access_token" );
                usersAccessToken.put( userId, accessToken );
                return accessToken;
            } catch ( Exception e ) {
                try {
                    Thread.sleep( 3000 );
                    Response postResponseMap = RestAssuredAPI.post( tokenURL, accessTokenHeaders, inputData, postBody.toString(), tokenEndpoint );
                    responseContent = new JSONObject( postResponseMap.getBody().asString() );
                    String accessToken = (String) responseContent.get( "access_token" );
                    usersAccessToken.put( userId, accessToken );
                    return accessToken;
                } catch ( Exception e1 ) {
                    Log.event( "Getting issue while get the accesstoken!!!!" );
                    return null;
                }
            }

        } catch ( Exception ex ) {
            ex.printStackTrace();
            Log.event( "No valid username or password found" );
            return null;
        }

    }

    /**
     * To check the accesstoken is already present for the given user
     * 
     * @param userId
     */
    public String isAccessTokenPresentForUser( String userName ) {
        if ( usersAccessToken.containsKey( userName ) ) {
            Log.message( "Access Token is exist for the given user. - " + userName + ". so, validating the existing token" );
            if ( validateAccessToken( usersAccessToken.get( userName ) ) ) {
                return usersAccessToken.get( userName );
            }
        }
        return null;
    }

    /**
     * To validate then access token
     * 
     * @param accesstoken
     * @return
     */
    public boolean validateAccessToken( String accesstoken ) {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( "access_token", accesstoken );

        String rbsLoginURL = configProperty.getProperty( "rbsLoginURL" );
        String tokenEndPoint = configProperty.getProperty( "tokenValidEndpoint" );
        try {
            Response response = RestAssuredAPIUtil.PUT( rbsLoginURL + tokenEndPoint, headers );
            return response.getStatusCode() == 200;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * @param orgID
     * @param newPassword
     * @param rumbaID
     * @throws Exception
     */
    public void resetPassword( String orgID, String newPassword, String rumbaID ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );
        headers.put( Constants.USERID_HEADER, rumbaID );
        headers.put( Constants.USERIDS_HEADER, rumbaID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        HashMap<String, String> userDetails = new HashMap<>();
        userDetails.put( RBSDataSetupConstants.PASSWORD, newPassword );
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgID );

        //Generating request body
        String requestBody = SMUtils.getPayload( PayloadFor.RBS, "updatePassword.json" );
        requestBody = generateRequestBody( requestBody, userDetails );

        //Hitting post call
        HashMap<String, String> response;
        try {
            response = RestHttpClientUtil.PUT( configProperty.getProperty( ConfigConstants.USER_SERVICE ), headers, params, configProperty.getProperty( "user_service_Update_endPoint" ), requestBody );
            if ( !response.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                Log.event( "Status code : " + response.get( Constants.STATUS_CODE ) );
                Log.event( "Response : " + response.get( Constants.REPORT_BODY ) );
                throw new Exception();
            }
        } catch ( Exception e ) {
            Log.message( "Getting issue while reset the password..Retrying to reset the password!!" );
            Thread.sleep( 3000 );
            response = RestHttpClientUtil.PUT( configProperty.getProperty( ConfigConstants.USER_SERVICE ), headers, params, configProperty.getProperty( "user_service_Update_endPoint" ), requestBody );
        }
        if ( response.get( Constants.STATUS_CODE ).equals( "200" ) ) {
            Log.message( "Password Updated" );
        } else {
            Log.message( "Password not reseted properly!!!" );
            Log.event( "Status code : " + response.get( Constants.STATUS_CODE ) );
        }

    }

    /**
     * This method is used to add products to the classes
     * 
     * @param sectionID
     * @return String
     * @throws Exception
     */
    public String addProduct( String sectionID, String productId ) {

        // Initializes return variable
        String msg = null;

        try {

            String url = configProperty.getProperty( "ebURL" ) + sectionID + "/";

            // Reads the JSON file format of tenant
            String sourceJson = SMUtils.getPayload( PayloadFor.RBS, "SaveProductForClass.json" );

            // Replaces the tenant info in the file
            sourceJson = JSONUtil.setProperty( sourceJson, "section.id", sectionID );

            // Declaring the map variable to store the values for headers
            Map<String, String> headers = new HashMap<String, String>();

            // Stores the values of header type
            headers.put( "Content-Type", "application/json;charset=UTF-8" );
            headers.put( "Accept", "application/json, text/plain, */*" );

            // Instantiating a class
            RestAssuredAPIUtil restCall = new RestAssuredAPIUtil();

            // Sends the POST request to create the tenant
            String response = restCall.callDigestAuthPOSTApi( url, headers, sourceJson, configProperty.getProperty( "district_ID" ), configProperty.getProperty( "eb_userName" ), configProperty.getProperty( "eb_password" ) );

            // Fetches the import State from the response
            msg = JSONUtil.getProperty( response, "Message" );

        } catch ( Exception e ) {
            e.printStackTrace();
            return msg;
        } // End catch

        return msg;
    }

    /**
     * Class details should have teacher username, class name, teacher rumba ID,
     * org ID
     * 
     * @param classDetails
     * @return
     * @throws Exception
     */
    public String createClass( HashMap<String, String> classDetails ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + getAccessToken( classDetails.get( RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        //Generating request body
        String requestBody = SMUtils.getPayload( PayloadFor.RBS, "createClassPayload.json" );
        requestBody = generateRequestBody( requestBody, classDetails );

        //Hitting post call
        HashMap<String, String> response = RestHttpClientUtil.POST( configProperty.getProperty( "roster_service" ), headers, params, configProperty.getProperty( "createClassEndpoint" ), requestBody );

        return response.get( Constants.RESPONSE_BODY );
    }

    /**
     * To get the class details from CMS
     * 
     * @param classID
     * @param token
     * @return
     */
    public String getClass( String classID ) {
        HashMap<String, String> response = new HashMap<>();
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );

            HashMap<String, String> params = new HashMap<>();

            String endPoint = String.format( CommonAPIConstants.GET_CLASS_CMS, classID );
            response = RestHttpClientUtil.GET( configProperty.getProperty( "roster_service" ), endPoint, headers, params );
            return response.get( Constants.RESPONSE_BODY );
        } catch ( Exception e ) {
            e.printStackTrace();
            return response.get( Constants.RESPONSE_BODY );
        }

    }

    /**
     * To get the group list of the student
     * 
     * @param studentId
     * @return
     */
    public String getClassForStudent( String studentId ) {
        Response response = null;
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            String endPoint = String.format( CommonAPIConstants.GET_GROUP_LIST_CMS, studentId );

            response = RestAssuredAPIUtil.GETWithDigestAuth( configProperty.getProperty( "cms_url" ), headers, configProperty.getProperty( "cms_userName" ), configProperty.getProperty( "cms_password" ), Constants.JSON_CONTENT_TYPE, endPoint );
            return response.getBody().asString();
        } catch ( Exception e ) {
            e.printStackTrace();
            return response.getBody().asString();
        }

    }

    /**
     * To create bulk users
     * 
     * @param userDetails
     * @param count
     * @return
     * @throws Exception
     */
    public String createBulkUsers( HashMap<String, String> userDetails, int count ) throws Exception {
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        //Generating request body

        String requestBody = SMUtils.getPayload( PayloadFor.RBS, "createBulkUserPayload.json" );
        requestBody = generateRequestBody( requestBody, userDetails );

        //Hitting post call
        HashMap<String, String> response = RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.USER_SERVICE ), headers, params, configProperty.getProperty( "user_service_endPoint" ), requestBody );

        teacherDetails = response.get( Constants.REPORT_BODY );
        return teacherDetails;
    }

    /**
     * To delete the user in Rumba
     * 
     * @param userIds
     * @return
     * @throws Exception
     */
    public boolean deleteUser( List<String> userIds ) throws Exception {
        boolean isDeleted = false;

        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );
            headers.put( RBSDataSetupConstants.USERID, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );

            HashMap<String, String> params = new HashMap<>();

            String requestBody = "[\"%s\"]";
            String listString = "";
            if ( userIds.size() > 0 ) {

                for ( String studentID : userIds ) {
                    listString += studentID.concat( "\",\"" );
                }
            }

            listString = listString.substring( 0, listString.length() - 3 );

            requestBody = String.format( requestBody, listString );

            HashMap<String, String> response;
            try {
                response = RestHttpClientUtil.DELETE( configProperty.getProperty( "ae_user_service" ), headers, params, configProperty.getProperty( "ae_user_service_delete_endpoint" ), requestBody );
                if ( !response.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                    Log.event( "Status code : " + response.get( Constants.STATUS_CODE ) );
                    Log.event( "Response : " + response.get( Constants.REPORT_BODY ) );
                    throw new Exception();
                }
            } catch ( Exception e ) {
                Log.message( "Getting issue while delete the user!!!" );
                Thread.sleep( 3000 );
                response = RestHttpClientUtil.DELETE( configProperty.getProperty( "ae_user_service" ), headers, params, configProperty.getProperty( "ae_user_service_delete_endpoint" ), requestBody );

            }
            if ( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( "200" ) ) {
                isDeleted = true;
            }

        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return isDeleted;
    }

    /**
     * To suspend the user in Rumba
     * 
     * @param userIds
     * @return
     * @throws Exception
     */
    public boolean suspendUser( List<String> userIds ) throws Exception {
        boolean isDeleted = false;

        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );
            headers.put( RBSDataSetupConstants.USERID, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );

            HashMap<String, String> params = new HashMap<>();

            String requestBody = "[\"%s\"]";
            String listString = "";
            if ( userIds.size() > 0 ) {

                for ( String studentID : userIds ) {
                    listString += studentID.concat( "\",\"" );
                }
            }

            listString = listString.substring( 0, listString.length() - 3 );

            requestBody = String.format( requestBody, listString );
            HashMap<String, String> response = RestHttpClientUtil.PUT( configProperty.getProperty( "ae_user_service" ), headers, params, configProperty.getProperty( "ae_user_service_suspend_endpoint" ), requestBody );

            if ( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( "200" ) ) {
                isDeleted = true;
                Log.message( "Suspended the users - " + listString );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return isDeleted;
    }

    /**
     * To generate the request payload
     * 
     * @param requestPayloadTemplate
     * @param requestDetails
     * @return generated request body
     */

    public String generateRequestBody( String requestPayloadTemplate, HashMap<String, String> requestDetails ) {
        String request = requestPayloadTemplate;
        try {
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.CREATED_BY ) ) && requestDetails.containsKey( RBSDataSetupConstants.CREATED_BY ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.CREATED_BY ), requestDetails.get( RBSDataSetupConstants.CREATED_BY ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.EMAIL ) ) && requestDetails.containsKey( RBSDataSetupConstants.EMAIL ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.EMAIL ), requestDetails.get( RBSDataSetupConstants.EMAIL ) );
            } else {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.EMAIL ), "smk" + System.nanoTime() + "@test.com" );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.FIRSTNAME ) ) && requestDetails.containsKey( RBSDataSetupConstants.FIRSTNAME ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.FIRSTNAME ), requestDetails.get( RBSDataSetupConstants.FIRSTNAME ) );
            } else {
                Faker dynamicName = new Faker();
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.FIRSTNAME ), dynamicName.name().firstName() );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.LASTNAME ) ) && requestDetails.containsKey( RBSDataSetupConstants.LASTNAME ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.LASTNAME ), requestDetails.get( RBSDataSetupConstants.LASTNAME ) );
            } else {
                Faker dynamicName = new Faker();
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.LASTNAME ), dynamicName.name().lastName() );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.MIDDLENAME ) ) && requestDetails.containsKey( RBSDataSetupConstants.MIDDLENAME ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.MIDDLENAME ), requestDetails.get( RBSDataSetupConstants.MIDDLENAME ) );
            } else {
                Faker dynamicName = new Faker();
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.MIDDLENAME ), dynamicName.name().nameWithMiddle().substring( 1, 2 ).toUpperCase() );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.ORGANIZATIONIDS ) ) && requestDetails.containsKey( RBSDataSetupConstants.ORGANIZATIONIDS ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.ORGANIZATIONIDS ), requestDetails.get( RBSDataSetupConstants.ORGANIZATIONIDS ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.PASSWORD ) ) && requestDetails.containsKey( RBSDataSetupConstants.PASSWORD ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.PASSWORD ), RBSDataSetupConstants.DEFAULT_PASSWORD );
            } else {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.PASSWORD ), RBSDataSetupConstants.DEFAULT_PASSWORD );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.ROLE ) ) && requestDetails.containsKey( RBSDataSetupConstants.ROLE ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.ROLE ), requestDetails.get( RBSDataSetupConstants.ROLE ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.USERNAME ) ) && requestDetails.containsKey( RBSDataSetupConstants.USERNAME ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.USERNAME ), requestDetails.get( RBSDataSetupConstants.USERNAME ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.ORGANIZATION_NAME ) ) && requestDetails.containsKey( RBSDataSetupConstants.ORGANIZATION_NAME ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.ORGANIZATION_NAME ), requestDetails.get( RBSDataSetupConstants.ORGANIZATION_NAME ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.ORGANIZATION_TYPE ) ) && requestDetails.containsKey( RBSDataSetupConstants.ORGANIZATION_TYPE ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.ORGANIZATION_TYPE ), requestDetails.get( RBSDataSetupConstants.ORGANIZATION_TYPE ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.IDENTIFIER_ID ) ) && requestDetails.containsKey( RBSDataSetupConstants.IDENTIFIER_ID ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.IDENTIFIER_ID ), requestDetails.get( RBSDataSetupConstants.IDENTIFIER_ID ) );
            } else {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.IDENTIFIER_ID ), configProperty.getProperty( "SMAppUrl" ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.DISTRICT_ID ) ) && requestDetails.containsKey( RBSDataSetupConstants.DISTRICT_ID ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.DISTRICT_ID ), requestDetails.get( RBSDataSetupConstants.DISTRICT_ID ) );
            } else {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.DISTRICT_ID ), configProperty.getProperty( "district_ID" ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.SCHOOL_ID ) ) && requestDetails.containsKey( RBSDataSetupConstants.SCHOOL_ID ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.SCHOOL_ID ), requestDetails.get( RBSDataSetupConstants.SCHOOL_ID ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.SECTION_NAME ) ) && requestDetails.containsKey( RBSDataSetupConstants.SECTION_NAME ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.SECTION_NAME ), requestDetails.get( RBSDataSetupConstants.SECTION_NAME ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.ORGANIZATION_ID ) ) && requestDetails.containsKey( RBSDataSetupConstants.ORGANIZATION_ID ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.ORGANIZATION_ID ), requestDetails.get( RBSDataSetupConstants.ORGANIZATION_ID ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.STAFF_PI_ID ) ) && requestDetails.containsKey( RBSDataSetupConstants.STAFF_PI_ID ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.STAFF_PI_ID ), requestDetails.get( RBSDataSetupConstants.STAFF_PI_ID ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.STUDENT_PI_ID ) ) && requestDetails.containsKey( RBSDataSetupConstants.STUDENT_PI_ID ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.STUDENT_PI_ID ), requestDetails.get( RBSDataSetupConstants.STUDENT_PI_ID ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.PRODUCT_ID ) ) && requestDetails.containsKey( RBSDataSetupConstants.PRODUCT_ID ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.PRODUCT_ID ), requestDetails.get( RBSDataSetupConstants.PRODUCT_ID ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.PRODUCT_ENTITY_ID ) ) && requestDetails.containsKey( RBSDataSetupConstants.PRODUCT_ENTITY_ID ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.PRODUCT_ENTITY_ID ), requestDetails.get( RBSDataSetupConstants.PRODUCT_ENTITY_ID ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.ORDER_LINE_ID ) ) && requestDetails.containsKey( RBSDataSetupConstants.ORDER_LINE_ID ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.ORDER_LINE_ID ), requestDetails.get( RBSDataSetupConstants.ORDER_LINE_ID ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.START_DATE ) ) && requestDetails.containsKey( RBSDataSetupConstants.START_DATE ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.START_DATE ), requestDetails.get( RBSDataSetupConstants.START_DATE ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.END_DATE ) ) && requestDetails.containsKey( RBSDataSetupConstants.END_DATE ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.END_DATE ), requestDetails.get( RBSDataSetupConstants.END_DATE ) );
            }
            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.QUANTITY ) ) && requestDetails.containsKey( RBSDataSetupConstants.QUANTITY ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.QUANTITY ), requestDetails.get( RBSDataSetupConstants.QUANTITY ) );
            }

            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.DISPLAY_NAME ) ) && requestDetails.containsKey( RBSDataSetupConstants.DISPLAY_NAME ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.DISPLAY_NAME ), requestDetails.get( RBSDataSetupConstants.DISPLAY_NAME ) );
            }

            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.ORG_ROLE ) ) && requestDetails.containsKey( RBSDataSetupConstants.ORG_ROLE ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.ORG_ROLE ), requestDetails.get( RBSDataSetupConstants.ORG_ROLE ) );
            }

            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.TITLE ) ) && requestDetails.containsKey( RBSDataSetupConstants.TITLE ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.TITLE ), requestDetails.get( RBSDataSetupConstants.TITLE ) );
            }

            if ( requestPayloadTemplate.contains( getRequestBodyParameter( RBSDataSetupConstants.USERID ) ) && requestDetails.containsKey( RBSDataSetupConstants.USERID ) ) {
                request = request.replace( getRequestBodyParameter( RBSDataSetupConstants.USERID ), requestDetails.get( RBSDataSetupConstants.USERID ) );
            }
            if ( requestPayloadTemplate.contains( Constants.COURSENAME_VALUE ) && requestDetails.containsKey( Constants.COURSE_NAME ) ) {
                request = request.replace( Constants.COURSENAME_VALUE, requestDetails.get( Constants.COURSE_NAME ) );
            }
            if ( requestPayloadTemplate.contains( Constants.GRADE_ID ) && requestDetails.containsKey( Constants.GRADE_ID ) ) {
                request = request.replace( Constants.GRADE_ID, requestDetails.get( Constants.GRADE_ID ) );
            }
            if ( requestPayloadTemplate.contains( Constants.STANDARDFRAMEWORK_ID ) && requestDetails.containsKey( Constants.STANDARDFRAMEWORK_ID ) ) {
                request = request.replace( Constants.STANDARDFRAMEWORK_ID, requestDetails.get( Constants.STANDARDFRAMEWORK_ID ) );
            }
            if ( requestPayloadTemplate.contains( Constants.BANKID ) && requestDetails.containsKey( Constants.BANKID ) ) {
                request = request.replace( Constants.BANKID, requestDetails.get( Constants.BANKID ) );
            }
            if ( requestPayloadTemplate.contains( Constants.LOID ) && requestDetails.containsKey( Constants.LOID ) ) {
                request = request.replace( Constants.LOID, requestDetails.get( Constants.LOID ) );
            }

        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return request;
    }

    /**
     * to generate the request body Parameter
     * 
     * @param parameterName
     * @return
     */
    public String getRequestBodyParameter( String parameterName ) {
        return "{" + parameterName + "}";
    }

    /**
     * Add student into section
     * 
     * @param sectionId
     * @param teacherId
     * @param studentId
     * @return
     */
    public boolean addStudentintoSection( String sectionId, String teacherId, String studentId ) {
        boolean flag;
        HashMap<String, String> response = new HashMap<>();
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( CommonAPIConstants.CMS_ADMIN_USERNAME, CommonAPIConstants.CMS_ADMIN_PASSWORD ) );

            HashMap<String, String> params = new HashMap<>();
            String requestBody = SMUtils.getPayload( PayloadFor.RBS, "addStudentintoSection.json" );
            requestBody = requestBody.replace( getRequestBodyParameter( RBSDataSetupConstants.TEACHER_ID ), teacherId );
            requestBody = requestBody.replace( getRequestBodyParameter( RBSDataSetupConstants.CLASS_ID ), sectionId );
            requestBody = requestBody.replace( getRequestBodyParameter( RBSDataSetupConstants.STUDENT_ID ), studentId );

            String endpoint = CommonAPIConstants.ROSTER_DELETE_STUDENT_FROM_SECTION;
            endpoint = endpoint.replace( getRequestBodyParameter( RBSDataSetupConstants.SECTION_ID ), sectionId );

            response = RestHttpClientUtil.PATCH( configProperty.getProperty( ConfigConstants.ROSTER_SERVICE_URL ), headers, params, endpoint, requestBody );
            if ( JsonUtils.getKeyValues( new JSONObject( response.get( Constants.RESPONSE_BODY ) ), CommonAPIConstants.STATUS_STRING ).get( 0 ).equals( CommonAPIConstants.SUCCESS_STRING ) ) {
                Log.pass( "Successfully deleted!" );
                flag = true;
            } else {
                Log.failsoft( "Failed to Delete From section" );
                flag = false;
            }

        } catch ( Exception e ) {
            e.printStackTrace();
            flag = false;
        }
        return flag;
    }

    /**
     * Class details should have teacher username, class name, org id, student
     * id
     * 
     * @param classDetails,teacherIds,studentIds
     * @return
     * @throws Exception
     */
    public String createClassWithMultipleTeacher( String className, List<String> teacherIds, List<String> studentIds, String OrgId, String accessToken ) throws Exception {

        // Setting teachers payload 
        AtomicReference<String> multipleStudentsPayLoadString = new AtomicReference<>();
        AtomicReference<String> multipleTeacherPayLoadString = new AtomicReference<>();
        List<String> teacherList = new ArrayList<>();
        if ( teacherIds.size() > 0 ) {
            HashMap<String, String> classInfo = new HashMap<>();

            IntStream.range( 0, teacherIds.size() ).forEach( count -> {
                String multiTeacherString = "{  \n               \"staffPiId\": \"{staffPiId}\",  \n               \"teacherOfRecord\": true,  \n               \"teacherAssignment\": \"Lead Teacher\"  \n             }";
                classInfo.put( RBSDataSetupConstants.STAFF_PI_ID, teacherIds.get( count ) );
                String a = generateRequestBody( multiTeacherString, classInfo );
                teacherList.add( a );
            } );

            multipleTeacherPayLoadString.set( teacherList.toString() );
        }

        // Setting students payload
        List<String> studentList = new ArrayList<>();

        if ( studentIds.size() > 0 ) {
            HashMap<String, String> classInfo = new HashMap<>();
            IntStream.range( 0, studentIds.size() ).forEach( count -> {
                String multipleStudentsString = "{\"studentPiId\": \"{studentPiId}\"} ";
                classInfo.put( RBSDataSetupConstants.STUDENT_PI_ID, studentIds.get( count ) );
                String a = generateRequestBody( multipleStudentsString, classInfo );
                studentList.add( a );
            } );
            multipleStudentsPayLoadString.set( studentList.toString() );
        }

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );

        // Parameters
        HashMap<String, String> params = new HashMap<>();

        // Generating request body
        HashMap<String, String> classDetails = new HashMap<>();
        String requestBody = SMUtils.getPayload( PayloadFor.RBS, "createClassPayload2.json" );

        classDetails.put( RBSDataSetupConstants.SECTION_NAME, className );
        classDetails.put( RBSDataSetupConstants.STAFF_PI_ID, multipleTeacherPayLoadString.get() );
        classDetails.put( RBSDataSetupConstants.STUDENT_PI_ID, multipleStudentsPayLoadString.get() );
        classDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, OrgId );
        requestBody = generateRequestBody( requestBody, classDetails );
        // Hitting post call
        HashMap<String, String> response = RestHttpClientUtil.POST( configProperty.getProperty( "roster_service" ), headers, params, configProperty.getProperty( "createClassEndpoint" ), requestBody );
        String classId = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.get( Constants.RESPONSE_BODY ), "data,section" ), "id" );

        addProduct( classId, configProperty.getProperty( "flexProduct" ) );
        return classId;
    }

    /**
     * To Delete the class details from CMS
     * 
     * @param classID
     * @param teacherId
     * @return
     */

    public boolean deleteClass( String classID, String teacherId ) {
        boolean flag = false;
        HashMap<String, String> response = new HashMap<>();
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( CommonAPIConstants.CMS_ADMIN_USERNAME, CommonAPIConstants.CMS_ADMIN_PASSWORD ) );
            headers.put( Constants.USER_ID, teacherId );

            HashMap<String, String> params = new HashMap<>();

            String endPoint = String.format( CommonAPIConstants.DELETE_CLASS_CMS, classID );
            try {
                response = RestHttpClientUtil.DELETE( configProperty.getProperty( "roster_service" ), endPoint, headers, params );
                if ( !response.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                    Log.event( "Status code : " + response.get( Constants.STATUS_CODE ) );
                    Log.event( "Response : " + response.get( Constants.REPORT_BODY ) );
                    throw new Exception();
                }
            } catch ( Exception e ) {
                Log.message( "Getting issue while delete the class!!!" );
                Thread.sleep( 3000 );
                response = RestHttpClientUtil.DELETE( configProperty.getProperty( "roster_service" ), endPoint, headers, params );
            }
            if ( JsonUtils.getKeyValues( new JSONObject( response.get( Constants.RESPONSE_BODY ) ), Constants.RESPONSE_BODY ).get( 0 ).equals( CommonAPIConstants.SUCCESS_STRING ) ) {
                Log.pass( "Successfully deleted!" );
                flag = true;
            } else {
                Log.failsoft( "Failed to Delete From section" );
                flag = false;
            }
            return flag;
        } catch ( Exception e ) {
            e.printStackTrace();
            return flag;
        }

    }

    /**
     * Create a class without sm Product
     * 
     * @param ClassName
     * @param staffId
     * @param studenId
     * @param orgId
     * @param accessToken
     * @return
     * @throws Exception
     */
    public String CreateClassWithoutSMProdcut( String ClassName, String staffId, String studenId, String orgId, String accessToken ) throws Exception {
        HashMap<String, String> response = null;
        try {
            HashMap<String, String> classDetails = new HashMap<>();
            classDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
            classDetails.put( RBSDataSetupConstants.STAFF_PI_ID, staffId );
            classDetails.put( RBSDataSetupConstants.STUDENT_PI_ID, studenId );
            classDetails.put( RBSDataSetupConstants.SECTION_NAME, ClassName );

            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );

            //Parameters
            HashMap<String, String> params = new HashMap<>();

            //Generating request body
            String requestBody = new SMUtils().getPayload( PayloadFor.RBS, "createClassPayloadWithoutProduct.json" );
            requestBody = generateRequestBody( requestBody, classDetails );

            //Hitting post call
            response = RestHttpClientUtil.POST( configProperty.getProperty( "roster_service" ), headers, params, configProperty.getProperty( "createClassEndpoint" ), requestBody );
            return new SMAPIProcessor().getKeyValues( new JSONObject( response.get( Constants.REPORT_BODY ) ), "id" ).get( 0 );
        } catch ( IOException e ) {
            Log.message( response.get( Constants.REPORT_BODY ) );
            return null;
        }
    }

    /**
     * Class details should have teacher username, class name, org id, student
     * id
     * 
     *
     * @param classDetails,teacherIds,studentIds
     * @return
     * @throws Exception
     */
    public String createClassWithMultipleTeacher( HashMap<String, String> classDetails, List<String> teacherIds, List<String> studentIds ) throws Exception {
        AtomicReference<String> multipleTeacherPayLoadString = new AtomicReference<>();
        List<String> teacherList = new ArrayList<>();
        if ( teacherIds.size() > 0 ) {
            HashMap<String, String> classInfo = new HashMap<>();

            IntStream.range( 0, teacherIds.size() ).forEach( count -> {
                String multiTeacherString = "{  \r\n" + "               \"staffPiId\": \"{staffPiId}\",  \r\n" + "               \"teacherOfRecord\": true,  \r\n" + "               \"teacherAssignment\": \"Lead Teacher\"  \r\n" + "             }";
                classInfo.put( RBSDataSetupConstants.STAFF_PI_ID, teacherIds.get( count ) );
                String generateResponse = generateRequestBody( multiTeacherString, classInfo );
                teacherList.add( generateResponse );
            } );
            multipleTeacherPayLoadString.set( teacherList.toString() );
        }
        AtomicReference<String> multipleStudentsPayLoadString = new AtomicReference<>();
        List<String> studentList = new ArrayList<>();

        if ( studentIds.size() > 0 ) {
            HashMap<String, String> classInfo = new HashMap<>();
            IntStream.range( 0, studentIds.size() ).forEach( count -> {
                String multipleStudentsString = "{\"studentPiId\": \"{studentPiId}\"} ";
                classInfo.put( RBSDataSetupConstants.STUDENT_PI_ID, studentIds.get( count ) );
                String a = generateRequestBody( multipleStudentsString, classInfo );
                studentList.add( a );
            } );
            multipleStudentsPayLoadString.set( studentList.toString() );
        }

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );

        // Parameters
        HashMap<String, String> params = new HashMap<>();

        // Generating request body
        String requestBodyFile = new File( "." ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "PayLoad" + File.separator
                + FileConstants.CREATE_GRP_PAYLOAD_NAME2;
        String requestBody = SMUtils.convertFileToString( requestBodyFile );

        classDetails.put( RBSDataSetupConstants.STAFF_PI_ID, multipleTeacherPayLoadString.get() );
        classDetails.put( RBSDataSetupConstants.STUDENT_PI_ID, multipleStudentsPayLoadString.get() );
        requestBody = generateRequestBody( requestBody, classDetails );

        // Hitting post call
        HashMap<String, String> response = RestHttpClientUtil.POST( configProperty.getProperty( "roster_service" ), headers, params, configProperty.getProperty( "createClassEndpoint" ), requestBody );

        return response.get( Constants.REPORT_BODY );
    }

    /**
     * To Delete the class details from CMS
     * 
     * @param classID
     * @param token
     * @return
     */

    public String deleteClass( String classID, String token, String teacherId ) {
        HashMap<String, String> response = new HashMap<>();
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );
            headers.put( Constants.USERID, teacherId );

            HashMap<String, String> params = new HashMap<>();

            String endPoint = String.format( CommonAPIConstants.DELETE_CLASS_CMS, classID );
            response = RestHttpClientUtil.DELETE( configProperty.getProperty( ConfigConstants.ROSTER_SERVICE ), endPoint, headers, params );
            Log.message( response.toString() );
            return response.get( Constants.REPORT_BODY );
        } catch ( Exception e ) {
            e.printStackTrace();
            return response.get( Constants.REPORT_BODY );
        }
    }

    /**
     * To create a user By User Service
     * 
     * @param userDetails
     * @return
     */
    public String createUserByUserService( HashMap<String, String> userDetails ) {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );
        headers.put( RBSDataSetupConstants.USERID, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        //Generating request body
        String requestBody = SMUtils.getPayload( PayloadFor.RBS, FileConstants.CREATE_USER_BY_USERSERVICE );
        requestBody = generateRequestBody( requestBody, userDetails );

        //Hitting post call
        HashMap<String, String> response = null;
        String teacherId = null;
        try {
            try {
                response = RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.AE_USER_SERVICE ), headers, params, configProperty.getProperty( ConfigConstants.CREATE_USER_BY_USER_SERVICE_ENDPOINT ), requestBody );
                if ( !response.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                    throw new Exception();
                }
            } catch ( Exception e ) {
                Log.message( "Getting issue while create the user. Retrying..." );
                Thread.sleep( 3000 );
                response = RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.AE_USER_SERVICE ), headers, params, configProperty.getProperty( ConfigConstants.CREATE_USER_BY_USER_SERVICE_ENDPOINT ), requestBody );
            }
            teacherId = JsonUtils.getKeyValues( new JSONObject( response.get( Constants.REPORT_BODY ) ), RBSDataSetupConstants.USERID ).get( 0 );
            new RBSUtils().resetPassword( JsonUtils.formatListForJSON( Arrays.asList( userDetails.get( RBSDataSetupConstants.ORGANIZATIONIDS ) ) ), RBSDataSetupConstants.DEFAULT_PASSWORD, teacherId );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return teacherId;
    }

    /**
     * update the userProfile by User service
     * 
     * @param userDetails
     * @return
     */
    public String updateUserByUserService( HashMap<String, String> userDetails ) {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );
        headers.put( RBSDataSetupConstants.USERID, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        //Generating request body
        String requestBody = SMUtils.getPayload( PayloadFor.RBS, FileConstants.UPDATE_USER_BY_USERSERVICE );
        requestBody = generateRequestBody( requestBody, userDetails );

        //Hitting post call
        HashMap<String, String> response = null;
        try {
            response = RestHttpClientUtil.PUT( configProperty.getProperty( ConfigConstants.AE_USER_SERVICE ), headers, params, configProperty.getProperty( ConfigConstants.CREATE_USER_BY_USER_SERVICE_ENDPOINT ), requestBody );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), RBSDataSetupConstants.USERID );
    }

    /**
     * This method will write the request body payload by giving the key and
     * value
     * 
     * @param requestBodyString
     * @param key
     * @param value
     * @return
     */
    public String generateRequestBodyString( String requestBodyString, String key, String value ) {
        String requestBody = requestBodyString;
        if ( requestBody.contains( key ) ) {
            requestBody = requestBody.replace( getRequestBodyParameter( key ), value );
        }
        return requestBody;

    }

    /**
     * To get the child organization for the given organization
     * 
     * @param parentOrg
     * @return
     */
    public String getChildOrganization( String parentOrg ) {

        HashMap<String, String> response = new HashMap<>();
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );

            HashMap<String, String> params = new HashMap<>();

            String endPoint = String.format( configProperty.getProperty( ConfigConstants.GET_CHILD_ORG_ENDPOINT ), parentOrg );
            try {
                response = RestHttpClientUtil.GET( configProperty.getProperty( ConfigConstants.RBS_ORG_SERVICE ), endPoint, headers, params );
                if ( !response.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                    throw new Exception();
                }
            } catch ( Exception e ) {
                Log.message( "Getting issue while get the child orgaizations." );
                Thread.sleep( 3000 );
                response = RestHttpClientUtil.GET( configProperty.getProperty( ConfigConstants.RBS_ORG_SERVICE ), endPoint, headers, params );
            }
            return response.get( Constants.RESPONSE_BODY );
        } catch ( Exception e ) {
            e.printStackTrace();
            return response.get( Constants.RESPONSE_BODY );
        }
    }

    /**
     * get user with user service
     * 
     * @param userID
     * @return
     */
    public String getUserWithUserService( String userID ) {

        HashMap<String, String> response = new HashMap<>();
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );

            HashMap<String, String> params = new HashMap<>();
            try {
                response = RestHttpClientUtil.GET( configProperty.getProperty( ConfigConstants.AE_USER_SERVICE ), String.format( configProperty.getProperty( ConfigConstants.AE_USER_SERVICE_GET_ENDPOINT ), userID ), headers, params );
                if ( !response.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                    throw new Exception();
                }
            } catch ( Exception e ) {
                Log.message( "Getting issue while try to get the user details using user Id!!!" );
                Thread.sleep( 3000 );
                response = RestHttpClientUtil.GET( configProperty.getProperty( ConfigConstants.AE_USER_SERVICE ), String.format( configProperty.getProperty( ConfigConstants.AE_USER_SERVICE_GET_ENDPOINT ), userID ), headers, params );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response.get( Constants.REPORT_BODY );
    }

    /**
     * To update the orgId for User
     *
     * @param userDetails. Get the user details from userservice and give it as
     *            String
     * @param userRole(T or S or CA)
     * @param orgIds list
     * @throws Exception
     */
    public void updateUserOrgId( String userDetails, String userRole, List<String> orgIds ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.SOAP_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.SOAP_CONTENT_TYPE );

        //input params
        HashMap<String, String> params = new HashMap<>();

        String multiOrgPayload = "";

        for ( String orgId : orgIds ) {
            multiOrgPayload += String.format( RBSDataSetupConstants.ORG_AFFILIATION_PAYLOAD, userRole, orgId );
        }
        HashMap<String, String> requestDetails = new HashMap<>();
        requestDetails.put( RBSDataSetupConstants.USERID, SMUtils.getKeyValueFromResponse( userDetails, RBSDataSetupConstants.USERID ) );
        requestDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( userDetails, RBSDataSetupConstants.FIRSTNAME ) );
        requestDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( userDetails, RBSDataSetupConstants.LASTNAME ) );
        requestDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( userDetails, RBSDataSetupConstants.MIDDLENAME ) );
        requestDetails.put( RBSDataSetupConstants.DISPLAY_NAME, SMUtils.getKeyValueFromResponse( userDetails, RBSDataSetupConstants.LASTNAME ) );
        requestDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( userDetails, RBSDataSetupConstants.USERNAME ) );
        requestDetails.put( RBSDataSetupConstants.CREATED_BY, SMUtils.getKeyValueFromResponse( userDetails, RBSDataSetupConstants.CREATED_BY ) );

        String soapBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.RBS, FileConstants.UPDATE_USER_ORG_PAYLOAD ), requestDetails );

        soapBody = soapBody.replace( "{orgIds}", multiOrgPayload );
        HashMap<String, String> response = RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.ULC_URL ), headers, params, configProperty.getProperty( ConfigConstants.USER_LIFECYCLE_ENDPOINT ), soapBody );
        JSONObject xmlJSONObj = XML.toJSONObject( response.get( Constants.RESPONSE_BODY ) );
        if ( xmlJSONObj.toString().contains( "SUCCESS" ) ) {
            Log.message( "User orgId updated sucessfully." );
        } else {
            Log.message( "Issue in updating the orgId" + response.get( Constants.RESPONSE_BODY ) );
        }
    }

    /**
     * add product to class using Graph QL
     * 
     * @param org ID
     * @param sectionId
     * @param productId
     * @param token
     * @param userid
     * 
     * @return
     * @throws Exception
     */

    public String addProductToClassGraphQL( String orgID, String sectionId, String productId, String token, String userid ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( Constants.USERID_HEADER, userid );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        //Generating request body
        String requestBody = SMUtils.getPayload( PayloadFor.RBS, CommonAPIConstants.ADD_PRODUCT );
        requestBody = generateRequestBodyString( requestBody, RBSDataSetupConstants.ORGANIZATIONIDS, orgID );
        requestBody = generateRequestBodyString( requestBody, RBSDataSetupConstants.PRODUCT_ID, productId );
        requestBody = generateRequestBodyString( requestBody, RBSDataSetupConstants.SECTION_ID, sectionId );

        //Hitting post call
        HashMap<String, String> response = RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.CLASS_SERVICE_GRAPHQL ), headers, params, "/graphql", requestBody );

        return response.get( CommonAPIConstants.BODY_FIELD );
    }

    /**
     * To create a Student with mulitple Organization
     * 
     * @param userName
     * @param Role
     * @param orgIds
     * @return studentId
     */
    public String createMultiOrgStudent( String userName, List<String> orgIds ) {
        HashMap<String, String> userDetails = new HashMap<>();
        try {
            String studentName = userName;

            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );

            userDetails.put( RBSDataSetupConstants.USERNAME, studentName );
            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, new JsonUtils().formatListForJSON( orgIds ) );
            userDetails.put( RBSDataSetupConstants.EMAIL, userName + "@savvas.com" );
            String studentDetails = new RBSUtils().createUser( userDetails );
            String studentId = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );
            new RBSUtils().resetPassword( new JsonUtils().formatListForJSON( orgIds ), RBSDataSetupConstants.DEFAULT_PASSWORD, studentId );
            return studentId;
        } catch ( Exception e ) {
            return null;
        }
    }

    /**
     * To create a Teacher with mulitple Organization
     * 
     * @param userName
     * @param Role
     * @param orgIds
     * @return studentId
     */
    public String createMultiOrgTeacher( String userName, List<String> orgIds ) {
        HashMap<String, String> userDetails = new HashMap<>();
        try {
            String teacherName = userName;

            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );

            userDetails.put( RBSDataSetupConstants.USERNAME, teacherName );
            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, new JsonUtils().formatListForJSON( orgIds ) );
            userDetails.put( RBSDataSetupConstants.EMAIL, userName + "@savvas.com" );
            String teacherdetails = new RBSUtils().createUser( userDetails );
            String teacherID = SMUtils.getKeyValueFromResponse( teacherdetails, RBSDataSetupConstants.USERID );
            new RBSUtils().resetPassword( new JsonUtils().formatListForJSON( orgIds ), RBSDataSetupConstants.DEFAULT_PASSWORD, teacherID );
            return teacherID;
        } catch ( Exception e ) {
            return null;
        }
    }

    /**
     * To Update the user for Grade and 6 demographic values , Student Id
     * 
     * @param userDetails
     * @return
     */
    public String updateUserByUserServiceForDemoGraphics( HashMap<String, String> userDetails ) {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );
        headers.put( RBSDataSetupConstants.USERID, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        //Generating request body
        String requestBody = SMUtils.getPayload( PayloadFor.RBS, FileConstants.UPDATE_USER_BY_USERSERVICE_DEMO );
        requestBody = generateRequestBody( requestBody, userDetails );

        //Hitting post call
        HashMap<String, String> response = null;
        try {
            response = RestHttpClientUtil.PUT( configProperty.getProperty( ConfigConstants.AE_USER_SERVICE ), headers, params, configProperty.getProperty( ConfigConstants.CREATE_USER_BY_USER_SERVICE_ENDPOINT ), requestBody );
        } catch ( Exception e ) {
            e.printStackTrace();
        }

        return SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), RBSDataSetupConstants.USERID );

    }

    /**
     * To create a class with Owners as given Teacher Ids id
     * 
     * @param classDetails,teacherIds,studentIds
     * @return
     * @throws Exception
     */
    public String createSharedClass( String className, List<String> teacherIds, List<String> studentIds, String OrgId, String accessToken ) throws Exception {

        // Setting teachers payload 
        AtomicReference<String> multipleStudentsPayLoadString = new AtomicReference<>();
        AtomicReference<String> multipleTeacherPayLoadString = new AtomicReference<>();
        List<String> teacherList = new ArrayList<>();
        if ( teacherIds.size() > 0 ) {
            HashMap<String, String> classInfo = new HashMap<>();

            IntStream.range( 0, teacherIds.size() ).forEach( count -> {
                String multiTeacherString = SMUtils.getPayload( PayloadFor.RBS, FileConstants.SINGLE_TEACHER_JSON );
                classInfo.put( RBSDataSetupConstants.STAFF_PI_ID, teacherIds.get( count ) );
                String singlePayload = generateRequestBody( multiTeacherString, classInfo );
                teacherList.add( singlePayload );
            } );

            multipleTeacherPayLoadString.set( teacherList.toString() );
        }

        // Setting students payload
        List<String> studentList = new ArrayList<>();

        if ( studentIds.size() > 0 ) {
            HashMap<String, String> classInfo = new HashMap<>();
            IntStream.range( 0, studentIds.size() ).forEach( count -> {
                String multipleStudentsString = SMUtils.getPayload( PayloadFor.RBS, FileConstants.SINGLE_STUDENT_JSON );
                classInfo.put( RBSDataSetupConstants.STUDENT_PI_ID, studentIds.get( count ) );
                String a = generateRequestBody( multipleStudentsString, classInfo );
                studentList.add( a );
            } );
            multipleStudentsPayLoadString.set( studentList.toString() );
        }

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );

        // Parameters
        HashMap<String, String> params = new HashMap<>();

        // Generating request body
        HashMap<String, String> classDetails = new HashMap<>();

        String requestBody = SMUtils.getPayload( PayloadFor.RBS, FileConstants.CREATE_CLASS_PAYLOAD2 );

        classDetails.put( RBSDataSetupConstants.SECTION_NAME, className );
        classDetails.put( RBSDataSetupConstants.STAFF_PI_ID, multipleTeacherPayLoadString.get() );
        classDetails.put( RBSDataSetupConstants.STUDENT_PI_ID, multipleStudentsPayLoadString.get() );
        classDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, OrgId );
        requestBody = generateRequestBody( requestBody, classDetails );
        HashMap<String, String> response = null;
        String classId = null;
        // Hitting post call
        try {
            response = RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.ROSTER_SERVICE ), headers, params, configProperty.getProperty( ConfigConstants.CREATE_CLASS_ENDPOINT ), requestBody );
            classId = new SMAPIProcessor().getKeyValues( new JSONObject( response.get( Constants.REPORT_BODY ) ), "id" ).get( 0 );
        } catch ( Exception e ) {
            Log.message( response.get( Constants.REPORT_BODY ) );
        }

        addProduct( classId, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );
        return classId;
    }

    /**
     * Update the Student with Grade
     * 
     * @param userid of fhe student
     * @param firstName
     * @param middleName
     * @param lastName
     * @return
     */

    public void updateStudentWithGrade( String userID, String firstName, String middleName, String lastName, String gradeId ) throws Exception {
        //headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        //Generating request body
        String requestBody = SMUtils.convertFileToString( SMUtils.getPayloadFilePath( FileConstants.UPDATE_GRADE ) );

        requestBody = generateRequestBodyString( requestBody, RBSDataSetupConstants.USERID, userID );
        requestBody = generateRequestBodyString( requestBody, RBSDataSetupConstants.FIRSTNAME, firstName );
        requestBody = generateRequestBodyString( requestBody, RBSDataSetupConstants.MIDDLENAME, middleName );
        requestBody = generateRequestBodyString( requestBody, RBSDataSetupConstants.LASTNAME, lastName );
        requestBody = generateRequestBodyString( requestBody, RBSDataSetupConstants.GRADE_ID, gradeId );

        HashMap<String, String> put = RestHttpClientUtil.PUT( configProperty.getProperty( ConfigConstants.GET_USER_SERVIVE_URL ), headers, params, configProperty.getProperty( ConfigConstants.GET_USER_SERVIVE_ENDPOINT ), requestBody );

    }

    /**
     * Remove student from section
     * 
     * @param sectionId
     * @param teacherId
     * @param studentId
     * @return
     */
    public boolean deleteStudentFromSection( String sectionId, String teacherId, String studentId ) {
        boolean flag;
        HashMap<String, String> response = new HashMap<>();
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );
            HashMap<String, String> params = new HashMap<>();
            String requestBody = SMUtils.getPayload( PayloadFor.RBS, FileConstants.DELETE_STUDENT_SECTION_PAYLOAD );
            requestBody = requestBody.replace( UserConstants.TEACHER_ID, teacherId );
            requestBody = requestBody.replace( UserConstants.CLASS_ID, sectionId );
            requestBody = requestBody.replace( UserConstants.STUDENT_ID, studentId );

            String endpoint = UserAPIEndPoints.ROSTER_DELETE_STUDENT_FROM_SECTION;
            endpoint = endpoint.replace( "{sectionId}", sectionId );

            //response = RestHttpClientUtil.DELETE( configProperty.getProperty( ConfigConstants.ROSTER_SERVICE_URL ), headers, params, endpoint, requestBody );
            if ( new SMAPIProcessor().getKeyValues( new JSONObject( response.get( Constants.REPORT_BODY ) ), UserConstants.STATUS_STRING ).get( 0 ).equals( UserConstants.SUCCESS_STRING ) ) {
                Log.pass( "Successfully deleted! the student: Id " + studentId + " From class " + sectionId );
                flag = true;
            } else {
                Log.failsoft( "Failed to Delete from class" );
                flag = false;
            }

        } catch ( Exception e ) {
            e.printStackTrace();
            flag = false;
        }
        return flag;
    }

    /**
     * To get all students from organizations
     * 
     * @param selectedOrganizationIds
     * @param teacherId
     * @param teacherOrgId
     * @param token
     * @return
     * @throws Exception
     */
    public List<String> getAllStudentsFromOrganization( String smUrl, List<String> selectedOrganizationIds, String teacherId, String teacherOrgId, String token ) throws Exception {
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put( UserConstants.USERID, teacherId );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.ORGID, teacherOrgId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        List<String> studentIds = new ArrayList<>();
        for ( String selectedOrganizationId : selectedOrganizationIds ) {
            String requestBody = String.format( AdminConstants.GET_ALL_STUDENTS_FROM_ORGANIZATION_PAYLOAD, selectedOrganizationId );
            int offsetCount = 0;
            int iter = 0;
            do {
                String body = requestBody.replace( AdminConstants.COUNT, String.valueOf( iter ) );
                HashMap<String, String> post = RestHttpClientUtil.POST( smUrl, headers, new HashMap<>(), AdminConstants.GET_STUDENT_END_POINT, body );
                JSONObject jsonObj = new JSONObject( SMUtils.getKeyValueFromResponse( post.get( Constants.REPORT_BODY ), "data" ) );
                if ( iter == 0 ) {
                    offsetCount = Integer.parseInt( SMUtils.getKeyValueFromResponse( jsonObj.toString(), AdminConstants.TOTAL_RECORDS ) ) / 250;
                    if ( Integer.parseInt( SMUtils.getKeyValueFromResponse( jsonObj.toString(), AdminConstants.TOTAL_RECORDS ) ) % 250 == 0 ) {
                        offsetCount -= 1;
                    }
                }
                JSONArray ja = jsonObj.getJSONArray( AdminConstants.USER_LIST );
                for ( int arrayCount = 0; arrayCount < ja.length(); arrayCount++ ) {
                    JSONObject jObj = ja.getJSONObject( arrayCount );
                    studentIds.add( jObj.get( Constants.USERID ).toString() );
                }
                iter++;
            } while ( iter <= offsetCount );
        }
        return studentIds;
    }

    /**
     * To get all students from organizations with grade
     * 
     * @param selectedOrganizationIds
     * @param teacherId
     * @param teacherOrgId
     * @param token
     * @return
     * @throws Exception
     */
    public Map<String, List<String>> getStudentsFromOrganizationWithGrade( String smUrl, List<String> selectedOrganizationIds, String teacherId, String teacherOrgId, String token ) throws Exception {
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put( UserConstants.USERID, teacherId );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.ORGID, teacherOrgId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        HashMap<String, List<String>> studentIds = new HashMap<>();
        for ( String selectedOrganizationId : selectedOrganizationIds ) {
            String requestBody = String.format( AdminConstants.GET_ALL_STUDENTS_FROM_ORGANIZATION_PAYLOAD, selectedOrganizationId );
            int offsetCount = 0;
            int iter = 0;
            do {
                String body = requestBody.replace( AdminConstants.COUNT, String.valueOf( iter ) );
                HashMap<String, String> post = RestHttpClientUtil.POST( smUrl, headers, new HashMap<>(), AdminConstants.GET_STUDENT_END_POINT, body );
                JSONObject jsonObj = new JSONObject( SMUtils.getKeyValueFromResponse( post.get( Constants.REPORT_BODY ), "data" ) );
                if ( iter == 0 ) {
                    offsetCount = Integer.parseInt( SMUtils.getKeyValueFromResponse( jsonObj.toString(), AdminConstants.TOTAL_RECORDS ) ) / 250;
                    if ( Integer.parseInt( SMUtils.getKeyValueFromResponse( jsonObj.toString(), AdminConstants.TOTAL_RECORDS ).trim() ) % 250 == 0 ) {
                        offsetCount -= 1;
                    }
                }
                JSONArray ja = jsonObj.getJSONArray( AdminConstants.USER_LIST );
                for ( int arrayCount = 0; arrayCount < ja.length(); arrayCount++ ) {
                    JSONObject jObj = ja.getJSONObject( arrayCount );
                    if ( jObj.toString().contains( AdminConstants.GRADE_NAME ) ) {
                        String grade = SMUtils.getKeyValueFromResponse( jObj.toString(), AdminConstants.GRADE + "," + AdminConstants.GRADE_NAME ).toLowerCase().replace( " ", "_" );
                        if ( Objects.nonNull( studentIds.get( grade ) ) ) {
                            ArrayList<String> students = new ArrayList<>( studentIds.get( grade ) );
                            students.add( jObj.get( Constants.USERID ).toString() );
                            studentIds.put( grade, students );
                        } else {
                            studentIds.put( grade, Arrays.asList( jObj.get( Constants.USERID ).toString() ) );
                        }
                    }
                }
                iter++;
            } while ( iter <= offsetCount );
        }
        return studentIds;
    }

    /**
     * To verify the user is exist in given org
     * 
     * @param userName
     * @param orgId
     * @return
     * @throws Exception
     */
    public boolean isUserExits( String userName, String orgId ) throws Exception {
        boolean isExist = false;
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.SOAP_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.SOAP_CONTENT_TYPE );

            //input params
            HashMap<String, String> params = new HashMap<>();

            //Generating body
            String SOAPBody = SMUtils.getPayload( PayloadFor.RBS, "getAllUserFromOrg.xml" );
            HashMap<String, String> orgDetails = new HashMap<>();
            orgDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgId );
            SOAPBody = generateRequestBody( SOAPBody, orgDetails );

            HashMap<String, String> response = RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.ULC_URL ), headers, params, configProperty.getProperty( ConfigConstants.ULC_READ_ENDPOINT ), SOAPBody );

            //Parsing XML to get the org ID
            JSONObject xmlJSONObj = XML.toJSONObject( response.get( Constants.RESPONSE_BODY ) );

            JSONArray users = xmlJSONObj.getJSONObject( RBSDataSetupConstants.SOAP_ENVELOP ).getJSONObject( RBSDataSetupConstants.SOAP_BODY ).getJSONObject( "tns:GetUsersByCriteriaResponseElement" ).getJSONObject( "tns:Users" ).getJSONArray( "tns:User" );

            for ( Object user : users ) {
                JSONObject userJson = new JSONObject( user.toString() );
                String username = userJson.get( "tns:UserName" ).toString();
                if ( username.equalsIgnoreCase( userName ) ) {
                    isExist = true;
                }
            }

            if ( isExist ) {
                Log.message( "User " + userName + " is already exist in A&E!" );
            } else {
                Log.message( "User " + userName + " is not there in A&E" );
            }
            return isExist;

        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return isExist;
    }

    /**
     * To verify the user is exist in given org
     * 
     * @param userName
     * @param orgId
     * @return
     * @throws Exception
     */
    public List<String> getAllUserNamesFromOrg( String orgId ) throws Exception {
        List<String> usersInOrg = new ArrayList<>();
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.SOAP_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.SOAP_CONTENT_TYPE );

            //input params
            HashMap<String, String> params = new HashMap<>();

            //Generating body
            String SOAPBody = SMUtils.getPayload( PayloadFor.RBS, "getAllUserFromOrg.xml" );
            HashMap<String, String> orgDetails = new HashMap<>();
            orgDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgId );
            SOAPBody = generateRequestBody( SOAPBody, orgDetails );

            HashMap<String, String> response = RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.ULC_URL ), headers, params, configProperty.getProperty( ConfigConstants.ULC_READ_ENDPOINT ), SOAPBody );

            //Parsing XML to get the org ID
            JSONObject xmlJSONObj = XML.toJSONObject( response.get( Constants.RESPONSE_BODY ) );

            JSONArray users = xmlJSONObj.getJSONObject( RBSDataSetupConstants.SOAP_ENVELOP ).getJSONObject( RBSDataSetupConstants.SOAP_BODY ).getJSONObject( "tns:GetUsersByCriteriaResponseElement" ).getJSONObject( "tns:Users" ).getJSONArray( "tns:User" );

            for ( Object user : users ) {
                JSONObject userJson = new JSONObject( user.toString() );
                String username = userJson.get( "tns:UserName" ).toString();
                usersInOrg.add( username );
            }

        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return usersInOrg;
    }

    /**
     * To create the organization settings based organization id
     * 
     * @param orgId
     * @param isDiagnosticEnabled
     * @param isAutoAssignEnabled
     * @return
     * @throws Exception
     */
    public HashMap<String, String> createOrgSettings( String orgId, String isDiagnosticEnabled, String isAutoAssignEnabled ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        //Generating request body
        AtomicReference<String> requestBody = new AtomicReference<>();

        requestBody.set( SMUtils.getPayload( PayloadFor.RBS, FileConstants.CREATE_ORG_SETTING ) );

        requestBody.set( JSONUtil.setProperty( requestBody.get(), Constants.ORGANIZATION_ID, orgId ) );
        requestBody.set( requestBody.get().replace( "{" + AdminConstants.IS_DIAGNOSTIC_ENABLED + "}", isDiagnosticEnabled ) );
        requestBody.set( requestBody.get().replace( "{" + AdminConstants.IS_AUTO_ASSIGN_ENABLED + "}", isAutoAssignEnabled ) );

        //Hitting post call
        return RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.RBS_ORG_SERVICE ), headers, params, String.format( configProperty.getProperty( "org_settings_endPoint" ), orgId ), requestBody.get() );
    }

    /**
     * To get the organization settings based organization id
     * 
     * @param orgId
     * @param isDiagnosticEnabled
     * @param isAutoAssignEnabled
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getOrgSettings( List<String> orgIds ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, configProperty.getProperty( ConfigConstants.BASIC_AUTH ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        //Generating request body
        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.RBS, "getOrgSettings.json" ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "orgIds", orgIds ) );

        //Hitting post call
        return RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.RBS_ORG_SERVICE ), headers, params, configProperty.getProperty( "get_org_settings" ), requestBody.get() );
    }

    /**
     * To get all the users details as JSON Array
     * 
     * @param orgId
     * @return
     * @throws Exception
     */
    public JSONArray getAllUsersAsJsonArry( String orgId ) throws Exception {
        JSONArray users = null;
        JSONObject xmlJSONObj = null;
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.SOAP_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.SOAP_CONTENT_TYPE );

            //input params
            HashMap<String, String> params = new HashMap<>();

            //Generating body
            String SOAPBody = SMUtils.getPayload( PayloadFor.RBS, Constants.GET_ALL_USERS_XML );
            HashMap<String, String> orgDetails = new HashMap<>();
            orgDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgId );
            SOAPBody = generateRequestBody( SOAPBody, orgDetails );

            HashMap<String, String> response = RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.ULC_URL ), headers, params, configProperty.getProperty( ConfigConstants.ULC_READ_ENDPOINT ), SOAPBody );

            //Parsing XML to get the org ID
            xmlJSONObj = XML.toJSONObject( response.get( Constants.RESPONSE_BODY ) );
            try {

                users = xmlJSONObj.getJSONObject( RBSDataSetupConstants.SOAP_ENVELOP ).getJSONObject( RBSDataSetupConstants.SOAP_BODY ).getJSONObject( "tns:GetUsersByCriteriaResponseElement" ).getJSONObject( "tns:Users" ).getJSONArray( "tns:User" );
            } catch ( Exception JSONException ) {
                if ( xmlJSONObj.toString().contains( "No user(s) found for the given search criteria" ) ) {
                    Log.message( "No user(s) found for the given search criteria Returning a empty JSON Array" );
                    users = new JSONArray();
                } else {
                    String json = "["
                            + xmlJSONObj.getJSONObject( RBSDataSetupConstants.SOAP_ENVELOP ).getJSONObject( RBSDataSetupConstants.SOAP_BODY ).getJSONObject( "tns:GetUsersByCriteriaResponseElement" ).getJSONObject( "tns:Users" ).getJSONObject( "tns:User" )
                            + "]";
                    users = new JSONArray( json.toString() );
                }
            }

        } catch ( Exception e ) {
            Log.message( "Exception occured for OrgId :" + orgId + xmlJSONObj.toString() );
            e.printStackTrace();
        }
        return users;
    }

    /**
     * To get all the Teacher Details From Org
     * 
     * @param userName
     * @param orgId
     * @return
     * @throws Exception
     */
    public JSONArray getAllTeachesForOrg( String orgId ) {
        JSONArray users = null;
        JSONArray teacherUsers = new JSONArray();
        try {
            users = getAllUsersAsJsonArry( orgId );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        ArrayList<String> usersInOrg = new ArrayList<String>();

        for ( int i = 0; i < users.length(); i++ ) {
            JSONObject userJson = new JSONObject( users.get( i ).toString() );
            JSONObject aff = null;
            try {
                String singleTeacher = userJson.get( AdminConstants.AFFILIATION_INFO ).toString();
                if ( singleTeacher.charAt( 0 ) == '{' ) {
                    aff = new JSONObject( singleTeacher );
                } else {
                    JSONArray array = new JSONArray( singleTeacher );
                    for ( Object object : array ) {
                        aff = new JSONObject( object.toString() );
                    }
                }
                String role = aff.get( AdminConstants.ORG_ROLE ).toString();
                if ( role.equals( RBSDataSetupConstants.TEACHER_ROLE ) ) {
                    teacherUsers.put( users.get( i ) );
                }
            } catch ( Exception e ) {
                Log.message( "Exception occured for json object: " + userJson.toString() );
                e.printStackTrace();
            }

        }
        return teacherUsers;
    }

    /**
     * To get all the Students Details From Org
     * 
     * @param userName
     * @param orgId
     * @return
     * @throws Exception
     */
    public JSONArray getAllStudentsForOrg( String orgId ) {
        JSONArray users = null;
        JSONArray studentUsers = new JSONArray();
        try {
            users = getAllUsersAsJsonArry( orgId );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        ArrayList<String> usersInOrg = new ArrayList<String>();

        for ( int i = 0; i < users.length(); i++ ) {
            JSONObject userJson = new JSONObject( users.get( i ).toString() );
            JSONObject aff = null;
            try {
                String singleTeacher = userJson.get( AdminConstants.AFFILIATION_INFO ).toString();
                if ( singleTeacher.charAt( 0 ) == '{' ) {
                    aff = new JSONObject( singleTeacher );
                } else {
                    JSONArray array = new JSONArray( singleTeacher );
                    for ( Object object : array ) {
                        aff = new JSONObject( object.toString() );
                    }
                }
                String role = aff.get( AdminConstants.ORG_ROLE ).toString();
                if ( role.equals( RBSDataSetupConstants.STUDENT_ROLE ) ) {
                    studentUsers.put( users.get( i ) );
                }
            } catch ( Exception e ) {
                Log.message( "Exception occured for json object: " + userJson.toString() );
                e.printStackTrace();
            }

        }
        return studentUsers;
    }

    /**
     * To get all the OrgIds under the Admins usernames
     * 
     * @param userNames Sub district admins and Savvas Admin.
     * @return
     * @throws Exception
     */
    public ArrayList<String> getAllSchoolIdsForAdmins( String userNames ) {
        String userId = new RBSUtils().getUserIDByUserName( userNames.toLowerCase() );
        String userDetails = new RBSUtils().getUserWithUserService( userId );
        String orgId = new SMAPIProcessor().getKeyValues( new JSONObject( userDetails.toString() ), RBSDataSetupConstants.ORGANIZATION_ID ).get( 0 );
        String childOrgDetails = new RBSUtils().getChildOrganization( orgId );
        JSONObject orgss = new JSONObject( "{ data:" + childOrgDetails + "}" );

        ArrayList<String> childOrgIds = new SMAPIProcessor().getKeyValues( orgss, RBSDataSetupConstants.ORGANIZATION_ID );
        if ( childOrgIds.equals( new ArrayList<String>() ) ) {
            return new ArrayList( Arrays.asList( orgId ) );
        } else {
            return childOrgIds;
        }
    }

    /**
     * To get the OrgIds that will return schools and sub district wihout
     * schools in it.
     * 
     * @param OrgIds combination for schoolId and subdistrict
     * @return
     */
    public List<String> getOrgIdsForReport( List<String> OrgIds ) {
        List<String> schoolIds = new ArrayList<>();
        List<String> nonSchoolIds = new ArrayList<>();
        List<String> others = new ArrayList<>();

        nonSchoolIds.clear();
        schoolIds.clear();
        OrgIds.stream().forEach( orgId -> {
            String orgDetails = new RBSUtils().getOrg( orgId );
            if ( new SMAPIProcessor().getKeyValues( new JSONObject( orgDetails ), "organizationType" ).get( 0 ).equals( "School" ) ) {
                schoolIds.add( orgId );
            } else {
                nonSchoolIds.add( orgId );
            }
        } );

        nonSchoolIds.stream().forEach( nonschoolId -> {
            String childOrgs = new RBSUtils().getChildOrganization( nonschoolId );
            JSONObject orgss = new JSONObject( "{ data:" + childOrgs + "}" );
            List<String> leafIds = new SMAPIProcessor().getKeyValues( orgss, RBSDataSetupConstants.ORGANIZATION_ID );
            if ( leafIds.isEmpty() ) {
                schoolIds.add( nonschoolId );
            } else {
                others.addAll( leafIds );
            }
        } );
        schoolLeafIds.addAll( schoolIds );
        if ( !nonSchoolIds.isEmpty() ) {
            getOrgIdsForReport( others );
        }
        return schoolLeafIds;
    }

}