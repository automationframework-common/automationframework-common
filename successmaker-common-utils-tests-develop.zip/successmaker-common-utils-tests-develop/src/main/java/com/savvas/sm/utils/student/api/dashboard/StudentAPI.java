package com.savvas.sm.utils.student.api.dashboard;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.FileConstants;

import io.restassured.response.Response;

public class StudentAPI extends EnvProperties {

    /**
     * To get the assignment list for the respective student
     * 
     * @param envUrl
     * @param orgId
     * @param userId
     * @param bearerToken
     * @return
     */
    public static Response getAssignmentListForStudent( String envUrl, String orgId, String userId, String bearerToken ) {
        String endPoint = StudentConstants.GET_ASSIGNMENTS_LIST_ENDPOINT;

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + bearerToken );
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        endPoint = endPoint.replace( "{studentId}", userId );

        return RestAssuredAPIUtil.GET( envUrl, headers, endPoint );
    }

    /**
     * 
     * @param endPoint
     * @param orgId
     * @param userId
     * @param headers
     * @return
     */
    public static Response getAssignmentListBffForStudent( String endPoint, String orgId, String userId, Map<String, String> headers ) {

        String requestBody = "{\"operationName\":\"GetStudentAssignments\",\"variables\":{\"userId\":\"{userId}\",\"organizationId\":\"{orgId}\"},\"query\":\"query GetStudentAssignments($userId: String!, $organizationId: String!) {\\n  getStudentAssignments(userId: $userId, orgId: $organizationId) {\\n    courseName\\n    courseType\\n    creatorId\\n    startDate\\n    assignmentUserId\\n    subjectId\\n    assignmentId\\n    sessionLengthMin\\n    creatorTitle\\n    creatorFirstName\\n    creatorMiddleName\\n    creatorLastName\\n  productId\\n  __typename\\n}\\n}\\n\"}";
        String mfeUrl = configProperty.getProperty( "StudentDashboardBff" );
        requestBody = requestBody.replace( "{userId}", userId );
        requestBody = requestBody.replace( "{orgId}", orgId );

        Response response = RestAssuredAPIUtil.POSTGraphQl( mfeUrl, headers, requestBody, endPoint );

        return response;

    }

    /**
     * To hit the session this week API for student
     * 
     * @param smUrl
     * @param studentId
     * @param orgId
     * @param accesstoken
     * @return
     */
    public static Response getSessionThisWeekUsageForStudent( String smUrl, String studentId, String orgId, String accesstoken ) {
        //To get the end point
        String endPoint = StudentConstants.POST_SESSTION_THIS_WEEK_USAGE;

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + accesstoken );
        headers.put( Constants.USERID_SM_HEADER, studentId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        endPoint = endPoint.replace( "{studentId}", studentId );

        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.STUDENT, FileConstants.GET_SESSION_THIS_WEEK_USAGE ) );

        //To get first day of week and last day of week
        Calendar calendar = Calendar.getInstance();
        calendar.set( Calendar.DAY_OF_WEEK, Calendar.MONDAY );
        calendar.set( Calendar.HOUR_OF_DAY, 0 );
        calendar.set( Calendar.MINUTE, 0 );
        calendar.set( Calendar.SECOND, 0 );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "thisWeekStartDate", calendar.getTime().getTime() / 1000 ) );

        calendar.add( Calendar.DATE, 7 );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "thisWeekEndDate", calendar.getTime().getTime() / 1000 ) );

        Log.message( "Request Paylod - " + requestBody.get() );
        return RestAssuredAPIUtil.POST( smUrl, headers, requestBody.get(), endPoint );
    }

    /**
     * To hit the session this week BFFF for student
     * 
     * @param smUrl
     * @param studentId
     * @param orgId
     * @param accesstoken
     * @return
     */
    public static Response sessionUsageThisWeekBFF( String studentId, String orgId, String accesstoken ) {
        //To get the BFF url
        String mfeUrl = configProperty.getProperty( "StudentDashboardBff" );

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + accesstoken );
        headers.put( Constants.USERID_SM_HEADER, studentId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.STUDENT, FileConstants.SESSION_THIS_WEEK_USAGE_BFFF ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.userId", studentId ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.organizationId", orgId ) );

        //To get first day of week and last day of week
        Calendar calendar = Calendar.getInstance();
        calendar.set( Calendar.DAY_OF_WEEK, Calendar.MONDAY );
        calendar.set( Calendar.HOUR_OF_DAY, 0 );
        calendar.set( Calendar.MINUTE, 0 );
        calendar.set( Calendar.SECOND, 0 );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.thisWeekStartDate", String.valueOf( calendar.getTime().getTime() / 1000 ) ) );

        calendar.add( Calendar.DATE, 7 );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.thisWeekEndDate", String.valueOf( calendar.getTime().getTime() / 1000 ) ) );

        Log.message( "Request Paylod - " + requestBody.get() );
        return RestAssuredAPIUtil.POST( mfeUrl, headers, requestBody.get(), StudentConstants.BFF_END_POINT );
    }

}
