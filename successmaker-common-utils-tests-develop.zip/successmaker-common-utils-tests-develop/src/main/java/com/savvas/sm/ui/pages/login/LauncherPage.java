package com.savvas.sm.ui.pages.login;

import static org.testng.AssertJUnit.assertTrue;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.utils.SMUtils;

public class LauncherPage extends LoadableComponent<LauncherPage> {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    private final WebDriver driver;
    private String smUrl;

    // ********* SuccessMaker Launcher/Login Page Elements ***************
    @FindBy ( id = "launchButton" )
    WebElement smLaunchButton;

    /**
     * 
     * Constructor class for Launcher page Here we initializing the driver for
     * page factory objects.
     * 
     * @param driver
     * @param url
     */
    public LauncherPage( WebDriver driver, String url ) {

        this.driver = driver;
        smUrl = url;
        PageFactory.initElements( driver, this );
    }

    @Override
    protected void isLoaded() {
        assertTrue( "Launcher page is not loaded!", driver.getCurrentUrl().contains( smUrl ) );

        if ( SMUtils.waitForElement( driver, smLaunchButton ) ) {
            Log.message( "SM Launcher page loaded successfully!" );
        } else {
            Log.fail( "SM Launcher page did not load." );
        }
    }

    @Override
    protected void load() {
        driver.get( smUrl );
        Log.message( "Hit the SM Instance Url - " + smUrl );
    }

    /**
     * navigates to EB sign in page
     * 
     * @return EBPlusAndAutoSignInPage
     */
    public EBPlusAndAutoSignInPage navigateToEBPlusAndAutoLoginPage() {
        String browserName = configProperty.getProperty( "BrowserPlatformToRun" ).toLowerCase();
        if ( browserName.contains( "safari" ) || browserName.contains( "firefox" ) ) {

            String urlForSafari = smUrl + "/lms/sso.view";
            driver.get( urlForSafari );
            Log.message( "Firefox/Safari issue- Using the EB Instance Url with serive url as SM- " + urlForSafari );
        } else {
            //get the current window handle
            String smLauncherWindowHandle = driver.getWindowHandle();

            SMUtils.click( driver, smLaunchButton );
            SMUtils.nap( 0.2 );
            //get the window counts
            Set<String> windowHandles = driver.getWindowHandles();
            for ( String currentWindow : windowHandles ) {
                // Switch to the new window-Savvas Sign In
                if ( !( currentWindow.equalsIgnoreCase( smLauncherWindowHandle ) ) ) {
                    //close the SM_Launcher window
                    driver.close();
                    driver.switchTo().window( currentWindow );
                }
            }
        }

        return new EBPlusAndAutoSignInPage( driver ).get();
    }

    /**
     * Validates whether EB sign in page opens in a new window
     * 
     * @return
     */
    public boolean validateEBSignPageOpenInNewWindow() {
        //get the current window handle
        String smLauncherWindowHandle = driver.getWindowHandle();

        SMUtils.click( driver, smLaunchButton );
        SMUtils.nap( 0.2 );

        //get the window counts
        Set<String> windowHandles = driver.getWindowHandles();
        for ( String currentWindow : windowHandles ) {
            // Switch to the new window-Savvas Sign In
            if ( !( currentWindow.equalsIgnoreCase( smLauncherWindowHandle ) ) ) {
                //close the SM_Launcher window
                driver.close();
                driver.switchTo().window( currentWindow );
            }
        }

        return windowHandles.size() == 2;
    }

}
