package com.savvas.sm.utils.sql.helper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.stream.IntStream;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.DBQueryFor;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;

/**
 * This class used to execute the query and functions for Course in database
 * 
 * @author dharani.chandrasekar
 *
 */
public class SqlHelperCourses {
    /**
     * This method is used to create the Course
     * 
     * @param orphan
     * @param content_base_id
     * @param content_course_name
     * @return
     */
    public String createCourse( boolean orphan, int content_base_id, String content_course_name ) {
        String query;
        if ( orphan ) {
            query = "INSERT INTO School.content_base (content_base_id,subject_id, product_id,parent_content_base_id, content_base_creator_id,content_base_name,selected_grade_id,content_type_base_id, is_assigned,date_created,pearson_content_base_id,isdeleted,is_hidden,date_updated)"
                    + "VALUES(" + content_base_id + ",1,1,null,26778," + "'Orphan_" + content_course_name + "'" + ",null,2,0,current_timestamp,null,0,null,current_timestamp)";
        } else {
            query = "INSERT INTO School.content_base (content_base_id,subject_id, product_id,parent_content_base_id, content_base_creator_id,content_base_name,selected_grade_id,content_type_base_id, is_assigned,date_created,pearson_content_base_id,isdeleted,is_hidden,date_updated)"
                    + "VALUES(" + content_base_id + ",1,2,1,25082," + "'Unassigned_" + content_course_name + "'" + ",4,4,0,current_timestamp,null,0,null,current_timestamp)";
        }
        try {
            SQLUtil.executeInsDelQueryWithoutResult( query );

        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return query;
    }

    /**
     * This method is used to get the Course
     * 
     * @param courseId
     * @return
     */
    public String getCourse( String courseId ) {
        String query;
        String courseIdFromDB = null;
        try {

            query = "select * from school.content_base where content_base_id=" + "'" + courseId + "'";
            List<Object[]> listItems = SQLUtil.executeQuery( query );
            List<String> arrList = new ArrayList<String>();
            for ( Object[] list : listItems ) {
                if ( list.length > 0 ) {
                    arrList.add( list[0].toString() );
                }
            }
            if ( arrList.size() == 0 ) {
                courseIdFromDB = null;
            } else {
                courseIdFromDB = arrList.get( 0 );
                return courseIdFromDB;
            }
        }

        catch ( Exception e ) {
            e.printStackTrace();
        }
        return courseIdFromDB;
    }

    /**
     * This method is used to verify the deleted course
     * 
     * @param courseId
     * @return
     */
    public boolean isCourseDeleted( String courseId ) {
        boolean flag = false;
        String courseIdFromDB = getCourse( courseId );
        if ( courseIdFromDB == null ) {
            flag = true;
        } else {
            flag = false;
        }
        return flag;
    }

    /**
     * To get the assignment ID based on name
     * 
     * @param assignmentName
     * @return
     */
    public String getAssignmentIDUsingName( String assignmentName ) {
        String assignmentID = null;
        String queryString = "select assignment_id from school.assignment where assignment_title='" + assignmentName + "'";
        List<Object[]> listItems = SQLUtil.executeQuery( queryString );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : listItems ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        assignmentID = arrList.get( 0 );
        return assignmentID;

    }

    /**
     * To get the assignment user details
     * 
     * @param assignmentName
     * @return
     */
    public HashMap<String, String> getAssignmentUserDetails( String assignmentName ) {
        HashMap<String, String> assignmentuserDetails = new HashMap<>();
        String assignmentId = getAssignmentIDUsingName( assignmentName );

        String queryString = "select assignment_id,assignment_user_id,person_id from school.assignment_user where assignment_id=" + assignmentId;
        List<Object[]> listItems = null;
        listItems = SQLUtil.executeQuery( queryString );
        HashMap<String, String> arrMap = null;
        if ( listItems != null && listItems.size() > 0 ) {
            arrMap = new HashMap<String, String>();
            arrMap.put( Constants.ASSIGNMENT_ID, listItems.get( 0 )[0].toString() );
            arrMap.put( Constants.ASSIGNMENT_USER_ID, listItems.get( 0 )[1].toString() );
            arrMap.put( Constants.PERSONID, listItems.get( 0 )[2].toString() );

        }
        return arrMap;
    }

    /**
     * To get the assignment user id for the given student with assignment ID
     * 
     * @param studentPersonId
     * @param assignmentID
     * @return
     */
    public String getAssignmentUserId( String studentPersonId, String assignmentID ) {
        String assignmentUserID = null;
        String queryString = null;
        queryString = SMUtils.getDBQuery( DBQueryFor.TEACHER, "getAssignmentUserID.sql" );
        queryString = String.format( queryString, assignmentID, studentPersonId );
        List<Object[]> listItems = SQLUtil.executeQuery( queryString );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : listItems ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        return assignmentUserID = arrList.get( 0 );

    }

    /**
     * To create the fluency files for given student assignment user ID
     * 
     * @param fileCount
     * @param assignmentUserId
     * @return
     * @throws Exception
     */
    public List<String> createFluencyFiles( int fileCount, int assignmentUserId ) throws Exception {
        List<String> fluencyFiles = new ArrayList();
        try {
            List<String> fluencyFileNames = getFluencyLoName( fileCount );
            IntStream.rangeClosed( 1, fileCount ).forEach( count -> {
                int aUserFileNo = new Random().nextInt( 9999999 );
                String fluencyFileName = fluencyFileNames.get( count ).toString();
                String queryString1 = null;
                try {
                    queryString1 = SMUtils.convertFileToString( SMUtils.getQueryDirPath() + "fluencyFileGenerationQuery.sql" );
                    queryString1 = String.format( queryString1, ( aUserFileNo + new Random().nextInt( fileCount ) ), assignmentUserId, fluencyFileName );
                } catch ( IOException e ) {
                    Log.message( "File not dound." );
                    e.printStackTrace();
                }
                List<Object[]> listItems = SQLUtil.executeQuery( queryString1 );
                if ( listItems.isEmpty() ) {
                    fluencyFiles.add( fluencyFileName );
                }

            } );
            return fluencyFiles;
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return fluencyFiles;

    }

    /**
     * To get the fluency file
     * 
     * @param count
     * @return
     */
    public List<String> getFluencyLoName( int count ) {
        String queryString = null;

        try {
            queryString = SMUtils.convertFileToString( SMUtils.getQueryDirPath() + "getFluencyFileNames.sql" );
        } catch ( IOException e ) {
            Log.message( "File not dound." );
            e.printStackTrace();
        }

        List<String[]> fluencyNames = null;
        List<Object[]> listItems = SQLUtil.executeQuery( queryString );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : listItems ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }

        return arrList;

    }

    /**
     * To get last session report math grid values
     * 
     * @return
     * @throws Exception
     */
    public List<String> getLastSessionMathGridValues( String studentUserId ) {

        String queryString = SMUtils.getPayload( PayloadFor.ADMIN, "getLastSessionMathGridValues.sql" );
        queryString = String.format( queryString, studentUserId );
        List<Object[]> MathDBQuery = SQLUtil.executeQuery( queryString );
        List<String> mathValuesLSR = new ArrayList<String>();

        for ( int i = 1; i < 8; i++ ) {
            mathValuesLSR.add( MathDBQuery.stream().findFirst().get()[i].toString() );

        }
        Log.message( mathValuesLSR.toString() );
        return mathValuesLSR;
    }

    /**
     * To get last session report reading grid values
     * 
     * @return
     * @throws Exception
     */
    public List<String> getLastSessionReadingGridValues( String studentUserId ) {

        String queryString = SMUtils.getPayload( PayloadFor.ADMIN, "getLastSessionReadingGridValues.sql" );
        queryString = String.format( queryString, studentUserId );
        List<Object[]> readingDBQuery = SQLUtil.executeQuery( queryString );
        List<String> readingValuesLSR = new ArrayList<String>();

        for ( int i = 1; i < 14; i++ ) {
            readingValuesLSR.add( readingDBQuery.stream().findFirst().get()[i].toString() );

        }
        Log.message( readingValuesLSR.toString() );
        return readingValuesLSR;
    }

    /**
     * To get all the shared courses
     * 
     * @return
     * @throws IOException
     */
    public Map<String, Map<String, String>> getAllSharedCourses() throws IOException {
        String queryString = SMUtils.getPayload( PayloadFor.ADMIN, "getSharedCourses.sql" );
        List<Object[]> listItems = null;
        int itr = 0;
        do {
            try {
                listItems = SQLUtil.executeQuery( queryString );
            } catch ( Exception e ) {
                Log.event( "Getting Issue in query Execution..... Retrying!!!" );
            }
            itr++;
        } while ( Objects.isNull( listItems ) && itr < 3 );
        Map<String, Map<String, String>> sharedCourses = new HashMap<>();
        listItems.forEach( eachItem -> {
            if ( Objects.nonNull( eachItem[2] ) ) {
                Map<String, String> sharedCourse = new HashMap<String, String>();
                sharedCourse.put( "courseName", eachItem[1].toString() );
                sharedCourse.put( "sharedOrgCount", eachItem[3].toString() );
                sharedCourse.put( "ownerOrgId", eachItem[2].toString() );
                sharedCourses.put( eachItem[0].toString(), sharedCourse );
            }
        } );
        return sharedCourses;
    }

    public String getSharedCourseEnrollmentID( String courseId ) {
        Log.message( "Getting the Enrollment ID of Shared Course" );
        String query = "Select enrollment_option_id from enrollment_option where content_base_id = " + courseId + " and display_name = 'Shared Courses'";
        List<Object[]> executeQuery = SQLUtil.executeQuery( query );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : executeQuery ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        return arrList.get( 0 );
    }

    /**
     * This method is used to get shared course org id and its assign status
     * 
     * @param courseId
     * @return
     */
    public Map<String, String> getSharedCourseOrgIdAndAssignedStatus( String courseId ) {
        Log.message( "Getting Shared Course Organization id and its assigned status" );
        String query = "select organization_id, is_assigned from organization_content_base where content_base_id = " + courseId;
        List<Object[]> executeQuery = SQLUtil.executeQuery( query );
        Map<String, String> sharedCourseOrgIdAndAssignedStatus = new HashMap<String, String>();
        executeQuery.forEach( org -> sharedCourseOrgIdAndAssignedStatus.put( org[0].toString(), org[1].toString() ) );
        return sharedCourseOrgIdAndAssignedStatus;
    }

    /**
     * This method will return the Skill details for the given skill ID
     * 
     * @param skillId
     * @param isMath
     * @return Skill Name
     */
    public String getSkillDetails( String skillId, boolean isMath ) {
        String queryString = null;
        List<Object[]> listItems = null;
        if ( isMath ) {
            queryString = "select lobj_description from learning_object where learning_object_id =" + skillId;
            listItems = SQLUtil.executeQuery( queryString );
        } else {
            queryString = "select skill_obj_description from skill_objectives where skill_objective_id =" + skillId;
            listItems = SQLUtil.executeQuery( queryString );
        }
        return listItems.get( 0 )[0].toString();
    }

    /**
     * This method used to get the LO/Sco details for given cttype ID.
     * 
     * @param cttypeId
     * @return LO / SCO ID, Desccription
     */
    public HashMap<String, String> getCatalogDetails( String cttypeId ) {

        String query = "select catalog_num,lobj_description from learning_object where learning_object_id =" + cttypeId;
        List<Object[]> listItems = null;
        listItems = SQLUtil.executeQuery( query );
        HashMap<String, String> arrMap = null;
        if ( listItems != null && listItems.size() > 0 ) {
            arrMap = new HashMap<String, String>();
            arrMap.put( SQLConstants.Course.CATALOG_NUMBER, listItems.get( 0 )[0].toString() );
            arrMap.put( SQLConstants.Course.LO_OBJECT_DESCRIPTION, listItems.get( 0 )[1].toString() );
        }
        return arrMap;
    }

    /**
     * This method is used to Delete the custom courses by rumbaID
     * 
     * @param rumbaID
     * @throws IOException
     * @throws InterruptedException
     */

    public static void deleteCustomCourseByRumbaID( String rumbaID ) throws IOException, InterruptedException {

        String query = SMUtils.getDBQuery( DBQueryFor.TEACHER, "deleteCustomcourses.sql" );
        query = query.replace( "<rumbaID>", rumbaID );
        boolean iscourseDeleted = false;
        int iter = 0;
        while ( ( !iscourseDeleted ) && iter < 3 ) {
            try {
                iscourseDeleted = SQLUtil.executeInsDelQueryWithoutResult( query );
            } catch ( Exception e ) {
                if ( iter == 2 ) {
                    Log.message( "Issue in deleting the courses for the teacher - " + rumbaID + "." + e.getMessage() );
                } else {
                    Log.message( "Issue in deleting the courses for the teacher - " + rumbaID + ".Retrying...." );
                    Thread.sleep( 10000 );
                }
            } finally {
                iter++;
            }
        }

        if ( iscourseDeleted ) {
            Log.message( "Custom courses Deleted for the Teacher: " + rumbaID );
        } else {
            Log.message( "Custom courses not Deleted for the Teacher: " + rumbaID );
        }
    }

    /**
     * To get the Assignment Listing Details
     * 
     * @param staffid
     * @return
     */
    public static HashMap<String, List<String>> getAssignmentListingDetails( String staffid ) {
        String queryString = "select assignment_id,content_base_id,assignment_title from school.assignment where assignment_owner_id=" + "'" + staffid + "'";
        List<Object[]> listItems = null;
        listItems = SQLUtil.executeQuery( queryString );
        HashMap<String, List<String>> arrMap = null;
        arrMap = new HashMap<String, List<String>>();

        List<String> assignment_id = new ArrayList<>();
        List<String> content_base_id = new ArrayList<>();
        List<String> assignment_name = new ArrayList<>();
        for ( int i = 0; i < listItems.size(); i++ ) {

            if ( listItems != null && listItems.size() > 0 ) {

                assignment_id.add( listItems.get( i )[0].toString() );
                content_base_id.add( listItems.get( i )[1].toString() );
                assignment_name.add( listItems.get( i )[2].toString() );

            }
        }

        arrMap.put( AssignmentAPIConstants.CONTENT_BASE_ID, content_base_id );
        arrMap.put( AssignmentAPIConstants.ASSIGNMENT_ID, assignment_id );
        arrMap.put( AssignmentAPIConstants.ASSIGNMENT_NAME, assignment_name );
        return arrMap;
    }

    /**
     * To get the students Active count
     * 
     * @param assignmentId
     * @return
     */

    public static String getStudentCountForAssignment( String assignmentId ) {
        String queryString = "select count(*) from school.assignment_user where active=1 and assignment_id =" + assignmentId;
        List<Object[]> listItems = null;
        listItems = SQLUtil.executeQuery( queryString );
        HashMap<String, String> arrMap = null;
        if ( listItems != null && listItems.size() > 0 ) {
            arrMap = new HashMap<String, String>();
            arrMap.put( AssignmentAPIConstants.STUDENT_COUNT, listItems.get( 0 )[0].toString() );
        }
        return arrMap.get( AssignmentAPIConstants.STUDENT_COUNT );
    }

    /**
     * To get the Recent assignment listing details (in Home Page)
     * 
     * @param staffid
     * @return
     */
    public static HashMap<String, List<String>> getRecentAssignmentListingDetails( String staffid ) {

        String queryString = "select assignment_id,content_base_id,assignment_title from school.assignment where assignment_owner_id=" + "'" + staffid + "'" + " order by date_updated desc limit 4";
        List<Object[]> listItems = null;
        listItems = SQLUtil.executeQuery( queryString );
        HashMap<String, List<String>> arrMap = null;
        arrMap = new HashMap<String, List<String>>();

        List<String> assignment_id = new ArrayList<>();
        List<String> content_base_id = new ArrayList<>();
        List<String> assignment_name = new ArrayList<>();
        for ( int i = 0; i < listItems.size(); i++ ) {

            if ( listItems != null && listItems.size() > 0 ) {

                assignment_id.add( listItems.get( i )[0].toString() );
                content_base_id.add( listItems.get( i )[1].toString() );
                assignment_name.add( listItems.get( i )[2].toString() );

            }
        }

        arrMap.put( AssignmentAPIConstants.CONTENT_BASE_ID, content_base_id );
        arrMap.put( AssignmentAPIConstants.ASSIGNMENT_ID, assignment_id );
        arrMap.put( AssignmentAPIConstants.ASSIGNMENT_NAME, assignment_name );
        return arrMap;
    }

    /**
     * To get the ContentBaseId
     * 
     * @param contentBaseId
     * @return
     */
    public static HashMap<String, String> getContentBaseDetails( String contentBaseId ) {
        String queryString = "select subject_id,product_id from school.content_base where content_base_id=" + contentBaseId;
        List<Object[]> listItems = null;

        listItems = SQLUtil.executeQuery( queryString );
        HashMap<String, String> arrMap = null;
        if ( listItems != null && listItems.size() > 0 ) {
            arrMap = new HashMap<String, String>();
            arrMap.put( AssignmentAPIConstants.SUBJECT_ID, listItems.get( 0 )[0].toString() );
            arrMap.put( AssignmentAPIConstants.PRODUCT_ID, listItems.get( 0 )[1].toString() );
            String query = "select subject_name from successmaker.subject where subject_id=" + arrMap.get( AssignmentAPIConstants.SUBJECT_ID );
            listItems = SQLUtil.executeQuery( query );
            arrMap.put( AssignmentAPIConstants.SUBJECT_NAME, listItems.get( 0 )[0].toString() );
        }
        return arrMap;
    }

    /**
     * To get the active assignment user id for the given student with
     * assignment ID
     * 
     * @param studentPersonId
     * @param assignmentID
     * @return
     */
    public String getActiveAssignmentUserId( String studentPersonId, String assignmentID ) {
        String assignmentUserID = null;
        String queryString = "select assignment_user_id from school.assignment_user where assignment_id=%s and person_id='%s' and isdeleted='0'";
        queryString = String.format( queryString, assignmentID, studentPersonId );
        List<Object[]> listItems = SQLUtil.executeQuery( queryString );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : listItems ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        return assignmentUserID = arrList.get( 0 );
    }

    /**
     * To get content Base ID by courseName
     * 
     * @param courseName
     * @return
     */
    public static String getContenBaseIdByName( String courseName ) {

        String queryString = "select content_base_id from school.content_base where content_base_name = '<courseName>'";
        queryString = queryString.replace( "<courseName>", courseName );
        List<Object[]> listItems = SQLUtil.executeQuery( queryString );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : listItems ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        return arrList.get( 0 );
    }

    /**
     * To get the assignment user details
     * 
     * @param assignmentName
     * @return
     */
    public List<HashMap<String, String>> getCourseForOrg( String orgId, int subjectId ) {
        List<HashMap<String, String>> courseDetails = new ArrayList<>();

        String queryString = SMUtils.getDBQuery( DBQueryFor.ADMIN, AdminConstants.COURSE_LISTING_DB_QUERY_FILENAME );
        queryString = queryString.replace( "{organizationId}", orgId );
        queryString = queryString.replace( "{subjectTypeId}", String.valueOf( subjectId ) );

        List<Object[]> listItems = null;
        listItems = SQLUtil.executeQuery( queryString );
        HashMap<String, String> arrMap = null;
        for ( int i = 0; i < listItems.size(); i++ ) {
            if ( listItems != null && listItems.size() > 0 ) {
                arrMap = new HashMap<String, String>();
                arrMap.put( Constants.ASSIGNMENT_ID, listItems.get( i )[0].toString() );
                arrMap.put( Constants.ASSIGNMENT_OWNER_ID, listItems.get( i )[1].toString() );
                arrMap.put( Constants.ASSIGNMENT_TITLE_DB, listItems.get( i )[2].toString() );
                arrMap.put( Constants.CONTENT_BASE_ID_DB, listItems.get( i )[3].toString() );
                arrMap.put( Constants.PRODUCT_ID_DB, listItems.get( i )[4].toString() );
                courseDetails.add( arrMap );
            }
        }
        return courseDetails;
    }

    /**
     * To get the assignment details for the org
     * 
     * @param orgId
     * @param subjectId
     * @param studentIds
     * @return
     */
    public List<HashMap<String, String>> getCourseForOrg( int subjectId, List<String> studentIds ) {
        List<HashMap<String, String>> courseDetails = new ArrayList<>();

        String queryString = SMUtils.getDBQuery( DBQueryFor.ADMIN, AdminConstants.COURSE_LISTING_DB_QUERY_FILENAME );
        queryString = queryString.replace( "{subjectTypeId}", String.valueOf( subjectId ) );

        StringBuffer students = new StringBuffer();

        for ( String student : studentIds ) {
            students.append( String.format( "'%s',", student ) );
        }
        students.deleteCharAt( students.length() - 1 );
        queryString = queryString.replace( "{userId}", students );

        List<Object[]> listItems = null;
        listItems = SQLUtil.executeQuery( queryString );
        HashMap<String, String> arrMap = null;
        if ( !listItems.isEmpty() ) {
            for ( int i = 0; i < listItems.size(); i++ ) {
                if ( listItems != null && listItems.size() > 0 ) {
                    arrMap = new HashMap<String, String>();

                    arrMap.put( Constants.ASSIGNMENT_ID, listItems.get( i )[0].toString() );
                    arrMap.put( Constants.ASSIGNMENT_OWNER_ID, listItems.get( i )[1].toString() );
                    arrMap.put( Constants.ASSIGNMENT_TITLE_DB, listItems.get( i )[2].toString() );
                    arrMap.put( Constants.CONTENT_BASE_ID_DB, listItems.get( i )[3].toString() );
                    arrMap.put( Constants.PRODUCT_ID_DB, listItems.get( i )[4].toString() );
                    courseDetails.add( arrMap );
                }
            }
        }

        return courseDetails;
    }

    /**
     * To get LOID with bankID for the random standards
     * 
     * @param loCountforCourse
     * @return
     * @throws IOException
     */
    public static HashMap<String, String> getSCOIDsRandomStandard( String standID, String gradeID, Boolean isMTInstance ) throws IOException {
        HashMap<String, String> bankLODetails = new HashMap<String, String>();
        String bankID = "";
        String scoID = "";
        List<String> loIds = new ArrayList<String>();
        String query = null;

        if ( Boolean.TRUE.equals( isMTInstance ) ) {
            query = SMUtils.convertFileToString( SMUtils.getQueryDirPath() + "getLObyStandard_mt.sql" );
        } else {
            query = SMUtils.convertFileToString( SMUtils.getQueryDirPath() + "getLObyStandard.sql" );
        }
        query = query.replace( "<standard_id>", standID ).replace( "<grade_id>", gradeID );
        List<Object[]> result = SQLUtil.executeQuery( query );
        for ( Object[] list : result ) {
            if ( list.length > 0 ) {
                bankID = list[0].toString();
                scoID = list[1].toString();
            }
        }
        String[] splitIndividualID = scoID.split( ";" );
        for ( int loCount = 0; loCount < 1; loCount++ ) {
            loIds.add( splitIndividualID[loCount] + "_" + bankID );
        }
        bankLODetails.put( "bankID", bankID );
        bankLODetails.put( "scoID", loIds.get( 0 ) );
        Log.message( "LO id is " + loIds.get( 0 ) );
        Log.message( "bank id is " + bankID );
        return bankLODetails;
    }

    /**
     * To get LOID with Standard ID for the given course type
     * 
     * @param courseType
     * @return
     * @throws IOException
     */
    public static HashMap<String, String> getGradeStandardID( String courseType, Boolean isMTInstance ) {
        try {
            HashMap<String, String> gradeStandardID = new HashMap<String, String>();
            HashMap<String, String> scoID = new HashMap<String, String>();
            List<String> gradeDetails = SqlHelperAssignment.getRandomStandardGradeID( courseType, isMTInstance );
            Log.message( "details: " + gradeDetails.get( 1 ) );
            Log.message( "details 2: " + gradeDetails.get( 0 ) );
            gradeStandardID.put( "GradeID", gradeDetails.get( 1 ) );
            gradeStandardID.put( "StandardID", gradeDetails.get( 0 ) );
            scoID = getSCOIDsRandomStandard( gradeStandardID.get( "StandardID" ), gradeStandardID.get( "GradeID" ), isMTInstance );
            gradeStandardID.put( "bankID", scoID.get( "bankID" ) );
            gradeStandardID.put( "scoID", scoID.get( "scoID" ) );
            return gradeStandardID;

        } catch ( IOException e ) {
            Log.message( "Issue in Fetching Grade & Standard framework ID" );
            return null;
        }
    }

    /**
     * To get LOID with Skill ID/Cttype ID for the given course type
     * 
     * @param courseType
     * @return
     * @throws IOException
     */
    public static HashMap<String, String> getSCOIDsOfRandomSkillID( String courseType ) throws IOException {
        HashMap<String, String> skillLODetails = new HashMap<String, String>();
        String gradeID = "";
        String parentNode = "";
        String loID = "";
        String query = SMUtils.convertFileToString( SMUtils.getQueryDirPath() + "getGradeIdForSkill.sql" );
        query = query.replace( "<subject_name>", "'" + courseType + "'" );
        List<Object[]> result = SQLUtil.executeQuery( query );
        for ( Object[] list : result ) {
            if ( list.length > 0 ) {
                gradeID = list[0].toString();
            }
        }
        String queryForParentID = SMUtils.convertFileToString( SMUtils.getQueryDirPath() + "getParentIdForSkill.sql" );
        queryForParentID = queryForParentID.replace( "<grade_id>", gradeID );
        List<Object[]> resultForParentID = SQLUtil.executeQuery( queryForParentID );
        for ( Object[] list : resultForParentID ) {
            if ( list.length > 0 ) {
                parentNode = list[0].toString();
            }
        }
        String queryForLOID = SMUtils.convertFileToString( SMUtils.getQueryDirPath() + "getLoObjectIdForSkill.sql" );
        queryForLOID = queryForLOID.replace( "<parent_cttype_id>", parentNode );
        List<Object[]> resultForLOID = SQLUtil.executeQuery( queryForLOID );
        for ( Object[] list : resultForLOID ) {
            if ( list.length > 0 ) {
                loID = list[0].toString();
            }
        }
        skillLODetails.put( "GradeID", gradeID );
        skillLODetails.put( "ParentNode", parentNode );
        skillLODetails.put( "LOName", loID + "_" + parentNode );
        return skillLODetails;

    }

}
