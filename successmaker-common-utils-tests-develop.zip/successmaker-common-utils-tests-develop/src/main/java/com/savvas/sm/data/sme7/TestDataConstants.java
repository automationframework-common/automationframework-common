package com.savvas.sm.data.sme7;

public interface TestDataConstants {

    interface ExcelSheetName {
        public final static String UI_MASTERY = "UI_Mastery";
    }

    public static String COURSETYPE_ID = "COURSETYPE_ID";
    public static String Admin_USERNAME = "Admin_USERNAME";
    public static String Admin_PASSWORD = "Admin_PASSWORD";
    public static String T_USERNAME = "T_USERNAME";
    public static String T_PASSWORD = "T_PASSWORD";
    public static String S_USERNAME = "S_USERNAME";
    public static String S_PASSWORD = "S_PASSWORD";
    public static String ORG_NAME = "ORGANIZATION_NAME";
    public static String ORG_ID = "ORGANIZATION_ID";
    public static String STAFF_NAME = "STAFF_NAME";
    public static String STAFF_ID = "STAFF_ID";
    public static String STUDENT_NAME = "STUDENT_NAME";
    public static String STUDENT_ID = "STUDENT_ID";
    public static String STUDENT_ID_REMOVE = "STUDENT_ID_REMOVE";
    public static String CONTENTBASE_ID = "CONTENTBASE_ID";
    public static String ASSIGNMENT_NAME = "ASSIGNMENT_NAME";
    public static String ASSIGNMENT_ID = "ASSIGNMENT_ID";
    public static String ASSIGNMENT_USER_ID = "ASSIGNMENT_USER_ID";
    public static String FILE_IDS = "FILE_IDS";
    public static String APPLY_TO_USERS = "APPLY_TO_USERS";
    public static String EXP_RESP_CODE = "EXP_RESP_CODE";
    public static String EXP_RESP = "EXP_RESPONSE";
    public static String EXP_RESP1 = "EXP_RESPONSE1";
    public static String EXP_RESP_CODE1 = "EXP_RESP_CODE1";
    public static String JSON_BODY = "JSON_BODY";
    public static String JSON_BODY1 = "JSON_BODY1";
    public static String POST_JSON_BODY = "POST_JSON_BODY";
    public static String COURSE_ID = "COURSE_ID";
    public static String DESCRIPTION = "DESCRIPTION";
    public static Object REPORT_ID = "REPORT_ID";
    public static Object REPORT_FILTERS = "REPORT_FILTERS";
    public static Object FILTER_ID = "FILTER_ID";
    public static Object F_NAME = "F_NAME";
    public static final String GROUP_ID = "GROUP_ID";
    public static final String EXP_HEADER_CONTENT_TYPE = "EXP_HEADER_CONTENT_TYPE";
    public static final String EXP_HEADER_CONTENT_LENGTH = "EXP_HEADER_CONTENT_LENGTH";
    public static final String EXP_HEADER_CONTENT_DISPOSITION = "EXP_HEADER_CONTENT_DISPOSITION";
    public static Object GET_FLUENCY_RESPONSE = "GET_FLUENCY_RESPONSE";
    public static final String TC_NAME = "TC_NAME";
    public static final String TLEVEL = "LEVEL";
    public static String PERSON_ID = "PERSON_ID";
    public static String CTTYPE_ID = "CTTYPE_ID";
    public static String CONTENT_BASE_ID = "CONTENT_BASE_ID";
    public static String LEVEL = "LEVEL";
    public static String INCLUDE_LOS = "INCLUDE_LOS";
    public static Object BANK_ID = "BANK_ID";
    public static String MATH_HIERARCHY_QUERY = "MATH_HIERARCHY_QUERY";
    public static String ASSIGN = "ASSIGN";
    public static String DEL_GROUP = "DEL_GROUP";
    public static String DEL_STUDENT = "DEL_STUDENT";
    public static final String PUT_BODY = "PUT_BODY";
    public static final String PUT_BODY_RESET = "PUT_BODY_RESET";
    public static String STUDENT_ID1 = "STUDENT_ID1";
    public static String STUDENT_ID2 = "STUDENT_ID2";
    public static String GROUP_ID1 = "GROUP_ID1";
    public static String GROUP_ID2 = "GROUP_ID2";
    public static String COURSE_ID1 = "COURSE_ID1";
    public static String COURSE_ID2 = "COURSE_ID2";
    public static String ORGANIZATION_ID = "ORGANIZATION_ID";
    public static String LO_TAG = "lo";
    public static String SKILL_OBJECTIVE_TAG = "skillobjective";
    public static String SCO_TAG = "sco";
    public static String RECORD_TAG = "RECORD";
    public static String LESSON_TAG = "lesson";
    public static String ID_TAG = "id";
    public static String ORDER_TAG = "order";
    public static String LO_REF_TAG = "lo_ref";
    public static String NAME_TAG = "name";
    public static String ROLE_TAG = "role";
    public static String HIERARCHY_QUERY = "HIERARCHY_QUERY";
    public static String ASSIGNED_COURSES = "ASSIGNED_COURSES";
    public static String IS_VALID = "IS_VALID";
    public static long SIMULATOR_WAIT = 180;

    /**
     * Mastery column names
     */
    public interface Mastery {
        public static String VALIDATION_FIELDS = "VALIDATION_FIELDS";
        public static String SUBJECT_ID = "SUBJECT_ID";
        public static String SUBJECT = "SUBJECT";
        public static String STUDENT_COUNT = "STUDENT_COUNT";
        public static String GROUP_COUNT = "GROUP_COUNT";
        public static String ASSIGNMENT_COUNT = "ASSIGNMENT_COUNT";
        public static String EXP_VALIDATION_DATA = "EXP_VALIDATION_DATA";
    }

}