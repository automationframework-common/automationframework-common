package com.savvas.sm.utils.sme187.teacher.api.mastery;

public interface MasterySummaryConstant {

    String MASTERY_SUMMARY_ENDPOINT = "/lms/web/api/v1/mastery/summary";

}