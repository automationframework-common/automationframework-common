package com.savvas.sm.utils.sql.helper;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.SqlConstants;
import com.savvas.sm.utils.SqlConstants.StudentProgress;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentUsage;

/*
 * @author: manikanda.nagendran
 */

public class SqlHelperUsage {

    /*
     * To share the current week usage data with previous weeks
     */
    public static void shareUsageData( String orgName ) {

        String query = "select maod_date_fixup(?);select msh_date_fixup(?);select raod_date_fixup(?);select rsh_date_fixup(?);";

        String[] querySplit = query.split( ";" );
        Object[] params = { orgName };
        try {
            for ( int i = 0; i < querySplit.length; i++ ) {
                SQLUtil.executeFunction( querySplit[i], params );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        Log.message( "Usage Data shared with previous weeks successfully" );
    }

    /*
     * To get the Progress Details of the student from DB
     */
    public HashMap<String, String> getProgressDetails( String assignmentID, String studentID, String subject ) {
        String getData;
        if ( subject.equals( Constants.MATH ) ) {
            getData = SqlConstants.StudentProgress.MATH_PROGRESS_QUERY;
        } else {
            getData = StudentProgress.READING_PROGRESS_QUERY;
        }

        String query = String.format( getData, new SqlHelperCourses().getAssignmentUserId( studentID, assignmentID ) );
        List<Object[]> listItems = null;

        listItems = SQLUtil.executeQuery( query );
        HashMap<String, String> arrMap = null;
        if ( listItems != null && listItems.size() > 0 ) {
            arrMap = new HashMap<String, String>();
            arrMap.put( StudentProgress.CURRENT_LEVEL, listItems.get( 0 )[0].toString() );
            arrMap.put( StudentProgress.IP_LEVEL, listItems.get( 0 )[1].toString() );
            arrMap.put( StudentProgress.ASSIGNED_LEVEL, listItems.get( 0 )[2].toString() );
            arrMap.put( StudentProgress.IP_COMPLETED_DATE, listItems.get( 0 )[3].toString() );
        }
        return arrMap;
    }

    /**
     * To get the student usage Details
     * 
     * @param assignmentIds
     * @param studentIds
     * @return
     */
    public Map<String, Map<String, String>> getStudentUsage( List<String> assignmentIds, List<String> studentIds ) {

        String query = "SELECT (SELECT SUM(EXTRACT (EPOCH FROM (session_complete_time - session_start_time))/60)::bigint AS readSessionMinutes  FROM read_session_history  WHERE assignment_user_id IN (SELECT assignment_user_id FROM Assignment_user WHERE assignment_id IN (assignmentIds) AND person_id IN (studentIds)  AND isdeleted = 0) AND session_complete_time BETWEEN 'fromDate' AND 'toDate') AS readmins,(SELECT SUM(EXTRACT (EPOCH FROM (session_complete_time - session_start_time))/60)::bigint AS mathSessionMinutes FROM math_session_history WHERE assignment_user_id IN (SELECT assignment_user_id FROM Assignment_user WHERE assignment_id IN (assignmentIds) AND person_id IN (studentIds) AND isdeleted = 0) AND session_complete_time BETWEEN 'fromDate' AND 'toDate') AS mathmins";

        if ( assignmentIds.isEmpty() ) {
            query = query.replace( "assignment_id IN (assignmentIds) AND", "" );
        } else {
            query = query.replace( "assignmentIds", assignmentIds.toString().substring( 1, assignmentIds.toString().length() - 1 ) );
        }

        query = query.replace( "studentIds", "'" + studentIds.toString().substring( 1, studentIds.toString().length() - 1 ).replace( ", ", "', '" ) + "'" );

        Map<String, Map<String, String>> usageDetails = new HashMap<>();
        Map<String, String> individualField = new HashMap<>();
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern( "YYYY-MM-dd" );
        ZonedDateTime weekStartDate = ZonedDateTime.now( ZoneId.of( "America/Phoenix" ) );

        if ( weekStartDate.getDayOfWeek().toString().equals( "SUNDAY" ) ) {
            weekStartDate = weekStartDate.minusDays( 1 );
        }

        while ( !weekStartDate.getDayOfWeek().toString().equals( "MONDAY" ) ) {
            weekStartDate = weekStartDate.minusDays( 1 );
        }

        String querywithdate = "";
        querywithdate = query.replace( "toDate", ZonedDateTime.now( ZoneId.of( "America/Phoenix" ) ).plusDays( 1 ).format( dateFormat ) );
        querywithdate = querywithdate.replace( "fromDate", weekStartDate.format( dateFormat ) );

        int iter = 0;
        while ( iter < 8 ) {

            List<Object[]> listItems = SQLUtil.executeQuery( querywithdate );
            Map<String, String> arrMap = new HashMap<>();
            if ( listItems != null && listItems.size() > 0 ) {

                if ( Objects.nonNull( listItems.get( 0 )[1] ) ) {
                    arrMap.put( StudentUsage.MATH_MINS, listItems.get( 0 )[1].toString() );
                } else {
                    arrMap.put( StudentUsage.MATH_MINS, "0" );
                }

                if ( Objects.nonNull( listItems.get( 0 )[0] ) ) {
                    arrMap.put( StudentUsage.READING_MINS, listItems.get( 0 )[0].toString() );
                } else {
                    arrMap.put( StudentUsage.READING_MINS, "0" );
                }
            }
            if ( iter == 0 ) {
                individualField.put( StudentUsage.THIS_WEEK_MINS, String.valueOf( Integer.parseInt( arrMap.get( StudentUsage.MATH_MINS ) ) + Integer.parseInt( arrMap.get( StudentUsage.READING_MINS ) ) ) );
            }
            if ( iter == 1 ) {
                individualField.put( StudentUsage.LAST_WEEK_MINS, String.valueOf( Integer.parseInt( arrMap.get( StudentUsage.MATH_MINS ) ) + Integer.parseInt( arrMap.get( StudentUsage.READING_MINS ) ) ) );
            }
            usageDetails.put( weekStartDate.format( dateFormat ), arrMap );
            querywithdate = query.replace( "toDate", weekStartDate.format( dateFormat ) );
            weekStartDate = weekStartDate.minusDays( 7 );
            querywithdate = querywithdate.replace( "fromDate", weekStartDate.format( dateFormat ) );
            iter++;
        }

        query = query.replace( "AND session_complete_time BETWEEN 'fromDate' AND 'toDate'", "" );
        List<Object[]> listItems = SQLUtil.executeQuery( query );
        Map<String, String> arrMap = new HashMap<String, String>();
        if ( listItems != null && listItems.size() > 0 ) {

            if ( Objects.nonNull( listItems.get( 0 )[1] ) ) {
                arrMap.put( StudentUsage.MATH_MINS, listItems.get( 0 )[1].toString() );
            } else {
                arrMap.put( StudentUsage.MATH_MINS, "0" );
            }

            if ( Objects.nonNull( listItems.get( 0 )[0] ) ) {
                arrMap.put( StudentUsage.READING_MINS, listItems.get( 0 )[0].toString() );
            } else {
                arrMap.put( StudentUsage.READING_MINS, "0" );
            }
        }
        individualField.put( StudentUsage.TOTAL_MINTUES, String.valueOf( Integer.parseInt( arrMap.get( StudentUsage.MATH_MINS ) ) + Integer.parseInt( arrMap.get( StudentUsage.READING_MINS ) ) ) );
        usageDetails.put( "individualFields", individualField );
        return usageDetails;
    }

    /**
     * To get the session this week from DB
     * 
     * @param assignmentUserId
     * @param isMath
     * @return
     */
    public static Map<String, Object> getSessionThisWeekUsageForStudent( String assignmentUserId, boolean isMath ) {
        Map<String, Object> parentMap = new HashMap<String, Object>();
        Map<String, Map<String, String>> sessionThisWeek = new HashMap<>();
        String sessionThisWeekQuery = null;
        String usageQuery = null;
        if ( isMath ) {
            sessionThisWeekQuery = "SELECT FLOOR(EXTRACT(EPOCH FROM(msh.session_complete_time))) AS session_complete_time, msh.session_attempts, msh.session_correct, false as fluency FROM school.math_session_history AS msh WHERE msh.assignment_user_id = "
                    + assignmentUserId;
            usageQuery = "SELECT CAST( SUM( EXTRACT( EPOCH FROM(msh.session_complete_time - msh.session_start_time) ) ) AS FLOAT ) AS usage FROM school.math_session_history AS msh WHERE msh.assignment_user_id = " + assignmentUserId;
        } else {
            sessionThisWeekQuery = "SELECT FLOOR(EXTRACT(EPOCH FROM(rsh.session_complete_time))) AS session_complete_time, rsh.session_attempts, rsh.session_correct, rsh.fluency FROM school.read_session_history AS rsh WHERE rsh.assignment_user_id ="
                    + assignmentUserId;
            usageQuery = "SELECT CAST( SUM( EXTRACT( EPOCH FROM(rsh.session_complete_time - rsh.session_start_time) ) ) AS FLOAT ) AS usage FROM school.read_session_history AS rsh WHERE rsh.assignment_user_id = " + assignmentUserId;
        }

        List<Object[]> listItems = SQLUtil.executeQuery( sessionThisWeekQuery );
        if ( Objects.nonNull( listItems ) ) {
            listItems.forEach( listItem -> {
                Map<String, String> session = new HashMap<>();
                session.put( "sessionDate", listItem[0].toString() );
                session.put( "sessionAttempt", listItem[1].toString() );
                session.put( "sessionCorrect", listItem[2].toString() );
                session.put( "fluency", listItem[3].toString() );
                sessionThisWeek.put( listItem[0].toString(), session );
            } );
        }

        parentMap.put( "sessionThisWeek", sessionThisWeek );
        listItems = SQLUtil.executeQuery( usageQuery );
        if ( Objects.nonNull( listItems ) ) {
            parentMap.put( "usage", listItems.get( 0 )[0] );
        }
        return parentMap;
    }

}
