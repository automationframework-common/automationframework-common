package com.savvas.sm.utils.sme187.admin.api.reports.exportcsv;

import java.util.Arrays;
import java.util.List;

public class ExportCsvConstants {

    public static String EXPORT_CSV_ENDPOINT = "/export-csv";
    public static String DEFAULT = "default";
    public static String CUSTOM = "custom";
    public static String FILTER_BY_TEACHER = "filterByTeacher";
    public static String FILTER_BY_GRADE = "filterByGrade";
    public static String FILTER_BY_GROUP = "filterByGroup";
    public static String ADDITIONAL_GROUPING = "additionalGrouping";
    public static List<String> DEMOGRAPHIC_FIELD_VALUES = Arrays.asList( "disabilityStatus", "englishLanguageProficiency", "gender", "migrantStatus", "race", "ethnicity", "socioeconomicStatus", "specialServices" );
    public static String ENGLISH_LANGUGAGE_PROFICIENCY = "englishLanguageProficiency";
    public static String GENDER = "gender";
    public static String MIGRANT_STATUS = "migrantStatus";
    public static String RACE = "race";
    public static String ETHINICITY = "ethnicity";
    public static String SOCIO_ECONOMIC_STATUS = "socioeconomicStatus";
    public static String SPECIAL_SERVICES = "specialServices";

    public static List<String> LSR_EXPORT_CSV_FIELDS = Arrays.asList( "assignmentTitle", "organizationName", "teacherName", "grade", "groupName", "studentName", "studentID", "studentUsername", "currentCourseLevel", "rawPerformance.exercisesCorrect",
            "rawPerformance.exercisesAttempted", "rawPerformance.exercisesPercentCorrect", "usage.helpUsed", "usage.timeSpent", "usage.totalSessions", "usage.sessionDate", "mean.currentCourseLevel", "mean.exercisesCorrect", "mean.exercisesAttempted",
            "mean.exercisesPercentCorrect", "mean.helpUsed", "mean.timeSpent", "mean.totalSessions", "standardDeviation.currentCourseLevel", "standardDeviation.exercisesCorrect", "standardDeviation.exercisesAttempted",
            "standardDeviation.exercisesPercentCorrect", "standardDeviation.helpUsed", "standardDeviation.timeSpent", "standardDeviation.totalSessions", "exercisesCorrectedAttempted.instructionalCorrect",
            "exercisesCorrectedAttempted.instructionalAttempted", "exercisesCorrectedAttempted.independentPracticeCorrect", "exercisesCorrectedAttempted.independentPracticeAttempted", "exercisesCorrectedAttempted.remediationCorrect",
            "exercisesCorrectedAttempted.remediationAttempted", "mean.instructionalCorrect", "mean.instructionalAttempted", "mean.independentPracticeCorrect", "mean.independentPracticeAttempted", "mean.remediationCorrect", "mean.remediationAttempted",
            "standardDeviation.instructionalCorrect", "standardDeviation.instructionalAttempted", "standardDeviation.independentPracticeCorrect", "standardDeviation.independentPracticeAttempted", "standardDeviation.remediationCorrect",
            "standardDeviation.remediationAttempted" );

    public static List<String> LSR_MATH_EXPORT_CSV_FIELDS = Arrays.asList( "assignmentTitle", "organizationName", "teacherName", "grade", "groupName", "studentName", "studentID", "studentUsername", "currentCourseLevel", "exercisesCorrect",
            "exercisesAttempted", "exercisesPercentCorrect", "helpUsed", "timeSpent", "totalSessions", "sessionDate", "meanCurrentCourseLevel", "meanExercisesCorrect", "meanExercisesAttempted", "meanExercisesPercentCorrect", "meanHelpUsed",
            "meanTimeSpent", "meanTotalSessions", "stdCurrentCourseLevel", "stdExercisesCorrect", "stdExercisesAttempted", "stdExercisesPercentCorrect", "stdHelpUsed", "stdTimeSpent", "stdTotalSessions" );

    public static List<String> LSR_READING_CSV_FIELDS = Arrays.asList( "assignmentTitle", "organizationName", "teacherName", "grade", "groupName", "studentName", "studentID", "studentUsername", "currentCourseLevel", "exercisesCorrect",
            "exercisesAttempted", "exercisesPercentCorrect", "helpUsed", "timeSpent", "totalSessions", "sessionDate", "meanCurrentCourseLevel", "meanExercisesCorrect", "meanExercisesAttempted", "meanExercisesPercentCorrect", "meanHelpUsed",
            "meanTimeSpent", "meanTotalSessions", "stdCurrentCourseLevel", "stdExercisesCorrect", "stdExercisesAttempted", "stdExercisesPercentCorrect", "stdHelpUsed", "stdTimeSpent", "stdTotalSessions", "instructionalCorrect", "instructionalAttempted",
            "independentPracticeCorrect", "independentPracticeAttempted", "remediationCorrect", "remediationAttempted", "meanInstructionalCorrect", "meanInstructionalAttempted", "meanIndependentPracticeCorrect", "meanIndependentPracticeAttempted",
            "meanRemediationCorrect", "meanRemediationAttempted", "stdInstructionalCorrect", "stdInstructionalAttempted", "stdIndependentPracticeCorrect", "stdIndependentPracticeAttempted", "stdRemediationCorrect", "stdRemediationAttempted" );

    public static List<String> LSR_DEFAULT_MATH_HEADERS = Arrays.asList( "Assignment", "School", "Teacher", "Grade", "Group", "Student", "Student ID", "Student Username", "Current Course Level", "Exercises Correct", "Exercises Attempted",
            "Exercises Percent Correct", "Help Used", "Time Spent", "Total Sessions", "Session Date", "Current Course Level (Mean)", "Exercises Correct (Mean)", "Exercises Attempted (Mean)", "Exercises Percent Correct (Mean)", "Help Used (Mean)",
            "Time Spent (Mean)", "Total Sessions (Mean)", "Current Course Level (SD)", "Exercises Correct (SD)", "Exercises Attempted (SD)", "Exercises Percent Correct (SD)", "Help Used (SD)", "Time Spent (SD)", "Total Sessions (SD)" );

    public static List<String> LSR_DEFAULT_READING_HEADERS = Arrays.asList( "Assignment", "School", "Teacher", "Grade", "Group", "Student", "Student ID", "Student Username", "Current Course Level", "Exercises Correct", "Exercises Attempted",
            "Exercises Percent Correct", "Help Used", "Time Spent", "Total Sessions", "Session Date", "Current Course Level (Mean)", "Exercises Correct (Mean)", "Exercises Attempted (Mean)", "Exercises Percent Correct (Mean)", "Help Used (Mean)",
            "Time Spent (Mean)", "Total Sessions (Mean)", "Current Course Level (SD)", "Exercises Correct (SD)", "Exercises Attempted (SD)", "Exercises Percent Correct (SD)", "Help Used (SD)", "Time Spent (SD)", "Total Sessions (SD)",
            "Instructional - Exercises Correct", "Instructional - Exercises Attempted", "Independent Practice - Exercises Correct", "Independent Practice - Exercises Attempted", "Remediation - Exercises Correct", "Remediation - Exercises Attempted",
            "Instructional - Exercises Correct (Mean)", "Instructional - Exercises Attempted (Mean)", "Independent Practice - Exercises Correct (Mean)", "Independent Practice - Exercises Attempted (Mean)", "Remediation - Exercises Correct (Mean)",
            "Remediation - Exercises Attempted (Mean)", "Instructional - Exercises Correct (SD)", "Instructional - Exercises Attempted (SD)", "Independent Practice - Exercises Correct (SD)", "Independent Practice - Exercises Attempted (SD)",
            "Remediation - Exercises Correct (SD)", "Remediation - Exercises Attempted (SD)" );

    public interface SPRExportCSVConstants {
        List<String> DEFAULT_MATH_SELECTED_FILTERS = Arrays.asList( "reportRun", "studentId", "studentUsername", "courses.name", "courses.school", "courses.teacher", "courses.grade", "courses.group", "courses.IPMCorrect", "courses.IPMAttempted",
                "courses.IPMPercent", "courses.IPTimeSpent", "courses.IPPlaced", "courses.assignedCourseLevel", "courses.currentCourseLevel", "courses.ipLevel", "courses.gain", "courses.exerCorrect", "courses.exerAttempted", "courses.exerCorrectPercent",
                "courses.cri", "courses.skillsMastered", "courses.skillsAssessed", "courses.skillsMasteredPercent", "courses.helpUsed", "courses.audioRepeatsUsed", "courses.reportCardViews", "courses.glossaryUsed", "courses.timeSpent",
                "courses.totalSessions", "courses.averageSessionTime" );
        List<String> DEFAULT_READING_SELECTED_FILTERS = Arrays.asList( "reportRun", "studentId", "studentUsername", "courses.name", "courses.school", "courses.teacher", "courses.grade", "courses.group", "courses.IPMCorrect", "courses.IPMAttempted",
                "courses.IPMPercent", "courses.IPTimeSpent", "courses.IPPlaced", "courses.assignedCourseLevel", "courses.currentCourseLevel", "courses.ipLevel", "courses.ipLevelSummary", "courses.gain", "courses.exerCorrect", "courses.exerAttempted",
                "courses.exerCorrectPercent", "courses.cri", "courses.skillsMastered", "courses.skillsAssessed", "courses.skillsMasteredPercent", "courses.helpUsed", "courses.audioRepeatsUsed", "courses.reportCardViews", "courses.glossaryUsed",
                "courses.timeSpent", "courses.totalSessions", "courses.averageSessionTime", "courses.otherPerformance.IndependentPractice.exerCorrect", "courses.otherPerformance.IndependentPractice.exerAttempted",
                "courses.otherPerformance.IndependentPractice.exerCorrectPercent", "courses.otherPerformance.Remediation.exerCorrect", "courses.otherPerformance.Remediation.exerAttempted", "courses.otherPerformance.Remediation.exerCorrectPercent" );
        List<String> DEFAULT_MATH_HEADERS = Arrays.asList( "\"Report Run\"", "\"Student Id\"", "\"Student Name\"", "\"Student Username\"", "\"Assignment Name\"", "\"School Name\"", "\"Teacher Name\"", "\"Grade Level\"", "\"Group\"", "\"IP Correct\"",
                "\"IP Attempted\"", "\"IP Percent Correct\"", "\"IP Time Spent\"", "\"Placed\"", "\"Assigned Course Level\"", "\"Current Course Level\"", "\"IP Level\"", "\"Gain\"", "\"Exercises Correct\"", "\"Exercises Attempted\"",
                "\"Exercises Percent Correct\"", "\"Computation Retention Index (CRI)\"", "\"Skills Mastered\"", "\"Skills Assessed\"", "\"Skills Percent Mastered\"", "\"Help Used\"", "\"Audio Repeats Used\"", "\"Report Card Views\"", "\"Glossary Used\"",
                "\"Time Spent\"", "\"Total Sessions - minimum of 1 assignment\"", "\"Average Session Time\"" );
        List<String> DEFAULT_READING_HEADERS = Arrays.asList( "\"Report Run\"", "\"Student Id\"", "\"Student Name\"", "\"Student Username\"", "\"Assignment Name\"", "\"School Name\"", "\"Teacher Name\"", "\"Grade Level\"", "\"Group\"", "\"IP Correct\"",
                "\"IP Attempted\"", "\"IP Percent Correct\"", "\"IP Time Spent\"", "\"Placed\"", "\"Assigned Course Level\"", "\"Current Course Level\"", "\"IP Level\"", "\"IP Level Summary\"", "\"Gain\"", "\"Exercises Correct\"",
                "\"Exercises Attempted\"", "\"Exercises Percent Correct\"", "\"Retention Index (RI)\"", "\"Skills Mastered\"", "\"Skills Assessed\"", "\"Skills Percent Mastered\"", "\"Help Used\"", "\"Audio Repeats Used\"", "\"Report Card Views\"",
                "\"Glossary Used\"", "\"Time Spent\"", "\"Total Sessions - minimum of 1 assignment\"", "\"Average Session Time\"", "\"Independent Practice Exercises Correct\"", "\"Independent Practice Exercises Attempted\"",
                "\"Independent Practice Exercises Percent Correct\"", "\"Remediation Exercises Correct\"", "\"Remediation Exercises Attempted\"", "\"Remediation Exercises Percent Correct\"" );

        List<String> CUSTOM_MATH_SELECTED_FILTERS = Arrays.asList( "reportRun", "studentId", "studentName", "studentUsername", "courses.name", "courses.school", "courses.teacher", "courses.grade", "courses.group", "courses.IPMCorrect",
                "courses.IPMAttempted", "courses.IPMPercent", "courses.IPTimeSpent", "courses.IPPlaced", "courses.assignedCourseLevel", "courses.currentCourseLevel", "courses.ipLevel", "courses.gain", "courses.exerCorrect", "courses.exerAttempted",
                "courses.exerCorrectPercent", "courses.cri", "courses.skillsMastered", "courses.skillsAssessed", "courses.skillsMasteredPercent", "courses.helpUsed", "courses.audioRepeatsUsed", "courses.reportCardViews", "courses.glossaryUsed",
                "courses.timeSpent", "courses.totalSessions", "courses.averageSessionTime", "courses.ipmStatusID" );
        List<String> CUSTOM_MATH_HEADERS = Arrays.asList( "\"reportRun\"", "\"studentId\"", "\"studentName\"", "\"studentUsername\"", "\"courseName\"", "\"school\"", "\"teacher\"", "\"grade\"", "\"group\"", "\"ipmCorrect\"", "\"ipmAttempted\"",
                "\"ipPercent\"", "\"ipTimeSpent\"", "\"ipPlaced\"", "\"assignedCourseLevel\"", "\"currentCourseLevel\"", "\"ipLevel\"", "\"gain\"", "\"exerCorrect\"", "\"exerAttempted\"", "\"exerCorrectPercent\"", "\"cri\"", "\"skillsMastered\"",
                "\"skillsAssessed\"", "\"skillsMasteredPercent\"", "\"helpUsed\"", "\"audioRepeatsUsed\"", "\"reportCardViews\"", "\"glossaryUsed\"", "\"timeSpent\"", "\"totalSessions\"", "\"averageSessionTime\"", "\"ipmStatusID\"" );

        List<String> CUSTOM_READING_SELECTED_FILTERS = Arrays.asList( "reportRun", "studentId", "studentName", "studentUsername", "courses.name", "courses.school", "courses.teacher", "courses.grade", "courses.group", "courses.IPMCorrect",
                "courses.IPMAttempted", "courses.IPMPercent", "courses.IPTimeSpent", "courses.IPPlaced", "courses.assignedCourseLevel", "courses.currentCourseLevel", "courses.ipLevel", "courses.gain", "courses.exerCorrect", "courses.exerAttempted",
                "courses.exerCorrectPercent", "courses.cri", "courses.skillsMastered", "courses.skillsAssessed", "courses.skillsMasteredPercent", "courses.helpUsed", "courses.audioRepeatsUsed", "courses.reportCardViews", "courses.glossaryUsed",
                "courses.timeSpent", "courses.totalSessions", "courses.averageSessionTime", "courses.ipmStatusID", "courses.k2IpmTotalCorrect", "courses.k2IpmTotalAttempts", "courses.fluencyStatus", "courses.grammarStatus", "courses.proficiencyStatus",
                "courses.otherPerformance.IndependentPractice.exerCorrect", "courses.otherPerformance.IndependentPractice.exerAttempted", "courses.otherPerformance.IndependentPractice.exerCorrectPercent", "courses.otherPerformance.Remediation.exerCorrect",
                "courses.otherPerformance.Remediation.exerAttempted", "courses.otherPerformance.Remediation.exerCorrectPercent" );
        List<String> CUSTOM_READING_HEADERS = Arrays.asList( "\"reportRun\"", "\"studentId\"", "\"studentName\"", "\"studentUsername\"", "\"courseName\"", "\"school\"", "\"teacher\"", "\"grade\"", "\"group\"", "\"ipmCorrect\"", "\"ipmAttempted\"",
                "\"ipPercent\"", "\"ipTimeSpent\"", "\"ipPlaced\"", "\"assignedCourseLevel\"", "\"currentCourseLevel\"", "\"ipLevel\"", "\"gain\"", "\"exerCorrect\"", "\"exerAttempted\"", "\"exerCorrectPercent\"", "\"cri\"", "\"skillsMastered\"",
                "\"skillsAssessed\"", "\"skillsMasteredPercent\"", "\"helpUsed\"", "\"audioRepeatsUsed\"", "\"reportCardViews\"", "\"glossaryUsed\"", "\"timeSpent\"", "\"totalSessions\"", "\"averageSessionTime\"", "\"ipmStatusID\"",
                "\"k2IpmTotalCorrect\"", "\"k2IpmTotalAttempts\"", "\"fluencyStatus\"", "\"grammarStatus\"", "\"proficiencyStatus\"", "\"otherPerformanceIndependentPracticeExerCorrect\"", "\"otherPerformanceIndependentPracticeExerAttempted\"",
                "\"otherPerformanceIndependentPracticeExerCorrectPercent\"", "\"otherPerformanceRemediationExerCorrect\"", "\"otherPerformanceRemediationExerAttempted\"", "\"otherPerformanceRemediationExerCorrectPercent\"" );

    }

    public interface AFGExportCSVConstants {
        List<String> DEFAULT_MATH_SELECTED_FILTERS = Arrays.asList( "data.getAFGOrgAdminReportData.orgRows.assignmentTitle", "data.getAFGOrgAdminReportData.reportRun", "data.getAFGOrgAdminReportData.orgRows.organizationName",
                "data.getAFGOrgAdminReportData.orgRows.teacherName", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.grade", "data.getAFGOrgAdminReportData.orgRows.groupName", "data.getAFGOrgAdminReportData.orgRows.totalSkills",
                "data.getAFGOrgAdminReportData.orgRows.totalStudents", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.strandName", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.strandLevel",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.skillDescription", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.studentName", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.failedDate",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.targetedLessonLinkName", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.targetedLessonLinkValue" );

        List<String> DEFAULT_READING_SELECTED_FILTERS = Arrays.asList( "data.getAFGOrgAdminReportData.orgRows.assignmentTitle", "data.getAFGOrgAdminReportData.reportRun", "data.getAFGOrgAdminReportData.orgRows.organizationName",
                "data.getAFGOrgAdminReportData.orgRows.teacherName", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.grade", "data.getAFGOrgAdminReportData.orgRows.groupName", "data.getAFGOrgAdminReportData.orgRows.totalSkills",
                "data.getAFGOrgAdminReportData.orgRows.totalStudents", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.strandName", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.strandLevel",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.skillDescription", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.studentName", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.failedDate",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.targetedLessonLinkName", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.targetedLessonLinkValue" );

        List<String> CUSTOM_MATH_SELECTED_FILTERS = Arrays.asList( "data.getAFGOrgAdminReportData.orgRows.organizationName", "data.getAFGOrgAdminReportData.orgRows.assignmentID", "data.getAFGOrgAdminReportData.orgRows.assignmentTitle",
                "data.getAFGOrgAdminReportData.orgRows.groupName", "data.getAFGOrgAdminReportData.orgRows.teacherFirstName", "data.getAFGOrgAdminReportData.orgRows.teacherLastName", "data.getAFGOrgAdminReportData.orgRows.teacherTitle",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.studentFirstName", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.studentLastName", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.strandName",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.strandLevel", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.catalogNum", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.loDescription",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.masteryStatus", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.username", "data.getAFGOrgAdminReportData.orgRows.teacherID",
                "data.getAFGOrgAdminReportData.orgRows.groupID", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.studentId", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.studentName",
                "data.getAFGOrgAdminReportData.orgRows.totalStudents", "data.getAFGOrgAdminReportData.orgRows.totalSkills", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.grade",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.gradeDisplayOrder", "data.getAFGOrgAdminReportData.orgRows.teacherName", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.failedDate",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.studentSortName", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.loDescription", "data.getAFGOrgAdminReportData.orgRows.teacherUsername",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.objectiveID", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.levelDescriptionPair", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.targetedLessonLinkName",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.targetedLessonLinkValue", "data.getAFGOrgAdminReportData.reportRun" );

        List<String> CUSTOM_READING_SELECTED_FILTERS = Arrays.asList( "data.getAFGOrgAdminReportData.orgRows.organizationName", "data.getAFGOrgAdminReportData.orgRows.assignmentID", "data.getAFGOrgAdminReportData.orgRows.assignmentTitle",
                "data.getAFGOrgAdminReportData.orgRows.groupName", "data.getAFGOrgAdminReportData.orgRows.teacherFirstName", "data.getAFGOrgAdminReportData.orgRows.teacherLastName", "data.getAFGOrgAdminReportData.orgRows.teacherTitle",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.studentFirstName", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.studentLastName", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.strandName",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.strandLevel", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.catalogNum", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.loDescription",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.masteryStatus", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.username", "data.getAFGOrgAdminReportData.orgRows.teacherID",
                "data.getAFGOrgAdminReportData.orgRows.groupID", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.studentId", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.studentName",
                "data.getAFGOrgAdminReportData.orgRows.totalStudents", "data.getAFGOrgAdminReportData.orgRows.totalSkills", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.grade",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.gradeDisplayOrder", "data.getAFGOrgAdminReportData.orgRows.teacherName", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.failedDate",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.studentRows.studentSortName", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.loDescription", "data.getAFGOrgAdminReportData.orgRows.teacherUsername",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.objectiveID", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.levelDescriptionPair", "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.targetedLessonLinkName",
                "data.getAFGOrgAdminReportData.orgRows.strandSkillRows.targetedLessonLinkValue", "data.getAFGOrgAdminReportData.reportRun" );

    }

    public interface CPRExportCSVConstants {
        List<String> DEFAULT_MATH_SELECTED_FILTERS = Arrays.asList( "data.getAdminCPOrgReportData.pageData.courseName", "data.getAdminCPOrgReportData.reportRun", "data.getAdminCPOrgReportData.pageData.organizationName",
                "data.getAdminCPOrgReportData.pageData.teacherName", "data.getAdminCPOrgReportData.pageData.grade", "data.getAdminCPOrgReportData.pageData.groupName", "data.getAdminCPOrgReportData.dateRange",
                "data.getAdminCPOrgReportData.pageData.studentRows.studentName", "data.getAdminCPOrgReportData.pageData.studentRows.levelData.assignedCourseLevel", "data.getAdminCPOrgReportData.pageData.studentRows.levelData.currentCourseLevel",
                "data.getAdminCPOrgReportData.pageData.studentRows.levelData.ipLevel", "data.getAdminCPOrgReportData.pageData.studentRows.levelData.gain", "data.getAdminCPOrgReportData.pageData.studentRows.usage.timeSpent",
                "data.getAdminCPOrgReportData.pageData.studentRows.usage.totalSessions", "data.getAdminCPOrgReportData.pageData.studentRows.instructionalPerformance.exercisesCorrect",
                "data.getAdminCPOrgReportData.pageData.studentRows.instructionalPerformance.exercisesAttempted", "data.getAdminCPOrgReportData.pageData.studentRows.instructionalPerformance.exercisesPercentCorrect",
                "data.getAdminCPOrgReportData.pageData.studentRows.mastery.skillsAssessed", "data.getAdminCPOrgReportData.pageData.studentRows.mastery.skillsMastered", "data.getAdminCPOrgReportData.pageData.studentRows.mastery.skillsPercentMastered",
                "data.getAdminCPOrgReportData.pageData.studentRows.mastery.isAcceptablePerformance", "data.getAdminCPOrgReportData.pageData.studentMean.levelData.assignedCourseLevel",
                "data.getAdminCPOrgReportData.pageData.studentMean.levelData.currentCourseLevel", "data.getAdminCPOrgReportData.pageData.studentMean.levelData.ipLevel", "data.getAdminCPOrgReportData.pageData.studentMean.levelData.gain",
                "data.getAdminCPOrgReportData.pageData.studentMean.usage.timeSpent", "data.getAdminCPOrgReportData.pageData.studentMean.usage.totalSessions", "data.getAdminCPOrgReportData.pageData.studentMean.instructionalPerformance.exercisesCorrect",
                "data.getAdminCPOrgReportData.pageData.studentMean.instructionalPerformance.exercisesAttempted", "data.getAdminCPOrgReportData.pageData.studentMean.instructionalPerformance.exercisesPercentCorrect",
                "data.getAdminCPOrgReportData.pageData.studentMean.mastery.skillsAssessed", "data.getAdminCPOrgReportData.pageData.studentMean.mastery.skillsMastered", "data.getAdminCPOrgReportData.pageData.studentMean.mastery.skillsPercentMastered",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.levelData.assignedCourseLevel", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.levelData.currentCourseLevel",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.levelData.ipLevel", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.levelData.gain",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.usage.timeSpent", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.usage.totalSessions",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.instructionalPerformance.exercisesCorrect", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.instructionalPerformance.exercisesAttempted",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.instructionalPerformance.exercisesPercentCorrect", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.mastery.skillsAssessed",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.mastery.skillsMastered", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.mastery.skillsPercentMastered" );
        List<String> CUSTOM_MATH_SELECTED_FILTERS = Arrays.asList( "data.getAdminCPOrgReportData.pageData.studentRows.levelData.ipmStatusID", "data.getAdminCPOrgReportData.pageData.studentRows.levelData.gain",
                "data.getAdminCPOrgReportData.pageData.studentRows.levelData.assignedCourseLevel", "data.getAdminCPOrgReportData.pageData.studentRows.levelData.currentCourseLevel", "data.getAdminCPOrgReportData.pageData.orgId",
                "data.getAdminCPOrgReportData.pageData.organizationName", "data.getAdminCPOrgReportData.pageData.courseName", "data.getAdminCPOrgReportData.pageData.groupName", "data.getAdminCPOrgReportData.pageData.studentRows.studentID",
                "data.getAdminCPOrgReportData.pageData.studentRows.studentUsername", "data.getAdminCPOrgReportData.pageData.studentRows.studentFirstName", "data.getAdminCPOrgReportData.pageData.studentRows.studentLastName",
                "data.getAdminCPOrgReportData.pageData.studentRows.levelData.contentTypeBaseID", "data.getAdminCPOrgReportData.pageData.studentRows.levelData.ipmEndLevel", "data.getAdminCPOrgReportData.pageData.studentRows.usage.timeSpent",
                "data.getAdminCPOrgReportData.pageData.studentRows.usage.totalSessions", "data.getAdminCPOrgReportData.pageData.studentRows.instructionalPerformance.exercisesCorrect",
                "data.getAdminCPOrgReportData.pageData.studentRows.instructionalPerformance.exercisesAttempted", "data.getAdminCPOrgReportData.pageData.studentRows.mastery.skillsAssessed",
                "data.getAdminCPOrgReportData.pageData.studentRows.mastery.skillsMastered", "data.getAdminCPOrgReportData.pageData.studentRows.studentName", "data.getAdminCPOrgReportData.pageData.teacherName", "data.getAdminCPOrgReportData.pageData.grade",
                "data.getAdminCPOrgReportData.pageData.gradeDisplayOrder", "data.getAdminCPOrgReportData.pageData.studentRows.instructionalPerformance.exercisesPercentCorrect",
                "data.getAdminCPOrgReportData.pageData.studentRows.mastery.skillsPercentMastered", "data.getAdminCPOrgReportData.reportRun", "data.getAdminCPOrgReportData.pageData.apCount", "data.getAdminCPOrgReportData.pageData.totalStudents",
                "data.getAdminCPOrgReportData.pageData.studentMean.levelData.assignedCourseLevel", "data.getAdminCPOrgReportData.pageData.studentMean.levelData.currentCourseLevel", "data.getAdminCPOrgReportData.pageData.studentMean.levelData.ipLevel",
                "data.getAdminCPOrgReportData.pageData.studentMean.levelData.gain", "data.getAdminCPOrgReportData.pageData.studentMean.usage.timeSpent", "data.getAdminCPOrgReportData.pageData.studentMean.usage.totalSessions",
                "data.getAdminCPOrgReportData.pageData.studentMean.instructionalPerformance.exercisesCorrect", "data.getAdminCPOrgReportData.pageData.studentMean.instructionalPerformance.exercisesAttempted",
                "data.getAdminCPOrgReportData.pageData.studentMean.instructionalPerformance.exercisesPercentCorrect", "data.getAdminCPOrgReportData.pageData.studentMean.mastery.skillsAssessed",
                "data.getAdminCPOrgReportData.pageData.studentMean.mastery.skillsMastered", "data.getAdminCPOrgReportData.pageData.studentMean.mastery.skillsPercentMastered",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.levelData.assignedCourseLevel", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.levelData.currentCourseLevel",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.levelData.ipLevel", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.levelData.gain",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.usage.timeSpent", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.usage.totalSessions",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.instructionalPerformance.exercisesCorrect", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.instructionalPerformance.exercisesAttempted",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.instructionalPerformance.exercisesPercentCorrect", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.mastery.skillsAssessed",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.mastery.skillsMastered", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.mastery.skillsPercentMastered",
                "data.getAdminCPOrgReportData.orgData.orgTotalStudents", "data.getAdminCPOrgReportData.orgData.orgMean.levelData.assignedCourseLevel", "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.levelData.assignedCourseLevel",
                "data.getAdminCPOrgReportData.orgData.orgMean.levelData.currentCourseLevel", "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.levelData.currentCourseLevel", "data.getAdminCPOrgReportData.orgData.orgMean.levelData.ipLevel",
                "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.levelData.ipLevel", "data.getAdminCPOrgReportData.orgData.orgMean.levelData.gain", "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.levelData.gain",
                "data.getAdminCPOrgReportData.orgData.orgMean.usage.timeSpent", "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.usage.timeSpent", "data.getAdminCPOrgReportData.orgData.orgMean.usage.totalSessions",
                "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.usage.totalSessions", "data.getAdminCPOrgReportData.orgData.orgMean.instructionalPerformance.exercisesCorrect",
                "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.instructionalPerformance.exercisesCorrect", "data.getAdminCPOrgReportData.orgData.orgMean.instructionalPerformance.exercisesAttempted",
                "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.instructionalPerformance.exercisesAttempted", "data.getAdminCPOrgReportData.orgData.orgMean.instructionalPerformance.exercisesPercentCorrect",
                "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.instructionalPerformance.exercisesPercentCorrect", "data.getAdminCPOrgReportData.orgData.orgMean.mastery.skillsAssessed",
                "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.mastery.skillsAssessed", "data.getAdminCPOrgReportData.orgData.orgMean.mastery.skillsMastered", "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.mastery.skillsMastered",
                "data.getAdminCPOrgReportData.orgData.orgMean.mastery.skillsPercentMastered", "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.mastery.skillsPercentMastered", "data.getAdminCPOrgReportData.orgData.orgAPCount",
                "data.getAdminCPOrgReportData.pageData.studentRows.studentSortName", "data.getAdminCPOrgReportData.pageData.studentRows.studentMiddleName", "data.getAdminCPOrgReportData.pageData.studentRows.levelData.ipmDoneInRange" );

        List<String> DEFAULT_READING_SELECTED_FILTERS = Arrays.asList( "data.getAdminCPOrgReportData.pageData.courseName", "data.getAdminCPOrgReportData.reportRun", "data.getAdminCPOrgReportData.pageData.organizationName",
                "data.getAdminCPOrgReportData.pageData.teacherName", "data.getAdminCPOrgReportData.pageData.grade", "data.getAdminCPOrgReportData.pageData.groupName", "data.getAdminCPOrgReportData.dateRange",
                "data.getAdminCPOrgReportData.pageData.studentRows.studentName", "data.getAdminCPOrgReportData.pageData.studentRows.levelData.assignedCourseLevel", "data.getAdminCPOrgReportData.pageData.studentRows.levelData.currentCourseLevel",
                "data.getAdminCPOrgReportData.pageData.studentRows.levelData.ipLevel", "data.getAdminCPOrgReportData.pageData.studentRows.levelData.gain", "data.getAdminCPOrgReportData.pageData.studentRows.usage.timeSpent",
                "data.getAdminCPOrgReportData.pageData.studentRows.usage.totalSessions", "data.getAdminCPOrgReportData.pageData.studentRows.instructionalPerformance.exercisesCorrect",
                "data.getAdminCPOrgReportData.pageData.studentRows.instructionalPerformance.exercisesAttempted", "data.getAdminCPOrgReportData.pageData.studentRows.instructionalPerformance.exercisesPercentCorrect",
                "data.getAdminCPOrgReportData.pageData.studentRows.mastery.skillsAssessed", "data.getAdminCPOrgReportData.pageData.studentRows.mastery.skillsMastered", "data.getAdminCPOrgReportData.pageData.studentRows.mastery.skillsPercentMastered",
                "data.getAdminCPOrgReportData.pageData.studentRows.mastery.isAcceptablePerformance", "data.getAdminCPOrgReportData.pageData.studentMean.levelData.assignedCourseLevel",
                "data.getAdminCPOrgReportData.pageData.studentMean.levelData.currentCourseLevel", "data.getAdminCPOrgReportData.pageData.studentMean.levelData.ipLevel", "data.getAdminCPOrgReportData.pageData.studentMean.levelData.gain",
                "data.getAdminCPOrgReportData.pageData.studentMean.usage.timeSpent", "data.getAdminCPOrgReportData.pageData.studentMean.usage.totalSessions", "data.getAdminCPOrgReportData.pageData.studentMean.instructionalPerformance.exercisesCorrect",
                "data.getAdminCPOrgReportData.pageData.studentMean.instructionalPerformance.exercisesAttempted", "data.getAdminCPOrgReportData.pageData.studentMean.instructionalPerformance.exercisesPercentCorrect",
                "data.getAdminCPOrgReportData.pageData.studentMean.mastery.skillsAssessed", "data.getAdminCPOrgReportData.pageData.studentMean.mastery.skillsMastered", "data.getAdminCPOrgReportData.pageData.studentMean.mastery.skillsPercentMastered",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.levelData.assignedCourseLevel", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.levelData.currentCourseLevel",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.levelData.ipLevel", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.levelData.gain",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.usage.timeSpent", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.usage.totalSessions",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.instructionalPerformance.exercisesCorrect", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.instructionalPerformance.exercisesAttempted",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.instructionalPerformance.exercisesPercentCorrect", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.mastery.skillsAssessed",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.mastery.skillsMastered", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.mastery.skillsPercentMastered" );

        List<String> CUSTOM_READING_SELECTED_FILTERS = Arrays.asList( "data.getAdminCPOrgReportData.pageData.studentRows.levelData.ipmStatusID", "data.getAdminCPOrgReportData.pageData.studentRows.levelData.gain",
                "data.getAdminCPOrgReportData.pageData.studentRows.levelData.assignedCourseLevel", "data.getAdminCPOrgReportData.pageData.studentRows.levelData.currentCourseLevel", "data.getAdminCPOrgReportData.pageData.orgId",
                "data.getAdminCPOrgReportData.pageData.organizationName", "data.getAdminCPOrgReportData.pageData.courseName", "data.getAdminCPOrgReportData.pageData.groupName", "data.getAdminCPOrgReportData.pageData.studentRows.studentID",
                "data.getAdminCPOrgReportData.pageData.studentRows.studentUsername", "data.getAdminCPOrgReportData.pageData.studentRows.studentFirstName", "data.getAdminCPOrgReportData.pageData.studentRows.studentLastName",
                "data.getAdminCPOrgReportData.pageData.studentRows.levelData.contentTypeBaseID", "data.getAdminCPOrgReportData.pageData.studentRows.levelData.ipmEndLevel", "data.getAdminCPOrgReportData.pageData.studentRows.usage.timeSpent",
                "data.getAdminCPOrgReportData.pageData.studentRows.usage.totalSessions", "data.getAdminCPOrgReportData.pageData.studentRows.instructionalPerformance.exercisesCorrect",
                "data.getAdminCPOrgReportData.pageData.studentRows.instructionalPerformance.exercisesAttempted", "data.getAdminCPOrgReportData.pageData.studentRows.mastery.skillsAssessed",
                "data.getAdminCPOrgReportData.pageData.studentRows.mastery.skillsMastered", "data.getAdminCPOrgReportData.pageData.studentRows.studentName", "data.getAdminCPOrgReportData.pageData.teacherName", "data.getAdminCPOrgReportData.pageData.grade",
                "data.getAdminCPOrgReportData.pageData.gradeDisplayOrder", "data.getAdminCPOrgReportData.pageData.studentRows.instructionalPerformance.exercisesPercentCorrect",
                "data.getAdminCPOrgReportData.pageData.studentRows.mastery.skillsPercentMastered", "data.getAdminCPOrgReportData.reportRun", "data.getAdminCPOrgReportData.pageData.apCount", "data.getAdminCPOrgReportData.pageData.totalStudents",
                "data.getAdminCPOrgReportData.pageData.studentMean.levelData.assignedCourseLevel", "data.getAdminCPOrgReportData.pageData.studentMean.levelData.currentCourseLevel", "data.getAdminCPOrgReportData.pageData.studentMean.levelData.ipLevel",
                "data.getAdminCPOrgReportData.pageData.studentMean.levelData.gain", "data.getAdminCPOrgReportData.pageData.studentMean.usage.timeSpent", "data.getAdminCPOrgReportData.pageData.studentMean.usage.totalSessions",
                "data.getAdminCPOrgReportData.pageData.studentMean.instructionalPerformance.exercisesCorrect", "data.getAdminCPOrgReportData.pageData.studentMean.instructionalPerformance.exercisesAttempted",
                "data.getAdminCPOrgReportData.pageData.studentMean.instructionalPerformance.exercisesPercentCorrect", "data.getAdminCPOrgReportData.pageData.studentMean.mastery.skillsAssessed",
                "data.getAdminCPOrgReportData.pageData.studentMean.mastery.skillsMastered", "data.getAdminCPOrgReportData.pageData.studentMean.mastery.skillsPercentMastered",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.levelData.assignedCourseLevel", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.levelData.currentCourseLevel",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.levelData.ipLevel", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.levelData.gain",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.usage.timeSpent", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.usage.totalSessions",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.instructionalPerformance.exercisesCorrect", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.instructionalPerformance.exercisesAttempted",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.instructionalPerformance.exercisesPercentCorrect", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.mastery.skillsAssessed",
                "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.mastery.skillsMastered", "data.getAdminCPOrgReportData.pageData.studentStandardDeviation.mastery.skillsPercentMastered",
                "data.getAdminCPOrgReportData.orgData.orgTotalStudents", "data.getAdminCPOrgReportData.orgData.orgMean.levelData.assignedCourseLevel", "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.levelData.assignedCourseLevel",
                "data.getAdminCPOrgReportData.orgData.orgMean.levelData.currentCourseLevel", "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.levelData.currentCourseLevel", "data.getAdminCPOrgReportData.orgData.orgMean.levelData.ipLevel",
                "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.levelData.ipLevel", "data.getAdminCPOrgReportData.orgData.orgMean.levelData.gain", "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.levelData.gain",
                "data.getAdminCPOrgReportData.orgData.orgMean.usage.timeSpent", "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.usage.timeSpent", "data.getAdminCPOrgReportData.orgData.orgMean.usage.totalSessions",
                "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.usage.totalSessions", "data.getAdminCPOrgReportData.orgData.orgMean.instructionalPerformance.exercisesCorrect",
                "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.instructionalPerformance.exercisesCorrect", "data.getAdminCPOrgReportData.orgData.orgMean.instructionalPerformance.exercisesAttempted",
                "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.instructionalPerformance.exercisesAttempted", "data.getAdminCPOrgReportData.orgData.orgMean.instructionalPerformance.exercisesPercentCorrect",
                "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.instructionalPerformance.exercisesPercentCorrect", "data.getAdminCPOrgReportData.orgData.orgMean.mastery.skillsAssessed",
                "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.mastery.skillsAssessed", "data.getAdminCPOrgReportData.orgData.orgMean.mastery.skillsMastered", "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.mastery.skillsMastered",
                "data.getAdminCPOrgReportData.orgData.orgMean.mastery.skillsPercentMastered", "data.getAdminCPOrgReportData.orgData.orgStandardDeviation.mastery.skillsPercentMastered", "data.getAdminCPOrgReportData.orgData.orgAPCount",
                "data.getAdminCPOrgReportData.pageData.studentRows.studentSortName", "data.getAdminCPOrgReportData.pageData.studentRows.studentMiddleName", "data.getAdminCPOrgReportData.pageData.studentRows.levelData.ipmDoneInRange" );

    }

    public interface CPARExportCSVConstants {
        List<String> DEFAULT_MATH_SELECTED_FILTERS = Arrays.asList( "data.getCPAOrgAdminReportData.courseName", "data.getCPAOrgAdminReportData.reportRun", "data.getCPAOrgAdminReportData.districtName", "data.getCPAOrgAdminReportData.dataRows.grade",
                "data.getCPAOrgAdminReportData.dataRows.orgData.organizationName", "data.getCPAOrgAdminReportData.dataRows.levelDataMean.currentCourseLevel", "data.getCPAOrgAdminReportData.dataRows.levelDataMean.ipLevel",
                "data.getCPAOrgAdminReportData.dataRows.levelDataMean.gain", "data.getCPAOrgAdminReportData.dataRows.usageMean.timeSpent", "data.getCPAOrgAdminReportData.dataRows.usageMean.totalSessions",
                "data.getCPAOrgAdminReportData.dataRows.instructionalPerformanceMean.exercisesCorrect", "data.getCPAOrgAdminReportData.dataRows.instructionalPerformanceMean.exercisesAttempted",
                "data.getCPAOrgAdminReportData.dataRows.instructionalPerformanceMean.exercisesPercentCorrect", "data.getCPAOrgAdminReportData.dataRows.masteryMean.skillsAssessed", "data.getCPAOrgAdminReportData.dataRows.masteryMean.skillsMastered",
                "data.getCPAOrgAdminReportData.dataRows.masteryMean.skillsPercentMastered", "data.getCPAOrgAdminReportData.dataRows.masteryMean.percentStudentsWithAP", "data.getCPAOrgAdminReportData.mean.levelDataMean.currentCourseLevel",
                "data.getCPAOrgAdminReportData.mean.levelDataMean.ipLevel", "data.getCPAOrgAdminReportData.mean.levelDataMean.gain", "data.getCPAOrgAdminReportData.mean.usageMean.timeSpent", "data.getCPAOrgAdminReportData.mean.usageMean.totalSessions",
                "data.getCPAOrgAdminReportData.mean.instructionalPerformanceMean.exercisesCorrect", "data.getCPAOrgAdminReportData.mean.instructionalPerformanceMean.exercisesAttempted",
                "data.getCPAOrgAdminReportData.mean.instructionalPerformanceMean.exercisesPercentCorrect", "data.getCPAOrgAdminReportData.mean.masteryMean.skillsAssessed", "data.getCPAOrgAdminReportData.mean.masteryMean.skillsMastered",
                "data.getCPAOrgAdminReportData.mean.masteryMean.skillsPercentMastered", "data.getCPAOrgAdminReportData.mean.masteryMean.percentStudentsWithAP", "data.getCPAOrgAdminReportData.standardDeviation.levelDataMean.currentCourseLevel",
                "data.getCPAOrgAdminReportData.standardDeviation.levelDataMean.ipLevel", "data.getCPAOrgAdminReportData.standardDeviation.levelDataMean.gain", "data.getCPAOrgAdminReportData.standardDeviation.usageMean.timeSpent",
                "data.getCPAOrgAdminReportData.standardDeviation.usageMean.totalSessions", "data.getCPAOrgAdminReportData.standardDeviation.instructionalPerformanceMean.exercisesCorrect",
                "data.getCPAOrgAdminReportData.standardDeviation.instructionalPerformanceMean.exercisesAttempted", "data.getCPAOrgAdminReportData.standardDeviation.instructionalPerformanceMean.exercisesPercentCorrect",
                "data.getCPAOrgAdminReportData.standardDeviation.masteryMean.skillsAssessed", "data.getCPAOrgAdminReportData.standardDeviation.masteryMean.skillsMastered", "data.getCPAOrgAdminReportData.standardDeviation.masteryMean.skillsPercentMastered",
                "data.getCPAOrgAdminReportData.standardDeviation.masteryMean.percentStudentsWithAP" );
        List<String> CUSTOM_MATH_SELECTED_FILTERS = Arrays.asList( "data.getCPAOrgAdminReportData.reportRun", "data.getCPAOrgAdminReportData.dataRows.orgData.organizationName", "data.getCPAOrgAdminReportData.dataRows.grade",
                "data.getCPAOrgAdminReportData.dataRows.gradeDisplayOrder", "data.getCPAOrgAdminReportData.dataRows.levelDataMean.currentCourseLevel", "data.getCPAOrgAdminReportData.dataRows.levelDataMean.ipLevel",
                "data.getCPAOrgAdminReportData.dataRows.levelDataMean.gain", "data.getCPAOrgAdminReportData.dataRows.usageMean.timeSpent", "data.getCPAOrgAdminReportData.dataRows.usageMean.totalSessions",
                "data.getCPAOrgAdminReportData.dataRows.instructionalPerformanceMean.exercisesCorrect", "data.getCPAOrgAdminReportData.dataRows.instructionalPerformanceMean.exercisesAttempted",
                "data.getCPAOrgAdminReportData.dataRows.masteryMean.skillsAssessed", "data.getCPAOrgAdminReportData.dataRows.masteryMean.skillsMastered", "data.getCPAOrgAdminReportData.courseName",
                "data.getCPAOrgAdminReportData.dataRows.masteryMean.percentStudentsWithAP", "data.getCPAOrgAdminReportData.dataRows.orgData.numberOfStudents", "data.getCPAOrgAdminReportData.schoolCount",
                "data.getCPAOrgAdminReportData.dataRows.masteryMean.skillsPercentMastered", "data.getCPAOrgAdminReportData.dataRows.instructionalPerformanceMean.exercisesPercentCorrect",
                "data.getCPAOrgAdminReportData.mean.levelDataMean.currentCourseLevel", "data.getCPAOrgAdminReportData.standardDeviation.levelDataMean.currentCourseLevel", "data.getCPAOrgAdminReportData.mean.levelDataMean.ipLevel",
                "data.getCPAOrgAdminReportData.standardDeviation.levelDataMean.ipLevel", "data.getCPAOrgAdminReportData.mean.levelDataMean.gain", "data.getCPAOrgAdminReportData.standardDeviation.levelDataMean.gain",
                "data.getCPAOrgAdminReportData.mean.usageMean.timeSpent", "data.getCPAOrgAdminReportData.standardDeviation.usageMean.timeSpent", "data.getCPAOrgAdminReportData.mean.usageMean.totalSessions",
                "data.getCPAOrgAdminReportData.standardDeviation.usageMean.totalSessions", "data.getCPAOrgAdminReportData.mean.instructionalPerformanceMean.exercisesCorrect",
                "data.getCPAOrgAdminReportData.standardDeviation.instructionalPerformanceMean.exercisesCorrect", "data.getCPAOrgAdminReportData.mean.instructionalPerformanceMean.exercisesAttempted",
                "data.getCPAOrgAdminReportData.standardDeviation.instructionalPerformanceMean.exercisesAttempted", "data.getCPAOrgAdminReportData.mean.instructionalPerformanceMean.exercisesPercentCorrect",
                "data.getCPAOrgAdminReportData.standardDeviation.instructionalPerformanceMean.exercisesPercentCorrect", "data.getCPAOrgAdminReportData.mean.masteryMean.skillsAssessed",
                "data.getCPAOrgAdminReportData.standardDeviation.masteryMean.skillsAssessed", "data.getCPAOrgAdminReportData.mean.masteryMean.skillsMastered", "data.getCPAOrgAdminReportData.standardDeviation.masteryMean.skillsMastered",
                "data.getCPAOrgAdminReportData.mean.masteryMean.skillsPercentMastered", "data.getCPAOrgAdminReportData.mean.masteryMean.percentStudentsWithAP", "data.getCPAOrgAdminReportData.standardDeviation.masteryMean.percentStudentsWithAP",
                "data.getCPAOrgAdminReportData.standardDeviation.masteryMean.skillsPercentMastered" );

        List<String> DEFAULT_READING_SELECTED_FILTERS = Arrays.asList( "data.getCPAOrgAdminReportData.courseName", "data.getCPAOrgAdminReportData.reportRun", "data.getCPAOrgAdminReportData.districtName", "data.getCPAOrgAdminReportData.dataRows.grade",
                "data.getCPAOrgAdminReportData.dataRows.orgData.organizationName", "data.getCPAOrgAdminReportData.dataRows.levelDataMean.currentCourseLevel", "data.getCPAOrgAdminReportData.dataRows.levelDataMean.ipLevel",
                "data.getCPAOrgAdminReportData.dataRows.levelDataMean.gain", "data.getCPAOrgAdminReportData.dataRows.usageMean.timeSpent", "data.getCPAOrgAdminReportData.dataRows.usageMean.totalSessions",
                "data.getCPAOrgAdminReportData.dataRows.instructionalPerformanceMean.exercisesCorrect", "data.getCPAOrgAdminReportData.dataRows.instructionalPerformanceMean.exercisesAttempted",
                "data.getCPAOrgAdminReportData.dataRows.instructionalPerformanceMean.exercisesPercentCorrect", "data.getCPAOrgAdminReportData.dataRows.masteryMean.skillsAssessed", "data.getCPAOrgAdminReportData.dataRows.masteryMean.skillsMastered",
                "data.getCPAOrgAdminReportData.dataRows.masteryMean.skillsPercentMastered", "data.getCPAOrgAdminReportData.dataRows.masteryMean.percentStudentsWithAP", "data.getCPAOrgAdminReportData.mean.levelDataMean.currentCourseLevel",
                "data.getCPAOrgAdminReportData.mean.levelDataMean.ipLevel", "data.getCPAOrgAdminReportData.mean.levelDataMean.gain", "data.getCPAOrgAdminReportData.mean.usageMean.timeSpent", "data.getCPAOrgAdminReportData.mean.usageMean.totalSessions",
                "data.getCPAOrgAdminReportData.mean.instructionalPerformanceMean.exercisesCorrect", "data.getCPAOrgAdminReportData.mean.instructionalPerformanceMean.exercisesAttempted",
                "data.getCPAOrgAdminReportData.mean.instructionalPerformanceMean.exercisesPercentCorrect", "data.getCPAOrgAdminReportData.mean.masteryMean.skillsAssessed", "data.getCPAOrgAdminReportData.mean.masteryMean.skillsMastered",
                "data.getCPAOrgAdminReportData.mean.masteryMean.skillsPercentMastered", "data.getCPAOrgAdminReportData.mean.masteryMean.percentStudentsWithAP", "data.getCPAOrgAdminReportData.standardDeviation.levelDataMean.currentCourseLevel",
                "data.getCPAOrgAdminReportData.standardDeviation.levelDataMean.ipLevel", "data.getCPAOrgAdminReportData.standardDeviation.levelDataMean.gain", "data.getCPAOrgAdminReportData.standardDeviation.usageMean.timeSpent",
                "data.getCPAOrgAdminReportData.standardDeviation.usageMean.totalSessions", "data.getCPAOrgAdminReportData.standardDeviation.instructionalPerformanceMean.exercisesCorrect",
                "data.getCPAOrgAdminReportData.standardDeviation.instructionalPerformanceMean.exercisesAttempted", "data.getCPAOrgAdminReportData.standardDeviation.instructionalPerformanceMean.exercisesPercentCorrect",
                "data.getCPAOrgAdminReportData.standardDeviation.masteryMean.skillsAssessed", "data.getCPAOrgAdminReportData.standardDeviation.masteryMean.skillsMastered", "data.getCPAOrgAdminReportData.standardDeviation.masteryMean.skillsPercentMastered",
                "data.getCPAOrgAdminReportData.standardDeviation.masteryMean.percentStudentsWithAP" );

        List<String> CUSTOM_READING_SELECTED_FILTERS = Arrays.asList( "data.getCPAOrgAdminReportData.reportRun", "data.getCPAOrgAdminReportData.dataRows.orgData.organizationName", "data.getCPAOrgAdminReportData.dataRows.grade",
                "data.getCPAOrgAdminReportData.dataRows.gradeDisplayOrder", "data.getCPAOrgAdminReportData.dataRows.levelDataMean.currentCourseLevel", "data.getCPAOrgAdminReportData.dataRows.levelDataMean.ipLevel",
                "data.getCPAOrgAdminReportData.dataRows.levelDataMean.gain", "data.getCPAOrgAdminReportData.dataRows.usageMean.timeSpent", "data.getCPAOrgAdminReportData.dataRows.usageMean.totalSessions",
                "data.getCPAOrgAdminReportData.dataRows.instructionalPerformanceMean.exercisesCorrect", "data.getCPAOrgAdminReportData.dataRows.instructionalPerformanceMean.exercisesAttempted",
                "data.getCPAOrgAdminReportData.dataRows.masteryMean.skillsAssessed", "data.getCPAOrgAdminReportData.dataRows.masteryMean.skillsMastered", "data.getCPAOrgAdminReportData.courseName",
                "data.getCPAOrgAdminReportData.dataRows.masteryMean.percentStudentsWithAP", "data.getCPAOrgAdminReportData.dataRows.orgData.numberOfStudents", "data.getCPAOrgAdminReportData.schoolCount",
                "data.getCPAOrgAdminReportData.dataRows.masteryMean.skillsPercentMastered", "data.getCPAOrgAdminReportData.dataRows.instructionalPerformanceMean.exercisesPercentCorrect",
                "data.getCPAOrgAdminReportData.mean.levelDataMean.currentCourseLevel", "data.getCPAOrgAdminReportData.standardDeviation.levelDataMean.currentCourseLevel", "data.getCPAOrgAdminReportData.mean.levelDataMean.ipLevel",
                "data.getCPAOrgAdminReportData.standardDeviation.levelDataMean.ipLevel", "data.getCPAOrgAdminReportData.mean.levelDataMean.gain", "data.getCPAOrgAdminReportData.standardDeviation.levelDataMean.gain",
                "data.getCPAOrgAdminReportData.mean.usageMean.timeSpent", "data.getCPAOrgAdminReportData.standardDeviation.usageMean.timeSpent", "data.getCPAOrgAdminReportData.mean.usageMean.totalSessions",
                "data.getCPAOrgAdminReportData.standardDeviation.usageMean.totalSessions", "data.getCPAOrgAdminReportData.mean.instructionalPerformanceMean.exercisesCorrect",
                "data.getCPAOrgAdminReportData.standardDeviation.instructionalPerformanceMean.exercisesCorrect", "data.getCPAOrgAdminReportData.mean.instructionalPerformanceMean.exercisesAttempted",
                "data.getCPAOrgAdminReportData.standardDeviation.instructionalPerformanceMean.exercisesAttempted", "data.getCPAOrgAdminReportData.mean.instructionalPerformanceMean.exercisesPercentCorrect",
                "data.getCPAOrgAdminReportData.standardDeviation.instructionalPerformanceMean.exercisesPercentCorrect", "data.getCPAOrgAdminReportData.mean.masteryMean.skillsAssessed",
                "data.getCPAOrgAdminReportData.standardDeviation.masteryMean.skillsAssessed", "data.getCPAOrgAdminReportData.mean.masteryMean.skillsMastered", "data.getCPAOrgAdminReportData.standardDeviation.masteryMean.skillsMastered",
                "data.getCPAOrgAdminReportData.mean.masteryMean.skillsPercentMastered", "data.getCPAOrgAdminReportData.mean.masteryMean.percentStudentsWithAP", "data.getCPAOrgAdminReportData.standardDeviation.masteryMean.percentStudentsWithAP",
                "data.getCPAOrgAdminReportData.standardDeviation.masteryMean.skillsPercentMastered" );

    }

}
