package com.savvas.sm.utils.sme187.admin.api.settings;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;

public class HolidayScheduler {

    /***
     * 
     * getHolidayScheduler() -> This method get the Holidays noted for the given
     * Admin.
     * 
     * @param smUrl -> The URL can be basic, auto and MSMN. Basic:
     *            https://nightly-next-basic.smdemo.info Auto:
     *            https://nightly-next-auto.smdemo.info MSMN:
     *            https://nightly-next-automsmn.smdemo.info
     * @param headers -> Header must contain the orgId,userId & Authorization
     *            The Keys to be given as follows:
     *            OrganizationAPIConstants.ORGID OrganizationAPIConstants.USERID
     *            OrganizationAPIConstants.AUTHORISATION
     * @return response -> The Get Call response will be given as a
     *         HashMap<String,String>
     * @throws Exception
     * 
     */
    public Map<String, String> getHolidayScheduler( String smUrl, Map<String, String> headers, String selectedOrgId ) throws Exception {
        Map<String, String> param = new HashMap<>();
        param.put( "selectedOrgId", selectedOrgId );
        return RestHttpClientUtil.GET( smUrl, AdminConstants.GET_HOLIDAY_SCHEDULER, headers, param );
    }

    /***
     * 
     * putHolidayScheduler() -> This method create/edit holidays and description
     * for the given dates.
     * 
     * @param smUrl -> The URL can be basic, auto and MSMN. Basic:
     *            https://nightly-next-basic.smdemo.info Auto:
     *            https://nightly-next-auto.smdemo.info MSMN:
     *            https://nightly-next-automsmn.smdemo.info
     * 
     * @param headers -> Header must contain the content-type, orgId, userId &
     *            Authorization The Keys to be given as follows:
     *            Constants.CONTENT_TYPE OrganizationAPIConstants.ORGID
     *            OrganizationAPIConstants.USERID
     *            OrganizationAPIConstants.AUTHORISATION
     * 
     * @param startDate -> Start date of the holiday should be passed as a
     *            String in <yyyy-mm-dd>
     * @param endDate -> End date of the holiday should be passed as a String in
     *            <yyyy-mm-dd>
     * @param description -> Description for the holiday(s) should be given as a
     *            String
     * @return response -> The Get Call response will be given as a
     *         HashMap<String,String>
     * @throws Exception
     * 
     */
    public Map<String, String> putHolidayScheduler( String smUrl, Map<String, String> headers, String startDate, String endDate, String description, String selectedOrgId ) throws Exception {
        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "editHolidaySchedulerPayload.json" ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), AdminConstants.START_DATE, startDate ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), AdminConstants.END_DATE, endDate ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), AdminConstants.DESCRIPTION, description ) );
        requestBody.set( "[" + requestBody.get() + "]" );
        Map<String, String> param = new HashMap<>();
        param.put( "selectedOrgId", selectedOrgId );
        return RestHttpClientUtil.PUT( smUrl, headers, param, AdminConstants.PUT_HOLIDAY_SCHEDULER, requestBody.get() );
    }

    /***
     * 
     * deleteHolidayScheduler() -> This method delete holidays for the given
     * dates.
     * 
     * @param smUrl -> The URL can be basic, auto and MSMN. Basic:
     *            https://nightly-next-basic.smdemo.info Auto:
     *            https://nightly-next-auto.smdemo.info MSMN:
     *            https://nightly-next-automsmn.smdemo.info
     * 
     * @param headers -> Header must contain the content-type, orgId, userId &
     *            Authorization The Keys to be given as follows:
     *            Constants.CONTENT_TYPE OrganizationAPIConstants.ORGID
     *            OrganizationAPIConstants.USERID
     *            OrganizationAPIConstants.AUTHORISATION
     * 
     * @param startDate -> Start date of the holiday should be passed as a
     *            String in <yyyy-mm-dd>
     * @param endDate -> End date of the holiday should be passed as a String in
     *            <yyyy-mm-dd>
     * @param description -> Description for the holiday(s) should be given as a
     *            String
     * @return response -> The Get Call response will be given as a
     *         HashMap<String,String>
     * @throws Exception
     * 
     */

    public Map<String, String> deleteHolidayScheduler( String smUrl, Map<String, String> headers, String startDate, String endDate, String description, String selectedOrgId ) throws Exception {
        String payload = "[{\"startDate\": \"{startdate}\", \"endDate\": \"{enddate}\"}]";
        payload = payload.replace( "{startdate}", startDate ).replace( "{enddate}", endDate );
        Map<String, String> param = new HashMap<>();
        param.put( "selectedOrgId", selectedOrgId );
        return RestHttpClientUtil.DELETE( smUrl, headers, param, AdminConstants.DELETE_HOLIDAY_SCHEDULER, payload );
    }
}
