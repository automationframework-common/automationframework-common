package com.savvas.sm.ui.constants;

public interface LoginConstants {
    interface UserType {
        public static String BASIC = "basic";
        public static String AUTO = "auto";
        public static String PLUS = "plus";
    }
}
