package com.savvas.sm.utils.sme187.teacher.api.assignment;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.sme7.DataSetupProcessor;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

import io.restassured.response.Response;

public class AssignmentAPI extends EnvProperties {

    public static String isItMt = configProperty.getProperty( "isMTExecution" );

    public interface Assignment {
        /**
         * The Assignment - TableConstants, Assignment SQL Constants
         * 
         * @author madhan.nagarathinam
         */
        public String ASSIGNMENT_ID = "assignment_id";
        public String ASSIGNMENT_NAME = "assignment_title";
        public String QUERY_TO_GET_ASSIGNMENT_MATH = "SELECT * FROM school.assignment where assignment_owner_id = '%s' and content_base_id IN ('1', '3', '4','5','6','7','8','9','10')";
        public String QUERY_TO_GET_ASSIGNMENT_READING = "SELECT * FROM school.assignment where assignment_owner_id = '%s' and content_base_id IN ('2', '11', '12','13','14','15','16','17','18')";
        public String QUERY_TO_GET_ASSIGNMENTS = "SELECT * FROM school.assignment";

    }

    /**
     * This Method will generate headers
     * 
     * @param userreqDetails should contains bearer token, teacher rumbaID & org
     *            ID
     * @return
     */
    public Map<String, String> getHeaders( HashMap<String, String> userreqDetails ) {
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + userreqDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );

        headers.put( Constants.USERID_SM_HEADER, userreqDetails.get( AssignmentAPIConstants.TEACHER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, userreqDetails.get( AssignmentAPIConstants.ORG_ID ) );
        return headers;
    }

    /**
     * 
     * @param envUrl
     * @param assignmentDetails contains bearer token, teacher rumbaID & org ID
     *            & assignment user ID
     * 
     * @param status
     * @param endpoint
     * @return
     * @throws Exception
     */

    public HashMap<String, String> changeAssignmentStatus( String envUrl, HashMap<String, String> assignmentDetails, String status, String endpoint ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String endPoint;

        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String assignmentUserID = assignmentDetails.get( AssignmentAPIConstants.ASSIGNMENT_USER_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        AtomicReference<String> requestBody = new AtomicReference<>();

        requestBody.set( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.PAUSE_RESUME_PAYLOAD ) );

        requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AssignmentAPIConstants.STATUS ), status ) );

        if ( endpoint.equalsIgnoreCase( "null" ) ) {
            endPoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_API;
            endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{AssignmentUserId}", assignmentUserID );
        } else {
            endPoint = endpoint;
        }
        return RestHttpClientUtil.PUT( envUrl, headers, params, endPoint, requestBody.get() );
    }

    /**
     * To get all the assignments assigned by teacher
     * 
     * @param envUrl
     * @param assignmentDetails contains bearer token, teacher rumbaID & org ID
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getAssignmentLists( String envUrl, HashMap<String, String> assignmentDetails ) throws Exception {

        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = AssignmentAPIConstants.GET_ASSIGNMENTS_LIST;

        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID );

        return RestHttpClientUtil.GET( envUrl, endPoint, headers, params );
    }

    /**
     * To get only recent assignments in HomePage
     * 
     * @param envUrl
     * @param assignmentDetails contains bearer token, teacher rumbaID & org ID
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getRecentAssignmentLists( String envUrl, HashMap<String, String> assignmentDetails ) throws Exception {

        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        Map<String, String> headers = getHeaders( assignmentDetails );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = AssignmentAPIConstants.GET_RECENT_ASSIGNMENTS_API;

        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID );

        return RestHttpClientUtil.GET( envUrl, endPoint, headers, params );
    }

    /**
     * To get all the assignments settings
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID,
     *            org ID & course ID
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getAssignmentSettings( String envUrl, HashMap<String, String> assignmentDetails ) throws Exception {
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String courseID = assignmentDetails.get( AssignmentAPIConstants.COURSE_ID );
        Map<String, String> headers = getHeaders( assignmentDetails );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = AssignmentAPIConstants.GET_ASSIGNMENT_SETTINGS_API;

        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{courseID}", courseID );

        return RestHttpClientUtil.GET( envUrl, endPoint, headers, params );
    }

    /**
     * To Delete the assignment
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID,
     *            org ID & course ID
     * @return
     * @throws Exception
     */
    public HashMap<String, String> deleteAssignment( String envUrl, HashMap<String, String> assignmentDetails, String endpoint ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String courseID = assignmentDetails.get( AssignmentAPIConstants.COURSE_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        if ( endpoint.equalsIgnoreCase( AssignmentAPIConstants.EXCEPTIONNULL ) ) {
            endpoint = AssignmentAPIConstants.DELETE_ASSIGNMENT_API;
            endpoint = endpoint.replace( AssignmentAPIConstants.ORG_ID_VALUE, orgID ).replace( AssignmentAPIConstants.TEACHER_ID_VALUE, teacherID ).replace( AssignmentAPIConstants.CONTENT_BASE_ID_ENDPOINT, courseID );
        }

        return RestHttpClientUtil.DELETE( envUrl, endpoint, headers, params );
    }

    /**
     * To assign an assignment to a user(s) or groups(s)
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID,
     *            org ID & course ID
     * @param studentRumbaIds
     * @param type should be users or groups
     * @return
     * @throws Exception
     */
    public HashMap<String, String> assignAssignment( String envUrl, HashMap<String, String> assignmentDetails, List<String> studentRumbaIds, String type ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String courseID = assignmentDetails.get( AssignmentAPIConstants.COURSE_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = AssignmentAPIConstants.CREATE_ASSIGNMENT_API;

        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.ASSIGN_ASSIGNMENT_PAYLOAD ) );

        if ( !studentRumbaIds.isEmpty() ) {
            String listString = "";
            for ( String studentID : studentRumbaIds ) {

                listString += studentID.concat( "\",\"" );

            }
            listString = listString.substring( 0, listString.length() - 3 );
            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AssignmentAPIConstants.STUDENT_RUMBA_IDS ), listString ) );

            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AssignmentAPIConstants.STUDENT_RUMBA_GRADE_IDS ), listString ).replace( ",,", "," ) );
        } else {
            Log.fail( "Student / Group ID missing" );
        }

        if ( type.equalsIgnoreCase( AssignmentAPIConstants.USERS_TYPE ) ) {
            requestBody.set( requestBody.get().replace( "{type}", AssignmentAPIConstants.USERS_TYPE ) );
        } else if ( type.equalsIgnoreCase( AssignmentAPIConstants.GROUPS_TYPE ) ) {
            requestBody.set( requestBody.get().replace( "{type}", AssignmentAPIConstants.GROUPS_TYPE ) );
        } else {
            Log.fail( "Invalid Type: " + type );
        }

        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{courseID}", courseID );

        return RestHttpClientUtil.POST( envUrl, headers, params, endPoint, requestBody.get() );

    }

    /**
     * To get all the assignments assigned
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID,
     *            org ID & course ID
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getViewAssignment( String envUrl, HashMap<String, String> assignmentDetails ) throws Exception {

        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String contentbaseId = assignmentDetails.get( AssignmentAPIConstants.COURSE_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = AssignmentAPIConstants.GET_ASSIGNMENT_VIEW;

        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{contentbaseId}", contentbaseId );

        return RestHttpClientUtil.GET( envUrl, endPoint, headers, params );
    }

    /**
     * To get the assignment lists based on the group ID
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID,
     *            org ID & group ID
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getGroupAssignmentLists( String envUrl, HashMap<String, String> assignmentDetails ) throws Exception {

        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String groupID = assignmentDetails.get( AssignmentAPIConstants.GROUP_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = AssignmentAPIConstants.GET_GROUP_ASSIGNMENTS_API;

        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{groupID}", groupID );

        return RestHttpClientUtil.GET( envUrl, endPoint, headers, params );
    }

    /**
     * To Resume or Pause the Assignment for all students
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID,
     *            org ID & course ID
     * @param status [ACTIVE => RESUME, INACTIVE=>PAUSE]
     * @param endpoint
     * @return
     * @throws Exception
     */
    public HashMap<String, String> changeAssignmentStatusForAllStudents( String envUrl, HashMap<String, String> assignmentDetails, String status, String endpoint ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );

        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String assignmentID = assignmentDetails.get( AssignmentAPIConstants.COURSE_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        AtomicReference<String> requestBody = new AtomicReference<>();

        requestBody.set( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.PAUSE_RESUME_PAYLOAD ) );
        requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AssignmentAPIConstants.STATUS ), status ) );

        // Input Path Parameters
        if ( endpoint.equalsIgnoreCase( AssignmentAPIConstants.EXCEPTIONNULL ) ) {
            endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
            endpoint = endpoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{contentbaseId}", assignmentID );
        }

        return RestHttpClientUtil.PUT( envUrl, headers, params, endpoint, requestBody.get() );
    }

    /**
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID &
     *            org ID
     * @param studentRumbaIds
     * @param courseIDs
     * @return
     * @throws Exception
     */
    public HashMap<String, String> assignMultipleAssignments( String envUrl, HashMap<String, String> assignmentDetails, List<String> studentRumbaIds, List<String> courseIDs ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = AssignmentAPIConstants.ASSIGN_MULTIPLE_ASSIGNMENTS_API;

        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.ASSIGN_MULTIPLE_ASSIGNMENT_PAYLOAD ) );

        if ( !studentRumbaIds.isEmpty() && !courseIDs.isEmpty() ) {
            String listString = "";
            for ( String studentID : studentRumbaIds ) {

                listString += studentID.concat( "\",\"" );

            }
            listString = listString.substring( 0, listString.length() - 3 );
            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AssignmentAPIConstants.STUDENT_RUMBA_IDS ), listString ) );

            listString = "";
            for ( String courseID : courseIDs ) {

                listString += courseID.concat( "\",\"" );

            }
            listString = listString.substring( 0, listString.length() - 3 );
            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AssignmentAPIConstants.COURSE_IDS ), listString ) );
        } else {
            Log.fail( "Student / Course ID missing" );
        }

        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID );
        return RestHttpClientUtil.POST( envUrl, headers, params, endPoint, requestBody.get() );

    }

    /**
     * To get the assignment lists by SubjectID => Math=1 & Reading=2
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID &
     *            org ID
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getAssignmentsBySubjectID( String envUrl, HashMap<String, String> assignmentDetails ) throws Exception {

        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = AssignmentAPIConstants.GET_ASSIGNMENTS_BY_SUBJECTID_API;

        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID );

        return RestHttpClientUtil.GET( envUrl, endPoint, headers, params );
    }

    /**
     * To Delete the assignment from group
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID &
     *            org ID, groupID & courseID
     * @param endpoint
     * @return
     * @throws Exception
     */
    public HashMap<String, String> deleteAssignmentfromGroup( String envUrl, HashMap<String, String> assignmentDetails, String endpoint ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String groupID = assignmentDetails.get( AssignmentAPIConstants.GROUP_ID );
        String courseID = assignmentDetails.get( AssignmentAPIConstants.COURSE_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        if ( endpoint.equalsIgnoreCase( AssignmentAPIConstants.EXCEPTIONNULL ) ) {
            endpoint = AssignmentAPIConstants.DELETE_ASSIGNMENT_GROUP_API;
            endpoint = endpoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{contentbaseId}", courseID ).replace( "{groupID}", groupID );
        }

        return RestHttpClientUtil.DELETE( envUrl, endpoint, headers, params );
    }

    /**
     * To Remove Student from the assignment
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID &
     *            assignment userID
     * @return
     * @throws Exception
     */
    public HashMap<String, String> removeStudentAssignment( String envUrl, HashMap<String, String> assignmentDetails, String endpoint ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String assignmentuserID = assignmentDetails.get( AssignmentAPIConstants.ASSIGNMENT_USER_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        if ( endpoint.equalsIgnoreCase( AssignmentAPIConstants.EXCEPTIONNULL ) ) {
            endpoint = AssignmentAPIConstants.DELETE_STUDENT_ASSIGNMENT_API;

            endpoint = endpoint.replace( "{assignmentUserID}", assignmentuserID );
        }

        return RestHttpClientUtil.DELETE( envUrl, endpoint, headers, params );
    }

    /**
     * To update the assignment user settings
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID &
     *            assignment userID
     * @param assignmentUserSettings
     * @param studentRumbaId
     * @param subject
     * @return
     * @throws Exception
     */
    public HashMap<String, String> updateAssignmentUserSettings( String envUrl, HashMap<String, String> assignmentDetails, HashMap<String, String> assignmentUserSettings, List<String> studentRumbaIds, String subject ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String endPoint;
        String requestBody = "";

        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String assignmentuserID = assignmentDetails.get( AssignmentAPIConstants.ASSIGNMENT_USER_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();
        if ( subject.equalsIgnoreCase( "Math" ) ) {
            requestBody = SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.MATH_UPDATE_USERSETTINGS );
        } else {
            requestBody = SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.READING_UPDATE_USERSETTINGS );
        }

        if ( !studentRumbaIds.isEmpty() ) {
            String listString = "";
            for ( String studentID : studentRumbaIds ) {
                listString += studentID.concat( "\",\"" );
            }

            listString = listString.substring( 0, listString.length() - 3 );

            requestBody = requestBody.replace( "{studentRumbaIds}", listString );
        }

        for ( String option : assignmentUserSettings.keySet() ) {
            requestBody = requestBody.replace( "{" + option + "}", assignmentUserSettings.get( option ) );
        }

        Log.message( requestBody );

        endPoint = AssignmentAPIConstants.UPDATE_ASSIGNMENT_USERSETTINGS_API;
        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{assignmentUserID}", assignmentuserID );

        return RestHttpClientUtil.PUT( envUrl, headers, params, endPoint, requestBody );
    }

    /**
     * To update the assignment user settings without Body
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID &
     *            assignment userID
     * @param assignmentUserSettings
     * @param studentRumbaId
     * @return
     * @throws Exception
     */
    public HashMap<String, String> updateAssignmentUserSettingsWithoutBody( String envUrl, HashMap<String, String> assignmentDetails, HashMap<String, String> assignmentUserSettings, List<String> studentRumbaIds ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String endPoint;

        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String assignmentuserID = assignmentDetails.get( AssignmentAPIConstants.ASSIGNMENT_USER_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        String requestBody = "";

        if ( !studentRumbaIds.isEmpty() ) {
            String listString = "";
            for ( String studentID : studentRumbaIds ) {
                listString += studentID.concat( "\",\"" );
            }

            listString = listString.substring( 0, listString.length() - 3 );

            requestBody = requestBody.replace( "{studentRumbaIds}", listString );
        }

        for ( String option : assignmentUserSettings.keySet() ) {
            requestBody = requestBody.replace( "{" + option + "}", assignmentUserSettings.get( option ) );
        }

        Log.message( requestBody );

        endPoint = AssignmentAPIConstants.UPDATE_ASSIGNMENT_USERSETTINGS_API;
        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{assignmentUserID}", assignmentuserID );

        return RestHttpClientUtil.PUT( envUrl, headers, params, endPoint, requestBody );
    }

    /**
     * To Resume or Pause the group Assignment
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID,
     *            group ID & course ID
     * 
     * @param status [ACTIVE => RESUME, INACTIVE=>PAUSE]
     * @return
     * @throws Exception
     */

    public HashMap<String, String> changeGroupAssignmentStatus( String envUrl, HashMap<String, String> assignmentDetails, String status, String endpoint ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String endPoint;

        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String groupID = assignmentDetails.get( AssignmentAPIConstants.GROUP_ID );
        String courseID = assignmentDetails.get( AssignmentAPIConstants.COURSE_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.PAUSE_RESUME_PAYLOAD ) );

        requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AssignmentAPIConstants.STATUS ), status ) );

        if ( endpoint.equalsIgnoreCase( "null" ) ) {
            endPoint = AssignmentAPIConstants.PAUSE_RESUME_GROUPASSIGNMENT_API;
            endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{groupID}", groupID ).replace( "{contentbaseId}", courseID );
        } else {
            endPoint = endpoint;
        }
        return RestHttpClientUtil.PUT( envUrl, headers, params, endPoint, requestBody.get() );
    }

    /**
     * 
     * @param smUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID &
     *            assignment ID
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getUserAssignmentSetting( String smUrl, HashMap<String, String> assignmentDetails ) throws Exception {
        //Headers
        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String assignmentID = assignmentDetails.get( AssignmentAPIConstants.ASSIGNMENT_ID );
        String studentID = assignmentDetails.get( AssignmentAPIConstants.STUDENT_RUMBA_IDS );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        //Input Path Parameters
        String endPoint = AssignmentAPIConstants.GET_USER_ASSIGNMENT_SETTINGS_API;

        endPoint = endPoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.OWNER_ORG_ID ) );
        endPoint = endPoint.replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID_ENDPOINT ) );
        endPoint = endPoint.replace( "{studentId}", studentID );
        endPoint = endPoint.replace( "{assignmentId}", assignmentID );

        return RestHttpClientUtil.GET( smUrl, endPoint, headers, params );

    }

    /**
     * To assign an assignment to a user(s) or groups(s)
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID &
     *            course ID
     * @param studentRumbaIds
     * @param type
     * @return
     * @throws Exception
     */
    public HashMap<String, String> assignAssignmentToSingleStudent( String envUrl, HashMap<String, String> assignmentDetails, List<String> studentRumbaIds, String type ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String courseID = assignmentDetails.get( AssignmentAPIConstants.COURSE_ID );

        assignmentDetails.put( AssignmentAPIConstants.REQUEST_BODY_TYPE, AssignmentAPIConstants.USERS_TYPE );
        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = AssignmentAPIConstants.CREATE_ASSIGNMENT_API;

        AtomicReference<String> requestBody = new AtomicReference<>();

        requestBody.set( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.ASSIGN_ASSIGNMENT_PAYLOAD ) );

        requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AssignmentAPIConstants.STUDENT_RUMBA_IDS ), studentRumbaIds.get( 0 ) ) );

        requestBody.set( requestBody.get().replace( "{type}", AssignmentAPIConstants.USERS_TYPE ) );

        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{courseID}", courseID );
        Log.message( "Assign Endpoint: " + endPoint );
        return RestHttpClientUtil.POST( envUrl, headers, params, endPoint, requestBody.get() );
    }

    /**
     * To get Assignment Details by studentID
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID,
     *            student rumbaID
     * @param endpoint
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getStudnetAssignmentDetailsByStudnetID( String envUrl, HashMap<String, String> assignmentDetails, String endpoint ) throws Exception {

        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String studentID = assignmentDetails.get( AssignmentAPIConstants.STUDENT_ID );
        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // End point
        if ( endpoint.equalsIgnoreCase( AssignmentAPIConstants.EXCEPTIONNULL ) ) {
            endpoint = AssignmentAPIConstants.GET_STUDENT_ASSIGNMENT_DETAILS_BY_STUDENT_ID;
            endpoint = endpoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{studentID}", studentID );
        }

        return RestHttpClientUtil.GET( envUrl, endpoint, headers, params );
    }

    /**
     * To get unassigned assignment of Students
     * 
     * @param envUrl
     * @param assignmentDetails
     * @param studentRumbaIds
     * @param type
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getAssignmentsunassignedStudent( String envUrl, HashMap<String, String> assignmentDetails, String studentRumbaIds, String endpoint ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );

        // Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters

        AtomicReference<String> requestBody = new AtomicReference<>();

        requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "getAssignmentsunassignedStudent" ) ) );

        requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AssignmentAPIConstants.STUDENT_RUMBA_IDS ), studentRumbaIds ) );

        requestBody.set( requestBody.get().replace( "{type}", AssignmentAPIConstants.USERS_TYPE ) );

        Log.message( "Assign Request Body: " + requestBody.get() );

        if ( endpoint.equalsIgnoreCase( CourseAPIConstants.NULL ) ) {
            endpoint = AssignmentAPIConstants.GET_ASSIGNMENTS_UNASSIGNED_STUDENTS;
            endpoint = endpoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID );
            System.out.println( endpoint );
        }

        Log.message( "Assign Endpoint: " + endpoint );

        return RestHttpClientUtil.POST( envUrl, headers, params, endpoint, requestBody.get() );
    }

    /**
     * To restore deleted user assignment
     *
     * @param envUrl
     * @param assignmentDetails
     * @param endpoint
     * @return
     * @throws Exception
     */
    public HashMap<String, String> restoreDeletedAssignment( String envUrl, HashMap<String, String> assignmentDetails, String endpoint ) throws Exception {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + assignmentDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) );

        // Parameters
        HashMap<String, String> params = new HashMap<>();

        AtomicReference<String> requestBody = new AtomicReference<>();

        requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "restoreDeletedAssignment" ) ) );

        requestBody.set( requestBody.get().replace( "{auser id}", assignmentDetails.get( AssignmentAPIConstants.ASSIGNMENT_USER_ID ) ) );

        Log.message( "Request Body: " + requestBody.get() );

        if ( endpoint.equalsIgnoreCase( CourseAPIConstants.NULL ) ) {
            endpoint = AssignmentAPIConstants.RESTORE_DELETED_ASSIGNMENTS;
        }

        return RestHttpClientUtil.PUT( envUrl, headers, params, endpoint, requestBody.get() );
    }

    /**
     *
     * @param envUrl
     * @param groupDetails should contains group name, organization ID, teacher
     *            ID and bearer token
     * @param studentRumbaIds If there is no student please leave as empty
     * @return
     * @throws Exception
     */
    public static HashMap<String, String> createGroupWithoutUpdateStudentGrade( String envUrl, HashMap<String, String> groupDetails, List<String> studentRumbaIds ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + groupDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, groupDetails.get( GroupConstants.GROUP_OWNER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, groupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        //Endpoint
        String endPoint = GroupConstants.GroupAPIEndPoints.CREATE_GROUP_API_ENDPOINT;

        if ( groupDetails.containsKey( GroupConstants.INVALID_ORG ) ) {
            endPoint = endPoint.replace( Constants.ORG_ID, groupDetails.get( GroupConstants.INVALID_ORG ) );
        } else {
            endPoint = endPoint.replace( Constants.ORG_ID, groupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );

        }
        if ( groupDetails.containsKey( GroupConstants.INVALID_TEACHER ) ) {
            endPoint = endPoint.replace( Constants.STAFF_ID, groupDetails.get( GroupConstants.INVALID_TEACHER ) );

        } else {
            endPoint = endPoint.replace( Constants.STAFF_ID, groupDetails.get( GroupConstants.GROUP_OWNER_ID ) );

        }

        //body
        String groupName = groupDetails.get( GroupConstants.GROUP_NAME );
        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( GroupConstants.CREATE_GROUP_API_PAYLOAD ) ) );
        if ( studentRumbaIds.size() > 0 ) {
            String listString = "";
            for ( String studentID : studentRumbaIds ) {

                listString += studentID.concat( "\",\"" );

            }
            listString = listString.substring( 0, listString.length() - 3 );
            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( GroupConstants.STUDENT_RUMBA_IDS ), listString ) );

        } else {
            requestBody.set( JSONUtil.removeProperty( requestBody.get(), GroupConstants.STUDENT_RUMBA_IDS ) );
        }
        if ( groupDetails.containsKey( GroupConstants.INVALID_GROUP_NAME ) ) {
            requestBody.set( JSONUtil.setProperty( requestBody.get(), GroupConstants.GROUP_NAME, groupDetails.get( GroupConstants.INVALID_GROUP_NAME ) ) );
        } else {
            requestBody.set( JSONUtil.setProperty( requestBody.get(), GroupConstants.GROUP_NAME, groupDetails.get( GroupConstants.GROUP_NAME ) ) );
        }

        HashMap<String, String> response = RestHttpClientUtil.POST( envUrl, headers, params, endPoint, requestBody.get() );
        return response;
    }

    /**
     * To School Motion
     *
     * @param envUrl
     * @param assignmentDetails
     * @param endpoint
     * @return
     * @throws Exception
     */
    public static HashMap<String, String> schoolMotion( String envUrl, HashMap<String, String> assignmentDetails, String endpoint, String reqParam ) throws Exception {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + assignmentDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, assignmentDetails.get( AssignmentAPIConstants.SCHOOL_ADMIN_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) );

        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        // Parameters
        HashMap<String, String> params = new HashMap<>();
        if ( reqParam.equalsIgnoreCase( CourseAPIConstants.NULL ) ) {
            params.put( "organizationId", orgID );
        } else {
            params.put( "organizationId", reqParam );
        }
        AtomicReference<String> requestBody = new AtomicReference<>();

        requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "schoolMotionLog" ) ) );

        requestBody.set( requestBody.get().replace( "{motion}", assignmentDetails.get( AssignmentAPIConstants.CAPTURE_RESEARCH_DATA ) ) );

        Log.message( "Request Body: " + requestBody.get() );

        if ( endpoint.equalsIgnoreCase( CourseAPIConstants.NULL ) ) {
            endpoint = AssignmentAPIConstants.SCHOOL_MOTION_ON;
        }

        return RestHttpClientUtil.POST( envUrl, headers, params, endpoint, requestBody.get() );
    }

    /**
     * To create a custom course
     * 
     * @param smUrl
     * @param token
     * @param subject
     * @param teacherID
     * @param orgID
     * @param courseType
     * @param courseName
     * @param jsonFileName
     * @return
     * @throws Exception
     */
    public String createCustomCourse( String smUrl, String token, String subject, String teacherID, String orgID, String courseType, String courseName, String jsonFileName ) throws Exception {
        HashMap<String, String> response_post = new HashMap<>();
        DataSetupProcessor dataprocess = new DataSetupProcessor();
        try {
            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + token );
            headers.put( Constants.USERID_SM_HEADER, teacherID );
            headers.put( Constants.ORGID_SM_HEADER, orgID );
            // Input Params
            HashMap<String, String> params = new HashMap<>();

            // EndPoint Details
            String endPoint_post = CourseAPIConstants.POST_STANDARD_COURSE_COPY;
            if ( subject.contentEquals( DataSetupConstants.MATH ) ) {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "1" );
            } else {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "2" );
            }

            endPoint_post = endPoint_post.replace( Constants.ORG_ID, orgID );
            endPoint_post = endPoint_post.replace( Constants.STAFF_ID, teacherID );

            Map<String, String> courseDetails = new HashMap<String, String>();
            courseDetails.put( Constants.COURSE_NAME, courseName );
            String requestBody = null;
            if ( courseType.equalsIgnoreCase( DataSetupConstants.SETTINGS ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                } else {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.SKILL ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                } else {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.STANDARD ) ) {
                List<String> standardDetails = new ArrayList<>();

                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    standardDetails = SqlHelperAssignment.getRandomStandardGradeID( DataSetupConstants.MATH, isItMt.equalsIgnoreCase( "true" ) );
                } else {
                    standardDetails = SqlHelperAssignment.getRandomStandardGradeID( DataSetupConstants.READING, isItMt.equalsIgnoreCase( "true" ) );
                }

                List<String> listLO = SqlHelperAssignment.getLOIDsRandomStandard( standardDetails.get( 0 ), standardDetails.get( 1 ), isItMt.equalsIgnoreCase( "true" ) );
                courseDetails.put( Constants.STANDARDFRAMEWORK_ID, standardDetails.get( 0 ) );
                courseDetails.put( Constants.GRADE_ID, standardDetails.get( 1 ) );
                courseDetails.put( Constants.BANKID, listLO.get( 0 ).split( "_" )[3] ); //To get Bank ID from LO
                courseDetails.put( Constants.LOID, listLO.get( 0 ) );
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                } else {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                }

            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.ONE_LO ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( DataSetupConstants.CUSTOM_BY_SKILL_ONE_LO, courseDetails );
                }
            }
            response_post = RestHttpClientUtil.POST( smUrl, headers, params, endPoint_post, requestBody );
            if ( response_post.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                return SMUtils.getKeyValueFromResponse( response_post.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.REPORT_COURSEID );
            } else {
                return response_post.get( Constants.REPORT_BODY );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response_post.get( Constants.REPORT_BODY );
    }

    /**
     * PUT API to save Session start time data
     *
     * @param envUrl
     * @param headers
     * @param assignmentDetails
     * 
     * @return
     */
    public HashMap<String, String> saveSessionStartTime( String envUrl, HashMap<String, String> headers, HashMap<String, String> assignmentDetails ) {
        try {

            String endpoint = CourseAPIConstants.SAVE_SAVE_SESSION_START_TIME;
            Log.message( "Save session start time = " + endpoint );

            String courseStartTime = String.valueOf( ZonedDateTime.now().toInstant().toEpochMilli() );

            //Parameters
            HashMap<String, String> params = new HashMap<>();
            params.put( CourseAPIConstants.COURSE_START_TIME, courseStartTime );

            String requestBody = "";

            Log.message( headers.toString() );

            HashMap<String, String> responseSaveSessionStartTime = RestHttpClientUtil.PUT( envUrl, headers, params, endpoint, requestBody );

            return responseSaveSessionStartTime;

        } catch ( Exception e ) {
            Log.message( "Error in saveSCO method" );
            return null;
        }
    }

    /**
     * To get group assignment settings
     * 
     * @param envUrl
     * @param assignmentDetails
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getGroupAssignmentSettings( String envUrl, HashMap<String, String> assignmentDetails ) throws Exception {
        Map<String, String> headers = new HashMap<>();
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String courseID = assignmentDetails.get( AssignmentAPIConstants.COURSE_ID );
        String groupID = assignmentDetails.get( AssignmentAPIConstants.GROUP_ID );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + assignmentDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, teacherID );
        headers.put( Constants.ORGID_SM_HEADER, orgID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = AssignmentAPIConstants.GET_GROUP_ASSIGNMENT_SETTINGS_API;

        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{courseID}", courseID ).replace( "{groupID}", groupID );

        return RestHttpClientUtil.GET( envUrl, endPoint, headers, params );
    }

    /**
     * Get response for the update group assignment Setting
     *
     * @param envUrl
     * @param headers
     * @param updateGroupAssignmentSettings
     * @param courseType
     * @param applyToUsersFlag
     * 
     * @return
     */
    public HashMap<String, String> updateGroupAssignmentSetting( String envUrl, HashMap<String, String> assignmentDetails, HashMap<String, String> updateGroupAssignmentSettings, String courseType ) {
        DataSetupProcessor dataprocess = new DataSetupProcessor();
        try {

            String endpoint = AssignmentAPIConstants.PUT_GROUP_ASSIGNMENT_SETTINGS_API;
            Map<String, String> headers = getHeaders( assignmentDetails );
            Log.message( "Update assignment setting which is assigned to a group" + endpoint );
            endpoint = endpoint.replace( "{orgID}", updateGroupAssignmentSettings.get( CourseAPIConstants.ORG_ID ) );
            endpoint = endpoint.replace( "{teacherID}", updateGroupAssignmentSettings.get( CourseAPIConstants.TEACHER_ID ) );
            endpoint = endpoint.replace( "{courseID}", updateGroupAssignmentSettings.get( CourseAPIConstants.COURSE_ID ) );
            endpoint = endpoint.replace( "{groupID}", updateGroupAssignmentSettings.get( CourseAPIConstants.GROUP_ID ) );

            //Parameters
            HashMap<String, String> params = new HashMap<>();

            Log.message( "Endpoint is : " + envUrl + endpoint );
            String requestBody = null;
            if ( courseType.contains( DataSetupConstants.READING ) ) {
                requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "updateGroupAssignmentSettingReading.json" ), updateGroupAssignmentSettings );
            } else {
                requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "updateGroupAssignmentSettingMath.json" ), updateGroupAssignmentSettings );
            }

            Log.message( "Payload is : " + requestBody );
            Log.message( headers.toString() );

            return RestHttpClientUtil.PUT( envUrl, headers, params, endpoint, requestBody );

        } catch ( Exception e ) {
            Log.message( "Error in updating the assignment setting of the group. Please check 'updateGroupAssignmentSetting' in 'BaseAPITest.java' class file" );
            return null;
        }
    }

    /**
     * Get response for the update group assignment Setting
     *
     * To Group Assignment
     *
     * @param envUrl
     * @param assignmentDetails
     * @param endpoint
     * @return
     * @throws Exception
     * 
     * @return
     */

    public HashMap<String, String> groupAssignmentGroupStudents( String envUrl, HashMap<String, String> assignmentDetails, String endpoint, String reqParam ) throws Exception {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + assignmentDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String requestBody = null;
        String endPoint;
        // Parameters
        HashMap<String, String> params = new HashMap<>();
        if ( reqParam.equalsIgnoreCase( CourseAPIConstants.NULL ) ) {
            params.put( "orgId", orgID );
        } else {
            params.put( "orgId", reqParam );
        }

        if ( endpoint.equalsIgnoreCase( CourseAPIConstants.NULL ) ) {
            endPoint = AssignmentAPIConstants.GROUP_ASSIGNMNETS_GROUP;
            endPoint = endPoint.replace( "{teacherID}", teacherID );
        } else {
            endPoint = endpoint;
        }
        HashMap<String, String> response = RestHttpClientUtil.POST( envUrl, headers, params, endPoint, requestBody );
        Log.message( "Response: " + response.get( "body" ) );
        return response;
    }

    /**
     * Get the assignment by student id
     * 
     * @param smUrl
     * @param token
     * @param studentID
     * @param schoolID
     * @param teacherID
     * 
     * @return response
     * 
     * @throws Exception
     */
    public String getAssignmentByStudent( String smUrl, String token, String studentID, String schoolID, String teacherID ) throws Exception {
        try {
            // headers
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + token );
            headers.put( Constants.USERID_SM_HEADER, teacherID );
            headers.put( Constants.ORGID_SM_HEADER, schoolID );

            HashMap<String, String> params = new HashMap<>();
            params.put( "organization-id", schoolID );
            params.put( "staff-id", teacherID );
            params.put( "student-id", studentID );

            // Input Path Parameters
            String endPoint = Constants.GET_ASSIGNMENT_DETAILS_BY_STUDENTID;

            Response response = RestAssuredAPIUtil.GET( smUrl, headers, endPoint, params );
            return response.getBody().asString();
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Get the assignment by student id
     * 
     * @param smUrl
     * @param token
     * @param assignmentDetails
     * @param studentId
     * @param subjectType
     * @return
     * @throws Exception
     */
    public String getLastSessionSkillTestedByStudent( String smUrl, String token, HashMap<String, String> assignmentDetails, String studentID, String subjectType ) throws Exception {
        try {

            // InputParams
            HashMap<String, String> params = new HashMap<>();
            DataSetupProcessor dataprocess = new DataSetupProcessor();

            // headers
            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + token );

            headers.put( Constants.USERID_SM_HEADER, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) );
            headers.put( Constants.ORGID_SM_HEADER, assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) );

            String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
            String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
            String assignmentUserID = assignmentDetails.get( AssignmentAPIConstants.ASSIGNMENT_USER_ID );

            // request body
            HashMap<String, String> requestBody = new HashMap<>();
            requestBody.put( Constants.ASSIGNMENT_USER_ID, assignmentUserID );
            if ( subjectType.equals( Constants.MATH ) ) {
                requestBody.put( Constants.SUBJECT_ID, "1" );
            } else {
                requestBody.put( Constants.SUBJECT_ID, "2" );
            }

            String requestPayLoad = dataprocess.generateRequestBody( Constants.LastSessionSkillTested.SKILLTESTED_BODY, requestBody );

            // end point
            String endPoint = Constants.LastSessionSkillTested.SKILL_TESTED_ENDPOINT;
            endPoint = endPoint.replace( Constants.ORG_ID, orgID );
            endPoint = endPoint.replace( Constants.STAFF_ID, teacherID );
            endPoint = endPoint.replace( Constants.ASSIGNMENT_ID_VALUE, assignmentUserID );
            endPoint = endPoint.replace( Constants.STUDENT_IDS_VALUE, studentID );

            //getting data from API
            HashMap<String, String> response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestPayLoad );
            return response.get( Constants.REPORT_BODY );
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

    public Response skillLevel( String smUrl, HashMap<String, String> headers ) throws Exception {
        String endpoint = AssignmentAPIConstants.ASSIGNMENT_SKILL_LEVEL;
        HashMap<String, String> pathParamsList = new HashMap<>();
        Response response = RestAssuredAPIUtil.GET( smUrl, headers, endpoint, pathParamsList );
        return response;
    }

    public Map<String, String> UpdateMathExitData( String url, HashMap<String, String> header, HashMap<String, String> studentDetails ) throws Exception {
        String payload = null;
        String endPoint = AssignmentAPIConstants.UPDATE_MATH_EXIT_DATA;
        endPoint = endPoint.replace( Constants.ASSIGNMENT_USER_ID_VALUE, studentDetails.get( Constants.ASSIGNMENT_USER_ID ) );
        Log.message( "endpoint is : " + endPoint );
        payload = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "updateMathExitData.json" );
        payload = payload.replace( "auId", studentDetails.get( Constants.ASSIGNMENT_USER_ID ) );
        payload = payload.replace( "FName", studentDetails.get( Constants.FIRSTNAME ) );
        payload = payload.replace( "LName", studentDetails.get( Constants.LASTNAME ) );
        payload = payload.replace( "mathSessionId", studentDetails.get( Constants.SESSION_ID ) );
        Log.message( "Payload is : " + payload );
        return RestHttpClientUtil.PUT( url, header, new HashMap<>(), endPoint, payload );
    }

}
