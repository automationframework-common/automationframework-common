package com.savvas.sm.ui.pages.login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.utils.SMUtils;

/**
 * This page contains web Element
 * @author madhan.nagarathinam
 *
 */

public class EasyBridgeDashBoardPage extends LoadableComponent<EasyBridgeDashBoardPage> {
	 public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

	    private final WebDriver driver;
	    boolean isPageLoaded;
		
	    
	    @FindBy(css = "div#header-logo")
	    WebElement easyBridgeTxt;
	    
	    @FindBy(css = ".menu-tab-drop-down-div button.learning-systems-tab")
	    WebElement learningServices;
	    
	    @FindBy(css = "ul.dropdown-menu a[data-e2e-id='tab-learning-systems-dropDown-successmaker']")//ul.dropdown-menu li>a:contains('SuccessMaker')
	    WebElement successMakerNavBar;
	    
	    
	    @FindBy(css = "#header-link-bar a.sign-out-link")
	    WebElement logOutBtn;
	    
	    /**
	     * constructor of the class
	     * 
	     * @param driver
	     */
	    public EasyBridgeDashBoardPage( WebDriver driver ) {

	        this.driver = driver;
	        PageFactory.initElements( driver, this );
	    }
	    
	    
	    @Override
		protected void load() {
	        isPageLoaded = true;

		}
		@Override
		protected void isLoaded() throws Error {
			  if ( !isPageLoaded ) {
		            Assert.fail();
			  }
			  try {
		            SMUtils.waitForSpinnertoDisapper( driver, 60 );
		        } catch ( InterruptedException e ) {
		            Log.message( "Issue in Spinner Loading" );
		        }
		        if ( SMUtils.waitForElement( driver, easyBridgeTxt ) ) {

		            Log.message( "EasyBridge page loaded successfully." );
		        } else {
		            Log.fail( "EasyBridge page did not load." );
		        }

		}
		
		
		//Method for Clicking Learning Services Nav bar
		public void navigateTolearningServices() {
			SMUtils.waitForElement(driver, learningServices);
			//Clicking logout Btn
			SMUtils.clickJS(driver, learningServices);
			Log.message("Clicked on LearninnServices Nav Button!");
		}
		
		
		//Method for Clicking successMaker under Learning Services
		public void navigateToSuccessMakerNavBar() {
			SMUtils.waitForElement(driver, successMakerNavBar);
			//Clicking logout Btn
			SMUtils.clickJS(driver, successMakerNavBar);
			Log.message("Clicked SuccessMaker Button!");
		}
		
		
		//Method for clicking Logout Button
		public void logout() {
			SMUtils.waitForElement(driver, logOutBtn);
			//Clicking logout Btn
			SMUtils.clickJS(driver, logOutBtn);
			Log.message("Logged out from EasyBridge");
		}
		
}
