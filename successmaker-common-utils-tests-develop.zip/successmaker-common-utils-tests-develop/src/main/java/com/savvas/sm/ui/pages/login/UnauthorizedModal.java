package com.savvas.sm.ui.pages.login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.ui.constants.LoginConstants;

/**
 * Check the user(teacher and student) log into unauthorized ThreeSIxiyID mapped
 * with other district
 * 
 * @author aravindan.sivanandan
 *
 */

public class UnauthorizedModal extends LoadableComponent<UnauthorizedModal> {

	public String UNAUTHORIZED = "Unauthorized";
	public String BODYCONTENT = "You do not have access to view this page with the credentials provided. Please try again.";
	
    private final WebDriver driver;
    boolean isPageLoaded;

    @FindBy ( css = "#header-content" )
    WebElement unauthorized;

    @FindBy ( css = "#body-content" )
    WebElement bodycontent;

    @FindBy ( css = "button.button" )
    WebElement okbutton;

    @FindBy ( css = "div.modal-content" )
    WebElement unauthorizedwindowpopup;

    public UnauthorizedModal( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
    }

    @Override
    protected void isLoaded() {

        if ( !isPageLoaded ) {
            Assert.fail();
        }
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }

        if ( SMUtils.waitForElement( driver, unauthorizedwindowpopup, 30 ) ) {
            Log.message( "SM Teacher home page loaded successfully." );
        } else {
            Log.fail( "SM Teacher home page did not load." );
        }
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, unauthorizedwindowpopup );
    }

    /**
     * To Verify the header and description for unauthorized popup
     * 
     * @return
     */
    public Boolean getUnauthorizedText() {
        SMUtils.waitForElement( driver, unauthorized );
        return unauthorized.getText().trim().equalsIgnoreCase( UNAUTHORIZED ) && bodycontent.getText().trim().equalsIgnoreCase( BODYCONTENT );
    }

    /**
     * To Verify for displaying unauthorized popup window
     * 
     * @return
     */
    public Boolean isUnauthorizedWindowPopupDisplayed() {
        SMUtils.waitForElement( driver, unauthorizedwindowpopup );
        return unauthorizedwindowpopup.isDisplayed();
    }

}
