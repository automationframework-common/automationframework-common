package com.savvas.sm.utils;

import com.learningservices.utils.DataUtils;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.StopWatch;
import com.opencsv.CSVReader;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.data.sme7.TestDataConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.DBQueryFor;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class SMUtils {

    public static int maxElementWait = 3;
    public static By pageBody = By.cssSelector("body");
    public static String MOUSE_HOVER_JS = "var evObj = document.createEvent('MouseEvents');" + "evObj.initMouseEvent(\"mouseover\",true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);" + "arguments[0].dispatchEvent(evObj);";
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    public static String MOUSE_OUT_JS = "$(arguments[0]).mouseout();";
    public static String HREF_ATTRIBUTE = "href";
    public static String INNERTEXT_ATTRIBUTE = "innerText";
    public static String TITLE_ATTRIBUTE = "title";
    public static String SCROLL_TO_MIDDLE = "middle";
    public static String SCROLL_TO_BOTTOM = "bottom";
    public static String spinnerElement = "loader cel-icon.icon-medium";
    public static String ARIA_PRESSED = "aria-pressed";
    public static String toastElementCSS = "span.alert__messageBody.sc-cel-toast";
    public static String PLACEHOLDER = "placeholder";
    public static String FONT_FAMILY = "font-family";

    /**
     * Nap using Thread.sleep in seconds
     *
     * @param seconds
     */
    public static void nap(double seconds) {
        try {
            Thread.sleep(Math.round(seconds * 1000));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Log method to print test case title in bold
     *
     * @param tcDesc
     */
    public static void logDescriptionTC(String tcDesc) {
        Log.message(Constants.HTML_TC_DESC_BEGIN + tcDesc + Constants.HTML_TC_DESC_CLOSE);
    }

    /**
     * To wait for the specific element on the page
     *
     * @param driver  -
     * @param element - webelement to wait for to appear
     * @return boolean - return true if element is present else return false
     */
    public static boolean waitForElement(WebDriver driver, WebElement element) {
        return waitForElement(driver, element, maxElementWait);
    }

    /**
     * To wait for the specific locator on the page
     *
     * @param driver  -
     * @param element - webElement to wait for to appear
     * @param maxWait - how long to wait for
     * @return boolean - return true if element is visible else return false
     */
    public static boolean waitForLocator(WebDriver driver, By locator, int maxWait) {
        boolean statusOfElementToBeReturned = false;
        long startTime = StopWatch.startTime();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(maxWait));
        try {
            wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(locator));
            statusOfElementToBeReturned = true;

        } catch (Exception ex) {
            statusOfElementToBeReturned = false;
            Log.event("Unable to find a element after " + StopWatch.elapsedTime(startTime) + " sec ==> " + locator);
        }
        return statusOfElementToBeReturned;
    }

    /**
     * To wait for the specific locator on the page
     *
     * @param driver  -
     * @param element - webElement to wait for to present in the current page
     * @param maxWait - how long to wait for
     * @return boolean - return true if element is present else return false
     */
    public static boolean waitForLocatorToPresent(WebDriver driver, By locator, int maxWait) {
        boolean statusOfElementToBeReturned = false;
        long startTime = StopWatch.startTime();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(maxWait));
        try {
            wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(locator));
            statusOfElementToBeReturned = true;
        } catch (Exception ex) {
            statusOfElementToBeReturned = false;
            Log.event("Unable to find a element after " + StopWatch.elapsedTime(startTime) + " sec ==> " + locator);
        }
        return statusOfElementToBeReturned;
    }

    /**
     * To wait for the specific element on the page
     *
     * @param driver  -
     * @param element - webelement to wait for to appear
     * @param maxWait - how long to wait for
     * @return boolean - return true if element is present else return false
     */
    public static boolean waitForElement(WebDriver driver, WebElement element, int maxWait) {
        boolean statusOfElementToBeReturned = false;
        long startTime = StopWatch.startTime();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(maxWait));
        try {
            WebElement waitElement = wait.until(ExpectedConditions.visibilityOf(element));
            if (waitElement.isDisplayed() && waitElement.isEnabled()) {
                statusOfElementToBeReturned = true;
                // Log.event("Element is displayed:: " + element.toString());
            }
        } catch (Exception ex) {

            // #### Workaround for safari driver issue. Failed to check
            // visibility/isDisplayed ####//
            if ((configProperty.getProperty("BrowserPlatformToRun").toLowerCase().matches(".*safari.*"))) {
                try {
                    if (element.isEnabled() && checkElementVisibilityUsingOffsetWidthHeight(driver, element)) {
                        statusOfElementToBeReturned = true;
                        Log.event("Element is displayed:: " + element.toString());
                    }
                } catch (Exception e) {
                    statusOfElementToBeReturned = false;
                    Log.event("Unable to find a element after " + StopWatch.elapsedTime(startTime) + " sec ==> " + element.toString());
                }
            } else {
                statusOfElementToBeReturned = false;
                Log.event("Unable to find a element after " + StopWatch.elapsedTime(startTime) + " sec ==> " + element.toString());
            }
            // #### Will be removed once the issue is fixed in Safari driver ####//
        }
        return statusOfElementToBeReturned;
    }

    /**
     * To wait for the specific element on the page
     *
     * @param driver  -
     * @param element - webelement to wait for to appear
     * @param maxWait - how long to wait for
     * @return boolean - return true if element is present else return false
     */
    public static boolean fluentWaitForElement(WebDriver driver, WebElement element, int... maxWait) {
        int waitTime = 0;
        if (maxWait.length == 0)
            waitTime = 30;
        else
            waitTime = maxWait[0];
        boolean statusOfElementToBeReturned = false;
        long startTime = StopWatch.startTime();

        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(waitTime)).pollingEvery(Duration.ofMillis(250)).ignoring(NoSuchElementException.class);

        try {
            wait.until(ExpectedConditions.visibilityOf(element));
            statusOfElementToBeReturned = true;
        } catch (Exception ex) {

            // #### Workaround for safari driver issue. Failed to check
            // visibility/isDisplayed ####//
            if ((configProperty.getProperty("BrowserPlatformToRun").toLowerCase().matches(".*safari.*"))) {
                try {
                    if (element.isEnabled() && checkElementVisibilityUsingOffsetWidthHeight(driver, element)) {
                        statusOfElementToBeReturned = true;
                        Log.event("Element is displayed:: " + element.toString());
                    }
                } catch (Exception e) {
                    statusOfElementToBeReturned = false;
                    Log.event("Unable to find a element after " + StopWatch.elapsedTime(startTime) + " sec ==> " + element.toString());
                }
            } else {
                statusOfElementToBeReturned = false;
                Log.event("Unable to find a element after " + StopWatch.elapsedTime(startTime) + " sec ==> " + element.toString());
            }
        }
        return statusOfElementToBeReturned;
    }

    /**
     * To check element visibility using offset height and width
     *
     * @param driver
     * @param element
     * @return boolean
     */
    public static boolean checkElementVisibilityUsingOffsetWidthHeight(WebDriver driver, WebElement element) {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        int elementOffsetWidth = Integer.parseInt(jse.executeScript("return arguments[0].offsetWidth;", element).toString());
        int elementOffsetHeight = Integer.parseInt(jse.executeScript("return arguments[0].offsetHeight;", element).toString());
        return elementOffsetWidth > 0 && elementOffsetHeight > 0;
    }

    /**
     * Wait for element to be clickable
     *
     * @param element
     * @param driver
     */
    public static void waitForElementToBeClickable(WebElement element, WebDriver driver) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    /**
     * To get matching text element from List of web elements
     *
     * @param elements    -
     * @param contenttext - text to match
     * @return elementToBeReturned as WebElement
     * @throws Exception -
     */
    public static WebElement getMachingTextElementFromList(List<WebElement> elements, String contenttext) throws Exception {
        WebElement elementToBeReturned = null;
        boolean found = false;

        if (elements.size() > 0) {
            for (WebElement element : elements) {
                if (element.getText().trim().replaceAll("\\s+", " ").equalsIgnoreCase(contenttext)) {
                    elementToBeReturned = element;
                    found = true;
                    break;
                }
            }
            if (!found) {
                throw new Exception("Didn't find the correct text(" + contenttext + ")..! on the page");
            }
        } else {
            throw new Exception("Unable to find list element...!");
        }
        return elementToBeReturned;
    }

    /**
     * Verifying the size of a list of WebElements
     *
     * @param listToVerify - list of WebElements to verify the size of
     * @param sizeToVerify - expected size
     * @return true if the size of the list to verify equals the expected value
     */
    public static boolean verifySizeOfList(List<WebElement> listToVerify, int sizeToVerify) {
        boolean status = false;
        if ((listToVerify.size() == sizeToVerify)) {
            status = true;
        }
        return status;
    }

    /**
     * To get the text of a WebElement
     *
     * @param element - the input field you need the value/text of
     * @param driver  -
     * @return text of the input's value
     */
    public static String getTextOfWebElement(WebElement element, WebDriver driver) {
        String sDataToBeReturned = null;
        if (waitForElement(driver, element)) {
            sDataToBeReturned = element.getText().trim().replaceAll("\\s+", " ");
        }
        Log.event("Text fetched from UI: " + sDataToBeReturned);
        return sDataToBeReturned;
    }

    /**
     * To get the attribute of a WebElement
     *
     * @param element - the input field you need the value/text of
     * @param driver  -
     * @return text of the input's value
     */
    public static String getAttributeOfWebElement(WebElement element, WebDriver driver, String attribute) {
        String sDataToBeReturned = null;

        sDataToBeReturned = element.getAttribute(attribute).trim().replaceAll("\\s+", " ");

        Log.event("Attribute fetched from UI: " + sDataToBeReturned);
        return sDataToBeReturned;
    }

    /**
     * To get the text of system date in format of MMDDYY
     *
     * @param driver -
     * @return date in format MMDDYY
     * @throws Exception - for dateformat.parse
     */
    public static String getDateTextFromSystemDate(WebDriver driver) throws Exception {
        String systemDate = (String) ((JavascriptExecutor) driver).executeScript("var d=new Date();return d.getMonth()+1 + '/' + d.getDate() + '/' + d.getFullYear();");
        DateFormat dateformat = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
        Date date = dateformat.parse(systemDate);
        return dateformat.format(date);
    }

    /**
     * Open a new tab on the browser
     *
     * @param driver
     */
    public static void openNewTab(WebDriver driver) {
        if ((configProperty.getProperty("BrowserPlatformToRun").equalsIgnoreCase("edge"))) {
            driver.findElement(pageBody).sendKeys(Keys.CONTROL + "t");
        }
        ((JavascriptExecutor) driver).executeScript("window.open('about:blank','_blank');");
    }

    /**
     * Open a new tab on the browser
     *
     * @param driver
     */
    public static void openNewTabAndSwitchToNewSMApp(WebDriver driver, String smNewUrl) {
        if ((configProperty.getProperty("BrowserPlatformToRun").toLowerCase().equalsIgnoreCase("edge"))) {
            driver.findElement(pageBody).sendKeys(Keys.CONTROL + "t");
        }
        ((JavascriptExecutor) driver).executeScript("window.open('about:blank','_blank');");

        String winHandle = driver.getWindowHandle();

        Set<String> handles = driver.getWindowHandles();

        for (String index : handles) {
            if (!index.equals(winHandle)) {
                driver.switchTo().window(index);
                break;
            }
        }

        driver.get(smNewUrl);
        SMUtils.nap(1);
    }

    /**
     * Function to get all text for given webelement list
     *
     * @param elements
     * @return text as List for the given elements
     */
    public static List<String> getAllTextFromWebElementList(List<WebElement> elements) {
        List<String> sDataToBeReturned = new ArrayList<String>();
        if (elements.size() > 0) {
            for (WebElement element : elements) {
                sDataToBeReturned.add(element.getText().trim().replaceAll("\\s+", " "));
            }
        } else {
            Log.event("Didn't find the text on the page with given list of webelements");
        }
        return sDataToBeReturned;
    }

    /**
     * Verify contents of a WebElement equals a passed in string variable
     *
     * @param textToVerify    - expected text
     * @param elementToVerify - element to verify the text of
     * @return true if text on screen matches passed variable contents
     */
    public static boolean verifyWebElementTextEquals(WebElement elementToVerify, String textToVerify) {
        boolean status = false;
        String actualText = elementToVerify.getText().trim().replaceAll("\\s+", " ");
        Log.event("Actual Text : " + actualText);
        if (actualText.equals(textToVerify)) {
            status = true;
        }
        return status;
    }

    /**
     * Verify contents of a WebElement equals ignoring case a passed in string
     * variable
     *
     * @param textToVerify    - expected text
     * @param elementToVerify - element to verify the text of
     * @return true if text on screen equals ignoring case passed variable
     * contents
     */
    public static boolean verifyWebElementTextEqualsIgnoreCase(WebElement elementToVerify, String textToVerify) {
        boolean status = false;
        if (elementToVerify.getText().trim().replaceAll("\\s+", " ").equalsIgnoreCase(textToVerify.trim())) {
            status = true;
        }
        return status;
    }

    /**
     * Verify contents of a WebElement contains a passed in string variable
     *
     * @param textToVerify    - expected text
     * @param elementToVerify - element to verify the text of
     * @return true if text on screen matches passed variable contents
     */
    public static boolean verifyWebElementTextContains(WebElement elementToVerify, String textToVerify) {
        boolean status = false;
        String UITextToVerify = elementToVerify.getText();
        Log.event("Text fetched from UI: " + UITextToVerify);
        Log.event("Text to compare: " + textToVerify);
        if (UITextToVerify.trim().replaceAll("\\s+", " ").contains(textToVerify.trim())) {
            status = true;
        }
        return status;
    }

    /**
     * To get the value of an input field.
     *
     * @param element - the input field you need the value/text of
     * @param driver  -
     * @return text of the input's value
     */
    public static String getValueOfInputField(WebElement element, WebDriver driver) {
        String sDataToBeReturned = null;
        if (waitForElement(driver, element)) {
            sDataToBeReturned = element.getAttribute("value");
        }
        return sDataToBeReturned;
    }

    /**
     * To keep the application idle for required minutes without sauce session
     * timeout
     *
     * @param minutes - Integer
     * @param driver  - WebDriver
     * @throws InterruptedException
     */
    public static void keepSessionIdle(int minutes, WebDriver driver) throws InterruptedException {
        Log.event("Session Idle time for " + minutes + " minutes starts");
        long startTime = StopWatch.startTime();
        while (StopWatch.elapsedTime(startTime) <= (minutes * 60)) {
            driver.getTitle();
            long intervalTime = StopWatch.elapsedTime(startTime);
            long interval = intervalTime % 60;
            if (interval == 0) {
                Log.event("Keeping Idle : " + (intervalTime / (60)) + " minutes");
                Thread.sleep(1000);
                continue;
            }
        }
        Log.message("Session Idle time for " + (StopWatch.elapsedTime(startTime) / (60)) + " minutes completed");
    }

    /**
     * Get the options in a select tag
     *
     * @param dropdown - which select dropdown to expand
     * @return list of the options in the select
     */
    public static ArrayList<Object> getSelectOptions(WebElement dropdown) {
        Select selectList = new Select(dropdown);
        List<WebElement> optionsList = selectList.getOptions();
        ArrayList<Object> optionsText = new ArrayList<Object>();
        for (WebElement option : optionsList) {
            optionsText.add(option.getText());
        }
        return optionsText;
    }

    /**
     * Click on an option in a select tag
     *
     * @param dropdown       - which select dropdown to expand
     * @param optionToSelect - text of the option to select
     */
    public static void selectOption(WebElement dropdown, String optionToSelect) {
        Select selectList = new Select(dropdown);
        selectList.selectByVisibleText(optionToSelect);
    }

    /**
     * Verify the css property for an element
     *
     * @param element       - WebElement for which to verify the css property
     * @param cssProperty   - the css property name to verify
     * @param expectedValue - the expected css value of the element
     * @return boolean
     */
    public static boolean verifyCssPropertyForElement(WebElement element, String cssProperty, String expectedValue) {
        boolean result = false;
        String actualClassProperty = element.getCssValue(cssProperty);
        if (actualClassProperty.contains(expectedValue)) {
            result = true;
        }
        return result;
    }

    /**
     * Check color of given element's css value "background"
     *
     * @param elementToCheck - WebElement that we are checking
     * @param desiredColor   - hex value of a color
     * @return true if the desired color matches actual color
     * @throws Exception for NoSuchElementException
     */
    public static boolean checkCssValueBackground(WebElement elementToCheck, String desiredColor) throws Exception {
        boolean flag = false;
        try {
            String color = StringUtils.substringBetween(elementToCheck.getCssValue("background"), "(", ")");
            String actualColor = convertColorFromRgbaToHex(color);
            flag = actualColor.equalsIgnoreCase(desiredColor);
        } catch (NoSuchElementException ex) {
            Log.exception(ex);
        }
        return flag;
    }

    public static String convertColorFromRgbaToHex(String color) {
        String[] hexValue = color.replaceAll("[^,0-9]", "").split(",");

        int hexValue1 = Integer.parseInt(hexValue[0]);
        hexValue[1] = hexValue[1].trim();
        int hexValue2 = Integer.parseInt(hexValue[1]);
        hexValue[2] = hexValue[2].trim();
        int hexValue3 = Integer.parseInt(hexValue[2]);

        String actualColor = String.format("#%02x%02x%02x", hexValue1, hexValue2, hexValue3);

        return actualColor;
    }

    /**
     * To check background color of given element
     *
     * @param elementToCheck - WebElement that we are checking
     * @param desiredColor   - hex value of a color
     * @return true if the desired color matches actual color
     * @throws Exception -
     */
    public static boolean checkBackgroundColor(WebElement elementToCheck, String desiredColor) throws Exception {
        boolean flag = false;
        try {
            String color = elementToCheck.getCssValue("background-color");
            String actualColor = convertColorFromRgbaToHex(color);
            Log.event("Actual background color : " + actualColor);
            flag = actualColor.equalsIgnoreCase(desiredColor);
        } catch (NoSuchElementException ex) {
            Log.exception(ex);
        }
        return flag;
    }

    /**
     * To get background color of given element
     *
     * @param element - target web element
     * @return the background color of the element
     */
    public static String getBackgroundColor(WebElement element) throws Exception {
        String color = "";
        try {
            color = element.getCssValue("background-color");
            color = convertColorFromRgbaToHex(color);
        } catch (NoSuchElementException ex) {
            Log.exception(ex);
        }
        return color;
    }

    /**
     * To check color of given element
     *
     * @param elementToCheck - WebElement that we are checking
     * @param desiredColor   - hex value of a color
     * @return true if the desired color matches actual color
     * @throws Exception -
     */
    public static boolean checkColor(WebElement elementToCheck, String desiredColor) throws Exception {
        boolean flag = false;
        try {
            String color = elementToCheck.getCssValue("color");
            String actualColor = convertColorFromRgbaToHex(color);
            Log.event("Actual text color : " + actualColor);
            flag = actualColor.equalsIgnoreCase(desiredColor);
        } catch (NoSuchElementException ex) {
            Log.exception(ex);
        }
        return flag;
    }

    /**
     * To perform mouse hover on an element using javascript
     *
     * @param driver
     * @param element
     */
    public static void moveToElementJS(WebDriver driver, WebElement element) {
        ((JavascriptExecutor) driver).executeScript(MOUSE_HOVER_JS, element);
    }

    /**
     * Press escape key
     *
     * @param driver
     */
    public static void sendEscapeKey(WebDriver driver) {
        driver.findElement(pageBody).sendKeys(Keys.ESCAPE);
        Log.event("Clicked escape key");
    }

    /**
     * To perform mouse hover on an element using selenium api
     *
     * @param driver
     * @param element
     */
    public static void moveToElementSelenium(WebDriver driver, WebElement element) {
        Actions action = new Actions(driver);
        action.moveToElement(element).build().perform();
    }

    /**
     * To perform mouse out from an element using java script
     *
     * @param driver
     * @param element
     */
    public static void moveOutFromElementJS(WebDriver driver, WebElement element) {
        ((JavascriptExecutor) driver).executeScript(MOUSE_OUT_JS, element);
        Log.message("Mouse Out from Element Action - Completed!");
    }

    public static void scrollIntoView(final WebDriver driver, WebElement element) {
        try {
            String scrollElementIntoMiddle = "var viewPortHeight = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);" + "var elementTop = arguments[0].getBoundingClientRect().top;"
                    + "window.scrollBy(0, elementTop-(viewPortHeight/2));";
            ((JavascriptExecutor) driver).executeScript(scrollElementIntoMiddle, element);
            Thread.sleep(250);
        } catch (Exception ex) {
            Log.event("Moved to element..");
        }
    }

    /**
     * To Scroll in the page and dropdown using the Java Script Executor
     *
     * @param driver
     * @param element
     */

    public static void scrollDownIntoViewElement(WebDriver driver, WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element);
    }

    /**
     * To scroll to bottom of page
     *
     * @param driver  -
     * @param element - the element to scroll to
     */
    public static void scrollToBottomOfPage(final WebDriver driver, int lastPage) {

        String script = "document.querySelector('.doc-preview').scrollTo(0, document.querySelector('div[class=\"doc-preview-page ng-scope\"] img').height*arguments[0]);";
        ((JavascriptExecutor) driver).executeScript(script, lastPage);
        script = "document.querySelector('.doc-preview').scrollTo(0, document.querySelector('div[class=\"doc-preview-page ng-scope\"] img').height*arguments[0]);";
    }

    /**
     * To scroll to bottom of page
     */
    public static void scrollToBottomOfPage(WebDriver driver) {
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, 250)");
        driver.findElement(By.tagName("body")).sendKeys(Keys.CONTROL, Keys.END);
    }

    /**
     * To scroll to bottom of page
     */
    public static void scrollToTopOfPage(WebDriver driver) {
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, 250)");
        driver.findElement(By.tagName("body")).sendKeys(Keys.CONTROL, Keys.HOME);
    }

    /**
     * Verify if a particular element is in the browser viewport
     *
     * @param driver  -
     * @param element - the element to verify is in viewport
     * @return true if the element is in the viewport
     */
    public static boolean isInViewport(final WebDriver driver, WebElement element) {
        String browser = configProperty.getProperty("BrowserPlatformToRun");

        JavascriptExecutor js = (JavascriptExecutor) driver;
        // Some browsers return long, others double, so casting to String and
        // then comparing the double value of the string
        double viewportWidth = Double.valueOf(js.executeScript("return document.documentElement.clientWidth;").toString());
        double viewportHeight = Double.valueOf(js.executeScript("return document.documentElement.clientHeight;").toString());
        double commentTop = Double.valueOf(js.executeScript("return arguments[0].getBoundingClientRect().top;", element).toString());
        double commentLeft = Double.valueOf(js.executeScript("return arguments[0].getBoundingClientRect().left;", element).toString());
        return commentLeft < viewportWidth && commentTop < viewportHeight;
    }

    /**
     * This function is to validate a error message on alert
     *
     * @param driver           -
     * @param errMsg           - error message text to verify
     * @param alertElement
     * @param alertCloseButton
     * @return true if error message as expected else return false
     * @throws Exception -
     */
    public static boolean validateErrorMsg(WebDriver driver, WebElement alertElement, WebElement alertCloseButton, String errMsg) throws Exception {
        boolean status = false;
        final long startTime = StopWatch.startTime();
        try {
            if (waitForElement(driver, alertElement)) {
                if (alertElement.getText().replaceAll("\\s+", " ").contains(errMsg)) {
                    alertCloseButton.click();
                    status = true;
                    Log.event("Error message is displayed:: " + errMsg, StopWatch.elapsedTime(startTime));
                } else {
                    status = false;
                }
            }
        } catch (Exception ex) {
            throw new Exception("Unable to find alert Message", ex);
        }
        return status;
    }

    /**
     * To verify the contents of a tool tip
     *
     * @param tooltipToCheck   - the WebElement of the tool tip
     * @param expectedContents - the String contents of what should appear
     * @param driver           -
     * @return boolean - return true if tool tip message is equivalent to
     * expectedContents, else return false
     * @throws InterruptedException -
     */

    public static boolean verifyToolTipContents(WebElement tooltipToCheck, String expectedContents, WebDriver driver) throws InterruptedException {
        boolean status = false;
        String actualContents = null;

        if ((configProperty.getProperty("BrowserPlatformToRun").matches(".*(safari|firefox).*"))) {
            String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript(mouseOverScript, tooltipToCheck);

        } else {
            Actions ToolTip = new Actions(driver);
            ToolTip.moveToElement(tooltipToCheck).perform();
        }
        Thread.sleep(2000);
        actualContents = tooltipToCheck.getAttribute("popover").trim();
        Log.message("Mouseover tool tip message:: '" + actualContents + "'");
        status = expectedContents.equalsIgnoreCase(actualContents) ? true : false;
        return status;
    }

    /**
     * Verify if the page has an element or not
     *
     * @param by     - by obj
     * @param driver - WebDriver
     * @return true - if the element does not exist
     */
    public static boolean verifyElementDoesNotExist(By by, WebDriver driver) {
        Log.event("Verifying that element does not exist");
        boolean flag = false;
        flag = driver.findElements(by).size() == 0;
        return flag;

    }

    /**
     * Closes current window & switches to the window handle passed
     *
     * @param driver
     * @param windowHandle
     */
    public static void closeCurrentWindowAndSwitchtoWindow(WebDriver driver, String windowHandle) {
        // Log.event("Closing current window");
        driver.close();
        driver.switchTo().window(windowHandle);
    }

    /**
     * Closes given window & switches to the other window handle passed
     *
     * @param driver
     * @param windowHandleToClose
     * @param windowHandleToSwitchTo
     */
    public static void closeWindowAndSwitchtoWindow(WebDriver driver, String windowHandleToClose, String windowHandleToSwitchTo) {
        // Log.event("Closing current window");
        driver.switchTo().window(windowHandleToClose);
        driver.close();
        driver.switchTo().window(windowHandleToSwitchTo);
    }

    /**
     * Closes all windows other than that is passed
     *
     * @param driver
     * @param windowHandleToRemainOpen - window to remain open
     */
    public static void closeOtherWindows(WebDriver driver, String windowHandleToRemainOpen) {

        Set<String> allWindows = driver.getWindowHandles();
        allWindows.remove(windowHandleToRemainOpen);
        if (!allWindows.isEmpty()) {
            for (String window : allWindows) {
                driver.switchTo().window(window);
                driver.close();
            }
        }
        driver.switchTo().window(windowHandleToRemainOpen);

    }

    /**
     * To get/pick the credentials depends on platform and browsers, depends on
     * that picking data from excel using the test case id and sheet name
     *
     * @param testcaseId -
     * @param sheetName  - Smoke, Regression, Integration
     * @param driver     -
     * @return the test data as a HashMap
     * @throws IOException
     */
    public static HashMap<String, String> getTestData(String testcaseId, String sheetName) throws IOException {
        HashMap<String, String> dataToBeReturned = null;

        String workbookName = "SMAutoTestData.xls";
        String sheetToFetch = sheetName.split("\\.")[(sheetName.split("\\.").length) - 1];

        String filePath = "/testdata/" + workbookName;

        dataToBeReturned = DataUtils.getTestData(filePath, workbookName, sheetToFetch, testcaseId);

        return dataToBeReturned;

    }

    /***
     * Gets the data from row for the given column
     *
     * @param testData
     * @param columnName
     * @return dataOfTheCell as String
     */
    public static String getColumnData(HashMap<String, String> testData, String columnName) {
        String dataToReturn = "";
        dataToReturn = testData.get(columnName).toString().trim();
        return dataToReturn;
    }

    /**
     * This method is used to fetch the JSON object from the response
     *
     * @param response, reqBlock
     * @return String
     */
    public static JSONObject convertResponseAsJsonObj(String response, String paramName, String keyName, String keyValue, String exclusionParam) throws Exception {

        // Initializes the return variable
        JSONObject jo = null;

        try {

            JSONObject jsonObj = new JSONObject(response);

            if (jsonObj.has(exclusionParam))
                jsonObj.remove(exclusionParam);

            try {
                jsonObj.getJSONArray(paramName);
            } catch (JSONException jse) {
                return jsonObj.getJSONObject(paramName);
            }

            JSONArray jsonArr = (JSONArray) jsonObj.get(paramName);
            ;

            for (int elements = 0; elements < jsonArr.length(); elements++) {

                jo = jsonArr.getJSONObject(elements);

                if (keyName != null && jo.get(keyName).toString().equals(keyValue))
                    return jo;

            }

        } catch (Exception e) {
            throw new Error(e);
        }

        return jo;

    } // End convertResponseAsStr

    /**
     * This method is used to fetch the current date and time
     *
     * @return current date and time
     */
    public static String getCurrentDateAndTime() {

        // Initializes the variable
        String currentDateAndTime = null;

        try {

            Date date = new Date();
            long time = date.getTime();

            Timestamp ts = new Timestamp(time);

            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone("US/Arizona"));

            currentDateAndTime = simpleDateFormat.format(ts);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return currentDateAndTime;

    } // End getCurrentDateAndTime

    /**
     * This method is used to verify the current date and time falls between the
     * specified range
     *
     * @param startDate, endDate and the currDate
     * @return boolean value
     */
    public static boolean verifyDateFallsInRange(String startDate, String endDate, String currDate) {

        // Initializes the variable
        boolean isDateFalls = false;

        try {

            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            Date currDateTime = simpleDateFormat.parse(currDate);
            Date startDateTime = simpleDateFormat.parse(startDate);
            Date endDateTime = simpleDateFormat.parse(endDate);

            if (currDateTime.after(startDateTime) && currDateTime.before(endDateTime))
                isDateFalls = true;
            else if (currDateTime.equals(startDateTime) || currDateTime.equals(endDateTime))
                isDateFalls = true;

        } catch (ParseException e) {
            e.printStackTrace();
        }

        return isDateFalls;

    } // End verifyDateFallsInRange

    /**
     * This method used to get the key value from json string.
     *
     * @param response
     * @param ArrayValueAndKey
     * @return key value
     */
    public static String getKeyValueFromResponse(String response, String ArrayValueAndKey) {
        String[] json_Array = ArrayValueAndKey.split(",");
        String keyValue = null;
        try {

            if (json_Array.length <= 1) {
                JSONObject jsonObj = new JSONObject(response);
                String JsonArrayValue = jsonObj.get(json_Array[0]).toString();
                return JsonArrayValue;
            } else {
                JSONObject jsonObj = new JSONObject(response);
                String JsonArrayValue = jsonObj.get(json_Array[0]).toString();
                if (JsonArrayValue.contains("[{")) {
                    JsonArrayValue = JsonArrayValue.replace("[{", "{");
                    JsonArrayValue = JsonArrayValue.replace("}]", "}");
                }
                JSONObject jsonObj1 = new JSONObject(JsonArrayValue);
                keyValue = jsonObj1.get(json_Array[1]).toString();
                return keyValue;
            }
        } catch (Exception e) {
            Log.event("Expected Key :" + ArrayValueAndKey + "\n Reponse :" + response);
            e.printStackTrace();
            return keyValue;
        }

    }

    /**
     * Count the word from string
     *
     * @param string
     * @param word
     * @return
     */
    public static int getWordCount(String string, String word) {
        String in = string;
        int count = 0;
        Pattern p = Pattern.compile(word);
        Matcher m = p.matcher(in);
        while (m.find()) {
            count++;
        }
        return count;
    }

    /**
     * Sort the given list
     *
     * @param list
     * @return
     */
    public static List<String> sortList(List<String> list) {
        Collections.sort(list);
        return list;
    }

    /**
     * Sort and reverse the given list
     *
     * @param list
     * @return
     */
    public static List<String> sortAndReverseList(List<String> list) {
        Collections.sort(list, Collections.reverseOrder());
        return list;
    }

    /**
     * Sort the given list(Integer)
     *
     * @param list
     * @return
     */
    public static List<Integer> sortListInteger(List<Integer> list) {
        Collections.sort(list);
        return list;
    }

    /**
     * Sort and reverse the given list(Integer)
     *
     * @param list
     * @return
     */
    public static List<Integer> sortAndReverseListInteger(List<Integer> list) {
        Collections.sort(list, Collections.reverseOrder());
        return list;
    }

    /**
     * Merge two list
     *
     * @param list1
     * @param list2
     * @return
     */
    public static List<String> mergeList(List<String> list1, List<String> list2) {
        List<String> merged = new ArrayList<String>();
        merged.addAll(list1);
        merged.addAll(list2);
        return merged;
    }

    /**
     * This method is used to get the key value from Json array.
     *
     * @param response
     * @param keyName
     * @param arrayIndex
     * @return
     */
    public static String getKeyValueFromJsonArray(String response, String keyName, int arrayIndex) {

        String keyValue = null;
        try {
            JSONObject jsonObj = new JSONObject(response);
            JSONArray ja = jsonObj.getJSONArray("data");
            JSONObject jObj = ja.getJSONObject(arrayIndex - 1);
            keyValue = jObj.get(keyName).toString();

            return keyValue;
        } catch (Exception e) {
            e.printStackTrace();
            return keyValue;
        }

    }

    /**
     * This Method creates the DataDriverObject of Testcases to be executed.If
     * we pass the TestcasePrefix and Starting number and ending number</br>
     * It will create the DataDriverObject with the mentioned testcases.If any
     * test cases to be excluded we needs to pass it in the last argument
     *
     * @param testCasePrefixName
     * @param startingIndex
     * @param endingIndex
     * @param exclusionList      -If none then pass null or blank string
     * @return
     */
    public static String[][] generateTestCasesToBeExecuted(String testCasePrefixName, int startingIndex, int endingIndex, String exclusionList) {
        int numberOfTestCasesToBeDeleted = 0;
        List<String> listOfExlcusion = null;
        String[][] testCaseDetails = null;
        boolean isExclusionDetailsPresent = false;
        if (exclusionList == null || exclusionList.trim().contentEquals("")) {
            isExclusionDetailsPresent = false;
        } else {
            isExclusionDetailsPresent = true;
        }

        if (isExclusionDetailsPresent) {

            String[] exclusionListArray = exclusionList.split(",");
            listOfExlcusion = Arrays.asList(exclusionListArray);
            numberOfTestCasesToBeDeleted = exclusionListArray.length;
        }
        int actualCountOfCaseWithoutExclusion = endingIndex - startingIndex + 1;
        int totalNumberOfTestCases = actualCountOfCaseWithoutExclusion - numberOfTestCasesToBeDeleted;
        if (totalNumberOfTestCases < 0) {
            Log.message("Issue in passing the arguments.Check the ExclusionList matches to the startIndex and endIndex" + exclusionList);
            return null;
        }

        testCaseDetails = new String[totalNumberOfTestCases][1];

        for (int i = 0, j = 0; i < actualCountOfCaseWithoutExclusion; i++) {

            int index = startingIndex + i;

            if (isExclusionDetailsPresent) {
                if (listOfExlcusion.contains(index + "") == false) {
                    if (index < 10) {
                        testCaseDetails[j][0] = testCasePrefixName + "00" + index;
                    } else if (index < 100) {
                        testCaseDetails[j][0] = testCasePrefixName + "0" + index;
                    } else {
                        testCaseDetails[j][0] = testCasePrefixName + index;
                    }
                    j = j + 1;
                }
            } else {
                if (index < 10) {
                    testCaseDetails[i][0] = testCasePrefixName + "00" + index;
                } else if (index < 100) {
                    testCaseDetails[i][0] = testCasePrefixName + "0" + index;
                } else {
                    testCaseDetails[i][0] = testCasePrefixName + index;
                }

            }
        }
        System.out.println("Test Cases to be executed" + Arrays.deepToString(testCaseDetails));
        return testCaseDetails;
    }

    /**
     * This method is used to define path parameters hash map
     *
     * @param endpoint
     * @param pathParamsList - This list should hold path parameters value in
     *                       the order mentioned in endpoint
     * @return
     */
    public static HashMap<String, String> setPathParametersFromEndpoint(String endpoint, List<String> pathParamsList) {
        HashMap<String, String> pathParamsToReturn = new HashMap<>();
        List<String> pathParamsFromEndpoint = new ArrayList<String>();

        try {
            Pattern regex = Pattern.compile("\\{(.*?)\\}");
            Matcher regexMatcher = regex.matcher(endpoint);

            while (regexMatcher.find()) {// Finds Matching Pattern in String
                pathParamsFromEndpoint.add(regexMatcher.group(1));// Fetching Group from String
            }

            for (int i = 0; i < pathParamsFromEndpoint.size(); i++) {
                pathParamsToReturn.put(pathParamsFromEndpoint.get(i), pathParamsList.get(i));
            }
        } catch (Exception e) {
            Log.message("Exception in defining path parameters" + e.getMessage());
        }

        return pathParamsToReturn;
    }

    // --------------------------------------------------------------------------------
    // Section START: Basic data structure methods
    // --------------------------------------------------------------------------------

    /**
     * To compare two array list values,then print unique list value and print
     * missed list value
     *
     * @param expectedElements - expected element list
     * @param actualElements   - actual element list
     * @return statusToBeReturned - returns true if both the lists are equal,
     * else returns false
     */
    public static boolean compareTwoList(List<String> expectedList, List<String> actualList) {
        boolean statusToBeReturned = false;
        List<String> uniqueList = new ArrayList<String>();
        List<String> missedList = new ArrayList<String>();
        for (String item : expectedList) {
            if (actualList.contains(item)) {
                uniqueList.add(item);
            } else {
                missedList.add(item);
            }
        }
        Collections.sort(expectedList);
        Collections.sort(actualList);
        if (expectedList.equals(actualList)) {
            Log.event("All elements checked on this page:: " + uniqueList);
            statusToBeReturned = true;
        } else {
            statusToBeReturned = false;
            if (missedList.size() > 0) {
                Log.event("Missing element on this page:: " + missedList);
            } else {
                List<String> extraElements = new ArrayList<String>(actualList);
                extraElements.removeAll(expectedList);
                Log.event("Extra elements on this list:: " + extraElements);
            }
        }
        return statusToBeReturned;
    }

    /**
     * To compare two HashMap values,then print unique list value and print
     * missed list value
     *
     * @param expectedList - expected element list
     * @param actualList   - actual element list
     * @return statusToBeReturned - returns true if both the lists are equal,
     * else returns false
     */
    public static boolean compareTwoHashMap(Map<String, String> expectedList, Map<String, String> actualList) {
        List<String> missedkey = new ArrayList<String>();
        HashMap<String, String> missedvalue = new HashMap<String, String>();
        try {
            for (String k : expectedList.keySet()) {
                if (!(actualList.get(k).equals(expectedList.get(k)))) {
                    missedvalue.put(k, actualList.get(k));
                    Log.event("Missed Values:: " + missedvalue);
                    return false;
                }
            }
            for (String y : actualList.keySet()) {
                if (!expectedList.containsKey(y)) {
                    missedkey.add(y);
                    Log.event("Missed keys:: " + missedkey);
                    return false;
                }
            }
        } catch (NullPointerException np) {
            return false;
        }
        return true;
    }

    /**
     * To verify a list is in alphabetical order
     *
     * @param listToCheck - what to check alpha order of
     * @return boolean
     */
    public static boolean verifyListInAlphabeticalOrder(List<WebElement> listToCheck) {
        boolean status = false;
        List<String> ActualList = new ArrayList<String>();
        List<String> Sortedlist = new ArrayList<String>();
        for (WebElement element : listToCheck) {
            ActualList.add(element.getText());
            Sortedlist.add(element.getText());
        }
        Collections.sort(Sortedlist);
        if (ActualList.equals(Sortedlist)) {
            status = true;
            Log.message("List is in alphabetical order: " + Sortedlist);
        } else {
            status = false;
        }
        return status;
    }

    /**
     * To unzip given file to a directory
     *
     * @param folderPath current Folder path
     * @param folderPath directory to which the file is to be extracted
     * @return boolean
     */
    public static void unzipFile(String zipFile, String outputPath) throws IOException {

        if (outputPath == null)
            outputPath = "";
        else
            outputPath += File.separator;
        // Create output directory
        File outputDirectory = new File(outputPath);
        if (outputDirectory.exists()) {
            FileUtils.deleteDirectory(outputDirectory);
        }
        outputDirectory.mkdir();
        try {
            ZipInputStream zip = new ZipInputStream(new FileInputStream(zipFile));
            ZipEntry entry = null;
            int len;
            byte[] buffer = new byte[1024];

            while ((entry = zip.getNextEntry()) != null) {
                if (!entry.isDirectory()) {
                    File file = new File(outputPath + entry.getName());
                    if (!new File(file.getParent()).exists())
                        new File(file.getParent()).mkdirs();
                    FileOutputStream fos = new FileOutputStream(file);
                    while ((len = zip.read(buffer)) > 0) {
                        fos.write(buffer, 0, len);
                    }
                    fos.close();
                }
            }
            zip.close();
            Log.message("Unzipped file " + zipFile + " to location : " + outputPath);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Gets the browser url from BrowserStack for the given session Id.
     *
     * @param sessionId - browser session Id
     * @return the browser_url from BS session Id
     * @throws Exception
     */
    public static String getBrowserUrlFromBS(String sessionId) throws Exception {
        String browserUrl = null;
        String userName = configProperty.getProperty("bs.userName").trim();
        String accessKey = configProperty.getProperty("bs.accessKey").trim();
        String sessionUrl = String.format("https://api.browserstack.com/automate/sessions/%s.json", sessionId);
        Response bsApiResponse = RestAssured.given().auth().preemptive().basic(userName, accessKey).get(sessionUrl);
        if (bsApiResponse.statusCode() == 200) {
            browserUrl = bsApiResponse.getBody().jsonPath().getString("automation_session.browser_url");
        } else {
            throw new Exception(bsApiResponse.statusCode() + " : " + bsApiResponse.getBody().asString());
        }
        return browserUrl;
    }

    /*
     * ############################################################## Shadow
     * elements related methods
     * ##############################################################
     */

    /**
     * Returns Web element from shadow-root elements
     *
     * @param driver
     * @param element
     * @return
     */
    public static WebElement getShadowRootElement(WebDriver driver, WebElement element) {
        WebElement shadowRootElement = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", element);
        return shadowRootElement;
    }

    /**
     * To get actual web element located by given CSS inside the shadow root
     * attached to the shadow host located by given CSS
     *
     * @param driver        - WebDriver
     * @param shadowHostCSS - CSS selector of the host from which the shadow
     *                      Root is attached
     * @param elementCSS    - CSS selector of the element to find inside the given
     *                      shadow Root
     * @return WebElement
     */

    public static WebElement getWebElement(WebDriver driver, String shadowHostCSS, String elementCSS) {
        WebElement shadowHost = driver.findElement(By.cssSelector(shadowHostCSS));
        WebElement shadowRootElement = getShadowRootElement(driver, shadowHost);
        WebElement actualElement = shadowRootElement.findElement(By.cssSelector(elementCSS));
        return actualElement;
    }

    /**
     * FireFox Workaround
     * <p>
     * To get actual web element located by given CSS inside the shadow root
     * attached to the given shadow host WebElement by direct query selectors
     *
     * @param driver     - WebDriver
     * @param shadowHost - shadow host WebElement from which the shadow Root is
     *                   attached
     * @param childEle   - CSS selector of the element to find inside the given
     *                   shadow Root
     * @return WebElement
     */
    public static WebElement getWebElementDirect(WebDriver driver, WebElement shadowHost, String... childEle) {
        WebElement elementToReturn = null;
        int args = childEle.length;

        elementToReturn = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot.querySelector(arguments[1])", shadowHost, childEle[0]);
        if (args > 1) {
            for (int i = 1; i < args; i++) {
                elementToReturn = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot.querySelector(arguments[1])", elementToReturn, childEle[i]);
                nap(1);
            }
        }

        return elementToReturn;
    }

    /***
     * Get WebElement with Firefox workaround
     *
     * @param driver
     * @param shadowHost
     * @param elementCSS
     * @return
     */
    public static WebElement getWebElement(WebDriver driver, WebElement shadowHost, String elementCSS) {
        WebElement actualElement = null;
        try {
            WebElement shadowRootElement = getShadowRootElement(driver, shadowHost);
            actualElement = shadowRootElement.findElement(By.cssSelector(elementCSS));
        } catch (Exception e) {
            actualElement = getWebElementDirect(driver, shadowHost, elementCSS); // Workaround for Firefox
        }
        return actualElement;
    }

    /**
     * Scroll down the page
     *
     * @param driver
     */
    public static void scrollDownPage(WebDriver driver) {
        driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL, Keys.END);
    }

    /***
     * Get List<WebElement> with Firefox workaround
     *
     * @param driver
     * @param shadowHost
     * @param elementCSS
     * @return
     */
    public static List<WebElement> getWebElements(WebDriver driver, WebElement shadowHost, String elementCSS) {
        List<WebElement> actualElements = new ArrayList<WebElement>();
        try {
            WebElement shadowRootElement = getShadowRootElement(driver, shadowHost);
            actualElements = shadowRootElement.findElements(By.cssSelector(elementCSS));
        } catch (Exception e) {
            actualElements = getWebElementsDirect(driver, shadowHost, elementCSS); // Workaround for Firefox
        }
        return actualElements;
    }

    /**
     * To get all web elements located by given CSS inside the shadow root
     * attached to the shadow host located by given CSS
     *
     * @param driver        - WebDriver
     * @param shadowHostCSS - CSS selector of the host from which the shadow
     *                      Root is attached
     * @param elementCSS    - CSS selector of the element to find inside the given
     *                      shadow Root
     * @return List of WebElements
     */
    public static List<WebElement> getAllWebElements(WebDriver driver, String shadowHostCSS, String elementCSS) {
        WebElement shadowHost = driver.findElement(By.cssSelector(shadowHostCSS));
        WebElement shadowRootElement = getShadowRootElement(driver, shadowHost);
        List<WebElement> actualElement = shadowRootElement.findElements(By.cssSelector(elementCSS));
        return actualElement;
    }

    /**
     * FireFox Workaround
     * <p>
     * To get actual web element list located by given CSS inside the shadow
     * root attached to the given shadow host WebElement by direct query
     * selector
     *
     * @param driver     - WebDriver
     * @param shadowHost - shadow host WebElement from which the shadow Root is
     *                   attached
     * @param elementCSS - CSS selector of the element to find inside the given
     *                   shadow Root
     * @return WebElement
     */
    public static List<WebElement> getWebElementsDirect(WebDriver driver, WebElement shadowHost, String elementCSS) {

        @SuppressWarnings("unchecked")
        List<WebElement> elementToReturns = (List<WebElement>) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot.querySelectorAll(arguments[1])", shadowHost, elementCSS);

        return elementToReturns;
    }

    /**
     * To get all web elements located by given CSS inside the shadow root
     * attached to the given shadow host WebElement
     *
     * @param driver     - WebDriver
     * @param shadowHost - shadow host WebElement from which the shadow Root is
     *                   attached
     * @param elementCSS - CSS selector of the element to find inside the given
     *                   shadow Root
     * @return List of WebElements
     */
    public static List<WebElement> getAllWebElements(WebDriver driver, WebElement shadowHost, String elementCSS) {
        List<WebElement> actualElements = null;
        try {
            WebElement shadowRootElement = getShadowRootElement(driver, shadowHost);
            actualElements = shadowRootElement.findElements(By.cssSelector(elementCSS));
        } catch (Exception e) {
            actualElements = getWebElementsDirect(driver, shadowHost, elementCSS); // Workaround for Firefox
        }
        return actualElements;
    }

    /*
     * This method used to form the data from CSV file into List
     *
     */

    public static List generateMathHierarchy(String sheetname) throws IOException {
        List<String> mathHierarchyMap = new ArrayList<String>();
        // String basePath = new File(".").getCanonicalPath() + File.separator + "src" +
        // File.separator + "main" + File.separator + "resources" + File.separator +
        // "testdata" + File.separator;
        // String configFilePath = basePath +
        // "MathConceptsHierarchyBulkUploader_SM2021.csv";
        String configFilePath = new File(".").getCanonicalPath() + configProperty.getProperty("mathHierarchyCSV");
        CSVReader reader = new CSVReader(new FileReader(configFilePath));
        String[] nextLine;
        int positions[] = {3, 7, 11, 15, 23}; // {GRADE, STRAND, CONCEPT, TOPIC, LOBJ_DESCRIPTION}
        nextLine = reader.readNext(); // To Skip headers
        while ((nextLine = reader.readNext()) != null) {
            String mathHierarchy = "";
            mathHierarchy += nextLine[18] + "|"; // LO_NAME
            for (int i = 0; i < positions.length; i++) {
                mathHierarchy += nextLine[positions[i]] + " >> ";
            }
            mathHierarchy = mathHierarchy.substring(0, mathHierarchy.length() - 4);
            Integer courseLevel = Integer.parseInt((nextLine[25])); // COURSE_LEVEL
            mathHierarchy = mathHierarchy + "|" + nextLine[29] + "|" + nextLine[29] + String.format("%03d", courseLevel);
            mathHierarchyMap.add(mathHierarchy);
        }
        return mathHierarchyMap;
    }

    /**
     * To get Tutorial id from hierarchyCSV file
     *
     * @param reader
     * @return
     * @throws Exception
     */
    public static List<String> getMathTutorialfromCSV(CSVReader reader) throws Exception {
        ArrayList<String> loList = new ArrayList<>();

        String[] nextLine;
        reader.readNext();
        while ((nextLine = reader.readNext()) != null) {
            if (!nextLine[28].isEmpty()) {
                loList.add(nextLine[28].trim());
            }
        }
        ArrayList<String> scoTutList = new ArrayList<String>();
        // Traverse through the first list
        for (String element : loList) {
            if (!scoTutList.contains(element)) {
                scoTutList.add(element);
            }
        }
        scoTutList.removeIf(Objects::isNull);

        return scoTutList;
    }

    /*
     * To get MathPrerequisite details from Motion XML LOName & XML Doc as
     * Parameter to the method
     */

    public static Map<String, String> getMathPrerequisiteTable(String LOName, Document doc) throws Exception {
        HashMap<String, String> prereqTable = new HashMap<String, String>();
        Map<String, String> sortedMap = new TreeMap<String, String>();

        doc.getDocumentElement().normalize();

        NodeList learnigObj = doc.getElementsByTagName("LearningObjective");

        for (int i = 0; i < learnigObj.getLength(); i++) {

            Node node = learnigObj.item(i);
            String XMLLOName = learnigObj.item(i).getAttributes().item(0).getTextContent();
            if (LOName.equals(XMLLOName)) {
                NodeList prerequisiteTable = ((Element) learnigObj.item(i)).getElementsByTagName("PrerequisiteTable");
                prereqTable.put("mastery", ((Element) prerequisiteTable.item(0)).getAttribute("mastery"));
                // Get all children nodes from PrerequisiteTable info
                NodeList prerequisitechildren = prerequisiteTable.item(0).getChildNodes();

                for (int j = 0; j < prerequisitechildren.getLength(); j++) {
                    Node current = prerequisitechildren.item(j);
                    if (current.getNodeType() == Node.ELEMENT_NODE) {
                        Element eElement = (Element) current;
                        prereqTable.put(current.getNodeName() + "_" + eElement.getAttribute(TestDataConstants.ORDER_TAG), eElement.getAttribute("name"));
                    }
                }
                break;
            }
        }
        sortedMap.putAll(prereqTable);
        return sortedMap;
    }

    /*
     * To get LO name and its course level from Mathhierarchy csv file
     */

    public static HashMap<String, String> getMathLOMapStrand() throws Exception {
        HashMap<String, String> dataToBeReturned = new HashMap<String, String>();
        ;
        // String basePath = new File(".").getCanonicalPath() + File.separator + "src" +
        // File.separator + "main" + File.separator + "resources" + File.separator +
        // "testdata" + File.separator;
        // String configFilePath = basePath +
        // "MathConceptsHierarchyBulkUploader_SM2021.csv";
        String configFilePath = new File(".").getCanonicalPath() + File.separator + "hierarchyValidation" + File.separator + configProperty.getProperty("mathHierarchyCSV");
        CSVReader reader = new CSVReader(new FileReader(configFilePath));
        String[] nextLine;
        nextLine = reader.readNext(); // To Skip headers
        while ((nextLine = reader.readNext()) != null) {
            Integer courseLevel = Integer.parseInt((nextLine[25])); // CourseLevel
            dataToBeReturned.put(nextLine[18], nextLine[29].toLowerCase() + String.format("%03d", courseLevel));
        }
        return dataToBeReturned;
    }

    /*
     * This method generates Hashmap from motion xml data for Tutorials
     */

    public static HashMap<String, String> getMathTutorialMap(Document doc) throws Exception {
        HashMap<String, String> tutorialTable = new HashMap<String, String>();
        Boolean tutorialPresent = false;

        doc.getDocumentElement().normalize();

        NodeList tutorialObj = ((Element) doc.getElementsByTagName("Tutorials").item(0)).getElementsByTagName("Tutorial");

        for (int i = 0; i < tutorialObj.getLength(); i++) {

            Node node = tutorialObj.item(i);

            tutorialTable.put(((Element) tutorialObj.item(i)).getAttribute("desc"), ((Element) tutorialObj.item(i)).getAttribute("name"));
        }
        return tutorialTable;
    }

    /*
     * To get Mastery details from math Motion xml file Parameters: Mastery ID &
     * Doc
     */
    public static HashMap<String, String> getMathMasteryMap(String mastery, Document doc) throws Exception {
        HashMap<String, String> tutorialTable = new HashMap<String, String>();
        Boolean tutorialPresent = false;

        doc.getDocumentElement().normalize();

        NodeList tutorialObj = ((Element) doc.getElementsByTagName("MasteryTable").item(0)).getElementsByTagName("Mastery");

        for (int i = 0; i < tutorialObj.getLength(); i++) {
            Node node = tutorialObj.item(i);
            if (((Element) tutorialObj.item(i)).getAttributes().item(3).getTextContent().equals(mastery)) {
                int len = ((Element) tutorialObj.item(i)).getAttributes().getLength();
                for (int j = 0; j < len; j++) {
                    tutorialTable.put(((Element) tutorialObj.item(i)).getAttributes().item(j).getNodeName(), ((Element) tutorialObj.item(i)).getAttributes().item(j).getTextContent());
                }
            }
        }
        return tutorialTable;
    }

    /***
     * Scroll the given element into view port
     *
     * @param driver
     * @param element
     */
    public static void scrollWebElementToView(WebDriver driver, WebElement element, String... scrollPosition) {
        if (scrollPosition.length == 0)
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
        else if (scrollPosition[0].equals(SMUtils.SCROLL_TO_BOTTOM))
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(false);", element);
        else if (scrollPosition[0].equals(SMUtils.SCROLL_TO_MIDDLE)) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block: 'center'});", element);
        }
    }

    public static void clickJS(WebDriver driver, WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
    }

    /**
     * Performs selenium click first, if error occurs, it uses JS click
     *
     * @param driver
     * @param element
     */
    public static void click(WebDriver driver, WebElement element) {
        try {
            element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
    }

    /**
     * To get actual web element located by given by_locator inside the shadow
     * root attached to the given shadow host WebElement
     *
     * @param driver     - WebDriver
     * @param shadowHost - shadow host WebElement from which the shadow Root is
     *                   attached
     * @param byLocator  - byLocator of the element to find inside the given
     *                   shadow Root
     * @return WebElement
     */
    public static WebElement getWebElement(WebDriver driver, WebElement shadowHost, By byLocator) {
        WebElement shadowRootElement = getShadowRootElement(driver, shadowHost);
        WebElement actualElement = shadowRootElement.findElement(byLocator);
        return actualElement;
    }

    /**
     * To get actual web elements located by given by_locator inside the shadow
     * root attached to the given shadow host WebElement
     *
     * @param driver     - WebDriver
     * @param shadowHost - shadow host WebElement from which the shadow Root is
     *                   attached
     * @param byLocator  - byLocator of the element to find inside the given
     *                   shadow Root
     * @return List<WebElement>
     */
    public static List<WebElement> getWebElements(WebDriver driver, WebElement shadowHost, By byLocator) {
        WebElement shadowRootElement = getShadowRootElement(driver, shadowHost);
        List<WebElement> actualElements = shadowRootElement.findElements(byLocator);
        return actualElements;
    }

    /***
     * Get child webElement from Parent element
     *
     * @param parentElement
     * @param byLocator
     * @return
     */
    public static WebElement getChildWebElementFromParent(WebElement parentElement, String cssLocator) {
        return parentElement.findElement(By.cssSelector(cssLocator));
    }

    /***
     * Get list of child webElements from Parent element
     *
     * @param parentElement
     * @param byLocator
     * @return
     */
    public static List<WebElement> getChildWebElementsFromParent(WebElement parentElement, String cssLocator) {
        return parentElement.findElements(By.cssSelector(cssLocator));
    }

    /***
     * Get list of Reading hierarchy from hierarchy csv file
     *
     * @param sheetname
     * @return
     * @throws IOException
     */
    public static List generateReadingHierarchy(String sheetname) throws IOException {
        List<String> mathHierarchyMap = new ArrayList<String>();
        String basePath = new File(".").getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator;
        String configFilePath = basePath + configProperty.getProperty("readingHierarchyFile");
        CSVReader reader = new CSVReader(new FileReader(configFilePath));
        String[] nextLine;
        int positions[] = {3, 7, 11, 15, 35, 36}; // {GRADE, BENCHMARK, UNIT, LESSON, LO_Title, LOBJ_DESCRIPTION}
        nextLine = reader.readNext(); // To Skip headers
        while ((nextLine = reader.readNext()) != null) {
            String mathHierarchy = "";
            mathHierarchy += nextLine[18] + "|"; // LO_NAME
            for (int i = 0; i < positions.length; i++) {
                mathHierarchy += nextLine[positions[i]] + " >> ";
            }
            mathHierarchy = mathHierarchy.substring(0, mathHierarchy.length() - 4);
            mathHierarchyMap.add(mathHierarchy);
        }
        return mathHierarchyMap;
    }

    /***
     * Get Strand Details from Reading resources.xml by LO ID
     *
     * @param doc
     * @param LOName
     * @return
     * @throws Exception
     */

    public static HashMap<String, String> getReadingLOStrandDetails(Document doc, String LOName) throws Exception {
        HashMap<String, String> LODetails = new HashMap<String, String>();

        doc.getDocumentElement().normalize();

        NodeList learnigObj = doc.getElementsByTagName(TestDataConstants.LO_TAG);

        for (int i = 0; i < learnigObj.getLength(); i++) {
            Node node = learnigObj.item(i);
            String XMLLOName = ((Element) learnigObj.item(i)).getAttribute(TestDataConstants.ID_TAG);
            if (LOName.equals(XMLLOName)) {
                int len = ((Element) learnigObj.item(i)).getAttributes().getLength();
                for (int j = 0; j < len; j++) {
                    LODetails.put(((Element) learnigObj.item(i)).getAttributes().item(j).getNodeName(), ((Element) learnigObj.item(i)).getAttributes().item(j).getTextContent());
                }
            }
        }
        return LODetails;
    }

    /**
     * To get SCO id from hierarchyCSV file
     *
     * @param reader
     * @return
     * @throws Exception
     */
    public static List<String> getMathSCOfromCSV(CSVReader reader) throws Exception {
        ArrayList<String> scoList = new ArrayList<>();

        String[] nextLine;
        reader.readNext();
        while ((nextLine = reader.readNext()) != null) {
            if (!nextLine[18].isEmpty()) {
                scoList.add(nextLine[18].trim() + "_S1");
            }
            if (!nextLine[28].isEmpty()) {
                scoList.add(nextLine[28].trim() + "_S1");
            }
        }
        ArrayList<String> scoTutList = new ArrayList<String>();
        // Traverse through the first list
        for (String element : scoList) {
            if ((!scoTutList.contains(element)) && (element != "_S1")) {
                scoTutList.add(element);
            }
        }
        Collections.sort(scoTutList);
        return scoTutList;
    }

    /**
     * To get SCO ID and scorable value from math motion xml
     *
     * @param doc
     * @return
     * @throws Exception
     */
    public static Map<String, String> getMathSCOfromMotion(Document doc) throws Exception {
        HashMap<String, String> SCOmap = new HashMap<String, String>();
        Map<String, String> sortedMap = new TreeMap<String, String>();
        doc.getDocumentElement().normalize();

        NodeList SCOObj = doc.getElementsByTagName(TestDataConstants.SCO_TAG);
        for (int i = 0; i < SCOObj.getLength(); i++) {

            String LessonID = ((Element) SCOObj.item(i)).getAttribute(TestDataConstants.ID_TAG);
            NodeList LOrecord = ((Element) SCOObj.item(i)).getChildNodes();
            SCOmap.put(LessonID, ((Element) LOrecord.item(1)).getAttribute("value")); //Storing isScorable value

        }
        sortedMap.putAll(SCOmap);
        return sortedMap;
    }

    /***
     * Get skillobjective details from Reading resources.xml by skill id
     *
     * @param doc
     * @param id
     * @return
     * @throws Exception
     */
    public static HashMap<String, String> getReadingSkillObjDetails(Document doc, String id) throws Exception {
        HashMap<String, String> skillObjDetails = new HashMap<String, String>();

        doc.getDocumentElement().normalize();

        NodeList learnigObj = doc.getElementsByTagName(TestDataConstants.SKILL_OBJECTIVE_TAG);

        for (int i = 0; i < learnigObj.getLength(); i++) {
            Node node = learnigObj.item(i);
            String XMLSkillID = ((Element) learnigObj.item(i)).getAttribute(TestDataConstants.ID_TAG);
            if (id.equals(XMLSkillID)) {
                int len = ((Element) learnigObj.item(i)).getAttributes().getLength();
                for (int j = 0; j < len; j++) {
                    skillObjDetails.put(((Element) learnigObj.item(i)).getAttributes().item(j).getNodeName(), ((Element) learnigObj.item(i)).getAttributes().item(j).getTextContent());
                }

            }
        }
        return skillObjDetails;
    }

    /***
     * Get SCODetails from readingscos.xml by LO ID
     *
     * @param doc
     * @param LOName
     * @return
     * @throws Exception
     */
    public static HashMap<String, String> getReadingSCODetails(Document doc, String LOName) throws Exception {
        HashMap<String, String> SCODetails = new HashMap<String, String>();

        doc.getDocumentElement().normalize();

        NodeList SCOObj = doc.getElementsByTagName(TestDataConstants.SCO_TAG);

        for (int i = 0; i < SCOObj.getLength(); i++) {
            Node node = SCOObj.item(i);
            String XMLLOName = ((Element) SCOObj.item(i)).getAttribute(TestDataConstants.ID_TAG);
            if (LOName.equals(XMLLOName)) {

                NodeList scoItems = ((Element) SCOObj.item(i)).getElementsByTagName("item");
                int len = scoItems.getLength();
                for (int j = 0; j < len; j++) {
                    Node current = scoItems.item(j);
                    Element eElement = (Element) current;
                    SCODetails.put(eElement.getAttribute("name"), eElement.getAttribute("value"));
                }
                break;
            }
        }
        return SCODetails;
    }

    /***
     * Get SCO order details from readingloscos.xml by LO ID
     *
     * @param doc
     * @param LOID
     * @return
     * @throws Exception
     */
    public static Map<String, String> getReadingLOSCOOrderDetails(Document doc, String LOID) throws Exception {
        HashMap<String, String> scoOrder = new HashMap<String, String>();
        Map<String, String> sortedMap = new TreeMap<String, String>();
        doc.getDocumentElement().normalize();

        NodeList SCOObj = doc.getElementsByTagName(TestDataConstants.LO_TAG);
        for (int i = 0; i < SCOObj.getLength(); i++) {
            String XMLLOName = ((Element) SCOObj.item(i)).getAttribute(TestDataConstants.ID_TAG);
            if (LOID.equals(XMLLOName)) {
                NodeList LOrecord = ((Element) SCOObj.item(i)).getElementsByTagName(TestDataConstants.SCO_TAG);
                for (int j = 0; j < LOrecord.getLength(); j++) {
                    scoOrder.put(((Element) LOrecord.item(j)).getAttribute(TestDataConstants.ID_TAG), ((Element) LOrecord.item(j)).getAttribute(TestDataConstants.ORDER_TAG));
                }
            }
        }
        sortedMap.putAll(scoOrder);
        return sortedMap;
    }

    /***
     * Get LO ID and its role by LO id from readingresources.xml
     *
     * @param doc
     * @param LessonID
     * @return
     * @throws Exception
     */
    public static Map<String, String> getReadingLOSByLesson(Document doc, String LessonID) throws Exception {
        HashMap<String, String> LOMap = new HashMap<String, String>();
        Map<String, String> sortedMap = new TreeMap<String, String>();
        doc.getDocumentElement().normalize();

        NodeList SCOObj = doc.getElementsByTagName(TestDataConstants.LESSON_TAG);
        for (int i = 0; i < SCOObj.getLength(); i++) {
            String XMLLessonID = ((Element) SCOObj.item(i)).getAttribute(TestDataConstants.ID_TAG);
            if (LessonID.equals(XMLLessonID)) {
                NodeList LOrecord = ((Element) SCOObj.item(i)).getElementsByTagName(TestDataConstants.LO_REF_TAG);
                for (int j = 0; j < LOrecord.getLength(); j++) {
                    LOMap.put(((Element) LOrecord.item(j)).getAttribute(TestDataConstants.ID_TAG), ((Element) LOrecord.item(j)).getAttribute(TestDataConstants.ROLE_TAG));
                }
                break;
            }
        }
        sortedMap.putAll(LOMap);
        return sortedMap;
    }

    /***
     * Get Lesson ID from CURRICULUM_TAXONOMYS_LOBJS.xml by Lesson name & grade
     *
     * @param doc
     * @param grade
     * @param lesson
     * @return
     * @throws Exception
     */
    public static String getReadingLessonID(Document doc, String grade, String lesson) throws Exception {
        HashMap<String, String> scoOrder = new HashMap<String, String>();
        String lessonID = "";
        String parentID = "";
        String FinalLessonID = "";
        Boolean status = false;
        List<String> type = new ArrayList<String>();
        doc.getDocumentElement().normalize();

        NodeList SCOObj = doc.getElementsByTagName(TestDataConstants.RECORD_TAG);
        for (int i = 0; i < SCOObj.getLength(); i++) {
            NodeList record = ((Element) SCOObj.item(i)).getChildNodes();

            if (record.item(3).getTextContent().equals(lesson)) {
                lessonID = record.item(9).getTextContent();
                parentID = record.item(11).getTextContent();
                type = checkLessonRoot(doc, parentID, grade);
                while (!type.get(1).equals("Grade")) {
                    type = checkLessonRoot(doc, type.get(0), grade);
                }
                if (type.get(2).equals("Found")) {
                    FinalLessonID = lessonID;
                    break;
                }
            }
        }

        return FinalLessonID;
    }

    /***
     * Get Lesson root from CURRICULUM_TAXONOMYS_LOBJS.xml by Parent ID of
     * lesson ID
     *
     * @param doc
     * @param parentID
     * @param grade
     * @return
     * @throws Exception
     */
    public static List<String> checkLessonRoot(Document doc, String parentID, String grade) throws Exception {

        ArrayList<String> rootDetails = new ArrayList<>();
        doc.getDocumentElement().normalize();
        String GradeFound = "NotFound";

        NodeList SCOObj = doc.getElementsByTagName(TestDataConstants.RECORD_TAG);
        for (int i = 0; i < SCOObj.getLength(); i++) {
            String CTTYPE_NAME = "";
            NodeList record = ((Element) SCOObj.item(i)).getChildNodes();
            CTTYPE_NAME = record.item(3).getTextContent();
            if (parentID.equals(record.item(9).getTextContent())) {
                rootDetails.add(record.item(11).getTextContent());
                rootDetails.add(record.item(19).getTextContent());
                if (CTTYPE_NAME.equals(grade)) {
                    GradeFound = "Found";
                }
            }
        }

        rootDetails.add(GradeFound);
        return rootDetails;
    }

    /***
     * Get list of unique Lesson name from reading hierarchy csv
     *
     * @param reader
     * @return
     * @throws Exception
     */
    public static List<String> getUniqueLesson(CSVReader reader) throws Exception {
        ArrayList<String> lessonList = new ArrayList<>();
        String[] nextLine;
        nextLine = reader.readNext();
        while ((nextLine = reader.readNext()) != null) {
            String lesson = nextLine[15].trim();
            lessonList.add(lesson);
        }
        ArrayList uniqueList = (ArrayList) lessonList.stream().distinct().collect(Collectors.toList());

        return uniqueList;
    }

    /***
     * Get LO id which is mapped to a Lesson UUID
     *
     * @param reader
     * @param lessonuuid
     * @return
     * @throws Exception
     */
    public static Map<String, String> getLOByLessonUUID(CSVReader reader, String lessonuuid) throws Exception {
        HashMap<String, String> lessonList = new HashMap<String, String>();
        Map<String, String> sortedMap = new TreeMap<String, String>();
        String[] nextLine;
        nextLine = reader.readNext();
        while ((nextLine = reader.readNext()) != null) {
            if (lessonuuid.equals(nextLine[14].trim()) && !(nextLine[18].contains("smre_pp"))) { // Ignore Print type LO
                lessonList.put(nextLine[18].trim(), nextLine[20].trim());
            }
        }
        sortedMap.putAll(lessonList);
        return sortedMap;
    }

    /**
     * Get All the lesson UUID, grade and its name from hierarchy csv
     *
     * @param reader
     * @return
     * @throws Exception
     */
    public static HashMap<String, String> getReadingLessonUUIDDetails(CSVReader reader) throws Exception {
        HashMap<String, String> UUIDorder = new HashMap<String, String>();

        String[] nextLine;
        nextLine = reader.readNext();
        while ((nextLine = reader.readNext()) != null) {
            UUIDorder.put(nextLine[14].trim() + "_" + nextLine[3].trim(), nextLine[15]);

        }
        return UUIDorder;
    }

    /**
     * Get list of unique LO ID from sco list csv file
     *
     * @param reader
     * @return
     * @throws Exception
     */
    public static List<String> getReadingUniqueLOSCODetails(CSVReader reader) throws Exception {
        ArrayList<String> lessonList = new ArrayList<>();

        String[] nextLine;
        nextLine = reader.readNext();
        while ((nextLine = reader.readNext()) != null) {
            String SCO = nextLine[0].trim();
            if (!SCO.contains("smre_pp")) { // Ignore Print type LO
                SCO = SCO.substring(0, SCO.length() - 3);
                lessonList.add(SCO);
            }
        }
        ArrayList uniqueList = (ArrayList) lessonList.stream().distinct().collect(Collectors.toList());
        return uniqueList;
    }

    /**
     * To get the list of LO ID from sco xml
     *
     * @param doc
     * @return
     * @throws Exception
     */
    public static List<String> getReadingLOSCOList(Document doc) throws Exception {
        ArrayList<String> lessonList = new ArrayList<>();
        doc.getDocumentElement().normalize();

        NodeList SCOObj = doc.getElementsByTagName(TestDataConstants.LO_TAG);
        for (int i = 0; i < SCOObj.getLength(); i++) {
            lessonList.add(((Element) SCOObj.item(i)).getAttribute(TestDataConstants.ID_TAG));

        }
        return lessonList;
    }

    /**
     * Get SCO by the LO ID
     *
     * @param reader
     * @param LOName
     * @return
     * @throws Exception
     */
    public static Map<String, String> getReadingSCOByLO(CSVReader reader, String LOName) throws Exception {
        HashMap<String, String> scoList = new HashMap<String, String>();
        Map<String, String> sortedscoList = new TreeMap<String, String>();

        String[] nextLine;
        nextLine = reader.readNext();
        while ((nextLine = reader.readNext()) != null) {
            if (nextLine[0].trim().contains(LOName + "_")) {
                scoList.put(nextLine[0].trim(), nextLine[4]);
            }
        }
        sortedscoList.putAll(scoList);
        return sortedscoList;
    }

    /**
     * Verify the element present
     *
     * @param element
     * @return
     */
    public static boolean isElementPresent(WebElement element) {
        if (element.isDisplayed()) {
            return true;
        } else {
            return false;
        }
    }

    public static String getLocalCurrentDateAndTime() {
        Date date = new Date();
        long time = date.getTime();
        Timestamp ts = new Timestamp(time);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        String currentDateAndTime = simpleDateFormat.format(ts);
        return currentDateAndTime;
    }

    public static void enterValue(WebElement element, String val) {
        element.clear();
        element.sendKeys(val);
        Log.message("Entered value as: " + val);
    }

    /**
     * This method switches to new focus to new window and returns the old
     * window reference.
     *
     * @param driver
     * @return
     */
    public static String switchWindow(WebDriver driver) {
        String winHandleBefore = driver.getWindowHandle();
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        return winHandleBefore;
    }

    /**
     * Verifies if all the values in the boolean array are true or not
     *
     * @param array of boolean values
     * @return overall status of the booleans in the array
     */
    public static boolean isAllValueTrue(ArrayList<Boolean> array) {
        for (boolean value : array) {
            if (!value) {
                return false;
            }
        }
        return array != null && array.size() > 0;
    }

    /**
     * To get the downloaded filePath
     *
     * @return
     */
    public static String getDownloadedFilePath() {
        String home = System.getProperty("user.home");
        String downloadedPath = "";
        File file = new File(home + "/Downloads/");
        downloadedPath = file.toString() + "\\";
        return downloadedPath;
    }

    /**
     * To verify the file is downloaded
     *
     * @param fileNameWithExtention
     * @param driver
     * @return boolean
     */
    public static boolean isFileDownloaded(String fileNameWithExtention, WebDriver driver) {

        boolean isFileExist = false;
        if (configProperty.getProperty("runBSFromLocal").equalsIgnoreCase("true")) {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            try {
                String script = "browserstack_executor: {\"action\": \"fileExists\", \"arguments\": {\"fileName\": \"%s\"}}";
                String fileAction = String.format(script, fileNameWithExtention);
                isFileExist = (boolean) js.executeScript(fileAction);
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (!isFileExist) {
                String script = "browserstack_executor: {\"action\": \"fileExists\"}";
                String fileAction = String.format(script, fileNameWithExtention);
                isFileExist = (boolean) js.executeScript(fileAction);
            }
            return isFileExist;
        } else {
            File directoryPath = new File(getDownloadedFilePath());
            File[] listOfFiles = directoryPath.listFiles();
            for (int i = 0; i < listOfFiles.length; i++) {

                if (listOfFiles[i].isFile()) {
                    String fName = listOfFiles[i].getName();
                    if (fileNameWithExtention.equalsIgnoreCase(fName)) {
                        isFileExist = true;
                    }
                }
            }
        }
        return isFileExist;
    }

    /**
     * This method will return all the parameters which present in given path
     * Even it is array, object etc.
     *
     * @param response
     * @param path
     * @return
     */
    public static String getKeyValueFromResponseWithArray(String response, String path) {
        String[] json_Array = path.split(",");
        String keyValue = null;
        try {

            if (json_Array.length <= 1) {
                JSONObject jsonObj = new JSONObject(response);
                String JsonArrayValue = jsonObj.get(json_Array[0]).toString();
                return JsonArrayValue;
            } else {
                JSONObject jsonObj = new JSONObject(response);
                String JsonArrayValue = jsonObj.get(json_Array[0]).toString();
                JSONObject jsonObj1 = new JSONObject(JsonArrayValue);
                keyValue = jsonObj1.get(json_Array[1]).toString();
                return keyValue;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return keyValue;
        }
    }

    /**
     * To get SQL Query directory path
     *
     * @return
     * @throws IOException
     */
    public static String getQueryDirPath() throws IOException {
        return new File(".").getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "DBQueries" + File.separator;
    }

    /**
     * To get SQL JSON directory path
     *
     * @return
     * @throws IOException
     */
    public static String getPayLoadDirPath() throws IOException {
        return new File(".").getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "PayLoad" + File.separator;
    }

    /**
     * To get the file as string. Make the fromJar true if the file is in Jar
     * compressed else put fail
     *
     * @param fileName
     * @param fromJar
     * @return
     * @throws IOException
     */
    public static String convertFileToString(String fileName) throws IOException {

        BufferedReader in = new BufferedReader(new FileReader(fileName));
        String str;
        StringBuffer sb = new StringBuffer();
        while ((str = in.readLine()) != null) {
            sb.append(str + " ");
        }
        in.close();
        return sb.toString();

    }

    /**
     * Wait until the spinner will disappear of Max 25 seconds
     *
     * @param driver
     * @throws InterruptedException
     */
    public static void waitForSpinnertoDisapper(WebDriver driver) throws InterruptedException {
        List<WebElement> spinner = driver.findElements(By.cssSelector(spinnerElement));
        long startTime = StopWatch.startTime();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        try {
            if (spinner.size() > 0) {
                System.out.println("Waiting for spinner to disappear");
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(spinnerElement)));
                Log.message("Spinner loaded for : " + StopWatch.elapsedTime(startTime));
            }
        } catch (TimeoutException e) {
            Log.message("Waited till the Max time");
        }
    }

    /**
     * Wait until only one Spinner in the page to disappear
     *
     * @param driver
     * @throws InterruptedException
     */
    public static void waitForSpinnertoDisapper(WebDriver driver, Integer waitTime) throws InterruptedException {
        long startTime = StopWatch.startTime();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(waitTime));
        try {
            Log.message("Waiting for spinner to disappear");
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(spinnerElement)));
            Log.message("Spinner loaded for : " + StopWatch.elapsedTime(startTime) + " second(s)");

        } catch (TimeoutException e) {
            Log.message("Waited till the Max time");
        }
    }

    /**
     * Verify the element enabled
     *
     * @param element
     * @return boolean
     */
    public static boolean isElementEnabled(WebElement element) {
        if (element.isEnabled()) {
            return true;
        } else {
            return false;
        }

    }

    /**
     * Press F5 key or refresh Page
     *
     * @param driver
     */
    public static void sendF5Key(WebDriver driver) {
        driver.findElement(pageBody).sendKeys(Keys.F5);
        Log.event("Clicked F5 key");
    }

    /*
     * To compare List and return true if matches or false if not matches
     *
     * @param actualList
     *
     * @param listToCompare
     *
     * @param sortingType - Will sort Ascending or Descending
     *
     * @return
     */
    public static Boolean sortAndCompareList(List<String> actualList, List<String> listToCompare, String sortingType) {
        boolean flag;
        if (sortingType.equals(Constants.ASCENDING)) {
            Collections.sort(listToCompare);
            flag = actualList.equals(listToCompare) ? true : false;
            if (!flag) {
                Log.message("The List is not Matches Expected" + listToCompare.toString() + "Actual" + actualList.toString());
            }
            return flag;
        } else if (sortingType.equals(Constants.DESCENDING)) {
            Collections.sort(listToCompare, Collections.reverseOrder());
            flag = actualList.equals(listToCompare) ? true : false;
            if (!flag) {
                Log.message("The List is not Matches Expected" + listToCompare.toString() + "Actual" + actualList.toString());
            }
            return flag;
        } else {
            Log.message("Sorting type is not Correct!");
            return false;
        }
    }

    /**
     * This will wait until the Toast message disappear
     *
     * @param driver
     * @throws InterruptedException
     * @throws TimeoutException
     */
    public static void waitForToastMessageToDisapper(WebDriver driver) throws InterruptedException, TimeoutException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25));
        System.out.println("Waiting for Toast message to disappear");
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(toastElementCSS)));
    }

    /**
     * get the HTML Text of the Given Element
     *
     * @param element
     * @return
     */
    public static String getOuterHTML(WebElement element) {
        return element.getAttribute("outerHTML");
    }

    /**
     * To get the StudentId mapped with given Teacher username while DATA setup
     *
     * @param username
     * @return
     */
    public static ArrayList<String> getStudentIdsForTeacher(String username) {
        ArrayList<String> studentIdList = new ArrayList<>();
        IntStream.rangeClosed(1, DataSetupConstants.STUDENT_COUNT).forEach(studentCount -> {
            String studentID = SMUtils.getKeyValueFromResponse(DataSetup.teacherStudentMap.get(username).get("Student" + studentCount), "data,studentIdentificationNumber");
            studentIdList.add(studentID);
        });
        return studentIdList;
    }

    /**
     * To get the font family from the element
     *
     * @param element
     * @return font family
     */
    public static String getFontFamily(WebElement element) {
        return element.getCssValue(FONT_FAMILY).trim();
    }

    public static boolean waitForPageLoad(WebDriver driver) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        // wait for jQuery to load
        ExpectedCondition<Boolean> jQueryLoad = new ExpectedCondition<Boolean>() {
            @Override
            public Boolean apply(WebDriver driver) {
                try {
                    return ((Long) ((JavascriptExecutor) driver).executeScript("return jQuery.active") == 0);
                } catch (Exception e) {
                    return true;
                }
            }
        };

        // wait for Javascript to load
        ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() {
            @Override
            public Boolean apply(WebDriver driver) {
                return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
            }
        };

        return wait.until(jQueryLoad) && wait.until(jsLoad);

    }

    /**
     * To get the canonical file path of given file
     *
     * @param fileName
     * @return
     * @throws IOException
     */
    public static String getPayloadFilePath(String fileName) throws IOException {
        return new File(".").getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "PayLoad" + File.separator + fileName;
    }

    /**
     * <p>
     * To get a confirmation on the presence of a value in the response
     *
     * @param jsonResponse
     * @param key
     * @param comparingValue
     * @return courseFound
     */
    public static Boolean compareKeyValue(String jsonResponse, String key, String comparingValue) {
        JSONArray jsonArray = new JSONArray(jsonResponse);
        AtomicReference<Object> value = new AtomicReference<>(null);
        AtomicReference<Boolean> courseFound = new AtomicReference<>(false);
        IntStream.range(0, jsonArray.length()).forEach(elementIndex -> {
            JSONObject item = jsonArray.getJSONObject(elementIndex);
            if (item.keySet().contains(key)) {
                value.set(item.get(key));
                if (value.toString().contains(comparingValue)) {
                    courseFound.set(true);
                }
            }
        });
        return courseFound.get();
    }

    /**
     * To get the payload related to the functionality. Eg: Admin/teacher/RBS
     *
     * @param payload
     * @param fileName
     * @return
     */
    public static String getPayload(PayloadFor payload, String fileName) {
        String payloadString = null;
        InputStream is;
        switch (payload) {
            case RBS:
                is = SMUtils.class.getClassLoader().getResourceAsStream(FileConstants.RBS_PAYLOAD_FOLDER + fileName);
                payloadString = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8)).lines().collect(Collectors.joining("\n"));
                break;
            case ADMIN:
                is = SMUtils.class.getClassLoader().getResourceAsStream(FileConstants.ADMIN_PAYLOAD_FOLDER + fileName);
                payloadString = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8)).lines().collect(Collectors.joining("\n"));
                break;
            case TEACHER:
                is = SMUtils.class.getClassLoader().getResourceAsStream(FileConstants.TEACHER_PAYLOAD_FOLDER + fileName);
                payloadString = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8)).lines().collect(Collectors.joining("\n"));
                break;
            case STUDENT:
                is = SMUtils.class.getClassLoader().getResourceAsStream( FileConstants.STUDENT_PAYLOAD_FOLDER + fileName );
                payloadString = new BufferedReader( new InputStreamReader( is, StandardCharsets.UTF_8 ) ).lines().collect( Collectors.joining( "\n" ) );
                break;
            default:
                Log.message("Invalid file name");
        }

        return payloadString.toString();
    }

    /**
     * To get the DBQuery related to the functionality. Eg: Admin/Teacher/Common
     *
     * @param dbQuery
     * @param fileName
     * @return
     */
    public static String getDBQuery(DBQueryFor dbQuery, String fileName) {
        String dbQueryString = null;
        InputStream is;
        switch (dbQuery) {
            case ADMIN:
                is = SMUtils.class.getClassLoader().getResourceAsStream(FileConstants.ADMIN_DBQUERIES_FOLDER + fileName);
                dbQueryString = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8)).lines().collect(Collectors.joining("\n"));
                break;
            case TEACHER:
                is = SMUtils.class.getClassLoader().getResourceAsStream(FileConstants.TEACHER_DBQUERIES_FOLDER + fileName);
                dbQueryString = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8)).lines().collect(Collectors.joining("\n"));
                break;
            case COMMON:
                is = SMUtils.class.getClassLoader().getResourceAsStream(FileConstants.COMMON_DBQUERIES_FOLDER + fileName);
                dbQueryString = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8)).lines().collect(Collectors.joining("\n"));
                break;
            default:
                Log.message("Invalid file name");
        }

        return dbQueryString.toString();
    }

    /**
     * To get the random values from Arraylist. This can used to avoid same type
     * of data used everywhere
     *
     * @param list
     * @return
     */
    public static String getRandomVariableFromArrayList(List<String> list) {
        Random random_index = new Random();
        return list.get(random_index.nextInt(list.size()));

    }

    /**
     * This methods will update the details whatever given in Key and value
     *
     * @param studentDetails
     * @param key
     * @param value
     * @return
     */
    public static HashMap<String, String> updateRequestBodyValues(HashMap<String, String> studentDetails, String key, String value) {
        HashMap<String, String> generatedStudentDetails = studentDetails;
        if (generatedStudentDetails.containsKey(key)) {
            generatedStudentDetails.put(key, value);
        } else {
            generatedStudentDetails.put(key, value);
        }
        return generatedStudentDetails;
    }

    /**
     * This methods is used to put the common header parameters
     *
     * @param userreqDetails
     * @return headers
     */

    public Map<String, String> getHeaders(HashMap<String, String> userreqDetails) {
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
        headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
        headers.put(Constants.AUTHORIZATION, "Bearer " + userreqDetails.get(RBSDataSetupConstants.BEARER_TOKEN));

        headers.put(Constants.USERID_SM_HEADER, userreqDetails.get(AssignmentAPIConstants.TEACHER_ID));
        headers.put(Constants.ORGID_SM_HEADER, userreqDetails.get(AssignmentAPIConstants.ORG_ID));
        return headers;
    }

    /**
     * Convert milliseconds into Date
     *
     * @param long milliseconds
     * @return
     */
    public String convertMillisecondstoDate(long millisconds) {
        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd'Z'");
        Date dateformated = new Date(millisconds);
        String s = simpleFormat.format(dateformated);
        return s;
    }

    /**
     * To get the count of the number of keys
     *
     * @param jsonResponse
     * @param key
     * @param comparingValue
     * @return courseFound
     */
    public static List<String> getTheKeyCount(String jsonResponse, String key) {
        List<String> listOfValuesForParticularKey = new ArrayList<>();
        JSONArray jsonArray = new JSONArray(jsonResponse);
        AtomicReference<Object> value = new AtomicReference<>(null);
        IntStream.range(0, jsonArray.length()).forEach(elementIndex -> {
            JSONObject item = jsonArray.getJSONObject(elementIndex);
            if (item.keySet().contains(key)) {
                value.set(item.get(key));
                listOfValuesForParticularKey.add(value.toString());
            }
        });
        return listOfValuesForParticularKey;
    }

    /**
     * @param response
     * @param keyName
     * @return
     */
    public static ArrayList<String> getAllKeyValueFromJsonArray(String response, String keyName) {

        ArrayList<String> keyValue = new ArrayList<>();
        try {
            JSONObject jsonObj = new JSONObject(response);
            JSONArray ja = jsonObj.getJSONArray("data");
            int count = ja.length();
            Log.message("count: " + count);
            for (int arrayCount = 0; arrayCount < ja.length(); arrayCount++) {
                JSONObject jObj = ja.getJSONObject(arrayCount);
                keyValue.add(jObj.get(keyName).toString());
            }

            return keyValue;
        } catch (Exception e) {
            e.printStackTrace();
            return keyValue;
        }

    }
}
