package com.savvas.sm.utils.sme187.student.api.licenses;

public interface LicenseConstants {
    String STUDENT_ASSIGNMENT_LAUNCH_DATA_ENDPOINT = "/lms/web/assignments/launchdata/{auId}";
    String LICENSE_RELEASE_END_POINT = "/lms/web/assignments/license/release/{auId}";
    String SIX_TO_EIGHT_READING_THEAME = "/lms/web/assignments/reading/sixeighttheme/{assignmentUserIDValue}?backgroundId={backgroundIdValue}&hue={hueValue}&saturation={saturationValue}";
    String BACKGROUNDID_VALUE = "{backgroundIdValue}";
    String HUE_VALUE = "{hueValue}";
    String SATURATION_VALUE = "{saturationValue}";
    String CHECK_MULTI_ASSIGNMENT_SESSION = "/lms/web/assignments/multiple/session/{auId}";
    String AU_ID = "{auId}";
    String GET_FOCUS_LICENSE_USAGE = "/lms/web/license/organization/allFocusLicenses";

}
