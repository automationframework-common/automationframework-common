package com.savvas.sm.utils.sme187.admin.api.audithistory;

import java.util.HashMap;
import java.util.Map;

import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestHttpClientUtil;

public class AuditHistory extends EnvProperties {
/**
 * This method get the assignments deleted from an organization by the teacher
 * @param smurl
 * @param token
 * @param schoolID
 * @param userID
 * @param districtID
 * @return
 * @throws Exception
 */
    public Map<String, String> getAuditHistoryAssignmentList( String smurl, String token, String schoolID, String userID, String districtID ) throws Exception {
        String endPoint = "/lms/web/api/v1/audit/assignment/" + schoolID;
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( Constants.ORGID_SM_HEADER, districtID );
        headers.put( Constants.USERID_SM_HEADER, userID );
        return RestHttpClientUtil.GET( smurl, endPoint, headers, new HashMap<>() );
    }
}
