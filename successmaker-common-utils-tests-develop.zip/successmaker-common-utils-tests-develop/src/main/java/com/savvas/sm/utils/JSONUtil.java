package com.savvas.sm.utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.skyscreamer.jsonassert.JSONCompare;
import org.skyscreamer.jsonassert.JSONCompareResult;
import org.skyscreamer.jsonassert.JSONParser;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.skyscreamer.jsonassert.JSONCompareMode.LENIENT;
import static org.skyscreamer.jsonassert.JSONCompareMode.STRICT;

public class JSONUtil {

    final public static String IGNORE_LIFECYCLE_DATE_ALL = "_IGNORE_LIFECYCLE_DATE_ALL_";
    final public static String IGNORE_LIFECYCLE_DATE_CREATE = "_IGNORE_LIFECYCLE_DATE_CREATED_";
    final public static String IGNORE_LIFECYCLE_DATE_MODIFIED = "_IGNORE_LIFECYCLE_DATE_MODIFIED_";
    final public static String IGNORE_LIFECYCLE_DATE_DELETE = "_IGNORE_LIFECYCLE_DATE_DELETED_";
    final public static String COMPARISON_PASS_MESSAGE = "Pass";
    final public static String COMPARISON_FAIL_MESSAGE = "Fail";

    final private static String JSON_MATCHING_KEY_FOUND = "___JSON_MATCHING_KEY_FOUND___:";

    /**
     * Converts JSON array string into array of JSON strings
     * 
     * @param arrayJsonObj JSON string starts surrounded [ and ]
     * @return array of JSON objects
     */
    public static String[] toArray( String arrayJsonObj ) {
        String[] array = null;
        try {
            //System.err.println("JSONDoc: "+arrayJsonObj);
            JSONArray ja = new JSONArray( arrayJsonObj );
            array = new String[ja.length()];
            for ( int i = 0; i < ja.length(); i++ ) {
                array[i] = ja.get( i ).toString();
            }
        } catch ( Exception e ) {
            System.err.println( "JSONDoc: " + arrayJsonObj );
            e.printStackTrace();
        }
        return array;
    }

    public static ArrayList<String> toArrayList( String arrayJsonObj ) {
        return new ArrayList<String>( Arrays.asList( JSONUtil.toArray( arrayJsonObj ) ) );
    }

    public static boolean isArray( String arrayJsonObj ) {
        try {
            new JSONArray( arrayJsonObj );
            return true;
        } catch ( JSONException e ) {
            return false;
        }
    }

    public static boolean jsonArrayContains( String jsonObjToLookFor, String arrayJsonObj, String[] exceptionList ) {
        return jsonArrayContains( jsonObjToLookFor, arrayJsonObj, exceptionList, false );
    }

    /**
     * Checks if arrayJsonObj contains Json object 'jsonObjToLookFor'
     * 
     * @param jsonObjToLookFor Json object to look for in the array
     * @param arrayJsonObj Array of Json objects
     * @param exceptionList List of json property paths to ignore. Ex) new
     *            String[]{"path.something.id","path1.something1.timestamp"}
     * @param strict true to compare json strictly
     * @return true if the array contains the Json object
     */
    public static boolean jsonArrayContains( String jsonObjToLookFor, String arrayJsonObj, String[] exceptionList, boolean strict ) {
        boolean pass = false;
        boolean isObjJson = isJSON( jsonObjToLookFor );
        if ( isObjJson && exceptionList instanceof String[] ) {
            for ( String k : exceptionList ) {
                jsonObjToLookFor = setProperty( jsonObjToLookFor, k, null, true );
            }
        }
        try {
            JSONArray ja = new JSONArray( arrayJsonObj );
            for ( int i = 0; i < ja.length(); i++ ) {
                String targetJson = isObjJson ? ja.getJSONObject( i ).toString() : ja.getString( i );
                if ( exceptionList instanceof String[] ) {
                    for ( String k : exceptionList )
                        targetJson = setProperty( targetJson, k, null, true );
                }
                if ( isObjJson ) {
                    if ( JSONCompare.compareJSON( targetJson, jsonObjToLookFor, strict ? STRICT : LENIENT ).passed() ) {
                        pass = true;
                        break;
                    }
                } else if ( jsonObjToLookFor.equals( targetJson ) ) {
                    pass = true;
                    break;
                }
            }
        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return pass;
    }

    public static String jsonCompare( String expected, String actual ) {
        return jsonCompare( expected, actual, new String[] {} );
    }

    /**
     * Compares two non-array JSON objects
     * 
     * @param expected the expected JSON object
     * @param actual the actual JSON object returned from an API
     * @param exceptionList list of JSON properties to be ignored
     * @return "Pass" if the two JSON objects are the same or returns list of
     *         different properties.
     */
    public static String jsonCompare( String expected, String actual, String[] exceptionList ) {
        String testMessage = COMPARISON_FAIL_MESSAGE;
        String expectedErrorMsg = "[expected error]:";
        try {
            JSONCompareResult result = JSONCompare.compareJSON( expected, actual, org.skyscreamer.jsonassert.JSONCompareMode.LENIENT );
            if ( result.failed() && exceptionList != null && exceptionList.length > 0 ) {
                String resultMessage = ( " ; " + result.getMessage() ).replaceAll( "\n", "\\\\n" );
                for ( int i = 0; i < exceptionList.length; i++ ) {
                    if ( exceptionList[i] != null ) {

                        // error message for value not found
                        String valueNotFoundMsgStr = " ; " + exceptionList[i].substring( 0, ( ( exceptionList[i].contains( "." ) ) ? exceptionList[i].lastIndexOf( "." ) : 0 ) ) + "\\nExpected: "
                                + exceptionList[i].substring( ( ( exceptionList[i].contains( "." ) ) ? exceptionList[i].lastIndexOf( "." ) + 1 : 0 ) ) + "\\n     but none found";

                        // error message for element not found in array
                        String regexStr = exceptionList[i].replaceAll( "\\[\\]", "\\\\[.*\\\\]" );
                        String elementNotFoundMsgStr = !exceptionList[i].contains( "[]" ) ? ""
                                : "(.*)( ; )(" + regexStr.substring( 0, regexStr.lastIndexOf( "]" ) + 1 ) + " Could not find match for element \\{\"" + regexStr.substring( regexStr.lastIndexOf( "]." ) + 2 ) + "\":)(.*)(\\})";

                        // error message for value difference of array elements
                        String arrayElementValueDifferenceRegex = "(.*)( ; )(" + regexStr + ")(.*)";

                        // handle value difference
                        if ( resultMessage.contains( " ; " + exceptionList[i] ) ) {
                            resultMessage = resultMessage.replace( " ; " + exceptionList[i], expectedErrorMsg + exceptionList[i] );

                            // handle value difference in an array
                        } else if ( resultMessage.matches( arrayElementValueDifferenceRegex ) ) {
                            resultMessage = expectedError( resultMessage, expectedErrorMsg, arrayElementValueDifferenceRegex );

                            // handle value not found
                        } else if ( resultMessage.contains( valueNotFoundMsgStr ) ) {
                            resultMessage = resultMessage.replace( valueNotFoundMsgStr, expectedErrorMsg + exceptionList[i] );

                            // handle element not found in array
                        } else if ( resultMessage.matches( elementNotFoundMsgStr ) ) {
                            resultMessage = expectedError( resultMessage, expectedErrorMsg, elementNotFoundMsgStr );

                            // compare all the elements manually since the org.skyscreamer.jsonassert.JSONCompare doesn't support
                            String jsonArrayPath = exceptionList[i].substring( 0, exceptionList[i].indexOf( "[" ) );
                            String jsonElemPath = exceptionList[i].substring( exceptionList[i].lastIndexOf( "]." ) + 2 );

                            for ( String elemExpected : getArray( expected, jsonArrayPath ) ) {
                                if ( !JSONUtil.jsonArrayContains( elemExpected, getProperty( actual, jsonArrayPath ), new String[] { jsonElemPath } ) ) {
                                    //System.out.println("elemExpected: "+elemExpected);
                                    //System.out.println("elemActual: "+getProperty(actual, jsonArrayPath));
                                    //System.out.println("Fail,"+jsonElemPath+"=>"+getProperty(getArray(actual, jsonArrayPath)[0],jsonElemPath));
                                    resultMessage += "\n ; " + exceptionList[i] + " Could not find match for element " + elemExpected;
                                }
                            }
                        }
                    }
                }
                if ( resultMessage.contains( " ; " ) ) {
                    testMessage = resultMessage.replaceAll( "\\\\n", "\n" );

                    // handle life cycle date fields
                    Pattern p = Pattern.compile( ";.*(.system.lifecycle.[create|modified|delete]+Date).*", Pattern.MULTILINE );
                    for ( int i = 0; i < exceptionList.length; i++ ) {
                        Matcher m = p.matcher( testMessage );
                        while ( m.find() ) {
                            if ( ( ( IGNORE_LIFECYCLE_DATE_CREATE.equals( exceptionList[i] ) || IGNORE_LIFECYCLE_DATE_ALL.equals( exceptionList[i] ) ) && m.group( 0 ).endsWith( ".createDate" ) )
                                    || ( ( IGNORE_LIFECYCLE_DATE_MODIFIED.equals( exceptionList[i] ) || IGNORE_LIFECYCLE_DATE_ALL.equals( exceptionList[i] ) ) && m.group( 0 ).endsWith( ".modifiedDate" ) )
                                    || ( ( IGNORE_LIFECYCLE_DATE_DELETE.equals( exceptionList[i] ) || IGNORE_LIFECYCLE_DATE_ALL.equals( exceptionList[i] ) ) && m.group( 0 ).endsWith( ".deleteDate" ) ) ) {
                                testMessage = testMessage.replace( m.group( 0 ), expectedErrorMsg + m.group( 0 ).substring( 2 ) );
                            }
                        }
                    }
                    if ( !testMessage.contains( " ; " ) ) {
                        testMessage = COMPARISON_PASS_MESSAGE;
                    }
                } else {
                    testMessage = COMPARISON_PASS_MESSAGE;
                }
            } else if ( result.passed() ) {
                testMessage = COMPARISON_PASS_MESSAGE;
            } else if ( !result.passed() ) {
                testMessage = result.getMessage();
            }
        } catch ( JSONException e ) {
            e.printStackTrace();
        }

        return testMessage;
    }

    private static String expectedError( String resultMessage, String expectedErrorMsg, String regex ) {
        String msg = resultMessage;
        while ( msg.matches( regex ) ) {
            Pattern pattern = Pattern.compile( regex );
            Matcher matcher = pattern.matcher( msg );
            if ( matcher.find() ) {
                msg = matcher.group( 1 ) + expectedErrorMsg;
                for ( int j = 3; j <= matcher.groupCount(); j++ )
                    msg += matcher.group( j );
            }
        }
        return msg == null ? resultMessage : msg;
    }

    /**
     * Reorder JSON object
     * 
     * @param jsonObject the JSON object to be re-ordered
     * @return re-ordered JSON object
     */
    public static String reorder( String jsonObject ) {
        try {
            return JSONParser.parseJSON( jsonObject ).toString();
        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Append value to an existing property value
     * 
     * @param jsonObject the source JSON object
     * @param propertyPath the property path
     * @param value value to append
     * @return the updated JSON object
     */
    public static String appendProperty( String jsonObject, String propertyPath, Object value ) {
        return JSONUtil.setProperty( jsonObject, propertyPath, JSONUtil.getProperty( jsonObject, propertyPath ) + value );
    }

    /**
     * Remove a property
     * 
     * @param jsonObject the source JSON object
     * @param propertyPath the property path
     * @return the updated JSON object
     */
    public static String removeProperty( String jsonObject, String propertyPath ) {
        String jsonStr = null;
        try {
            // root object
            JSONObject obj = (JSONObject) JSONParser.parseJSON( jsonObject );
            obj.remove( propertyPath );
            jsonStr = obj.toString();
        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return jsonStr;
    }

    public static String setPropertyUpsert( String jsonObject, String propertyPath, Object value ) {
        return setProperty( jsonObject, propertyPath, value, true );
    }

    public static String setProperty( String jsonObject, String propertyPath, Object value ) {
        return setProperty( jsonObject, propertyPath, value, false );
    }

    /**
     * Sets a new property value
     * 
     * @param jsonObject the source JSON object
     * @param propertyPath the property path
     * @param valueOrJSONArray value or org.json.JSONArray() object
     * @param ignoreNull true to ignore null value or add new value if specific
     *            path doesn't exist
     * @return the updated JSON object
     */
    /*
     * TODO: 2013.08.26 - need to update this with new methods? value =
     * getJSONObjectAsString(jo, path[i]); jo = getJSONObject(jo,path[i]);
     */
    public static String setProperty( String jsonObject, String propertyPath, Object valueOrJSONArray, boolean ignoreNull ) {

        String jsonStr = null;
        try {

            // root object
            JSONObject obj = (JSONObject) JSONParser.parseJSON( jsonObject );

            // working object
            JSONObject jo = obj;
            JSONObject parentJo = null;
            String[] path = propertyPath.split( "\\." );
            for ( int i = 0; i < path.length; i++ ) {
                //System.out.println(path[i]+"=>"+jo);
                //System.out.println("path: "+path[i]);
                try {
                    // handles JSON array
                    // path example: studentSchoolEnrollmentList[entryGradeLevel=8]
                    String arrayPatern = "(\\w+)\\[(\\w+)=(\\w+)\\]";
                    String arrayPatern2 = "(\\w+)\\[(\\d+)]";
                    if ( path[i].matches( arrayPatern ) ) {
                        Pattern pattern = Pattern.compile( arrayPatern );
                        Matcher matcher = pattern.matcher( path[i] );
                        matcher.find();
                        JSONArray array = jo.getJSONArray( matcher.group( 1 ) );
                        boolean isKeyValueFound = false;
                        for ( int j = 0; j < array.length(); j++ ) {
                            if ( array.get( j ) instanceof JSONObject ) {
                                JSONObject targetCandidate = (JSONObject) array.get( j );
                                while ( targetCandidate.keys().hasNext() ) {
                                    String k = (String) targetCandidate.keys().next();
                                    if ( k.equals( matcher.group( 2 ) ) && matcher.group( 3 ).equals( targetCandidate.getString( k ) ) ) {
                                        //System.out.println("key&value found: "+k+" => "+targetCandidate.getString(k));
                                        parentJo = jo;
                                        jo = targetCandidate;
                                        isKeyValueFound = true;
                                        break;
                                    }
                                }
                            }
                            if ( isKeyValueFound )
                                break;
                        }
                    } else if ( path[i].matches( arrayPatern2 ) ) {
                        Pattern pattern = Pattern.compile( arrayPatern2 );
                        Matcher matcher = pattern.matcher( path[i] );
                        matcher.find();
                        JSONArray array = jo.getJSONArray( matcher.group( 1 ) );
                        int index = Integer.parseInt( matcher.group( 2 ) );
                        if ( index < array.length() ) {
                            parentJo = jo;
                            jo = (JSONObject) array.get( index );
                            //System.out.println("index&value found: "+index+" => "+jo);
                        }
                    } else {
                        // create a new JSONObject if the end path doesn't exist
                        if ( ignoreNull && !( i + 1 < path.length ) && !jo.has( path[i] ) ) {
                            //jo.append(path[i], new JSONObject());
                            jo.put( path[i], new JSONObject() );
                        }
                        parentJo = jo;
                        jo = jo.getJSONObject( path[i] );
                    }

                    // update value if it's the end of path
                    if ( !( i + 1 < path.length ) ) {
                        // convert array object to JSONArray
                        if ( valueOrJSONArray != null ) {
                            if ( valueOrJSONArray.getClass().isArray() ) {
                                valueOrJSONArray = new JSONArray( valueOrJSONArray );
                            } else if ( valueOrJSONArray instanceof JSONArray ) {
                                // do nothing
                            }
                        }
                        parentJo.put( path[i], valueOrJSONArray );
                    }
                } catch ( JSONException e ) {
                    if ( e.getMessage().endsWith( "is not a JSONObject." ) ||
                    // the property is already removed
                            ( valueOrJSONArray == null && e.getMessage().endsWith( "not found." ) && ignoreNull ) ) {
                        // update property
                        if ( valueOrJSONArray != null && valueOrJSONArray.getClass().isArray() ) {
                            valueOrJSONArray = new JSONArray( valueOrJSONArray );
                        }
                        jo.put( path[i], valueOrJSONArray );
                    } else if ( e.getMessage().endsWith( "cannot be converted to JSONObject" ) ) {
                        jo.put( path[i], valueOrJSONArray );
                    } else {
                        jsonStr = null;
                        e.printStackTrace();
                        break;
                    }
                }
            }
            jsonStr = obj.toString();
        } catch ( JSONException e ) {
            jsonStr = null;
            e.printStackTrace();
        }

        return jsonStr;
    }

    /**
     * Get an array from JSON object
     * 
     * @param jsonObject the source JSON object
     * @param propertyPath the property path
     * @return list of values from the property
     */
    public static String[] getArray( String jsonObject, String propertyPath ) {
        return toArray( getProperty( jsonObject, propertyPath, true ) );
    }

    /**
     * Get a value from JSON object
     * 
     * @param jsonObject the source JSON object
     * @param propertyPath the property path
     * @return value of the property
     */
    public static String getProperty( String jsonObject, String propertyPath ) {
        return getProperty( jsonObject, propertyPath, true );
    }

    public static String getProperty( String jsonObject, String propertyPath, boolean noError ) {
        String value = null;
        String[] path = propertyPath.split( "\\." );
        try {
            JSONObject jo = (JSONObject) JSONParser.parseJSON( jsonObject );
            for ( int i = 0; i < path.length; i++ ) {
                //System.out.println(path[i]+"=>"+jo);
                try {
                    // get value
                    //System.out.println("before: "+value+", "+path[i]+", "+jo);
                    value = getJSONObjectAsString( jo, path[i] );
                    //System.out.println("after: "+value+", "+path[i]+", "+jo.getClass());
                    Object o = getJSONObject( jo, path[i] );
                    if ( o instanceof JSONObject ) {
                        jo = (JSONObject) o;
                    }
                    if ( i == path.length - 1 && o != null )
                        return o.toString();
                } catch ( JSONException e ) {
                    // ignore error if path hit the end
                    if ( !e.getMessage().startsWith( JSON_MATCHING_KEY_FOUND ) ) {
                        if ( !noError )
                            e.printStackTrace();
                        value = null;
                        break;
                    }
                }
            }
        } catch ( ClassCastException cce ) {
            if ( path[0].startsWith( "[" ) ) {
                int idx = Integer.valueOf( path[0].substring( 1, path[0].length() - 1 ) );
                try {
                    if ( path.length > 1 ) {
                        return getProperty( new JSONArray( jsonObject ).getString( idx ), propertyPath.substring( propertyPath.indexOf( "." ) + 1 ), noError );
                    } else {
                        return toArray( jsonObject )[idx];
                    }
                } catch ( NumberFormatException | JSONException e ) {
                    e.printStackTrace();
                }
            }
        } catch ( JSONException e ) {
            value = null;
            if ( !noError )
                e.printStackTrace();
        }
        return value;
    }

    /**
     * Returns true if specified property path exists
     * 
     * @param jsonObject
     * @param propertyPath
     * @return boolean
     */
    public static boolean propertyExists( String jsonObject, String propertyPath ) {
        return getProperty( jsonObject, propertyPath, true ) != null;
    }

    /**
     * Returns JSON document converted from XML document
     * 
     * @param xmlDocument
     * @return JSONDocument
     */
    public static String convertXMLtoJSON( String xml ) throws JSONException {
        JSONObject jsonObj = XML.toJSONObject( xml, true );
        return jsonObj.toString();
    }

    /**
     * Returns JSON document converted with namespace removed from XML document
     * 
     * @param xmlDocument
     * @return JSONDocument
     */
    public static String convertXMLtoJSONWithoutNS( String xml ) throws JSONException {
        // source: http://stackoverflow.com/questions/4661154/how-do-i-remove-namespaces-from-xml-using-java-dom
        xml = xml.replaceAll( "(<\\?[^<]*\\?>)?", "" ) // remove preamble
                .replaceAll( "xmlns.*?(\"|\').*?(\"|\')", "" ) // remove xmlns declaration
                .replaceAll( "(<)(\\w+:)(.*?>)", "$1$3" ) // remove opening tag prefix
                .replaceAll( "(</)(\\w+:)(.*?>)", "$1$3" ); // remove closing tags prefix
        JSONObject jsonObj = XML.toJSONObject( xml, true );
        return jsonObj.toString();
    }

    // JSON array handler
    private static String getJSONObjectAsString( JSONObject jo, String path ) throws JSONException {
        try {
            //System.out.println("before jo: "+path+" ----->"+jo);

            String result = null;
            if ( isString( jo, path ) )
                result = jo.getString( path );
            else if ( isJSONArray( jo, path ) )
                result = jo.getJSONArray( path ).toString();
            else if ( isInt( jo, path ) )
                result = String.valueOf( jo.getInt( path ) );
            else if ( isLong( jo, path ) )
                result = String.valueOf( jo.getLong( path ) );
            else if ( isBoolean( jo, path ) )
                result = String.valueOf( jo.getBoolean( path ) );
            else if ( isDouble( jo, path ) )
                result = String.valueOf( jo.getDouble( path ) );
            //System.out.println("after jo: "+path+" ----->"+jo);
            //System.out.println("isJSONObj: "+result);
            return result;
            //return o != null ? o.toString() : null;
        } catch ( JSONException je ) {
            je.printStackTrace();
            if ( je.getMessage().contains( JSON_MATCHING_KEY_FOUND ) ) {
                return je.getMessage().substring( JSON_MATCHING_KEY_FOUND.length() );
            }
        }
        return null;
    }

    private static Object getJSONObject( JSONObject jo, String path ) throws JSONException {
        if ( jo instanceof JSONObject ) {
            if ( path instanceof String && path.length() > 0 ) {
                if ( path.matches( ".*\\[[0-9]+\\]" ) ) { // if path = array[0]
                    //System.out.println("Array path ["+path+"] found.");
                    JSONArray ja = jo.getJSONArray( path.substring( 0, path.indexOf( "[" ) ) );
                    Object o = ja.get( Integer.parseInt( path.substring( path.indexOf( "[" ) + 1, path.lastIndexOf( "]" ) ) ) );
                    if ( o instanceof JSONObject ) {
                        jo = (JSONObject) o;
                        return o; //o.toString();
                    } else {
                        return o;
                    }
                } else if ( path.matches( ".*\\[.+=.+\\]" ) ) { // if path = array[propertyName=key]
                    //System.out.println("Array path ["+path+"] found.");
                    JSONArray ja = jo.getJSONArray( path.substring( 0, path.indexOf( "[" ) ) );
                    String kvPair[] = path.substring( path.indexOf( "[" ) + 1, path.lastIndexOf( "]" ) ).split( "=" );
                    int elementFound = 0;
                    for ( int i = 0; i < ja.length(); i++ ) {
                        if ( ja.getJSONObject( i ).getString( kvPair[0] ).equals( kvPair[1] ) ) {
                            jo = ja.getJSONObject( i );
                            elementFound++;
                        }
                    }
                    if ( elementFound == 0 ) {
                        throw new JSONException( "Element not found: " + path );
                    } else if ( elementFound > 1 ) {
                        throw new JSONException( "Element key is not unique; " + elementFound + " elements found: " + path );
                    }
                } else { // if path = property name
                    try {
                        //System.out.println("JSON property path ["+path+"] found.");
                        if ( isJSONObject( jo, path ) )
                            jo = (JSONObject) jo.getJSONObject( path );
                        else
                            throw new JSONException( JSON_MATCHING_KEY_FOUND + path );

                    } catch ( JSONException je ) {
                        //System.out.println("jsonobj of path["+path+"]:"+jo);
                        throw new JSONException( JSON_MATCHING_KEY_FOUND + path );
                    }
                }
                return jo;
            }
        }
        return null;
    }

    public static boolean isJSON( String str ) {
        try {
            new JSONObject( str );
        } catch ( JSONException ex ) {
            try {
                new JSONArray( str );
            } catch ( JSONException ex1 ) {
                return false;
            }
        }
        return true;
    }

    private static boolean isJSONObject( JSONObject jo, String path ) {
        try {
            jo.getJSONObject( path );
        } catch ( JSONException e ) {
            return false;
        }
        return true;
    }

    private static boolean isJSONArray( JSONObject jo, String path ) {
        try {
            jo.getJSONArray( path );
        } catch ( JSONException e ) {
            return false;
        }
        return true;
    }

    private static boolean isString( JSONObject jo, String path ) {
        try {
            jo.getString( path );
        } catch ( JSONException e ) {
            return false;
        }
        return true;
    }

    private static boolean isBoolean( JSONObject jo, String path ) {
        try {
            jo.getBoolean( path );
        } catch ( JSONException e ) {
            return false;
        }
        return true;
    }

    private static boolean isInt( JSONObject jo, String path ) {
        try {
            jo.getInt( path );
        } catch ( JSONException e ) {
            return false;
        }
        return true;
    }

    private static boolean isLong( JSONObject jo, String path ) {
        try {
            jo.getLong( path );
        } catch ( JSONException e ) {
            return false;
        }
        return true;
    }

    private static boolean isDouble( JSONObject jo, String path ) {
        try {
            jo.getDouble( path );
        } catch ( JSONException e ) {
            return false;
        }
        return true;
    }

}
