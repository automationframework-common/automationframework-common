package com.savvas.sm.utils.sme187.admin.api.sharedcourse;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import io.restassured.response.Response;

public class SharedCourses extends EnvProperties {

    public static String isItMt = configProperty.getProperty( "isMTExecution" );

    /***
     * getSharedCourseList() -> This method get the shared courses in all
     * organization
     * 
     * @param smUrl - The URL can be basic, auto and MSMN. Basic:
     *            https://nightly-next-basic.smdemo.info Auto:
     *            https://nightly-next-auto.smdemo.info MSMN:
     *            https://nightly-next-automsmn.smdemo.info
     * 
     * @param headers - Headers must contain the content-type, orgId, userId &
     *            Authorization The Keys to be given as follows:
     *            Constants.CONTENT_TYPE OrganizationAPIConstants.ORGID
     *            OrganizationAPIConstants.USERID
     *            OrganizationAPIConstants.AUTHORISATION
     * 
     * @return response -> The Get Call response will be given as a
     *         HashMap<String,String>
     * @throws Exception
     */
    public Map<String, String> getSharedCourseList( String smUrl, Map<String, String> headers, String selectedOrgId ) throws Exception {
        Map<String, String> params = new HashMap<>();
        params.put( AdminConstants.SELECTED_ORGANIZATION_ID, selectedOrgId );
        return RestHttpClientUtil.GET( smUrl, AdminConstants.GET_SHARED_COURSE, headers, params );
    }

    /***
     * editShareCourseList() -> This method edit the shared course given.
     * 
     * @param smUrl - The URL can be basic, auto and MSMN. Basic:
     *            https://nightly-next-basic.smdemo.info Auto:
     *            https://nightly-next-auto.smdemo.info MSMN:
     *            https://nightly-next-automsmn.smdemo.info
     * 
     * @param headers - Headers must contain the content-type, orgId, userId &
     *            Authorization The Keys to be given as follows:
     *            Constants.CONTENT_TYPE OrganizationAPIConstants.ORGID
     *            OrganizationAPIConstants.USERID
     *            OrganizationAPIConstants.AUTHORISATION
     * @param organizationIds -> The organization(s) to be shared with should be
     *            given as a String[]
     * @param courseID -> The Course ID of the Course to be shared with the
     *            organizations
     * 
     * @return response -> The Get Call response will be given as a
     *         HashMap<String,String>
     * @throws Exception
     */
    public Map<String, String> editShareCourseList( String smUrl, Map<String, String> headers, String[] organizationIds, String courseID, String selectedOrgId ) throws Exception {
        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "editSharedCourse.json" ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), AdminConstants.ORGANIZATION_IDS, organizationIds ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), AdminConstants.COURSE_ID, courseID ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), AdminConstants.SELECTED_ORGANIZATION_ID, selectedOrgId ) );
        return RestHttpClientUtil.PUT( smUrl, headers, new HashMap<>(), AdminConstants.GET_SHARED_COURSE, requestBody.get() );
    }

    /**
     * This method post a graphQL call for getting the Shared courses in Admin
     * dashboard.
     * 
     * @param smurl - The URL can be basic, auto and MSMN. Basic:
     *            https://nightly-next-basic.smdemo.info Auto:
     *            https://nightly-next-auto.smdemo.info MSMN:
     *            https://nightly-next-automsmn.smdemo.info
     * 
     * @param headers - Header should contain the authorization token for the
     *            graphQL call. Header key Should be Constants.AUTHORIZATION
     * @param userID - Admin user ID should be passed as a <String>
     * @param orgID - Organization ID of the User should be passed as a <String>
     * @param queryItems - This list should contains the fields that are
     *            required in the response. The queryItems should contain
     *            following items as a values. AdminConstants.ID,
     *            AdminConstants.COURSE_NAME, AdminConstants.OWNER_ORG_ID,
     *            AdminConstants.OWNER_ORG_NAME, AdminConstants.SHARED_ORG_COUNT
     * @author bharathi.murugan
     * @return Response - returns the response of the getSharedCourseBFF GraphQL
     *         call
     * 
     */
    public Response postSharedCourse_BFF( Map<String, String> headers, String userID, String orgID, List<String> queryItems, String selectedOrgId ) {
        String query = AdminConstants.SHARED_COURSE_PAYLOAD;
        query = query.replace( Constants.USER_ID_VALUE, userID );
        query = query.replace( Constants.ORG_ID, orgID );
        query = query.replace( AdminConstants.SELECTED_ORG_ID, selectedOrgId );
        StringBuilder frameQuery = new StringBuilder();
        frameQuery.append( "{" );
        queryItems.forEach( querItem -> {
            if ( frameQuery.toString().equals( "{" ) ) {
                frameQuery.append( querItem );
            } else {
                frameQuery.append( "," + querItem );
            }
        } );
        frameQuery.append( "}" );
        query = query.replace( AdminConstants.QUERY_ITEM, frameQuery.toString() );
        return RestAssuredAPIUtil.POSTGraphQl( AdminConstants.SHARED_COURSE_BFF, headers, query, AdminConstants.GRAPHQL_ENDPOINT );
    }

    /**
     * This method post a graphQL call for getting the course shared
     * organization in Admin dashboard.
     * 
     * @param smurl - The URL can be basic, auto and MSMN. Basic:
     *            https://nightly-next-basic.smdemo.info Auto:
     *            https://nightly-next-auto.smdemo.info MSMN:
     *            https://nightly-next-automsmn.smdemo.info
     * 
     * @param headers - Header should contain the authorization token for the
     *            graphQL call. Header key Should be Constants.AUTHORIZATION
     * @param userID - Admin user ID should be passed as a <String>
     * @param orgID - Organization ID of the User should be passed as a <String>
     * @param queryItems - This list should contains the fields that are
     *            required in the response. The queryItems should contain
     *            following items as a values. AdminConstants.ID,
     *            AdminConstants.COURSE_NAME, AdminConstants.OWNER_ORG_ID,
     *            AdminConstants.OWNER_ORG_NAME, AdminConstants.SHARED_ORG_COUNT
     * @author bharathi.murugan
     * @return Response - returns the response of the getSharedCourseBFF GraphQL
     *         call
     * 
     */
    public Response postSharedCourseOrganization_BFF( Map<String, String> headers, String userId, String orgId, String courseId, List<String> queryItems, String selectedOrgId ) {

        String query = AdminConstants.COURSE_SHARED_ORGANIZATIONS_PAYLOAD;
        query = query.replace( Constants.USER_ID_VALUE, userId );
        query = query.replace( Constants.ORG_ID, orgId );
        query = query.replace( Constants.COURSE_ID, courseId );
        query = query.replace( AdminConstants.SELECTED_ORG_ID, selectedOrgId );
        StringBuilder frameQuery = new StringBuilder();
        frameQuery.append( "{" );
        queryItems.forEach( querItem -> {
            if ( frameQuery.toString().equals( "{" ) ) {
                frameQuery.append( querItem );
            } else {
                frameQuery.append( "," + querItem );
            }
        } );
        frameQuery.append( "}" );

        query = query.replace( AdminConstants.QUERY_ITEM, frameQuery.toString() );
        return RestAssuredAPIUtil.POSTGraphQl( AdminConstants.SHARED_COURSE_BFF, headers, query, AdminConstants.GRAPHQL_ENDPOINT );
    }

    /**
     * To create a custom course
     * 
     * @param smUrl
     * @param token
     * @param subject
     * @param teacherID
     * @param orgID
     * @param courseType
     * @param courseName
     * @param jsonFileName
     * @return
     * @throws Exception
     */
    public String createCustomCourse( String smUrl, String token, String subject, String teacherID, String orgID, String courseType, String courseName ) throws Exception {
        HashMap<String, String> response_post = new HashMap<>();
        try {
            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + token );
            headers.put( Constants.USERID_SM_HEADER, teacherID );
            headers.put( Constants.ORGID_SM_HEADER, orgID );
            // Input Params
            HashMap<String, String> params = new HashMap<>();

            // EndPoint Details
            String endPoint_post = AdminConstants.CUSTOM_COURSE;
            if ( subject.contentEquals( DataSetupConstants.MATH ) ) {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "1" );
            } else {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "2" );
            }

            endPoint_post = endPoint_post.replace( Constants.ORG_ID, orgID );
            endPoint_post = endPoint_post.replace( Constants.STAFF_ID, teacherID );

            Map<String, String> courseDetails = new HashMap<String, String>();
            courseDetails.put( Constants.COURSE_NAME, courseName );
            String requestBody = null;
            if ( courseType.equalsIgnoreCase( DataSetupConstants.SETTINGS ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = generateRequestBody( SMUtils.getPayload( PayloadFor.ADMIN, "customBySettingsSharedCourse_MATH.json" ), courseDetails );
                } else {
                    requestBody = generateRequestBody( SMUtils.getPayload( PayloadFor.ADMIN, "customBySettingsSharedCourse_READING.json" ), courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.SKILL ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = generateRequestBody( SMUtils.getPayload( PayloadFor.ADMIN, "customBySkillsSharedCourse_MATH.json" ), courseDetails );
                } else {
                    requestBody = generateRequestBody( SMUtils.getPayload( PayloadFor.ADMIN, "customBySkillsSharedCourse_READING.json" ), courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.STANDARD ) ) {
                List<String> standardDetails = new ArrayList<>();

                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    standardDetails = UserSqlHelper.getRandomStandardGradeID( CommonAPIConstants.ADMIN, DataSetupConstants.MATH, isItMt.equalsIgnoreCase( "true" ) );
                } else {
                    standardDetails = UserSqlHelper.getRandomStandardGradeID( CommonAPIConstants.ADMIN, DataSetupConstants.READING, isItMt.equalsIgnoreCase( "true" ) );
                }

                List<String> listLO = UserSqlHelper.getLOIDsRandomStandard( CommonAPIConstants.ADMIN, standardDetails.get( 0 ), standardDetails.get( 1 ), isItMt.equalsIgnoreCase( "true" ) );
                courseDetails.put( Constants.STANDARDFRAMEWORK_ID, standardDetails.get( 0 ) );
                courseDetails.put( Constants.GRADE_ID, standardDetails.get( 1 ) );
                courseDetails.put( Constants.BANKID, listLO.get( 0 ).split( "_" )[3] ); //To get Bank ID from LO
                courseDetails.put( Constants.LOID, listLO.get( 0 ) );
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = generateRequestBody( SMUtils.getPayload( PayloadFor.ADMIN, "customByStandardsRandomSharedCourse_MATH.json" ), courseDetails );
                } else {
                    requestBody = generateRequestBody( SMUtils.getPayload( PayloadFor.ADMIN, "customByStandardsRandomSharedCourse_READING.json" ), courseDetails );
                }

            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.ONE_LO ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = generateRequestBody( DataSetupConstants.CUSTOM_BY_SKILL_ONE_LO, courseDetails );
                }
            }
            response_post = RestHttpClientUtil.POST( smUrl, headers, params, endPoint_post, requestBody );
            Log.message( response_post + "" );
            if ( response_post.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                return SMUtils.getKeyValueFromResponse( response_post.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.REPORT_COURSEID );
            } else {
                return response_post.get( Constants.REPORT_BODY );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response_post.get( Constants.REPORT_BODY );
    }

    /**
     * This method generates the request body required for API.
     * 
     * @param requestBodyTemplate
     * @param requestDetails
     * @return
     */
    public String generateRequestBody( String requestBodyTemplate, Map<String, String> requestDetails ) {
        String requestBody = requestBodyTemplate;
        if ( requestBody.contains( Constants.GROUPNAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.GROUPNAME_VALUE, requestDetails.get( Constants.GROUP_NAME ) );
        }
        if ( requestBody.contains( Constants.STUDENT_IDS_VALUE ) ) {
            requestBody = requestBody.replace( Constants.STUDENT_IDS_VALUE, requestDetails.get( Constants.STUDENT_ID ) );
        }
        if ( requestBody.contains( Constants.GROUP_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.GROUP_ID_VALUE, requestDetails.get( Constants.GROUP_ID ) );
        }
        if ( requestBody.contains( Constants.SCHOOL_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.SCHOOL_ID_VALUE, requestDetails.get( Constants.SCHOOL_ID ) );
        }
        if ( requestBody.contains( Constants.FIRST_NAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.FIRST_NAME_VALUE, requestDetails.get( Constants.FIRSTNAME ) );
        }
        if ( requestBody.contains( Constants.MIDDLE_NAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.MIDDLE_NAME_VALUE, requestDetails.get( Constants.MIDDLENAME ) );
        }
        if ( requestBody.contains( Constants.LAST_NAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.LAST_NAME_VALUE, requestDetails.get( Constants.LASTNAME ) );
        }
        if ( requestBody.contains( Constants.USERNAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.USERNAME_VALUE, requestDetails.get( Constants.USER_NAME ) );
        }
        if ( requestBody.contains( Constants.TEACHER_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.TEACHER_ID_VALUE, requestDetails.get( Constants.TEACHER_ID ) );
        }
        if ( requestBody.contains( Constants.USERID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.USERID_VALUE, requestDetails.get( Constants.USER_ID ) );
        }
        if ( requestBody.contains( Constants.GRADE_VALUE ) ) {
            requestBody = requestBody.replace( Constants.GRADE_VALUE, requestDetails.get( Constants.GRADE ) );
        }
        if ( requestBody.contains( Constants.COURSENAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.COURSENAME_VALUE, requestDetails.get( Constants.COURSE_NAME ) );
        }
        if ( requestBody.contains( Constants.ASSIGNMENT_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.ASSIGNMENT_ID_VALUE, requestDetails.get( Constants.ASSIGNMENT_ID ) );
        }
        if ( requestBody.contains( Constants.ASSIGNMENT_USER_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.ASSIGNMENT_USER_ID_VALUE, requestDetails.get( Constants.ASSIGNMENT_USER_ID ) );
        }
        if ( requestBody.contains( Constants.GRADE_ID ) ) {
            requestBody = requestBody.replace( Constants.GRADE_ID, requestDetails.get( Constants.GRADE_ID ) );
        }
        if ( requestBody.contains( Constants.STANDARDFRAMEWORK_ID ) ) {
            requestBody = requestBody.replace( Constants.STANDARDFRAMEWORK_ID, requestDetails.get( Constants.STANDARDFRAMEWORK_ID ) );
        }
        if ( requestBody.contains( Constants.BANKID ) ) {
            requestBody = requestBody.replace( Constants.BANKID, requestDetails.get( Constants.BANKID ) );
        }
        if ( requestBody.contains( Constants.LOID ) ) {
            requestBody = requestBody.replace( Constants.LOID, requestDetails.get( Constants.LOID ) );
        }
        if ( requestBody.contains( Constants.SUBJECT_TYPE_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.SUBJECT_TYPE_ID_VALUE, requestDetails.get( Constants.SUBJECT_ID ) );
        }
        if ( requestBody.contains( Constants.PAYLOAD_ASSIGNMENT_USER_IDS ) ) {
            requestBody = requestBody.replace( Constants.PAYLOAD_ASSIGNMENT_USER_IDS, requestDetails.get( Constants.ASSIGNMENT_USER_ID ) );
        }
        if ( requestBody.contains( Constants.PAYLOAD_SUBJECT_TYPE_ID ) ) {
            requestBody = requestBody.replace( Constants.PAYLOAD_SUBJECT_TYPE_ID, requestDetails.get( Constants.SUBJECT_ID ) );
        }

        if ( requestBody.contains( Constants.COURSE_ID ) ) {
            requestBody = requestBody.replace( Constants.COURSE_ID, requestDetails.get( Constants.COURSE_ID ) );
        }
        if ( requestBody.contains( Constants.COURSE_ID ) ) {
            requestBody = requestBody.replace( Constants.COURSE_ID, requestDetails.get( Constants.COURSE_ID ) );
        }
        if ( requestBody.contains( Constants.ORG_ID ) ) {
            requestBody = requestBody.replace( Constants.ORG_ID, requestDetails.get( Constants.ORG_ID ) );
        }
        if ( requestBody.contains( Constants.CONTENT_BASE_TYPE ) ) {
            requestBody = requestBody.replace( Constants.CONTENT_BASE_TYPE, requestDetails.get( Constants.CONTENT_BASE_TYPE ) );
        }

        return requestBody;
    }

    /**
     * This method is used to delete the course
     * 
     * @param smUrl
     * @param username
     * @param password
     * @param userId
     * @param orgId
     * @param courseId
     * @return
     * @throws Exception
     */
    public Map<String, String> deleteCourse( String smUrl, String username, String password, String userId, String orgId, String courseId ) throws Exception {

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( username, password ) );
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        // Input Params
        HashMap<String, String> params = new HashMap<>();

        String endPoint = AdminConstants.DELETE_COURSE_API;

        endPoint = endPoint.replace( Constants.ORG_ID, orgId );
        endPoint = endPoint.replace( Constants.STAFF_ID, userId );
        endPoint = endPoint.replace( Constants.COURSE_ID, courseId );
        return RestHttpClientUtil.DELETE( smUrl, endPoint, headers, params );
    }

    public void updateSharedCourse( String smurl, String username, String password, String userId, String orgId, String courseId, String courseName, String contentBaseTypeId, String isShared, String enrollmentId ) throws Exception {
        String endPoint = AdminConstants.DELETE_COURSE_API;
        endPoint = endPoint.replace( Constants.ORG_ID, orgId );
        endPoint = endPoint.replace( Constants.STAFF_ID, userId );
        endPoint = endPoint.replace( Constants.COURSE_ID, courseId );

        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( username, password ) );
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        String payload = SMUtils.getPayload( PayloadFor.ADMIN, "UpdateSharedCourseSetting.json" );
        payload = payload.replace( "{courseName}", courseName );
        payload = payload.replace( "{contentBaseTypeId}", contentBaseTypeId );
        payload = payload.replace( "{isShared}", isShared );
        payload = payload.replace( "{id}", enrollmentId );

        RestHttpClientUtil.PUT( smurl, headers, new HashMap<>(), endPoint, payload );
    }

    /**
     * This method is used to get shared course organization list
     * 
     * @param smUrl
     * @param username
     * @param password
     * @param userId
     * @param orgId
     * @param courseId
     * @return
     * @throws Exception
     */
    public Map<String, String> getSharedCourseOrgList( String smUrl, Map<String, String> headers, String courseId, String selectedOrgId ) throws Exception {
        String endPoint = AdminConstants.GET_SHARED_COURSE_ORG_LIST;
        endPoint = endPoint.replace( Constants.COURSE_ID, courseId );
        Map<String, String> params = new HashMap<String, String>();
        params.put( AdminConstants.SELECTED_ORGANIZATION_ID, selectedOrgId );
        return RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
    }

    /**
     * This method post graphQL call for edit the course share save organization
     * in Admin dashboard.
     *
     * @param smurl - The URL can be basic, auto and MSMN. Basic:
     *            https://nightly-next-basic.smdemo.info Auto:
     *
     *
     * @param headers - Header should contain the authorization token for the
     *            graphQL call. Header key Should be Constants.AUTHORIZATION
     * @param userID - Admin user ID should be passed as a <String>
     * @param orgID - Organization ID of the User should be passed as a <String>
     * @param queryItems
     * @author bharathi.murugan
     * @return Response - returns the response of the getSharedCourseBFF GraphQL
     *         call
     *
     */
    public Response EditSharedCourse_BFF( Map<String, String> headers, String userId, String orgId, String courseId, List<String> courseSharedOrgIds, String queryItem, String selectedOrgId ) {

        String query = AdminConstants.EDIT_SHARED_COURSE_PAYLOAD;
        query = query.replace( Constants.USER_ID_VALUE, userId );
        query = query.replace( Constants.ORG_ID, orgId );
        query = query.replace( Constants.COURSE_ID, courseId );
        query = query.replace( AdminConstants.SELECTED_ORG_ID, selectedOrgId );
        StringBuilder orgIds = new StringBuilder();
        orgIds.append( "\\\"" );
        courseSharedOrgIds.forEach( querItem -> {
            if ( orgIds.toString().equals( "\\\"" ) ) {
                orgIds.append( querItem + "\\\"" );
            } else {
                orgIds.append( ",\\\"" + querItem + "\\\"" );
            }
        } );

        query = query.replace( AdminConstants.SHARED_ORG_IDS, orgIds.toString() );
        query = query.replace( AdminConstants.QUERY_ITEMS, queryItem );
        Log.message( query );
        return RestAssuredAPIUtil.POSTGraphQl( AdminConstants.SHARED_COURSE_BFF, headers, query, AdminConstants.GRAPHQL_ENDPOINT );
    }

}
