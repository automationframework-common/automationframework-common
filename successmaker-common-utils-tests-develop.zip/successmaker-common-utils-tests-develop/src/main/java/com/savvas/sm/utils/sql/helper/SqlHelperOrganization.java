package com.savvas.sm.utils.sql.helper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.learningservices.utils.Log;
import com.savvas.sm.data.sme7.DataSetupProcessor;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SQLUtil;

public class SqlHelperOrganization extends DataSetupProcessor {

    /**
     * 
     * @param organizationName
     * @param organizationDistrictNum
     * @return
     */
    public Integer createOrganization( String organizationName, String organizationDistrictNum ) {

        // Log.message( "Creating school -> " + organizationName );
        Object[] params = { organizationName, DataSetupConstants.SCHOOL_ORG_TYPE_ID, organizationDistrictNum, DataSetupConstants.DEFAULT_DISTRICT_ID, DataSetupConstants.SIF_REF_ID, organizationName };
        int orgId = SQLUtil.executeFunction( "{call successmaker.create_organization(?,?,?,?,?,?)}", params );
        // Log.message( "Created school -> " + organizationName + " with school
        // id -> " + orgId );
        return orgId;
    }

    /**
     * 
     * @param organizationName
     */
    public void deleteOrganization( String organizationName ) {
        try {
            // Log.message( "Deleting school -> " + organizationName );
            Object[] params = { organizationName };
            SQLUtil.executeFunction( "{call successmaker.delete_organization_proc(?)}", params );
            // Log.message( "Deleted school -> " + organizationName );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     * 
     * @param schoolName
     * @return
     */
    public boolean isOrganisationExist( String schoolName ) {
        String queryString = "SELECT * FROM school.organization WHERE organization_name= '" + schoolName + "'";
        if ( SQLUtil.executeQuery( queryString ).isEmpty() ) {
            return false;
        }
        return true;
    }

    /**
     * 
     * @param organization_id
     * @param productType
     * @param subject
     * @param noOfUsers
     */
    public void addLicenseToOrg( int organization_id, String productType, String subject, int noOfUsers ) {
        Integer subjectID;
        Integer productID;
        if ( subject.contentEquals( "Math" ) ) {
            subjectID = 1;
        } else {
            subjectID = 2;
        }
        if ( productType.contentEquals( "Default" ) ) {
            productID = 1;
        } else {
            productID = 2;
        }
        java.util.Date utilDate = new java.util.Date();
        java.sql.Timestamp timestamp = new java.sql.Timestamp( utilDate.getTime() );
        Object[] params = { organization_id, productID, UUID.randomUUID().toString(), 0, timestamp, noOfUsers, noOfUsers, subjectID };
        SQLUtil.executeFunction( "{call successmaker.add_license(?,?,?,?,?,?,?,?)}", params );
    }

    /***
     * This method retrieves the holiday list for admin users
     * 
     * @author balaji.chandra
     * @return
     */

    public HashMap<String, String> getHolidayList() {
        String queryString1 = "select holiday,description from holidays";

        List<Object[]> listItems = SQLUtil.executeQuery( queryString1 );

        HashMap<String, String> arrMap = new HashMap<String, String>();
        if ( listItems != null && listItems.size() > 0 ) {
            for ( Object[] eachItem : listItems ) {
                arrMap.put( eachItem[0].toString(), eachItem[1].toString() );
            }
        }
        Log.message( "Holiday List retrieved" );
        return arrMap;
    }

    /**
     * 
     * @return
     */
    public Map<String, String> getNYRdateAandTeanantId() {
        String queryString = "select tenant_id, nyr_date from tenant_nyr_date";
        List<Object[]> listItems = SQLUtil.executeQuery( queryString );
        Map<String, String> arrMap = new HashMap<>();
        if ( listItems != null && listItems.size() > 0 ) {
            arrMap.put( "tenant_id", listItems.get( 0 )[0].toString() );
            arrMap.put( "nyr_date", listItems.get( 0 )[1].toString() );
        }
        return arrMap;
    }

}