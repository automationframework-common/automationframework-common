package com.savvas.sm.utils.sme187.admin.api.dashboard;

import java.util.Map;

import io.restassured.response.Response;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.constants.AdminConstants;

public class OrganizationPerformance {

    /***
     * 
     * @author madhan.nagarathinam
     * 
     *         postAdmin'sOrganizationPerformance() -> This method get the
     *         details for organization student's performance
     *
     * 
     * @param smUrl - The URL can be basic, auto and MSMN. Basic:
     *            https://nightly-next-basic.smdemo.info Auto:
     *            https://nightly-next-auto.smdemo.info MSMN:
     *            https://nightly-next-automsmn.smdemo.info
     * 
     * @param headers - headers must contains org-id, user-id and authorization
     * 
     * @param requestBody - the requestBody should contain orgStudentsMap,
     *            lastWeekStartDate, lastWeekEndDate, thisWeekStartDate,
     *            thisWeekEndDate as the mandatory parameter
     * 
     * @return response -> The Post Call response will be given as a static
     *         Response
     * @throws Exception
     */

    public Response PostAdminOrganizationPerfomance( String smUrl, Map<String, String> headers, Map<String, Object> requestBody ) throws Exception {
        return RestAssuredAPIUtil.POST_REQ( smUrl, headers, requestBody, AdminConstants.POST_ADMIN_ORGANIZATION_PERFORMACE );

    }

}
