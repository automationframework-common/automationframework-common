package com.savvas.sm.utils.sme187.teacher.api.course;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

public class SharedCourseTeacherAPI extends EnvProperties {

    public static String isItMt = configProperty.getProperty( "isMTExecution" );

    /**
     * This method is used to create a shared course
     * <p>
     * envUrl - The SM instance URL
     * <p>
     * token - It is the bearer token of the teacher
     * <p>
     * subject - It is the subject type. It can be Math or Reading
     * <p>
     * teacherId - It is the id of the teacher
     * <p>
     * orgId - It is the org to which the teacher belongs
     * <p>
     * courseType - This defines the type of course you want. It can be
     * Settings,Skills or Standards
     * <p>
     * courseName - This is the name of the course that is being newly created
     * 
     * @param smUrl
     * @param token
     * @param subject
     * @param teacherId
     * @param orgId
     * @param courseType
     * @param courseName
     * 
     * @return
     * 
     * @throws Exception
     */

    public String createSharedCourse( String envUrl, String token, String subject, String teacherId, String orgId, String courseType, String courseName ) throws Exception {
        HashMap<String, String> response_post = new HashMap<>();
        // Input Params
        HashMap<String, String> params = new HashMap<>();
        // EndPoint Details
        String endPoint_post = CourseAPIConstants.CREATE_CUSTOM_COURSE;
        try {
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + token );
            headers.put( Constants.USERID_SM_HEADER, teacherId );
            headers.put( Constants.ORGID_SM_HEADER, orgId );

            if ( subject.contentEquals( DataSetupConstants.MATH ) ) {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "1" );
            } else {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "2" );
            }

            endPoint_post = endPoint_post.replace( Constants.ORG_ID, orgId );
            endPoint_post = endPoint_post.replace( Constants.STAFF_ID, teacherId );

            HashMap<String, String> courseDetails = new HashMap<String, String>();
            courseDetails.put( Constants.COURSE_NAME, courseName );
            String requestBody = null;
            if ( courseType.equalsIgnoreCase( DataSetupConstants.SETTINGS ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SETTING_GENERIC_MATH ), courseDetails );
                } else {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SETTING_SHARED_READING ), courseDetails );
                }
            }
            //TODO To get RandomSkills
            else if ( courseType.equalsIgnoreCase( DataSetupConstants.SKILL ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SKILLS_SHARED_MATH ), courseDetails );
                } else {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SKILLS_SHARED_READING ), courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.STANDARD ) ) {
                List<String> standardDetails = new ArrayList<>();

                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    standardDetails = UserSqlHelper.getRandomStandardGradeID( CommonAPIConstants.TEACHER, DataSetupConstants.MATH, isItMt.equalsIgnoreCase( "true" ) );
                } else {
                    standardDetails = UserSqlHelper.getRandomStandardGradeID( CommonAPIConstants.TEACHER, DataSetupConstants.READING, isItMt.equalsIgnoreCase( "true" ) );
                }

                List<String> listLO = UserSqlHelper.getLOIDsRandomStandard( CommonAPIConstants.TEACHER, standardDetails.get( 0 ), standardDetails.get( 1 ), isItMt.equalsIgnoreCase( "true" ) );
                courseDetails.put( Constants.STANDARDFRAMEWORK_ID, standardDetails.get( 0 ) );
                courseDetails.put( Constants.GRADE_ID, standardDetails.get( 1 ) );
                courseDetails.put( Constants.BANKID, listLO.get( 0 ).split( "_" )[3] ); //To get Bank ID from LO
                courseDetails.put( Constants.LOID, listLO.get( 0 ) );
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_SHARED_MATH ), courseDetails );
                    Log.message( requestBody );
                } else {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_SHARED_READING ), courseDetails );
                }

            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.ONE_LO ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = new RBSUtils().generateRequestBody( DataSetupConstants.CUSTOM_BY_SKILL_ONE_LO, courseDetails );
                }
            }
            response_post = RestHttpClientUtil.POST( envUrl, headers, params, endPoint_post, requestBody );
            if ( response_post.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                return SMUtils.getKeyValueFromResponse( response_post.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.REPORT_COURSEID );
            } else {
                return response_post.get( Constants.REPORT_BODY );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response_post.get( Constants.REPORT_BODY );
    }
}
