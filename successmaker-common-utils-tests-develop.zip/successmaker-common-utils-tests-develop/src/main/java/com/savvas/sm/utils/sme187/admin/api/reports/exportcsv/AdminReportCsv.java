package com.savvas.sm.utils.sme187.admin.api.reports.exportcsv;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.ExportCsvConstants.AFGExportCSVConstants;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.ExportCsvConstants.CPARExportCSVConstants;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.ExportCsvConstants.CPRExportCSVConstants;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.ExportCsvConstants.SPRExportCSVConstants;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportAdminConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;

import io.restassured.response.Response;

public class AdminReportCsv {

    /**
     * This method is used to get Admin LSR CSV data
     * 
     * @param headers
     * @param selectedSchoolId
     * @param isMath
     * @param assignmentIds
     * @param isCustomExport
     * @param maskStudentDisplay
     * @param selectedFields
     * @param filerValues
     * @param additionalGroupingId
     * @return
     */
    public static Response GetAdminLastSessionReportCsv( Map<String, String> headers, String selectedSchoolId, boolean isMath, List<String> assignmentIds, boolean isCustomExport, boolean maskStudentDisplay, List<String> selectedFields,
            Map<String, List<String>> filerValues, int additionalGroupingId, String requestId ) {
        Response response = null;
        try {
            String userId = headers.get( Constants.USERID_SM_HEADER );
            String orgId = headers.get( Constants.ORGID_SM_HEADER );
            headers.put( "Content-Type", "application/json" );
            headers.put( "Accept", "text/csv" );

            AtomicReference<String> requestBody = new AtomicReference<>();
            // Generate Payload
            requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "AdminLastSessionReportCsvPayload.json" ) );

            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.organizationId", orgId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.requestId", requestId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.userId", userId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams.maskStudentDisplay", maskStudentDisplay ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams.filterBySchool", selectedSchoolId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams.courseList", assignmentIds ) );

            if ( isMath ) {
                if ( !isCustomExport ) {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", ExportCsvConstants.LSR_EXPORT_CSV_FIELDS ) );
                } else {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.exportType", ExportCsvConstants.CUSTOM ) );
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", selectedFields ) );
                }
            } else {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams.subject", Constants.READING ) );
                if ( !isCustomExport ) {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", ExportCsvConstants.LSR_EXPORT_CSV_FIELDS ) );
                } else {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.exportType", ExportCsvConstants.CUSTOM ) );
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", selectedFields ) );
                }
            }

            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams.additionalGrouping", additionalGroupingId ) );

            if ( Objects.nonNull( filerValues ) ) {
                filerValues.keySet().stream().forEach( fieldName -> {
                    if ( Objects.nonNull( filerValues ) && ExportCsvConstants.DEMOGRAPHIC_FIELD_VALUES.contains( fieldName ) ) {
                        requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams." + fieldName, filerValues.get( fieldName ) ) );
                    } else {
                        requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams." + fieldName, filerValues.get( fieldName ) ) );
                    }
                } );
            }
            Log.message( "LSR Export CSV Payload : " + requestBody.get() );
            response = RestAssuredAPIUtil.POST( ReportAdminConstants.REPORT_BFF + ExportCsvConstants.EXPORT_CSV_ENDPOINT, headers, requestBody.get() );
        } catch ( Exception e ) {
            Log.message( e.getMessage() );
        }
        return response;
    }

    /**
     * To hit the export csv API for Admin - student Performance Report
     * 
     * @param headers
     * @param isMath
     * @param selectedOrgIds
     * @param teacherIds
     * @param groupIds
     * @param gradeIds
     * @param assignmentIds
     * @param weeks
     * @param isCustomExport
     * @param language
     * @param isMaskStudentDisplay
     * @param selectedFields
     * @return
     */
    public static Response postAdminStudentPerformanceReportCSV( Map<String, String> headers, String reportRun, boolean isMath, List<String> selectedOrgIds, List<String> teacherIds, List<String> groupIds, List<String> gradeIds, List<String> assignmentIds,
            int weeks, boolean isCustomExport, String language, boolean isMaskStudentDisplay, boolean includePerformanceSummary, boolean includePerformanceByStrand, boolean includeAreasOfDifficulty, List<String> selectedFields, String requestId ) {
        Response response = null;
        try {
            headers.put( "Content-Type", "application/json" );
            headers.put( "Accept", "text/csv" );

            // Generate Payload
            AtomicReference<String> requestBody = new AtomicReference<>();
            requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "postAdminStudentPerformanceReportExportCSV.json" ) );

            if ( isCustomExport ) {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.exportType", "custom" ) );
                requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", selectedFields ) );
            } else {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.exportType", "default" ) );
                if ( isMath ) {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", SPRExportCSVConstants.DEFAULT_MATH_SELECTED_FILTERS ) );
                } else {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", SPRExportCSVConstants.DEFAULT_READING_SELECTED_FILTERS ) );
                }
            }

            if ( isMath ) {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.subject", "math" ) );
            } else {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.subject", "reading" ) );
            }
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.reportRun", reportRun ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.maskStudentDisplay", isMaskStudentDisplay ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.language", language ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.includeRecentHistoryData", weeks ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.courseList", assignmentIds ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterBySchool", selectedOrgIds ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterByTeacher", teacherIds ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterByGrade", gradeIds ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterByGroup", groupIds ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.includePerformanceSummary", includePerformanceSummary ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.includePerformanceByStrand", includePerformanceByStrand ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.includeAreasOfDifficulty", includeAreasOfDifficulty ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.requestId", requestId ) );

            String endPoint = "/export-csv";
            Log.message( "Payload : " + requestBody.get() );
            response = RestAssuredAPIUtil.POST( ReportAdminConstants.REPORT_BFF + endPoint, headers, requestBody.get() );
        } catch ( Exception e ) {
            Log.message( e.getMessage() );
        }
        return response;
    }

    /**
     * To hit the export csv API for Admin - Mastery
     * 
     * @param headers
     * @param selectedOrgId
     * @param exportType
     * @param standId
     * @param subjectId
     * @param selectedFieldsOrdered
     * @return
     * @throws IOException
     */
    public Response postMasteryExportCSVAPI( Map<String, String> headers, String selectedOrgId, String exportType, String requestId, String standId, int subjectId, List<String> selectedFieldsOrdered ) throws IOException {
        Response response = null;
        try {

            String endPoint = "/export-csv";

            // Generate Payload
            AtomicReference<String> requestBody = new AtomicReference<>();
            requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "AdminMasteryCSVRequestBody.json" ) );

            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.exportType", exportType ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.requestId", requestId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.subjectId", subjectId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.organizationId", selectedOrgId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.standardId", standId ) );

            if ( exportType.equals( "custom" ) ) {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", selectedFieldsOrdered ) );
            }

            response = RestAssuredAPIUtil.POST( ReportAdminConstants.REPORT_BFF + endPoint, headers, requestBody.get() );
        } catch ( Exception e ) {
            Log.message( e.getMessage() );
        }
        return response;
    }

    /**
     * To hit the export csv API for Admin - CPR
     * 
     * @param headers
     * @param selectedOrgId
     * @param exportType
     * @param standId
     * @param subjectId
     * @param selectedFieldsOrdered
     * @return
     * @throws IOException
     */
    public static Response postCPRExportCSVAPI( Map<String, String> headers, List<String> selectedOrgId, String exportType, String requestId, String reportRun, String subject, List<String> selectedFieldsOrdered, Map<String, Object> optionalFilters )
            throws IOException {
        Response response = null;
        try {

            String endPoint = "/export-csv";

            // Generate Payload
            AtomicReference<String> requestBody = new AtomicReference<>();
            requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "AdminCPReportCSVPayload.json" ) );

            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.exportType", exportType ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.requestId", requestId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.userId", headers.get( Constants.USERID_SM_HEADER ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.organizationId", headers.get( Constants.ORGID_SM_HEADER ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.reportRun", reportRun ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams.subject", subject ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams.filterBySchool", selectedOrgId ) );

            if ( exportType.equals( "custom" ) ) {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", selectedFieldsOrdered ) );
            } else {
                if ( subject.equalsIgnoreCase( "Math" ) ) {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", CPRExportCSVConstants.DEFAULT_MATH_SELECTED_FILTERS ) );
                } else {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", CPRExportCSVConstants.DEFAULT_READING_SELECTED_FILTERS ) );
                }
            }

            if ( Objects.nonNull( optionalFilters ) ) {
                optionalFilters.keySet().stream().forEach( fieldName -> {
                    if ( ExportCsvConstants.DEMOGRAPHIC_FIELD_VALUES.contains( fieldName ) ) {
                        requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams.filterByDemographics." + fieldName, optionalFilters.get( fieldName ) ) );
                    } else {
                        requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams." + fieldName, optionalFilters.get( fieldName ) ) );
                    }
                } );
            }
            response = RestAssuredAPIUtil.POST( ReportAdminConstants.REPORT_BFF + endPoint, headers, requestBody.get() );
        } catch ( Exception e ) {
            Log.message( e.getMessage() );
        }
        return response;
    }

    /**
     * To hit the export csv API for Admin - CPAR
     * 
     * @param headers
     * @param selectedOrgId
     * @param exportType
     * @param standId
     * @param subjectId
     * @param selectedFieldsOrdered
     * @return
     * @throws IOException
     */
    public static Response postCPARExportCSVAPI( Map<String, String> headers, List<String> selectedOrgId, String exportType, String requestId, String reportRun, String subject, List<String> selectedFieldsOrdered, Map<String, Object> optionalFilters )
            throws IOException {
        Response response = null;
        try {

            String endPoint = "/export-csv";

            // Generate Payload
            AtomicReference<String> requestBody = new AtomicReference<>();
            requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "AdminCPAReportCSVPayload.json" ) );

            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.exportType", exportType ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.requestId", requestId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.userId", headers.get( Constants.USERID_SM_HEADER ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.organizationId", Constants.ORGID_SM_HEADER ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.reportRun", reportRun ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams.subject", subject ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams.filterBySchool", selectedOrgId ) );

            if ( exportType.equals( "custom" ) ) {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", selectedFieldsOrdered ) );
            } else {
                if ( subject.equalsIgnoreCase( "Math" ) ) {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", CPARExportCSVConstants.DEFAULT_MATH_SELECTED_FILTERS ) );
                } else {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", CPARExportCSVConstants.DEFAULT_READING_SELECTED_FILTERS ) );
                }
            }

            if ( Objects.nonNull( optionalFilters ) ) {
                optionalFilters.keySet().stream().forEach( fieldName -> {
                    if ( ExportCsvConstants.DEMOGRAPHIC_FIELD_VALUES.contains( fieldName ) ) {
                        requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams.filterByDemographics." + fieldName, optionalFilters.get( fieldName ) ) );
                    } else {
                        requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams." + fieldName, optionalFilters.get( fieldName ) ) );
                    }
                } );
            }
            response = RestAssuredAPIUtil.POST( ReportAdminConstants.REPORT_BFF + endPoint, headers, requestBody.get() );
        } catch ( Exception e ) {
            Log.message( e.getMessage() );
        }
        return response;
    }

    /**
     * 
     * @param headers
     * @param selectedOrgId
     * @param exportType
     * @param requestId
     * @param reportRun
     * @param subject
     * @param selectedFieldsOrdered
     * @param optionalFilters
     * @return
     * @throws IOException
     */
    public Response postAFGExportCSVAPI( Map<String, String> headers, String selectedOrgId, String exportType, String requestId, String reportRun, String subject, List<String> selectedFieldsOrdered, Map<String, Object> optionalFilters )
            throws IOException {

        Response response = null;
        try {

            String endPoint = "/export-csv";

            // Generate Payload
            AtomicReference<String> requestBody = new AtomicReference<>();
            requestBody.set( SMUtils.getPayload( PayloadFor.ADMIN, "AdminAFGReportCSVPayload.json" ) );

            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.exportType", exportType ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.requestId", requestId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.userId", headers.get( UserConstants.USERID ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.organizationId", headers.get( UserConstants.ORGID ) ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.reportRun", reportRun ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams.subject", subject ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams.filterBySchool", selectedOrgId ) );

            if ( exportType.equals( "custom" ) ) {
                requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", selectedFieldsOrdered ) );
            } else {
                if ( subject.equalsIgnoreCase( "Math" ) ) {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", AFGExportCSVConstants.DEFAULT_MATH_SELECTED_FILTERS ) );
                } else {
                    requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.selectedFieldsOrdered", AFGExportCSVConstants.DEFAULT_READING_SELECTED_FILTERS ) );
                }
            }

            if ( Objects.nonNull( optionalFilters ) ) {
                optionalFilters.keySet().stream().forEach( fieldName -> {
                    if ( ExportCsvConstants.DEMOGRAPHIC_FIELD_VALUES.contains( fieldName ) ) {
                        requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams.filterByDemographics." + fieldName, optionalFilters.get( fieldName ) ) );
                    } else {
                        requestBody.set( JSONUtil.setProperty( requestBody.get(), "reportParams.reportQueryParams.filterParams." + fieldName, optionalFilters.get( fieldName ) ) );
                    }
                } );
            }
            Log.message( requestBody.toString() );
            response = RestAssuredAPIUtil.POST( ReportAdminConstants.REPORT_BFF + endPoint, headers, requestBody.get() );
        } catch ( Exception e ) {
            Log.message( e.getMessage() );
        }
        return response;
    }

}
