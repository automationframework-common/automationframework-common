package com.savvas.sm.utils.sql.helper;

import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.SqlConstants;
import com.savvas.sm.utils.SqlQueryConstants;
import com.savvas.sm.utils.sql.helper.StandardVersionTable.StandardVersionMastery;

import javax.sql.rowset.CachedRowSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SqlHelperMastery {

    public static List<StandardVersionMastery> getStandards( String... bySubject ) throws SQLException {
        // define variables required
        List<StandardVersionMastery> objToReturn = new ArrayList<StandardVersionMastery>();

        // define query
        String queryToExecute;

        // frame query to execute
        if ( bySubject.length > 0 ) {
            if ( bySubject[0].toString().toLowerCase().equalsIgnoreCase( "math" ) )
                queryToExecute = SqlQueryConstants.Mastery.QUERY_TO_GET_STANDARDS_BY_MATH;
            else if ( bySubject[0].toString().toLowerCase().equalsIgnoreCase( "reading" ) )
                queryToExecute = SqlQueryConstants.Mastery.QUERY_TO_GET_STANDARDS_BY_READING;
            else
                queryToExecute = SqlQueryConstants.Mastery.QUERY_TO_GET_STANDARDS;
        } else
            queryToExecute = SqlQueryConstants.Mastery.QUERY_TO_GET_STANDARDS;

        CachedRowSet resultSet = SQLUtil.executeQueryAndReturnTable( queryToExecute );
        // process query results
        while ( resultSet.next() ) {
            String standardsID = resultSet.getString( SqlConstants.Mastery.STANDARD_VERSION_ID );
            String standardsName = resultSet.getString( SqlConstants.Mastery.STANDARD_VERSION );
            String stateVersionId = resultSet.getString( SqlConstants.Mastery.STATE_VERSION_ID );

            StandardVersionTable standardVersion = new StandardVersionTable();
            StandardVersionMastery standardVersionMastery = standardVersion.new StandardVersionMastery( standardsID, standardsName, stateVersionId );

            objToReturn.add( standardVersionMastery );
        }
        return objToReturn;
    }
}
