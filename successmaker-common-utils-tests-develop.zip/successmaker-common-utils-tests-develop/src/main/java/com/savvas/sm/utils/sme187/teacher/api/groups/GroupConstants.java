package com.savvas.sm.utils.sme187.teacher.api.groups;

public interface GroupConstants {

    String GROUP_OWNER_ORG_ID = "groupOwnerOrgId";
    String GROUP_OWNER_ID = "groupOwnerId";
    String STAFF_ID = "staffId";
    String STUDENT_ID = "studentId";
    String STUDENT_RUMBA_IDS = "studentRumbaIds";
    String GROUP_IDS = "groupIds";
    String INVALID_TEACHER = "INVALID_TEACHER";
    String INVALID_ORG = "INVALID_ORG";
    String USER_ID_ENDPOINT = "{userId}";
    String GROUP_ID_ENDPOINT = "{group_id}";
    String ORG_ID_ENDPOINT = "{organizationId}";
    String COURSE_ID_ENDPOINT = "{contentBaseId}";
    String STAFF_ID_ENDPOINT = "{staffId}";
    String CREATE_GROUP_API_PAYLOAD = "createGroupAPIPayload";

    String INVALID_GROUP_ID = "INVALID_GROUPID";
    String GROUP_ID = "groupId";

    String SUBJECT_TYPE_ID = "subjectTypeId";
    String CONTENT_BASE = "contentBase";
    String INVALID_CONTENT_BASE = "invalid content base";
    String INVALID_SUBJECT_TYPE = "invalid subjectType";

    String INVALID_GROUP_NAME = "INVALID_GROUPNAME";
    String INVALID_GROUP_OWNER_ID = "INVALID_GROUPOWNER_ID";
    String INVALID_COURSE_ID = "INVALID_COURSE_ID";

    String GROUP_NAME = "groupName";

    String ORG_ID = "orgId";
    String STUDENT_IDS = "studentIds";
    String STUDENT_IDS_VALUE = "studentIdsValue";
    String GROUP_IDS_VALUE = "groupIdsValue";
    String ORG_ID_HEADER = "org-Id";
    String USER_ID_HEADER = "user-Id";
    String INVALID_STUDENT = "INVALID_STUDENT";
    String TEACHER_ID = "{teacher_id}";
    String RUMBA_ID = "rumbaId";
    
    String ORG_ID_REQBODY = "organizationId";
    String ORG_NAME_REQBODY = "organizationName";
    String ORG_IDS_REQBODY = "orgIds";

    public interface GroupAPIEndPoints {
        String ADD_STUDENT_TO_GROUP_ENDPOINT = "/lms/web/api/v1/organization/{organizationId}/staffs/{staffId}/groups/students";
        String CREATE_GROUP_API_ENDPOINT = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/groups/students";
        String GET_GROUP_LIST_FOR_TEACHERID_NEW_API = "/lms/web/api/v1/users/{userId}/groups";
        String GET_STUDENT_LIST_FOR_GROUP_API = "/lms/web/api/v1/groups/{group_id}/students";
        String MOST_ASSESSED_SKILL_GROUP_ENDPOINT = "/lms/web/api/v1/organizations/%s/staffs/%s/contentBase/%s/groups/%s/mostAssessedSkills";

        String REMOVE_STUDENT_FROM_GROUP_ENDPOINT = "/lms/web/api/v1/organizations/orgId/staffs/staffId/groups/students";
        String GET_GROUP_LIST_FOR_STUDENT_API = "/lms/web/api/v1/users/%s/groups";
        String UPDATE_GROUP_API = "/lms/web/api/v1/groups/{group_id}";
        String DELETE_GROUP_ENDPOINT = "/lms/web/api/v1/groups/groupId";
        String STUDENTS_NOT_PARTOF_GROUP = "/lms/web/api/v1/staffs/{teacher_id}/students";

        String GET_GROUP_LIST_FOR_ASSIGNMENT_NOTPARTOF_API = "/lms/web/api/v1/organization/{organizationId}/staffs/{staffId}/courses/{contentBaseId}/unassigned/groups";

        String GET_GROUPLIST_STUDENTS_NOT_BELONG_TO = "/lms/web/api/v1/organizations/%s/staffs/%s/enroll/groups";
        String POST_GROUP_USAGE_END_POINT = "/lms/web/api/v1/organization/{organizationId}/staffs/{staffId}/usageReport";

    }

    public interface RemoveStudentsFromGroupsAPIConstants {
        public static String ENDPOINT = "/lms/web/api/v1/organizations/orgId/staffs/staffId/groups/students";
        public static String ORG_ID = "orgId";
        public static String STAFF_ID = "staffId";
        public static String STUDENT_IDS = "studentIds";
        public static String GROUP_IDS = "groupIds";
        public static String STUDENT_IDS_VALUE = "studentIdsValue";
        public static String GROUP_IDS_VALUE = "groupIdsValue";
        public static String ORG_ID_HEADER = "org-Id";
        public static String USER_ID_HEADER = "user-Id";
    }

}
