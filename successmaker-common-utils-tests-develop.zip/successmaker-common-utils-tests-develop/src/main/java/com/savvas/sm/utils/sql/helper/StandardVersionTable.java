package com.savvas.sm.utils.sql.helper;

import java.sql.Timestamp;

/***
 * This class represents the DB_table- standard_version
 * 
 * @author magesh.nagamani
 *
 */
public class StandardVersionTable {
    // define column names from table as variables
    private int standard_version_id;
    private String standard_version;
    private int state_version_id;
    private int pcs_subject_id;
    private String standard_version_short_name;
    private Timestamp date_ins;
    private Timestamp date_upd;

    /**
     * No-arg constructor
     */
    public StandardVersionTable() {

    }

    /**
     * Constructor used to create Objects for StandardVersion table
     * (Insert/Update/Retrieve)
     * 
     * @param standard_version_id
     * @param standard_version
     * @param state_version_id
     * @param pcs_subject_id
     * @param standard_version_short_name
     * @param date_ins
     * @param date_upd
     */
    public StandardVersionTable( int standard_version_id, String standard_version, int state_version_id, int pcs_subject_id, String standard_version_short_name, Timestamp date_ins, Timestamp date_upd ) {
        this.standard_version_id = standard_version_id;
        this.standard_version = standard_version;
        this.state_version_id = state_version_id;
        this.pcs_subject_id = pcs_subject_id;
        this.standard_version_short_name = standard_version_short_name;
        this.date_ins = date_ins;
        this.date_upd = date_upd;
    }

    /**
     * This inner class represents the DB_table- standard_version. Used by the
     * API- GET Standard (Mastery)
     * 
     * @author magesh.nagamani
     *
     */
    public class StandardVersionMastery {
        // define fields from GET- Standards Mastery response
        private String standardsId;
        private String standardsName;
        private String stateVersionId;

        /**
         * Constructor used to create Objects for StandardVersion table. By
         * accommodating the response fields of GET- Standards Mastery response
         * 
         * @param standard_version_id
         * @param standard_version
         * @param state_version_id
         */
        public StandardVersionMastery( String standard_version_id, String standard_version, String state_version_id ) {
            this.standardsId = standard_version_id;
            this.standardsName = standard_version;
            this.stateVersionId = state_version_id;
        }

        /**
         * Getter method for standardsId
         * 
         * @return standardsId
         */
        public String getStandardsId() {
            return this.standardsId;
        }

        /**
         * Getter method for standardsName
         * 
         * @return standardsName
         */
        public String getStandardsName() {
            return this.standardsName;
        }

        /**
         * Getter method for stateVersionId
         * 
         * @return stateVersionId
         */
        public String getStateVersionId() {
            return this.stateVersionId;
        }

    }
}
