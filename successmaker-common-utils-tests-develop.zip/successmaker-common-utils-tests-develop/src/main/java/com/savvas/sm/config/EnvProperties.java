package com.savvas.sm.config;

import com.learningservices.utils.EnvironmentPropertiesReader;

public class EnvProperties {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
}
