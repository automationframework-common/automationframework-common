package com.savvas.sm.simulatorrun;

import org.openqa.selenium.WebDriver;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.ui.constants.LoginConstants;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;

/**
 * 
 * This class is used to create mastery data using simulator
 * 
 * @author madhan.nagarathinam
 *
 */
public class SimulatorRun extends EnvProperties {

	String chromePlatform = "Windows_10_Chrome_latest";

	public void masterySimulatorRun(String smUrl, String teacherUserId, String studentUserName, String assignmentName,
			String noOfSessions, String percentage, String noOfLo) throws Exception {

		// Get driver
		WebDriver driver = null;
		WebDriver chromeDriver = WebDriverFactory.get(chromePlatform); // for simulator run
		Log.message("Running Simulator to generate Mastery Data");
		try {

			// Simulator run to execute courses in students dashboard for student mastery
			// status in both Math and Reading subject
			Log.message("Executing the courses using simulator for student");
			StudentDashboardPage studentHomePage = LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl,
					LoginConstants.UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD);

			if (assignmentName.contains("Math")) {
				try {
					studentHomePage.executeMathCourse(teacherUserId, assignmentName, percentage, noOfSessions, noOfLo);
				} catch (Exception e) {
					Log.message(e.getLocalizedMessage());
				}
			} else {
				try {
					studentHomePage.executeReadingCourse(teacherUserId, assignmentName, percentage, noOfSessions,
							noOfLo);
				} catch (Exception e) {
					Log.message(e.getLocalizedMessage());
				}
			}
			studentHomePage.logout();
			chromeDriver.quit();

		} catch (Exception e) {
			Log.exception(e, chromeDriver);
		} finally {
			chromeDriver.quit();
		}
	}

}
