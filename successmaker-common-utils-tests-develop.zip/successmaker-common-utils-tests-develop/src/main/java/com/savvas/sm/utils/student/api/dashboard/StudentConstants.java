package com.savvas.sm.utils.student.api.dashboard;

public interface StudentConstants {

    public static String GET_ASSIGNMENTS_LIST_ENDPOINT = "/lms/web/api/v1/studentDashboard/assignments/{studentId}";
    public static String POST_SESSTION_THIS_WEEK_USAGE = "/lms/web/api/v1/student/dashboard/sessionUsageThisWeek/{studentId}";

    public static String BFF_END_POINT = "/graphql";
}
