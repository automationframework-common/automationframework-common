package com.savvas.sm.utils;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.utils.jsch.MyLogger;

import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetProvider;

import org.postgresql.util.PSQLException;

import java.io.File;
import java.net.URL;
import java.nio.file.Paths;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class SQLUtil {

    private static SQLUtil sqlUtil;

    private static final String POST_GRES_DRIVER = "org.postgresql.Driver";
    private static StringBuilder dbUrl;

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    static {
        try {
            Class.forName(POST_GRES_DRIVER);
        } catch (Exception e) {
            Log.fail("Error while loading database driver.");
        }
    }

    private static Connection connection = null;

    private SQLUtil() {
    }

    public synchronized static SQLUtil getInstance() {
        if (sqlUtil == null) {
            sqlUtil = new SQLUtil();
        }
        return sqlUtil;
    }

    /**
     * @return Connection
     */
    private static synchronized Connection getConnection() {
        if (connection != null) {
            return connection;
        }

        connection = null;
        Session session;

        int attempts = 1;
        while (attempts < 4) {
            try {

                String dbHost;

                if (configProperty.getProperty("SMInstanceType").equalsIgnoreCase("Non-Integrated")) {
                    dbHost = configProperty.getProperty("dbHostNonIntegrated");
                } else {
                    dbHost = configProperty.getProperty("dbHostIntegrated");
                }
                Integer dbPort = Integer.parseInt(configProperty.getProperty("dbPort"));

                if (configProperty.getProperty("isMultitenantDB").equalsIgnoreCase("true")) {
                    String sshHost = configProperty.getProperty("SSHHost");
                    String sshUser = configProperty.getProperty("SSHUser");
                    // String sshIdentity = configProperty.getProperty("SSHIdentity");
                    String sshPassPhrase = configProperty.getProperty("SSHPassPhrase");
                    String sshPortForwarding = configProperty.getProperty("SSHPortForwarding");


                    Integer portForwarding = 1234;

                    if (sshPortForwarding != null) {
                        portForwarding = Integer.parseInt(sshPortForwarding);
                    }
//                    if (sshIdentity == null) {
//                        sshIdentity = "C:\\Users\\Likitha.dangeti\\.ssh\\id_rsa";
//                    }
                    //Enable JSch Logger
                    JSch.setLogger(new MyLogger());
                    JSch jsch = new JSch();

                    //Add SSH Identity, make sure its RSA key
                    //ssh-keygen -t rsa -m PEM
                    URL res = SQLUtil.class.getClassLoader().getResource(".ssh/id_rsa");
                    File file = Paths.get(res.toURI()).toFile();
                    String sshIdentity = file.getAbsolutePath();
                    Log.message("SSH Identity Path: " + sshIdentity);

                    jsch.addIdentity(sshIdentity, sshPassPhrase);
                    session = jsch.getSession(sshUser, sshHost, 22);

                    session.setConfig("StrictHostKeyChecking", "no");
                    session.setConfig("PreferredAuthentications", "publickey");
                    session.connect();
                    Log.message("SSH Tunnel Connected");

                    Integer assignedPort = session.setPortForwardingL(portForwarding, dbHost, dbPort);
                    Log.message("localhost:" + assignedPort + " -> " + sshHost + ":" + 22);
                    Log.message("Port Forwarded");
                    dbHost = "localhost";
                    dbPort = assignedPort;
                }

                Properties props = new Properties();
                props.setProperty("options", "-c statement_timeout=1500000");

                dbUrl = new StringBuilder();
                dbUrl.append("jdbc:postgresql://")
                        .append(dbHost).append(":")
                        .append(dbPort).append("/")
                        .append(configProperty.getProperty("dbName"))
                        .append("?user=").append(configProperty.getProperty("dbUsername"))
                        .append("&password=").append(configProperty.getProperty("dbPassword"))
                        .append( "&ssl=true" )
                        .append( "&sslfactory=org.postgresql.ssl.NonValidatingFactory" )
                        .append( "&sslmode=allow" );

                Log.message("Connection URL: " + dbUrl.toString());
                connection = DriverManager.getConnection(dbUrl.toString(), props);

                break;
            } catch (Exception e) {
                e.printStackTrace();
                Log.fail("Error in establishing DB connection");
            }
            attempts++;
        }
        if (attempts == 4) {
            Log.fail("Unable to establish DB connection in 3 attempts");
        }
        return connection;
    }

    /**
     * @param queryConnection
     * @return Statement
     * @throws SQLException
     */
    private static Statement createStmt(Connection queryConnection) throws SQLException {
        Statement qSt = queryConnection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
        return qSt;
    }

    /**
     * @param functionStatement
     * @param parameters
     * @return
     */
    public static Integer executeFunction(String functionStatement, Object[] parameters) {
        Connection queryConnection = SQLUtil.getInstance().getConnection();
        CallableStatement cst = null;
        ResultSet rs = null;
        Integer statusCode = 0;
        try {
            cst = queryConnection.prepareCall(functionStatement);
            for (int i = 0; i < parameters.length; i++) {
                if (parameters[i] instanceof String) {
                    cst.setString(i + 1, parameters[i].toString());
                } else if (parameters[i] instanceof Integer) {
                    cst.setInt(i + 1, ((Integer) parameters[i]).intValue());
                } else if (parameters[i] instanceof Long) {
                    cst.setLong(i + 1, ((Long) parameters[i]).longValue());
                } else if (parameters[i] instanceof Double) {
                    cst.setDouble(i + 1, ((Float) parameters[i]).doubleValue());
                } else if (parameters[i] instanceof Float) {
                    cst.setFloat(i + 1, ((Float) parameters[i]).floatValue());
                } else if (parameters[i] instanceof Timestamp) {
                    cst.setTimestamp(i + 1, ((Timestamp) parameters[i]));
                }
            }
            cst.execute();
            rs = cst.getResultSet();
            if (rs != null) {
                while (rs.next()) {
                    statusCode = rs.getInt(1);
                }
            }
        } catch (SQLException sqe) {
            sqe.printStackTrace();
            Log.fail("Error while executing function.");
        } finally {

            try {
                //Close the result set
                if (rs != null) {
                    rs.close();
                    rs = null;
                }
                //Close the statement
                if (cst != null) {
                    cst.close();
                    cst = null;
                }
            } catch (SQLException sqe) {
                Log.fail("Error while releasing resources");
            }
        }
        return statusCode;
    }

    /**
     * @param queryString
     * @return
     */
    public static List<Object[]> executeQuery(String queryString) {
        Connection queryConnection = SQLUtil.getInstance().getConnection();
        ResultSet resultSet = null;
        Statement qSt = null;
        List<Object[]> records = new ArrayList<Object[]>();
        Log.message( "Given Query :"+ queryString );
        try {
            qSt = createStmt(queryConnection);
            Log.message("Executing Query: " + queryString);
            resultSet = qSt.executeQuery(queryString);
            Log.event("Query executed!");

            // call only once
            int cols = resultSet.getMetaData().getColumnCount();
            while (resultSet.next()) {
                Object[] arr = new Object[cols];
                for (int i = 0; i < cols; i++) {
                    arr[i] = resultSet.getObject(i + 1);
                }
                records.add(arr);
            }
        } catch (PSQLException exp) {
            Log.message( "Exception occured :"+ exp  );
            try {
                Thread.sleep(2000 );
                Log.message( "Performing retry" );
                retryExecuteQuery( queryString );
            } catch ( InterruptedException e ) {
                e.printStackTrace();
            }
        } catch (SQLException e) {
            if (e.getMessage().toString().equalsIgnoreCase(Constants.NO_RESULT_QUERY)) {
                Log.pass("Query executed and no result found");
            } else {
                e.printStackTrace();
                Log.event("Error in executing the query");
            }
        } finally {
            try {
                //Close the result set
                if (resultSet != null) {
                    resultSet.close();
                    resultSet = null;
                }
                //Close the statement
                if (qSt != null) {
                    qSt.close();
                    qSt = null;
                }

            } catch (SQLException sqe) {
                Log.fail("Error while releasing resources");
            }
        }
        return records;
    }

    /**
     * This method executes the given query and return the results as table
     * format. The CachedRowSet obj can be further used by DB representation
     * classes.
     *
     * @param queryString
     * @return
     * @throws SQLException
     */
    public static CachedRowSet executeQueryAndReturnTable(String queryString) throws SQLException {
        Connection queryConnection = SQLUtil.getInstance().getConnection();
        ResultSet resultSet = null;
        Statement qSt = null;
        CachedRowSet crs = RowSetProvider.newFactory().createCachedRowSet();
        try {
            qSt = createStmt(queryConnection);
            Log.message("Executing Query: " + queryString);
            resultSet = qSt.executeQuery(queryString);
            Log.event("Query executed!");

            crs.populate(resultSet);
        } catch (SQLException e) {
            Log.fail("Error in executing the query");
        } finally {
            try {
                //Close the result set
                if (resultSet != null) {
                    resultSet.close();
                    resultSet = null;
                }
                //Close the statement
                if (qSt != null) {
                    qSt.close();
                    qSt = null;
                }
            } catch (SQLException sqe) {
                Log.fail("Error while releasing resources");
            }
        }
        return crs;
    }

    /**
     * @param queryString
     * @return
     */
    public static boolean executeUpdateQuery(String queryString) {
        Connection queryConnection = SQLUtil.getInstance().getConnection();
        Statement qSt = null;
        try {
            qSt = createStmt(queryConnection);
            Log.message("Executing Query: " + queryString);
            qSt.executeUpdate(queryString);
            Log.event("Query executed!");
        } catch (SQLException e) {
            Log.fail("Error in executing the query");
            return false;
        } finally {
            try {
                //Close the statement
                if (qSt != null) {
                    qSt.close();
                    qSt = null;
                }
            } catch (SQLException sqe) {
                Log.fail("Error while releasing resources");
            }
        }
        return true;
    }

    /**
     * @param queryString
     * @return
     */
    public static boolean executeInsDelQuery(String queryString) {
        Connection queryConnection = SQLUtil.getInstance().getConnection();
        Statement qSt = null;
        try {
            qSt = createStmt(queryConnection);
            Log.message("Executing Query: " + queryString);
            qSt.executeQuery(queryString);
            Log.event("Query executed!");
        } catch (SQLException e) {
            Log.fail("Error in executing the query");
            return false;
        } finally {
            try {
                //Close the statement
                if (qSt != null) {
                    qSt.close();
                    qSt = null;
                }
            } catch (SQLException sqe) {
                Log.fail("Error while releasing resources");
            }
        }
        return true;
    }

    /**
     * This method is used to Execute the Query for insert/delete without result
     * set
     *
     * @param queryString
     * @return
     */
    public static boolean executeInsDelQueryWithoutResult(String queryString) {
        Connection queryConnection = SQLUtil.getInstance().getConnection();
        Statement qSt = null;
        try {
            qSt = createStmt(queryConnection);
            Log.message("Executing Query: " + queryString);
            qSt.executeQuery(queryString);
            Log.event("Query executed!");
        } catch (Exception e) {
            if (e.toString().contains("No results were returned by the query")) {
                Log.message("Query executed!");
                return true;
            } else {
                e.printStackTrace();
                Log.event("Error in executing the query");
                return false;
            }

        } finally {
            try {
                //Close the statement
                if (qSt != null) {
                    qSt.close();
                    qSt = null;
                }
            } catch (SQLException sqe) {
                sqe.printStackTrace();
                Log.event("Error while releasing resources");
            }
        }
        return true;
    }
    
    /**
     * @param queryString
     * @return
     */
    public static List<Object[]> retryExecuteQuery(String queryString) {
        Connection queryConnection =null;
        ResultSet resultSet = null;
        Statement qSt = null;
        List<Object[]> records = new ArrayList<Object[]>();
        boolean flagIsExecutionSuccessfull = false;
        try {
            for ( int i = 1; i < 4; i++ ) {
                try {
//                    if(queryConnection!=null) {
//                        queryConnection.close();
//                    }
                    queryConnection =  SQLUtil.getInstance().getConnection(); 
                    qSt = createStmt(queryConnection);
                    Log.message("Executing Query with retry "+ i +" : " + queryString);
                    resultSet = qSt.executeQuery(queryString);

                    // call only once
                    int cols = resultSet.getMetaData().getColumnCount();
                    while (resultSet.next()) {
                        Object[] arr = new Object[cols];
                        for (int j = 0; j < cols; j++) {
                            arr[j] = resultSet.getObject(j + 1);
                        }
                        records.add(arr);
                    }
                    flagIsExecutionSuccessfull = true;
                    break;
                }catch (PSQLException exp) {
                    if (exp.getMessage().toString().equalsIgnoreCase(Constants.NO_RESULT_QUERY)) {
                        Log.pass("Query executed and no result found");
                    } else {
                        exp.printStackTrace();
                        Log.event("Error in executing the query performing retry :"+ i);
                        continue;
                    }
                }
            }
           
        } catch ( SQLException e ) {
            if (e.getMessage().toString().equalsIgnoreCase(Constants.NO_RESULT_QUERY)) {
                Log.pass("Query executed and no result found");
            } else {
                e.printStackTrace();
                Log.event("Error in executing the query");
            }
        } finally {
            try {
                //Close the result set
                if (resultSet != null) {
                    resultSet.close();
                    resultSet = null;
                }
                //Close the statement
                if (qSt != null) {
                    qSt.close();
                    qSt = null;
                }
                if ( flagIsExecutionSuccessfull ) {
                    Log.message( "Query executed successfully" );
                } else {
                    Log.message( "Query execution failed after reattempting : 3" );
                }

            } catch ( SQLException sqe ) {
                Log.fail("Error while releasing resources");
            }
        }
        return records;
    }
}

