package com.savvas.sm.utils.sme187.teacher.api.users;

import java.util.ArrayList;
import java.util.Arrays;

public interface UserConstants {
    String USERID = "user-id";
    String ORGID = "org-id";
    String STAFFID = "staffId";
    String STAFFID_ENDPOINT = "{staffId}";

    String TEACHER_ID = "teacherId";
    String GRADE = "grade";
    String BIRTHDAY = "birthday";
    String STUDENT_IDENTIFICATION_NUMBER = "studentIdentificationNumber";
    String USER_PASSWORD = "userPassword";
    String CONFIRM_PASSWORD = "confirmPassword";
    String ETHINICITY = "ethnicity";
    String SPECIAL_SERVICES = "specialServices";
    String HAS_DISABILITY = "hasDisability";
    String HAS_ECONOMIC_DISADVANTAGE = "hasEconomicDisadvantage";
    String HAS_ENGLISH_PROFICIENCY = "hasEnglishProficiency";
    String ISMIGRANT = "isMigrant";
    String SCHOOLID = "schoolId";
    String PERSONID = "personId";
    String INVALID_TEACHER = "INVALID_TEACHER";
    String INVALID_ORG = "INVALID_ORG";
    String GENDER_FIELD = "gender";
    String ORG_ID = "orgID";

    String VALID = "valid";
    String GRADE_VALUE = "G02";
    String INVALID_ORG_ID = "invalidorg";
    String INVALID_TEACHER_ID = "invalidteacherid";
    String INVALID_COURSE_ID = "invalidcourseid";
    String SPCL_CHARACTER_USER_EMAIL_ID = "autoTesting@savvas.com";

    String CMS_ADMIN_USERNAME = "absavvasadmin";
    String CMS_ADMIN_PASSWORD = "password1";
    String ROSTER_SERVICE_URL = "roster_service_url";
    String ADD_STUDENT_SECTION_PAYLOAD = "addStudentintoSectionPayload";
    String DELETE_STUDENT_SECTION_PAYLOAD = "deleteStudentFromSectionPayload";

    String CLASS_ID = "{classId}";
    String SECTION_ID = "{sectionId}";
    String STUDENT_ID = "{studentId}";
    String GROUP_ID = "groupId";
    String USERNAME = "userName";
    String SUCCESS_STRING = "Success";
    String STATUS_STRING = "status";
    String STUDENT_ID_FIELD = "studentId";

    public static ArrayList<String> GRADE_CODES_CMS = new ArrayList<String>( Arrays.asList( "KG", "G01", "G02", "G03", "G04", "G05", "G06", "G07", "G08", "G09", "G10", "G11", "G12" ) );

    public static enum grade {
        K,
        FIRST,
        SECOND,
        THIRD,
        FOURTH,
        FIFTH,
        SIXTH,
        SEVENTH,
        EIGHT,
        NINTH,
        TENTH,
        ELEVENTH,
        TWELVETH,

    }

    public static enum ethnicity {
        HISPANIC_OR_LATINO,
        NOT_HISPANIC_OR_LATINO,
        NOT_SPECIFIED
    }

    public static enum race {
        WHITE,
        BLACK_OR_AFRICAN_AMERICAN,
        ASIAN,
        AMERICAN_NATIVE_OR_ALASKAN_NATIVE,
        NATIVE_HAWAIIAN_OR_PACIFIC_ISLANDER,
        HISPANIC_LATINO,
        UNKNOWN,
        NOT_SPECIFIED
    }

    public static enum specialServices {
        OTHER,
        NO_SPECIAL_SERVICES,
        PLAN_504,
        IEP,
        GIFTED_TALENTED,
        NOT_SPECIFIED
    }

    public static enum hasDisability {
        NO,
        NOT_SPECIFIED,
        YES
    }

    public static enum gender {
        NOT_SPECIFIED,
        MALE,
        FEMALE
    }

    public static enum hasEconomicDisadvantage {
        NOT_ECONOMICALLY_DISADVANTAGED,
        NOT_SPECIFIED,
        ECONOMICALLY_DISADVANTAGED
    }

    public static enum hasEnglishProficiency {
        ENGLISH,
        ENGLISH_LANGUAGE_LEARNER,
        NOT_SPECIFIED
    }

    public static enum isMigrant {
        MIGRANT,
        NOT_SPECIFIED,
        NON_MIGRANT
    }

    public interface UserAPIEndPoints {
        String UPDATE_STAFF_PROFILE_API = "/lms/web/api/v1/staffs/{staffId}/";
        String CREATE_STUDENT_ENDPOINT = "/lms/web/api/v1/students";
        String GET_STUDENT_PROGRESS_API = "/lms/web/api/v1/organizations/{organizationId}/staffs/{userID}/students/{studentIds_value}/assignments/{assignmentIdValue}/progressMonitoring";
        String POST_LAST_SESSION_SKILLS_STUDENT_API = "/lms/web/api/v1/organizations/organizationId/staffs/staffId/assignments/assignmentId/students/studentId/skillsTestedReport";
        String RETURN_STUDENT_ENDPOINT = "/lms/web/api/v1/organization/{organizationId}/staffs/{userID}/courses/{courseId}/unassigned";
        String GET_USER_DETAILS = "/lms/web/api/v1/users/user-id";
        String ROSTER_DELETE_STUDENT_FROM_SECTION = "/v2/sections/{sectionId}/students";
        String GET_STUDENT_DETAILS = "/lms/web/api/v1/students/studentId";
    }

    public interface StudentDetailsForGivenTeacherConstants {

        public static String GET_STUDENTS_DETAILS_FOR_TEACHERID = "/lms/web/api/v1/staffs/{teacherId}/students";
        public static String user_id_TEXT = "user-id";
        public static String userId_TEXT = "userId";
        public static String TEACHER_ID = "{teacherId}";
        public static String ORG_ID = "org-id";
    }

    public interface UpdateStudentProfileConstants {
        public static String PUT_UPDATE_STUDENT_PROFILE_ENDPOINT = "/lms/web/api/v1/students/studentId";
        public static String STUDENT_ID = "studentId";
        public static String TEACHER_USERNAME = "teacherUsername";
        public static String TEACHER_PASSWORD = "teacherPassword";

        // Req Body paramaeter:
        String PERSONID_REQBODY = "personId";
        String USERNAME_REQBODY = "userName";
        String USERPASSWORD_REQBODY = "userPassword";
        String TEACHERID_REQBODY = "teacherId";
        String FIRSTNAME_REQBODY = "firstName";
        String MIDDLENAME_REQBODY = "middleName";
        String LASTNAME_REQBODY = "lastName";
        String BIRTHDAY_REQBODY = "birthday";
        String GRADE_REQBODY = "grade";
        String GENDER_REQBODY = "gender";
        String SPECIAL_SERVICES_REQBODY = "specialServices";
        String HAS_ECONONMIC_DISADVANTAGED_REQBODY = "hasEconomicDisadvantage";
        String HAS_DISABILITY_REQBODY = "hasDisability";
        String HAS_ENGLISH_PROFICIENCY_REQBODY = "hasEnglishProficiency";
        String ISMIGRANT_REQBODY = "isMigrant";
        String ETHINICITY_REQBODY = "ethnicity";
        String STUDENT_IDENTIFICATION_NUMBER_REQBODY = "studentIdentificationNumber";
    }

    public interface StudentSkillAssesedConstants {
        public static String endPoint = "/lms/web/api/v1/organizations/organizationId/staffs/staffId/assignments/assignmentId/students/studentId/skillsTestedReport";
        public static String SUBJECT_TYPE_ID = "subjectTypeId";
        public static String ASSIGNMENT_USER_ID = "assignmentUserID";
        public static String SESSION_DATES = "sessionDates";
        public static String LAST_SESSION_FLAG = "lastSessionFlag";
        public static String INVALID_ASSIGMENT_ID = "invalid_assignment_id";
        public static String INVALID_ASSIGMENT_USER_ID = "invalid_assignment_user_id";
    }

    public interface StudentUsage {
        String POST_STUDENTUSAGE = "/lms/web/api/v1/organization/{organizationId}/staffs/{staffId}/usageReport";
        String STUDENTID = "studentId";
        String GROUPID = "groupId";
        String ASSIGNMENTIDS = "assignmentIds";
        String LAST_WEEK_MINS = "lastWeekMins";
        String THIS_WEEK_MINS = "thisWeekMins";
        String TOTAL_MINTUES = "totalMinutes";
        String STUDENT_USAGE_DATA = "studentUsageData";
        String WEEK = "week";
        String MATH_MINS = "mathMins";
        String READING_MINS = "readingMins";
    }

    public interface getDemographicsConstants {
        String endpoint = "/lms/web/api/v1/demographics";
        String GRADE_NAME = "gradeName";
        String DEMOGRAPHIC_VALUE = "demographicValue";
        String GENDER_RESPONSE_VALUE = "GENDER";
        String DISABILITY_STATUS_RESPONSE_VALUE = "DISABILITY_STATUS";
        String MIGRANT_STATUS_RESPONSE_VALUE = "MIGRANT_STATUS";
        String SOCIOECONOMIC_STATUS_RESPONSE_VALUE = "SOCIOECONOMIC_STATUS";
        String RACE_RESPONSE_VALUE = "RACE";
        String SPECIAL_SERVICES_RESPONSE_VALUE = "SPECIAL_SERVICES";
        String ENGLISH_LANGUAGE_RESPONSE_VALUE = "ENGLISH_LANGUAGE";
        String GET_DEMOGRAPHICS_SCHEMA = "GetDemographicsSchema";
        String SUCCESS_MESSAGE = "Operation succeeded!";
        String ETHINICITY = "ETHNICITY";

    }

    public interface StudentSearchUsingSolar {
        String STUDENT_SOLAR_SEARCH = "/lms/web/api/v1/search/user";
    }

    public interface DemographicValuesForUserProfile {
        String DEMOGRAPHIC_ENDPOINT = "/lms/web/api/v1/demographics";
    }
}