package com.savvas.sm.utils.sme187.teacher.api.groups;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.json.JSONObject;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants.GroupAPIEndPoints;

public class GroupAPI extends EnvProperties {

    /**
     * This method will add the student into group.
     * 
     * @param envUrl
     * @param groupDetails should contains bearer token,group owner id and group
     *            owner org_id it should be in the form of
     *            RBSDataSetupConstants.BEARER_TOKEN,GroupConstants.GROUP_OWNER_ID,GroupConstants.GROUP_OWNER_ORG_ID
     * @param studentRumbaIds
     * @param groupIds
     * @return
     * @throws Exception
     */
    public HashMap<String, String> addStudentToGroup( String envUrl, HashMap<String, String> groupDetails, List<String> studentRumbaIds, List<String> groupIds ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + groupDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, groupDetails.get( GroupConstants.GROUP_OWNER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, groupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = GroupAPIEndPoints.ADD_STUDENT_TO_GROUP_ENDPOINT;

        if ( groupDetails.containsKey( GroupConstants.INVALID_ORG ) ) {
            endPoint = endPoint.replace( new RBSUtils().getRequestBodyParameter( RBSDataSetupConstants.ORGANIZATION_ID ), groupDetails.get( GroupConstants.INVALID_ORG ) );
        } else {
            endPoint = endPoint.replace( new RBSUtils().getRequestBodyParameter( RBSDataSetupConstants.ORGANIZATION_ID ), groupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );
        }

        if ( groupDetails.containsKey( GroupConstants.INVALID_TEACHER ) ) {
            endPoint = endPoint.replace( new RBSUtils().getRequestBodyParameter( GroupConstants.STAFF_ID ), groupDetails.get( GroupConstants.INVALID_TEACHER ) );
        } else {
            endPoint = endPoint.replace( new RBSUtils().getRequestBodyParameter( GroupConstants.STAFF_ID ), groupDetails.get( GroupConstants.GROUP_OWNER_ID ) );
        }

        String requestBody = SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.ADD_STUDENT_TO_GROUP_PAYLOAD );
        if ( studentRumbaIds.size() > 0 ) {
            String listString = "";
            for ( String studentID : studentRumbaIds ) {
                listString += studentID.concat( "\",\"" );
            }
            listString = listString.substring( 0, listString.length() - 3 );
            requestBody = requestBody.replace( new RBSUtils().getRequestBodyParameter( GroupConstants.STUDENT_RUMBA_IDS ), listString );
        } else {
            requestBody = requestBody.replace( new RBSUtils().getRequestBodyParameter( GroupConstants.STUDENT_RUMBA_IDS ), "" );
        }

        if ( groupIds.size() > 0 ) {
            String listString = "";
            for ( String groupID : groupIds ) {
                listString += groupID.concat( "\",\"" );
            }
            listString = listString.substring( 0, listString.length() - 3 );
            requestBody = requestBody.replace( new RBSUtils().getRequestBodyParameter( GroupConstants.GROUP_IDS ), listString );
        } else {
            requestBody = requestBody.replace( new RBSUtils().getRequestBodyParameter( GroupConstants.GROUP_IDS ), "" );
        }

        HashMap<String, String> response = RestHttpClientUtil.PUT( envUrl, headers, params, endPoint, requestBody );
        return response;

    }

    public HashMap<String, String> createGroup( String envUrl, HashMap<String, String> groupDetails, List<String> studentRumbaIds ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + groupDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, groupDetails.get( GroupConstants.GROUP_OWNER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, groupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = GroupAPIEndPoints.CREATE_GROUP_API_ENDPOINT;

        if ( groupDetails.containsKey( GroupConstants.INVALID_ORG ) ) {
            endPoint = endPoint.replace( new RBSUtils().getRequestBodyParameter( RBSDataSetupConstants.ORGANIZATION_ID ), groupDetails.get( GroupConstants.INVALID_ORG ) );
        } else {
            endPoint = endPoint.replace( new RBSUtils().getRequestBodyParameter( RBSDataSetupConstants.ORGANIZATION_ID ), groupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );
        }

        if ( groupDetails.containsKey( GroupConstants.INVALID_TEACHER ) ) {
            endPoint = endPoint.replace( new RBSUtils().getRequestBodyParameter( GroupConstants.STAFF_ID ), groupDetails.get( GroupConstants.INVALID_TEACHER ) );
        } else {
            endPoint = endPoint.replace( new RBSUtils().getRequestBodyParameter( GroupConstants.STAFF_ID ), groupDetails.get( GroupConstants.GROUP_OWNER_ID ) );
        }

        String groupName = groupDetails.get( GroupConstants.GROUP_NAME );
        StringBuilder stringBuilder = new StringBuilder();
        AtomicReference<String> requestBody = new AtomicReference<>();
        stringBuilder.append( "{ \"" + GroupConstants.GROUP_NAME + "\":\"" + groupName + "\",\"" + GroupConstants.STUDENT_RUMBA_IDS + "\":[" );
        IntStream.rangeClosed( 0, studentRumbaIds.size() - 1 ).forEach( index -> {
            stringBuilder.append( "\"" + studentRumbaIds.get( index ) + "\"" );
            if ( index != studentRumbaIds.size() - 1 ) {
                stringBuilder.append( "," );
            }
        } );
        stringBuilder.append( "]}" );
        String body = stringBuilder.toString();
        requestBody.set( body );
        HashMap<String, String> response;
        try {
            response = RestHttpClientUtil.POST( envUrl, headers, params, endPoint, requestBody.get() );
            if ( !response.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                Log.event( "Status code : " + response.get( Constants.STATUS_CODE ) );
                Log.event( "Response : " + response.get( Constants.REPORT_BODY ) );
                throw new Exception();
            }
        } catch ( Exception e ) {
            Log.message( "Getting issue while create the group!!!" );
            Thread.sleep( 3000 );
            response = RestHttpClientUtil.POST( envUrl, headers, params, endPoint, requestBody.get() );
        }
        return response;
    }

    /**
     * Get the Group Detail For Given Teacher ID
     * 
     * @return
     * 
     * @throws Exception
     * 
     */

    public HashMap<String, String> getGroupListingForTeacherID( String url, HashMap<String, String> apiDetails ) throws Exception {
        Map<String, String> headers1;
        HashMap<String, String> params1;
        String endpoint1;
        HashMap<String, String> response1;

        // Headers
        headers1 = new HashMap<String, String>();
        headers1.put( Constants.AUTHORIZATION, "Bearer " + apiDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers1.put( Constants.USERID_SM_HEADER, apiDetails.get( GroupConstants.STAFF_ID ) );
        headers1.put( Constants.ORGID_SM_HEADER, apiDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );

        // Params
        params1 = new HashMap<>();

        if ( apiDetails.containsKey( GroupConstants.INVALID_ORG ) ) {
            params1.put( Constants.ORG_ID_VALUE, apiDetails.get( GroupConstants.INVALID_ORG ) );
        } else {
            params1.put( Constants.ORG_ID_VALUE, apiDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );
        }

        // Endpoint
        endpoint1 = GroupAPIEndPoints.GET_GROUP_LIST_FOR_TEACHERID_NEW_API;

        if ( apiDetails.containsKey( GroupConstants.INVALID_TEACHER ) ) {
            endpoint1 = endpoint1.replace( GroupConstants.USER_ID_ENDPOINT, apiDetails.get( GroupConstants.INVALID_TEACHER ) );
        } else {
            endpoint1 = endpoint1.replace( GroupConstants.USER_ID_ENDPOINT, apiDetails.get( GroupConstants.STAFF_ID ) );
        }

        // Make a Get Call
        try {
            response1 = RestHttpClientUtil.GET( url, endpoint1, headers1, params1 );
            if ( !response1.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                Log.event( "Status code : " + response1.get( Constants.STATUS_CODE ) );
                Log.event( "Response : " + response1.get( Constants.REPORT_BODY ) );
                throw new Exception();
            }
        } catch ( Exception e ) {
            Log.message( "Getting issue while get the group details for teacher!!!" );
            Thread.sleep( 3000 );
            response1 = RestHttpClientUtil.GET( url, endpoint1, headers1, params1 );
        }
        return response1;
    }

    /**
     * 
     * @param envUrl
     * @param studentDetails should contains Authentication token,Teacher ID,
     *            Student ID,School ID
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getStudentDetailsforGroup( String envUrl, HashMap<String, String> viewGroupDetails ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + viewGroupDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, viewGroupDetails.get( GroupConstants.GROUP_OWNER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, viewGroupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();
        Log.message( "Parameters - " + params );

        //Endpoints
        String endPoint = GroupAPIEndPoints.GET_STUDENT_LIST_FOR_GROUP_API;

        if ( viewGroupDetails.containsKey( GroupConstants.INVALID_GROUP_ID ) ) {
            endPoint = endPoint.replace( GroupConstants.GROUP_ID_ENDPOINT, viewGroupDetails.get( GroupConstants.INVALID_GROUP_ID ) );
        } else {
            endPoint = endPoint.replace( GroupConstants.GROUP_ID_ENDPOINT, viewGroupDetails.get( GroupConstants.GROUP_ID ) );

        }
        HashMap<String, String> response = RestHttpClientUtil.GET( envUrl, endPoint, headers, params );

        return response;
    }

    /**
     * To get the most skill assessed for group
     * 
     * @param smUrl
     * @param groupDetails
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getMostSkillAssessedForGroup( String smUrl, HashMap<String, String> groupDetails ) throws Exception {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + groupDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );

        headers.put( Constants.USERID_SM_HEADER, groupDetails.get( GroupConstants.GROUP_OWNER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, groupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );
        String orgID = null;
        String teacherID = null;
        String groupId = null;
        String courseId = null;

        if ( groupDetails.containsKey( GroupConstants.INVALID_ORG ) ) {
            orgID = groupDetails.get( GroupConstants.INVALID_ORG );
        } else {
            orgID = groupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID );
        }

        if ( groupDetails.containsKey( GroupConstants.INVALID_GROUP_OWNER_ID ) ) {
            teacherID = groupDetails.get( GroupConstants.INVALID_GROUP_OWNER_ID );
        } else {
            teacherID = groupDetails.get( GroupConstants.GROUP_OWNER_ID );
        }

        if ( groupDetails.containsKey( GroupConstants.INVALID_GROUP_ID ) ) {
            groupId = groupDetails.get( GroupConstants.INVALID_GROUP_ID );
        } else {
            groupId = groupDetails.get( GroupConstants.GROUP_ID );
        }

        if ( groupDetails.containsKey( GroupConstants.INVALID_CONTENT_BASE ) ) {
            courseId = groupDetails.get( GroupConstants.INVALID_CONTENT_BASE );
        } else {
            courseId = groupDetails.get( GroupConstants.CONTENT_BASE );
        }

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        if ( groupDetails.containsKey( GroupConstants.INVALID_SUBJECT_TYPE ) ) {
            params.put( GroupConstants.SUBJECT_TYPE_ID, groupDetails.get( GroupConstants.INVALID_SUBJECT_TYPE ) );
        } else {
            params.put( GroupConstants.SUBJECT_TYPE_ID, groupDetails.get( GroupConstants.SUBJECT_TYPE_ID ) );
        }

        if ( !groupDetails.containsKey( GroupConstants.SUBJECT_TYPE_ID ) ) {
            params.clear();
        }
        // End point
        String endPoint = GroupAPIEndPoints.MOST_ASSESSED_SKILL_GROUP_ENDPOINT;
        endPoint = String.format( endPoint, orgID, teacherID, courseId, groupId );

        HashMap<String, String> response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );

        return response;

    }

    /**
     * Get response for the Remove Students from Groups API
     * 
     * @param smURL
     * @param studentId
     * @param groupId
     * @param teacherId
     * @param orgId
     * @param accessToken
     * @return
     */
    public HashMap<String, String> removeStudentFromGroup( String smURL, String studentId, String groupId, String teacherId, String orgId, String accessToken ) {
        String endpoint = GroupConstants.RemoveStudentsFromGroupsAPIConstants.ENDPOINT;
        Map<String, String> headers = new HashMap<String, String>();
        HashMap<String, String> params = new HashMap<>();
        HashMap<String, String> response = new HashMap<>();

        try {
            // Endpoint
            endpoint = endpoint.replace( GroupConstants.RemoveStudentsFromGroupsAPIConstants.ORG_ID, orgId );
            endpoint = endpoint.replace( GroupConstants.RemoveStudentsFromGroupsAPIConstants.STAFF_ID, teacherId );

            // headers
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
            headers.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.ORG_ID_HEADER, orgId );
            headers.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.USER_ID_HEADER, teacherId );

            // Input Parameters
            params.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.STUDENT_IDS, studentId );
            params.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.GROUP_IDS, groupId );

            // Getting resonse
            response = RestHttpClientUtil.DELETE( smURL, endpoint, headers, params );
            Log.message( "The Received response is : " + response.toString() );

        } catch ( Exception e ) {
            Log.message( e.getMessage() );
            return null;
        }
        return response;
    }

    /**
     * To get only recent assignments in HomePage
     * 
     * @param envUrl
     * @param groupId
     * @param orgId
     * @return response
     * @throws Exception
     */
    public HashMap<String, String> StudentsNotPartOfGroupAPI( String envUrl, HashMap<String, String> userDetails ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        String teacherID = userDetails.get( GroupConstants.GROUP_OWNER_ID );
        String orgID = userDetails.get( GroupConstants.GROUP_OWNER_ORG_ID );
        String groupID = userDetails.get( GroupConstants.GROUP_ID );

        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + userDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, userDetails.get( GroupConstants.GROUP_OWNER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, userDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        if ( userDetails.containsKey( GroupConstants.INVALID_GROUP_ID ) ) {
            params.put( GroupConstants.GROUP_ID, userDetails.get( GroupConstants.INVALID_GROUP_ID ) );
        } else {
            params.put( GroupConstants.GROUP_ID, groupID );
        }
        if ( userDetails.containsKey( GroupConstants.INVALID_ORG ) ) {
            params.put( RBSDataSetupConstants.ORGANIZATION_ID, userDetails.get( GroupConstants.INVALID_ORG ) );
        } else {
            params.put( RBSDataSetupConstants.ORGANIZATION_ID, orgID );
        }
        Log.message( "Parameters - " + params );

        // Input Path Parameters
        String endPoint = GroupAPIEndPoints.STUDENTS_NOT_PARTOF_GROUP;

        //String endPoint = null;
        if ( userDetails.containsKey( GroupConstants.INVALID_TEACHER ) ) {
            endPoint = endPoint.replace( GroupConstants.TEACHER_ID, GroupConstants.INVALID_TEACHER );

        } else {
            endPoint = endPoint.replace( GroupConstants.TEACHER_ID, teacherID );
        }

        return RestHttpClientUtil.GET( envUrl, endPoint, headers, params );

    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) {
        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception! Expected - " + exception + "Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ) );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

    /**
     * 
     * @param envUrl
     * @param studentDetails should contains Authentication token,Teacher ID,
     *            Student ID,School ID
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getGroupDetailsAssignmentNotPartOfGrp( String envUrl, HashMap<String, String> viewGroupDetails ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + viewGroupDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, viewGroupDetails.get( GroupConstants.GROUP_OWNER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, viewGroupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();
        Log.message( "Parameters - " + params );

        //Endpoints
        String endPoint = GroupAPIEndPoints.GET_GROUP_LIST_FOR_ASSIGNMENT_NOTPARTOF_API;

        if ( viewGroupDetails.containsKey( GroupConstants.INVALID_ORG ) ) {
            endPoint = endPoint.replace( GroupConstants.ORG_ID_ENDPOINT, viewGroupDetails.get( GroupConstants.INVALID_ORG ) );
        } else {
            endPoint = endPoint.replace( GroupConstants.ORG_ID_ENDPOINT, viewGroupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );

        }
        if ( viewGroupDetails.containsKey( GroupConstants.INVALID_GROUP_OWNER_ID ) ) {
            endPoint = endPoint.replace( GroupConstants.STAFF_ID_ENDPOINT, viewGroupDetails.get( GroupConstants.INVALID_GROUP_OWNER_ID ) );
        } else {
            endPoint = endPoint.replace( GroupConstants.STAFF_ID_ENDPOINT, viewGroupDetails.get( GroupConstants.GROUP_OWNER_ID ) );

        }
        if ( viewGroupDetails.containsKey( GroupConstants.INVALID_COURSE_ID ) ) {
            endPoint = endPoint.replace( GroupConstants.COURSE_ID_ENDPOINT, viewGroupDetails.get( GroupConstants.INVALID_COURSE_ID ) );
        } else {
            endPoint = endPoint.replace( GroupConstants.COURSE_ID_ENDPOINT, viewGroupDetails.get( GroupConstants.COURSE_ID_ENDPOINT ) );

        }
        HashMap<String, String> response = RestHttpClientUtil.GET( envUrl, endPoint, headers, params );
        return response;

    }

    /**
     * To get the group listing that given Students not belongs to it
     * 
     * @param envUrl
     * @param StudentIds
     * @param teacherId
     * @param orgId
     * @param accessToken
     * @return
     */
    public HashMap<String, String> GetGroupsListingForStudentsNotBelongTo( String envUrl, List<String> StudentIds, String teacherId, String orgId, String accessToken ) {

        String endPoint = GroupAPIEndPoints.GET_GROUPLIST_STUDENTS_NOT_BELONG_TO;
        Map<String, String> headers = new HashMap<String, String>();
        HashMap<String, String> response = null;
        HashMap<String, String> params = new HashMap<>();
        String body = null;
        try {

            // End point
            endPoint = String.format( endPoint, orgId, teacherId );

            //Parameters
            Log.message( "Parameters - " + params );

            // headers
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + accessToken );
            headers.put( Constants.USERID_SM_HEADER, teacherId );
            headers.put( Constants.ORGID_SM_HEADER, orgId );

            // Body
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append( "{\"studentIds\":[" );
            IntStream.rangeClosed( 0, StudentIds.size() - 1 ).forEach( index -> {
                stringBuilder.append( "\"" + StudentIds.get( index ) + "\"" );
                if ( index != StudentIds.size() - 1 ) {
                    stringBuilder.append( "," );
                }
            } );
            stringBuilder.append( "]}" );
            body = stringBuilder.toString();

            // Respone
            response = RestHttpClientUtil.POST( envUrl, headers, params, endPoint, body );
            Log.message( "The response is  : " + response.toString() );
        } catch ( Exception e ) {
            Log.message( "Exception is : " + e.getMessage() );
        }
        return response;
    }

    public List<String> getgroupDetails( String groupId ) {
        String getData;
        List<Object[]> listItems = null;
        List<String> courseIds = new ArrayList<>();
        getData = "select assignment_id from school.assignment_group where group_id = '" + groupId + "'";
        listItems = SQLUtil.executeQuery( getData );
        for ( int i = 0; i < listItems.size(); i++ ) {
            courseIds.add( listItems.get( i )[0].toString() );
        }
        return courseIds;
    }

    public List<String> getStudentAssignmentDetails( String studentId ) {
        String getData;
        List<Object[]> listItems = null;
        List<String> courseIds = new ArrayList<>();
        getData = "select a.content_base_id from school.assignment as a join school.assignment_user as au on a.assignment_id = au.assignment_id where au.person_id = '" + studentId + "'";
        listItems = SQLUtil.executeQuery( getData );
        for ( int i = 0; i < listItems.size(); i++ ) {
            courseIds.add( listItems.get( i )[0].toString() );
        }
        return courseIds;

    }

    /**
     * Create Group with No. of Teacher and Students and Organization
     * 
     * @param className
     * @param teachedId
     * @param StudentIds
     * @param orgId
     * @param accessToken
     * @return
     * @throws Exception
     */
    public String createGroupWithCustomization( String className, String teacherId, List<String> StudentIds, String orgId, String accessToken ) throws Exception {
        HashMap<String, String> result = null;
        try {
            HashMap<String, String> groupDetails = new HashMap<>();
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
            groupDetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
            groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
            groupDetails.put( GroupConstants.GROUP_NAME, className );
            result = createGroup( configProperty.getProperty( "SMAppUrl" ), groupDetails, StudentIds );
            return SMUtils.getKeyValueFromResponse( result.get( Constants.REPORT_BODY ), "data," + GroupConstants.GROUP_ID );

        } catch ( Exception e ) {
            Log.failsoft( "Issues in Creating Group!" );
            Log.message( result.get( Constants.REPORT_BODY ) );
            return null;

        }

    }

    /**
     * return true if all the students is present on the class
     * 
     * @param classId
     * @param accessToken
     * @param studentIds
     */
    public boolean isStudentsPresentinClass( String accessToken, String classId, List<String> studentIds ) {
        String class1 = new RBSUtils().getClass( classId );
        ArrayList<String> keyValues = new SMAPIProcessor().getKeyValues( new JSONObject( class1 ), "studentIds" );
        AtomicBoolean flag = new AtomicBoolean();
        flag.set( true );
        studentIds.forEach( id -> {
            if ( !keyValues.contains( id ) ) {
                flag.set( false );
            }
        } );
        return flag.get();
    }

    /**
     * To create Group with no students
     * 
     * @param groupName
     * @param teacherId
     * @param orgId
     * @param accessToken
     * @return
     */
    public String createEmptyGroup( String groupName, String teacherId, String orgId, String accessToken ) {
        try {
            return createGroupWithCustomization( groupName, teacherId, new ArrayList<String>(), orgId, accessToken );
        } catch ( Exception e ) {
            return null;
        }
    }

    /**
     * 
     * @param envUrl
     * @param studentDetails should contains Authentication token,Teacher ID,
     *            Student ID,School ID
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getGroupsForStudentID( String envUrl, HashMap<String, String> studentDetails ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + studentDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, studentDetails.get( GroupConstants.GROUP_OWNER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, studentDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        if ( studentDetails.containsKey( GroupConstants.INVALID_TEACHER ) ) {
            params.put( GroupConstants.STAFF_ID, studentDetails.get( GroupConstants.INVALID_TEACHER ) );
        } else {
            params.put( GroupConstants.STAFF_ID, studentDetails.get( GroupConstants.GROUP_OWNER_ID ) );
        }
        if ( studentDetails.containsKey( GroupConstants.GROUP_OWNER_ORG_ID ) ) {
            params.put( GroupConstants.ORG_ID, studentDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );
        }
        if ( studentDetails.containsKey( GroupConstants.INVALID_ORG ) ) {
            params.put( GroupConstants.ORG_ID, studentDetails.get( GroupConstants.INVALID_ORG ) );
        }
        Log.message( "Parameters - " + params );

        //Endpoints
        String endPoint = null;
        if ( studentDetails.containsKey( GroupConstants.INVALID_STUDENT ) ) {
            endPoint = String.format( GroupAPIEndPoints.GET_GROUP_LIST_FOR_STUDENT_API, studentDetails.get( GroupConstants.INVALID_STUDENT ) );
        } else {
            endPoint = String.format( GroupAPIEndPoints.GET_GROUP_LIST_FOR_STUDENT_API, studentDetails.get( GroupConstants.STUDENT_ID ) );
        }
        HashMap<String, String> response = RestHttpClientUtil.GET( envUrl, endPoint, headers, params );

        return response;
    }

    /*
     * @param envUrl
     * 
     * @param groupDetails should contains group name, organization ID, teacher
     * ID and bearer token
     * 
     * @param studentRumbaIds If there is no student please leave as empty
     * 
     * @return
     * 
     * @throws Exception
     */
    public HashMap<String, String> updateGroup( String envUrl, HashMap<String, String> groupDetails ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + groupDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, groupDetails.get( GroupConstants.GROUP_OWNER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, groupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = GroupAPIEndPoints.UPDATE_GROUP_API;

        endPoint = endPoint.replace( "{group_id}", groupDetails.get( GroupConstants.GROUP_ID ) );

        AtomicReference<String> requestBody = new AtomicReference<>();
        String requestBodyFile = new File( "." ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "PayLoad" + File.separator + "updateGroupPayload.json";
        requestBody.set( SMUtils.convertFileToString( requestBodyFile ) );
        if ( groupDetails.containsKey( GroupConstants.INVALID_GROUP_ID ) ) {
            requestBody.set( JSONUtil.setProperty( requestBody.get(), GroupConstants.GROUP_ID, groupDetails.get( GroupConstants.INVALID_GROUP_ID ) ) );
        } else {
            requestBody.set( JSONUtil.setProperty( requestBody.get(), GroupConstants.GROUP_ID, groupDetails.get( GroupConstants.GROUP_ID ) ) );
        }
        if ( groupDetails.containsKey( GroupConstants.INVALID_GROUP_NAME ) ) {
            requestBody.set( JSONUtil.setProperty( requestBody.get(), GroupConstants.GROUP_NAME, groupDetails.get( GroupConstants.INVALID_GROUP_NAME ) ) );
        } else {
            requestBody.set( JSONUtil.setProperty( requestBody.get(), GroupConstants.GROUP_NAME, groupDetails.get( GroupConstants.GROUP_NAME ) ) );
        }
        if ( groupDetails.containsKey( GroupConstants.INVALID_GROUP_OWNER_ID ) ) {
            requestBody.set( JSONUtil.setProperty( requestBody.get(), GroupConstants.GROUP_OWNER_ID, groupDetails.get( GroupConstants.INVALID_GROUP_OWNER_ID ) ) );
        } else {
            requestBody.set( JSONUtil.setProperty( requestBody.get(), GroupConstants.GROUP_OWNER_ID, groupDetails.get( GroupConstants.GROUP_OWNER_ID ) ) );
        }

        HashMap<String, String> response = RestHttpClientUtil.PUT( envUrl, headers, params, endPoint, requestBody.get() );
        return response;

    }

    /**
     * delete Group
     * 
     * @param groupId
     * @param teacherId
     * @param orgId
     * @param accessToken
     * @return
     */
    public HashMap<String, String> deleteGroup( String groupId, String teacherId, String orgId, String accessToken ) {
        try {

            // Endpoint
            String endpoint = GroupAPIEndPoints.DELETE_GROUP_ENDPOINT;
            endpoint = endpoint.replace( GroupConstants.GROUP_ID, groupId );

            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
            headers.put( GroupConstants.ORG_ID_HEADER, orgId );
            headers.put( GroupConstants.USER_ID_HEADER, teacherId );

            // Input Parameters
            HashMap<String, String> params = new HashMap<>();

            // Make DELETE Call
            Log.message( "Making DELETE Call - " + configProperty.getProperty( "SMAppUrl" ) + GroupAPIEndPoints.DELETE_GROUP_ENDPOINT );
            HashMap<String, String> response;
            try {
                response = RestHttpClientUtil.DELETE( configProperty.getProperty( "SMAppUrl" ), endpoint, headers, params );
                if ( !response.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                    Log.event( "Status code : " + response.get( Constants.STATUS_CODE ) );
                    Log.event( "Response : " + response.get( Constants.REPORT_BODY ) );
                    throw new Exception();
                }
            } catch ( Exception e ) {
                Log.message( "Getting issue while delete the group!!!" );
                Thread.sleep( 3000 );
                response = RestHttpClientUtil.DELETE( configProperty.getProperty( "SMAppUrl" ), endpoint, headers, params );
            }
            return response;
        } catch ( Exception e ) {
            return null;

        }
    }

    public HashMap<String, String> getGroupUsage( String envUrl, HashMap<String, String> groupDetails ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + groupDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, groupDetails.get( GroupConstants.STAFF_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, groupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        params.put( GroupConstants.GROUP_ID, groupDetails.get( GroupConstants.GROUP_ID ) );

        //Endpoints

        String endPoint = GroupAPIEndPoints.POST_GROUP_USAGE_END_POINT;

        if ( groupDetails.containsKey( GroupConstants.INVALID_ORG ) ) {
            endPoint = endPoint.replace( GroupConstants.ORG_ID_ENDPOINT, groupDetails.get( GroupConstants.INVALID_ORG ) );
        } else {
            endPoint = endPoint.replace( GroupConstants.ORG_ID_ENDPOINT, groupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ) );
        }

        if ( groupDetails.containsKey( GroupConstants.INVALID_TEACHER ) ) {
            endPoint = endPoint.replace( GroupConstants.STAFF_ID_ENDPOINT, groupDetails.get( GroupConstants.INVALID_TEACHER ) );
        } else {
            endPoint = endPoint.replace( GroupConstants.STAFF_ID_ENDPOINT, groupDetails.get( GroupConstants.STAFF_ID ) );
        }

        String requestBody = SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.GROUP_USAGE_PAYLOAD );

        HashMap<String, String> response = RestHttpClientUtil.POST( envUrl, headers, params, endPoint, requestBody );

        return response;

    }

    /**
     * Get Group List for Selected Teachers in the Admin Board
     * 
     * @param apiDetails
     * @param teacherIds
     * @param orgIds
     * @return
     */

    public HashMap<String, String> getGroupListForGivenTeacherIdAdminReports( HashMap<String, String> apiDetails, List<String> teacherIds, List<String> orgIds ) throws Exception {
        HashMap<String, String> response = null;
        String body;
        try {
            // Headers
            HashMap<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + apiDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );

            // Input Params
            HashMap<String, String> params = new HashMap<>();

            String endpoint = "/graphql";

            StringBuffer requestBody = new StringBuffer();
            requestBody.append( "{\"query\":\"query {  getGroupsList( userId:\\\"" + apiDetails.get( GroupConstants.RUMBA_ID ) + "\\\" ,  orgIds: [  \\\"" );
            for ( int i = 0; i < orgIds.size(); i++ ) {
                requestBody.append( orgIds.get( i ) );
                if ( i != orgIds.size() - 1 ) {
                    requestBody.append( "\\\",\\\"" );
                } else {
                    requestBody.append( "\\\"" );
                }
            }
            requestBody.append( "]" );

            requestBody.append( "teacherIds: [ \\\"" );
            for ( int i = 0; i < teacherIds.size(); i++ ) {
                requestBody.append( teacherIds.get( i ) );
                if ( i != teacherIds.size() - 1 ) {
                    requestBody.append( "\\\",\\\"" );
                } else {
                    requestBody.append( "\\\"" );
                }
            }
            requestBody.append( "] ) {    groups {     groupId      groupName  }}}\",\"variables\": {}}" );

            //Hitting Post call for getting Group List for the Teacher in Admin Dash Board
            response = RestHttpClientUtil.POST( configProperty.getProperty( ConfigConstants.GET_GROUPLIST_USERSERVICE_REPORTS ), headers, params, endpoint, requestBody.toString() );

            Log.message( "The response is : " + response.toString() );
            return response;

        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }

    }

}
