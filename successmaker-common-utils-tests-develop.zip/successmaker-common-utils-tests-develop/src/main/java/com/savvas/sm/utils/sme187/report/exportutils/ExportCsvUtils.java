package com.savvas.sm.utils.sme187.report.exportutils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

public class ExportCsvUtils {

    /**
     * To Split and Store the response csv data
     * 
     * @return
     * @throws IOException
     * 
     */
    public static String getCsvFileHeasers( String response ) {
        List<String> valueList = new ArrayList<>( Arrays.asList( response.split( "\n" ) ) );
        return valueList.remove( 0 );
    }

    /**
     * To Split and Store the response csv data
     *
     * @return
     *
     * @throws IOException
     *
     */
    public static List<Map<String, String>> splitCSVData( String response ) {
        List<Map<String, String>> keysAndValueList = new ArrayList<>();

        List<String> valueList = new ArrayList<>( Arrays.asList( response.split( "\n" ) ) );
        List<String> keys = Arrays.asList( valueList.get( 0 ).split( "," ) );

        valueList.remove( 0 );

        valueList.stream().forEach( row -> {
            List<String> rowValues = Arrays.asList( row.split( "," ) );
            List<String> rowValue = new ArrayList<>();
            for ( int itr = 0; itr < rowValues.size(); itr++ ) {
                if ( !rowValues.get( itr ).isEmpty() ) {
                    String rowText = rowValues.get( itr ).trim();
                    if ( ( rowText.charAt( 0 ) == '"' && rowText.charAt( rowText.length() - 1 ) == '"' ) || ( !( rowText.charAt( 0 ) == '"' ) && !( rowText.charAt( rowText.length() - 1 ) == '"' ) ) ) {
                        rowValue.add( rowText.startsWith( "\"" ) ? rowText.substring( 1, rowText.length() - 1 ) : rowText );
                    } else {
                        String value = rowValues.get( itr ).trim();
                        while ( !( value.startsWith( "\"" ) && value.endsWith( "\"" ) ) ) {
                            itr++;
                            value = value + "," + rowValues.get( itr ).trim();
                        }
                        rowValue.add( value.startsWith( "\"" ) ? value.substring( 1, value.length() - 1 ) : value );
                    }
                }
            }
            Map<String, String> keysAndValue = new HashMap<>();
            IntStream.range( 0, rowValue.size() ).forEach( itr -> {
                keysAndValue.put( keys.get( itr ), rowValue.get( itr ) );
            } );
            keysAndValueList.add( keysAndValue );
        } );
        Log.message( "Splitted data: " + keysAndValueList );
        return keysAndValueList;

    }

    /**
     * This method is used to get API values for given keys
     * 
     * @param response
     * @param studentUsername
     * @param assignmentId
     * @param values
     * @return
     */
    public static Map<String, String> getValuesFromLSResponse( String response, String studentUsername, String assignmentId, List<String> values ) {
        Map<String, String> valueList = new HashMap<>();

        try {
            String fromResponse = SMUtils.getKeyValueFromResponse( response, "data" );
            JSONArray jsonArray = new JSONObject( fromResponse ).getJSONArray( "getLSAdminReportData" );
            String assignmentName = SqlHelperAssignment.getAssignmentDetails( assignmentId ).get( 1 );

            IntStream.range( 0, jsonArray.length() ).forEach( itr -> {
                JSONObject jObj = jsonArray.getJSONObject( itr );
                if ( jObj.get( "studentUsername" ).toString().equals( studentUsername ) && jObj.get( "assignmentTitle" ).toString().equals( assignmentName ) ) {
                    values.stream().forEach( value -> {
                        if ( new JSONObject( jObj.toString() ).get( "rawPerformance" ).toString().contains( value ) ) {
                            valueList.put( value, SMUtils.getKeyValueFromResponse( new JSONObject( jObj.toString() ).get( "rawPerformance" ).toString(), value ) );

                        } else if ( new JSONObject( jObj.toString() ).get( "usage" ).toString().contains( value ) ) {
                            valueList.put( value, SMUtils.getKeyValueFromResponse( new JSONObject( jObj.toString() ).get( "usage" ).toString(), value ) );

                        } else {
                            valueList.put( value, jObj.get( value ).toString() );

                        }
                    } );
                }
            } );
        } catch ( Exception e ) {
            Log.message( e.getMessage() );
        }
        return valueList;
    }

    /**
     * 
     * @param response
     * 
     * @return
     */
    public static List<String> getCSVHeadersFromResponse( String response ) {
        List<String> valueList = new ArrayList<>( Arrays.asList( response.split( "\n" ) ) );
        return Arrays.asList( valueList.get( 0 ).split( "," ) );
    }

    /**
     * This method is used to split the CSV data
     *
     * @return
     *
     * @throws IOException
     *
     */
    public static List<Map<String, String>> splitCSVDataFromResponse( String response ) {
        List<Map<String, String>> keysAndValueList = new ArrayList<>();

        List<String> valueList = new ArrayList<>( Arrays.asList( response.split( "\n" ) ) );
        List<String> keys = Arrays.asList( valueList.get( 0 ).replace( "\"", "" ).split( "," ) );

        valueList.remove( 0 );

        valueList.forEach( row -> {
            List<String> rowValues = Arrays.asList( row.split( "," ) );
            List<String> rowValue = new ArrayList<>();
            for ( int itr = 0; itr < rowValues.size(); itr++ ) {
                if ( !rowValues.get( itr ).isEmpty() ) {
                    String rowText = rowValues.get( itr ).trim();

                    if ( ( rowText.charAt( 0 ) == '"' && rowText.charAt( rowText.length() - 1 ) == '"' ) || ( ( rowText.charAt( 0 ) != '"' ) && ( rowText.charAt( rowText.length() - 1 ) != '"' ) ) ) {
                        rowValue.add( rowText.startsWith( "\"" ) ? rowText.substring( 1, rowText.length() - 1 ) : rowText );
                    } else {
                        String value = rowValues.get( itr ).trim();
                        while ( !( value.startsWith( "\"" ) && value.endsWith( "\"" ) ) ) {
                            itr++;
                            value = value + "," + rowValues.get( itr ).trim();
                        }
                        rowValue.add( value.startsWith( "\"" ) ? value.substring( 1, value.length() - 1 ) : value );
                    }
                }
            }
            Map<String, String> keysAndValue = new HashMap<>();
            IntStream.range( 0, rowValue.size() ).forEach( itr -> {
                keysAndValue.put( keys.get( itr ), rowValue.get( itr ) );
            } );
            keysAndValueList.add( keysAndValue );
        } );

        return keysAndValueList;
    }

    /**
     * To get the downloaded file content from Browserstack
     * 
     * @param driver
     * @return
     */
    public static String getCsvDataFromBS( WebDriver driver ) {
        String csvData = null;
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        int itr = 0;
        do {
            try {
                //Waiting for file download to complete
                String base64EncodedFile = (String) jse.executeScript( "browserstack_executor: {\"action\": \"getFileContent\"}" );
                // Decode the content to Base64 and write to a file
                byte[] data = Base64.getDecoder().decode( base64EncodedFile );
                csvData = new String( data );
                Log.message( "CSV file data: " + csvData );
            } catch ( Exception e ) {
                e.getMessage();
                Log.message( "Issue on reading the file. Retrying...." );
                //Waiting for file downloading
                SMUtils.nap( 30 );
                itr++;
            }
        } while ( Objects.isNull( csvData ) && itr < 3 );
        return csvData;
    }

    /**
     * To check whether the file is downloaded or not
     * 
     * @param driver
     * @return
     */
    public static boolean isCsvFileDownloaded( WebDriver driver ) {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        int itr = 0;
        do {
            try {
                if ( (boolean) jse.executeScript( "browserstack_executor: {\"action\": \"fileExists\"}" ) ) {
                    Log.message( "CSV file is downloaded successfully!!!" );
                    return true;
                }
            } catch ( Exception e ) {
                Log.fail( "Csv file is not downloaded..Retrying!!!" );
                SMUtils.nap( 15 );
                itr++;
            }

        } while ( itr < 3 );
        return false;
    }

    /**
     * To get the downloaded file name
     * 
     * @param driver
     * @return
     */
    public static String getCsvFileNameFromBS( WebDriver driver ) {
        String fileName = null;
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        int itr = 0;
        do {
            try {
                Map<String, String> properties = (Map<String, String>) jse.executeScript( "browserstack_executor: {\"action\": \"getFileProperties\"}" );
                Log.message( properties.toString() );
                fileName = properties.get( "file_name" );
            } catch ( Exception e ) {
                e.getMessage();
                Log.message( "Issue on reading the file. Retrying...." );
                //Waiting for file downloading
                SMUtils.nap( 30 );
            }
            itr++;
        } while ( Objects.isNull( fileName ) && itr < 3 );
        return fileName;
    }

}
