package com.savvas.sm.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

public interface Constants {

    public static String COPYRIGHT_SYMBOL = "©";
    public static String COPYRIGHT_HEXCODE = "&#169;";
    public static String HTML_BREAK_TAG = "<br>";
    public static String HTML_BOLD_TAG_OPEN = "<b>";
    public static String HTML_BOLD_TAG_CLOSE = "</b>";
    public String ATTEMPT_COLOR_CODE = "#6F777B";
    public static String BUTTON_COLOR_CODE = "#cc333f";

    public static String HTML_TC_DESC_BEGIN = "<div class=\"test-title\"> <strong><font size = \"3\" color = \"#FF69B4\">";
    public static String HTML_TC_DESC_CLOSE = "</font> </strong> </div>";

    public static String LOGIN_URL_RESOURCE = "/lms/sm.view?action=relogin";
    public static String LOGOUT_URL_RESOURCE = "/lms/sm.view?action=logout";
    public static String GET_STAFF_PROFILE = "/lms/web/users/staffs";
    public static String GET_STUDENT_LIST_TEACHER = "/lms/web/api/v1/staffs/{staff_id}/students";
    public static String GET_STUDENT_LIST_GROUP = "/lms/web/api/v1/groups/{group_id}/students";
    public static String GET_REPORT_FILTEROPTION = "/lms/web/api/v1/organization/{organizationId}/staffs/{staffId}/reports/{reportId}/filters";
    public static String POST_REPORT_FILTEROPTION = "/lms/web/api/v1/organization/{organizationId}/staffs/{staffId}/reports/{reportId}/filters";
    public static String GET_COURSE_SETTINGS = "/lms/web/api/v1/courses/{course_id}/settings";
    public static final String PUT_SKILLCOURSES = "/lms/web/api/v1/organizations/{org_id}/staffs/{staff_id}/courses/{course_id}";
    public static String COURSE_SELECTED_HIERARCHY = "/lms/web/api/v1/courses/{course_id}/hierarchyStatus ";
    public static String PUT_COURSE_SETTINGS = "/lms/web/api/v1/courses/{course_id}/settings";
    public static String GET_DEMOGRAPHICS_DETAILS = "/lms/web/api/v1/demographics";
    public static String PUT_REPORT_FILTEROPTION = "/lms/web/api/v1/organization/{organizationId}/staffs/{staffId}/reports/{reportId}/filters/{filterid}";
    public static String CREATE_USER = "/lms/web/api/v1/students";
    public static final String PUT_CUSTOM_BY_STANDARD = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}";
    public static final String PUT_CUSTOM_BY_SETTING = "/lms/web/api/v1/organizations/{org_id}/staffs/{staff_id}/courses/{course_id}";

    public static String GET_STUDENT_PROFILE = "/lms/web/users/students/";
    public static String POST_STUDENT_SEARCH = "/lms/web/api/v1/search/user";
    public static String GET_GRADES_LIST = "/lms/web/api/v1/grades";
    public static final String GET_COURSES_LIST_TEACHER_LEVEL = "/lms/web/api/v1/organizations/{org_id}/staffs/{teacher_id}/courses";
    public static final String GET_COURSES_LIST_ORG_LEVEL = "/lms/web/api/v1/organizations/{org_id}/courses/";
    public static String POST_GROUP_SEARCH = "/lms/web/api/v1/organization/{organizationId}/staffs/{staffId}/groups";
    public static String GET_GROUP_LIST = "/lms/web/api/v1/users/{person_Id}/groups";
    public static String GET_COURSE_DETAILS_SKILL_BASED_API = "/lms/web/api/v1/skills/{contentbaseid}/hierarchy";
    public static String GET_COURSE_DETAILS_STANDARD_BASED_API = "/lms/web/api/v1/standards/{contentbaseid}/hierarchy";
    public static String DELETE_GROUP_DETAILS = "/lms/web/api/v1/groups/{groupID}";
    public static String POST_GROUP_CREATION = "/lms/web/api/v1/groups";
    public static String POST_STUDENT_USAGE = "/lms/web/api/v1/organization/{organizationId}/staffs/{staffId}/usageReport";
    public static String DELETE_COURSE = "/lms/web/api/v1/courses/{courseId}";
    public static String DELETE_ORPHAN_COURSE = "/lms/web/api/v1/courses/orphaned";
    public static String PUT_STUDENT_PROFILE = "/lms/web/api/v1/students/{studentId}";
    public static String GET_ASSIGNMENT_SETTINGS = "/lms/web/api/v1/courses/{course_id}/settings";
    public static String GET_USER_DETAILS = "/lms/web/api/v1/me";
    public static String PUT_ADDSTUDENTS_GROUP = "/lms/web/api/v1/organization/{organizationId}/staffs/{staffId}/groups/students";
    public static String DELETE_STUDENTS_FROM_GROUP = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/groups/students";
    public static String POST_STANDARD_COURSE_COPY = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/copy";
    public static String POST_SKILLS_TESTED = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/assignments/{assignmentId}/students/{studentId}/skillsTestedReport";
    public static String GET_STUDENT_ASSIGNMENT_SETTINGS = "/lms/web/api/v1/students/studentId/assignments/assignmentId/settings";
    public static String GET_GROUP_ASSIGNMENT_SETTINGS = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/groups/groupId/courseassignments/{courseId}/settings";
    public static String STUDENT_PROGRESS_MONITORING = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/students/{studentIds_value}/assignments/{assignmentIdValue}/progressMonitoring";
    String STUDENT_PERFORMANCE_DETAILS = "/lms/web/api/v1/mastery/organizations/{organizationId}/staffs/{staffId}/performanceDetails";
    String MATH_HIERARCHY_DETAILS = "/lms/web/api/v1/standards/1/hierarchy";
    String READING_HIERARCHY_DETAILS = "/lms/web/api/v1/standards/2/hierarchy";
    public static String GET_STUDENTS_NOT_PART_OF_GROUP = "/lms/web/api/v1/staffs/{staffId}/students";
    public static final String GET_COURSE_LIST_ENHANCEMENT = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses";
    public static String TRANSFER_TEACHER = "/lms/web/transfer/toschool/{new_organizationId}/teachers/fromschool/{organizationId}";
    public static String TRANSFER_STUDENT = "/lms/web/transfer/toschool/{new_organizationId}/students";
    public static String RESTORE_ASSIGNMENT = "/lms/web/assignment/restore";
    public static String STUDENT_NAME = "smsautos1t1S1 smsautos1t1S1";
    public static String GROUP_NAME_TEACHER1 = "smautoGroupt1Group1";
    public static String STUDENT_ID_TEACHER1 = "smsautos1t1S1";
    public static String ASCENDING = "Ascending";
    public static String DESCENDING = "Descending";
    public static String GET_SKILLS_ASSESSMENT = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/contentBase/{contentBaseId}/groups/{groupId}/mostAssessedSkills";
    public static String PASSWORD_TEXT = "password";
    public static String CHECKBOX_COLOR = "#02549c";
    public static String TOP_CHECKBOX_COLOR = "#007bff";
    public static String WHITEHEX_COLOR = "#000000";
    public static String PERSON_ID_DATAVALUE = "data,personId";
    public static String DEFAULT_MATH_ID = "1";

    /**
     * API parameters
     */
    public static String STUDENT_LIST_PARAM = "organizationId";

    /**
     * Header details.
     */

    public static String ACCEPT_TYPE = "accept";
    public static String JSON_CONTENT_TYPE = "application/json";
    public static String JSON_CONTENT_TYPE_EMPTY = org.apache.commons.lang3.StringUtils.EMPTY;
    public static String COOKIES = "Cookie";
    public static String COOKIES_INVALID = "Cookie123";
    public static String FORM_CONTENT_TYPE = "application/x-www-form-urlencoded";
    public static String CONTENT_TYPE = "Content-Type";
    public static String XML_CONTENT_TYPE = "application/xml";
    public static String GET_USER_PROFILE = "/lms/web/api/v1/users/{person_id}";
    public static String ZIP_CONTENT_TYPE = "application/zip";
    public static String HEADER_CONTENT_DISPOSITION = "Content-Disposition";
    public static String HEADER_CONTENT_LENGTH = "Content-Length";
    public static String AUTHORIZATION = "Authorization";
    public static String BEARER = "Bearer ";
    public static String SOAP_CONTENT_TYPE = "application/soap+xml";
    public static String USERID_HEADER = "userId";
    public static String USERIDS_HEADER = "userIds";
    public static String USERID_SM_HEADER = "user-id";
    public static String ORGID_SM_HEADER = "org-id";
    public static String ORGIDS_HEADER = "orgIds";

    /**
     * Endpoints related to Assignments
     */

    public static String RESPONSE_BODY = "body";
    public static String STATUS_CODE = "statusCode";
    public static String GET_ASSIGNMENT_DETAILS = "/lms/web/api/v1/organizations/{organisation-id}/staffs/{staff-id}/assignments";
    public static String DELETE_FLUENCY_FILES = "/lms/web/api/v1/assignments/users/{assignmentUserId}/fluency/files";
    public static String GET_FLUENCY_FILES = "/lms/web/api/v1/assignments/users/{assignmentUserId}/fluency/metadata";
    public static String GET_ASSIGNMENT_DETAILS_BY_CONTENTBASEID = "/lms/web/api/v1/organizations/{organization-id}/staffs/{staff-id}/courseassignments/{contentbaseId}/students";
    public static String GET_ASSIGNMENT_DETAILS_BY_STUDENTID = "/lms/web/api/v1/organizations/{organization-id}/staffs/{staff-id}/students/{student-id}/assignments";
    public static String GET_ASSIGNMENT_DETAILS_BY_GROUPID = "/lms/web/api/v1/groups/{group-id}/staffs/{staff-id}/assignments";
    public static String GET_FLUENCY_FILES_BY_FILEID = "/lms/web/api/v1/assignments/users/{assignmentUserId}/fluency/files";
    public static String PUT_GROUP_UPDATE_API = "/lms/web/api/v1/organizations/organizationId/staffs/groupOwnerId/groups/groupId";
    public static String CREATE_GROUP_API = "/lms/web/api/v1/groups";
    public static String GET_GROUP_DETAILS = "/lms/web/groups/groupId";
    public static String POST_ASSIGNMENTS_UNASSIGNED = "/lms/web/api/v1/organizations/{organisation-id}/staffs/{staff-id}/assignments/unassigned";
    public static String APPLY_SETTINGS_TO_USERS = "applyToUsers";
    public static String PUT_ASSIGNMENT_SETTINGS = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courseassignments/{contentbaseId}/settings";
    public static String PUT_PAUSE_RESUME_STUDENT_ASSIGNMENT = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/assignmentusers/{assignmentuserId}/status";
    public static String GET_ASSIGNMENT_GROUPS = "/lms/web/api/v1/organization/{organizationId}/staffs/{staffId}/assignments/{assignmentId}/unassigned/groups";
    public static String GET_COURSE_GROUPS = "/lms/web/api/v1/organization/{organizationId}/staffs/{staffId}/courses/{courseId}/unassigned/groups";
    public static String CREATE_GROUP_WITH_STUDENT = "/lms/web/api/v1/organizations/organizationId/staffs/teacherId/groups/students";
    public static String GET_STUDENT_DETAILS = "/lms/web/api/v1/students/studentId";
    public static String PUT_ASSIGNMENT_USER_SETTINGS = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/assignmentusers/{assignmentUserId}/settings";
    public static String GET_UNASSIGNED_ASSIGNMENT_STUDENTLIST = "/lms/web/api/v1/organization/{organizationId}/staffs/{staffId}/assignments/assignmentId/unassigned";
    public static String GET_UNASSIGNED_COURSE_STUDENTLIST = "/lms/web/api/v1/organization/{organizationId}/staffs/{staffId}/courses/{courseId}/unassigned";
    public static String DELETE_STUDENTS_FROM_ASSIGNMENT = "/lms/web/api/v1/assignmentusers/{assignmentUserId}";
    public static String GET_GROUP_STUDENT_NOT_PARTOF = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/enroll/groups";
    public static String POST_STUDENTS_TO_MULTIPLE_ASSIGNMENTS = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/assign";
    public static String DELETE_ASSIGNMENT_FROM_GROUP = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/groups/{groupId}/courseassignments/{contentbaseId}";
    public static String POST_STUDENTS_TO_COURSE = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/assign";
    public static String DELETE_ASSIGNMENT = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courseassignments/{contentbaseId}";
    public static String GET_ASSIGNMENT_BY_COURSE = "/lms/web/api/v1/organizations/{organization-id}/staffs/{staff-id}/courseassignments/{contentbaseId}/students";
    public static String GET_GROUP_STUDNETS = "/lms/web/api/v1/groups/groupId/students";
    public static String GET_ASSIGNMENTS_BY_TEACHER = "/lms/web/api/v1/organizations/{organization-id}/staffs/{staff-id}/assignments";
    public static String GET_COURSE_AT_ORGLEVEL_API = "/lms/web/api/v1/organizations/{organizationId}/courses";
    public static String PUT_GROUP_ASSIGNMENT_SETTINGS = "/lms/web/api/v1/organizations/{orgId}/staffs/{staffId}/groups/{groupId}/courseassignments/{contentbaseId}/settings";
    public static String GET_SETTINGS_FOR_GROUPS = "/lms/web/api/v1/organizations/{orgId}/staffs/{staffId}/groups/{groupId}/courseassignments/{contentbaseId}/settings";
    public static String ENROLLMENT_OPTIONS = "enrollmentOptions";
    public static String ENROLLMENT_OPTION_ID = "enrollmentOptionId";
    public static String CURRENT_VALUE = "currentValue";
    public static String UPDATED_VALUE = "value";
    public static String RESPONSE_DATA = "data";
    public static String POST_ASSIGNMENTS_STUDENTS_GROUPS = "/lms/web/api/v1/organizations/{organisation-id}/staffs/{staff-id}/assignments/assigned";
    public static String GET_SETTINGS_FOR_ASSIGNMENT = "/lms/web/api/v1/assignments/{assignmentId}/settings";
    public static String MESSAGES = "messages";
    public static String MESSAGE = "message";
    public static String GET_USAGE_GOAL = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/usagegoals";
    public static String POST_USAGE_GOAL_STUDENTLIST = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/usageGoalsStudentList";

    public static String NO_RESULT_QUERY = "No results were returned by the query.";
    public static String DELETE = "Delete";
    public static String CANCEL = "Cancel";
    public static String FLUENCY_FILE_DOWNLOAD_NAME = "fluencyFileAudio.zip";
    public static String ZERO_STATE_FLUENCY = "NO FILES";
    public static String TOAST_MESSAGE = "File(s) deleted successfully.";

    public static String GROUP_USAGE_REPORT = "/lms/web/api/v1/organization/organizationId/staffs/staffId/usageReport";
    /**
     * Response parameters.
     */
    public static String REPORT_BODY = "body";
    public static String REPORT_MESSAGES = "messages";
    public static String REPORT_TIMESTAMP = "timestamp";
    public static String REPORT_BODY_DATA = "data";
    public static String REPORT_FILTER_KEY_NAME = "name";
    public static String REPORT_STATUS_CODE = "statusCode";
    public static String REPORT_FILTER_ID = "filterId";
    public static String REPORT_NAME = "name";
    public static String REPORT_FILTERS = "reportfilters";
    public static String REPORT_MESSAGE_VALUE = "message";
    public static String REPORT_COURSEID = "id";
    public static String REPORT_DATECREATED = "dateCreated";
    public static String REPORT_DATEUPDATED = "dateUpdated";

    /**
     * Report Filter Options URL parameters.
     */
    public static String STAFF_ID = "{staffId}";
    public static String ORG_ID = "{organizationId}";
    public static String NEW_ORG_ID = "{new_organizationId}";
    public static String REPORT_ID = "{reportId}";
    public static String REPORT_URL_FILTER_ID = "{filterid}";
    public static String REPORT_URL_WEB = "web";
    public static String USER = "user";
    public static String GRADE = "grade";
    public static String GRADE_NAME = "gradeName";
    public static String UPDATE_USER_PROFILE_API = "/lms/web/api/v1/staffs/{staff_ID}";
    public static String STUDENT_ID = "studentId";
    public static String STATUS_CODE_404 = "404";
    public static String VALID_RESPONSE_200 = "200";
    public static String RESPONSE_CODE_400 = "400";
    public static String ASSIGNMENT_ID = "assignmentId";
    public static String COURSE_ID = "{courseId}";
    public static String ASSIGNMENT_USER_ID = "assignmentUserId";
    public static String ASSIGNMENT_OWNER_ID = "assignment_owner_Id";
    public static String SUBJECT_ID = "{subjectId}";
    public static String SUBJECT_TYPE_ID = "subjectTypeId";
    public static String PAYLOAD_ASSIGNMENT_USER_IDS = "\"{assignmentUserIDs}\"";
    public static String PAYLOAD_SUBJECT_TYPE_ID = "\"{subjectTypeId}\"";
    public static String HOLIDAY_DATA = "holidayData";
    public static String SUB_ROLL_TYPE = "{subRoleType}";
    /**
     * Create user database values.
     */
    public static int TEACHER_PERSON_TYPE_ID = 7;
    public static String RUMBA_ID = "";
    public static int DEFAULT_SCHOOL_ID = 1;
    public static int MALE_GENDER_ID = 1;
    public static String GENERAL_DOB = "1999-01-20";
    public static String PASSWORD_HASH = "$2a$05$ynlRZ83KG1Er0HvXvUOIU.hxgt8ZPgLvkN6mpH9hAAZnJQhDPm3EO";
    public static String TEACHER_FIRSTNAME = "TeacherFN";
    public static String TEACHER_LASTNAME = "TeacherLN";
    public static String TEACHER_USERNAME = "TeacherUN";
    public static String STUDENT_USERNAME = "studentUserName";
    /**
     * input values
     */
    public static String SCHOOL_ID_VALUE = "{school_idValue}";
    public static String USERNAME_VALUE = "{userNameValue}";
    public static String PASSWORD_VALUE = "{passwordValue}";
    public static String TEACHER_ID_VALUE = "{teacherIdValue}";
    public static String USERID_VALUE = "{userIdValue}";
    public static String GRADE_VALUE = "{gradeValue}";

    public static String GROUP_ID_VALUE = "{groupIDValue}";
    public static String GROUP_NAME_VALUE = "{groupNameValue}";
    public static String DESC_VALUE = "{descValue}";

    /**
     * Response body values
     */
    public static String PERSONID_VALUE = "{personIdValue}";
    public static String GUID_VALUE = "{guid_value}";
    public static String SCHOOLID_VALUE = "{schoolIdValue}";
    public static String TEACHERID_VALUE = "{teacher_idValue}";
    public static String USER_ID_VALUE = "{userID}";
    public static String USER_NAME_VALUE = "{userName_value}";
    public static String REPORTURI = "REPORTURI";
    public static String REPORTID = "REPORTID";
    public static String FILTERID = "FILTERID";
    public static String FILTERNAME = "FILTERNAME";
    public static String REPORTFILTER = "REPORTFILTER";
    public static String NA = "NA";
    public static String REPORT_FILTER_NAME = "Reportfilter_";
    public static String FIRST_NAME_VALUE = "{firstName_value}";
    public static String MIDDLE_NAME_VALUE = "{middleName_value}";
    public static String LAST_NAME_VALUE = "{lastName_value}";
    public static String OLD_PASSWORD_VALUE = "{oldPassword_value}";
    public static String NEW_PASSWORD_VALUE = "{newPassword_value}";
    public static String REQUESTURL_VALUE = "{requestedUri_Value}";
    public static String STUDENTS_COUNT = "studentCount";
    public static String REQUEST_URI = "requestedUri";
    public static String STUDENT_IDS_VALUE = "{studentIds_value}";
    public static String ASSIGNMENT_ID_VALUE = "{assignmentIdValue}";
    public static String ASSIGNMENT_USER_ID_VALUE = "{assignmentUserIDValue}";
    public static String SUBJECT_TYPE_ID_VALUE = "{subjectTypeIdValue}";

    /**
     * Person API parameters.
     */
    public static String PERSONID = "personId";
    public static String GUID = "guid";
    public static String SCHOOL_ID = "schoolId";
    public static String TEACHER_ID = "teacherId";
    public static String USER_NAME = "userName";
    public static String USER_ID = "studentIdentificationNumber";
    public static String BIRTHDAY = "birthday";
    public static String FIRSTNAME = "firstName";
    public static String MIDDLENAME = "middleName";
    public static String LASTNAME = "lastName";
    public static String USERID = "userId";
    public static String GROUP_ID = "groupId";
    public static String GROUP_OWNER_ID = "groupOwnerId";
    public static String GROUP_NAME = "groupName";
    public static String GROUP_ORG_ID = "groupOwnerOrgId";
    public static String GROUP_DESC = "description";
    public static String ORGANIZATION_ID = "organizationId";
    public static String GROUP_OWNER_FN = "ownerFirstName";
    public static String GROUP_OWNER_LN = "ownerLastName";
    public static String GROUP_OWNER_MN = "ownerMiddleName";
    public static String GROUP_TYPE_ID = "groupTypeId";
    public static String Group_Ids = "groupIds";
    public static String Student_IDs = "studentIds";
    public static String ID = "id";
    public static String SESSION_ID = "sessionID";

    /**
     * Course Hierarchy Parameters.
     */
    public static String CONTENT_BASE_ID = "contentbaseid";
    public static String CTTYPE_ID = "cttypeId";
    public static String LEVEL = "level";
    public static String INCLUDE_LOS = "includeLos";
    public static String BANK_ID = "bankId";
    public static String ASSIGNED_COURSES = "assignedCourses";
    public static String COURSE_NAME = "courseName";

    /**
     * Group Creation API Parameters
     */
    public static String GROUPID_VALUE = "{groupId_value}";
    public static String GROUPNAME_VALUE = "{groupName_value}";
    public static String GROUPDESCRIPTION_VALUE = "{description_value}";
    public static String GROUPID = "{groupId}";
    public static String CONTENTBASE_ID = "{contentBaseId}";
    public static String GROUP_ID_DATAVALUE = "data,groupId";
    public static String ADMIN_ID_VALUE = "admin_id";

    /**
     * Course Creation API Parameters
     */
    public static String COURSEID_VALUE = "{courseId_value}";
    public static String COURSENAME_VALUE = "{courseName_value}";
    public static String DATECREATED_VALUE = "{dateCreated_value}";
    public static String DATEUPDATED_VALUE = "{dateUpdated_value}";

    /**
     * Home Page Mastery Related API Parameters
     */
    String SUBJECT_ID_VALUE = "{subjectId_value}";
    String LIMIT_ID_VALUE = "{limitId_value}";

    /**
     * Get Assignment setting Parameters.
     */
    public static String ASSIGN = "assign";
    public static String COURSETYPE_ID = "courseTypeId";
    public static String groupAssignmentZeroPage = "There are no assignments in this group";

    /**
     * Endpoints related to Mastery
     */
    public interface Mastery {
        public static String GET_MASTERY_STANDARDS = "/lms/web/api/v1/subjects/{subjectId}/standards";
        public static String POST_MASTERY_LISTINGS = "/lms/web/api/v1/mastery/organizations/{organizationId}/staffs/{staffId}/summary";
        public static String POST_MASTERY_DETAILS = "/lms/web/api/v1/mastery/organizations/{organisationId}/staffs/{staffId}/detail";
    }

    /**
     * Constants related to Mastery page
     *
     * @author magesh.nagamani
     *
     */
    public interface MasteryUI {

        public static String MASTERED = "Mastered";
        public static String NOT_MASTERED = "Not Mastered";
        public static String AT_RISK = "At Risk";
        public static String UNASSESSED = "Unassessed";
        public static String STUDENTS = "students";
        public static String GROUPS = "groups";
        public static String ASSIGNMENTS = "assignments";
        public static String SUBJECT_MATH = "Math";
        public static String SUBJECT_READING = "Reading";
        public static String SKILL_MATH = "SuccessMaker Mastery Skills - Math";
        public static String SKILL_READING = "SuccessMaker Mastery Skills - Reading";
        public static String STANDARD_AIMSWEBPLUS_MATH = "AimswebPlus";
        public static String STANDARD_ALASKAENGLISH_READING = "Alaska English/Language Arts Standards, 2012";
        public static String ALL_GROUPS_COUNT = Integer.toString( DataSetupConstants.GROUP_COUNT );
        public static String ALL_GROUPS_MESSAGE = "All Groups (" + ALL_GROUPS_COUNT + ")";
        public static String ALL_STUDENTS_COUNT = Integer.toString( DataSetupConstants.STUDENT_COUNT );
        public static String ALL_STUDENTS_MESSAGE = "All Students (" + ALL_STUDENTS_COUNT + ")";
        public static String ALL_ASSIGNMENTS_COUNT = "3";
        public static String ALL_ASSIGNMENTS_MESSAGE = "All Assignments (" + ALL_ASSIGNMENTS_COUNT + ")";
        public static String NO_RESULTS_HEADER = "NO RESULTS FOUND";
        public static String NO_RESULTS_MSG = "No matches for your search criteria. Please filter again";
        public static String LO_COLOR_CODE = "#007ee";
        public static List<String> MASTERY_ZERO_STATE_MESSAGE = new ArrayList<>( Arrays.asList( "NO DATA YET", "Mastery results will be displayed here once students start taking the given assignment." ) );
        public static List<String> ASSESSED_OBJECTIVES_HEADERS = new ArrayList<>( Arrays.asList( "Assessed Objectives", "Mastered", "At Risk", "Not Mastered", "Unassessed" ) );
        public static String STUDENT_ASSESSMENT_COUNT = "studentCount Student Assessment";
        public static String LO_ID_COLOR_CODE = "#007bff";
        public static String MASTERY_STATUS_FIELD = "Mastery Status";
        public static String STUDENT_FIELD = "Student";
        public static String SKILLS_EVALUATED_FIELD = "Skills Evaluated";
        public static String ATTEMPTS_FIELD = "Attempts";
        public static String MASTERED_COLOR_CODE = "#008A00";
        public static String ATRISK_COLOR_CODE = "#FFBA4A";
        public static String NOTMASTERED_COLOR_CODE = "#CC333F";
        public static String UNASSESSED_COLOR_CODE = "#CDCFD1";
        public static List<String> masteryTableHeaders = new ArrayList<>( Arrays.asList( "Student", "Mastery Status", "Skills Evaluated", "Attempts" ) );
        public static String STUDENT_ASSESSMENTS_COUNT = "studentCount Student Assessments";

        public static String NOTMASTERED_RGB_CODE_CHROME = "rgba(204, 51, 63, 1)";
        public static String MASTERED_RGB_CODE_CHROME = "rgba(0, 138, 0, 1)";
        public static String ATRISK_RGB_CODE_CHROME = "rgba(255, 186, 74, 1)";
        public static String NOTMASTERED_RGB_CODE_SAFARI = "rgb(204, 51, 63)";
        public static String MASTERED_RGB_CODE_SAFARI = "rgb(0, 138, 0)";
        public static String ATRISK_RGB_CODE_SAFARI = "rgb(255, 186, 74)";

    }

    /**
     * Endpoints related to Groups
     */
    public interface Groups {
        public static String PUT_PAUSERESUMEGROUPASSIGNMENTS = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/groups/{groupId}/courseassignments/{contentBaseId}/status";

        // The end point is same for removing students from groups
        public static String Create_Group_withStudents = "/lms/web/api/v1/organizations/{organisationId}/staffs/{staffId}/groups/students";

        // End point for deleting group
        public static String SIMPLE_GROUP_NAME = "UI_Automation_" + System.nanoTime();
        public static String ABOVE_75_CHAR_GROUP_NAME = "Test automation group name with 75 characters only used for successmaker.....";
        public static String BELOW_3_CHAR_GROUP_NAME = "AB";
        public static String EXACT_75_CHAR_GROUP_NAME = "Test automation group name with 75 characters only used for successmaker..";
        public static String SPECIAL_CHAR_GROUP_NAME = "#$%^&*()";
        public static String WHITE_SPACE_GROUP_NAME = " ";
        public static String EXACT_3_CHAR_GROUP_NAME = "ABC";
        public static String NULL_GROUP_NAME = "";
        public static String GROUP_NAME_INBETWEEN_SPACE = "SUCCESSMAKER GROUP";
        public static String APHOSTROPHY_CHAR_GROUP_NAME = "SUCCESSMAKER's GROUP";
        public static String NUMERIC_GROUP_NAME = "12345689 GROUP";

        public static String MIN_MAX_ERROR_MESSAGE = "Group name must be between 3 and 75 characters";
        public static String NULL_GROUP_NAME_ERROR_MESSAGE = "Please enter a group name.";
        public static String DUPLICATE_GROUP_NAME_MESSAGE = "Group name taken. Please enter a unique group name.";

        public static String createGroupWindowTitle = "Create a New Group";

        public static String NO_DATA_YET = "NO DATA YET";
        public static String ZERO_STATE_MESSAGE = "You haven't created any groups yet.";

        public static String CREATE_NEW_GROUP = "Create New Group";
        public static String ZEROSTATE_HEADER = "NO DATA YET";
        public static String ZEROSTATE_MESSAGE = "There are no students in this group";
        public static String ZEROSTATE_LINK = "Add Students To Group";
        public static String ZEROSTATE_ASSIGNMENT_MSG = "There are no assignments in this group";
        public static String GROUP_ALLGRADES = "All Grades";
        public static String CREATE_GROUP_HELP_TITLE = "Create a New Group";
        public static String ADD_STUDENT_TO_GROUP_HELP_TITLE = "Add Students to a Group";
        public static String Delete_Group = " /lms/web/api/v1/groups/{groupId}";
        public static String USERS = "Users";
        public static String MASTERY = "Mastery";
        public static String ASSIGNMENTS = "Assignments";
        public static String COLUMN_NO_OF_STUDENTS = "# Of Students";
        public static String COLUMN_GROUP_NAME = "Group Name";

        // view group constants
        public static String ADDSTUDENT_TO_GROUP_TITLE = "Add Students to";
        public static String GET_ERROR_MSG_GRDAENOT_SELECTED = "Start typing to search for students in your school. Select a grade in the drop-down menu to narow the list of students by grade.";
        public static String GRADE_5 = "Grade 5";
        public static String GRADE_K = "Grade K";
        public static String GRADE_2 = "Grade 2";
        public static String GRADE_NOT_SPECIFIED = "Not Specified";
        public static String EMPTY_GRP = "Empty_group";
        public static String INVALID_SEARCH_TXT = "No students match your search criteria.";
        public static String PARTIAL_SEARCH_TXT = "S4";
        public static String CREATE_A_GROUP_COLOR = "#0072ee";

    }

    /*
     * Endpoints related to Assignments
     */
    public interface Assignments {
        public static String PUT_PAUSERESUME_ALLSTUDENTSASSIGNMENT = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courseassignments/{contentBaseId}/status";
        /** Column Name in Assignments Page **/
        public static String COLUMN_ASSIGNMENT_TITILE = "Assignment Title";
        public static String COLUMN_DATE_ASSIGNED = "Date Assigned";
        public static String COLUMN_ACTIVE_STUDENTS = "Active Students";
        public static String COLUMN_PAUSED_STUDENTS = "Paused Students";
        public static String COLUMN_FLUENCY_FILES = "Fluency Files";
        public static String ASSIGNMENT_PAGE_URL = "/lms/dashboard.view#/assignments";
        public static String ZERO_MESSAGE = "No assignments have been created yet.";
        public static String TEACHER_UNAME = "TeacherN";
        public static String VALUE_ZERO = "0";
        public static String VALUE_FULL = "100%";

    }

    /**
     * Course Listing Page
     */
    public static String CUSTOM_BY_SETTINGS_COURSE = "Custom by Settings course";
    public static String CUSTOM_BY_SKILLS_COURSE = "Custom by Skills course";
    public static String CUSTOM_BY_STANDARDS_COURSE = "Custom by Standards course";
    public static String COURSELEVEL_1_75 = "1.75";
    public static String COURSELEVEL_8_75 = "8.75";
    public static String COMPLETED_COLOR = "#008a00";
    public static String PAUSED_COLOR = "#6f777b";
    static String COMPLETED_ASSIGNMEMT_TAG_COLOR = "#28A745";
    public static String SKILLS = "Skills";
    public static String SETTINGS = "Settings";
    public static String STANDARDS = "Standards";
    public static String ON = "On";
    public static String OFF = "Off";
    public static String ON_CAPS = "ON";
    public static String OFF_CAPS = "OFF";
    public static List<String> COURSE_TYPES = new ArrayList<>( Arrays.asList( "Focus Courses", "Default Courses", "Custom Courses", "All Courses" ) );
    public static List<String> SORT_BY = new ArrayList<>( Arrays.asList( "Course Title (Ascending)", "Course Title (Descending)", "Course Date (Ascending)", "Course Date (Descending)" ) );
    public static List<String> STUDENT_LEVEL_ASSIGNMENT_ELLIPSIS_OPTION = new ArrayList<>( Arrays.asList( "Fluency Files (0)", "Assignment Settings", "Pause Assignment For Student", "Remove Student" ) );
    public static String CHECK_ASCENDING_ORDER = "Course Title (Ascending)";
    public static String CHECK_DESCENDING_ORDER = "Course Title (Descending)";
    public static String CHECK_DATE_ASCENDING_ORDER = "Course Date (Ascending)";
    public static String CHECK_DATE_DESCENDING_ORDER = "Course Date (Descending)";
    public boolean SORTING_ORDER_VALID = true;
    public boolean SORTING_ORDER_INVALID = false;
    public static String READING = "Reading";
    public static String MATH = "Math";
    public static String DEFAULT_COURSES = "Default Courses";
    public static String ALL_COURSES = "All Courses";
    public static String FOCUS_COURSES = "Focus Courses";
    public static String CUSTOM_COURSES = "Custom Courses";
    public static String SM_FOCUS_MATH_GRADE_I = "SM Focus Math: Grade 1";
    public static String SM_FOCUS_READING_GRADE_I = "SM Focus Reading: Grade 1";
    String GRADE_NUMBER_3 = "3";
    int TEACHER_INDEX = 5;

    String SM_FOCUS_MATH_GRADE1 = "SM Focus Math: Grade 1";
    String SM_FOCUS_MATH_GRADE2 = "SM Focus Math: Grade 2";
    String SM_FOCUS_MATH_GRADE3 = "SM Focus Math: Grade 3";
    String SM_FOCUS_MATH_GRADE4 = "SM Focus Math: Grade 4";
    String SM_FOCUS_MATH_GRADE5 = "SM Focus Math: Grade 5";
    String SM_FOCUS_MATH_GRADE6 = "SM Focus Math: Grade 6";
    String SM_FOCUS_MATH_GRADE7 = "SM Focus Math: Grade 7";
    String SM_FOCUS_MATH_GRADE8 = "SM Focus Math: Grade 8";
    String SM_FOCUS_READING_GRADE1 = "SM Focus Reading: Grade 1";
    String SM_FOCUS_READING_GRADE2 = "SM Focus Reading: Grade 2";
    String SM_FOCUS_READING_GRADE3 = "SM Focus Reading: Grade 3";
    String SM_FOCUS_READING_GRADE4 = "SM Focus Reading: Grade 4";
    String SM_FOCUS_READING_GRADE5 = "SM Focus Reading: Grade 5";
    String SM_FOCUS_READING_GRADE6 = "SM Focus Reading: Grade 6";
    String SM_FOCUS_READING_GRADE7 = "SM Focus Reading: Grade 7";
    String SM_FOCUS_READING_GRADE8 = "SM Focus Reading: Grade 8";
    public static String FULL_COURSE = "Full Course";
    public static String FOCUS_COURSE = "Focus Course";
    public static String MAX_LENGTH_COURSE_NAME = "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvw";
    public static String COURSE_NAME_WITH_ELLIPSE = "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrs...";
    public static String GROUP_HELP_PAGE_TEXT = "Group Details - Users";
    public static String SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT = "All the students have been assigned the assignment";
    public static String FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT = "All the students have not been assigned the assignment";
    public static String SUCCESS_MESSAGE_FOR_DISPLAY_LO_INFORMATION_TURNED_ON = "Newly added courses are displayed with LO information as ON.";
    public static String SUCCESS_MESSAGE_FOR_DISPLAY_LO_INFORMATION_TURNED_OFF = "Newly added courses are displayed with LO information as OFF.";
    public static String SUCCESS_MESSAGE_FOR_TEACHER_NAME_IS_PRESENT = "Teacher name is present";
    public static String SUCCESS_MESSAGE_FOR_TEACHER_NAME_IS_ABSENT = "Teacher name is absent";
    public static String HTML_BEGINING_TAG_FOR_REPORT = "<small><b><i>[";
    public static String HTML_ENDING_TAG_FOR_REPORT = "]</b></i></small>";
    public int FOCUS_COURSE_SIZE = 16;
    public int FOCUS_AND_DEFAULT_COURSE_SIZE = 18;
    public int DEFAULT_COURSE_SIZE = 2;
    public static String MISS = "Miss";
    public static String SELECT_TITLE = "Select Title";
    public static String UNABLE_TO_TURN_OFF_LO_INFORMATION = "Unable to turn OFF the LO Information";
    public static String SHARE_AT_DISTRICT_LABEL = "SHARE AT DISTRICT LEVEL?";
    public static String DISPLAY_LO_INFORMATION = "DISPLAY LO INFORMATION";
    public static String FLUENCY = "FLUENCY";
    public static String STUDENT_FULL_NAME = "smsautos1t1S20 smsautos1t1S20";
    List<String> SUBJECT_DROPDOWN_LIST = new ArrayList<>( Arrays.asList( "Math", "Reading" ) );
    List<String> MATH_SKILLS_DROPDOWN_LIST = new ArrayList<>(
            Arrays.asList( "SuccessMaker Mastery Skills - Math", "AimswebPlus", "Alabama Course Of Study: Mathematics, 2019", "Alaska Mathematics Standards, 2012", "Arizona Mathematics Academic Standards: 2017", "Arkansas Mathematics Standards, 2016",
                    "California Common Core State Standards: Mathematics, 2010", "Colorado Academic Standards: Mathematics, 2020", "Common Core State Standards: Mathematics, 2010", "EnVisionMATH California", "EnVision Math 2.0 6-8",
                    "EnVision Math 2.0 K-6", "EnVisionMATH Texas 2.0", "EnVision 2020 Mathematics K-5 And EnVision 2021 Mathematics 6-8", "EnVision Florida Mathematics", "Florida B.E.S.T. Standards Mathematics, 2020", "Mathematics Florida Standards, 2014",
                    "SM Focus Math", "Georgia Standards Of Excellence: Mathematics: 2016", "Indiana Academic Standards Mathematics, 2014", "Investigations 3", "Louisiana Student Standards For Mathematics, 2016", "MAP Growth (Math)",
                    "Maryland College And Career-Ready Standards For Mathematics, 2015", "Minnesota K-12 Academic Standards In Mathematics: 2007", "Mississippi College- And Career-Readiness Standards For Mathematics, 2016",
                    "Nebraska'S College And Career Ready Standards For Mathematics, 2015", "Nevada Academic Content Standards In Mathematics", "New Jersey Student Learning Standards For Mathematics 2016",
                    "New York State Learning Standards For Mathematics, PK-12, 2017", "North Carolina Standard Course Of Study, K-8 Mathematics, 2017", "Ohio Learning Standards: Mathematics: 2017", "Oklahoma Academic Standards For Mathematics, 2021",
                    "Pennsylvania Academic Standards For Mathematics, 2014", "South Carolina: College- And Career-Ready Standards For Mathematics: K-12: 2015: PCSA01", "Tennessee Academic Standards For Mathematics, K-12: 2016",
                    "Texas Essential Knowledge And Skills For Mathematics, 2012", "Utah Core State Standards For Mathematics, 2016", "Virginia Mathematics Standards Of Learning, 2016", "SuccessMaker Math Performance Tasks" ) );
    List<String> READING_SKILLS_DROPDOWN_LIST = new ArrayList<>( Arrays.asList( "SuccessMaker Mastery Skills - Reading", "AimswebPlus CCSS Language Arts Grade-Domain", "Alabama Course Of Study English Language Arts, 2021",
            "Alaska English/Language Arts Standards, 2012", "Arizona English Language Arts Standards, 2016", "Arkansas English Language Arts Standards, 2016", "California Common Core State Standards, English Language Arts & Literacy, 2010",
            "Colorado Academic Standards In Reading, Writing, And Communicating, 2020", "Common Core State Standards: English Language Arts, 2010", "Florida B.E.S.T. Standards: English Language Arts, 2020", "Language Arts Florida Standards, 2014",
            "SM Focus Reading", "Georgia Standards Of Excellence: English Language Arts, 2015", "Idaho Content Standards For English Language Arts/Literacy, 2015", "Indiana Academic Standards English Language Arts, 2020",
            "Louisiana Student Standards For English Language Arts, 2016", "MAP Growth (Reading)", "Massachusetts English Language Arts And Literacy Curriculum Framework, 2017",
            "Mississippi College- And CareerReadiness Standards For English Language Arts, 2016", "Missouri English Language Arts Learning Standards, 2016", "MyPerspectives © 2017 SE", "MyView Literacy 2020", "Texas MyView Literacy 2020",
            "Nebraska College- And Career-Ready English Language Arts Standards, 2014", "New Jersey Student Learning Standards For English Language Arts, 2016", "New York State Next Generation English Language Arts Learning Standards, 2017",
            "North Carolina Standard Course Of Study For English Language Arts, K-12: 2017", "Ohio Learning Standards: English Language Arts: 2017", "Oklahoma Academic Standards: English Language Arts, 2021",
            "Pennsylvania Academic Standards For English Language Arts, 2014", "ReadyGen", "South Carolina College- And Career-Ready Standards For English Language Arts, 2015", "Tennessee Academic Standards: English Language Arts, 2016",
            "Texas Essential Knowledge And Skills For English Language Arts And Reading, 2017", "Utah Core Standards For English Language Arts, 2013", "English Standards Of Learning For Virginia, 2017",
            "Wisconsin Standards For English Language Arts, 2020" ) );
    List<String> MATH_BANK_ID_LIST = new ArrayList<>(

            Arrays.asList( "1000015009", "1000016494", "1000034001", "1000020535", "1000012962", "1000011064", "1000012570", "1000022538", "1000023001", "1000027170", "1000029823", "1000030309", "1000031135", "1000018056", "1000017053" ) );

    List<String> READING_BANK_ID_LIST = Arrays.asList( "1000029054", "1000036771", "1000020066", "1000013447", "1000018519", "1000015496", "1000030769" );
    List<String> STANDARDS_LIST = new ArrayList<>( Arrays.asList( "Alaska Mathematics Standards, 2012", "Alabama Course of Study: Mathematics, 2019", "Arkansas Mathematics Standards, 2016", "Florida B.E.S.T. Standards Mathematics, 2020",
            "Georgia Standards of Excellence: Mathematics: 2016", "Louisiana Student Standards for Mathematics, 2016", "North Carolina Standard Course of Study, K-8 Mathematics, 2017", "New Jersey Student Learning Standards for Mathematics 2016",
            "Nevada Academic Content Standards in Mathematics", "Ohio Learning Standards: Mathematics: 2017", "South Carolina: College- and Career-Ready Standards for Mathematics: K-12: 2015: PCSA01",
            "Tennessee Academic Standards for Mathematics, K-12: 2016", "Utah Core State Standards for Mathematics, 2016", "Common Core State Standards: Mathematics, 2010", "California Common Core State Standards: Mathematics, 2010",
            "South Carolina College- and Career-Ready Standards for English Language Arts, 2015", "Arizona English Language Arts Standards, 2016", "Florida B.E.S.T. Standards: English Language Arts, 2020",
            "Georgia Standards of Excellence: English Language Arts, 2015", "Common Core State Standards: English Language Arts, 2010", "Alaska English/Language Arts Standards, 2012", "Tennessee Academic Standards: English Language Arts, 2016" ) );
    public static String MAX_IDLE_TIME = "6 Minutes";
    public static String MAX_SHOWLIMIT = "10 per session";
    String NO_ASSIGNMENTS_FOUND = "No Assignments Found";
    String TOP_PERFORMING = "Top Performing";
    String LOW_PERFORMING = "Low Performing";
    String TOP_PERFORMERS = "topPerformers";
    String LOW_PERFORMERS = "lowPerformers";
    String ZERO_STATE_MESSAGE_HOME_PAGE = "No mastery data has been captured yet for this discipline and library.";
    String STUDENT_PERFORMANCE_DETAILS_BODY = "{\"subjectId\":{subjectId_value},\"limit\":{limitId_value}}";
    String NEGATIVE_ONE = "-1";
    String FALSE = "false";
    String DATA = "data";
    List<String> SLIDER_VALUES = new ArrayList<>( Arrays.asList( "2.2", "2.2" ) );
    String SLIDER_MAX_VALUE = "8.95";
    String SLIDER_MIN_VALUE = "0";
    Integer DRAG_VALUES_FIRST = -60;
    Integer DRAG_VALUES_SECOND = -20;
    String MATH_SUBJECT_ID_VALUE = "1";
    String READING_SUBJECT_ID_VALUE = "2";
    String MASTERY_FILTER_LIMIT_ID_VALUE = "3";
    String MARGIN_LEFT = "margin-left";
    String ELLIPSIS_MARGIN_LEFT_VALUE = "0px";
    String PADDING_TOP = "padding-top";
    String PADDING_BOTTOM = "padding-bottom";
    String NAME_TOP_SPACING_VALUE = "12px";
    String COURSES_LAST_ASSIGNED_TOP_SPACING_VALUE = "24px";
    String NAME_COURSES_BOTTOM_SPACING_VALUE = "8px";
    String VIEW_ASSIGNED_BY_TABLE_HEADER_BG_COLOR = "background-color";
    String GRAY_HEX_VALUE = "#f9f9f9";
    String CENTER = "center";

    public static String MY_CUSTOM_BY_SETTINGS_COURSE = "ZzMy Custom by Settings course";

    String FONT_FAMILY = "font-family";
    String POPPINS_SEMI_BOLD = "Poppins-SemiBold";
    String TEXT_ALIGN = "text-align";
    String LEFT = "left";
    String HEIGHT = "height";
    String WIDTH = "width";
    String DISPLAY = "display";
    String GREY_COLOR = "rgba(128, 128, 128, 1)";
    String GREY_COLOR_MAC = "rgb(128, 128, 128)";
    String LIGHT_GREY_COLOR = "rgba(230, 230, 230,1)";
    String LIGHT_GREY_COLOR_MAC = "rgb(230, 230, 230)";

    String TEXT_ANCHOR = "text-anchor";
    String MIDDLE = "middle";
    String PADDING_LEFT = "padding-left";
    String PADDING_RIGHT = "padding-right";
    String VIEW_GRAPH_LEFT_PADDING = "24px";
    String PROGRESS_MARGIN_LEFT = "25px";
    String PROGRESS_MARGIN_LEFT_SAFARI = "24px";
    String TRANSFORM_ORIGIN = "transform-origin";
    String TRANSFORM_ORIGIN_VALUE = "0px 0px";
    String SHOW_TARGET_TOGGLE_PADDING_LEFT = "6px";

    /**
     * Parameters related to Assignment Page
     */
    public String SESSION_LENGHT_SELECTED = "20 minutes";
    public String IDEAL_TIME_SELECTED = "6 minutes";
    public String CUSTOM_ASSIGMENT_TITLE = "T7_MathCustomSkills";
    String CUSTOM_BY_SETTINGS_MATH_COURSE = "Custom by Settings Math course";
    String CUSTOM_BY_SETTING_IP_ON_MATH_COURSE = "Custom by Settings IP ON Math course";
    String CUSTOM_BY_SKILLS_MATH_COURSE = "Custom by Skills Math course";
    String CUSTOM_BY_STANDARDS_MATH_COURSE = "Custom by Standards Math course";
    String SHARED_COURSE_MATH = "Shared Course Math";
    String DELETED_ASSIGNMENT_MATH = "Deleted Assignment Math";
    String RESTORED_ASSIGNMENT_MATH = "Restored Assignment Math";
    String CUSTOM_BY_SETTINGS_READING_COURSE = "Custom by Settings Reading course";
    String CUSTOM_BY_SETTING_IP_ON_READING_COURSE = "Custom by Settings IP ON Reading course";
    String CUSTOM_BY_SKILLS_READING_COURSE = "Custom by Skills Reading course";
    String CUSTOM_BY_STANDARDS_READING_COURSE = "Custom by Standards Reading course";
    String SHARED_COURSE_READING = "Shared Course Reading";
    String DELETED_ASSIGNMENT_READING = "Deleted Assignment Reading";
    String RESTORED_ASSIGNMENT_READING = "Restored Assignment Reading";
    public String ACTIVE_STUDENTS_ASSIGMENT_SUBTITILE = "Active Students";
    public String PAUSED_STUDENTS_ASSIGMENT_SUBTITILE = "Paused Students";
    String STATUS_SUBTITLE = "1 Active Student | 0 Paused Students";
    public String ASSIGMENT_SETTINGS = "Assignment Settings";
    String IP_LEVEL = "IP Level";
    public String PAUSED_ALL_STUDENTS = "Pause All Students";
    public String DELETED_ASSIGNMENT = "Delete Assignment";
    String GAIN = "Gain";
    public String NAME = "Name";
    public String LAST_SESSION = "Last Session";
    String NOT_STARTED_VALUE = "--";
    String NOT_APPLICABLE_VALUE = "NA";
    public String ASSIGNED_LEVEL = "Assigned Level";
    public String CURRENT_LEVEL = "Current Level";
    public String PERCENT_CORRECT = "% Correct";
    public String ASSIGNED_ON = "Assigned On";
    String FLUENCY_FILES_FOR_STUDENT = "Fluency Files (0)";
    public String PAUSE_ASSIGNMENT_FOR_STUDENTS = "Pause Assignment For Student";
    public String REMOVE_STUDENTS = "Remove Student";
    public String ASSIGNMENT_TITLE = "Assignment Title";
    public String DATE_ASSIGNED = "Date Assigned";
    public String ACTIVE_STUDENTS = "Active Students";
    public String PAUSED_STUDENTS = "Paused Students";
    public String FLUENCY_FILES = "Fluency Files";
    public String PAUSED_STUDENT = "Paused";
    public String RANDOM_STRING_CHAR = "Zz";
    public String ASSIGNED_BY_POPOUP_TITLE = "Assigned By";
    String DECIMAL_FORMAT = "^\\d+\\.\\d+";
    String DATE_FORMAT = "\\d{1,2}/\\d{1,2}/\\d{4}";
    String TIME_FORMAT = "^\\d+\\:\\d+";
    public String ASSIGNMENT_TITLE_DB = "assignment_title";
    public String CONTENT_BASE_ID_DB = "contenty_base_id";
    public String PRODUCT_ID_DB = "product_id";

    String GAIN_VALUE_FORMAT = "#0.00";
    String PERCENTAGE_VALUE_FORMAT = "^\\d\\d%$";
    public String STUDENTS = "Students";
    public static String USERS = "Users";
    public static String MASTERY = "Mastery";
    public static String ASSIGNMENTS = "Assignments";
    Boolean STATUSTRUE = true;
    String ONESTUDENTASSIGNED = "1 Student Assigned";
    String THREESTUDENTSASSIGNED = "3 Students Assigned";
    int MAXASSIGNMENTCOUNT = 4;
    String SEARCH_MESSAGE_RESULTS = "No results found";

    String CUSTOM_SETTINGS_MATH_ASSIGMENT_TITLE = "Custom-Setting-Math-IP-Off";
    String CUSTOM_MATH_ASSIGMENT_TITLE = "Math_Custom By Settings"; // Newly added for the custom custom course title
    String CUSTOM_READING_ASSIGMENT_TITLE = "Reading_Custom By Settings"; // Newly added for the custom custom course title
    String DELETE_ASSIGMENT_POPUP_TITLE = "Delete Assignment"; // Newly added for the delete assignment popup title
    // Newly added for Assignment Listing 
    String ASSIGNMENT_LISTING_TITLE = "Assignments";
    String EDIT_SETTINGS_POPUP_TITLE = "Edit Assignment Settings";
    String SKILLS_TESTED_TAB_TITLE = "Skills Tested";
    String READING_FOCUS_COURSE_TITLE = "SM Focus Reading: Grade 2";
    String PRIMARY_TARGET = "Primary Target";
    String SECONDARY_TARGET = "Secondary Target";
    String MATH_FOCUS_COURSE_TITLE = "SM Focus Math: Grade 1";
    List<String> ASSIGNMENT_DETAILS = new ArrayList<>( Arrays.asList( "Name", "Last Session", "IP Level", "Assigned Level", "Current Level", "Gain", "% Correct" ) );
    List<String> DELETE_POPUP_TEXT = new ArrayList<>( Arrays.asList( "Heads Up!, This will delete the assignment for 1 Active Student | 0 Paused Students" ) );
    List<String> ASSIGNMENT_SETTINGS = new ArrayList<>( Arrays.asList( "SESSION LENGTH", "IDLE TIME", "SHOW / LIMIT PROGRESS REPORT", "INITIAL PLACEMENT (IP)", "DISPLAY LO INFORMATION", "HELP ICON ACTIVE", "EXIT COURSE BUTTON", "SPANISH GLOSSARY",
            "GRAMMAR STRAND", "READ TO ME", "TRANSLATE", "SHARE AT DISTRICT LEVEL?", "FLUENCY" + ", ," + " MANUALLY SET COURSE LEVEL, " ) );
    List<String> ASSIGNMENT_SETTINGS_SAFARI = new ArrayList<>( Arrays.asList( "SESSION LENGTH", "IDLE TIME", "SHOW / LIMIT PROGRESS REPORT", "INITIAL PLACEMENT (IP)", "DISPLAY LO INFORMATION", "HELP ICON ACTIVE", "EXIT COURSE BUTTON", "SPANISH GLOSSARY",
            "GRAMMAR STRAND", "READ TO ME", "TRANSLATE", "SHARE AT DISTRICT LEVEL?", "FLUENCY", "FLUENCY RECORDING TIME", "MANUALLY SET COURSE LEVEL", "COURSE LEVEL" ) );

    List<String> VIEW_SUMMARY_FORMAT_IP = new ArrayList<>( Arrays.asList( "Primary Target", "Secondary Target", "Days to Target", "Target Date", "IP Level", "Current Level", "Gain" ) );
    List<String> VIEW_SUMMARY_FORMAT_FOCUS = new ArrayList<>( Arrays.asList( "Primary Target", "Secondary Target", "Days to Target", "Target Date" ) );
    List<String> VIEW_SUMMARY_FORMAT_NOTSTART = new ArrayList<>( Arrays.asList( "Primary Target", "Secondary Target", "Days to Target", "Target Date", "Current Level", "Gain", "IP Level", "Last Session Date" ) );
    List<String> VIEW_SUMMARY_FORMAT_FOCUS_NOTSTART = new ArrayList<>( Arrays.asList( "Primary Target", "Secondary Target", "Days to Target", "Target Date", "Assigned Level", "Current Level", "Gain" ) );

    String X_AXIS_VALUE = "Calendar Days";
    String Y_AXIS_VALUE = "Course Level";
    String SEARCH_MESSAGE = "NO RESULTS FOUND";
    String SEARCH_ERROR_MESSAGE = "Please update your search criteria.";
    public static String IPLEVEL = "ipLevel";
    public static String INIP = "In-IP";
    public static String BLANKVALUE = "--";
    public static String NOTAPPLICABLE = "NA";
    public static String ASSIGNMENTNAME = "name";

    public static String SKILL_TESTED_HEADER = "Skills Tested";
    String ASSIGNED_TO = "Assigned To";

    public String MATH_ASSIGMENT_TITLE = "Math";
    public String READING_ASSIGMENT_TITLE = "Reading";
    public int MATH_DROPDOWN_WIDGET_SIZE = 5;
    public int MATH_DROPDOWN_WIDGET_SIZE_TOGGLE = 7;
    public int READ_DROPDOWN_WIDGET_SIZE = 4;
    public int READ_DROPDOWN_WIDGET_SIZE_TOGGLE = 9;
    public static String removeText = "Remove";
    public static String LABEL = "label";
    String REMOVE_STUDENT_POPUP_TEXT = "Are you sure you want to remove this student?";
    String REMOVE_STUDENT_POPUP_HEADSUP_TEXT = "Heads Up!This will remove the student tasked to work on this assignment.";

    String SUMMARY_LABEL_IP = "IP Level";
    String SUMMARY_LABEL_CURRENT = "Current Level";
    String SUMMARY_LABEL_GAIN = "Gain";
    String SUMMARY_LABEL_ASSIGNED = "Assigned Level";
    String SUMMARY_HEADER = "Progress";
    List<String> VIEW_SUMMARY = ( Arrays.asList( "Primary Target", "Secondary Target", "Target Date", "Days to Target", "Assigned Level", "IP Level", "Current Level", "Gain", "Last Session Date", "Total Sessions", "Sessions Since IP", "Total Time Spent",
            "Avg. Session Time" ) );
    List<String> VIEW_SUMMARY_HEADER = ( Arrays.asList( "Performance Targets", "Level Details", "Usage Details" ) );

    //Newly added for Zero state screen for Assignment Listing page
    String ZERO_STATE_SCREEN_MESSAGE = "No assignments have been created yet.";
    String NO_DATA_MESSAGE = "NO DATA YET";
    public String MATH_COURSE_TITLE_DISPLAYED = "Math course Assign widget Title is displayed";
    public String MATH_COURSE_TITLE_NOT_DISPLAYED = "Math course Assign widget Title is not displayed";
    public String READ_COURSE_TITLE_DISPLAYED = "Reading course Assign widget Title is displayed";
    public String READ_COURSE_TITLE_NOT_DISPLAYED = "Reading course Assign widget Title is not displayed";
    public String MATH_COURSE_ASSIGN_DISPLAYED = "Course Assign widget for Math course is displayed";
    public String MATH_COURSE_ASSIGN_NOT_DISPLAYED = "Course Assign widget for Math course is not displayed";
    public String READ_COURSE_ASSIGN_DISPLAYED = "Course Assign widget for Reading course is displayed";
    public String READ_COURSE_ASSIGN_NOT_DISPLAYED = "Course Assign widget for Reading course is not displayed";
    public String GROUP_RADIO_ENABLED = "Groups radio button is enabled";
    public String GROUP_RADIO_DISABLED = "Groups radio button is disabled";
    public String GROUP_ADDED = "Groups are added to the course";
    public String GROUP_NOT_ADDED = "Groups are not added to the course";
    public String STUDENTS_ADDED = "Students are added to the course";
    public String STUDENTS_NOT_ADDED = "Students are not added to the course";
    public String GROUP_REMOVED = "Group is removed";
    public String GROUP_NOT_REMOVED = "Group is not removed";
    public String STUDENTS_REMOVED = "Student is removed";
    public String STUDENTS_NOT_REMOVED = "Student is not removed";
    public String REMOVE_DISPLAYED = "Remove button is displayed";
    public String REMOVE_NOT_DISPLAYED = "Remove button is not displayed";
    public String PREVIOUSLY_ADDED_STUDENT_NOT_DISPLAYED = "Previously added student is not displayed";
    public String PREVIOUSLY_ADDED_STUDENT_DISPLAYED = "Previously added student is displayed";
    public String PREVIOUSLY_ADDED_GROUP_NOT_DISPLAYED = "Previously added group is not displayed";
    public String PREVIOUSLY_ADDED_GROUP_DISPLAYED = "Previously added group is displayed";
    public String USER_ON_ASSIGN = "User is on the Assign popup";
    public String USER_NOT_ON_ASSIGN = "User is not on the Assign popup";
    public String MATH_SETTINGS_DISPLAYED = "Settings for Math course are displayed as expected";
    public String MATH_SETTINGS_NOT_DISPLAYED = "Settings for Math course are not displayed as expected";
    public String READ_SETTINGS_DISPLAYED = "Settings for Reading course are displayed as expected";
    public String READ_SETTINGS_NOT_DISPLAYED = "Settings for Reading course are not displayed as expected";
    public String MATH_ASSIGN_WIDGET_CLOSED = "The Math Course-Assign Widget is closed as expected";
    public String MATH_ASSIGN_WIDGET_NOT_CLOSED = "The Math Course-Assign Widget is not closed";
    public String READ_ASSIGN_WIDGET_CLOSED = "The Reading Course-Assign Widget is closed as expected";
    public String READ_ASSIGN_WIDGET_NOT_CLOSED = "The Reading Course-Assign Widget is not closed";
    public String MATH_COURSE_ID = "1";
    public String READING_COURSE_ID = "2";
    public String FOCUS_COURSE_ID = "3";
    public String MATH_COLOR_STRING = "#9eca47";
    public String READ_COLOR_STRING = "#32325d";
    public String MATH_PERCENT_TEXT_COLOR = "#000000";
    public String READ_PERCENT_TEXT_COLOR = "#ffffff";
    public String ZOOM_IN_TEXT_COLOR = "#2150a3";
    public String VIEW_GRAPH_FONT_WEIGHT = "600";
    public String PROGRESS_TEXT_FONT_WEIGHT = "700";
    public String SHOW_TARGET_FONT_SIZE = "11.008px";
    public String SHOW_TARGET_FONT_SIZE_SAFARI = "11.008000373840332px";
    public String PROGRESS_FONT_SIZE = "24px";
    public String BOLD = "bold";

    public String DARK_GRAY_HEX = "#cdcfd1";
    String HEIGHT_OF_VIEW_GRAP_ZOOM_IN = "224px";
    String WIDTH_OF_VIEW_GRAP_ZOOM_IN = "537px";
    String X_AXIS_LENGTH_ZOOM_IN = "63px";
    String Y_AXIS_LENGTH_ZOOM_IN = "30px";
    String HEIGHT_OF_VIEW_GRAP_ZOOM_IN_MAC = "225px";
    String WIDTH_OF_VIEW_GRAP_ZOOM_IN_MAC = "531px";
    String X_AXIS_LENGTH_ZOOM_IN_MAC = "69px";
    String Y_AXIS_LENGTH_ZOOM_IN_MAC = "30px";
    String LAST_DATE_X_AXIS_TRANSFORM_ORIGIN_VAUE = "0px 0px";
    String TARGET_LINE_ZOOM_IN = "#7cb5f3";
    String HEIGHT_OF_LEGEND_IMAGE_ZOOM_IN = "50px";
    String X_AXIS_LENGTH_LEGEND_IMAGE = "0.5px";
    String Y_AXIS_LENGTH_LEGEND_IMAGE = "0.5px";
    String VIEW_SUMMARY_SUBHEADING_COLOR = "#3d4149";

    /**
     * Parameters related to Courseware Page
     */
    public static String TRANSLATE = "Translate";
    public static String TOGGLE_BUTTON = "TOGGLE_BUTTON";
    public static String DROPDOWN = "DROPDOWN";
    public static String MANUALLY_SET_COURSE_LEVEL = "Manually Set Course Level";
    public static String INITIAL_PLACEMENT = "Initial Placement (IP)";
    public static String READ_TO_ME = "Read To Me";
    public static String SESSION_LENGHT = "Session Length";
    public static String IDLE_TIME = "Idle Time";
    public static String SHOW_LIMIT_PROGRESS = "Show / limit progress Report";
    public static String CALCULATOR = "Calculator";
    public static String SCRATCHPAD = "Scratchpad";
    public static String SHOW_ANSWER = "Show answer";
    public static String EXIT_COURSE_BUTTON = "Exit Course Button";
    public static String SPEED_GAMES = "Speed Games";
    public static String HELP_ICON_ACTIVE = "Help Icon Active";
    public static String SPANISH_GLOSSARY = "Spanish Glossary";
    public static String SHARE_AT_DISTRICT_LEVEL = "Share at District Level?";
    public static String FLUENCY_RECORDING_TIME = "Fluency recording time";
    public static String GRAMMER_STRAND = "Grammar Strand";
    public static String CHROME = "Windows_10_Chrome_latest";
    public static String SAFARI = "OS X_Big Sur_Safari_14.1";

    /**
     * Standards
     */
    public static List<String> READING_SUCCESSMAKER_STANDARDS = new ArrayList<>( Arrays.asList( "SuccessMaker Mastery Skills - Reading", "Arizona: English Language Arts Standards: K-12: 2016", "Florida B.E.S.T. Standards: English Language Arts, 2020",
            "SMFocus Reading", "MAP Growth (Reading)", "MyPerspectives � 2017 SE", "My Sidewalks", "MyView Literacy 2020", "Texas MyView Literacy 2020", "North Carolina Standard Course Of Study For English Language Arts, K-12: 2017", "Reading Street",
            "ReadyGen", "Common Core: State Standards: English Language Arts: K-12: 2010: PCSA04" ) );
    public static List<String> MATH_SUCCESSMAKER_STANDARDS = new ArrayList<>( Arrays.asList( "SuccessMaker Mastery Skills - Math", "AimswebPlus", "Arizona Mathematics Academic Standards: 2017", "EnVisionMATH California", "EnVision Math 2.0 6-8",
            "EnVision Math 2.0 K-6", "EnVisionMATH Texas 2.0", "EnVision 2020 Mathematics", "Florida B.E.S.T. Standards Mathematics, 2020", "SM Focus Math", "Investigations 3", "MAP Growth (Math)",
            "North Carolina Standard Course Of Study, K-8 Mathematics, 2017", "SuccessMaker Math Performance Tasks", "Common Core State Standards: Mathematics, 2010" ) );

    /*
     * Group Listing Parameters
     */
    public static String STAFF_ID_VALUE = "staffId";
    public static String ORG_ID_VALUE = "orgId";

    /*
     * Create Student Constants
     * 
     *
     */

    public interface Students {
        public static String PASSWORD_MISMATCH_ERROR_MESSAGE = "Password does not match";
        public static String DUPLICATE_USERNAME_ERROR_MESSAGE = "Username already exists";
        public static String DUPLICATE_STUDENTID_ERROR_MESSAGE = "Student ID already exists.";
        public static String MANDATORY_FIELD_ERROR_MESSAGE = "Enter all required fields.";
        public static String INVALID_BIRTHDATE_CHARAC_ERROR_MESSAGE = "Must be a valid date.";
        public static String APOSTROPHE_AND_MIXED_CHARACS_VALUE = "'Ar;?u@n'K8%m*a&r" + System.nanoTime();
        public static int TOTAL_NUMBEROF_FIELDS_POPUP = 16;
        public static String removeStudentText = "Remove Student from Group";
        public static String removeStudentMessage = "Are you sure you want to remove %s from the %s Group?";
        public static String removeText = "Remove";
        public static String cancelText = "Cancel";
        public static String NO_DATA_YET = "NO DATA YET";
        public static String ZERO_STATE_MESSAGE = "You haven't added any students to a list yet.";
        public static String SAVE_TEXT = "Save";
        public static String ADD_TEXT = "Add";

        public static String ADD_STUDENT = "Add Student";

        public static String POPUP_HEADER_GROUP = "Add Students to Group(s)";
        public static String POPUP_HEADER_ASSIGNMENT = "Add Student(s) to Assignment(s)";

        // Elipses options   Add Student to Group Add Student to Assignment
        public static String VIEW_STUDENTS = "View Student";
        public static String ADD_STUDENTS_TO_GROUPS = "Add Student to Group";
        public static String ADD_STUDENTS_TO_ASSIGNMENTS = "Add Student to Assignment";
        public static String ADD_STUDENT_TO_GROUPS = "Add Student to Group(s)";

        public static final String POST_DELETE_STUDENTS = "/lms/web/users/students/delete";
        public static String GRADE1 = "Grade 1";
        public static String COLUMN_FIRST_NAME = "First Name";
        public static String COLUMN_LAST_NAME = "Last Name";
        public static String COLUMN_USER_NAME = "Username";
        public static String COLUMN_STUDNET_ID = "Student ID";
        public static String COLUMN_GRADE = "Grade";
        public static String HELP_URL_FOR_ADD_STU_GRP_POPUP = "https://help-dev.learningservicestechnology.com/successmaker/en/teacher/Content/Teacher/Students/add_student_to_group.htm?cshid=teacher_59d601c5c5d5338011adab79f88ceca659e9dcfe96c680d7f911d3372f5874f9";
        public static String ADD_STU_GRP_TEXT = "Add Students to Groups";
        public static String ZERO_STATE_HEADER = "NO GROUPS";
        public static String ZERO_STATE_DESC = "Currently, you do not have any groups to designate the selected student(s) to. They may already be present in all available group(s).";

        /*
         * Update Student Constants
         *
         */
        public static String GRADE_5 = "Grade 5";
        public static String NAVIGATE_USER_PROFILE = "User Profile";
        public static String DOB_UPDATE = "19/08/2010";
        public static String UPDATE_FIRSTNAME = "Automated_Edited";
        public static String UPDATE_MIDDLENAME = "Automated_Edited";
        public static String UPDATE_LASTNAME = "Automated_Edited";
        public static String UPDATE_STUDENTID = "Automated_Edited";
        public static String UPDATE_USERNAME = "Automated_Edited";
        public static String UPDATE_PASSWORD = "Password_Edited";

        public static List<String> ALL_GRADES = new ArrayList<>( Arrays.asList( "Grade K", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12", "Not Specified" ) );
        public static List<String> ETHNICITY_LISTING = new ArrayList<>( Arrays.asList( "Native American / Alaskan Native", "Asian / Pacific Islander", "Hispanic or Latino", "African American", "Caucasian", "Other", "Not Specified" ) );
        public static List<String> SPL_SERVICE_LISTING = new ArrayList<>( Arrays.asList( "504 Plan", "Gifted / Talented", "IEP", "Other", "No Special Services", "Not Specified" ) );
        public static List<String> DISSABILITY_LISTING = new ArrayList<>( Arrays.asList( "Yes", "No", "Not Specified" ) );
        public static List<String> GENDER_LISTING = new ArrayList<>( Arrays.asList( "Female", "Male", "Not Specified" ) );
        public static List<String> ECONOMIC_LISTING = new ArrayList<>( Arrays.asList( "Economically disadvantaged", "Not economically disadvantaged", "Not Specified" ) );
        public static List<String> ENGLISH_LISTING = new ArrayList<>( Arrays.asList( "English", "English Language Learner", "Not Specified" ) );
        public static List<String> MIGRANT_LISTING = new ArrayList<>( Arrays.asList( "Migrant", "Non-Migrant", "Not Specified" ) );

        /*
         * Student Progress Graph
         *
         */

        public static String MATH_CUSTOM_BY_SETTINGS = "setCrsMath";
        public String NO_DATA_MESSAGE = "NO DATA YET";
        public static String READING_CUSTOM_BY_SETTINGS = "setCrsRead";
        public static String DEFAULT_MATH = "Math";
        public static String DEFAULT_READING = "Reading";
        public static int SIZE_OF_YAXIS = 5;
        public static String SKILL_COURSE = "skillReadCrs";
        public static String STANDARD_COURSE = "stanMathCrs";
        public static String FOCUS_COURSE_MATH = "SM Focus Math: Grade 1";
        public static String FOCUS_COURSE_READING = "SM Focus Reading: Grade 1";
        public static String GAIN_FIELD = "GAIN";
        public static String CURRENT_LEVEL_FIELD = "CURRENT LEVEL";
        public static String IP_LEVEL = "IP LEVEL";
        public static String ASSIGNED_LEVEL = "ASSIGNED LEVEL";
        public static String SIDE_NAV_ASSIGNMENT = "Assignments";
        public static String STUDENT_LAST_SESSION_SKILLS_HEADER = "Last Session Skills";
        public static List<String> STUDENT_LAST_SESSION_SKILLS_ZERO_STATE_MESSAGE = new ArrayList<>( Arrays.asList( "NO DATA YET", "No last session data to show you.", "Once the student begins work on an assignment, data will appear." ) );
        public static String MATH_CUSTOM_BY_STANDARDS = "staCrsMath";
        public static String READ_CUSTOM_BY_STANDARDS = "staCrsReading";

        // Student Details Mastery Drop downs
        public static List<String> LIST_OF_SUBNAVIGATION = new ArrayList<String>( Arrays.asList( "Groups", "Assignments", "Mastery", "User Profile" ) );
        public static String NAVIGATE_ASSIGNMENTS = "Assignments";
        public static String NAVIGATE_MASTERY = "Mastery";
        public static String NAVIGATE_GROUPS = "Groups";

        public static List<String> SUBJECT_DROPDOWN_VALUES = new ArrayList<String>( Arrays.asList( "Math", "Reading" ) );
        public static List<String> MASTERY_ZERO_STATE_MESSAGE = new ArrayList<String>( Arrays.asList( "NO DATA", "Mastery results will be displayed here once you add assignments to the given student and they complete some work." ) );

        public enum Mastery_DropDowns {
            SUBJECT,
            MASTERY_SKILL,
            ASSIGNMENTS
        }

        public static String LEGENDS = "Legends";
        public static String GRADE = "Grade";
        public static String TOPLEVELHIERARCY = "Top Level Hierarcy";
        public static String MIDDLELEVELHIERARCY = "Middle Level Hierarcy";
        public static String LEAFNODEHIERARCY = "Leaf Node Hierarcy";
        public static String LODESCRIPTION = "LO Descriptions";
        public static String PROGRESSBARS = "Progress Bars";
        public static String MASTERYHELPRURL = "https://help-dev.learningservicestechnology.com/successmaker/en/teacher/Content/Teacher/Students/student_details_mastery.htm?cshid=teacher_0e4b96193478b089d72a79d4cc53b42af6d7a2561750eeeab7c89ed0e1e42441";
        public static String MASTERYHELPTITLE = "Student Details - Mastery";
        public static String MASTERY_ASSIGNMENTS_SELECT_ALL = "SELECT ALL";
        public static String MASTERY_SKILL_DEFAULT_VALUE = "SuccessMaker Mastery Skills - Math";
        public static String MASTERY_NO_DATA_ASSIGNMENT = "NO DATA";
        public static String MASTERY_ZERO_STATE_ASSIGNMENT = "Mastery results will be displayed here once you add assignments to the given student and they complete some work.";

        /*
         * Students Tab - Assignment Details Page
         * 
         */
        static String SIDE_NAV_ASSIGNMENT_TAB = "Assignments";
        static String ASSIGNMENT_TITLE = "Title";
        static String ASSIGNMENT_LAST_SESSION = "Last Session";
        static String ASSIGNMENT_IP_LEVEL = "IP Level";
        static String ASSIGNMENT_ASSIGNED_LEVEL = "Assigned Level";
        static String ASSIGNMENT_CURRENT_LEVEL = "Current Level";
        static String ASSIGNMENT_GAIN = "Gain";
        static String ASSIGNMENT_PERCENTAGE = "% Correct";
        static String ZERO_STATE_FOR_ASSIGNMENTS_HEADER_MSG = "NO DATA YET";
        static String ZERO_STATE_FOR_ASSIGNMENTS_DESC_MSG = "This student doesn t have any assignments yet.";
        static String ASSIGNMENT_FLUENCY_FILES = "Fluency Files";
        static String ASSIGNMENT_VIEW_ASSIGNMENT = "View Assignment";
        static String ASSIGNMENT_EDIT_ASSIGNMENT_SETTINGS = "Edit Assignment Settings";
        static String ASSIGNMENT_PAUSE_ASSIGNMENT_FOR_STUDENT = "Pause Assignment For Student";
        static String ASSIGNMENT_REMOVE_STUDENT_FROM_ASSGINMENT = "Remove Student From Assignment";
        static String BACKGROUND_COLOR = "background-color";
    }

    /*
     * User Profile Constants
     * 
     *
     */

    public interface TeacherUserProfile {
        public static String USER_ID_VALUE = " D w_e564hj*g&jiufkg7$h645gfjkt@5 ";
        public static String USER_ID_ERROR_MESSAGE = "User ID already exists";
        public static String MAX_LENGTH_ERROR_MESSAGE = "Exceed Maximum Length";
        public static String EMAIL_ERROR_MESSAGE = "Please enter a valid email address.";
        public static String CURRENT_NEWPASSWORD_SAME_ERROR = "Your new password must be different from your current password.";
        public static String MANDATORY_FIELD_ERROR = "Enter all required fields.";
        public static String WRONG_CURRENT_PASSWORD_ERROR_MESSAGE = "Incorrect password.";
        public static String EMAIL_ID_VALUE = "Erv@gmail.com";
        public static String FIRSTNAME_WITH_MIXEDCHARACS = "yuV:#$ 'jh5df@$";
        public static String LASTNAME_WITH_MIXEDCHARACS = "yuV:#$ 'jh5df@$";
        public static String MIDDLENAME_WITH_MIXEDCHARACS = "yuV:#$ 'jh5df@$";
        public static String INCORRECT_EMAIL_ID_VALUE = "yuvan123gmail.com";
        public static String INCORRECT_EMAIL_ID_VALUE_WITHOUT_DOMAIN = "yuvan123@gmail";
        public static List<String> TITLE_DROPDOWN_VALUES_USERPROFILE = new ArrayList<>( Arrays.asList( "Select Title", "Dr", "Miss", "Ms", "Mr", "Mrs" ) );

    }

    /**
     * Reports
     */
    public interface Reports {
        public static List<String> ADDITION_GROUPING = new ArrayList<>( Arrays.asList( "None", "Grade", "Group" ) );
        public static List<String> DISPLAY = new ArrayList<>( Arrays.asList( "Student Name", "Student ID", "Student Username" ) );
        public static List<String> SORT = new ArrayList<>( Arrays.asList( "Student", "Assigned Course Level", "Current Course Level", "IP Level", "Gain", "Time Spent", "Total Sessions", "Exercises Correct", "Exercises Attempted",
                "Exercises Percent Correct", "Skills Assessed", "Skills Mastered", "Skills Percent Mastered", "AP" ) );
        public static List<String> SORT_LSR = new ArrayList<>( Arrays.asList( "Student", "Current Course Level", "Exercises Correct", "Exercises Attempted", "Exercises Percent Correct", "Help Used", "Time Spent", "Total Sessions", "Session Date" ) );
        public static String FILTERS = "FILTERS";
        public static String LSR_REPORT = "Last Session";
        public static String LSR_HEADER = "Last Session Report";
        public static String LSR_DESCRIPTION = "The Last Session Report (LSR) for both Math and Reading provides information about the last completed session for groups of students and for individual students in the group.";
        public static String CPR_HEADER = "Cumulative Performance Report";
        public static String CPR_DESCRIPTION = "The Cumulative Performance Report (CPR) provides information about student performance and progress including students' current course level and gain, usage time, raw exercise performance, and mastery performance";
        public static String SPR_REPORT = "Student Performance";
        public static String AOD_REPORT = "Areas of Difficulty";
        public static String PSR_REPORT = "Prescriptive Scheduling";
        public static String EXERCISE_PERCENTAGE_CORRECT = "Exercises Percent Correct";
        public static String GROUP_DROPDOWN = "Groups";
        public static String STUDENTS_DROPDOWN = "Students";
        public static String SUBJECT_DROPDOWN = "Subject";
        public static String ASSIGNMENTS_DROPDOWN = "Assignments";
        public static String EXERCISE_ATTEMPT = "Exercises Attempted";
        public static String ADDITIONAL_GROUPING_DROPDOWN = "Additional Grouping";
        public static String DISPLAY_DROPDOWN = "Display";
        public static String SORT_DROPDOWN = "Sort";
        public static String DATE_AT_RISK_DROPDOWN = "date at risk";
        public static String CURRENT_COURSE_LEVEL = "Current Course Level";
        public static String EXERCISE_CORRECT = "Exercises Correct";
        public static String SAVED_OPTIONS_DROPDOWN = "Saved Options";
        public static String SELECTED_GROUPS = "{selected_count} Groups Selected";
        public static String SELECTED_STUDENTS = "{selected_count} Students Selected";
        public static String SELECTED_ASSIGNMENTS = "{selected_count} Assignments Selected";
        public static String SELECTED_ALL_GROUPS = "All Groups ({selected_count})";
        public static String SELECTED_ALL_STUDENTS = "All Students ({selected_count})";
        public static String SELECTED_ALL_ASSIGNMENTS = "All Assignments ({selected_count})";
        public static String SELECTED_ALL_SUBJECTS = "All Subjects ({selected_count})";
        public static String SELECTED_COUNT = "{selected_count}";
        public static String UNCHECKED_SUBJECTS = "Select Subject(s)";
        public static String GROUP_OR_STUDENT_HEADER = "STEP 1: Select Groups or Students";
        public static String REFINE_SEARCH = "STEP 2: Refine Search";
        public static String REPORT_OPTION_HEADER = "REPORT OPTIONS";
        public static String GROUPS_SELECTED_COUNT = "Groups ({selected_count})";
        public static String STUDENTS_SELECTED_COUNT = "Students ({selected_count})";
        public static String ASSIGNMENTS_SELECTED_COUNT = "Assignments ({selected_count})";

        public static String SAVEREPORT_POUP_HEADER = "Save Report Options As";
        public static String NEW_HEADER_SAVEREPORT = "New";
        public static String REPLACE_EXISTING_HEADER = "Replace Existing Report Options";
        public static String SAVEBTN_SAVEREPORT_OPTION = "Save";
        public static String CANCELBTN_SAVEREPORT_OPTION = "Cancel";
        public static List<String> SUBJECTS = new ArrayList<>( Arrays.asList( "Math", "Reading" ) );
        public static String ADDITIONAL_GROUPING = "Additional Grouping";
        public static String NONE = "None";
        public static String GRADES = "Grade";
        public static String GROUP = "Group";
        public static String STUDENT_NAME = "Student Name";
        public static String STUDENTID = "Student ID";
        public static String STUDENT_USERNAME = "Student Username";
        public static String REMOVE_PAGE_BREAKS = "Remove Page Breaks";
        public static String MASK_STUDENT_DISPLAY = "Mask Student Display";
        public static String EXISTING_NAME_ERROR = "Name already exists, choose another one.";
        public static String TIME_SPENT = "Time Spent";
        public static String NO_ASSIGNMENTS = "No Assignments Available";
        public static String CHOOSE_ONE = "Choose One";

        public static String EXCEED_MAX_LENGTH = "Exceed Maximum Length";
        public static String MAX_LENGTH_FILTER_NAME = "oitrtyuopasdfhgjkzmnbvcx1234667890123ytsdsdsdbsusfhiadhshd";

        public static String SELECT_ALL = "Select All";
        public static String SAVE_REPORT_OPTION = "Save Report Options";

        /*
         * CPR Reports
         */
        public static String CPR_REPORT = "Cumulative Performance";
        public static String CPR_SHOW_STUDENT_PERFORMANCE_HEADER = "Show Student Performance for:";
        public static String CPR_ALL_DATES = "All Dates";
        public static String CPR_SELECTED_DATE_RANGE = "Selected Date Range";
        public static String CPR_FROM_DATE = "From Date";
        public static String CPR_TO_DATE = "To Date";
        public static String START_DATE = "27/27/2021";
        public static String END_DATE = "27/30/2021";
        public static String DATE_ERROR_MESSAGE = "Must be a valid date";
        public static String ZERO_STATE_MESSAGE_HEADER = "NO DATA AVAILABLE";
        public static String ZERO_STATE_MESSAGE_DESCRIPTION = "No students exist in the database. Once students are available, you will be able to use the Reports feature.";

        /*
         * PSR Reports
         */
        public static String PSR_HEADER = "Prescriptive Scheduling Report";
        public static String PSR_DESCRIPTION = "The Prescriptive Scheduling Report (PSR) is a forecasting tool that enables you to monitor student progress and adjust schedules to reach performance goals.";
        public static String PSR_HOLIDAY_INFO = "Report results are based on school days as defined in the Holiday Schedule.";
        public static String PSR_TARGET_DATE = "Target Date";
        public static String PSR_SET_TARGETLEVEL_PERGRADE = "Set Target Level per Grade";
        public static List<String> PSR_ADDITION_GROUPING = new ArrayList<>( Arrays.asList( "grade", "grade then group" ) );
        public static List<String> PSR_SORT = new ArrayList<>( Arrays.asList( "student", "current course level", "ip/start level", "time (since ip-if used)", "recent % of skills mastered", "session length setting", "average min/day",
                "current learning rate", "current forecast time", "current forecast level", "add'l sessions to target", "add'l time to target", "add'l min/day to target" ) );
        public static String PSR_ERROR_MESSAGE = "Must be a current or future date.";
        public static String PSR_CURRENT_COURSE_LEVEL = "Current Course Level";
        public static String PSR_LOWER_RANGE = "0";
        public static String PSR_HIGHER_RANGE = "8.95";

        /**
         * Student performance Reports
         */
        public static String DATEATRISK_DROPDOWN = "Date at Risk";
        public static String SPR_SUBMENU = "Student Performance";
        public static String SPR_HEADER = "Student Performance Report";
        public static String SPR_DESCRIPTIONTEXT = "The Student Performance Report (SPR) provides detailed information about student performance and progress in a course. The report includes cumulative and recent performance information in both Math and Reading, Initial Placement performance information, and identifies specific areas of difficulty.";
        public static String SPR_DATEATRISK_DROPDOWN = "date at risk";
        public static String SPR_LANGUAGE_DROPDOWN = "Language";
        public static String SPR_INCLUDEPERFORMANCE = "Include Performance Summary";
        public static String SPR_INCLUDEPERFORMANCESTRAND = "Include Performance by Strand";
        public static String SPR_INCLUDEAOD = "Include Areas of Difficulty";
        public static String SPR_SAVEREPORT_POUP_HEADER = "Save Report Options As";
        public static String SPR_NEW_HEADER_SAVEREPORT = "New";
        public static String SPR_REPLACE_EXISTING_HEADER = "Replace Existing Report Options";
        public static String SPR_CANCELBTN_SAVEREPORT_OPTION = "Cancel";
        public static String SPR_SAVEBTN_SAVEREPORT_OPTION = "save";
        public static String SPR_SAVEDREPORT_NAME = "Save Report options As for Student Performance Report ";
        public static String SPR_ERROR_MESSAGE = "exceed maximum length";
        public static List<String> DATE_AT_RISK = new ArrayList<>( Arrays.asList( "since ip", "24 weeks", "20 weeks", "16 weeks", "12 weeks", "8 weeks", "4 weeks", "2 weeks", "1 week" ) );
        public static List<String> LANGUAGE = new ArrayList<>( Arrays.asList( "english", "spanish" ) );
        public static String SPR_SPANISH = "spanish";
        public static String ENGLISH = "english";
        public static String SPR_MATH = "Math";
        public static String SPR_READING = "Reading";
        public static String ZERO_STATE_TEXT_GRP = "No Groups Found";
        public static String ZERO_STATE_TEXT_ASSIGNMENTS = "No Assignments Available";
        public static String SINCE_IP = "since ip";
        // AOD Reports
        public static String AOD_HEADER = "Areas of Difficulty Report";
        public static String AOD_DESCRIPTION = "The Areas of Difficulty (AOD) Report lists the Math and Reading skills with which the selected students are having difficulty. The report groups students by these skills to allow teachers to determine which students require assistance and/or intervention.";
        public static List<String> AOD_SORT = new ArrayList<>( Arrays.asList( "Strand", "Level", "Skill Description" ) );
        public static String LEVEL = "Level";
        public static List<String> AOD_DATE_AT_RISK = new ArrayList<>( Arrays.asList( "Since IP", "24 Weeks", "20 Weeks", "16 Weeks", "12 Weeks", "8 Weeks", "4 Weeks", "2 Weeks", "1 Week" ) );
        public static String WEEKS_20 = "20 Weeks";
        public static String SAVE_REPORT_ERROR_MESSAGE = "Enter all required fields.";
        public static String UNCHECKED_ASSIGNMENT_DROPDOWN_DEFAULT_VALUE = "Select Assignment(s)";
        public static String AOD_NO_STUDENT_ZERO_STATE = "No students exist in the database. Once students are available, you will be able to use the Reports feature.";
        public static String AOD_NO_ASSIGNMENT = "No Assignments Available";
        public static String LONG_STUDENT_FIRST_NAME = "TestSTUDENT0000000000000000000000000000001";
        public static String LONG_STUDENT_LAST_NAME = "Test STUDENT Last Name";
        public static String LONG_GROUP_NAME = "Test Group 000000000000000000000000001";
        public static String LONG_ASSIGNMENT_NAME = "Test Assignment 000000000000000000001";

    }

    /**
     * User UI related test cases
     * 
     *
     * @author ajith.mohan
     */
    public interface UserUIConstants {
        public static String ADD_STUDENT_TO_ASSIGNMENT_ZERO_STAGE = " Currently, you do not have any assignments to designate to the student(s) that you've selected. ";
        public static String ADD_STUDENT_TO_ASSIGNMENT_TITLE = "Add Student(s) to Assignment(s)";
        public static String ADD_STUDENT_TO_ASSIGNMENT_TOAST_MESSAGE = "Your assignment(s) were successfully assigned to your chosen student(s).";
        public static String CREATE_STUDENT_HELP_TITLE = "Add a Student";
        public static String ADD_STUDENT_ASSIGNMENT_HELP_TITLE = "Add Students to Assignments";
    }

    /**
     * Group UI related constants
     * 
     * @author ajith.mohan
     *
     */
    public interface GroupUIConstants {
        public static String SIMPLE_GROUP_NAME = "UI_Automation_" + System.nanoTime();
        public static String ABOVE_75_CHAR_GROUP_NAME = "Test automation group name with 75 characters only used for successmaker.....";
        public static String BELOW_3_CHAR_GROUP_NAME = "AB";
        public static String EXACT_75_CHAR_GROUP_NAME = "Test automation group name with 75 characters only used for successmaker..";
        public static String SPECIAL_CHAR_GROUP_NAME = "#$%^&*()";
        public static String WHITE_SPACE_GROUP_NAME = " ";
        public static String EXACT_3_CHAR_GROUP_NAME = "ABC";
        public static String NULL_GROUP_NAME = StringUtils.SPACE;
        public static String GROUP_NAME_INBETWEEN_SPACE = "SUCCESSMAKER GROUP";
        public static String APHOSTROPHY_CHAR_GROUP_NAME = "SUCCESSMAKER's GROUP";
        public static String NUMERIC_GROUP_NAME = "12345689 GROUP";
        public static String MIN_MAX_ERROR_MESSAGE = "Group name must be between 3 and 75 characters";
        public static String NULL_GROUP_NAME_ERROR_MESSAGE = "Please enter a group name.";
        public static String DUPLICATE_GROUP_NAME_MESSAGE = "Group name taken. Please enter a unique group name.";
        public static String CREATE_GROUP_HELP_TITLE = "Create a New Group";
        public static String ADD_STUDENT_TO_GROUP_HELP_TITLE = "Add Students to a Group";
        public static String ZEROSTATE_HEADER = "NO DATA YET";
        public static String ZEROSTATE_MESSAGE = "There are no students in this group";
        public static String ZEROSTATE_LINK = "Add Students To Group";
        public static String ZEROSTATE_ASSIGNMENT_MSG = "There are no assignments in this group";
        public static String GROUP_ALLGRADES = "All Grades";
        public static String MAX_LENGTH_GROUP_NAME = "oitrtyuopasdfhgjkzmnbvcx1234667890123ytsdsdsdbsusfhiadhshdsgdnsugudgusgdhdg";
        public static String NEW_GROUP_NAME = "group_09";
        public static String UPPER_lOWER_CASE_GROUP_NAME = "GroUP TeXT tesTINg";
        public static String SPACE_BETWEEN_CHAR_GROUP_NAME = "s u c c e s s m a k e r";
        public static String UPPER_CASE_GROUP_NAME = "SAMPLE";
        public static String ALPHANUMERIC_GROUP_NAME = "Success@123";
        public static String LOWER_CASE_GROUP_NAME = "successmaker";
        public static String UPPER_SPECIAL_CHAR_NAME = "SAMPLE@#@!@#*&^&(*";
        public static String LOWER_SPECIAL_CHAR_NAME = "testing@#@!@#*&^&(*";
        public static String UPDATED_GROUP_NAME = "group_10";
        public static String EXISTING_GROUP_NAME = "group_09";
        public static String UNASSIGNED_GROUP = "Unassigned Group";
        public static String HELP_URL_FOR_ADD_STU_GRP_POPUP = "https://help-dev.learningservicestechnology.com/successmaker/en/teacher/Content/Teacher/Groups/group_add_students.htm?cshid=teacher_b69c50588bb81d4f05dfb916d95b694be57681cf4b509ededc2fae15b34fd1b7";
        public static List<String> SKILLASSESS_ZEROSTATEMESSAGE = new ArrayList<>( Arrays.asList( "NO DATA YET", "Only skills assessed in the past 30 days are considered for this graph." ) );
        public static List<String> SKILLASSESS_NO_ASSIGNMENT_ZERO_STATE_MESSAGE = new ArrayList<>( Arrays.asList( "NO DATA YET", "No skills assessment data to show you.", "Once the student begins work on an assignment, data will appear." ) );
        public static String ASSIGNMENTS = "Assignments";
        public static String MATH = "Math";
        public static String READING = "Reading";
        public static String GROUP_NAME = "Group Name";
        public static String GROUP_USAGE = "Group Usage";
        public static String SKILLS_ASSESSMENT = "Skills Assessment";
        public static String PERCENT_OF_STUDENTS_MASTERED = "PERCENT OF STUDENTS MASTERED";
        public static String ZERO_STATE_MESSAGE_FOR_USAGE = "NO DATA YET";
        public static String THIS_WEEK = "THIS WEEK";
        public static String LAST_WEEK = "LAST WEEK";
        public static String SCHOOL_YEAR = "SCHOOL YEAR";
        public static List<String> MASTERY_ZERO_STATE_MESSAGE = new ArrayList<>( Arrays.asList( "NO DATA", "Mastery results will be displayed here once you add students and assignments." ) );
        public static String CREATE_GROUP_POPUP_HEADER = "Create New Group";
        public static String GROUP_NAME_LABEL = "Name Your Group";
        public static String ADD_STUDENT_LABEL = "Add Students";
        public static String GROUP_NAME_PLACEHOLDER = "Enter Name of Group";
        public static String ADD_STUDENT_PLACEHOLDER = "Search Student or Username";
        public static String SELECT_ALL_STUDENTS_LABEL = "Search all students in your school";
        public static String NO_STUDENT_FOUND_MESSAGE = "No students match your search criteria.";
        public static String SCHOOL_STUDENT_SELECTION_HINT = "Please select a grade in the drop-down menu on the upper-right and start typing to search for students in your school.";
        public static String CREATE_BUTTON_COLOR_ENABLED = "rgba(0, 123, 255, 1)";
        public static String CREATE_BUTTON_COLOR_DISABLED = "rgba(0, 0, 0, 0.2)";
        public static String STUDENT_INFO_MAX_SIZE = "575px";
    }

    /**
     * HomePage Widget UI related constants
     */
    public interface HomePageWidgetConstants {
        public static String ANNOUNCEMENT_HEADER = "Announcements";
        public static String MASTERY = "Mastery";
        public static String MASTERED_TEXT = "Mastered";
        public static String TOP_PERFORMING = "Top Performing";
        public static String LOW_PERFORMING = "Low Performing";
        public static String DIDYOUKNOWHEADER = "Did you know?";
        public static String DIDYOUKNOWCONTENTLINK = "my Savvas Training";
        public static List<String> GOALS_LEGENDS = new ArrayList<>( Arrays.asList( "On Track", "Falling Behind", "Watch Closely" ) );
        public static String GOALS_HINT = "Usage goals apply only to the default courses Math and Reading.";

        public static String GOALS_STUDENT_LEGEND_UI = "% of Students";
        public static String GOALS_COLOR_UI_ON_TRACK = "background%s rgb(158, 202, 71); width: %s";
        public static String GOALS_COLOR_UI_WATCH_CLOSELY = "background%s rgb(249, 168, 70); width: %s";
        public static String GOALS_COLOR_UI_FALLING_BEHIND = "background%s rgb(215, 58, 89); width: %s";
        public static String USAGE_GOALS_TITLE = "Usage Goals";
        public static String SAFARI_GOALS_COLOR_CHANGE = "-color:";
        public static String ZERO_STATE_GOALS_TITLE = "NO DATA AVAILABLE";
        public static String ZERO_STATE_GOALS_CONTENT = "Usage goals data will display when available.";

    }

    /**
     * Groups Assignments subnav Constants
     * 
     *
     * 
     * @author madhan.nagarathinam
     */
    public interface GroupsAssignments {
        public static String MATH = "Math";
        public static String TITLE = "Title";
        public static String DATEASSIGNED = "DateAssigned";
        public static String PAUSED = "Paused";
        // Delete Assignments Pop-up Message    
        public static String DELETE_ASSIGNMENT_POPUP_MESSAGE = "Heads Up!This will remove the assignment associated to this group and all students associated to this group.";
        // Groups with zero assignments message 
        public static String ZERO_STATE_ASSIGNMENT_MESSAGE = "There are no assignments in this group";
        // Pause Assignments Pop-up Message 
        public static String PAUSE_ASSIGNMENT_POPUP_MESSAGE = "Heads Up!If you pause this assignment, you will not see student progress on it until you resume the assignment.";
        // Resume Assignments Pop-up Message
        public static String RESUME_ASSIGNMENT_POPUP_MESSAGE = "Heads Up!This action will resume assignment for all the students.";
    }

    /**
     * Groups SettingsConstants
     * 
     * @author aravindan.sivanandan
     */

    public interface GroupsSettings {
        public static String GROUP_SETTINGS_HEADER = "Settings";
        public static String EDIT_SETTINGS = "EDIT SETTINGS";
        public static String GROUP_NAME = "Group Name";
        public static String DELETE_GROUP = "DELETE GROUP";
        public static String DELETE_GROUP_TEXT = "Deleting a group will remove all assignments, mastery, and students for that group.";
    }

    /**
     * Usage chart
     */
    public interface UsageChart {
        public static String STUDENT_USAGE_HEADER = "Student Usage";
        public static List<String> USAGE_FIELDS = new ArrayList<>( Arrays.asList( "THIS WEEK", "LAST WEEK", "SCHOOL YEAR" ) );
        public static List<String> LEGENDS = new ArrayList<>( Arrays.asList( "Math", "Reading" ) );
        public static List<String> STUDENTUSAGE_ZEROSTATEMESSAGE = new ArrayList<>( Arrays.asList( "NO DATA YET", "No usage to show you.", "Once the student begins work on an assignment, data will appear." ) );
        public static String HOURS = "Hours";
        public static String MINUTES = "Minutes";
        public static String MATH = "Math";
        public static String READING = "Reading";
        public static String TOTAL = "Total";
        public static String ZERO_HOURS = "0 hours";
        public static String LESS_THAN_ONE_HOUR = "< 1 hour";
        public static String ZERO_MINUTES = "0 minutes";
        public static String ONE_HOUR = "1 hour";
        public static String ONE_MINUTE = "1 minute";
        public static String HOUR = "hour";
        public static String Minute = "minute";
        public static String WEEKS = "Weeks";
        public static String GROUP_USAGE_HEADER = "Group Usage";
        public static List<Double> YAXISINTERVAL_DEFAULT = new ArrayList<>( Arrays.asList( 15.0, 30.0, 45.0, 60.0 ) );
    }

    /**
     * Groups Assignments subnav Constants
     *
     * @author Sudarshan.Govindarajan
     */

    public interface HelpPage_AnnoucementPageTitles {
        public static String HOMEPAGEHELPTITLE = "Explore the Dashboard";
        public static String STUDENTHELPPAGETITLE = "Students";
        public static String GROUPSHELPPAGETITLE = "Groups";
        public static String ASSIGNMENTHELPPAGETITLE = "Assignments";
        public static String COURSESHELPPAGETITLE = "Courses";
        public static String MASTERYHELPPAGETITLE = "Mastery";
        public static String CPRHELPPAGETITILE = "Cumulative Performance Report";
        public static String LSRHELPPAGETITLE = "Last Session Report";
        public static String SPRHELPPAGETITILE = "Student Performance Report";
        public static String CREATENEWGROUPDIALOGBOXHELPPAGETITLE = "Create a New Group";
        public static String ANNOUNCEMENTICONPAGETITLE = "SM help Announcements and Resources page is loaded in a new tab";

    }

    /**
     * Course Creation Page Constants
     */

    public interface Course_Creation {
        public static String IPMLABEL = "Initial Placement (IP)";
    }

    /**
     * Last session skill Tested Constants
     *
     * @author Bharathi.Murugan
     */
    public interface LastSessionSkillTested {
        public static String SKILL_TESTED_ENDPOINT = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/assignments/{assignmentIdValue}/students/{studentIds_value}/skillsTestedReport";
        public static String SKILLTESTED_BODY = "{\"assignmentUserId\": {assignmentUserIDValue},\"lastSessionFlag\": true,\"sessionDates\": [],\"subjectTypeId\": {subjectTypeIdValue}}";
        public static String SKILL_NAME = "skillName";
        public static String TOTAL_LO_ATTEMPTS = "completedTotalLoAttempts";
        public static String TOTAL_LO_CORRECT = "completedTotalLoCorrect";
        public static String OBJECT_DESCRIPTION = "objectDescription";
        public static String CATALOG_NUMBER = "catalogNum";
        public static String LO_DETAILS = "loDetails";
        public static String MATH_SKILL_TESTED_POPUP_HEADER = "Math Skill";
        public static String READING_SKILL_TESTED_POPUP_HEADER = "Reading Skill";
        public static String LO_URL = "viewLoUrl";
        public static String PERCENTAGE_CORRECT = "percentageCorrect";
        public static String COLOR_BLACK = "#000000";
        public static String COLOR_WHITE = "#ffffff";
        public static String BG_COLOR_GREEN = "#9eca47";
        public static String BG_COLOR_BLUE = "#32325d";
    }

    /**
     * 
     * Course Widget on HomePage
     * 
     * @author vikas.pandey
     *
     */
    public interface HomePage {
        public static String MATH_COURSE = "Math";
        public static String READING_COURSE = "Reading";
        public static String FOCUS_MATH_COURSE = "SM Focus Math: Grade 1";
        public static String FOCUS_READING_COURSE = "SM Focus Math: Grade 1";
        public static String CUSTOM_MATH_COURSE = "SM Focus Reading: Grade 1";
        public static String CUSTOM_READING_COURSE = "SM Focus Math: Grade 1";
        public static String CREATED_DATE = "Created";
        public static String ASSIGNED_DATE = "Assigned";
        public static String LAST_EDIATED_DATE = "Last Edited";
        public static String RULE_FOR_DEFAULT_MATH = "Math_Friends_Default_green.png";
        public static String RULE_FOR_DEFAULT_READING = "Reading_Friends_Default_Indigo.png";
        public static String RULE_FOR_CUSTOM_MATH = "Math_Avocado_Customized.png";
        public static String RULE_FOR_CUSTOM_READING = "Reading_Ferret_Customized_Indigo.png";
        public static String RULE_FOR_FOCUS_MATH = "Math_Octopus_Focused_green.png";
        public static String RULE_FOR_FOCUS_READING = "Reading_Hamster_Focus_Indigo.png";
        public static String COURSE_WIDGET = "Full Course";
        public static String COURSE_WIDGET_CUSTOM = "My Custom Course";
        public static String COURSE_WIDGET_SHARED = "Shared Course";
        public static String COURSE_ASSIGN_BTN = "Assign";
        public static String HOME_PAGE_USAGE_GOALS_API = "/lms/web/api/v1/organizations/organizationId/staffs/staffId/usagegoals";
    }

    /**
     * 
     * Usage Goal - HomePage
     * 
     * @author bharathi.murugan
     *
     */
    public interface UsageGoal {
        public static List<String> USAG_EGOAL_COLUMNS_HEADER = new ArrayList<>( Arrays.asList( "Student", "Usage Goal Status", "Total Time", "Avg Time / Wk", "Target Hours", "Goal End Date" ) );
        public static String USAGE_GOAL_MATH_HEADER = "Math Usage Goals";
        public static String USAGE_GOAL_READING_HEADER = "Reading Usage Goals";
        public static String STUDENT_DETAIL = "studentDetail";
        public static String STUDENT = "student";
        public static String GOAL_BUCKET = "goalBucket";
        public static String ACTUAL_MINUTES = "actualMinutesInCourse";
        public static String AVERAGE_MINUTE_PER_WEEK = "averageMinutesPerWeek";
        public static String ADDITIONAL_MINUTE_PER_WEEK = "additionalMinutesPerWeek";
        public static String GOAL_MINUTES = "goalMinutesInCourse";
        public static String GOAL_END_DATE = "goalEndDate";
        public static String STUDENT_COUNT = "Student%s";
        public static String WATCH_CLOSELY = "Watch Closely";
        public static String FALLING_BEHIND = "Falling Behind";
        public static String ONTRACK = "On Track";
        //****************/*******************/
        public static String HINT_MESSAGE = "Usage goals apply only to the default courses Math and Reading.";
        public static String ORGANIZATION_SELECTED_TEXT = "Organizations Selected";
        public static String PERCENTAGE_TEXT_LEGENDS = "% of Students";
        public static String NO_DATA_DISPLAYED = "No Usage data to display";
        public static String NO_RESULT_DISPLAYED = "NO RESULTS DISPLAYED";
        public static int NO_OF_ORG_TEXT_SIZE = 22;
        public static String HEX_VALUE_BLACK_COlOUR = "#000000";
        public static String HEX_VALUE_ONTRACK = "#9eca47";
        public static String HEX_VALUE_WATCHCLOSELY = "#f9a846";
        public static String HEX_VALUE_FALLINGBEHIND = "#d73a59";
    }

    /**
     * Custom by Standard course creation
     */
    public static String GRADE_ID = "{gradeId}";
    public static String STANDARDFRAMEWORK_ID = "{standardId}";
    public static String BANKID = "{bankID}";
    public static String LOID = "{loID}";
    String CONTENT_BASE_TYPE = "{contentBaseId}";
    public static String SESSION_LENGTH_ID = "{sessionLengthId}";
    public static String SESSION_LENGTH_NAME = "{sessionLengthName}";
    public static String SESSION_LENGTH_VALUE = "{sessionLengthValue}";
    public static String IDLE_TIME_ID = "{idleTimeId}";
    public static String IDLE_TIME_NAME = "{idleTimeName}";
    public static String IDLE_TIME_VALUE = "{idleTimeValue}";

    /**
     * Edit assignment pop up page
     * 
     * @author vikas.pandey
     *
     */
    public interface EditAssignments {
        public static String SESSION_LENGTH_HEADER = "Session Length";
        public static String IDEAL_TIME_HEADER = "Idle Time";
        public static String SESSION_LENGTH_FIRST_ELEMENT = "5 minutes";
        public static String SESSION_LENGTH_LAST_ELEMENT = "180 minutes";
        public static String IDEAL_TIME_FIRST_ELEMENT = "2 minutes";
        public static String IDEAL_TIME_LAST_ELEMENT = "6 minutes";
        public static String PROGRESS_LIMIT_FIRST = "0 per session";
        public static String PROGRESS_LIMIT_LAST = "10 per session";
        public static String SPEED_GAMES_QUESTION = " Speed Games Time per Question";
        public static String SPEED_GAMES_TOTAL_TIMES = "Speed Games Total Time";
        public static String SPEED_GAME_FIRST_ELEMENT = "1 seconds";
        public static String SPEED_GAME_LAST_ELEMENT = "6 seconds";
        public static String SPEED_GAME_TOTAL_TIME_GAME_FIRST_ELEMENT = "1 minutes";
        public static String SPEED_GAME_TOTAL_TIME_LAST_ELEMENT = "3 minutes";
        public static String INITIAL_PLACEMENT = "Initial Placement (IP)";
        public static String SET_COURSE_LEVEL = "Manually Set Course Level";
        public static String ON = "On";
        public static String OFF = "Off";
        public static String DISPLAY_LO_INFORMATION = "Display Lo Information";
        public static String HELP_ICON_ACTIVE = " Help Icon Active";
        public static String PROGRESS_LIMIT_HEADER = "Show / limit progress Report";
        public static String EXIT_COURSE_BUTTON = "Exit Course Button";
        public static String SPANISH_GLOSSARY = "Spanish Glossary";
        public static String GRAMMAR_STRAND = "Grammar Strand";
        public static String READ_TO_ME = "Read To Me";
        public static String TRANSLATE = "Translate";
        public static String FLUENCY = "Fluency";

    }

    /**
     * Qualtrics Survey Popup
     * 
     * @author Kathiravan.m
     */
    public String NIGHTLY_SM_URL = "https://nightly.smdemo.info";
    public String QUALTRICS_POPUP_TEXT = "Help us understand your experience with SuccessMaker. Would you be willing to complete a short survey following your visit?";
    public String QUALTRICS_POPUP_YES_BUTTON = "YES!";
    public String QUALTRICS_POPUP_NO_TEXT = "No thank you";
    public String QUALTRICS_SURVEY_THANK_YOU = "Thank you";
    public String DISTRICT_DROPDOWN_IN_SURVEY = "Alabama";
    public String SURVEY_TEXT_ANSWER = "Qualitrics Survey Test Automation test note";
    public String SATISFACTION_QUESTION = "Please begin by rating your satisfaction with SuccessMaker.";
    public String LIKE_ABOUT_SM_QUESTION = "What do you like most about SuccessMaker?";
    public String LEAST_LIKE_QUESTION = "What do you like least about SuccessMaker? In your response, please include any suggestions for improving this program.";
    public String WHICH_SM_PROGRAM_QUESTION = "Which SuccessMaker program(s) do you currently use?";
    public String WHICH_GRADE_READING_QUESTION = "At which grade level(s) are you currently using SuccessMaker Reading?";
    public String WHICH_GRADE_MATH_QUESTION = "At which grade level(s) are you currently using SuccessMaker Math?";
    public String AGREE_DISAGREE_QUESTION = "How strongly do you agree or disagree that each of the following statements applies to the SuccessMaker program?";
    public String YEARS_OF_USING_SM_QUESTION = "Including this school year, how long have you been using SuccessMaker?";
    public String JOB_TITLE_QUESTION = "Which of the following best describes your job title?";
    public String USAGE_OF_SM_QUESTION = "Which of the following scenarios best describes how most of your students are receiving instruction using the SuccessMaker program this school year (2021-2022)?";
    public String STATE_SELECTION_QUESTION = "Please indicate the state in which your district is located.";
    public String SAVVAS_URL = "https://www.savvas.com/";
    public String GET_ALL_USERS_XML = "getAllUserFromOrg.xml";
    
    /**
     * Report Data Creation
     * 
     * @author karthigeyan.bala
     *
     */
    public interface ReportDataCreation {

        String SHARED_GROUP = "Shared_Group";
        String SHARED_STUDENT_GROUP = "Shared_Student_Group";
        String GROUP_WITH_NO_STUDENTS = "Group_With_No_Students";
        String GROUP_WITHOUT_PRODUCT = "Group_Without_Product";

    }
}