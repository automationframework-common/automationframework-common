package com.savvas.sm.utils.sme187.admin.api.mastery;

import com.savvas.sm.config.EnvProperties;

public class Mastery extends EnvProperties {

}
