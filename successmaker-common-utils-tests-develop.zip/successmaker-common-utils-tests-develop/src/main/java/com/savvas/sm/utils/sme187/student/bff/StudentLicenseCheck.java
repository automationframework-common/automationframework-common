package com.savvas.sm.utils.sme187.student.bff;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.reports.ReportConstants;
import com.savvas.sm.utils.sme187.student.api.licenses.LicenseConstants;
import com.savvas.sm.utils.sme187.teacher.api.reports.ReportConstants.ReportAdminConstants;

import io.restassured.response.Response;

public class StudentLicenseCheck {

    public Response getFocusLicenseCheckBff( String userName, String userId, String orgId, List<String> selectedOrgIds ) throws IOException {
        Response response = null;
        try {

            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.USERID_SM_HEADER, userId );
            headers.put( Constants.ORGID_SM_HEADER, orgId );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, DataSetupConstants.DEFAULT_PASSWORD ) );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            // Generate Payload
            AtomicReference<String> requestBody = new AtomicReference<>();
            requestBody.set( SMUtils.getPayload( PayloadFor.STUDENT, "FocusLicenseCheck.json" ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.userId", userId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.orgId", orgId ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), "variables.programOrgIds", selectedOrgIds ) );

            response = RestAssuredAPIUtil.POSTGraphQl( ReportAdminConstants.STUDENT_BFF, headers, requestBody.get(), ReportConstants.GRAPHQL_ENDPOINT );
        } catch ( Exception e ) {
            Log.message( e.getMessage() );
        }
        return response;
    }

    public HashMap<String, String> checkAllFocusLicenses( String smUrl, String userName, String userId, String orgId, String selectedOrgUds ) throws Exception {

        HashMap<String, String> response = new HashMap<>();
        try {
            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.USERID_SM_HEADER, userId );
            headers.put( Constants.ORGID_SM_HEADER, orgId );
            headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, DataSetupConstants.DEFAULT_PASSWORD ) );

            Map<String, String> params = new HashMap<>();
            params.put( Constants.ORGIDS_HEADER, selectedOrgUds );
            response = RestHttpClientUtil.GET( smUrl, LicenseConstants.GET_FOCUS_LICENSE_USAGE, headers, params );

        } catch ( Exception e ) {
            e.getStackTrace();
        }
        return response;
    }

}
