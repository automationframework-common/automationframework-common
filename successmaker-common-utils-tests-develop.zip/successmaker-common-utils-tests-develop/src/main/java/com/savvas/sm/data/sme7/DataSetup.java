package com.savvas.sm.data.sme7;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.testng.annotations.BeforeSuite;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperOrganization;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

public class DataSetup extends DataSetupProcessor {

    private SqlHelperOrganization orgHelper;
    private UserSqlHelper userHelper;
    private String smUrl;
    private static String sessionCookie;

    public static HashMap<String, String> teacherDetailsMap = new HashMap<String, String>();
    public static HashMap<String, String> studentDetailsMap = null;
    public static HashMap<String, String> groupDetailsMap = null;
    public static HashMap<String, String> groupStudents = null;
    public static HashMap<String, String> studentsGroupMap = null;
    public static HashMap<String, String> assignmentsStudentsMap = null;
    public static HashMap<String, HashMap<String, String>> teacherStudentMap = new HashMap<>();
    public static HashMap<String, HashMap<String, String>> teacherGroupMap = new HashMap<>();
    public static HashMap<String, HashMap<String, String>> teacherAssignmentMap = new HashMap<>();
    public static HashMap<String, HashMap<String, String>> studentAssignmentMap = new HashMap<>();
    public static HashMap<String, HashMap<String, String>> studentgroupMap = new HashMap<>();
    public static HashMap<String, HashMap<String, String>> groupStudentsMap = new HashMap<>();
    public static Integer organizationId;

    public DataSetup() {
        orgHelper = new SqlHelperOrganization();
        userHelper = new UserSqlHelper();
        smUrl = configProperty.getProperty( "SMAppUrl" );
    }

    @BeforeSuite ( alwaysRun = true )
    public void testDataSetup() throws Exception {

        setupData();
    }

    public void setupData() throws Exception {
        cleanData();
        loadData();
    }

    private void cleanData() {
        orgHelper.deleteOrganization( DataSetupConstants.BVT_SCHOOL );
    }

    private void loadData() {

        int teacherStartIndex = 1;
        int teacherEndIndex = DataSetupConstants.TEACHER_COUNT;

        String overrideDataSetup = System.getProperty( "overrideDataSetup" ) != null ? System.getProperty( "overrideDataSetup" ) : "false";
        boolean overrideDataSetupSettings = Boolean.parseBoolean( overrideDataSetup );
        if ( overrideDataSetupSettings ) {
            String teacherNumberToCreate = System.getProperty( "teacherNumber" ) != null ? System.getProperty( "teacherNumber" ) : "0";
            teacherStartIndex = Integer.parseInt( teacherNumberToCreate );
            teacherEndIndex = Integer.parseInt( teacherNumberToCreate );

            System.out.println( "Data Setup Overriden. Teacher start and end indexes are: " + teacherStartIndex + "-" + teacherEndIndex );
        }

        try {
            organizationId = orgHelper.createOrganization( DataSetupConstants.BVT_SCHOOL, DataSetupConstants.BVT_SCHOOL );
            orgHelper.addLicenseToOrg( organizationId, DataSetupConstants.DEFAULT_LICENSE, DataSetupConstants.MATH, 500 );
            orgHelper.addLicenseToOrg( organizationId, DataSetupConstants.DEFAULT_LICENSE, DataSetupConstants.READING, 500 );
            List<Integer> teacherIds = new ArrayList<Integer>();
            List<String> studentIds = new ArrayList<String>();
            List<Integer> groupIds = new ArrayList<Integer>();
            List<String> courseIds = new ArrayList<String>();
            Log.message( "******BVT Data Creation Started!******" );

            for ( int teacherCount = teacherStartIndex; teacherCount <= teacherEndIndex; teacherCount++ ) {

                studentDetailsMap = new HashMap<String, String>();
                teacherIds.clear();
                groupIds.clear();
                studentIds.clear();
                courseIds.clear();

                Faker teacherDetails = new Faker();
                Integer teacherId = userHelper.createTeacher( teacherDetails.name().firstName(), teacherDetails.name().lastName(), String.format( DataSetupConstants.BVT_TEACHER, teacherCount ), Constants.PASSWORD_HASH, organizationId );
                Log.message( "Created Teacher : " + String.format( DataSetupConstants.BVT_TEACHER, teacherCount ) );
                teacherIds.add( teacherId );
                generateJsession( String.format( DataSetupConstants.BVT_TEACHER, teacherCount ), DataSetupConstants.DEFAULT_PASSWORD );
                teacherDetailsMap.put( "Teacher" + teacherCount, getUserDetails( smUrl, sessionCookie, "Teacher", teacherId.toString() ) );

                courseIds.add( createCourse( smUrl, sessionCookie, DataSetupConstants.READING, teacherId.toString(), organizationId.toString(), DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, teacherCount ) ) );
                courseIds.add( createCourse( smUrl, sessionCookie, DataSetupConstants.READING, teacherId.toString(), organizationId.toString(), DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, teacherCount ) ) );
                courseIds.add( createCourse( smUrl, sessionCookie, DataSetupConstants.READING, teacherId.toString(), organizationId.toString(), DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, teacherCount ) ) );

                courseIds.add( createCourse( smUrl, sessionCookie, DataSetupConstants.MATH, teacherId.toString(), organizationId.toString(), DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, teacherCount ) ) );
                courseIds.add( createCourse( smUrl, sessionCookie, DataSetupConstants.MATH, teacherId.toString(), organizationId.toString(), DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, teacherCount ) ) );
                courseIds.add( createCourse( smUrl, sessionCookie, DataSetupConstants.MATH, teacherId.toString(), organizationId.toString(), DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, teacherCount ) ) );

                for ( int groupCount = 1; groupCount <= DataSetupConstants.GROUP_COUNT; groupCount++ ) {

                    Integer groupID = createGroup( smUrl, sessionCookie, String.format( DataSetupConstants.BVT_GROUP, teacherCount, groupCount ), teacherId.toString(), organizationId.toString() );
                    groupIds.add( groupID );

                    Log.message( "Group ( " + String.format( DataSetupConstants.BVT_GROUP, teacherCount, groupCount ) + " ) created for the teacher " + String.format( DataSetupConstants.BVT_TEACHER, teacherCount ) );

                }
                groupDetailsMap = new HashMap<String, String>();
                groupDetailsMap.put( String.format( DataSetupConstants.BVT_TEACHER, teacherCount ), getstudentGroups( smUrl, sessionCookie, teacherId.toString(), organizationId.toString() ) );
                teacherGroupMap.put( String.format( DataSetupConstants.BVT_TEACHER, teacherCount ), groupDetailsMap );

                for ( int studentCount = 1; studentCount <= DataSetupConstants.STUDENT_COUNT; studentCount++ ) {

                    Faker studentDetails = new Faker();
                    Random random = new Random();
                    Integer grade = random.nextInt( DataSetupConstants.SM_GRADE );
                    String studentId = createStudent( smUrl, sessionCookie, String.format( DataSetupConstants.BVT_STUDENT, teacherCount, studentCount ), studentDetails.name().firstName(),
                            studentDetails.name().nameWithMiddle().substring( 1, 2 ).toUpperCase(), studentDetails.name().lastName(), teacherId.toString(), organizationId.toString(), grade.toString() );
                    studentIds.add( studentId );
                    Log.message( "Created student: " + String.format( DataSetupConstants.BVT_STUDENT, teacherCount, studentCount ) );
                    studentDetailsMap.put( "Student" + studentCount, getUserDetails( smUrl, sessionCookie, "Student", studentId.toString() ) );
                }

                for ( int groupCount = 0; groupCount < 2; groupCount++ ) {
                    for ( int studentCount = 0; studentCount < 3; studentCount++ ) {
                        addStudentToGroup( smUrl, sessionCookie, groupIds.get( groupCount ), studentIds.get( studentCount ), teacherId, organizationId );
                        groupStudents = new HashMap<String, String>();
                        groupStudents.put( String.format( DataSetupConstants.BVT_GROUP, teacherCount, groupCount ), getGroupStudent( smUrl, sessionCookie, groupIds.get( groupCount ).toString() ) );
                        studentsGroupMap = new HashMap<String, String>();
                        studentsGroupMap.put( String.format( DataSetupConstants.BVT_STUDENT, teacherCount, studentCount ), getstudentGroups( smUrl, sessionCookie, studentIds.get( groupCount ).toString(), organizationId.toString() ) );
                        Log.message( "Student (" + String.format( DataSetupConstants.BVT_STUDENT, teacherCount, studentCount + 1 ) + ") added in group (" + String.format( DataSetupConstants.BVT_GROUP, teacherCount, groupCount + 1 ) + ")" );
                        studentgroupMap.put( String.format( DataSetupConstants.BVT_STUDENT, teacherCount, studentCount ), studentsGroupMap );
                        groupStudentsMap.put( String.format( DataSetupConstants.BVT_GROUP, teacherCount, groupCount ), groupStudents );
                    }

                }
                for ( int i = 0; i < courseIds.size(); i++ ) {

                    //                    if ( String.format( DataSetupConstants.BVT_TEACHER, teacherCount ).equals( "smsautos1t1" ) ) {
                    //                        // need few unassigned students for this teacher
                    //
                    //                        List<String> studentIdsWithRemoved = new ArrayList<String>();
                    //                        studentIdsWithRemoved = studentIds;
                    //                        studentIdsWithRemoved.remove( 0 );
                    //                        studentIdsWithRemoved.remove( 1 );
                    //
                    //                        assignCourse( smUrl, sessionCookie, DataSetupConstants.READING, organizationId.toString(), teacherId.toString(), courseIds.get( i ), studentIdsWithRemoved );
                    //                        Log.message( "Course Assigned. Course ID - " + courseIds.get( i ) );
                    //                    } else {
                    if ( i < 3 ) {
                        assignCourse( smUrl, sessionCookie, DataSetupConstants.READING, organizationId.toString(), teacherId.toString(), courseIds.get( i ), studentIds );
                        Log.message( "Reading Course Assigned. Course ID - " + courseIds.get( i ) );
                    } else {

                        assignCourse( smUrl, sessionCookie, DataSetupConstants.MATH, organizationId.toString(), teacherId.toString(), courseIds.get( i ), studentIds );
                        Log.message( "Math Course Assigned. Course ID - " + courseIds.get( i ) );
                    }

                }
                for ( int studentCount = 0; studentCount < studentIds.size(); studentCount++ ) {
                    assignmentsStudentsMap = new HashMap<String, String>();
                    assignmentsStudentsMap.put( String.format( DataSetupConstants.BVT_STUDENT, teacherCount, studentCount ),
                            getAssignmentByStudent( smUrl, sessionCookie, studentIds.get( studentCount ).toString(), organizationId.toString(), teacherId.toString() ) );
                    HashMap<String, String> assignmentsTeachersMap = new HashMap<String, String>();
                    studentAssignmentMap.put( String.format( DataSetupConstants.BVT_STUDENT, teacherCount, studentCount ), assignmentsStudentsMap );
                    assignmentsTeachersMap.put( String.format( DataSetupConstants.BVT_TEACHER, teacherCount ), getAssignmentByTeacher( smUrl, sessionCookie, organizationId.toString(), teacherId.toString() ) );
                    teacherAssignmentMap.put( String.format( DataSetupConstants.BVT_TEACHER, teacherCount ), assignmentsTeachersMap );
                }
                Log.message( "Data creation completed for " + String.format( DataSetupConstants.BVT_TEACHER, teacherCount ) );
                teacherStudentMap.put( String.format( DataSetupConstants.BVT_TEACHER, teacherCount ), studentDetailsMap );
                sessionInvalidate();
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    private void generateJsession( String userName, String password ) {
        try {
            sessionCookie = getJessionCookie( smUrl, userName, password );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    private void sessionInvalidate() throws Exception {
        invalidateSession( smUrl, sessionCookie );
    }
}
