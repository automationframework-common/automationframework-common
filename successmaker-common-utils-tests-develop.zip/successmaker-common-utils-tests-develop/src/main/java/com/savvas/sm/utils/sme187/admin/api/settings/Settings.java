package com.savvas.sm.utils.sme187.admin.api.settings;

import com.savvas.sm.config.EnvProperties;

public class Settings extends EnvProperties {

}
