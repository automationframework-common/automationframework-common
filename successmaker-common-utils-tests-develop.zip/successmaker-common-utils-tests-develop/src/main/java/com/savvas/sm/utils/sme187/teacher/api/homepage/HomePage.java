package com.savvas.sm.utils.sme187.teacher.api.homepage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.sme187.teacher.api.homepage.HomePageConstants.UsageGoal;

public class HomePage extends EnvProperties {
	
	/**
     * This method is to Edit usage goal for students
     * 
     * @param smUrl
     * @param userID
     * @param orgID
     * @param assignmentUserIds
     * @param date
     * @param hrs
     * @return
     * @throws Exception
     */
	public Map<String, String> putEditUsageGoal(String Url, String token, String orgId, String userId, String date,
			String hrs, List<String> assignmentuserid, String endPoint) throws Exception {
		AtomicReference<String> requestBody = new AtomicReference<>();
		if (endPoint.isEmpty()) {
			endPoint = UsageGoal.EDIT_USAGE_GOAL;
		}
		Map<String, String> headers = new HashMap<>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.AUTHORIZATION, "Bearer " + token);
		headers.put(Constants.ORGID_SM_HEADER, orgId);
		headers.put(Constants.USERID_SM_HEADER, userId);
		requestBody.set(SMUtils.getPayload(PayloadFor.TEACHER, "editUsageGoal.json"));
		requestBody.set(JSONUtil.setProperty(requestBody.get(), "targetGoalEndDate", date));
		requestBody.set(JSONUtil.setProperty(requestBody.get(), "targetHours", hrs));
		requestBody.set(JSONUtil.setProperty(requestBody.get(), "assignmentUserIds", assignmentuserid));
		return RestHttpClientUtil.PUT(Url, headers, new HashMap<>(), endPoint, requestBody.get());

	}
     
	

    /**
     * This method is to get the list of student details from Usage Goals
     * 
     * @param smUrl
     * @param headers
     * @param staffId
     * @param orgId
     * @param assignmentUserIds
     * @param subjectTypeId
     * @return
     * @throws Exception
     */
    public Map<String, String> getUsageGoalStudentList( String smUrl, Map<String, String> headers, String staffId, String orgId, List<String> assignmentUserIds, String subjectTypeId ) throws Exception {
        HashMap<String, String> response = null;

        try {

            // Input Params
            HashMap<String, String> params = new HashMap<>();

            // Body
            AtomicReference<String> requestBody = new AtomicReference<>();
            requestBody.set( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.USAGE_GOALS_STUDENT_LIST ) );

            requestBody.set( JSONUtil.setProperty( requestBody.get(), UsageGoal.ASSIGNMENT_USER_IDS, assignmentUserIds ) );
            requestBody.set( JSONUtil.setProperty( requestBody.get(), Constants.SUBJECT_TYPE_ID, subjectTypeId ) );

            String endpoint = UsageGoal.POST_USAGE_GOALS_STUDENT_LIST;
            endpoint = endpoint.replace( "{" + Constants.STAFF_ID_VALUE + "}", staffId );
            endpoint = endpoint.replace( "{" + Constants.ORGANIZATION_ID + "}", orgId );

            //Hitting Post call for student usage
            response = RestHttpClientUtil.POST( smUrl, headers, params, endpoint, requestBody.get() );
            Log.message( "The response is : " + response.toString() );
            return response;

        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }

    }

    /**
     * This method is to get the list of student details from Usage Goals API
     * 
     * @param smUrl
     * @param token
     * @param orgId
     * @param userId
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getUsageGoalAPI( String smUrl, String token, String orgId, String userId ) throws Exception {
        String endPoint = "/lms/web/api/v1/usagegoals";
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( Constants.ORGID_SM_HEADER, orgId );
        headers.put( Constants.USERID_SM_HEADER, userId );
        return RestHttpClientUtil.GET( smUrl, endPoint, headers, new HashMap<>() );
    }


}

