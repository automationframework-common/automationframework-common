package com.savvas.sm.utils.json;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.SMUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class JsonUtils {

    public static List<String> getKeyValues( JSONObject json, String key ) {
        ArrayList<String> keyValues = new ArrayList<>();

        Boolean exists = json.has( key );
        Iterator<?> keys;
        String nextKeys;
        if ( !exists ) {
            keys = json.keys();
            while ( keys.hasNext() ) {
                nextKeys = (String) keys.next();
                try {
                    if ( json.get( nextKeys ) instanceof JSONObject ) {
                        if ( Boolean.FALSE.equals( false ) ) {
                            getKeyValues( json.getJSONObject( nextKeys ), key );
                        }

                    } else if ( json.get( nextKeys ) instanceof JSONArray ) {
                        JSONArray jsonarray = json.getJSONArray( nextKeys );
                        for ( int i = 0; i < jsonarray.length(); i++ ) {
                            String jsonArrayString = jsonarray.get( i ).toString();
                            JSONObject innerJSOn = new JSONObject( jsonArrayString );
                            if ( Boolean.FALSE.equals( false ) ) {
                                getKeyValues( innerJSOn, key );
                            }
                        }
                    }

                } catch ( Exception e ) {
                    Log.message( "The key is not found" );
                }
            }

        } else {
            keyValues.add( json.get( key ).toString() );
        }
        return keyValues;
    }

    /**
     * ss get the payload JSON as a String
     *
     * @param fileName with .Json extension
     * @return
     */
    public static String getPayLoadAsString( String fileName ) {
        try {
            String payload = new File( "." ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "PayLoad" + File.separator + fileName;
            String requestBody = SMUtils.convertFileToString( payload );
            return requestBody;
        } catch ( IOException e ) {
            e.printStackTrace();
            Log.message( "Error in file path" );
            return null;
        }
    }

    /**
     * Format the string with appending text of '","' to the list of values
     */
    public static String formatListForJSON( List<String> values ) {
        StringBuffer strBuffer = new StringBuffer();
        for ( int i = 0; i < values.size(); i++ ) {
            if ( i != 0 ) {
                strBuffer.append( "\"" + "," + "\"" );
                strBuffer.append( values.get( i ) );
            } else {
                strBuffer.append( values.get( i ) );
            }
        }
        return strBuffer.toString();
    }
}