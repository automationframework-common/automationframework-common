package com.savvas.sm.utils.sme187.admin.api.settings;

import java.util.List;
import java.util.Map;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.constants.AdminConstants;

import io.restassured.response.Response;

public class HolidaySchedulerBFF {

    /**
     * This method is used to Create an Holidays
     * 
     * @param smUrl
     * @param headers
     * @param userId
     * @param orgId
     * @param saveHolidayData
     * @param queryItems
     * @return
     */
    public Response saveHoliday_BFF( Map<String, String> headers, String subRoleType, String userId, String orgId, String saveHolidayData, String queryItems, String selectedOrgId ) {

        String query = AdminConstants.SAVE_HOLIDAY_SCHEDULER_PAYLOAD;
        query = query.replace( Constants.SUB_ROLL_TYPE, subRoleType );
        query = query.replace( Constants.USER_ID_VALUE, userId );
        query = query.replace( Constants.ORG_ID, orgId );
        query = query.replace( AdminConstants.SELECTED_ORG_ID, selectedOrgId );
        query = query.replace( Constants.HOLIDAY_DATA, saveHolidayData );
        query = query.replace( AdminConstants.QUERY_ITEM, queryItems );
        return RestAssuredAPIUtil.POSTGraphQl( AdminConstants.ADMIN_DASHBOARD_BFF, headers, query, AdminConstants.GRAPHQL_ENDPOINT );
    }

    /**
     * This method is used to GET an Holidays
     * 
     * @param smUrl
     * @param headers
     * @param userId
     * @param orgId
     * @param queryItems
     * @return
     */
    public Response getHoliday_BFF( Map<String, String> headers, String subRoleType, String userId, String orgId, List<String> queryItems, String selectedOrgId ) {

        String query = AdminConstants.GET_HOLIDAY_SCHEDULER_PAYLOAD;
        query = query.replace( Constants.SUB_ROLL_TYPE, subRoleType );
        query = query.replace( Constants.USER_ID_VALUE, userId );
        query = query.replace( Constants.ORG_ID, orgId );
        query = query.replace( AdminConstants.SELECTED_ORG_ID, selectedOrgId );
        StringBuilder frameQuery = new StringBuilder();
        frameQuery.append( "{" );
        queryItems.forEach( querItem -> {
            if ( frameQuery.toString().equals( "{" ) ) {
                frameQuery.append( querItem );
            } else {
                frameQuery.append( "," + querItem );
            }
        } );
        frameQuery.append( "}" );

        query = query.replace( AdminConstants.QUERY_ITEM, frameQuery.toString() );
        Log.message( "query is "+ query);
        return RestAssuredAPIUtil.POSTGraphQl( AdminConstants.ADMIN_DASHBOARD_BFF, headers, query, AdminConstants.GRAPHQL_ENDPOINT );
    }

    /**
     * This method is used to Delete an Holidays
     * 
     * @param smUrl
     * @param headers
     * @param userId
     * @param orgId
     * @param saveHolidayData
     * @param queryItems
     * @return
     */
    public Response deleteHoliday_BFF( Map<String, String> headers, String subRoleType, String userId, String orgId, String saveHolidayData, String queryItems, String selectedOrgId ) {

        String query = AdminConstants.DELETE_HOLIDAY_SCHEDULER_PAYLOAD;
        query = query.replace( Constants.SUB_ROLL_TYPE, subRoleType );
        query = query.replace( Constants.USER_ID_VALUE, userId );
        query = query.replace( Constants.ORG_ID, orgId );
        query = query.replace( AdminConstants.SELECTED_ORG_ID, selectedOrgId );
        query = query.replace( Constants.HOLIDAY_DATA, saveHolidayData );
        query = query.replace( AdminConstants.QUERY_ITEM, queryItems );
        return RestAssuredAPIUtil.POSTGraphQl( AdminConstants.ADMIN_DASHBOARD_BFF, headers, query, AdminConstants.GRAPHQL_ENDPOINT );
    }

    /**
     * This method gets the subrole type for BFF login admin
     * 
     * @param userID
     * @param orgID
     * @param headers
     * @param role
     * @return
     */
    public Response getSubRoleTypeBFF( String userID, String orgID, Map<String, String> headers, String role, String selectedOrgId ) {
        String body = AdminConstants.SUBROLETYPE_PAYLOAD;
        body = body.replace( "{userID}", userID ).replace( "{orgID}", orgID ).replace( "{role}", role ).replace( "{selectedOrgId}", selectedOrgId );
        return RestAssuredAPIUtil.POSTGraphQl( AdminConstants.ADMIN_DASHBOARD_BFF, headers, body, AdminConstants.GRAPHQL_ENDPOINT );

    }

}
