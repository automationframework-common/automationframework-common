Prerequisites

Java 1.8
Gradle 5.6.4


Add below code for initialization to set up the test data

    /**
     * 
     * @param args
     * @throws Exception
     */
    public static void main( String[] args ) throws Exception {
        DataSetup helper = new DataSetup();
        helper.setupData();
    }