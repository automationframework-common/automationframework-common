SELECT 
    content_base.content_base_id, content_base.content_base_name,
    ( SELECT organization_id from school.organization_content_base  WHERE organization_content_base.content_base_id = content_base.content_base_id ORDER BY date_created limit 1 ),
    ( SELECT count(*)  FROM school.organization_content_base WHERE content_base_id = content_base.content_base_id GROUP BY content_base_id ) as sharedOrgCount 
    FROM School.content_base
    INNER JOIN school.enrollment_option using (content_base_id)
    WHERE  
        enrollment_option.option_name ='pst.enrollment_option.shared_courses' and 
        enrollment_option.isdeleted =0 AND 
        content_base.isdeleted IS NULL AND 
        enrollment_option.default_value = 'true'
    GROUP BY content_base.content_base_id, content_base.content_base_name;
