WITH RECURSIVE standard_alignment_with_Lo AS 
( 
select btoplevel.bank_id as bankkkk_id,btoplevel.parent_bank_id, btoplevel.is_leaf , btoplevel.version
	from bank btoplevel where btoplevel.standard_version_id=<standard_id> and btoplevel.parent_bank_id=<grade_id> and version='v22'
UNION ALL
select blevel.bank_id, blevel.parent_bank_id, blevel.is_leaf, blevel.version 
	from bank blevel, standard_alignment_with_Lo cte where blevel.standard_version_id=<standard_id> and blevel.parent_bank_id!=0 and blevel.version='v22'
and blevel.parent_bank_id = cte.bankkkk_id and cte.version='v22'
)
SELECT bankkkk_id, string_agg(lo.catalog_num,';' order by lo.catalog_num) as "LO IDs" 
FROM standard_alignment_with_Lo sal, alignment a , learning_object lo where sal.is_leaf=1
and a.bank_id=sal.bankkkk_id and  lo.pearson_lobj_id=a.pearson_content_id and sal.version='v22' and a.version='v22' and lo.version='v22'
group by bankkkk_id order by random() limit 1