SELECT DISTINCT lrfs.assignment_user_id,     
			st.strand_description AS cttype_name,     
			slo.learning_object_id as object_id,     
			(SELECT lrt.lo_review_type_name FROM math_lo_review_type lrt         
				WHERE lrfs.lo_review_type_id = lrt.lo_review_type_id ) AS lo_review_type_name,     
			slo.strand_lo_level AS strand_level,         
			(SELECT lo.lobj_description FROM learning_object lo         
				WHERE slo.learning_object_id = lo.learning_object_id ) AS skill_obj_description,        
			lrfs.lo_review_fail_timestamp AS mastery_status_date,         
			(SELECT lo.catalog_num FROM learning_object lo         
			    WHERE slo.learning_object_id = lo.learning_object_id ) AS catalog_num,        
			(SELECT tl.targeted_lesson_number FROM targeted_lesson tl             
				WHERE tl.targeted_lesson_id = (Select tllo.targeted_lesson_id from targeted_lesson_learning_object tllo where tllo.learning_object_id = slo.learning_object_id ) ) as lesson_number,         (SELECT tl.targeted_lesson_title FROM targeted_lesson  tl              WHERE tl.targeted_lesson_id = (Select tllo.targeted_lesson_id from targeted_lesson_learning_object tllo where tllo.learning_object_id = slo.learning_object_id ) ) as lesson_title  FROM math_strand st, math_lo_review_fail lrfs,         math_strand_learning_object slo,         assignment_user au,         assignment a WHERE     au.isdeleted = 0     AND EXISTS ( SELECT content_base_id FROM content_base cb         WHERE a.content_base_id = cb.content_base_id         AND cb.subject_id = 1 AND cb.content_type_base_id < 3 )         AND lrfs.lo_review_type_id =1         AND au.assignment_user_id = lrfs.assignment_user_id         AND au.assignment_id = a.assignment_id         AND lrfs.learning_object_id = slo.learning_object_id         AND slo.strand_id = st.strand_id    
					AND lrfs.lo_review_fail_timestamp IN
								(SELECT lo_review_fail_timestamp FROM math_lo_review_fail loah WHERE
										loah.assignment_user_id = au.assignment_user_id)     
											AND au.assignment_id IN ({assignmentId})