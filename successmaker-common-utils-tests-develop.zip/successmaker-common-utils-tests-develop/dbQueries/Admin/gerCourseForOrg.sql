SELECT DISTINCT	a.assignment_id,
				    a.assignment_owner_id ,
				    a.assignment_title ,
				    cb.content_base_id ,
				    cb.product_id 
				    FROM assignment a, content_base cb,	assignment_user au
				    WHERE a.content_base_id = cb.content_base_id
					AND a.isdeleted = 0
					AND au.isdeleted = 0 
					AND a.assignment_id = au.assignment_id
					AND cb.subject_id = {subjectTypeId}					
					AND au.person_id IN ({userId})