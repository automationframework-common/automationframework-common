SELECT
    cttype.cttype_name as strandName,
    lo_skill_history.strand_level AS strandLevel,
    skill_objectives.pearson_skill_obj_id AS catalognum,
    skill_objectives.skill_obj_description AS lodescription,
    lo_skill_history.mastery_status_date AS FailedDate,
    mastery_status_name AS MasteryStatus,
    au.assignment_user_id,
    pearson_skill_obj_id as objectiveid,
    (SELECT tl.targeted_lesson_number FROM targeted_lesson_learning_object tlo, targeted_lesson tl, read_session_skill rsk WHERE tl.targeted_lesson_id = tlo.targeted_lesson_id AND tlo.learning_object_id = rsk.learning_object_id AND rsk.assignment_user_id = au.assignment_user_id
     AND rsk.skill_objective_id=skill_objectives.skill_objective_id AND rsk.mastery_status_id IN(3,4) AND tl.subject_id=2 limit 1) AS lessonNumber,
    (SELECT tl.targeted_lesson_title FROM targeted_lesson_learning_object tlo, targeted_lesson tl, read_session_skill rsk WHERE tl.targeted_lesson_id = tlo.targeted_lesson_id AND tlo.learning_object_id = rsk.learning_object_id AND rsk.assignment_user_id = au.assignment_user_id
     AND rsk.skill_objective_id=skill_objectives.skill_objective_id AND rsk.mastery_status_id IN(3,4) AND tl.subject_id=2 limit 1) AS lessonTitle
FROM
    cttype,
    lo_skill_history,
    skill_objectives,
    mastery_status,
    assignment_user au
    Where au.assignment_id IN ({assignmentId})
    AND au.isdeleted = 0
    AND lo_skill_history.assignment_user_id = au.assignment_user_id
    AND lo_skill_history.mastery_status_id IN (3, 4)   
    AND mastery_status.mastery_status_id = lo_skill_history.mastery_status_id
    AND lo_skill_history.skill_objective_id = skill_objectives.skill_objective_id
    AND lo_skill_history.strand_cttype_id = cttype.cttype_id