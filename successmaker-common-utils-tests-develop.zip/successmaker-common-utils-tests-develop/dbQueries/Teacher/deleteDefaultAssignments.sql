delete from school.assignment_session where assignment_user_id in (
select assignment_user_id  from school.assignment_user where asmt_assigner_id = '<rumbaID>');
delete from school.assignment where assignment_owner_id = '<rumbaID>'