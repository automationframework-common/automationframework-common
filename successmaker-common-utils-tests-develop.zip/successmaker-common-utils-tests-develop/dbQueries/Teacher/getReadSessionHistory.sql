select * from school.read_session_history where assignment_user_id in (
select assignment_user_id from assignment_user where asmt_assigner_id ='<rumbaID>'
)
