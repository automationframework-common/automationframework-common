select cttype_id as cttypeIdOfGrade
from successmaker.cttype
where parent_cttype_id in 
    (
    select cttype_id as cttypeId
    from successmaker.cttype
    where cttype_name=<subject_name> 
    order by cttype_id ASC 
    limit 1
    )
and cttype_id Not in ('3268','3269','3270','3271','3272')
order by random() limit 1