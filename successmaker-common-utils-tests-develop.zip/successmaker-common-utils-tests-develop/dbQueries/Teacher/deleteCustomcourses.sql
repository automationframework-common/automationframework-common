delete from school.assignment_session where assignment_user_id in (
select assignment_user_id  from school.assignment_user where asmt_assigner_id = '<rumbaID>');
DELETE from school.content_base where content_type_base_id in (2,3,4)
and content_base_creator_id = '<rumbaID>'