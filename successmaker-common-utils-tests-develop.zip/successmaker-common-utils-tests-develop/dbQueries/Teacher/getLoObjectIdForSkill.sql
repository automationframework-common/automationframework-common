select catalog_num as catalogNumber
from successmaker.learning_object
where learning_object_id in 
	(
	select learning_object_id as LOOBJ_ID
	from successmaker.cttype_learning_object
	where cttype_id=<parent_cttype_id>
	order by random() limit 1
	)
order by random() limit 1