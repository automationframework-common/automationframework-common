select cttype_id from successmaker.cttype 
where parent_cttype_id=
	(
    select cttype_id from successmaker.cttype 
	where parent_cttype_id=(
    	(
    	select cttype_id from successmaker.cttype 
		where parent_cttype_id=<grade_id> and tier_depth=2 
		order by random() 
		limit 1)
    	) 
	and tier_depth=3 
	order by random() limit 1
	) 
and tier_depth=4 
order by random() limit 1